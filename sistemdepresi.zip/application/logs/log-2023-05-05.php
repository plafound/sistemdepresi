<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-05 17:09:50 --> Config Class Initialized
INFO - 2023-05-05 17:09:50 --> Hooks Class Initialized
INFO - 2023-05-05 17:09:50 --> Utf8 Class Initialized
INFO - 2023-05-05 17:09:50 --> URI Class Initialized
INFO - 2023-05-05 17:09:50 --> Router Class Initialized
INFO - 2023-05-05 17:09:50 --> Output Class Initialized
INFO - 2023-05-05 17:09:50 --> Security Class Initialized
INFO - 2023-05-05 17:09:50 --> Input Class Initialized
INFO - 2023-05-05 17:09:50 --> Language Class Initialized
INFO - 2023-05-05 17:09:50 --> Loader Class Initialized
INFO - 2023-05-05 17:09:50 --> Helper loaded: url_helper
INFO - 2023-05-05 17:09:50 --> Helper loaded: form_helper
INFO - 2023-05-05 17:09:50 --> Database Driver Class Initialized
INFO - 2023-05-05 17:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-05 17:09:50 --> Form Validation Class Initialized
INFO - 2023-05-05 17:09:50 --> Controller Class Initialized
INFO - 2023-05-05 17:09:50 --> Model "M_tutor" initialized
INFO - 2023-05-05 17:09:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-05 17:09:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-05 17:09:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-05 17:09:50 --> Final output sent to browser
INFO - 2023-05-05 17:13:07 --> Config Class Initialized
INFO - 2023-05-05 17:13:07 --> Hooks Class Initialized
INFO - 2023-05-05 17:13:07 --> Utf8 Class Initialized
INFO - 2023-05-05 17:13:07 --> URI Class Initialized
INFO - 2023-05-05 17:13:07 --> Router Class Initialized
INFO - 2023-05-05 17:13:07 --> Output Class Initialized
INFO - 2023-05-05 17:13:07 --> Security Class Initialized
INFO - 2023-05-05 17:13:07 --> Input Class Initialized
INFO - 2023-05-05 17:13:07 --> Language Class Initialized
INFO - 2023-05-05 17:13:07 --> Loader Class Initialized
INFO - 2023-05-05 17:13:07 --> Helper loaded: url_helper
INFO - 2023-05-05 17:13:07 --> Helper loaded: form_helper
INFO - 2023-05-05 17:13:07 --> Database Driver Class Initialized
INFO - 2023-05-05 17:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-05 17:13:07 --> Form Validation Class Initialized
INFO - 2023-05-05 17:13:07 --> Controller Class Initialized
INFO - 2023-05-05 17:13:07 --> Model "M_tutor" initialized
INFO - 2023-05-05 17:13:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-05 17:13:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-05 17:13:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-05 17:13:07 --> Final output sent to browser
INFO - 2023-05-05 17:17:01 --> Config Class Initialized
INFO - 2023-05-05 17:17:01 --> Hooks Class Initialized
INFO - 2023-05-05 17:17:01 --> Utf8 Class Initialized
INFO - 2023-05-05 17:17:01 --> URI Class Initialized
INFO - 2023-05-05 17:17:01 --> Router Class Initialized
INFO - 2023-05-05 17:17:01 --> Output Class Initialized
INFO - 2023-05-05 17:17:01 --> Security Class Initialized
INFO - 2023-05-05 17:17:01 --> Input Class Initialized
INFO - 2023-05-05 17:17:01 --> Language Class Initialized
INFO - 2023-05-05 17:17:01 --> Loader Class Initialized
INFO - 2023-05-05 17:17:01 --> Helper loaded: url_helper
INFO - 2023-05-05 17:17:01 --> Helper loaded: form_helper
INFO - 2023-05-05 17:17:01 --> Database Driver Class Initialized
INFO - 2023-05-05 17:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-05 17:17:01 --> Form Validation Class Initialized
INFO - 2023-05-05 17:17:01 --> Controller Class Initialized
INFO - 2023-05-05 17:17:01 --> Model "M_tutor" initialized
INFO - 2023-05-05 17:17:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-05 17:17:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-05 17:17:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-05 17:17:01 --> Final output sent to browser
INFO - 2023-05-05 17:17:07 --> Config Class Initialized
INFO - 2023-05-05 17:17:07 --> Hooks Class Initialized
INFO - 2023-05-05 17:17:07 --> Utf8 Class Initialized
INFO - 2023-05-05 17:17:07 --> URI Class Initialized
INFO - 2023-05-05 17:17:07 --> Router Class Initialized
INFO - 2023-05-05 17:17:07 --> Output Class Initialized
INFO - 2023-05-05 17:17:07 --> Security Class Initialized
INFO - 2023-05-05 17:17:07 --> Input Class Initialized
INFO - 2023-05-05 17:17:07 --> Language Class Initialized
INFO - 2023-05-05 17:17:07 --> Loader Class Initialized
INFO - 2023-05-05 17:17:07 --> Helper loaded: url_helper
INFO - 2023-05-05 17:17:07 --> Helper loaded: form_helper
INFO - 2023-05-05 17:17:07 --> Database Driver Class Initialized
INFO - 2023-05-05 17:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-05 17:17:07 --> Form Validation Class Initialized
INFO - 2023-05-05 17:17:07 --> Controller Class Initialized
INFO - 2023-05-05 17:17:07 --> Model "M_tutor" initialized
INFO - 2023-05-05 17:17:07 --> Config Class Initialized
INFO - 2023-05-05 17:17:07 --> Hooks Class Initialized
INFO - 2023-05-05 17:17:07 --> Utf8 Class Initialized
INFO - 2023-05-05 17:17:07 --> URI Class Initialized
INFO - 2023-05-05 17:17:07 --> Router Class Initialized
INFO - 2023-05-05 17:17:07 --> Output Class Initialized
INFO - 2023-05-05 17:17:07 --> Security Class Initialized
INFO - 2023-05-05 17:17:07 --> Input Class Initialized
INFO - 2023-05-05 17:17:07 --> Language Class Initialized
INFO - 2023-05-05 17:17:07 --> Loader Class Initialized
INFO - 2023-05-05 17:17:07 --> Helper loaded: url_helper
INFO - 2023-05-05 17:17:07 --> Helper loaded: form_helper
INFO - 2023-05-05 17:17:07 --> Database Driver Class Initialized
INFO - 2023-05-05 17:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-05 17:17:07 --> Form Validation Class Initialized
INFO - 2023-05-05 17:17:07 --> Controller Class Initialized
INFO - 2023-05-05 17:17:07 --> Model "M_tutor" initialized
INFO - 2023-05-05 17:17:07 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-05 17:17:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-05 17:17:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-05 17:17:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-05 17:17:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-05 17:17:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-05 17:17:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-05 17:17:07 --> Final output sent to browser
INFO - 2023-05-05 17:17:17 --> Config Class Initialized
INFO - 2023-05-05 17:17:17 --> Hooks Class Initialized
INFO - 2023-05-05 17:17:17 --> Utf8 Class Initialized
INFO - 2023-05-05 17:17:17 --> URI Class Initialized
INFO - 2023-05-05 17:17:17 --> Router Class Initialized
INFO - 2023-05-05 17:17:17 --> Output Class Initialized
INFO - 2023-05-05 17:17:17 --> Security Class Initialized
INFO - 2023-05-05 17:17:17 --> Input Class Initialized
INFO - 2023-05-05 17:17:17 --> Language Class Initialized
INFO - 2023-05-05 17:17:17 --> Loader Class Initialized
INFO - 2023-05-05 17:17:17 --> Helper loaded: url_helper
INFO - 2023-05-05 17:17:17 --> Helper loaded: form_helper
INFO - 2023-05-05 17:17:17 --> Database Driver Class Initialized
INFO - 2023-05-05 17:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-05 17:17:17 --> Form Validation Class Initialized
INFO - 2023-05-05 17:17:17 --> Controller Class Initialized
INFO - 2023-05-05 17:17:17 --> Model "M_tutor" initialized
INFO - 2023-05-05 17:17:17 --> Config Class Initialized
INFO - 2023-05-05 17:17:17 --> Hooks Class Initialized
INFO - 2023-05-05 17:17:17 --> Utf8 Class Initialized
INFO - 2023-05-05 17:17:17 --> URI Class Initialized
INFO - 2023-05-05 17:17:17 --> Router Class Initialized
INFO - 2023-05-05 17:17:17 --> Output Class Initialized
INFO - 2023-05-05 17:17:17 --> Security Class Initialized
INFO - 2023-05-05 17:17:17 --> Input Class Initialized
INFO - 2023-05-05 17:17:17 --> Language Class Initialized
INFO - 2023-05-05 17:17:17 --> Loader Class Initialized
INFO - 2023-05-05 17:17:17 --> Helper loaded: url_helper
INFO - 2023-05-05 17:17:17 --> Helper loaded: form_helper
INFO - 2023-05-05 17:17:17 --> Database Driver Class Initialized
INFO - 2023-05-05 17:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-05 17:17:17 --> Form Validation Class Initialized
INFO - 2023-05-05 17:17:17 --> Controller Class Initialized
INFO - 2023-05-05 17:17:17 --> Model "M_tutor" initialized
INFO - 2023-05-05 17:17:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-05 17:17:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-05 17:17:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-05 17:17:17 --> Final output sent to browser
INFO - 2023-05-05 17:29:12 --> Config Class Initialized
INFO - 2023-05-05 17:29:12 --> Hooks Class Initialized
INFO - 2023-05-05 17:29:12 --> Utf8 Class Initialized
INFO - 2023-05-05 17:29:12 --> URI Class Initialized
INFO - 2023-05-05 17:29:12 --> Router Class Initialized
INFO - 2023-05-05 17:29:12 --> Output Class Initialized
INFO - 2023-05-05 17:29:12 --> Security Class Initialized
INFO - 2023-05-05 17:29:12 --> Input Class Initialized
INFO - 2023-05-05 17:29:12 --> Language Class Initialized
INFO - 2023-05-05 17:29:12 --> Loader Class Initialized
INFO - 2023-05-05 17:29:12 --> Helper loaded: url_helper
INFO - 2023-05-05 17:29:12 --> Helper loaded: form_helper
INFO - 2023-05-05 17:29:12 --> Database Driver Class Initialized
INFO - 2023-05-05 17:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-05 17:29:12 --> Form Validation Class Initialized
INFO - 2023-05-05 17:29:12 --> Controller Class Initialized
INFO - 2023-05-05 17:29:12 --> Model "M_tutor" initialized
INFO - 2023-05-05 17:29:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-05 17:29:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-05 17:29:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-05 17:29:12 --> Final output sent to browser
INFO - 2023-05-05 18:06:54 --> Config Class Initialized
INFO - 2023-05-05 18:06:54 --> Hooks Class Initialized
INFO - 2023-05-05 18:06:54 --> Utf8 Class Initialized
INFO - 2023-05-05 18:06:54 --> URI Class Initialized
INFO - 2023-05-05 18:06:54 --> Router Class Initialized
INFO - 2023-05-05 18:06:54 --> Output Class Initialized
INFO - 2023-05-05 18:06:54 --> Security Class Initialized
INFO - 2023-05-05 18:06:54 --> Input Class Initialized
INFO - 2023-05-05 18:06:54 --> Language Class Initialized
INFO - 2023-05-05 18:06:54 --> Loader Class Initialized
INFO - 2023-05-05 18:06:54 --> Helper loaded: url_helper
INFO - 2023-05-05 18:06:54 --> Helper loaded: form_helper
INFO - 2023-05-05 18:06:54 --> Database Driver Class Initialized
INFO - 2023-05-05 18:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-05 18:06:54 --> Form Validation Class Initialized
INFO - 2023-05-05 18:06:54 --> Controller Class Initialized
INFO - 2023-05-05 18:06:54 --> Model "M_tutor" initialized
INFO - 2023-05-05 18:06:55 --> Config Class Initialized
INFO - 2023-05-05 18:06:55 --> Hooks Class Initialized
INFO - 2023-05-05 18:06:55 --> Utf8 Class Initialized
INFO - 2023-05-05 18:06:55 --> URI Class Initialized
INFO - 2023-05-05 18:06:55 --> Router Class Initialized
INFO - 2023-05-05 18:06:55 --> Output Class Initialized
INFO - 2023-05-05 18:06:55 --> Security Class Initialized
INFO - 2023-05-05 18:06:55 --> Input Class Initialized
INFO - 2023-05-05 18:06:55 --> Language Class Initialized
INFO - 2023-05-05 18:06:55 --> Loader Class Initialized
INFO - 2023-05-05 18:06:55 --> Helper loaded: url_helper
INFO - 2023-05-05 18:06:55 --> Helper loaded: form_helper
INFO - 2023-05-05 18:06:55 --> Database Driver Class Initialized
INFO - 2023-05-05 18:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-05 18:06:55 --> Form Validation Class Initialized
INFO - 2023-05-05 18:06:55 --> Controller Class Initialized
INFO - 2023-05-05 18:06:55 --> Model "M_tutor" initialized
INFO - 2023-05-05 18:06:55 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-05 18:06:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-05 18:06:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-05 18:06:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-05 18:06:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-05 18:06:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-05 18:06:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-05 18:06:55 --> Final output sent to browser
