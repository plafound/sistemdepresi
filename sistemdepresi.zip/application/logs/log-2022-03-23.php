<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-23 03:26:57 --> Config Class Initialized
INFO - 2022-03-23 03:26:57 --> Hooks Class Initialized
INFO - 2022-03-23 03:26:57 --> Utf8 Class Initialized
INFO - 2022-03-23 03:26:57 --> URI Class Initialized
INFO - 2022-03-23 03:26:57 --> Router Class Initialized
INFO - 2022-03-23 03:26:57 --> Output Class Initialized
INFO - 2022-03-23 03:26:58 --> Security Class Initialized
INFO - 2022-03-23 03:26:58 --> Input Class Initialized
INFO - 2022-03-23 03:26:58 --> Language Class Initialized
INFO - 2022-03-23 03:26:58 --> Loader Class Initialized
INFO - 2022-03-23 03:26:58 --> Helper loaded: url_helper
INFO - 2022-03-23 03:26:58 --> Helper loaded: form_helper
INFO - 2022-03-23 03:26:58 --> Database Driver Class Initialized
INFO - 2022-03-23 03:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:26:58 --> Form Validation Class Initialized
INFO - 2022-03-23 03:26:58 --> Controller Class Initialized
INFO - 2022-03-23 03:26:59 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:26:59 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-23 03:26:59 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-23 03:26:59 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-23 03:26:59 --> Final output sent to browser
INFO - 2022-03-23 03:27:06 --> Config Class Initialized
INFO - 2022-03-23 03:27:06 --> Hooks Class Initialized
INFO - 2022-03-23 03:27:06 --> Utf8 Class Initialized
INFO - 2022-03-23 03:27:06 --> URI Class Initialized
INFO - 2022-03-23 03:27:06 --> Router Class Initialized
INFO - 2022-03-23 03:27:06 --> Output Class Initialized
INFO - 2022-03-23 03:27:06 --> Security Class Initialized
INFO - 2022-03-23 03:27:06 --> Input Class Initialized
INFO - 2022-03-23 03:27:06 --> Language Class Initialized
INFO - 2022-03-23 03:27:06 --> Loader Class Initialized
INFO - 2022-03-23 03:27:06 --> Helper loaded: url_helper
INFO - 2022-03-23 03:27:06 --> Helper loaded: form_helper
INFO - 2022-03-23 03:27:06 --> Database Driver Class Initialized
INFO - 2022-03-23 03:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:27:06 --> Form Validation Class Initialized
INFO - 2022-03-23 03:27:06 --> Controller Class Initialized
INFO - 2022-03-23 03:27:06 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:27:06 --> Config Class Initialized
INFO - 2022-03-23 03:27:06 --> Hooks Class Initialized
INFO - 2022-03-23 03:27:06 --> Utf8 Class Initialized
INFO - 2022-03-23 03:27:06 --> URI Class Initialized
INFO - 2022-03-23 03:27:06 --> Router Class Initialized
INFO - 2022-03-23 03:27:06 --> Output Class Initialized
INFO - 2022-03-23 03:27:06 --> Security Class Initialized
INFO - 2022-03-23 03:27:06 --> Input Class Initialized
INFO - 2022-03-23 03:27:06 --> Language Class Initialized
INFO - 2022-03-23 03:27:06 --> Loader Class Initialized
INFO - 2022-03-23 03:27:06 --> Helper loaded: url_helper
INFO - 2022-03-23 03:27:06 --> Helper loaded: form_helper
INFO - 2022-03-23 03:27:06 --> Database Driver Class Initialized
INFO - 2022-03-23 03:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:27:06 --> Form Validation Class Initialized
INFO - 2022-03-23 03:27:06 --> Controller Class Initialized
INFO - 2022-03-23 03:27:06 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:27:06 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-23 03:27:06 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-23 03:27:06 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-23 03:27:06 --> Final output sent to browser
INFO - 2022-03-23 03:27:11 --> Config Class Initialized
INFO - 2022-03-23 03:27:11 --> Hooks Class Initialized
INFO - 2022-03-23 03:27:11 --> Utf8 Class Initialized
INFO - 2022-03-23 03:27:11 --> URI Class Initialized
INFO - 2022-03-23 03:27:11 --> Router Class Initialized
INFO - 2022-03-23 03:27:11 --> Output Class Initialized
INFO - 2022-03-23 03:27:11 --> Security Class Initialized
INFO - 2022-03-23 03:27:11 --> Input Class Initialized
INFO - 2022-03-23 03:27:11 --> Language Class Initialized
INFO - 2022-03-23 03:27:11 --> Loader Class Initialized
INFO - 2022-03-23 03:27:11 --> Helper loaded: url_helper
INFO - 2022-03-23 03:27:11 --> Helper loaded: form_helper
INFO - 2022-03-23 03:27:11 --> Database Driver Class Initialized
INFO - 2022-03-23 03:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:27:11 --> Form Validation Class Initialized
INFO - 2022-03-23 03:27:11 --> Controller Class Initialized
INFO - 2022-03-23 03:27:11 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:27:11 --> Config Class Initialized
INFO - 2022-03-23 03:27:11 --> Hooks Class Initialized
INFO - 2022-03-23 03:27:11 --> Utf8 Class Initialized
INFO - 2022-03-23 03:27:11 --> URI Class Initialized
INFO - 2022-03-23 03:27:11 --> Router Class Initialized
INFO - 2022-03-23 03:27:11 --> Output Class Initialized
INFO - 2022-03-23 03:27:11 --> Security Class Initialized
INFO - 2022-03-23 03:27:11 --> Input Class Initialized
INFO - 2022-03-23 03:27:11 --> Language Class Initialized
INFO - 2022-03-23 03:27:11 --> Loader Class Initialized
INFO - 2022-03-23 03:27:11 --> Helper loaded: url_helper
INFO - 2022-03-23 03:27:11 --> Helper loaded: form_helper
INFO - 2022-03-23 03:27:11 --> Database Driver Class Initialized
INFO - 2022-03-23 03:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:27:12 --> Form Validation Class Initialized
INFO - 2022-03-23 03:27:12 --> Controller Class Initialized
INFO - 2022-03-23 03:27:12 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:27:12 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-23 03:27:12 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-23 03:27:12 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-23 03:27:12 --> Final output sent to browser
INFO - 2022-03-23 03:27:16 --> Config Class Initialized
INFO - 2022-03-23 03:27:16 --> Hooks Class Initialized
INFO - 2022-03-23 03:27:16 --> Utf8 Class Initialized
INFO - 2022-03-23 03:27:16 --> URI Class Initialized
INFO - 2022-03-23 03:27:16 --> Router Class Initialized
INFO - 2022-03-23 03:27:16 --> Output Class Initialized
INFO - 2022-03-23 03:27:16 --> Security Class Initialized
INFO - 2022-03-23 03:27:16 --> Input Class Initialized
INFO - 2022-03-23 03:27:16 --> Language Class Initialized
INFO - 2022-03-23 03:27:16 --> Loader Class Initialized
INFO - 2022-03-23 03:27:16 --> Helper loaded: url_helper
INFO - 2022-03-23 03:27:16 --> Helper loaded: form_helper
INFO - 2022-03-23 03:27:16 --> Database Driver Class Initialized
INFO - 2022-03-23 03:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:27:16 --> Form Validation Class Initialized
INFO - 2022-03-23 03:27:16 --> Controller Class Initialized
INFO - 2022-03-23 03:27:16 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:27:17 --> Config Class Initialized
INFO - 2022-03-23 03:27:17 --> Hooks Class Initialized
INFO - 2022-03-23 03:27:17 --> Utf8 Class Initialized
INFO - 2022-03-23 03:27:17 --> URI Class Initialized
INFO - 2022-03-23 03:27:17 --> Router Class Initialized
INFO - 2022-03-23 03:27:17 --> Output Class Initialized
INFO - 2022-03-23 03:27:17 --> Security Class Initialized
INFO - 2022-03-23 03:27:17 --> Input Class Initialized
INFO - 2022-03-23 03:27:17 --> Language Class Initialized
INFO - 2022-03-23 03:27:17 --> Loader Class Initialized
INFO - 2022-03-23 03:27:17 --> Helper loaded: url_helper
INFO - 2022-03-23 03:27:17 --> Helper loaded: form_helper
INFO - 2022-03-23 03:27:17 --> Database Driver Class Initialized
INFO - 2022-03-23 03:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:27:17 --> Form Validation Class Initialized
INFO - 2022-03-23 03:27:17 --> Controller Class Initialized
INFO - 2022-03-23 03:27:17 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:27:17 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-23 03:27:17 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-23 03:27:17 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-23 03:27:17 --> Final output sent to browser
INFO - 2022-03-23 03:27:22 --> Config Class Initialized
INFO - 2022-03-23 03:27:22 --> Hooks Class Initialized
INFO - 2022-03-23 03:27:22 --> Utf8 Class Initialized
INFO - 2022-03-23 03:27:22 --> URI Class Initialized
INFO - 2022-03-23 03:27:22 --> Router Class Initialized
INFO - 2022-03-23 03:27:22 --> Output Class Initialized
INFO - 2022-03-23 03:27:22 --> Security Class Initialized
INFO - 2022-03-23 03:27:22 --> Input Class Initialized
INFO - 2022-03-23 03:27:22 --> Language Class Initialized
INFO - 2022-03-23 03:27:22 --> Loader Class Initialized
INFO - 2022-03-23 03:27:22 --> Helper loaded: url_helper
INFO - 2022-03-23 03:27:22 --> Helper loaded: form_helper
INFO - 2022-03-23 03:27:22 --> Database Driver Class Initialized
INFO - 2022-03-23 03:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:27:22 --> Form Validation Class Initialized
INFO - 2022-03-23 03:27:22 --> Controller Class Initialized
INFO - 2022-03-23 03:27:22 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:27:22 --> Config Class Initialized
INFO - 2022-03-23 03:27:22 --> Hooks Class Initialized
INFO - 2022-03-23 03:27:22 --> Utf8 Class Initialized
INFO - 2022-03-23 03:27:22 --> URI Class Initialized
INFO - 2022-03-23 03:27:22 --> Router Class Initialized
INFO - 2022-03-23 03:27:22 --> Output Class Initialized
INFO - 2022-03-23 03:27:22 --> Security Class Initialized
INFO - 2022-03-23 03:27:22 --> Input Class Initialized
INFO - 2022-03-23 03:27:22 --> Language Class Initialized
INFO - 2022-03-23 03:27:22 --> Loader Class Initialized
INFO - 2022-03-23 03:27:22 --> Helper loaded: url_helper
INFO - 2022-03-23 03:27:22 --> Helper loaded: form_helper
INFO - 2022-03-23 03:27:22 --> Database Driver Class Initialized
INFO - 2022-03-23 03:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:27:22 --> Form Validation Class Initialized
INFO - 2022-03-23 03:27:22 --> Controller Class Initialized
INFO - 2022-03-23 03:27:22 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:27:22 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-23 03:27:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-23 03:27:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-23 03:27:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-23 03:27:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-23 03:27:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-23 03:27:22 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-23 03:27:22 --> Final output sent to browser
INFO - 2022-03-23 03:27:29 --> Config Class Initialized
INFO - 2022-03-23 03:27:29 --> Hooks Class Initialized
INFO - 2022-03-23 03:27:29 --> Config Class Initialized
INFO - 2022-03-23 03:27:29 --> Hooks Class Initialized
INFO - 2022-03-23 03:27:29 --> Utf8 Class Initialized
INFO - 2022-03-23 03:27:29 --> Utf8 Class Initialized
INFO - 2022-03-23 03:27:29 --> URI Class Initialized
INFO - 2022-03-23 03:27:29 --> URI Class Initialized
INFO - 2022-03-23 03:27:29 --> Router Class Initialized
INFO - 2022-03-23 03:27:29 --> Router Class Initialized
INFO - 2022-03-23 03:27:29 --> Output Class Initialized
INFO - 2022-03-23 03:27:29 --> Output Class Initialized
INFO - 2022-03-23 03:27:29 --> Security Class Initialized
INFO - 2022-03-23 03:27:29 --> Security Class Initialized
INFO - 2022-03-23 03:27:29 --> Input Class Initialized
INFO - 2022-03-23 03:27:29 --> Language Class Initialized
INFO - 2022-03-23 03:27:29 --> Input Class Initialized
INFO - 2022-03-23 03:27:29 --> Language Class Initialized
INFO - 2022-03-23 03:27:29 --> Loader Class Initialized
INFO - 2022-03-23 03:27:29 --> Helper loaded: url_helper
INFO - 2022-03-23 03:27:29 --> Loader Class Initialized
INFO - 2022-03-23 03:27:29 --> Helper loaded: form_helper
INFO - 2022-03-23 03:27:29 --> Helper loaded: url_helper
INFO - 2022-03-23 03:27:29 --> Helper loaded: form_helper
INFO - 2022-03-23 03:27:29 --> Database Driver Class Initialized
INFO - 2022-03-23 03:27:29 --> Database Driver Class Initialized
INFO - 2022-03-23 03:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:27:29 --> Form Validation Class Initialized
INFO - 2022-03-23 03:27:29 --> Controller Class Initialized
INFO - 2022-03-23 03:27:30 --> Model "M_todo_group" initialized
INFO - 2022-03-23 03:27:30 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-23 03:27:30 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-23 03:27:30 --> Final output sent to browser
INFO - 2022-03-23 03:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:27:30 --> Form Validation Class Initialized
INFO - 2022-03-23 03:27:30 --> Controller Class Initialized
INFO - 2022-03-23 03:27:30 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-23 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-23 03:27:30 --> Final output sent to browser
INFO - 2022-03-23 03:27:43 --> Config Class Initialized
INFO - 2022-03-23 03:27:43 --> Hooks Class Initialized
INFO - 2022-03-23 03:27:43 --> Utf8 Class Initialized
INFO - 2022-03-23 03:27:43 --> URI Class Initialized
INFO - 2022-03-23 03:27:43 --> Router Class Initialized
INFO - 2022-03-23 03:27:43 --> Output Class Initialized
INFO - 2022-03-23 03:27:43 --> Security Class Initialized
INFO - 2022-03-23 03:27:43 --> Input Class Initialized
INFO - 2022-03-23 03:27:43 --> Language Class Initialized
INFO - 2022-03-23 03:27:43 --> Loader Class Initialized
INFO - 2022-03-23 03:27:43 --> Helper loaded: url_helper
INFO - 2022-03-23 03:27:43 --> Helper loaded: form_helper
INFO - 2022-03-23 03:27:43 --> Database Driver Class Initialized
INFO - 2022-03-23 03:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:27:43 --> Form Validation Class Initialized
INFO - 2022-03-23 03:27:43 --> Controller Class Initialized
INFO - 2022-03-23 03:27:43 --> Model "M_todo_list" initialized
INFO - 2022-03-23 03:27:43 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-23 03:27:43 --> Model "M_todo_group" initialized
INFO - 2022-03-23 03:27:43 --> Model "M_todo_task" initialized
INFO - 2022-03-23 03:27:43 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:27:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-23 03:27:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-23 03:27:43 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-23 03:27:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-23 03:27:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-23 03:27:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-23 03:27:43 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-23 03:27:43 --> Final output sent to browser
INFO - 2022-03-23 03:28:04 --> Config Class Initialized
INFO - 2022-03-23 03:28:04 --> Hooks Class Initialized
INFO - 2022-03-23 03:28:04 --> Utf8 Class Initialized
INFO - 2022-03-23 03:28:04 --> URI Class Initialized
INFO - 2022-03-23 03:28:04 --> Router Class Initialized
INFO - 2022-03-23 03:28:04 --> Output Class Initialized
INFO - 2022-03-23 03:28:04 --> Security Class Initialized
INFO - 2022-03-23 03:28:04 --> Input Class Initialized
INFO - 2022-03-23 03:28:04 --> Language Class Initialized
INFO - 2022-03-23 03:28:04 --> Loader Class Initialized
INFO - 2022-03-23 03:28:04 --> Helper loaded: url_helper
INFO - 2022-03-23 03:28:04 --> Helper loaded: form_helper
INFO - 2022-03-23 03:28:04 --> Database Driver Class Initialized
INFO - 2022-03-23 03:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:28:04 --> Form Validation Class Initialized
INFO - 2022-03-23 03:28:04 --> Controller Class Initialized
INFO - 2022-03-23 03:28:04 --> Model "M_todo_list" initialized
INFO - 2022-03-23 03:28:04 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-23 03:28:04 --> Model "M_todo_group" initialized
INFO - 2022-03-23 03:28:04 --> Model "M_todo_task" initialized
INFO - 2022-03-23 03:28:04 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:28:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-23 03:28:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-23 03:28:04 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-23 03:28:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-23 03:28:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-23 03:28:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-23 03:28:04 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-23 03:28:04 --> Final output sent to browser
INFO - 2022-03-23 03:28:21 --> Config Class Initialized
INFO - 2022-03-23 03:28:21 --> Hooks Class Initialized
INFO - 2022-03-23 03:28:21 --> Utf8 Class Initialized
INFO - 2022-03-23 03:28:21 --> URI Class Initialized
INFO - 2022-03-23 03:28:21 --> Router Class Initialized
INFO - 2022-03-23 03:28:21 --> Output Class Initialized
INFO - 2022-03-23 03:28:21 --> Security Class Initialized
INFO - 2022-03-23 03:28:21 --> Input Class Initialized
INFO - 2022-03-23 03:28:21 --> Language Class Initialized
INFO - 2022-03-23 03:28:21 --> Loader Class Initialized
INFO - 2022-03-23 03:28:21 --> Helper loaded: url_helper
INFO - 2022-03-23 03:28:21 --> Helper loaded: form_helper
INFO - 2022-03-23 03:28:21 --> Database Driver Class Initialized
INFO - 2022-03-23 03:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:28:21 --> Form Validation Class Initialized
INFO - 2022-03-23 03:28:21 --> Controller Class Initialized
INFO - 2022-03-23 03:28:21 --> Model "M_todo_list" initialized
INFO - 2022-03-23 03:28:21 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-23 03:28:21 --> Model "M_todo_group" initialized
INFO - 2022-03-23 03:28:21 --> Model "M_todo_task" initialized
INFO - 2022-03-23 03:28:21 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:28:21 --> Config Class Initialized
INFO - 2022-03-23 03:28:21 --> Hooks Class Initialized
INFO - 2022-03-23 03:28:21 --> Utf8 Class Initialized
INFO - 2022-03-23 03:28:21 --> URI Class Initialized
INFO - 2022-03-23 03:28:21 --> Router Class Initialized
INFO - 2022-03-23 03:28:21 --> Output Class Initialized
INFO - 2022-03-23 03:28:21 --> Security Class Initialized
INFO - 2022-03-23 03:28:21 --> Input Class Initialized
INFO - 2022-03-23 03:28:21 --> Language Class Initialized
INFO - 2022-03-23 03:28:21 --> Loader Class Initialized
INFO - 2022-03-23 03:28:21 --> Helper loaded: url_helper
INFO - 2022-03-23 03:28:21 --> Helper loaded: form_helper
INFO - 2022-03-23 03:28:21 --> Database Driver Class Initialized
INFO - 2022-03-23 03:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:28:21 --> Form Validation Class Initialized
INFO - 2022-03-23 03:28:21 --> Controller Class Initialized
INFO - 2022-03-23 03:28:21 --> Model "M_todo_list" initialized
INFO - 2022-03-23 03:28:21 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-23 03:28:21 --> Model "M_todo_group" initialized
INFO - 2022-03-23 03:28:21 --> Model "M_todo_task" initialized
INFO - 2022-03-23 03:28:21 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:28:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-23 03:28:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-23 03:28:21 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-23 03:28:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-23 03:28:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-23 03:28:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-23 03:28:21 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-23 03:28:21 --> Final output sent to browser
INFO - 2022-03-23 03:28:31 --> Config Class Initialized
INFO - 2022-03-23 03:28:31 --> Hooks Class Initialized
INFO - 2022-03-23 03:28:31 --> Utf8 Class Initialized
INFO - 2022-03-23 03:28:31 --> URI Class Initialized
INFO - 2022-03-23 03:28:31 --> Router Class Initialized
INFO - 2022-03-23 03:28:31 --> Output Class Initialized
INFO - 2022-03-23 03:28:31 --> Security Class Initialized
INFO - 2022-03-23 03:28:31 --> Input Class Initialized
INFO - 2022-03-23 03:28:31 --> Language Class Initialized
INFO - 2022-03-23 03:28:31 --> Loader Class Initialized
INFO - 2022-03-23 03:28:31 --> Helper loaded: url_helper
INFO - 2022-03-23 03:28:31 --> Helper loaded: form_helper
INFO - 2022-03-23 03:28:31 --> Database Driver Class Initialized
INFO - 2022-03-23 03:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:28:31 --> Form Validation Class Initialized
INFO - 2022-03-23 03:28:31 --> Controller Class Initialized
INFO - 2022-03-23 03:28:31 --> Model "M_todo_list" initialized
INFO - 2022-03-23 03:28:31 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-23 03:28:31 --> Model "M_todo_group" initialized
INFO - 2022-03-23 03:28:31 --> Model "M_todo_task" initialized
INFO - 2022-03-23 03:28:31 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:28:31 --> Config Class Initialized
INFO - 2022-03-23 03:28:31 --> Hooks Class Initialized
INFO - 2022-03-23 03:28:31 --> Utf8 Class Initialized
INFO - 2022-03-23 03:28:31 --> URI Class Initialized
INFO - 2022-03-23 03:28:31 --> Router Class Initialized
INFO - 2022-03-23 03:28:31 --> Output Class Initialized
INFO - 2022-03-23 03:28:31 --> Security Class Initialized
INFO - 2022-03-23 03:28:31 --> Input Class Initialized
INFO - 2022-03-23 03:28:31 --> Language Class Initialized
INFO - 2022-03-23 03:28:31 --> Loader Class Initialized
INFO - 2022-03-23 03:28:31 --> Helper loaded: url_helper
INFO - 2022-03-23 03:28:31 --> Helper loaded: form_helper
INFO - 2022-03-23 03:28:31 --> Database Driver Class Initialized
INFO - 2022-03-23 03:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:28:31 --> Form Validation Class Initialized
INFO - 2022-03-23 03:28:31 --> Controller Class Initialized
INFO - 2022-03-23 03:28:31 --> Model "M_todo_list" initialized
INFO - 2022-03-23 03:28:31 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-23 03:28:31 --> Model "M_todo_group" initialized
INFO - 2022-03-23 03:28:31 --> Model "M_todo_task" initialized
INFO - 2022-03-23 03:28:31 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-23 03:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-23 03:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-23 03:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-23 03:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-23 03:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-23 03:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-23 03:28:31 --> Final output sent to browser
INFO - 2022-03-23 03:28:43 --> Config Class Initialized
INFO - 2022-03-23 03:28:43 --> Hooks Class Initialized
INFO - 2022-03-23 03:28:43 --> Utf8 Class Initialized
INFO - 2022-03-23 03:28:43 --> URI Class Initialized
INFO - 2022-03-23 03:28:43 --> Router Class Initialized
INFO - 2022-03-23 03:28:43 --> Output Class Initialized
INFO - 2022-03-23 03:28:43 --> Security Class Initialized
INFO - 2022-03-23 03:28:43 --> Input Class Initialized
INFO - 2022-03-23 03:28:43 --> Language Class Initialized
INFO - 2022-03-23 03:28:43 --> Loader Class Initialized
INFO - 2022-03-23 03:28:43 --> Helper loaded: url_helper
INFO - 2022-03-23 03:28:44 --> Helper loaded: form_helper
INFO - 2022-03-23 03:28:44 --> Database Driver Class Initialized
INFO - 2022-03-23 03:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:28:44 --> Form Validation Class Initialized
INFO - 2022-03-23 03:28:44 --> Controller Class Initialized
INFO - 2022-03-23 03:28:44 --> Model "M_todo_list" initialized
INFO - 2022-03-23 03:28:44 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-23 03:28:44 --> Model "M_todo_group" initialized
INFO - 2022-03-23 03:28:44 --> Model "M_todo_task" initialized
INFO - 2022-03-23 03:28:44 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:28:44 --> Config Class Initialized
INFO - 2022-03-23 03:28:44 --> Hooks Class Initialized
INFO - 2022-03-23 03:28:44 --> Utf8 Class Initialized
INFO - 2022-03-23 03:28:44 --> URI Class Initialized
INFO - 2022-03-23 03:28:44 --> Router Class Initialized
INFO - 2022-03-23 03:28:44 --> Output Class Initialized
INFO - 2022-03-23 03:28:44 --> Security Class Initialized
INFO - 2022-03-23 03:28:44 --> Input Class Initialized
INFO - 2022-03-23 03:28:44 --> Language Class Initialized
INFO - 2022-03-23 03:28:44 --> Loader Class Initialized
INFO - 2022-03-23 03:28:44 --> Helper loaded: url_helper
INFO - 2022-03-23 03:28:44 --> Helper loaded: form_helper
INFO - 2022-03-23 03:28:44 --> Database Driver Class Initialized
INFO - 2022-03-23 03:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:28:44 --> Form Validation Class Initialized
INFO - 2022-03-23 03:28:44 --> Controller Class Initialized
INFO - 2022-03-23 03:28:44 --> Model "M_todo_list" initialized
INFO - 2022-03-23 03:28:44 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-23 03:28:44 --> Model "M_todo_group" initialized
INFO - 2022-03-23 03:28:44 --> Model "M_todo_task" initialized
INFO - 2022-03-23 03:28:44 --> Model "M_tutor" initialized
INFO - 2022-03-23 03:28:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-23 03:28:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-23 03:28:44 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-23 03:28:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-23 03:28:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-23 03:28:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-23 03:28:44 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-23 03:28:44 --> Final output sent to browser
