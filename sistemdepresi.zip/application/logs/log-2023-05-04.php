<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-04 19:12:46 --> Config Class Initialized
INFO - 2023-05-04 19:12:46 --> Hooks Class Initialized
INFO - 2023-05-04 19:12:46 --> Utf8 Class Initialized
INFO - 2023-05-04 19:12:46 --> URI Class Initialized
INFO - 2023-05-04 19:12:46 --> Router Class Initialized
INFO - 2023-05-04 19:12:46 --> Output Class Initialized
INFO - 2023-05-04 19:12:46 --> Security Class Initialized
INFO - 2023-05-04 19:12:46 --> Input Class Initialized
INFO - 2023-05-04 19:12:46 --> Language Class Initialized
INFO - 2023-05-04 19:12:46 --> Loader Class Initialized
INFO - 2023-05-04 19:12:46 --> Helper loaded: url_helper
INFO - 2023-05-04 19:12:46 --> Helper loaded: form_helper
INFO - 2023-05-04 19:12:46 --> Database Driver Class Initialized
INFO - 2023-05-04 19:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:12:47 --> Form Validation Class Initialized
INFO - 2023-05-04 19:12:47 --> Controller Class Initialized
INFO - 2023-05-04 19:12:47 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:12:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-04 19:12:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-04 19:12:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-04 19:12:47 --> Final output sent to browser
INFO - 2023-05-04 19:12:47 --> Config Class Initialized
INFO - 2023-05-04 19:12:47 --> Hooks Class Initialized
INFO - 2023-05-04 19:12:47 --> Utf8 Class Initialized
INFO - 2023-05-04 19:12:47 --> URI Class Initialized
INFO - 2023-05-04 19:12:47 --> Router Class Initialized
INFO - 2023-05-04 19:12:47 --> Output Class Initialized
INFO - 2023-05-04 19:12:47 --> Security Class Initialized
INFO - 2023-05-04 19:12:47 --> Input Class Initialized
INFO - 2023-05-04 19:12:47 --> Language Class Initialized
ERROR - 2023-05-04 19:12:47 --> 404 Page Not Found: Assets/assetslogin
INFO - 2023-05-04 19:12:47 --> Config Class Initialized
INFO - 2023-05-04 19:12:47 --> Hooks Class Initialized
INFO - 2023-05-04 19:12:47 --> Utf8 Class Initialized
INFO - 2023-05-04 19:12:47 --> URI Class Initialized
INFO - 2023-05-04 19:12:47 --> Router Class Initialized
INFO - 2023-05-04 19:12:47 --> Output Class Initialized
INFO - 2023-05-04 19:12:47 --> Security Class Initialized
INFO - 2023-05-04 19:12:47 --> Input Class Initialized
INFO - 2023-05-04 19:12:47 --> Language Class Initialized
ERROR - 2023-05-04 19:12:47 --> 404 Page Not Found: Assets/assetslogin
INFO - 2023-05-04 19:12:53 --> Config Class Initialized
INFO - 2023-05-04 19:12:53 --> Hooks Class Initialized
INFO - 2023-05-04 19:12:53 --> Utf8 Class Initialized
INFO - 2023-05-04 19:12:53 --> URI Class Initialized
INFO - 2023-05-04 19:12:53 --> Router Class Initialized
INFO - 2023-05-04 19:12:53 --> Output Class Initialized
INFO - 2023-05-04 19:12:53 --> Security Class Initialized
INFO - 2023-05-04 19:12:53 --> Input Class Initialized
INFO - 2023-05-04 19:12:53 --> Language Class Initialized
INFO - 2023-05-04 19:12:53 --> Loader Class Initialized
INFO - 2023-05-04 19:12:53 --> Helper loaded: url_helper
INFO - 2023-05-04 19:12:54 --> Helper loaded: form_helper
INFO - 2023-05-04 19:12:54 --> Database Driver Class Initialized
INFO - 2023-05-04 19:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:12:54 --> Form Validation Class Initialized
INFO - 2023-05-04 19:12:54 --> Controller Class Initialized
INFO - 2023-05-04 19:12:54 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:12:54 --> Config Class Initialized
INFO - 2023-05-04 19:12:54 --> Hooks Class Initialized
INFO - 2023-05-04 19:12:54 --> Utf8 Class Initialized
INFO - 2023-05-04 19:12:54 --> URI Class Initialized
INFO - 2023-05-04 19:12:54 --> Router Class Initialized
INFO - 2023-05-04 19:12:54 --> Output Class Initialized
INFO - 2023-05-04 19:12:54 --> Security Class Initialized
INFO - 2023-05-04 19:12:54 --> Input Class Initialized
INFO - 2023-05-04 19:12:54 --> Language Class Initialized
INFO - 2023-05-04 19:12:54 --> Loader Class Initialized
INFO - 2023-05-04 19:12:54 --> Helper loaded: url_helper
INFO - 2023-05-04 19:12:54 --> Helper loaded: form_helper
INFO - 2023-05-04 19:12:54 --> Database Driver Class Initialized
INFO - 2023-05-04 19:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:12:54 --> Form Validation Class Initialized
INFO - 2023-05-04 19:12:54 --> Controller Class Initialized
INFO - 2023-05-04 19:12:54 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:12:54 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:12:54 --> Final output sent to browser
INFO - 2023-05-04 19:12:55 --> Config Class Initialized
INFO - 2023-05-04 19:12:55 --> Hooks Class Initialized
INFO - 2023-05-04 19:12:55 --> Utf8 Class Initialized
INFO - 2023-05-04 19:12:55 --> URI Class Initialized
INFO - 2023-05-04 19:12:55 --> Router Class Initialized
INFO - 2023-05-04 19:12:55 --> Output Class Initialized
INFO - 2023-05-04 19:12:55 --> Security Class Initialized
INFO - 2023-05-04 19:12:55 --> Input Class Initialized
INFO - 2023-05-04 19:12:55 --> Language Class Initialized
ERROR - 2023-05-04 19:12:55 --> 404 Page Not Found: Assets/assetslogin
INFO - 2023-05-04 19:14:24 --> Config Class Initialized
INFO - 2023-05-04 19:14:24 --> Hooks Class Initialized
INFO - 2023-05-04 19:14:24 --> Utf8 Class Initialized
INFO - 2023-05-04 19:14:24 --> URI Class Initialized
INFO - 2023-05-04 19:14:24 --> Router Class Initialized
INFO - 2023-05-04 19:14:24 --> Output Class Initialized
INFO - 2023-05-04 19:14:24 --> Security Class Initialized
INFO - 2023-05-04 19:14:24 --> Input Class Initialized
INFO - 2023-05-04 19:14:24 --> Language Class Initialized
INFO - 2023-05-04 19:14:24 --> Loader Class Initialized
INFO - 2023-05-04 19:14:24 --> Helper loaded: url_helper
INFO - 2023-05-04 19:14:24 --> Helper loaded: form_helper
INFO - 2023-05-04 19:14:24 --> Database Driver Class Initialized
INFO - 2023-05-04 19:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:14:24 --> Form Validation Class Initialized
INFO - 2023-05-04 19:14:24 --> Controller Class Initialized
INFO - 2023-05-04 19:14:24 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:14:24 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:14:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:14:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:14:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:14:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:14:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:14:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:14:24 --> Final output sent to browser
INFO - 2023-05-04 19:14:25 --> Config Class Initialized
INFO - 2023-05-04 19:14:25 --> Hooks Class Initialized
INFO - 2023-05-04 19:14:25 --> Utf8 Class Initialized
INFO - 2023-05-04 19:14:25 --> URI Class Initialized
INFO - 2023-05-04 19:14:25 --> Router Class Initialized
INFO - 2023-05-04 19:14:25 --> Output Class Initialized
INFO - 2023-05-04 19:14:25 --> Security Class Initialized
INFO - 2023-05-04 19:14:25 --> Input Class Initialized
INFO - 2023-05-04 19:14:25 --> Language Class Initialized
ERROR - 2023-05-04 19:14:25 --> 404 Page Not Found: Assets/assetslogin
INFO - 2023-05-04 19:15:54 --> Config Class Initialized
INFO - 2023-05-04 19:15:54 --> Hooks Class Initialized
INFO - 2023-05-04 19:15:54 --> Utf8 Class Initialized
INFO - 2023-05-04 19:15:54 --> URI Class Initialized
INFO - 2023-05-04 19:15:54 --> Router Class Initialized
INFO - 2023-05-04 19:15:54 --> Output Class Initialized
INFO - 2023-05-04 19:15:54 --> Security Class Initialized
INFO - 2023-05-04 19:15:54 --> Input Class Initialized
INFO - 2023-05-04 19:15:54 --> Language Class Initialized
INFO - 2023-05-04 19:15:54 --> Loader Class Initialized
INFO - 2023-05-04 19:15:54 --> Helper loaded: url_helper
INFO - 2023-05-04 19:15:54 --> Helper loaded: form_helper
INFO - 2023-05-04 19:15:54 --> Database Driver Class Initialized
INFO - 2023-05-04 19:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:15:54 --> Form Validation Class Initialized
INFO - 2023-05-04 19:15:54 --> Controller Class Initialized
INFO - 2023-05-04 19:15:54 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:15:54 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:15:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:15:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:15:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:15:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:15:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:15:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:15:54 --> Final output sent to browser
INFO - 2023-05-04 19:16:37 --> Config Class Initialized
INFO - 2023-05-04 19:16:37 --> Hooks Class Initialized
INFO - 2023-05-04 19:16:37 --> Utf8 Class Initialized
INFO - 2023-05-04 19:16:37 --> URI Class Initialized
INFO - 2023-05-04 19:16:37 --> Router Class Initialized
INFO - 2023-05-04 19:16:37 --> Output Class Initialized
INFO - 2023-05-04 19:16:37 --> Security Class Initialized
INFO - 2023-05-04 19:16:37 --> Input Class Initialized
INFO - 2023-05-04 19:16:37 --> Language Class Initialized
INFO - 2023-05-04 19:16:37 --> Loader Class Initialized
INFO - 2023-05-04 19:16:37 --> Helper loaded: url_helper
INFO - 2023-05-04 19:16:37 --> Helper loaded: form_helper
INFO - 2023-05-04 19:16:37 --> Database Driver Class Initialized
INFO - 2023-05-04 19:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:16:37 --> Form Validation Class Initialized
INFO - 2023-05-04 19:16:37 --> Controller Class Initialized
INFO - 2023-05-04 19:16:37 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:16:37 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:16:37 --> Final output sent to browser
INFO - 2023-05-04 19:17:59 --> Config Class Initialized
INFO - 2023-05-04 19:17:59 --> Hooks Class Initialized
INFO - 2023-05-04 19:17:59 --> Utf8 Class Initialized
INFO - 2023-05-04 19:17:59 --> URI Class Initialized
INFO - 2023-05-04 19:17:59 --> Router Class Initialized
INFO - 2023-05-04 19:17:59 --> Output Class Initialized
INFO - 2023-05-04 19:17:59 --> Security Class Initialized
INFO - 2023-05-04 19:17:59 --> Input Class Initialized
INFO - 2023-05-04 19:17:59 --> Language Class Initialized
INFO - 2023-05-04 19:17:59 --> Loader Class Initialized
INFO - 2023-05-04 19:17:59 --> Helper loaded: url_helper
INFO - 2023-05-04 19:17:59 --> Helper loaded: form_helper
INFO - 2023-05-04 19:17:59 --> Database Driver Class Initialized
INFO - 2023-05-04 19:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:17:59 --> Form Validation Class Initialized
INFO - 2023-05-04 19:17:59 --> Controller Class Initialized
INFO - 2023-05-04 19:17:59 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:17:59 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:17:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:17:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:17:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:17:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:17:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:17:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:17:59 --> Final output sent to browser
INFO - 2023-05-04 19:18:21 --> Config Class Initialized
INFO - 2023-05-04 19:18:21 --> Hooks Class Initialized
INFO - 2023-05-04 19:18:21 --> Utf8 Class Initialized
INFO - 2023-05-04 19:18:21 --> URI Class Initialized
INFO - 2023-05-04 19:18:21 --> Router Class Initialized
INFO - 2023-05-04 19:18:21 --> Output Class Initialized
INFO - 2023-05-04 19:18:21 --> Security Class Initialized
INFO - 2023-05-04 19:18:21 --> Input Class Initialized
INFO - 2023-05-04 19:18:21 --> Language Class Initialized
INFO - 2023-05-04 19:18:21 --> Loader Class Initialized
INFO - 2023-05-04 19:18:21 --> Helper loaded: url_helper
INFO - 2023-05-04 19:18:21 --> Helper loaded: form_helper
INFO - 2023-05-04 19:18:21 --> Database Driver Class Initialized
INFO - 2023-05-04 19:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:18:21 --> Form Validation Class Initialized
INFO - 2023-05-04 19:18:21 --> Controller Class Initialized
INFO - 2023-05-04 19:18:21 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:18:21 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:18:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:18:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:18:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:18:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:18:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:18:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:18:21 --> Final output sent to browser
INFO - 2023-05-04 19:34:33 --> Config Class Initialized
INFO - 2023-05-04 19:34:33 --> Hooks Class Initialized
INFO - 2023-05-04 19:34:33 --> Utf8 Class Initialized
INFO - 2023-05-04 19:34:33 --> URI Class Initialized
INFO - 2023-05-04 19:34:33 --> Router Class Initialized
INFO - 2023-05-04 19:34:33 --> Output Class Initialized
INFO - 2023-05-04 19:34:33 --> Security Class Initialized
INFO - 2023-05-04 19:34:33 --> Input Class Initialized
INFO - 2023-05-04 19:34:33 --> Language Class Initialized
INFO - 2023-05-04 19:34:33 --> Loader Class Initialized
INFO - 2023-05-04 19:34:33 --> Helper loaded: url_helper
INFO - 2023-05-04 19:34:33 --> Helper loaded: form_helper
INFO - 2023-05-04 19:34:33 --> Database Driver Class Initialized
INFO - 2023-05-04 19:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:34:33 --> Form Validation Class Initialized
INFO - 2023-05-04 19:34:33 --> Controller Class Initialized
INFO - 2023-05-04 19:34:33 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:34:33 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:34:33 --> Final output sent to browser
INFO - 2023-05-04 19:35:13 --> Config Class Initialized
INFO - 2023-05-04 19:35:13 --> Hooks Class Initialized
INFO - 2023-05-04 19:35:13 --> Utf8 Class Initialized
INFO - 2023-05-04 19:35:13 --> URI Class Initialized
INFO - 2023-05-04 19:35:13 --> Router Class Initialized
INFO - 2023-05-04 19:35:13 --> Output Class Initialized
INFO - 2023-05-04 19:35:13 --> Security Class Initialized
INFO - 2023-05-04 19:35:13 --> Input Class Initialized
INFO - 2023-05-04 19:35:13 --> Language Class Initialized
INFO - 2023-05-04 19:35:13 --> Loader Class Initialized
INFO - 2023-05-04 19:35:13 --> Helper loaded: url_helper
INFO - 2023-05-04 19:35:13 --> Helper loaded: form_helper
INFO - 2023-05-04 19:35:13 --> Database Driver Class Initialized
INFO - 2023-05-04 19:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:35:13 --> Form Validation Class Initialized
INFO - 2023-05-04 19:35:13 --> Controller Class Initialized
INFO - 2023-05-04 19:35:13 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:35:13 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:35:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:35:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:35:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:35:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:35:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:35:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:35:13 --> Final output sent to browser
INFO - 2023-05-04 19:35:16 --> Config Class Initialized
INFO - 2023-05-04 19:35:16 --> Hooks Class Initialized
INFO - 2023-05-04 19:35:16 --> Utf8 Class Initialized
INFO - 2023-05-04 19:35:16 --> URI Class Initialized
INFO - 2023-05-04 19:35:16 --> Router Class Initialized
INFO - 2023-05-04 19:35:16 --> Output Class Initialized
INFO - 2023-05-04 19:35:16 --> Security Class Initialized
INFO - 2023-05-04 19:35:16 --> Input Class Initialized
INFO - 2023-05-04 19:35:16 --> Language Class Initialized
INFO - 2023-05-04 19:35:16 --> Loader Class Initialized
INFO - 2023-05-04 19:35:16 --> Helper loaded: url_helper
INFO - 2023-05-04 19:35:16 --> Helper loaded: form_helper
INFO - 2023-05-04 19:35:16 --> Database Driver Class Initialized
INFO - 2023-05-04 19:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:35:16 --> Form Validation Class Initialized
INFO - 2023-05-04 19:35:16 --> Controller Class Initialized
INFO - 2023-05-04 19:35:16 --> Model "M_todo_list" initialized
INFO - 2023-05-04 19:35:16 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:35:16 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:35:16 --> Model "M_todo_task" initialized
INFO - 2023-05-04 19:35:16 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_list/v_index.php
INFO - 2023-05-04 19:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:35:16 --> Final output sent to browser
INFO - 2023-05-04 19:38:01 --> Config Class Initialized
INFO - 2023-05-04 19:38:01 --> Hooks Class Initialized
INFO - 2023-05-04 19:38:01 --> Utf8 Class Initialized
INFO - 2023-05-04 19:38:01 --> URI Class Initialized
INFO - 2023-05-04 19:38:01 --> Router Class Initialized
INFO - 2023-05-04 19:38:01 --> Output Class Initialized
INFO - 2023-05-04 19:38:01 --> Security Class Initialized
INFO - 2023-05-04 19:38:01 --> Input Class Initialized
INFO - 2023-05-04 19:38:01 --> Language Class Initialized
INFO - 2023-05-04 19:38:01 --> Loader Class Initialized
INFO - 2023-05-04 19:38:01 --> Helper loaded: url_helper
INFO - 2023-05-04 19:38:01 --> Helper loaded: form_helper
INFO - 2023-05-04 19:38:01 --> Database Driver Class Initialized
INFO - 2023-05-04 19:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:38:01 --> Form Validation Class Initialized
INFO - 2023-05-04 19:38:01 --> Controller Class Initialized
INFO - 2023-05-04 19:38:01 --> Model "M_todo_list" initialized
INFO - 2023-05-04 19:38:01 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:38:01 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:38:01 --> Model "M_todo_task" initialized
INFO - 2023-05-04 19:38:01 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:38:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:38:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:38:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_list/v_index.php
INFO - 2023-05-04 19:38:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:38:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:38:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:38:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:38:01 --> Final output sent to browser
INFO - 2023-05-04 19:39:04 --> Config Class Initialized
INFO - 2023-05-04 19:39:04 --> Hooks Class Initialized
INFO - 2023-05-04 19:39:04 --> Utf8 Class Initialized
INFO - 2023-05-04 19:39:04 --> URI Class Initialized
INFO - 2023-05-04 19:39:04 --> Router Class Initialized
INFO - 2023-05-04 19:39:04 --> Output Class Initialized
INFO - 2023-05-04 19:39:04 --> Security Class Initialized
INFO - 2023-05-04 19:39:04 --> Input Class Initialized
INFO - 2023-05-04 19:39:04 --> Language Class Initialized
INFO - 2023-05-04 19:39:04 --> Loader Class Initialized
INFO - 2023-05-04 19:39:04 --> Helper loaded: url_helper
INFO - 2023-05-04 19:39:04 --> Helper loaded: form_helper
INFO - 2023-05-04 19:39:04 --> Database Driver Class Initialized
INFO - 2023-05-04 19:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:39:04 --> Form Validation Class Initialized
INFO - 2023-05-04 19:39:04 --> Controller Class Initialized
INFO - 2023-05-04 19:39:04 --> Model "M_todo_list" initialized
INFO - 2023-05-04 19:39:04 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:39:04 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:39:04 --> Model "M_todo_task" initialized
INFO - 2023-05-04 19:39:04 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:39:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:39:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:39:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_list/v_index.php
INFO - 2023-05-04 19:39:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:39:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:39:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:39:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:39:04 --> Final output sent to browser
INFO - 2023-05-04 19:39:47 --> Config Class Initialized
INFO - 2023-05-04 19:39:47 --> Hooks Class Initialized
INFO - 2023-05-04 19:39:47 --> Utf8 Class Initialized
INFO - 2023-05-04 19:39:47 --> URI Class Initialized
INFO - 2023-05-04 19:39:47 --> Router Class Initialized
INFO - 2023-05-04 19:39:47 --> Output Class Initialized
INFO - 2023-05-04 19:39:47 --> Security Class Initialized
INFO - 2023-05-04 19:39:47 --> Input Class Initialized
INFO - 2023-05-04 19:39:47 --> Language Class Initialized
INFO - 2023-05-04 19:39:47 --> Loader Class Initialized
INFO - 2023-05-04 19:39:47 --> Helper loaded: url_helper
INFO - 2023-05-04 19:39:47 --> Helper loaded: form_helper
INFO - 2023-05-04 19:39:47 --> Database Driver Class Initialized
INFO - 2023-05-04 19:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:39:47 --> Form Validation Class Initialized
INFO - 2023-05-04 19:39:47 --> Controller Class Initialized
INFO - 2023-05-04 19:39:47 --> Model "M_todo_list" initialized
INFO - 2023-05-04 19:39:47 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:39:47 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:39:47 --> Model "M_todo_task" initialized
INFO - 2023-05-04 19:39:47 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:39:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:39:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:39:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_list/v_index.php
INFO - 2023-05-04 19:39:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:39:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:39:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:39:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:39:47 --> Final output sent to browser
INFO - 2023-05-04 19:44:21 --> Config Class Initialized
INFO - 2023-05-04 19:44:21 --> Hooks Class Initialized
INFO - 2023-05-04 19:44:21 --> Utf8 Class Initialized
INFO - 2023-05-04 19:44:21 --> URI Class Initialized
INFO - 2023-05-04 19:44:21 --> Router Class Initialized
INFO - 2023-05-04 19:44:21 --> Output Class Initialized
INFO - 2023-05-04 19:44:21 --> Security Class Initialized
INFO - 2023-05-04 19:44:21 --> Input Class Initialized
INFO - 2023-05-04 19:44:21 --> Language Class Initialized
INFO - 2023-05-04 19:44:21 --> Loader Class Initialized
INFO - 2023-05-04 19:44:21 --> Helper loaded: url_helper
INFO - 2023-05-04 19:44:21 --> Helper loaded: form_helper
INFO - 2023-05-04 19:44:21 --> Database Driver Class Initialized
INFO - 2023-05-04 19:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:44:21 --> Form Validation Class Initialized
INFO - 2023-05-04 19:44:21 --> Controller Class Initialized
INFO - 2023-05-04 19:44:21 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:44:21 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:44:21 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:44:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:44:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:44:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_group/v_index.php
INFO - 2023-05-04 19:44:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:44:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:44:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:44:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:44:21 --> Final output sent to browser
INFO - 2023-05-04 19:47:30 --> Config Class Initialized
INFO - 2023-05-04 19:47:30 --> Hooks Class Initialized
INFO - 2023-05-04 19:47:30 --> Utf8 Class Initialized
INFO - 2023-05-04 19:47:30 --> URI Class Initialized
INFO - 2023-05-04 19:47:30 --> Router Class Initialized
INFO - 2023-05-04 19:47:30 --> Output Class Initialized
INFO - 2023-05-04 19:47:30 --> Security Class Initialized
INFO - 2023-05-04 19:47:30 --> Input Class Initialized
INFO - 2023-05-04 19:47:30 --> Language Class Initialized
INFO - 2023-05-04 19:47:30 --> Loader Class Initialized
INFO - 2023-05-04 19:47:30 --> Helper loaded: url_helper
INFO - 2023-05-04 19:47:30 --> Helper loaded: form_helper
INFO - 2023-05-04 19:47:30 --> Database Driver Class Initialized
INFO - 2023-05-04 19:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:47:30 --> Form Validation Class Initialized
INFO - 2023-05-04 19:47:30 --> Controller Class Initialized
INFO - 2023-05-04 19:47:30 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:47:30 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:47:30 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:47:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:47:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:47:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_group/v_index.php
INFO - 2023-05-04 19:47:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:47:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:47:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:47:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:47:30 --> Final output sent to browser
INFO - 2023-05-04 19:47:54 --> Config Class Initialized
INFO - 2023-05-04 19:47:54 --> Hooks Class Initialized
INFO - 2023-05-04 19:47:54 --> Utf8 Class Initialized
INFO - 2023-05-04 19:47:54 --> URI Class Initialized
INFO - 2023-05-04 19:47:54 --> Router Class Initialized
INFO - 2023-05-04 19:47:54 --> Output Class Initialized
INFO - 2023-05-04 19:47:54 --> Security Class Initialized
INFO - 2023-05-04 19:47:54 --> Input Class Initialized
INFO - 2023-05-04 19:47:54 --> Language Class Initialized
INFO - 2023-05-04 19:47:54 --> Loader Class Initialized
INFO - 2023-05-04 19:47:54 --> Helper loaded: url_helper
INFO - 2023-05-04 19:47:54 --> Helper loaded: form_helper
INFO - 2023-05-04 19:47:54 --> Database Driver Class Initialized
INFO - 2023-05-04 19:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:47:54 --> Form Validation Class Initialized
INFO - 2023-05-04 19:47:54 --> Controller Class Initialized
INFO - 2023-05-04 19:47:54 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:47:54 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:47:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:47:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:47:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_tutor/v_index.php
INFO - 2023-05-04 19:47:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:47:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:47:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:47:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:47:54 --> Final output sent to browser
INFO - 2023-05-04 19:49:05 --> Config Class Initialized
INFO - 2023-05-04 19:49:05 --> Hooks Class Initialized
INFO - 2023-05-04 19:49:05 --> Utf8 Class Initialized
INFO - 2023-05-04 19:49:05 --> URI Class Initialized
INFO - 2023-05-04 19:49:05 --> Router Class Initialized
INFO - 2023-05-04 19:49:05 --> Output Class Initialized
INFO - 2023-05-04 19:49:05 --> Security Class Initialized
INFO - 2023-05-04 19:49:05 --> Input Class Initialized
INFO - 2023-05-04 19:49:05 --> Language Class Initialized
INFO - 2023-05-04 19:49:05 --> Loader Class Initialized
INFO - 2023-05-04 19:49:05 --> Helper loaded: url_helper
INFO - 2023-05-04 19:49:05 --> Helper loaded: form_helper
INFO - 2023-05-04 19:49:05 --> Database Driver Class Initialized
INFO - 2023-05-04 19:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:49:05 --> Form Validation Class Initialized
INFO - 2023-05-04 19:49:05 --> Controller Class Initialized
INFO - 2023-05-04 19:49:05 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:49:05 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:49:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:49:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:49:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_tutor/v_index.php
INFO - 2023-05-04 19:49:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:49:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:49:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:49:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:49:05 --> Final output sent to browser
INFO - 2023-05-04 19:49:37 --> Config Class Initialized
INFO - 2023-05-04 19:49:37 --> Hooks Class Initialized
INFO - 2023-05-04 19:49:37 --> Utf8 Class Initialized
INFO - 2023-05-04 19:49:37 --> URI Class Initialized
INFO - 2023-05-04 19:49:37 --> Router Class Initialized
INFO - 2023-05-04 19:49:37 --> Output Class Initialized
INFO - 2023-05-04 19:49:37 --> Security Class Initialized
INFO - 2023-05-04 19:49:37 --> Input Class Initialized
INFO - 2023-05-04 19:49:37 --> Language Class Initialized
INFO - 2023-05-04 19:49:37 --> Loader Class Initialized
INFO - 2023-05-04 19:49:37 --> Helper loaded: url_helper
INFO - 2023-05-04 19:49:37 --> Helper loaded: form_helper
INFO - 2023-05-04 19:49:37 --> Database Driver Class Initialized
INFO - 2023-05-04 19:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:49:37 --> Form Validation Class Initialized
INFO - 2023-05-04 19:49:37 --> Controller Class Initialized
INFO - 2023-05-04 19:49:37 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:49:37 --> Config Class Initialized
INFO - 2023-05-04 19:49:37 --> Hooks Class Initialized
INFO - 2023-05-04 19:49:37 --> Utf8 Class Initialized
INFO - 2023-05-04 19:49:37 --> URI Class Initialized
INFO - 2023-05-04 19:49:37 --> Router Class Initialized
INFO - 2023-05-04 19:49:37 --> Output Class Initialized
INFO - 2023-05-04 19:49:37 --> Security Class Initialized
INFO - 2023-05-04 19:49:37 --> Input Class Initialized
INFO - 2023-05-04 19:49:37 --> Language Class Initialized
INFO - 2023-05-04 19:49:37 --> Loader Class Initialized
INFO - 2023-05-04 19:49:37 --> Helper loaded: url_helper
INFO - 2023-05-04 19:49:37 --> Helper loaded: form_helper
INFO - 2023-05-04 19:49:37 --> Database Driver Class Initialized
INFO - 2023-05-04 19:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:49:37 --> Form Validation Class Initialized
INFO - 2023-05-04 19:49:37 --> Controller Class Initialized
INFO - 2023-05-04 19:49:37 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:49:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-04 19:49:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-04 19:49:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-04 19:49:37 --> Final output sent to browser
INFO - 2023-05-04 19:49:37 --> Config Class Initialized
INFO - 2023-05-04 19:49:37 --> Hooks Class Initialized
INFO - 2023-05-04 19:49:37 --> Utf8 Class Initialized
INFO - 2023-05-04 19:49:37 --> URI Class Initialized
INFO - 2023-05-04 19:49:37 --> Router Class Initialized
INFO - 2023-05-04 19:49:37 --> Output Class Initialized
INFO - 2023-05-04 19:49:37 --> Security Class Initialized
INFO - 2023-05-04 19:49:37 --> Input Class Initialized
INFO - 2023-05-04 19:49:37 --> Language Class Initialized
ERROR - 2023-05-04 19:49:37 --> 404 Page Not Found: Assets/assetslogin
INFO - 2023-05-04 19:49:47 --> Config Class Initialized
INFO - 2023-05-04 19:49:47 --> Hooks Class Initialized
INFO - 2023-05-04 19:49:47 --> Utf8 Class Initialized
INFO - 2023-05-04 19:49:47 --> URI Class Initialized
INFO - 2023-05-04 19:49:47 --> Router Class Initialized
INFO - 2023-05-04 19:49:47 --> Output Class Initialized
INFO - 2023-05-04 19:49:47 --> Security Class Initialized
INFO - 2023-05-04 19:49:47 --> Input Class Initialized
INFO - 2023-05-04 19:49:47 --> Language Class Initialized
INFO - 2023-05-04 19:49:47 --> Loader Class Initialized
INFO - 2023-05-04 19:49:47 --> Helper loaded: url_helper
INFO - 2023-05-04 19:49:47 --> Helper loaded: form_helper
INFO - 2023-05-04 19:49:47 --> Database Driver Class Initialized
INFO - 2023-05-04 19:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:49:48 --> Form Validation Class Initialized
INFO - 2023-05-04 19:49:48 --> Controller Class Initialized
INFO - 2023-05-04 19:49:48 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:49:48 --> Config Class Initialized
INFO - 2023-05-04 19:49:48 --> Hooks Class Initialized
INFO - 2023-05-04 19:49:48 --> Utf8 Class Initialized
INFO - 2023-05-04 19:49:48 --> URI Class Initialized
INFO - 2023-05-04 19:49:48 --> Router Class Initialized
INFO - 2023-05-04 19:49:48 --> Output Class Initialized
INFO - 2023-05-04 19:49:48 --> Security Class Initialized
INFO - 2023-05-04 19:49:48 --> Input Class Initialized
INFO - 2023-05-04 19:49:48 --> Language Class Initialized
INFO - 2023-05-04 19:49:48 --> Loader Class Initialized
INFO - 2023-05-04 19:49:48 --> Helper loaded: url_helper
INFO - 2023-05-04 19:49:48 --> Helper loaded: form_helper
INFO - 2023-05-04 19:49:48 --> Database Driver Class Initialized
INFO - 2023-05-04 19:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:49:48 --> Form Validation Class Initialized
INFO - 2023-05-04 19:49:48 --> Controller Class Initialized
INFO - 2023-05-04 19:49:48 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:49:48 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:49:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:49:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:49:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:49:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:49:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:49:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:49:48 --> Final output sent to browser
INFO - 2023-05-04 19:49:58 --> Config Class Initialized
INFO - 2023-05-04 19:49:58 --> Hooks Class Initialized
INFO - 2023-05-04 19:49:58 --> Utf8 Class Initialized
INFO - 2023-05-04 19:49:58 --> URI Class Initialized
INFO - 2023-05-04 19:49:58 --> Router Class Initialized
INFO - 2023-05-04 19:49:58 --> Output Class Initialized
INFO - 2023-05-04 19:49:58 --> Security Class Initialized
INFO - 2023-05-04 19:49:58 --> Input Class Initialized
INFO - 2023-05-04 19:49:58 --> Language Class Initialized
INFO - 2023-05-04 19:49:58 --> Loader Class Initialized
INFO - 2023-05-04 19:49:58 --> Helper loaded: url_helper
INFO - 2023-05-04 19:49:58 --> Helper loaded: form_helper
INFO - 2023-05-04 19:49:58 --> Database Driver Class Initialized
INFO - 2023-05-04 19:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:49:58 --> Form Validation Class Initialized
INFO - 2023-05-04 19:49:58 --> Controller Class Initialized
INFO - 2023-05-04 19:49:58 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:49:58 --> Config Class Initialized
INFO - 2023-05-04 19:49:58 --> Hooks Class Initialized
INFO - 2023-05-04 19:49:58 --> Utf8 Class Initialized
INFO - 2023-05-04 19:49:58 --> URI Class Initialized
INFO - 2023-05-04 19:49:58 --> Router Class Initialized
INFO - 2023-05-04 19:49:58 --> Output Class Initialized
INFO - 2023-05-04 19:49:58 --> Security Class Initialized
INFO - 2023-05-04 19:49:58 --> Input Class Initialized
INFO - 2023-05-04 19:49:58 --> Language Class Initialized
INFO - 2023-05-04 19:49:58 --> Loader Class Initialized
INFO - 2023-05-04 19:49:58 --> Helper loaded: url_helper
INFO - 2023-05-04 19:49:58 --> Helper loaded: form_helper
INFO - 2023-05-04 19:49:58 --> Database Driver Class Initialized
INFO - 2023-05-04 19:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:49:58 --> Form Validation Class Initialized
INFO - 2023-05-04 19:49:58 --> Controller Class Initialized
INFO - 2023-05-04 19:49:58 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:49:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-04 19:49:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-04 19:49:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-04 19:49:58 --> Final output sent to browser
INFO - 2023-05-04 19:49:58 --> Config Class Initialized
INFO - 2023-05-04 19:49:58 --> Hooks Class Initialized
INFO - 2023-05-04 19:49:58 --> Utf8 Class Initialized
INFO - 2023-05-04 19:49:58 --> URI Class Initialized
INFO - 2023-05-04 19:49:58 --> Router Class Initialized
INFO - 2023-05-04 19:49:58 --> Output Class Initialized
INFO - 2023-05-04 19:49:58 --> Security Class Initialized
INFO - 2023-05-04 19:49:58 --> Input Class Initialized
INFO - 2023-05-04 19:49:58 --> Language Class Initialized
ERROR - 2023-05-04 19:49:58 --> 404 Page Not Found: Assets/assetslogin
INFO - 2023-05-04 19:50:54 --> Config Class Initialized
INFO - 2023-05-04 19:50:54 --> Hooks Class Initialized
INFO - 2023-05-04 19:50:54 --> Utf8 Class Initialized
INFO - 2023-05-04 19:50:54 --> URI Class Initialized
INFO - 2023-05-04 19:50:54 --> Router Class Initialized
INFO - 2023-05-04 19:50:54 --> Output Class Initialized
INFO - 2023-05-04 19:50:54 --> Security Class Initialized
INFO - 2023-05-04 19:50:54 --> Input Class Initialized
INFO - 2023-05-04 19:50:54 --> Language Class Initialized
INFO - 2023-05-04 19:50:54 --> Loader Class Initialized
INFO - 2023-05-04 19:50:54 --> Helper loaded: url_helper
INFO - 2023-05-04 19:50:54 --> Helper loaded: form_helper
INFO - 2023-05-04 19:50:54 --> Database Driver Class Initialized
INFO - 2023-05-04 19:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:50:54 --> Form Validation Class Initialized
INFO - 2023-05-04 19:50:54 --> Controller Class Initialized
INFO - 2023-05-04 19:50:54 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:50:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-04 19:50:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-04 19:50:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-04 19:50:54 --> Final output sent to browser
INFO - 2023-05-04 19:51:04 --> Config Class Initialized
INFO - 2023-05-04 19:51:04 --> Hooks Class Initialized
INFO - 2023-05-04 19:51:04 --> Utf8 Class Initialized
INFO - 2023-05-04 19:51:04 --> URI Class Initialized
INFO - 2023-05-04 19:51:04 --> Router Class Initialized
INFO - 2023-05-04 19:51:04 --> Output Class Initialized
INFO - 2023-05-04 19:51:04 --> Security Class Initialized
INFO - 2023-05-04 19:51:04 --> Input Class Initialized
INFO - 2023-05-04 19:51:04 --> Language Class Initialized
INFO - 2023-05-04 19:51:04 --> Loader Class Initialized
INFO - 2023-05-04 19:51:04 --> Helper loaded: url_helper
INFO - 2023-05-04 19:51:04 --> Helper loaded: form_helper
INFO - 2023-05-04 19:51:04 --> Database Driver Class Initialized
INFO - 2023-05-04 19:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:51:04 --> Form Validation Class Initialized
INFO - 2023-05-04 19:51:04 --> Controller Class Initialized
INFO - 2023-05-04 19:51:04 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:51:04 --> Config Class Initialized
INFO - 2023-05-04 19:51:04 --> Hooks Class Initialized
INFO - 2023-05-04 19:51:04 --> Utf8 Class Initialized
INFO - 2023-05-04 19:51:04 --> URI Class Initialized
INFO - 2023-05-04 19:51:04 --> Router Class Initialized
INFO - 2023-05-04 19:51:04 --> Output Class Initialized
INFO - 2023-05-04 19:51:04 --> Security Class Initialized
INFO - 2023-05-04 19:51:04 --> Input Class Initialized
INFO - 2023-05-04 19:51:04 --> Language Class Initialized
INFO - 2023-05-04 19:51:04 --> Loader Class Initialized
INFO - 2023-05-04 19:51:04 --> Helper loaded: url_helper
INFO - 2023-05-04 19:51:04 --> Helper loaded: form_helper
INFO - 2023-05-04 19:51:04 --> Database Driver Class Initialized
INFO - 2023-05-04 19:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:51:04 --> Form Validation Class Initialized
INFO - 2023-05-04 19:51:04 --> Controller Class Initialized
INFO - 2023-05-04 19:51:04 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:51:04 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:51:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:51:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:51:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:51:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:51:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:51:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:51:04 --> Final output sent to browser
INFO - 2023-05-04 19:51:21 --> Config Class Initialized
INFO - 2023-05-04 19:51:21 --> Hooks Class Initialized
INFO - 2023-05-04 19:51:21 --> Utf8 Class Initialized
INFO - 2023-05-04 19:51:21 --> URI Class Initialized
INFO - 2023-05-04 19:51:21 --> Router Class Initialized
INFO - 2023-05-04 19:51:21 --> Output Class Initialized
INFO - 2023-05-04 19:51:21 --> Security Class Initialized
INFO - 2023-05-04 19:51:21 --> Input Class Initialized
INFO - 2023-05-04 19:51:21 --> Language Class Initialized
INFO - 2023-05-04 19:51:21 --> Loader Class Initialized
INFO - 2023-05-04 19:51:21 --> Helper loaded: url_helper
INFO - 2023-05-04 19:51:21 --> Helper loaded: form_helper
INFO - 2023-05-04 19:51:21 --> Database Driver Class Initialized
INFO - 2023-05-04 19:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:51:21 --> Form Validation Class Initialized
INFO - 2023-05-04 19:51:21 --> Controller Class Initialized
INFO - 2023-05-04 19:51:21 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:51:21 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:51:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:51:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:51:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:51:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:51:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:51:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:51:21 --> Final output sent to browser
INFO - 2023-05-04 19:51:24 --> Config Class Initialized
INFO - 2023-05-04 19:51:24 --> Hooks Class Initialized
INFO - 2023-05-04 19:51:24 --> Utf8 Class Initialized
INFO - 2023-05-04 19:51:24 --> URI Class Initialized
INFO - 2023-05-04 19:51:24 --> Router Class Initialized
INFO - 2023-05-04 19:51:24 --> Output Class Initialized
INFO - 2023-05-04 19:51:24 --> Security Class Initialized
INFO - 2023-05-04 19:51:24 --> Input Class Initialized
INFO - 2023-05-04 19:51:24 --> Language Class Initialized
INFO - 2023-05-04 19:51:24 --> Loader Class Initialized
INFO - 2023-05-04 19:51:24 --> Helper loaded: url_helper
INFO - 2023-05-04 19:51:24 --> Helper loaded: form_helper
INFO - 2023-05-04 19:51:24 --> Database Driver Class Initialized
INFO - 2023-05-04 19:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:51:24 --> Form Validation Class Initialized
INFO - 2023-05-04 19:51:24 --> Controller Class Initialized
INFO - 2023-05-04 19:51:24 --> Model "M_todo_list" initialized
INFO - 2023-05-04 19:51:24 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:51:24 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:51:24 --> Model "M_todo_task" initialized
INFO - 2023-05-04 19:51:24 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:51:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:51:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:51:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_list/v_index.php
INFO - 2023-05-04 19:51:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:51:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:51:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:51:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:51:24 --> Final output sent to browser
INFO - 2023-05-04 19:51:45 --> Config Class Initialized
INFO - 2023-05-04 19:51:45 --> Hooks Class Initialized
INFO - 2023-05-04 19:51:45 --> Utf8 Class Initialized
INFO - 2023-05-04 19:51:45 --> URI Class Initialized
INFO - 2023-05-04 19:51:45 --> Router Class Initialized
INFO - 2023-05-04 19:51:45 --> Output Class Initialized
INFO - 2023-05-04 19:51:45 --> Security Class Initialized
INFO - 2023-05-04 19:51:45 --> Input Class Initialized
INFO - 2023-05-04 19:51:45 --> Language Class Initialized
INFO - 2023-05-04 19:51:45 --> Loader Class Initialized
INFO - 2023-05-04 19:51:45 --> Helper loaded: url_helper
INFO - 2023-05-04 19:51:45 --> Helper loaded: form_helper
INFO - 2023-05-04 19:51:45 --> Database Driver Class Initialized
INFO - 2023-05-04 19:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:51:45 --> Form Validation Class Initialized
INFO - 2023-05-04 19:51:45 --> Controller Class Initialized
INFO - 2023-05-04 19:51:45 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:51:45 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:51:45 --> Final output sent to browser
INFO - 2023-05-04 19:53:33 --> Config Class Initialized
INFO - 2023-05-04 19:53:33 --> Hooks Class Initialized
INFO - 2023-05-04 19:53:33 --> Utf8 Class Initialized
INFO - 2023-05-04 19:53:33 --> URI Class Initialized
INFO - 2023-05-04 19:53:33 --> Router Class Initialized
INFO - 2023-05-04 19:53:33 --> Output Class Initialized
INFO - 2023-05-04 19:53:33 --> Security Class Initialized
INFO - 2023-05-04 19:53:33 --> Input Class Initialized
INFO - 2023-05-04 19:53:33 --> Language Class Initialized
INFO - 2023-05-04 19:53:33 --> Loader Class Initialized
INFO - 2023-05-04 19:53:33 --> Helper loaded: url_helper
INFO - 2023-05-04 19:53:33 --> Helper loaded: form_helper
INFO - 2023-05-04 19:53:33 --> Database Driver Class Initialized
INFO - 2023-05-04 19:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:53:33 --> Form Validation Class Initialized
INFO - 2023-05-04 19:53:33 --> Controller Class Initialized
INFO - 2023-05-04 19:53:33 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:53:33 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:53:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:53:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:53:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:53:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:53:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:53:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:53:33 --> Final output sent to browser
INFO - 2023-05-04 19:53:55 --> Config Class Initialized
INFO - 2023-05-04 19:53:55 --> Hooks Class Initialized
INFO - 2023-05-04 19:53:55 --> Utf8 Class Initialized
INFO - 2023-05-04 19:53:55 --> URI Class Initialized
INFO - 2023-05-04 19:53:55 --> Router Class Initialized
INFO - 2023-05-04 19:53:55 --> Output Class Initialized
INFO - 2023-05-04 19:53:55 --> Security Class Initialized
INFO - 2023-05-04 19:53:55 --> Input Class Initialized
INFO - 2023-05-04 19:53:55 --> Language Class Initialized
INFO - 2023-05-04 19:53:55 --> Loader Class Initialized
INFO - 2023-05-04 19:53:55 --> Helper loaded: url_helper
INFO - 2023-05-04 19:53:55 --> Helper loaded: form_helper
INFO - 2023-05-04 19:53:55 --> Database Driver Class Initialized
INFO - 2023-05-04 19:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:53:55 --> Form Validation Class Initialized
INFO - 2023-05-04 19:53:55 --> Controller Class Initialized
INFO - 2023-05-04 19:53:55 --> Model "M_todo_list" initialized
INFO - 2023-05-04 19:53:55 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:53:55 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:53:55 --> Model "M_todo_task" initialized
INFO - 2023-05-04 19:53:55 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:53:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:53:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:53:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_list/v_index.php
INFO - 2023-05-04 19:53:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:53:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:53:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:53:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:53:55 --> Final output sent to browser
INFO - 2023-05-04 19:54:04 --> Config Class Initialized
INFO - 2023-05-04 19:54:04 --> Hooks Class Initialized
INFO - 2023-05-04 19:54:04 --> Utf8 Class Initialized
INFO - 2023-05-04 19:54:04 --> URI Class Initialized
INFO - 2023-05-04 19:54:04 --> Router Class Initialized
INFO - 2023-05-04 19:54:04 --> Output Class Initialized
INFO - 2023-05-04 19:54:04 --> Security Class Initialized
INFO - 2023-05-04 19:54:04 --> Input Class Initialized
INFO - 2023-05-04 19:54:04 --> Language Class Initialized
INFO - 2023-05-04 19:54:04 --> Loader Class Initialized
INFO - 2023-05-04 19:54:04 --> Helper loaded: url_helper
INFO - 2023-05-04 19:54:04 --> Helper loaded: form_helper
INFO - 2023-05-04 19:54:04 --> Database Driver Class Initialized
INFO - 2023-05-04 19:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:54:04 --> Form Validation Class Initialized
INFO - 2023-05-04 19:54:04 --> Controller Class Initialized
INFO - 2023-05-04 19:54:04 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:54:04 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:54:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:54:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:54:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:54:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:54:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:54:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:54:04 --> Final output sent to browser
INFO - 2023-05-04 19:54:08 --> Config Class Initialized
INFO - 2023-05-04 19:54:08 --> Hooks Class Initialized
INFO - 2023-05-04 19:54:08 --> Utf8 Class Initialized
INFO - 2023-05-04 19:54:08 --> URI Class Initialized
INFO - 2023-05-04 19:54:08 --> Router Class Initialized
INFO - 2023-05-04 19:54:08 --> Output Class Initialized
INFO - 2023-05-04 19:54:08 --> Security Class Initialized
INFO - 2023-05-04 19:54:08 --> Input Class Initialized
INFO - 2023-05-04 19:54:08 --> Language Class Initialized
INFO - 2023-05-04 19:54:08 --> Loader Class Initialized
INFO - 2023-05-04 19:54:08 --> Helper loaded: url_helper
INFO - 2023-05-04 19:54:08 --> Helper loaded: form_helper
INFO - 2023-05-04 19:54:08 --> Database Driver Class Initialized
INFO - 2023-05-04 19:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:54:08 --> Form Validation Class Initialized
INFO - 2023-05-04 19:54:08 --> Controller Class Initialized
INFO - 2023-05-04 19:54:08 --> Model "M_todo_list" initialized
INFO - 2023-05-04 19:54:08 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:54:08 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:54:08 --> Model "M_todo_task" initialized
INFO - 2023-05-04 19:54:08 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_list/v_index.php
INFO - 2023-05-04 19:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:54:08 --> Final output sent to browser
INFO - 2023-05-04 19:54:18 --> Config Class Initialized
INFO - 2023-05-04 19:54:18 --> Hooks Class Initialized
INFO - 2023-05-04 19:54:18 --> Utf8 Class Initialized
INFO - 2023-05-04 19:54:18 --> URI Class Initialized
INFO - 2023-05-04 19:54:18 --> Router Class Initialized
INFO - 2023-05-04 19:54:18 --> Output Class Initialized
INFO - 2023-05-04 19:54:18 --> Security Class Initialized
INFO - 2023-05-04 19:54:18 --> Input Class Initialized
INFO - 2023-05-04 19:54:18 --> Language Class Initialized
INFO - 2023-05-04 19:54:18 --> Loader Class Initialized
INFO - 2023-05-04 19:54:18 --> Helper loaded: url_helper
INFO - 2023-05-04 19:54:18 --> Helper loaded: form_helper
INFO - 2023-05-04 19:54:18 --> Database Driver Class Initialized
INFO - 2023-05-04 19:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:54:18 --> Form Validation Class Initialized
INFO - 2023-05-04 19:54:18 --> Controller Class Initialized
INFO - 2023-05-04 19:54:18 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:54:18 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:54:18 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:54:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:54:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:54:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_group/v_index.php
INFO - 2023-05-04 19:54:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:54:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:54:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:54:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:54:18 --> Final output sent to browser
INFO - 2023-05-04 19:54:21 --> Config Class Initialized
INFO - 2023-05-04 19:54:21 --> Hooks Class Initialized
INFO - 2023-05-04 19:54:21 --> Utf8 Class Initialized
INFO - 2023-05-04 19:54:21 --> URI Class Initialized
INFO - 2023-05-04 19:54:21 --> Router Class Initialized
INFO - 2023-05-04 19:54:21 --> Output Class Initialized
INFO - 2023-05-04 19:54:21 --> Security Class Initialized
INFO - 2023-05-04 19:54:21 --> Input Class Initialized
INFO - 2023-05-04 19:54:21 --> Language Class Initialized
INFO - 2023-05-04 19:54:21 --> Loader Class Initialized
INFO - 2023-05-04 19:54:21 --> Helper loaded: url_helper
INFO - 2023-05-04 19:54:21 --> Helper loaded: form_helper
INFO - 2023-05-04 19:54:21 --> Database Driver Class Initialized
INFO - 2023-05-04 19:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:54:21 --> Form Validation Class Initialized
INFO - 2023-05-04 19:54:21 --> Controller Class Initialized
INFO - 2023-05-04 19:54:21 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:54:21 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:54:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:54:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:54:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:54:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:54:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:54:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:54:21 --> Final output sent to browser
INFO - 2023-05-04 19:55:08 --> Config Class Initialized
INFO - 2023-05-04 19:55:08 --> Hooks Class Initialized
INFO - 2023-05-04 19:55:08 --> Utf8 Class Initialized
INFO - 2023-05-04 19:55:08 --> URI Class Initialized
INFO - 2023-05-04 19:55:08 --> Router Class Initialized
INFO - 2023-05-04 19:55:08 --> Output Class Initialized
INFO - 2023-05-04 19:55:08 --> Security Class Initialized
INFO - 2023-05-04 19:55:08 --> Input Class Initialized
INFO - 2023-05-04 19:55:08 --> Language Class Initialized
INFO - 2023-05-04 19:55:08 --> Loader Class Initialized
INFO - 2023-05-04 19:55:08 --> Helper loaded: url_helper
INFO - 2023-05-04 19:55:08 --> Helper loaded: form_helper
INFO - 2023-05-04 19:55:08 --> Database Driver Class Initialized
INFO - 2023-05-04 19:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:55:08 --> Form Validation Class Initialized
INFO - 2023-05-04 19:55:08 --> Controller Class Initialized
INFO - 2023-05-04 19:55:08 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:55:08 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:55:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:55:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:55:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:55:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:55:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:55:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:55:08 --> Final output sent to browser
INFO - 2023-05-04 19:55:17 --> Config Class Initialized
INFO - 2023-05-04 19:55:17 --> Hooks Class Initialized
INFO - 2023-05-04 19:55:17 --> Utf8 Class Initialized
INFO - 2023-05-04 19:55:17 --> URI Class Initialized
INFO - 2023-05-04 19:55:17 --> Router Class Initialized
INFO - 2023-05-04 19:55:17 --> Output Class Initialized
INFO - 2023-05-04 19:55:17 --> Security Class Initialized
INFO - 2023-05-04 19:55:17 --> Input Class Initialized
INFO - 2023-05-04 19:55:17 --> Language Class Initialized
INFO - 2023-05-04 19:55:17 --> Loader Class Initialized
INFO - 2023-05-04 19:55:17 --> Helper loaded: url_helper
INFO - 2023-05-04 19:55:17 --> Helper loaded: form_helper
INFO - 2023-05-04 19:55:17 --> Database Driver Class Initialized
INFO - 2023-05-04 19:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:55:17 --> Form Validation Class Initialized
INFO - 2023-05-04 19:55:17 --> Controller Class Initialized
INFO - 2023-05-04 19:55:17 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:55:17 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:55:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:55:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:55:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:55:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:55:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:55:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:55:17 --> Final output sent to browser
INFO - 2023-05-04 19:55:23 --> Config Class Initialized
INFO - 2023-05-04 19:55:23 --> Hooks Class Initialized
INFO - 2023-05-04 19:55:23 --> Utf8 Class Initialized
INFO - 2023-05-04 19:55:23 --> URI Class Initialized
INFO - 2023-05-04 19:55:23 --> Router Class Initialized
INFO - 2023-05-04 19:55:23 --> Output Class Initialized
INFO - 2023-05-04 19:55:23 --> Security Class Initialized
INFO - 2023-05-04 19:55:23 --> Input Class Initialized
INFO - 2023-05-04 19:55:23 --> Language Class Initialized
INFO - 2023-05-04 19:55:23 --> Loader Class Initialized
INFO - 2023-05-04 19:55:23 --> Helper loaded: url_helper
INFO - 2023-05-04 19:55:23 --> Helper loaded: form_helper
INFO - 2023-05-04 19:55:23 --> Database Driver Class Initialized
INFO - 2023-05-04 19:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:55:23 --> Form Validation Class Initialized
INFO - 2023-05-04 19:55:23 --> Controller Class Initialized
INFO - 2023-05-04 19:55:23 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:55:23 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:55:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:55:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:55:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_tutor/v_index.php
INFO - 2023-05-04 19:55:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:55:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:55:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:55:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:55:23 --> Final output sent to browser
INFO - 2023-05-04 19:55:32 --> Config Class Initialized
INFO - 2023-05-04 19:55:32 --> Hooks Class Initialized
INFO - 2023-05-04 19:55:32 --> Utf8 Class Initialized
INFO - 2023-05-04 19:55:32 --> URI Class Initialized
INFO - 2023-05-04 19:55:32 --> Router Class Initialized
INFO - 2023-05-04 19:55:32 --> Output Class Initialized
INFO - 2023-05-04 19:55:32 --> Security Class Initialized
INFO - 2023-05-04 19:55:32 --> Input Class Initialized
INFO - 2023-05-04 19:55:32 --> Language Class Initialized
INFO - 2023-05-04 19:55:32 --> Loader Class Initialized
INFO - 2023-05-04 19:55:32 --> Helper loaded: url_helper
INFO - 2023-05-04 19:55:32 --> Helper loaded: form_helper
INFO - 2023-05-04 19:55:32 --> Database Driver Class Initialized
INFO - 2023-05-04 19:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:55:32 --> Form Validation Class Initialized
INFO - 2023-05-04 19:55:32 --> Controller Class Initialized
INFO - 2023-05-04 19:55:32 --> Model "M_todo_list" initialized
INFO - 2023-05-04 19:55:32 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:55:32 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:55:32 --> Model "M_todo_task" initialized
INFO - 2023-05-04 19:55:32 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:55:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:55:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:55:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_list/v_index.php
INFO - 2023-05-04 19:55:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:55:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:55:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:55:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:55:32 --> Final output sent to browser
INFO - 2023-05-04 19:56:44 --> Config Class Initialized
INFO - 2023-05-04 19:56:44 --> Hooks Class Initialized
INFO - 2023-05-04 19:56:44 --> Utf8 Class Initialized
INFO - 2023-05-04 19:56:44 --> URI Class Initialized
INFO - 2023-05-04 19:56:44 --> Router Class Initialized
INFO - 2023-05-04 19:56:44 --> Output Class Initialized
INFO - 2023-05-04 19:56:44 --> Security Class Initialized
INFO - 2023-05-04 19:56:44 --> Input Class Initialized
INFO - 2023-05-04 19:56:44 --> Language Class Initialized
INFO - 2023-05-04 19:56:44 --> Loader Class Initialized
INFO - 2023-05-04 19:56:44 --> Helper loaded: url_helper
INFO - 2023-05-04 19:56:44 --> Helper loaded: form_helper
INFO - 2023-05-04 19:56:44 --> Database Driver Class Initialized
INFO - 2023-05-04 19:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:56:44 --> Form Validation Class Initialized
INFO - 2023-05-04 19:56:44 --> Controller Class Initialized
INFO - 2023-05-04 19:56:44 --> Model "M_todo_list" initialized
INFO - 2023-05-04 19:56:44 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:56:44 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:56:44 --> Model "M_todo_task" initialized
INFO - 2023-05-04 19:56:44 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_list/v_index.php
INFO - 2023-05-04 19:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:56:44 --> Final output sent to browser
INFO - 2023-05-04 19:57:23 --> Config Class Initialized
INFO - 2023-05-04 19:57:23 --> Hooks Class Initialized
INFO - 2023-05-04 19:57:23 --> Utf8 Class Initialized
INFO - 2023-05-04 19:57:23 --> URI Class Initialized
INFO - 2023-05-04 19:57:23 --> Router Class Initialized
INFO - 2023-05-04 19:57:23 --> Output Class Initialized
INFO - 2023-05-04 19:57:23 --> Security Class Initialized
INFO - 2023-05-04 19:57:23 --> Input Class Initialized
INFO - 2023-05-04 19:57:23 --> Language Class Initialized
INFO - 2023-05-04 19:57:23 --> Loader Class Initialized
INFO - 2023-05-04 19:57:23 --> Helper loaded: url_helper
INFO - 2023-05-04 19:57:23 --> Helper loaded: form_helper
INFO - 2023-05-04 19:57:23 --> Database Driver Class Initialized
INFO - 2023-05-04 19:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:57:23 --> Form Validation Class Initialized
INFO - 2023-05-04 19:57:23 --> Controller Class Initialized
INFO - 2023-05-04 19:57:23 --> Model "M_todo_group" initialized
INFO - 2023-05-04 19:57:23 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:57:23 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:57:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:57:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:57:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_group/v_index.php
INFO - 2023-05-04 19:57:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:57:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:57:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:57:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-04 19:57:23 --> Final output sent to browser
INFO - 2023-05-04 19:57:33 --> Config Class Initialized
INFO - 2023-05-04 19:57:33 --> Hooks Class Initialized
INFO - 2023-05-04 19:57:33 --> Utf8 Class Initialized
INFO - 2023-05-04 19:57:33 --> URI Class Initialized
INFO - 2023-05-04 19:57:33 --> Router Class Initialized
INFO - 2023-05-04 19:57:33 --> Output Class Initialized
INFO - 2023-05-04 19:57:33 --> Security Class Initialized
INFO - 2023-05-04 19:57:33 --> Input Class Initialized
INFO - 2023-05-04 19:57:33 --> Language Class Initialized
INFO - 2023-05-04 19:57:33 --> Loader Class Initialized
INFO - 2023-05-04 19:57:33 --> Helper loaded: url_helper
INFO - 2023-05-04 19:57:33 --> Helper loaded: form_helper
INFO - 2023-05-04 19:57:33 --> Database Driver Class Initialized
INFO - 2023-05-04 19:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:57:33 --> Form Validation Class Initialized
INFO - 2023-05-04 19:57:33 --> Controller Class Initialized
INFO - 2023-05-04 19:57:33 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:57:33 --> Config Class Initialized
INFO - 2023-05-04 19:57:33 --> Hooks Class Initialized
INFO - 2023-05-04 19:57:33 --> Utf8 Class Initialized
INFO - 2023-05-04 19:57:33 --> URI Class Initialized
INFO - 2023-05-04 19:57:33 --> Router Class Initialized
INFO - 2023-05-04 19:57:33 --> Output Class Initialized
INFO - 2023-05-04 19:57:33 --> Security Class Initialized
INFO - 2023-05-04 19:57:33 --> Input Class Initialized
INFO - 2023-05-04 19:57:33 --> Language Class Initialized
INFO - 2023-05-04 19:57:34 --> Loader Class Initialized
INFO - 2023-05-04 19:57:34 --> Helper loaded: url_helper
INFO - 2023-05-04 19:57:34 --> Helper loaded: form_helper
INFO - 2023-05-04 19:57:34 --> Database Driver Class Initialized
INFO - 2023-05-04 19:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:57:34 --> Form Validation Class Initialized
INFO - 2023-05-04 19:57:34 --> Controller Class Initialized
INFO - 2023-05-04 19:57:34 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:57:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-04 19:57:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-04 19:57:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-04 19:57:34 --> Final output sent to browser
INFO - 2023-05-04 19:57:49 --> Config Class Initialized
INFO - 2023-05-04 19:57:49 --> Hooks Class Initialized
INFO - 2023-05-04 19:57:49 --> Utf8 Class Initialized
INFO - 2023-05-04 19:57:49 --> URI Class Initialized
INFO - 2023-05-04 19:57:49 --> Router Class Initialized
INFO - 2023-05-04 19:57:49 --> Output Class Initialized
INFO - 2023-05-04 19:57:49 --> Security Class Initialized
INFO - 2023-05-04 19:57:49 --> Input Class Initialized
INFO - 2023-05-04 19:57:49 --> Language Class Initialized
INFO - 2023-05-04 19:57:49 --> Loader Class Initialized
INFO - 2023-05-04 19:57:49 --> Helper loaded: url_helper
INFO - 2023-05-04 19:57:49 --> Helper loaded: form_helper
INFO - 2023-05-04 19:57:49 --> Database Driver Class Initialized
INFO - 2023-05-04 19:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:57:49 --> Form Validation Class Initialized
INFO - 2023-05-04 19:57:49 --> Controller Class Initialized
INFO - 2023-05-04 19:57:49 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:57:50 --> Config Class Initialized
INFO - 2023-05-04 19:57:50 --> Hooks Class Initialized
INFO - 2023-05-04 19:57:50 --> Utf8 Class Initialized
INFO - 2023-05-04 19:57:50 --> URI Class Initialized
INFO - 2023-05-04 19:57:50 --> Router Class Initialized
INFO - 2023-05-04 19:57:50 --> Output Class Initialized
INFO - 2023-05-04 19:57:50 --> Security Class Initialized
INFO - 2023-05-04 19:57:50 --> Input Class Initialized
INFO - 2023-05-04 19:57:50 --> Language Class Initialized
INFO - 2023-05-04 19:57:50 --> Loader Class Initialized
INFO - 2023-05-04 19:57:50 --> Helper loaded: url_helper
INFO - 2023-05-04 19:57:50 --> Helper loaded: form_helper
INFO - 2023-05-04 19:57:50 --> Database Driver Class Initialized
INFO - 2023-05-04 19:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 19:57:50 --> Form Validation Class Initialized
INFO - 2023-05-04 19:57:50 --> Controller Class Initialized
INFO - 2023-05-04 19:57:50 --> Model "M_tutor" initialized
INFO - 2023-05-04 19:57:50 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 19:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 19:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 19:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 19:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 19:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 19:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 19:57:50 --> Final output sent to browser
INFO - 2023-05-04 20:01:29 --> Config Class Initialized
INFO - 2023-05-04 20:01:29 --> Hooks Class Initialized
INFO - 2023-05-04 20:01:29 --> Utf8 Class Initialized
INFO - 2023-05-04 20:01:29 --> URI Class Initialized
INFO - 2023-05-04 20:01:29 --> Router Class Initialized
INFO - 2023-05-04 20:01:29 --> Output Class Initialized
INFO - 2023-05-04 20:01:29 --> Security Class Initialized
INFO - 2023-05-04 20:01:29 --> Input Class Initialized
INFO - 2023-05-04 20:01:29 --> Language Class Initialized
INFO - 2023-05-04 20:01:29 --> Loader Class Initialized
INFO - 2023-05-04 20:01:29 --> Helper loaded: url_helper
INFO - 2023-05-04 20:01:29 --> Helper loaded: form_helper
INFO - 2023-05-04 20:01:29 --> Database Driver Class Initialized
INFO - 2023-05-04 20:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:01:29 --> Form Validation Class Initialized
INFO - 2023-05-04 20:01:29 --> Controller Class Initialized
INFO - 2023-05-04 20:01:29 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:01:29 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:01:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 20:01:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 20:01:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 20:01:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 20:01:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 20:01:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 20:01:29 --> Final output sent to browser
INFO - 2023-05-04 20:02:03 --> Config Class Initialized
INFO - 2023-05-04 20:02:03 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:03 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:03 --> URI Class Initialized
INFO - 2023-05-04 20:02:03 --> Router Class Initialized
INFO - 2023-05-04 20:02:03 --> Output Class Initialized
INFO - 2023-05-04 20:02:03 --> Security Class Initialized
INFO - 2023-05-04 20:02:03 --> Input Class Initialized
INFO - 2023-05-04 20:02:03 --> Language Class Initialized
INFO - 2023-05-04 20:02:03 --> Loader Class Initialized
INFO - 2023-05-04 20:02:03 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:03 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:03 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:03 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:03 --> Controller Class Initialized
INFO - 2023-05-04 20:02:03 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:03 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 20:02:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 20:02:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 20:02:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 20:02:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 20:02:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 20:02:03 --> Final output sent to browser
INFO - 2023-05-04 20:02:06 --> Config Class Initialized
INFO - 2023-05-04 20:02:06 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:06 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:06 --> URI Class Initialized
INFO - 2023-05-04 20:02:06 --> Router Class Initialized
INFO - 2023-05-04 20:02:06 --> Output Class Initialized
INFO - 2023-05-04 20:02:06 --> Security Class Initialized
INFO - 2023-05-04 20:02:06 --> Input Class Initialized
INFO - 2023-05-04 20:02:06 --> Language Class Initialized
INFO - 2023-05-04 20:02:06 --> Loader Class Initialized
INFO - 2023-05-04 20:02:06 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:06 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:06 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:06 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:06 --> Controller Class Initialized
INFO - 2023-05-04 20:02:06 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:06 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 20:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 20:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 20:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 20:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 20:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 20:02:06 --> Final output sent to browser
INFO - 2023-05-04 20:02:10 --> Config Class Initialized
INFO - 2023-05-04 20:02:10 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:10 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:10 --> URI Class Initialized
INFO - 2023-05-04 20:02:10 --> Router Class Initialized
INFO - 2023-05-04 20:02:10 --> Output Class Initialized
INFO - 2023-05-04 20:02:10 --> Security Class Initialized
INFO - 2023-05-04 20:02:10 --> Input Class Initialized
INFO - 2023-05-04 20:02:10 --> Language Class Initialized
INFO - 2023-05-04 20:02:10 --> Loader Class Initialized
INFO - 2023-05-04 20:02:10 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:10 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:10 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:10 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:10 --> Controller Class Initialized
INFO - 2023-05-04 20:02:10 --> Model "M_todo_list" initialized
INFO - 2023-05-04 20:02:10 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:10 --> Model "M_todo_group" initialized
INFO - 2023-05-04 20:02:10 --> Model "M_todo_task" initialized
INFO - 2023-05-04 20:02:10 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:10 --> Final output sent to browser
INFO - 2023-05-04 20:02:15 --> Config Class Initialized
INFO - 2023-05-04 20:02:15 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:15 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:15 --> URI Class Initialized
INFO - 2023-05-04 20:02:15 --> Router Class Initialized
INFO - 2023-05-04 20:02:15 --> Output Class Initialized
INFO - 2023-05-04 20:02:15 --> Security Class Initialized
INFO - 2023-05-04 20:02:15 --> Input Class Initialized
INFO - 2023-05-04 20:02:15 --> Language Class Initialized
INFO - 2023-05-04 20:02:15 --> Loader Class Initialized
INFO - 2023-05-04 20:02:15 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:15 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:15 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:15 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:15 --> Controller Class Initialized
INFO - 2023-05-04 20:02:15 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:15 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 20:02:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 20:02:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 20:02:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 20:02:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 20:02:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 20:02:15 --> Final output sent to browser
INFO - 2023-05-04 20:02:17 --> Config Class Initialized
INFO - 2023-05-04 20:02:17 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:17 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:17 --> URI Class Initialized
INFO - 2023-05-04 20:02:17 --> Router Class Initialized
INFO - 2023-05-04 20:02:17 --> Output Class Initialized
INFO - 2023-05-04 20:02:17 --> Security Class Initialized
INFO - 2023-05-04 20:02:17 --> Input Class Initialized
INFO - 2023-05-04 20:02:17 --> Language Class Initialized
INFO - 2023-05-04 20:02:17 --> Loader Class Initialized
INFO - 2023-05-04 20:02:17 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:17 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:17 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:17 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:17 --> Controller Class Initialized
INFO - 2023-05-04 20:02:17 --> Model "M_todo_list" initialized
INFO - 2023-05-04 20:02:17 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:17 --> Model "M_todo_group" initialized
INFO - 2023-05-04 20:02:17 --> Model "M_todo_task" initialized
INFO - 2023-05-04 20:02:17 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:17 --> Final output sent to browser
INFO - 2023-05-04 20:02:19 --> Config Class Initialized
INFO - 2023-05-04 20:02:19 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:19 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:19 --> URI Class Initialized
INFO - 2023-05-04 20:02:19 --> Router Class Initialized
INFO - 2023-05-04 20:02:19 --> Output Class Initialized
INFO - 2023-05-04 20:02:19 --> Security Class Initialized
INFO - 2023-05-04 20:02:19 --> Input Class Initialized
INFO - 2023-05-04 20:02:19 --> Language Class Initialized
INFO - 2023-05-04 20:02:19 --> Loader Class Initialized
INFO - 2023-05-04 20:02:19 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:19 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:19 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:19 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:19 --> Controller Class Initialized
INFO - 2023-05-04 20:02:19 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:19 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 20:02:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 20:02:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 20:02:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 20:02:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 20:02:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 20:02:19 --> Final output sent to browser
INFO - 2023-05-04 20:02:22 --> Config Class Initialized
INFO - 2023-05-04 20:02:22 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:22 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:22 --> URI Class Initialized
INFO - 2023-05-04 20:02:22 --> Router Class Initialized
INFO - 2023-05-04 20:02:22 --> Output Class Initialized
INFO - 2023-05-04 20:02:22 --> Security Class Initialized
INFO - 2023-05-04 20:02:22 --> Input Class Initialized
INFO - 2023-05-04 20:02:22 --> Language Class Initialized
INFO - 2023-05-04 20:02:22 --> Loader Class Initialized
INFO - 2023-05-04 20:02:22 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:22 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:22 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:22 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:22 --> Controller Class Initialized
INFO - 2023-05-04 20:02:22 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:22 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 20:02:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 20:02:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 20:02:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 20:02:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 20:02:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 20:02:22 --> Final output sent to browser
INFO - 2023-05-04 20:02:41 --> Config Class Initialized
INFO - 2023-05-04 20:02:41 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:41 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:41 --> URI Class Initialized
INFO - 2023-05-04 20:02:41 --> Router Class Initialized
INFO - 2023-05-04 20:02:41 --> Output Class Initialized
INFO - 2023-05-04 20:02:41 --> Security Class Initialized
INFO - 2023-05-04 20:02:41 --> Input Class Initialized
INFO - 2023-05-04 20:02:41 --> Language Class Initialized
INFO - 2023-05-04 20:02:41 --> Loader Class Initialized
INFO - 2023-05-04 20:02:41 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:41 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:41 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:41 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:41 --> Controller Class Initialized
INFO - 2023-05-04 20:02:41 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:41 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 20:02:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 20:02:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 20:02:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 20:02:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 20:02:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 20:02:41 --> Final output sent to browser
INFO - 2023-05-04 20:02:43 --> Config Class Initialized
INFO - 2023-05-04 20:02:43 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:43 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:43 --> URI Class Initialized
INFO - 2023-05-04 20:02:43 --> Router Class Initialized
INFO - 2023-05-04 20:02:43 --> Output Class Initialized
INFO - 2023-05-04 20:02:43 --> Security Class Initialized
INFO - 2023-05-04 20:02:43 --> Input Class Initialized
INFO - 2023-05-04 20:02:43 --> Language Class Initialized
INFO - 2023-05-04 20:02:43 --> Loader Class Initialized
INFO - 2023-05-04 20:02:43 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:43 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:43 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:43 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:43 --> Controller Class Initialized
INFO - 2023-05-04 20:02:43 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:43 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 20:02:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 20:02:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 20:02:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 20:02:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 20:02:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 20:02:43 --> Final output sent to browser
INFO - 2023-05-04 20:02:48 --> Config Class Initialized
INFO - 2023-05-04 20:02:48 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:48 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:48 --> URI Class Initialized
INFO - 2023-05-04 20:02:48 --> Router Class Initialized
INFO - 2023-05-04 20:02:48 --> Output Class Initialized
INFO - 2023-05-04 20:02:48 --> Security Class Initialized
INFO - 2023-05-04 20:02:48 --> Input Class Initialized
INFO - 2023-05-04 20:02:48 --> Language Class Initialized
INFO - 2023-05-04 20:02:48 --> Loader Class Initialized
INFO - 2023-05-04 20:02:48 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:48 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:48 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:48 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:48 --> Controller Class Initialized
INFO - 2023-05-04 20:02:48 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:48 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 20:02:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 20:02:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 20:02:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 20:02:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 20:02:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 20:02:48 --> Final output sent to browser
INFO - 2023-05-04 20:02:50 --> Config Class Initialized
INFO - 2023-05-04 20:02:50 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:50 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:50 --> URI Class Initialized
INFO - 2023-05-04 20:02:50 --> Router Class Initialized
INFO - 2023-05-04 20:02:50 --> Output Class Initialized
INFO - 2023-05-04 20:02:50 --> Security Class Initialized
INFO - 2023-05-04 20:02:50 --> Input Class Initialized
INFO - 2023-05-04 20:02:50 --> Language Class Initialized
INFO - 2023-05-04 20:02:50 --> Loader Class Initialized
INFO - 2023-05-04 20:02:50 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:50 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:50 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:50 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:50 --> Controller Class Initialized
INFO - 2023-05-04 20:02:50 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:50 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 20:02:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 20:02:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 20:02:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 20:02:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 20:02:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 20:02:50 --> Final output sent to browser
INFO - 2023-05-04 20:02:52 --> Config Class Initialized
INFO - 2023-05-04 20:02:52 --> Hooks Class Initialized
INFO - 2023-05-04 20:02:52 --> Utf8 Class Initialized
INFO - 2023-05-04 20:02:52 --> URI Class Initialized
INFO - 2023-05-04 20:02:52 --> Router Class Initialized
INFO - 2023-05-04 20:02:52 --> Output Class Initialized
INFO - 2023-05-04 20:02:52 --> Security Class Initialized
INFO - 2023-05-04 20:02:52 --> Input Class Initialized
INFO - 2023-05-04 20:02:52 --> Language Class Initialized
INFO - 2023-05-04 20:02:52 --> Loader Class Initialized
INFO - 2023-05-04 20:02:52 --> Helper loaded: url_helper
INFO - 2023-05-04 20:02:52 --> Helper loaded: form_helper
INFO - 2023-05-04 20:02:52 --> Database Driver Class Initialized
INFO - 2023-05-04 20:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-04 20:02:52 --> Form Validation Class Initialized
INFO - 2023-05-04 20:02:52 --> Controller Class Initialized
INFO - 2023-05-04 20:02:52 --> Model "M_tutor" initialized
INFO - 2023-05-04 20:02:52 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-04 20:02:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-04 20:02:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-04 20:02:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-04 20:02:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-04 20:02:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-04 20:02:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-04 20:02:52 --> Final output sent to browser
