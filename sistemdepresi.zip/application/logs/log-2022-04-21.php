<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-04-21 10:04:09 --> Config Class Initialized
INFO - 2022-04-21 10:04:09 --> Hooks Class Initialized
INFO - 2022-04-21 10:04:09 --> Utf8 Class Initialized
INFO - 2022-04-21 10:04:09 --> URI Class Initialized
INFO - 2022-04-21 10:04:09 --> Router Class Initialized
INFO - 2022-04-21 10:04:09 --> Output Class Initialized
INFO - 2022-04-21 10:04:09 --> Security Class Initialized
INFO - 2022-04-21 10:04:09 --> Input Class Initialized
INFO - 2022-04-21 10:04:09 --> Language Class Initialized
INFO - 2022-04-21 10:04:09 --> Loader Class Initialized
INFO - 2022-04-21 10:04:09 --> Helper loaded: url_helper
INFO - 2022-04-21 10:04:09 --> Helper loaded: form_helper
INFO - 2022-04-21 10:04:09 --> Database Driver Class Initialized
INFO - 2022-04-21 10:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:04:09 --> Form Validation Class Initialized
INFO - 2022-04-21 10:04:09 --> Controller Class Initialized
INFO - 2022-04-21 10:04:09 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:04:09 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:04:09 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:04:09 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:04:09 --> Final output sent to browser
INFO - 2022-04-21 10:04:26 --> Config Class Initialized
INFO - 2022-04-21 10:04:26 --> Hooks Class Initialized
INFO - 2022-04-21 10:04:26 --> Utf8 Class Initialized
INFO - 2022-04-21 10:04:26 --> URI Class Initialized
INFO - 2022-04-21 10:04:26 --> Router Class Initialized
INFO - 2022-04-21 10:04:26 --> Output Class Initialized
INFO - 2022-04-21 10:04:26 --> Security Class Initialized
INFO - 2022-04-21 10:04:26 --> Input Class Initialized
INFO - 2022-04-21 10:04:26 --> Language Class Initialized
INFO - 2022-04-21 10:04:26 --> Loader Class Initialized
INFO - 2022-04-21 10:04:26 --> Helper loaded: url_helper
INFO - 2022-04-21 10:04:26 --> Helper loaded: form_helper
INFO - 2022-04-21 10:04:26 --> Database Driver Class Initialized
INFO - 2022-04-21 10:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:04:27 --> Form Validation Class Initialized
INFO - 2022-04-21 10:04:27 --> Controller Class Initialized
INFO - 2022-04-21 10:04:27 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:04:27 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:04:27 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:04:27 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:04:27 --> Final output sent to browser
INFO - 2022-04-21 10:04:36 --> Config Class Initialized
INFO - 2022-04-21 10:04:36 --> Hooks Class Initialized
INFO - 2022-04-21 10:04:36 --> Utf8 Class Initialized
INFO - 2022-04-21 10:04:36 --> URI Class Initialized
INFO - 2022-04-21 10:04:36 --> Router Class Initialized
INFO - 2022-04-21 10:04:36 --> Output Class Initialized
INFO - 2022-04-21 10:04:36 --> Security Class Initialized
INFO - 2022-04-21 10:04:36 --> Input Class Initialized
INFO - 2022-04-21 10:04:36 --> Language Class Initialized
INFO - 2022-04-21 10:04:36 --> Loader Class Initialized
INFO - 2022-04-21 10:04:36 --> Helper loaded: url_helper
INFO - 2022-04-21 10:04:36 --> Helper loaded: form_helper
INFO - 2022-04-21 10:04:36 --> Database Driver Class Initialized
INFO - 2022-04-21 10:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:04:36 --> Form Validation Class Initialized
INFO - 2022-04-21 10:04:36 --> Controller Class Initialized
INFO - 2022-04-21 10:04:36 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:04:36 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:04:36 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:04:36 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:04:36 --> Final output sent to browser
INFO - 2022-04-21 10:04:49 --> Config Class Initialized
INFO - 2022-04-21 10:04:49 --> Hooks Class Initialized
INFO - 2022-04-21 10:04:49 --> Utf8 Class Initialized
INFO - 2022-04-21 10:04:49 --> URI Class Initialized
INFO - 2022-04-21 10:04:49 --> Router Class Initialized
INFO - 2022-04-21 10:04:49 --> Output Class Initialized
INFO - 2022-04-21 10:04:49 --> Security Class Initialized
INFO - 2022-04-21 10:04:49 --> Input Class Initialized
INFO - 2022-04-21 10:04:49 --> Language Class Initialized
INFO - 2022-04-21 10:04:49 --> Loader Class Initialized
INFO - 2022-04-21 10:04:49 --> Helper loaded: url_helper
INFO - 2022-04-21 10:04:49 --> Helper loaded: form_helper
INFO - 2022-04-21 10:04:49 --> Database Driver Class Initialized
INFO - 2022-04-21 10:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:04:49 --> Form Validation Class Initialized
INFO - 2022-04-21 10:04:49 --> Controller Class Initialized
INFO - 2022-04-21 10:04:49 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:04:49 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:06:34 --> Config Class Initialized
INFO - 2022-04-21 10:06:34 --> Hooks Class Initialized
INFO - 2022-04-21 10:06:34 --> Utf8 Class Initialized
INFO - 2022-04-21 10:06:34 --> URI Class Initialized
INFO - 2022-04-21 10:06:34 --> Router Class Initialized
INFO - 2022-04-21 10:06:34 --> Output Class Initialized
INFO - 2022-04-21 10:06:34 --> Security Class Initialized
INFO - 2022-04-21 10:06:34 --> Input Class Initialized
INFO - 2022-04-21 10:06:34 --> Language Class Initialized
INFO - 2022-04-21 10:06:34 --> Loader Class Initialized
INFO - 2022-04-21 10:06:34 --> Helper loaded: url_helper
INFO - 2022-04-21 10:06:34 --> Helper loaded: form_helper
INFO - 2022-04-21 10:06:34 --> Database Driver Class Initialized
INFO - 2022-04-21 10:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:06:34 --> Form Validation Class Initialized
INFO - 2022-04-21 10:06:34 --> Controller Class Initialized
INFO - 2022-04-21 10:06:34 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:06:35 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:06:35 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:06:35 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:06:35 --> Final output sent to browser
INFO - 2022-04-21 10:06:46 --> Config Class Initialized
INFO - 2022-04-21 10:06:46 --> Hooks Class Initialized
INFO - 2022-04-21 10:06:46 --> Utf8 Class Initialized
INFO - 2022-04-21 10:06:46 --> URI Class Initialized
INFO - 2022-04-21 10:06:46 --> Router Class Initialized
INFO - 2022-04-21 10:06:46 --> Output Class Initialized
INFO - 2022-04-21 10:06:46 --> Security Class Initialized
INFO - 2022-04-21 10:06:46 --> Input Class Initialized
INFO - 2022-04-21 10:06:46 --> Language Class Initialized
INFO - 2022-04-21 10:06:46 --> Loader Class Initialized
INFO - 2022-04-21 10:06:46 --> Helper loaded: url_helper
INFO - 2022-04-21 10:06:46 --> Helper loaded: form_helper
INFO - 2022-04-21 10:06:46 --> Database Driver Class Initialized
INFO - 2022-04-21 10:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:06:46 --> Form Validation Class Initialized
INFO - 2022-04-21 10:06:46 --> Controller Class Initialized
INFO - 2022-04-21 10:06:46 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:06:46 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:06:46 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:06:46 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:06:46 --> Final output sent to browser
INFO - 2022-04-21 10:09:04 --> Config Class Initialized
INFO - 2022-04-21 10:09:04 --> Hooks Class Initialized
INFO - 2022-04-21 10:09:04 --> Utf8 Class Initialized
INFO - 2022-04-21 10:09:04 --> URI Class Initialized
INFO - 2022-04-21 10:09:04 --> Router Class Initialized
INFO - 2022-04-21 10:09:04 --> Output Class Initialized
INFO - 2022-04-21 10:09:04 --> Security Class Initialized
INFO - 2022-04-21 10:09:04 --> Input Class Initialized
INFO - 2022-04-21 10:09:04 --> Language Class Initialized
INFO - 2022-04-21 10:09:04 --> Loader Class Initialized
INFO - 2022-04-21 10:09:04 --> Helper loaded: url_helper
INFO - 2022-04-21 10:09:04 --> Helper loaded: form_helper
INFO - 2022-04-21 10:09:04 --> Database Driver Class Initialized
INFO - 2022-04-21 10:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:09:04 --> Form Validation Class Initialized
INFO - 2022-04-21 10:09:04 --> Controller Class Initialized
INFO - 2022-04-21 10:09:04 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:09:04 --> Model "M_todo_group_ptk" initialized
ERROR - 2022-04-21 10:09:04 --> 404 Page Not Found: 
INFO - 2022-04-21 10:09:14 --> Config Class Initialized
INFO - 2022-04-21 10:09:14 --> Hooks Class Initialized
INFO - 2022-04-21 10:09:14 --> Utf8 Class Initialized
INFO - 2022-04-21 10:09:14 --> URI Class Initialized
INFO - 2022-04-21 10:09:14 --> Router Class Initialized
INFO - 2022-04-21 10:09:14 --> Output Class Initialized
INFO - 2022-04-21 10:09:14 --> Security Class Initialized
INFO - 2022-04-21 10:09:14 --> Input Class Initialized
INFO - 2022-04-21 10:09:14 --> Language Class Initialized
INFO - 2022-04-21 10:09:14 --> Loader Class Initialized
INFO - 2022-04-21 10:09:14 --> Helper loaded: url_helper
INFO - 2022-04-21 10:09:14 --> Helper loaded: form_helper
INFO - 2022-04-21 10:09:14 --> Database Driver Class Initialized
INFO - 2022-04-21 10:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:09:14 --> Form Validation Class Initialized
INFO - 2022-04-21 10:09:14 --> Controller Class Initialized
INFO - 2022-04-21 10:09:14 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:09:14 --> Model "M_todo_group_ptk" initialized
ERROR - 2022-04-21 10:09:14 --> 404 Page Not Found: 
INFO - 2022-04-21 10:10:51 --> Config Class Initialized
INFO - 2022-04-21 10:10:51 --> Hooks Class Initialized
INFO - 2022-04-21 10:10:51 --> Utf8 Class Initialized
INFO - 2022-04-21 10:10:51 --> URI Class Initialized
INFO - 2022-04-21 10:10:51 --> Router Class Initialized
INFO - 2022-04-21 10:10:51 --> Output Class Initialized
INFO - 2022-04-21 10:10:51 --> Security Class Initialized
INFO - 2022-04-21 10:10:51 --> Input Class Initialized
INFO - 2022-04-21 10:10:51 --> Language Class Initialized
INFO - 2022-04-21 10:10:51 --> Loader Class Initialized
INFO - 2022-04-21 10:10:51 --> Helper loaded: url_helper
INFO - 2022-04-21 10:10:51 --> Helper loaded: form_helper
INFO - 2022-04-21 10:10:51 --> Database Driver Class Initialized
INFO - 2022-04-21 10:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:10:51 --> Form Validation Class Initialized
INFO - 2022-04-21 10:10:51 --> Controller Class Initialized
INFO - 2022-04-21 10:10:51 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:10:51 --> Model "M_todo_group_ptk" initialized
ERROR - 2022-04-21 10:10:51 --> 404 Page Not Found: 
INFO - 2022-04-21 10:10:53 --> Config Class Initialized
INFO - 2022-04-21 10:10:53 --> Hooks Class Initialized
INFO - 2022-04-21 10:10:53 --> Utf8 Class Initialized
INFO - 2022-04-21 10:10:53 --> URI Class Initialized
INFO - 2022-04-21 10:10:53 --> Router Class Initialized
INFO - 2022-04-21 10:10:53 --> Output Class Initialized
INFO - 2022-04-21 10:10:53 --> Security Class Initialized
INFO - 2022-04-21 10:10:53 --> Input Class Initialized
INFO - 2022-04-21 10:10:53 --> Language Class Initialized
INFO - 2022-04-21 10:10:53 --> Loader Class Initialized
INFO - 2022-04-21 10:10:53 --> Helper loaded: url_helper
INFO - 2022-04-21 10:10:53 --> Helper loaded: form_helper
INFO - 2022-04-21 10:10:53 --> Database Driver Class Initialized
INFO - 2022-04-21 10:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:10:53 --> Form Validation Class Initialized
INFO - 2022-04-21 10:10:53 --> Controller Class Initialized
INFO - 2022-04-21 10:10:53 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:10:53 --> Model "M_todo_group_ptk" initialized
ERROR - 2022-04-21 10:10:53 --> 404 Page Not Found: 
INFO - 2022-04-21 10:10:54 --> Config Class Initialized
INFO - 2022-04-21 10:10:54 --> Hooks Class Initialized
INFO - 2022-04-21 10:10:54 --> Utf8 Class Initialized
INFO - 2022-04-21 10:10:54 --> URI Class Initialized
INFO - 2022-04-21 10:10:54 --> Router Class Initialized
INFO - 2022-04-21 10:10:54 --> Output Class Initialized
INFO - 2022-04-21 10:10:54 --> Security Class Initialized
INFO - 2022-04-21 10:10:54 --> Input Class Initialized
INFO - 2022-04-21 10:10:54 --> Language Class Initialized
INFO - 2022-04-21 10:10:54 --> Loader Class Initialized
INFO - 2022-04-21 10:10:54 --> Helper loaded: url_helper
INFO - 2022-04-21 10:10:54 --> Helper loaded: form_helper
INFO - 2022-04-21 10:10:54 --> Database Driver Class Initialized
INFO - 2022-04-21 10:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:10:54 --> Form Validation Class Initialized
INFO - 2022-04-21 10:10:54 --> Controller Class Initialized
INFO - 2022-04-21 10:10:54 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:10:54 --> Model "M_todo_group_ptk" initialized
ERROR - 2022-04-21 10:10:54 --> 404 Page Not Found: 
INFO - 2022-04-21 10:11:01 --> Config Class Initialized
INFO - 2022-04-21 10:11:01 --> Hooks Class Initialized
INFO - 2022-04-21 10:11:01 --> Utf8 Class Initialized
INFO - 2022-04-21 10:11:01 --> URI Class Initialized
INFO - 2022-04-21 10:11:01 --> Router Class Initialized
INFO - 2022-04-21 10:11:01 --> Output Class Initialized
INFO - 2022-04-21 10:11:01 --> Security Class Initialized
INFO - 2022-04-21 10:11:01 --> Input Class Initialized
INFO - 2022-04-21 10:11:01 --> Language Class Initialized
INFO - 2022-04-21 10:11:01 --> Loader Class Initialized
INFO - 2022-04-21 10:11:01 --> Helper loaded: url_helper
INFO - 2022-04-21 10:11:01 --> Helper loaded: form_helper
INFO - 2022-04-21 10:11:01 --> Database Driver Class Initialized
INFO - 2022-04-21 10:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:11:01 --> Form Validation Class Initialized
INFO - 2022-04-21 10:11:01 --> Controller Class Initialized
INFO - 2022-04-21 10:11:01 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:11:01 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:11:01 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:11:01 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:11:01 --> Final output sent to browser
INFO - 2022-04-21 10:11:02 --> Config Class Initialized
INFO - 2022-04-21 10:11:02 --> Config Class Initialized
INFO - 2022-04-21 10:11:02 --> Hooks Class Initialized
INFO - 2022-04-21 10:11:02 --> Hooks Class Initialized
INFO - 2022-04-21 10:11:02 --> Config Class Initialized
INFO - 2022-04-21 10:11:02 --> Hooks Class Initialized
INFO - 2022-04-21 10:11:02 --> Config Class Initialized
INFO - 2022-04-21 10:11:02 --> Hooks Class Initialized
INFO - 2022-04-21 10:11:02 --> Utf8 Class Initialized
INFO - 2022-04-21 10:11:02 --> Utf8 Class Initialized
INFO - 2022-04-21 10:11:02 --> URI Class Initialized
INFO - 2022-04-21 10:11:02 --> URI Class Initialized
INFO - 2022-04-21 10:11:02 --> Utf8 Class Initialized
INFO - 2022-04-21 10:11:02 --> Utf8 Class Initialized
INFO - 2022-04-21 10:11:02 --> Router Class Initialized
INFO - 2022-04-21 10:11:02 --> URI Class Initialized
INFO - 2022-04-21 10:11:02 --> URI Class Initialized
INFO - 2022-04-21 10:11:02 --> Router Class Initialized
INFO - 2022-04-21 10:11:02 --> Output Class Initialized
INFO - 2022-04-21 10:11:02 --> Router Class Initialized
INFO - 2022-04-21 10:11:02 --> Security Class Initialized
INFO - 2022-04-21 10:11:02 --> Output Class Initialized
INFO - 2022-04-21 10:11:02 --> Router Class Initialized
INFO - 2022-04-21 10:11:02 --> Output Class Initialized
INFO - 2022-04-21 10:11:02 --> Input Class Initialized
INFO - 2022-04-21 10:11:02 --> Security Class Initialized
INFO - 2022-04-21 10:11:02 --> Language Class Initialized
INFO - 2022-04-21 10:11:02 --> Security Class Initialized
INFO - 2022-04-21 10:11:02 --> Output Class Initialized
INFO - 2022-04-21 10:11:02 --> Input Class Initialized
ERROR - 2022-04-21 10:11:02 --> 404 Page Not Found: Localhost/lisa-todo
INFO - 2022-04-21 10:11:02 --> Input Class Initialized
INFO - 2022-04-21 10:11:02 --> Language Class Initialized
INFO - 2022-04-21 10:11:02 --> Language Class Initialized
INFO - 2022-04-21 10:11:02 --> Security Class Initialized
ERROR - 2022-04-21 10:11:02 --> 404 Page Not Found: Localhost/lisa-todo
ERROR - 2022-04-21 10:11:02 --> 404 Page Not Found: Localhost/lisa-todo
INFO - 2022-04-21 10:11:02 --> Input Class Initialized
INFO - 2022-04-21 10:11:02 --> Language Class Initialized
ERROR - 2022-04-21 10:11:02 --> 404 Page Not Found: Localhost/lisa-todo
INFO - 2022-04-21 10:11:02 --> Config Class Initialized
INFO - 2022-04-21 10:11:02 --> Hooks Class Initialized
INFO - 2022-04-21 10:11:02 --> Config Class Initialized
INFO - 2022-04-21 10:11:02 --> Hooks Class Initialized
INFO - 2022-04-21 10:11:02 --> Config Class Initialized
INFO - 2022-04-21 10:11:02 --> Hooks Class Initialized
INFO - 2022-04-21 10:11:02 --> Utf8 Class Initialized
INFO - 2022-04-21 10:11:02 --> Utf8 Class Initialized
INFO - 2022-04-21 10:11:02 --> URI Class Initialized
INFO - 2022-04-21 10:11:02 --> URI Class Initialized
INFO - 2022-04-21 10:11:02 --> Utf8 Class Initialized
INFO - 2022-04-21 10:11:02 --> Router Class Initialized
INFO - 2022-04-21 10:11:02 --> URI Class Initialized
INFO - 2022-04-21 10:11:02 --> Router Class Initialized
INFO - 2022-04-21 10:11:02 --> Output Class Initialized
INFO - 2022-04-21 10:11:02 --> Security Class Initialized
INFO - 2022-04-21 10:11:02 --> Output Class Initialized
INFO - 2022-04-21 10:11:02 --> Router Class Initialized
INFO - 2022-04-21 10:11:02 --> Input Class Initialized
INFO - 2022-04-21 10:11:02 --> Security Class Initialized
INFO - 2022-04-21 10:11:02 --> Language Class Initialized
INFO - 2022-04-21 10:11:02 --> Output Class Initialized
INFO - 2022-04-21 10:11:02 --> Input Class Initialized
ERROR - 2022-04-21 10:11:02 --> 404 Page Not Found: Localhost/lisa-todo
INFO - 2022-04-21 10:11:02 --> Security Class Initialized
INFO - 2022-04-21 10:11:02 --> Language Class Initialized
INFO - 2022-04-21 10:11:02 --> Input Class Initialized
ERROR - 2022-04-21 10:11:02 --> 404 Page Not Found: Localhost/lisa-todo
INFO - 2022-04-21 10:11:02 --> Language Class Initialized
ERROR - 2022-04-21 10:11:02 --> 404 Page Not Found: Localhost/lisa-todo
INFO - 2022-04-21 10:11:02 --> Config Class Initialized
INFO - 2022-04-21 10:11:02 --> Hooks Class Initialized
INFO - 2022-04-21 10:11:02 --> Utf8 Class Initialized
INFO - 2022-04-21 10:11:02 --> URI Class Initialized
INFO - 2022-04-21 10:11:02 --> Router Class Initialized
INFO - 2022-04-21 10:11:02 --> Output Class Initialized
INFO - 2022-04-21 10:11:02 --> Security Class Initialized
INFO - 2022-04-21 10:11:02 --> Input Class Initialized
INFO - 2022-04-21 10:11:02 --> Language Class Initialized
ERROR - 2022-04-21 10:11:02 --> 404 Page Not Found: Localhost/lisa-todo
INFO - 2022-04-21 10:11:13 --> Config Class Initialized
INFO - 2022-04-21 10:11:13 --> Hooks Class Initialized
INFO - 2022-04-21 10:11:13 --> Utf8 Class Initialized
INFO - 2022-04-21 10:11:13 --> URI Class Initialized
INFO - 2022-04-21 10:11:13 --> Router Class Initialized
INFO - 2022-04-21 10:11:13 --> Output Class Initialized
INFO - 2022-04-21 10:11:13 --> Security Class Initialized
INFO - 2022-04-21 10:11:13 --> Input Class Initialized
INFO - 2022-04-21 10:11:13 --> Language Class Initialized
ERROR - 2022-04-21 10:11:13 --> 404 Page Not Found: Localhost/lisa-todo
INFO - 2022-04-21 10:14:39 --> Config Class Initialized
INFO - 2022-04-21 10:14:39 --> Hooks Class Initialized
INFO - 2022-04-21 10:14:39 --> Utf8 Class Initialized
INFO - 2022-04-21 10:14:39 --> URI Class Initialized
INFO - 2022-04-21 10:14:39 --> Router Class Initialized
INFO - 2022-04-21 10:14:39 --> Output Class Initialized
INFO - 2022-04-21 10:14:39 --> Security Class Initialized
INFO - 2022-04-21 10:14:39 --> Input Class Initialized
INFO - 2022-04-21 10:14:39 --> Language Class Initialized
INFO - 2022-04-21 10:14:39 --> Loader Class Initialized
INFO - 2022-04-21 10:14:39 --> Helper loaded: url_helper
INFO - 2022-04-21 10:14:39 --> Helper loaded: form_helper
INFO - 2022-04-21 10:14:39 --> Database Driver Class Initialized
INFO - 2022-04-21 10:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:14:39 --> Form Validation Class Initialized
INFO - 2022-04-21 10:14:39 --> Controller Class Initialized
INFO - 2022-04-21 10:14:39 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:14:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:14:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:14:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:14:39 --> Final output sent to browser
INFO - 2022-04-21 10:14:46 --> Config Class Initialized
INFO - 2022-04-21 10:14:46 --> Hooks Class Initialized
INFO - 2022-04-21 10:14:46 --> Utf8 Class Initialized
INFO - 2022-04-21 10:14:46 --> URI Class Initialized
INFO - 2022-04-21 10:14:46 --> Router Class Initialized
INFO - 2022-04-21 10:14:46 --> Output Class Initialized
INFO - 2022-04-21 10:14:46 --> Security Class Initialized
INFO - 2022-04-21 10:14:46 --> Input Class Initialized
INFO - 2022-04-21 10:14:46 --> Language Class Initialized
INFO - 2022-04-21 10:14:46 --> Loader Class Initialized
INFO - 2022-04-21 10:14:47 --> Helper loaded: url_helper
INFO - 2022-04-21 10:14:47 --> Helper loaded: form_helper
INFO - 2022-04-21 10:14:47 --> Database Driver Class Initialized
INFO - 2022-04-21 10:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:14:47 --> Form Validation Class Initialized
INFO - 2022-04-21 10:14:47 --> Controller Class Initialized
INFO - 2022-04-21 10:14:47 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:14:47 --> Config Class Initialized
INFO - 2022-04-21 10:14:47 --> Hooks Class Initialized
INFO - 2022-04-21 10:14:47 --> Utf8 Class Initialized
INFO - 2022-04-21 10:14:47 --> URI Class Initialized
INFO - 2022-04-21 10:14:47 --> Router Class Initialized
INFO - 2022-04-21 10:14:47 --> Output Class Initialized
INFO - 2022-04-21 10:14:47 --> Security Class Initialized
INFO - 2022-04-21 10:14:47 --> Input Class Initialized
INFO - 2022-04-21 10:14:47 --> Language Class Initialized
INFO - 2022-04-21 10:14:47 --> Loader Class Initialized
INFO - 2022-04-21 10:14:47 --> Helper loaded: url_helper
INFO - 2022-04-21 10:14:47 --> Helper loaded: form_helper
INFO - 2022-04-21 10:14:47 --> Database Driver Class Initialized
INFO - 2022-04-21 10:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:14:47 --> Form Validation Class Initialized
INFO - 2022-04-21 10:14:47 --> Controller Class Initialized
INFO - 2022-04-21 10:14:47 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:14:47 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:14:47 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:14:47 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:14:47 --> Final output sent to browser
INFO - 2022-04-21 10:14:58 --> Config Class Initialized
INFO - 2022-04-21 10:14:58 --> Hooks Class Initialized
INFO - 2022-04-21 10:14:58 --> Utf8 Class Initialized
INFO - 2022-04-21 10:14:58 --> URI Class Initialized
INFO - 2022-04-21 10:14:58 --> Router Class Initialized
INFO - 2022-04-21 10:14:58 --> Output Class Initialized
INFO - 2022-04-21 10:14:58 --> Security Class Initialized
INFO - 2022-04-21 10:14:58 --> Input Class Initialized
INFO - 2022-04-21 10:14:58 --> Language Class Initialized
INFO - 2022-04-21 10:14:58 --> Loader Class Initialized
INFO - 2022-04-21 10:14:58 --> Helper loaded: url_helper
INFO - 2022-04-21 10:14:58 --> Helper loaded: form_helper
INFO - 2022-04-21 10:14:58 --> Database Driver Class Initialized
INFO - 2022-04-21 10:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:14:58 --> Form Validation Class Initialized
INFO - 2022-04-21 10:14:58 --> Controller Class Initialized
INFO - 2022-04-21 10:14:58 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:14:58 --> Config Class Initialized
INFO - 2022-04-21 10:14:58 --> Hooks Class Initialized
INFO - 2022-04-21 10:14:58 --> Utf8 Class Initialized
INFO - 2022-04-21 10:14:58 --> URI Class Initialized
INFO - 2022-04-21 10:14:58 --> Router Class Initialized
INFO - 2022-04-21 10:14:58 --> Output Class Initialized
INFO - 2022-04-21 10:14:58 --> Security Class Initialized
INFO - 2022-04-21 10:14:58 --> Input Class Initialized
INFO - 2022-04-21 10:14:58 --> Language Class Initialized
INFO - 2022-04-21 10:14:58 --> Loader Class Initialized
INFO - 2022-04-21 10:14:58 --> Helper loaded: url_helper
INFO - 2022-04-21 10:14:58 --> Helper loaded: form_helper
INFO - 2022-04-21 10:14:58 --> Database Driver Class Initialized
INFO - 2022-04-21 10:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:14:58 --> Form Validation Class Initialized
INFO - 2022-04-21 10:14:58 --> Controller Class Initialized
INFO - 2022-04-21 10:14:58 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:14:58 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:14:58 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:14:58 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:14:58 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:14:58 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:14:58 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:14:58 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:14:58 --> Final output sent to browser
INFO - 2022-04-21 10:15:55 --> Config Class Initialized
INFO - 2022-04-21 10:15:55 --> Hooks Class Initialized
INFO - 2022-04-21 10:15:55 --> Utf8 Class Initialized
INFO - 2022-04-21 10:15:55 --> URI Class Initialized
INFO - 2022-04-21 10:15:55 --> Router Class Initialized
INFO - 2022-04-21 10:15:55 --> Output Class Initialized
INFO - 2022-04-21 10:15:55 --> Security Class Initialized
INFO - 2022-04-21 10:15:55 --> Input Class Initialized
INFO - 2022-04-21 10:15:55 --> Language Class Initialized
INFO - 2022-04-21 10:15:55 --> Loader Class Initialized
INFO - 2022-04-21 10:15:55 --> Helper loaded: url_helper
INFO - 2022-04-21 10:15:55 --> Helper loaded: form_helper
INFO - 2022-04-21 10:15:55 --> Database Driver Class Initialized
INFO - 2022-04-21 10:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:15:55 --> Form Validation Class Initialized
INFO - 2022-04-21 10:15:55 --> Controller Class Initialized
INFO - 2022-04-21 10:15:55 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:15:55 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:15:55 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:15:55 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:15:55 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:15:55 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:15:55 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:15:55 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:15:55 --> Final output sent to browser
INFO - 2022-04-21 10:16:00 --> Config Class Initialized
INFO - 2022-04-21 10:16:00 --> Hooks Class Initialized
INFO - 2022-04-21 10:16:00 --> Utf8 Class Initialized
INFO - 2022-04-21 10:16:00 --> URI Class Initialized
INFO - 2022-04-21 10:16:00 --> Router Class Initialized
INFO - 2022-04-21 10:16:00 --> Output Class Initialized
INFO - 2022-04-21 10:16:00 --> Security Class Initialized
INFO - 2022-04-21 10:16:00 --> Input Class Initialized
INFO - 2022-04-21 10:16:00 --> Language Class Initialized
INFO - 2022-04-21 10:16:00 --> Loader Class Initialized
INFO - 2022-04-21 10:16:00 --> Helper loaded: url_helper
INFO - 2022-04-21 10:16:00 --> Helper loaded: form_helper
INFO - 2022-04-21 10:16:00 --> Database Driver Class Initialized
INFO - 2022-04-21 10:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:16:00 --> Form Validation Class Initialized
INFO - 2022-04-21 10:16:00 --> Controller Class Initialized
INFO - 2022-04-21 10:16:00 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:16:00 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:16:00 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:16:00 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:16:00 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:16:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:16:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:16:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 10:16:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:16:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:16:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:16:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:16:00 --> Final output sent to browser
INFO - 2022-04-21 10:16:11 --> Config Class Initialized
INFO - 2022-04-21 10:16:11 --> Hooks Class Initialized
INFO - 2022-04-21 10:16:11 --> Utf8 Class Initialized
INFO - 2022-04-21 10:16:11 --> URI Class Initialized
INFO - 2022-04-21 10:16:11 --> Router Class Initialized
INFO - 2022-04-21 10:16:11 --> Output Class Initialized
INFO - 2022-04-21 10:16:11 --> Security Class Initialized
INFO - 2022-04-21 10:16:11 --> Input Class Initialized
INFO - 2022-04-21 10:16:11 --> Language Class Initialized
INFO - 2022-04-21 10:16:11 --> Loader Class Initialized
INFO - 2022-04-21 10:16:11 --> Helper loaded: url_helper
INFO - 2022-04-21 10:16:11 --> Helper loaded: form_helper
INFO - 2022-04-21 10:16:11 --> Database Driver Class Initialized
INFO - 2022-04-21 10:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:16:11 --> Form Validation Class Initialized
INFO - 2022-04-21 10:16:11 --> Controller Class Initialized
INFO - 2022-04-21 10:16:11 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:16:11 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:16:11 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:16:11 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:16:11 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:16:11 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:16:11 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:16:11 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:16:11 --> Final output sent to browser
INFO - 2022-04-21 10:16:14 --> Config Class Initialized
INFO - 2022-04-21 10:16:14 --> Hooks Class Initialized
INFO - 2022-04-21 10:16:14 --> Utf8 Class Initialized
INFO - 2022-04-21 10:16:14 --> URI Class Initialized
INFO - 2022-04-21 10:16:14 --> Router Class Initialized
INFO - 2022-04-21 10:16:14 --> Output Class Initialized
INFO - 2022-04-21 10:16:14 --> Security Class Initialized
INFO - 2022-04-21 10:16:14 --> Input Class Initialized
INFO - 2022-04-21 10:16:14 --> Language Class Initialized
INFO - 2022-04-21 10:16:14 --> Loader Class Initialized
INFO - 2022-04-21 10:16:14 --> Helper loaded: url_helper
INFO - 2022-04-21 10:16:14 --> Helper loaded: form_helper
INFO - 2022-04-21 10:16:14 --> Database Driver Class Initialized
INFO - 2022-04-21 10:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:16:14 --> Form Validation Class Initialized
INFO - 2022-04-21 10:16:14 --> Controller Class Initialized
INFO - 2022-04-21 10:16:14 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:16:14 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:16:14 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:16:14 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:16:14 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:16:14 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:16:14 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:16:14 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 10:16:14 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:16:14 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:16:14 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:16:14 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:16:14 --> Final output sent to browser
INFO - 2022-04-21 10:16:21 --> Config Class Initialized
INFO - 2022-04-21 10:16:21 --> Hooks Class Initialized
INFO - 2022-04-21 10:16:21 --> Utf8 Class Initialized
INFO - 2022-04-21 10:16:21 --> URI Class Initialized
INFO - 2022-04-21 10:16:21 --> Router Class Initialized
INFO - 2022-04-21 10:16:21 --> Output Class Initialized
INFO - 2022-04-21 10:16:21 --> Security Class Initialized
INFO - 2022-04-21 10:16:21 --> Input Class Initialized
INFO - 2022-04-21 10:16:21 --> Language Class Initialized
INFO - 2022-04-21 10:16:21 --> Loader Class Initialized
INFO - 2022-04-21 10:16:21 --> Helper loaded: url_helper
INFO - 2022-04-21 10:16:21 --> Helper loaded: form_helper
INFO - 2022-04-21 10:16:21 --> Database Driver Class Initialized
INFO - 2022-04-21 10:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:16:21 --> Form Validation Class Initialized
INFO - 2022-04-21 10:16:21 --> Controller Class Initialized
INFO - 2022-04-21 10:16:21 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:16:21 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:16:21 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:16:21 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:16:21 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:16:21 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:16:21 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:16:21 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:16:21 --> Final output sent to browser
INFO - 2022-04-21 10:16:27 --> Config Class Initialized
INFO - 2022-04-21 10:16:27 --> Hooks Class Initialized
INFO - 2022-04-21 10:16:27 --> Utf8 Class Initialized
INFO - 2022-04-21 10:16:27 --> URI Class Initialized
INFO - 2022-04-21 10:16:27 --> Router Class Initialized
INFO - 2022-04-21 10:16:27 --> Output Class Initialized
INFO - 2022-04-21 10:16:27 --> Security Class Initialized
INFO - 2022-04-21 10:16:27 --> Input Class Initialized
INFO - 2022-04-21 10:16:27 --> Language Class Initialized
INFO - 2022-04-21 10:16:27 --> Loader Class Initialized
INFO - 2022-04-21 10:16:27 --> Helper loaded: url_helper
INFO - 2022-04-21 10:16:27 --> Helper loaded: form_helper
INFO - 2022-04-21 10:16:27 --> Database Driver Class Initialized
INFO - 2022-04-21 10:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:16:27 --> Form Validation Class Initialized
INFO - 2022-04-21 10:16:27 --> Controller Class Initialized
INFO - 2022-04-21 10:16:27 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:16:27 --> Model "M_todo_group_ptk" initialized
ERROR - 2022-04-21 10:16:27 --> 404 Page Not Found: 
INFO - 2022-04-21 10:16:41 --> Config Class Initialized
INFO - 2022-04-21 10:16:41 --> Hooks Class Initialized
INFO - 2022-04-21 10:16:41 --> Utf8 Class Initialized
INFO - 2022-04-21 10:16:41 --> URI Class Initialized
INFO - 2022-04-21 10:16:41 --> Router Class Initialized
INFO - 2022-04-21 10:16:41 --> Output Class Initialized
INFO - 2022-04-21 10:16:41 --> Security Class Initialized
INFO - 2022-04-21 10:16:41 --> Input Class Initialized
INFO - 2022-04-21 10:16:41 --> Language Class Initialized
INFO - 2022-04-21 10:16:41 --> Loader Class Initialized
INFO - 2022-04-21 10:16:41 --> Helper loaded: url_helper
INFO - 2022-04-21 10:16:41 --> Helper loaded: form_helper
INFO - 2022-04-21 10:16:41 --> Database Driver Class Initialized
INFO - 2022-04-21 10:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:16:41 --> Form Validation Class Initialized
INFO - 2022-04-21 10:16:41 --> Controller Class Initialized
INFO - 2022-04-21 10:16:41 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:16:41 --> Model "M_todo_group_ptk" initialized
ERROR - 2022-04-21 10:16:41 --> 404 Page Not Found: 
INFO - 2022-04-21 10:17:04 --> Config Class Initialized
INFO - 2022-04-21 10:17:04 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:04 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:04 --> URI Class Initialized
INFO - 2022-04-21 10:17:04 --> Router Class Initialized
INFO - 2022-04-21 10:17:04 --> Output Class Initialized
INFO - 2022-04-21 10:17:04 --> Security Class Initialized
INFO - 2022-04-21 10:17:04 --> Input Class Initialized
INFO - 2022-04-21 10:17:04 --> Language Class Initialized
ERROR - 2022-04-21 10:17:04 --> 404 Page Not Found: Todo_tutor/index
INFO - 2022-04-21 10:17:09 --> Config Class Initialized
INFO - 2022-04-21 10:17:09 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:09 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:09 --> URI Class Initialized
INFO - 2022-04-21 10:17:09 --> Router Class Initialized
INFO - 2022-04-21 10:17:09 --> Output Class Initialized
INFO - 2022-04-21 10:17:09 --> Security Class Initialized
INFO - 2022-04-21 10:17:09 --> Input Class Initialized
INFO - 2022-04-21 10:17:09 --> Language Class Initialized
INFO - 2022-04-21 10:17:09 --> Loader Class Initialized
INFO - 2022-04-21 10:17:09 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:09 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:09 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:09 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:09 --> Controller Class Initialized
INFO - 2022-04-21 10:17:09 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:09 --> Config Class Initialized
INFO - 2022-04-21 10:17:09 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:09 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:09 --> URI Class Initialized
INFO - 2022-04-21 10:17:09 --> Router Class Initialized
INFO - 2022-04-21 10:17:09 --> Output Class Initialized
INFO - 2022-04-21 10:17:09 --> Security Class Initialized
INFO - 2022-04-21 10:17:09 --> Input Class Initialized
INFO - 2022-04-21 10:17:09 --> Language Class Initialized
INFO - 2022-04-21 10:17:09 --> Loader Class Initialized
INFO - 2022-04-21 10:17:09 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:09 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:09 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:09 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:09 --> Controller Class Initialized
INFO - 2022-04-21 10:17:09 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:09 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:17:09 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:17:09 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:17:09 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:17:09 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:17:09 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:17:09 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:17:09 --> Final output sent to browser
INFO - 2022-04-21 10:17:18 --> Config Class Initialized
INFO - 2022-04-21 10:17:18 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:18 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:18 --> URI Class Initialized
INFO - 2022-04-21 10:17:18 --> Router Class Initialized
INFO - 2022-04-21 10:17:18 --> Output Class Initialized
INFO - 2022-04-21 10:17:18 --> Security Class Initialized
INFO - 2022-04-21 10:17:18 --> Input Class Initialized
INFO - 2022-04-21 10:17:18 --> Language Class Initialized
INFO - 2022-04-21 10:17:18 --> Loader Class Initialized
INFO - 2022-04-21 10:17:18 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:18 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:18 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:18 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:18 --> Controller Class Initialized
INFO - 2022-04-21 10:17:18 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:18 --> Config Class Initialized
INFO - 2022-04-21 10:17:18 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:18 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:18 --> URI Class Initialized
INFO - 2022-04-21 10:17:18 --> Router Class Initialized
INFO - 2022-04-21 10:17:18 --> Output Class Initialized
INFO - 2022-04-21 10:17:18 --> Security Class Initialized
INFO - 2022-04-21 10:17:18 --> Input Class Initialized
INFO - 2022-04-21 10:17:18 --> Language Class Initialized
INFO - 2022-04-21 10:17:18 --> Loader Class Initialized
INFO - 2022-04-21 10:17:18 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:18 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:18 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:18 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:18 --> Controller Class Initialized
INFO - 2022-04-21 10:17:18 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:18 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:17:18 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:17:18 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:17:18 --> Final output sent to browser
INFO - 2022-04-21 10:17:22 --> Config Class Initialized
INFO - 2022-04-21 10:17:22 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:22 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:22 --> URI Class Initialized
INFO - 2022-04-21 10:17:22 --> Router Class Initialized
INFO - 2022-04-21 10:17:22 --> Output Class Initialized
INFO - 2022-04-21 10:17:22 --> Security Class Initialized
INFO - 2022-04-21 10:17:22 --> Input Class Initialized
INFO - 2022-04-21 10:17:22 --> Language Class Initialized
INFO - 2022-04-21 10:17:22 --> Loader Class Initialized
INFO - 2022-04-21 10:17:22 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:22 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:22 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:22 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:22 --> Controller Class Initialized
INFO - 2022-04-21 10:17:22 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:22 --> Config Class Initialized
INFO - 2022-04-21 10:17:22 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:22 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:22 --> URI Class Initialized
INFO - 2022-04-21 10:17:22 --> Router Class Initialized
INFO - 2022-04-21 10:17:22 --> Output Class Initialized
INFO - 2022-04-21 10:17:22 --> Security Class Initialized
INFO - 2022-04-21 10:17:22 --> Input Class Initialized
INFO - 2022-04-21 10:17:22 --> Language Class Initialized
INFO - 2022-04-21 10:17:22 --> Loader Class Initialized
INFO - 2022-04-21 10:17:22 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:22 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:22 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:22 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:22 --> Controller Class Initialized
INFO - 2022-04-21 10:17:22 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:22 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:17:22 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:17:22 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:17:22 --> Final output sent to browser
INFO - 2022-04-21 10:17:26 --> Config Class Initialized
INFO - 2022-04-21 10:17:26 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:26 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:26 --> URI Class Initialized
INFO - 2022-04-21 10:17:26 --> Router Class Initialized
INFO - 2022-04-21 10:17:26 --> Output Class Initialized
INFO - 2022-04-21 10:17:26 --> Security Class Initialized
INFO - 2022-04-21 10:17:26 --> Input Class Initialized
INFO - 2022-04-21 10:17:26 --> Language Class Initialized
INFO - 2022-04-21 10:17:26 --> Loader Class Initialized
INFO - 2022-04-21 10:17:26 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:26 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:26 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:26 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:26 --> Controller Class Initialized
INFO - 2022-04-21 10:17:26 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:26 --> Config Class Initialized
INFO - 2022-04-21 10:17:26 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:26 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:26 --> URI Class Initialized
INFO - 2022-04-21 10:17:26 --> Router Class Initialized
INFO - 2022-04-21 10:17:26 --> Output Class Initialized
INFO - 2022-04-21 10:17:26 --> Security Class Initialized
INFO - 2022-04-21 10:17:26 --> Input Class Initialized
INFO - 2022-04-21 10:17:26 --> Language Class Initialized
INFO - 2022-04-21 10:17:26 --> Loader Class Initialized
INFO - 2022-04-21 10:17:26 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:26 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:26 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:26 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:26 --> Controller Class Initialized
INFO - 2022-04-21 10:17:26 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:26 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:17:26 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:17:26 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:17:26 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:17:26 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:17:26 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:17:26 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:17:26 --> Final output sent to browser
INFO - 2022-04-21 10:17:31 --> Config Class Initialized
INFO - 2022-04-21 10:17:31 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:31 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:31 --> URI Class Initialized
INFO - 2022-04-21 10:17:31 --> Router Class Initialized
INFO - 2022-04-21 10:17:31 --> Output Class Initialized
INFO - 2022-04-21 10:17:31 --> Security Class Initialized
INFO - 2022-04-21 10:17:31 --> Input Class Initialized
INFO - 2022-04-21 10:17:31 --> Language Class Initialized
INFO - 2022-04-21 10:17:31 --> Loader Class Initialized
INFO - 2022-04-21 10:17:31 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:31 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:31 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:31 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:31 --> Controller Class Initialized
INFO - 2022-04-21 10:17:31 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:31 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:17:31 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:17:31 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:17:31 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 10:17:31 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:17:31 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:17:31 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:17:31 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:17:31 --> Final output sent to browser
INFO - 2022-04-21 10:17:40 --> Config Class Initialized
INFO - 2022-04-21 10:17:40 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:40 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:40 --> URI Class Initialized
INFO - 2022-04-21 10:17:40 --> Router Class Initialized
INFO - 2022-04-21 10:17:40 --> Output Class Initialized
INFO - 2022-04-21 10:17:40 --> Security Class Initialized
INFO - 2022-04-21 10:17:40 --> Input Class Initialized
INFO - 2022-04-21 10:17:40 --> Language Class Initialized
INFO - 2022-04-21 10:17:40 --> Loader Class Initialized
INFO - 2022-04-21 10:17:40 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:40 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:40 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:40 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:40 --> Controller Class Initialized
INFO - 2022-04-21 10:17:40 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:40 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:17:40 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:17:40 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:17:40 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:17:40 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:17:40 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:17:40 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:17:40 --> Final output sent to browser
INFO - 2022-04-21 10:17:42 --> Config Class Initialized
INFO - 2022-04-21 10:17:42 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:42 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:42 --> URI Class Initialized
INFO - 2022-04-21 10:17:42 --> Router Class Initialized
INFO - 2022-04-21 10:17:42 --> Output Class Initialized
INFO - 2022-04-21 10:17:42 --> Security Class Initialized
INFO - 2022-04-21 10:17:42 --> Input Class Initialized
INFO - 2022-04-21 10:17:42 --> Language Class Initialized
INFO - 2022-04-21 10:17:42 --> Loader Class Initialized
INFO - 2022-04-21 10:17:42 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:42 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:42 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:42 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:42 --> Controller Class Initialized
INFO - 2022-04-21 10:17:42 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:17:42 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:17:42 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:17:42 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:17:42 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:42 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:17:42 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:17:42 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 10:17:42 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:17:42 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:17:42 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:17:42 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:17:42 --> Final output sent to browser
INFO - 2022-04-21 10:17:49 --> Config Class Initialized
INFO - 2022-04-21 10:17:49 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:49 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:49 --> URI Class Initialized
INFO - 2022-04-21 10:17:49 --> Router Class Initialized
INFO - 2022-04-21 10:17:49 --> Output Class Initialized
INFO - 2022-04-21 10:17:49 --> Security Class Initialized
INFO - 2022-04-21 10:17:49 --> Input Class Initialized
INFO - 2022-04-21 10:17:49 --> Language Class Initialized
INFO - 2022-04-21 10:17:49 --> Loader Class Initialized
INFO - 2022-04-21 10:17:49 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:49 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:49 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:49 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:49 --> Controller Class Initialized
INFO - 2022-04-21 10:17:49 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:17:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:17:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_admin/v_index.php
INFO - 2022-04-21 10:17:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:17:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:17:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:17:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:17:49 --> Final output sent to browser
INFO - 2022-04-21 10:17:50 --> Config Class Initialized
INFO - 2022-04-21 10:17:50 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:50 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:50 --> URI Class Initialized
INFO - 2022-04-21 10:17:50 --> Router Class Initialized
INFO - 2022-04-21 10:17:50 --> Output Class Initialized
INFO - 2022-04-21 10:17:50 --> Security Class Initialized
INFO - 2022-04-21 10:17:50 --> Input Class Initialized
INFO - 2022-04-21 10:17:50 --> Language Class Initialized
INFO - 2022-04-21 10:17:50 --> Loader Class Initialized
INFO - 2022-04-21 10:17:50 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:50 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:50 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:50 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:50 --> Controller Class Initialized
INFO - 2022-04-21 10:17:50 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:50 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:17:50 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:17:50 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:17:50 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 10:17:50 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:17:50 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:17:50 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:17:50 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:17:50 --> Final output sent to browser
INFO - 2022-04-21 10:17:51 --> Config Class Initialized
INFO - 2022-04-21 10:17:51 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:51 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:51 --> URI Class Initialized
INFO - 2022-04-21 10:17:51 --> Router Class Initialized
INFO - 2022-04-21 10:17:51 --> Output Class Initialized
INFO - 2022-04-21 10:17:51 --> Security Class Initialized
INFO - 2022-04-21 10:17:51 --> Input Class Initialized
INFO - 2022-04-21 10:17:51 --> Language Class Initialized
INFO - 2022-04-21 10:17:51 --> Loader Class Initialized
INFO - 2022-04-21 10:17:51 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:51 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:51 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:51 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:51 --> Controller Class Initialized
INFO - 2022-04-21 10:17:51 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:17:51 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:17:51 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:17:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:17:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_group/v_index.php
INFO - 2022-04-21 10:17:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:17:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:17:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:17:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:17:51 --> Final output sent to browser
INFO - 2022-04-21 10:17:54 --> Config Class Initialized
INFO - 2022-04-21 10:17:54 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:54 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:54 --> URI Class Initialized
INFO - 2022-04-21 10:17:54 --> Router Class Initialized
INFO - 2022-04-21 10:17:54 --> Output Class Initialized
INFO - 2022-04-21 10:17:54 --> Security Class Initialized
INFO - 2022-04-21 10:17:54 --> Input Class Initialized
INFO - 2022-04-21 10:17:54 --> Language Class Initialized
INFO - 2022-04-21 10:17:54 --> Loader Class Initialized
INFO - 2022-04-21 10:17:54 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:54 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:54 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:54 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:54 --> Controller Class Initialized
INFO - 2022-04-21 10:17:54 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:17:54 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:17:54 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:17:54 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:17:54 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:17:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:17:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 10:17:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:17:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:17:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:17:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:17:54 --> Final output sent to browser
INFO - 2022-04-21 10:17:56 --> Config Class Initialized
INFO - 2022-04-21 10:17:56 --> Hooks Class Initialized
INFO - 2022-04-21 10:17:56 --> Utf8 Class Initialized
INFO - 2022-04-21 10:17:56 --> URI Class Initialized
INFO - 2022-04-21 10:17:56 --> Router Class Initialized
INFO - 2022-04-21 10:17:56 --> Output Class Initialized
INFO - 2022-04-21 10:17:56 --> Security Class Initialized
INFO - 2022-04-21 10:17:56 --> Input Class Initialized
INFO - 2022-04-21 10:17:56 --> Language Class Initialized
INFO - 2022-04-21 10:17:56 --> Loader Class Initialized
INFO - 2022-04-21 10:17:56 --> Helper loaded: url_helper
INFO - 2022-04-21 10:17:56 --> Helper loaded: form_helper
INFO - 2022-04-21 10:17:56 --> Database Driver Class Initialized
INFO - 2022-04-21 10:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:17:56 --> Form Validation Class Initialized
INFO - 2022-04-21 10:17:56 --> Controller Class Initialized
INFO - 2022-04-21 10:17:56 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:17:56 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:17:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:17:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:17:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:17:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:17:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:17:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:17:56 --> Final output sent to browser
INFO - 2022-04-21 10:18:07 --> Config Class Initialized
INFO - 2022-04-21 10:18:07 --> Hooks Class Initialized
INFO - 2022-04-21 10:18:07 --> Utf8 Class Initialized
INFO - 2022-04-21 10:18:07 --> URI Class Initialized
INFO - 2022-04-21 10:18:07 --> Router Class Initialized
INFO - 2022-04-21 10:18:07 --> Output Class Initialized
INFO - 2022-04-21 10:18:07 --> Security Class Initialized
INFO - 2022-04-21 10:18:07 --> Input Class Initialized
INFO - 2022-04-21 10:18:07 --> Language Class Initialized
INFO - 2022-04-21 10:18:07 --> Loader Class Initialized
INFO - 2022-04-21 10:18:07 --> Helper loaded: url_helper
INFO - 2022-04-21 10:18:07 --> Helper loaded: form_helper
INFO - 2022-04-21 10:18:07 --> Database Driver Class Initialized
INFO - 2022-04-21 10:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:18:07 --> Form Validation Class Initialized
INFO - 2022-04-21 10:18:07 --> Controller Class Initialized
INFO - 2022-04-21 10:18:07 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:18:07 --> Config Class Initialized
INFO - 2022-04-21 10:18:07 --> Hooks Class Initialized
INFO - 2022-04-21 10:18:07 --> Utf8 Class Initialized
INFO - 2022-04-21 10:18:07 --> URI Class Initialized
INFO - 2022-04-21 10:18:07 --> Router Class Initialized
INFO - 2022-04-21 10:18:07 --> Output Class Initialized
INFO - 2022-04-21 10:18:07 --> Security Class Initialized
INFO - 2022-04-21 10:18:07 --> Input Class Initialized
INFO - 2022-04-21 10:18:07 --> Language Class Initialized
INFO - 2022-04-21 10:18:07 --> Loader Class Initialized
INFO - 2022-04-21 10:18:07 --> Helper loaded: url_helper
INFO - 2022-04-21 10:18:07 --> Helper loaded: form_helper
INFO - 2022-04-21 10:18:07 --> Database Driver Class Initialized
INFO - 2022-04-21 10:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:18:07 --> Form Validation Class Initialized
INFO - 2022-04-21 10:18:07 --> Controller Class Initialized
INFO - 2022-04-21 10:18:07 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:18:07 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:18:07 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:18:07 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:18:07 --> Final output sent to browser
INFO - 2022-04-21 10:27:53 --> Config Class Initialized
INFO - 2022-04-21 10:27:53 --> Hooks Class Initialized
INFO - 2022-04-21 10:27:53 --> Utf8 Class Initialized
INFO - 2022-04-21 10:27:53 --> URI Class Initialized
INFO - 2022-04-21 10:27:53 --> Router Class Initialized
INFO - 2022-04-21 10:27:53 --> Output Class Initialized
INFO - 2022-04-21 10:27:53 --> Security Class Initialized
INFO - 2022-04-21 10:27:53 --> Input Class Initialized
INFO - 2022-04-21 10:27:53 --> Language Class Initialized
INFO - 2022-04-21 10:27:53 --> Loader Class Initialized
INFO - 2022-04-21 10:27:53 --> Helper loaded: url_helper
INFO - 2022-04-21 10:27:53 --> Helper loaded: form_helper
INFO - 2022-04-21 10:27:53 --> Database Driver Class Initialized
INFO - 2022-04-21 10:27:57 --> Config Class Initialized
INFO - 2022-04-21 10:27:57 --> Hooks Class Initialized
INFO - 2022-04-21 10:27:57 --> Utf8 Class Initialized
INFO - 2022-04-21 10:27:57 --> URI Class Initialized
INFO - 2022-04-21 10:27:57 --> Router Class Initialized
INFO - 2022-04-21 10:27:57 --> Output Class Initialized
INFO - 2022-04-21 10:27:57 --> Security Class Initialized
INFO - 2022-04-21 10:27:57 --> Input Class Initialized
INFO - 2022-04-21 10:27:57 --> Language Class Initialized
INFO - 2022-04-21 10:27:57 --> Loader Class Initialized
INFO - 2022-04-21 10:27:57 --> Helper loaded: url_helper
INFO - 2022-04-21 10:27:57 --> Helper loaded: form_helper
INFO - 2022-04-21 10:27:57 --> Database Driver Class Initialized
ERROR - 2022-04-21 10:27:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lisa-todo\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-04-21 10:27:57 --> Unable to connect to the database
INFO - 2022-04-21 10:27:57 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-04-21 10:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lisa-todo\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-04-21 10:28:01 --> Unable to connect to the database
INFO - 2022-04-21 10:28:01 --> Language file loaded: language/english/db_lang.php
INFO - 2022-04-21 10:28:07 --> Config Class Initialized
INFO - 2022-04-21 10:28:07 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:07 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:07 --> URI Class Initialized
INFO - 2022-04-21 10:28:07 --> Router Class Initialized
INFO - 2022-04-21 10:28:07 --> Output Class Initialized
INFO - 2022-04-21 10:28:07 --> Security Class Initialized
INFO - 2022-04-21 10:28:07 --> Input Class Initialized
INFO - 2022-04-21 10:28:07 --> Language Class Initialized
INFO - 2022-04-21 10:28:07 --> Loader Class Initialized
INFO - 2022-04-21 10:28:07 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:07 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:07 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:07 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:07 --> Controller Class Initialized
INFO - 2022-04-21 10:28:07 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:07 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:28:07 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:28:07 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:28:07 --> Final output sent to browser
INFO - 2022-04-21 10:28:12 --> Config Class Initialized
INFO - 2022-04-21 10:28:12 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:12 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:12 --> URI Class Initialized
INFO - 2022-04-21 10:28:12 --> Router Class Initialized
INFO - 2022-04-21 10:28:12 --> Output Class Initialized
INFO - 2022-04-21 10:28:12 --> Security Class Initialized
INFO - 2022-04-21 10:28:12 --> Input Class Initialized
INFO - 2022-04-21 10:28:12 --> Language Class Initialized
INFO - 2022-04-21 10:28:12 --> Loader Class Initialized
INFO - 2022-04-21 10:28:12 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:12 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:12 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:12 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:12 --> Controller Class Initialized
INFO - 2022-04-21 10:28:12 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:12 --> Config Class Initialized
INFO - 2022-04-21 10:28:12 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:12 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:12 --> URI Class Initialized
INFO - 2022-04-21 10:28:12 --> Router Class Initialized
INFO - 2022-04-21 10:28:12 --> Output Class Initialized
INFO - 2022-04-21 10:28:12 --> Security Class Initialized
INFO - 2022-04-21 10:28:12 --> Input Class Initialized
INFO - 2022-04-21 10:28:12 --> Language Class Initialized
INFO - 2022-04-21 10:28:12 --> Loader Class Initialized
INFO - 2022-04-21 10:28:12 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:12 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:12 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:12 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:12 --> Controller Class Initialized
INFO - 2022-04-21 10:28:12 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:12 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:28:12 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:28:12 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:28:12 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:28:12 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:28:12 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:28:12 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:28:12 --> Final output sent to browser
INFO - 2022-04-21 10:28:16 --> Config Class Initialized
INFO - 2022-04-21 10:28:16 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:16 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:16 --> URI Class Initialized
INFO - 2022-04-21 10:28:16 --> Router Class Initialized
INFO - 2022-04-21 10:28:16 --> Output Class Initialized
INFO - 2022-04-21 10:28:16 --> Security Class Initialized
INFO - 2022-04-21 10:28:16 --> Input Class Initialized
INFO - 2022-04-21 10:28:16 --> Language Class Initialized
INFO - 2022-04-21 10:28:16 --> Loader Class Initialized
INFO - 2022-04-21 10:28:16 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:16 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:16 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:16 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:16 --> Controller Class Initialized
INFO - 2022-04-21 10:28:16 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:16 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:28:16 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:28:16 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:28:16 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 10:28:16 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:28:16 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:28:16 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:28:16 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:28:16 --> Final output sent to browser
INFO - 2022-04-21 10:28:22 --> Config Class Initialized
INFO - 2022-04-21 10:28:22 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:22 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:22 --> URI Class Initialized
INFO - 2022-04-21 10:28:22 --> Router Class Initialized
INFO - 2022-04-21 10:28:22 --> Output Class Initialized
INFO - 2022-04-21 10:28:22 --> Security Class Initialized
INFO - 2022-04-21 10:28:22 --> Input Class Initialized
INFO - 2022-04-21 10:28:22 --> Language Class Initialized
INFO - 2022-04-21 10:28:22 --> Loader Class Initialized
INFO - 2022-04-21 10:28:22 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:22 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:22 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:22 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:22 --> Controller Class Initialized
INFO - 2022-04-21 10:28:22 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:22 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:28:22 --> Config Class Initialized
INFO - 2022-04-21 10:28:22 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:22 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:22 --> URI Class Initialized
INFO - 2022-04-21 10:28:22 --> Router Class Initialized
INFO - 2022-04-21 10:28:22 --> Output Class Initialized
INFO - 2022-04-21 10:28:22 --> Security Class Initialized
INFO - 2022-04-21 10:28:22 --> Input Class Initialized
INFO - 2022-04-21 10:28:22 --> Language Class Initialized
INFO - 2022-04-21 10:28:22 --> Loader Class Initialized
INFO - 2022-04-21 10:28:22 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:22 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:22 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:22 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:22 --> Controller Class Initialized
INFO - 2022-04-21 10:28:22 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:22 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:28:22 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:28:22 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:28:22 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 10:28:22 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:28:22 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:28:22 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:28:22 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:28:22 --> Final output sent to browser
INFO - 2022-04-21 10:28:23 --> Config Class Initialized
INFO - 2022-04-21 10:28:23 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:23 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:23 --> URI Class Initialized
INFO - 2022-04-21 10:28:23 --> Router Class Initialized
INFO - 2022-04-21 10:28:23 --> Output Class Initialized
INFO - 2022-04-21 10:28:23 --> Security Class Initialized
INFO - 2022-04-21 10:28:23 --> Input Class Initialized
INFO - 2022-04-21 10:28:23 --> Language Class Initialized
INFO - 2022-04-21 10:28:23 --> Loader Class Initialized
INFO - 2022-04-21 10:28:23 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:23 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:23 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:23 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:23 --> Controller Class Initialized
INFO - 2022-04-21 10:28:23 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:28:23 --> Config Class Initialized
INFO - 2022-04-21 10:28:23 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:23 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:23 --> URI Class Initialized
INFO - 2022-04-21 10:28:23 --> Router Class Initialized
INFO - 2022-04-21 10:28:23 --> Output Class Initialized
INFO - 2022-04-21 10:28:23 --> Security Class Initialized
INFO - 2022-04-21 10:28:23 --> Input Class Initialized
INFO - 2022-04-21 10:28:23 --> Language Class Initialized
INFO - 2022-04-21 10:28:23 --> Loader Class Initialized
INFO - 2022-04-21 10:28:23 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:23 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:23 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:23 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:23 --> Controller Class Initialized
INFO - 2022-04-21 10:28:23 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:28:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:28:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:28:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 10:28:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:28:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:28:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:28:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:28:23 --> Final output sent to browser
INFO - 2022-04-21 10:28:25 --> Config Class Initialized
INFO - 2022-04-21 10:28:25 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:25 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:25 --> URI Class Initialized
INFO - 2022-04-21 10:28:25 --> Router Class Initialized
INFO - 2022-04-21 10:28:25 --> Output Class Initialized
INFO - 2022-04-21 10:28:25 --> Security Class Initialized
INFO - 2022-04-21 10:28:25 --> Input Class Initialized
INFO - 2022-04-21 10:28:25 --> Language Class Initialized
INFO - 2022-04-21 10:28:25 --> Loader Class Initialized
INFO - 2022-04-21 10:28:25 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:25 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:25 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:25 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:25 --> Controller Class Initialized
INFO - 2022-04-21 10:28:25 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:25 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:28:25 --> Config Class Initialized
INFO - 2022-04-21 10:28:25 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:25 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:25 --> URI Class Initialized
INFO - 2022-04-21 10:28:25 --> Router Class Initialized
INFO - 2022-04-21 10:28:25 --> Output Class Initialized
INFO - 2022-04-21 10:28:25 --> Security Class Initialized
INFO - 2022-04-21 10:28:25 --> Input Class Initialized
INFO - 2022-04-21 10:28:25 --> Language Class Initialized
INFO - 2022-04-21 10:28:25 --> Loader Class Initialized
INFO - 2022-04-21 10:28:25 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:25 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:25 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:25 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:25 --> Controller Class Initialized
INFO - 2022-04-21 10:28:25 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:25 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:28:25 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:28:25 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:28:25 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 10:28:25 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:28:25 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:28:25 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:28:25 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:28:25 --> Final output sent to browser
INFO - 2022-04-21 10:28:27 --> Config Class Initialized
INFO - 2022-04-21 10:28:27 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:27 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:27 --> URI Class Initialized
INFO - 2022-04-21 10:28:27 --> Router Class Initialized
INFO - 2022-04-21 10:28:27 --> Output Class Initialized
INFO - 2022-04-21 10:28:27 --> Security Class Initialized
INFO - 2022-04-21 10:28:27 --> Input Class Initialized
INFO - 2022-04-21 10:28:27 --> Language Class Initialized
INFO - 2022-04-21 10:28:27 --> Loader Class Initialized
INFO - 2022-04-21 10:28:27 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:27 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:27 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:27 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:27 --> Controller Class Initialized
INFO - 2022-04-21 10:28:27 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:28:27 --> Config Class Initialized
INFO - 2022-04-21 10:28:27 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:27 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:27 --> URI Class Initialized
INFO - 2022-04-21 10:28:27 --> Router Class Initialized
INFO - 2022-04-21 10:28:27 --> Output Class Initialized
INFO - 2022-04-21 10:28:27 --> Security Class Initialized
INFO - 2022-04-21 10:28:27 --> Input Class Initialized
INFO - 2022-04-21 10:28:27 --> Language Class Initialized
INFO - 2022-04-21 10:28:27 --> Loader Class Initialized
INFO - 2022-04-21 10:28:27 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:27 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:27 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:27 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:27 --> Controller Class Initialized
INFO - 2022-04-21 10:28:27 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:28:27 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:28:27 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:28:27 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 10:28:27 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:28:27 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:28:27 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:28:27 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:28:27 --> Final output sent to browser
INFO - 2022-04-21 10:28:33 --> Config Class Initialized
INFO - 2022-04-21 10:28:33 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:33 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:33 --> URI Class Initialized
INFO - 2022-04-21 10:28:33 --> Router Class Initialized
INFO - 2022-04-21 10:28:33 --> Output Class Initialized
INFO - 2022-04-21 10:28:33 --> Security Class Initialized
INFO - 2022-04-21 10:28:33 --> Input Class Initialized
INFO - 2022-04-21 10:28:33 --> Language Class Initialized
INFO - 2022-04-21 10:28:33 --> Loader Class Initialized
INFO - 2022-04-21 10:28:33 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:33 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:33 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:33 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:33 --> Controller Class Initialized
INFO - 2022-04-21 10:28:33 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:33 --> Config Class Initialized
INFO - 2022-04-21 10:28:33 --> Hooks Class Initialized
INFO - 2022-04-21 10:28:33 --> Utf8 Class Initialized
INFO - 2022-04-21 10:28:33 --> URI Class Initialized
INFO - 2022-04-21 10:28:33 --> Router Class Initialized
INFO - 2022-04-21 10:28:33 --> Output Class Initialized
INFO - 2022-04-21 10:28:33 --> Security Class Initialized
INFO - 2022-04-21 10:28:33 --> Input Class Initialized
INFO - 2022-04-21 10:28:33 --> Language Class Initialized
INFO - 2022-04-21 10:28:33 --> Loader Class Initialized
INFO - 2022-04-21 10:28:33 --> Helper loaded: url_helper
INFO - 2022-04-21 10:28:33 --> Helper loaded: form_helper
INFO - 2022-04-21 10:28:33 --> Database Driver Class Initialized
INFO - 2022-04-21 10:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:28:33 --> Form Validation Class Initialized
INFO - 2022-04-21 10:28:33 --> Controller Class Initialized
INFO - 2022-04-21 10:28:33 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:28:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:28:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:28:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:28:33 --> Final output sent to browser
INFO - 2022-04-21 10:35:46 --> Config Class Initialized
INFO - 2022-04-21 10:35:46 --> Hooks Class Initialized
INFO - 2022-04-21 10:35:46 --> Utf8 Class Initialized
INFO - 2022-04-21 10:35:46 --> URI Class Initialized
INFO - 2022-04-21 10:35:46 --> Router Class Initialized
INFO - 2022-04-21 10:35:46 --> Output Class Initialized
INFO - 2022-04-21 10:35:46 --> Security Class Initialized
INFO - 2022-04-21 10:35:46 --> Input Class Initialized
INFO - 2022-04-21 10:35:46 --> Language Class Initialized
INFO - 2022-04-21 10:35:46 --> Loader Class Initialized
INFO - 2022-04-21 10:35:46 --> Helper loaded: url_helper
INFO - 2022-04-21 10:35:46 --> Helper loaded: form_helper
INFO - 2022-04-21 10:35:46 --> Database Driver Class Initialized
INFO - 2022-04-21 10:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:35:46 --> Form Validation Class Initialized
INFO - 2022-04-21 10:35:46 --> Controller Class Initialized
INFO - 2022-04-21 10:35:46 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:35:46 --> Config Class Initialized
INFO - 2022-04-21 10:35:46 --> Hooks Class Initialized
INFO - 2022-04-21 10:35:46 --> Utf8 Class Initialized
INFO - 2022-04-21 10:35:46 --> URI Class Initialized
INFO - 2022-04-21 10:35:46 --> Router Class Initialized
INFO - 2022-04-21 10:35:46 --> Output Class Initialized
INFO - 2022-04-21 10:35:46 --> Security Class Initialized
INFO - 2022-04-21 10:35:46 --> Input Class Initialized
INFO - 2022-04-21 10:35:46 --> Language Class Initialized
INFO - 2022-04-21 10:35:46 --> Loader Class Initialized
INFO - 2022-04-21 10:35:46 --> Helper loaded: url_helper
INFO - 2022-04-21 10:35:46 --> Helper loaded: form_helper
INFO - 2022-04-21 10:35:46 --> Database Driver Class Initialized
INFO - 2022-04-21 10:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:35:46 --> Form Validation Class Initialized
INFO - 2022-04-21 10:35:46 --> Controller Class Initialized
INFO - 2022-04-21 10:35:46 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:35:46 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:35:46 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:35:46 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:35:46 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:35:46 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:35:46 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:35:46 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:35:46 --> Final output sent to browser
INFO - 2022-04-21 10:35:51 --> Config Class Initialized
INFO - 2022-04-21 10:35:51 --> Hooks Class Initialized
INFO - 2022-04-21 10:35:51 --> Utf8 Class Initialized
INFO - 2022-04-21 10:35:51 --> URI Class Initialized
INFO - 2022-04-21 10:35:51 --> Router Class Initialized
INFO - 2022-04-21 10:35:51 --> Output Class Initialized
INFO - 2022-04-21 10:35:51 --> Security Class Initialized
INFO - 2022-04-21 10:35:51 --> Input Class Initialized
INFO - 2022-04-21 10:35:51 --> Language Class Initialized
INFO - 2022-04-21 10:35:51 --> Loader Class Initialized
INFO - 2022-04-21 10:35:51 --> Helper loaded: url_helper
INFO - 2022-04-21 10:35:51 --> Helper loaded: form_helper
INFO - 2022-04-21 10:35:51 --> Database Driver Class Initialized
INFO - 2022-04-21 10:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:35:51 --> Form Validation Class Initialized
INFO - 2022-04-21 10:35:51 --> Controller Class Initialized
INFO - 2022-04-21 10:35:51 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:35:51 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:35:51 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:35:51 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:35:51 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:35:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:35:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
ERROR - 2022-04-21 10:35:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\lisa-todo\application\views\todo_list\v_index.php 193
ERROR - 2022-04-21 10:35:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\lisa-todo\application\views\todo_list\v_index.php 238
INFO - 2022-04-21 10:35:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 10:35:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:35:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:35:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:35:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:35:51 --> Final output sent to browser
INFO - 2022-04-21 10:35:53 --> Config Class Initialized
INFO - 2022-04-21 10:35:53 --> Hooks Class Initialized
INFO - 2022-04-21 10:35:53 --> Utf8 Class Initialized
INFO - 2022-04-21 10:35:53 --> URI Class Initialized
INFO - 2022-04-21 10:35:53 --> Router Class Initialized
INFO - 2022-04-21 10:35:53 --> Output Class Initialized
INFO - 2022-04-21 10:35:53 --> Security Class Initialized
INFO - 2022-04-21 10:35:53 --> Input Class Initialized
INFO - 2022-04-21 10:35:53 --> Language Class Initialized
INFO - 2022-04-21 10:35:53 --> Loader Class Initialized
INFO - 2022-04-21 10:35:53 --> Helper loaded: url_helper
INFO - 2022-04-21 10:35:53 --> Helper loaded: form_helper
INFO - 2022-04-21 10:35:53 --> Database Driver Class Initialized
INFO - 2022-04-21 10:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:35:53 --> Form Validation Class Initialized
INFO - 2022-04-21 10:35:53 --> Controller Class Initialized
INFO - 2022-04-21 10:35:53 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:35:53 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:35:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:35:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:35:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:35:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:35:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:35:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:35:53 --> Final output sent to browser
INFO - 2022-04-21 10:35:54 --> Config Class Initialized
INFO - 2022-04-21 10:35:54 --> Hooks Class Initialized
INFO - 2022-04-21 10:35:54 --> Utf8 Class Initialized
INFO - 2022-04-21 10:35:54 --> URI Class Initialized
INFO - 2022-04-21 10:35:54 --> Router Class Initialized
INFO - 2022-04-21 10:35:54 --> Output Class Initialized
INFO - 2022-04-21 10:35:54 --> Security Class Initialized
INFO - 2022-04-21 10:35:54 --> Input Class Initialized
INFO - 2022-04-21 10:35:54 --> Language Class Initialized
INFO - 2022-04-21 10:35:54 --> Loader Class Initialized
INFO - 2022-04-21 10:35:54 --> Helper loaded: url_helper
INFO - 2022-04-21 10:35:54 --> Helper loaded: form_helper
INFO - 2022-04-21 10:35:54 --> Database Driver Class Initialized
INFO - 2022-04-21 10:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:35:54 --> Form Validation Class Initialized
INFO - 2022-04-21 10:35:54 --> Controller Class Initialized
INFO - 2022-04-21 10:35:54 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:35:54 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:35:54 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:35:54 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:35:54 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:35:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:35:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:35:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 10:35:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:35:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:35:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:35:54 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:35:54 --> Final output sent to browser
INFO - 2022-04-21 10:35:56 --> Config Class Initialized
INFO - 2022-04-21 10:35:56 --> Hooks Class Initialized
INFO - 2022-04-21 10:35:56 --> Utf8 Class Initialized
INFO - 2022-04-21 10:35:56 --> URI Class Initialized
INFO - 2022-04-21 10:35:56 --> Router Class Initialized
INFO - 2022-04-21 10:35:56 --> Output Class Initialized
INFO - 2022-04-21 10:35:56 --> Security Class Initialized
INFO - 2022-04-21 10:35:56 --> Input Class Initialized
INFO - 2022-04-21 10:35:56 --> Language Class Initialized
INFO - 2022-04-21 10:35:56 --> Loader Class Initialized
INFO - 2022-04-21 10:35:56 --> Helper loaded: url_helper
INFO - 2022-04-21 10:35:56 --> Helper loaded: form_helper
INFO - 2022-04-21 10:35:56 --> Database Driver Class Initialized
INFO - 2022-04-21 10:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:35:56 --> Form Validation Class Initialized
INFO - 2022-04-21 10:35:56 --> Controller Class Initialized
INFO - 2022-04-21 10:35:56 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:35:56 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:35:56 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:35:56 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:35:56 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:35:56 --> Config Class Initialized
INFO - 2022-04-21 10:35:56 --> Hooks Class Initialized
INFO - 2022-04-21 10:35:56 --> Utf8 Class Initialized
INFO - 2022-04-21 10:35:56 --> URI Class Initialized
INFO - 2022-04-21 10:35:56 --> Router Class Initialized
INFO - 2022-04-21 10:35:56 --> Output Class Initialized
INFO - 2022-04-21 10:35:56 --> Security Class Initialized
INFO - 2022-04-21 10:35:56 --> Input Class Initialized
INFO - 2022-04-21 10:35:56 --> Language Class Initialized
INFO - 2022-04-21 10:35:56 --> Loader Class Initialized
INFO - 2022-04-21 10:35:56 --> Helper loaded: url_helper
INFO - 2022-04-21 10:35:56 --> Helper loaded: form_helper
INFO - 2022-04-21 10:35:56 --> Database Driver Class Initialized
INFO - 2022-04-21 10:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:35:56 --> Form Validation Class Initialized
INFO - 2022-04-21 10:35:56 --> Controller Class Initialized
INFO - 2022-04-21 10:35:56 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:35:56 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:35:56 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:35:56 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:35:56 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:35:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:35:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:35:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 10:35:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:35:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:35:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:35:56 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:35:56 --> Final output sent to browser
INFO - 2022-04-21 10:36:05 --> Config Class Initialized
INFO - 2022-04-21 10:36:05 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:05 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:05 --> URI Class Initialized
INFO - 2022-04-21 10:36:05 --> Router Class Initialized
INFO - 2022-04-21 10:36:05 --> Output Class Initialized
INFO - 2022-04-21 10:36:05 --> Security Class Initialized
INFO - 2022-04-21 10:36:05 --> Input Class Initialized
INFO - 2022-04-21 10:36:05 --> Language Class Initialized
INFO - 2022-04-21 10:36:05 --> Loader Class Initialized
INFO - 2022-04-21 10:36:05 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:05 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:05 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:05 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:05 --> Controller Class Initialized
INFO - 2022-04-21 10:36:05 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:36:05 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:36:05 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:36:05 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:36:05 --> Model "M_tutor" initialized
ERROR - 2022-04-21 10:36:05 --> Severity: Notice --> Undefined index: todo C:\xampp\htdocs\lisa-todo\application\models\M_todo_list.php 36
INFO - 2022-04-21 10:36:05 --> Config Class Initialized
INFO - 2022-04-21 10:36:05 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:05 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:05 --> URI Class Initialized
INFO - 2022-04-21 10:36:05 --> Router Class Initialized
INFO - 2022-04-21 10:36:05 --> Output Class Initialized
INFO - 2022-04-21 10:36:05 --> Security Class Initialized
INFO - 2022-04-21 10:36:05 --> Input Class Initialized
INFO - 2022-04-21 10:36:05 --> Language Class Initialized
INFO - 2022-04-21 10:36:05 --> Loader Class Initialized
INFO - 2022-04-21 10:36:05 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:05 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:05 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:05 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:05 --> Controller Class Initialized
INFO - 2022-04-21 10:36:05 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:36:05 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:36:05 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:36:05 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:36:05 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:36:05 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:36:05 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:36:05 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 10:36:05 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:36:05 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:36:05 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:36:05 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:36:05 --> Final output sent to browser
INFO - 2022-04-21 10:36:10 --> Config Class Initialized
INFO - 2022-04-21 10:36:10 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:10 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:10 --> URI Class Initialized
INFO - 2022-04-21 10:36:10 --> Router Class Initialized
INFO - 2022-04-21 10:36:10 --> Output Class Initialized
INFO - 2022-04-21 10:36:10 --> Security Class Initialized
INFO - 2022-04-21 10:36:10 --> Input Class Initialized
INFO - 2022-04-21 10:36:10 --> Language Class Initialized
INFO - 2022-04-21 10:36:10 --> Loader Class Initialized
INFO - 2022-04-21 10:36:10 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:10 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:10 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:10 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:10 --> Controller Class Initialized
INFO - 2022-04-21 10:36:10 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:36:10 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:36:10 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:36:10 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:36:10 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:36:10 --> Config Class Initialized
INFO - 2022-04-21 10:36:10 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:10 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:10 --> URI Class Initialized
INFO - 2022-04-21 10:36:10 --> Router Class Initialized
INFO - 2022-04-21 10:36:10 --> Output Class Initialized
INFO - 2022-04-21 10:36:10 --> Security Class Initialized
INFO - 2022-04-21 10:36:10 --> Input Class Initialized
INFO - 2022-04-21 10:36:10 --> Language Class Initialized
INFO - 2022-04-21 10:36:10 --> Loader Class Initialized
INFO - 2022-04-21 10:36:10 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:10 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:10 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:10 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:10 --> Controller Class Initialized
INFO - 2022-04-21 10:36:10 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:36:10 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:36:10 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:36:10 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:36:10 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:36:10 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:36:10 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:36:10 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 10:36:10 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:36:10 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:36:10 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:36:10 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:36:10 --> Final output sent to browser
INFO - 2022-04-21 10:36:19 --> Config Class Initialized
INFO - 2022-04-21 10:36:19 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:19 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:19 --> URI Class Initialized
INFO - 2022-04-21 10:36:19 --> Router Class Initialized
INFO - 2022-04-21 10:36:19 --> Output Class Initialized
INFO - 2022-04-21 10:36:19 --> Security Class Initialized
INFO - 2022-04-21 10:36:19 --> Input Class Initialized
INFO - 2022-04-21 10:36:19 --> Language Class Initialized
INFO - 2022-04-21 10:36:19 --> Loader Class Initialized
INFO - 2022-04-21 10:36:19 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:19 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:19 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:19 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:19 --> Controller Class Initialized
INFO - 2022-04-21 10:36:19 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:36:19 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:36:19 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:36:19 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:36:19 --> Model "M_tutor" initialized
ERROR - 2022-04-21 10:36:19 --> Severity: Notice --> Undefined index: todo C:\xampp\htdocs\lisa-todo\application\models\M_todo_list.php 36
INFO - 2022-04-21 10:36:19 --> Config Class Initialized
INFO - 2022-04-21 10:36:19 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:19 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:19 --> URI Class Initialized
INFO - 2022-04-21 10:36:19 --> Router Class Initialized
INFO - 2022-04-21 10:36:19 --> Output Class Initialized
INFO - 2022-04-21 10:36:19 --> Security Class Initialized
INFO - 2022-04-21 10:36:19 --> Input Class Initialized
INFO - 2022-04-21 10:36:19 --> Language Class Initialized
INFO - 2022-04-21 10:36:19 --> Loader Class Initialized
INFO - 2022-04-21 10:36:19 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:19 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:19 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:19 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:19 --> Controller Class Initialized
INFO - 2022-04-21 10:36:19 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:36:19 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:36:19 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:36:19 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:36:19 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:36:19 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:36:19 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:36:19 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 10:36:19 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:36:19 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:36:19 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:36:19 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:36:19 --> Final output sent to browser
INFO - 2022-04-21 10:36:23 --> Config Class Initialized
INFO - 2022-04-21 10:36:23 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:23 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:23 --> URI Class Initialized
INFO - 2022-04-21 10:36:23 --> Router Class Initialized
INFO - 2022-04-21 10:36:23 --> Output Class Initialized
INFO - 2022-04-21 10:36:23 --> Security Class Initialized
INFO - 2022-04-21 10:36:23 --> Input Class Initialized
INFO - 2022-04-21 10:36:23 --> Language Class Initialized
INFO - 2022-04-21 10:36:23 --> Loader Class Initialized
INFO - 2022-04-21 10:36:23 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:23 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:23 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:23 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:23 --> Controller Class Initialized
INFO - 2022-04-21 10:36:23 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:36:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:36:23 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:36:23 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:36:23 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:36:23 --> Config Class Initialized
INFO - 2022-04-21 10:36:23 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:23 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:23 --> URI Class Initialized
INFO - 2022-04-21 10:36:23 --> Router Class Initialized
INFO - 2022-04-21 10:36:23 --> Output Class Initialized
INFO - 2022-04-21 10:36:23 --> Security Class Initialized
INFO - 2022-04-21 10:36:23 --> Input Class Initialized
INFO - 2022-04-21 10:36:23 --> Language Class Initialized
INFO - 2022-04-21 10:36:23 --> Loader Class Initialized
INFO - 2022-04-21 10:36:23 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:23 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:23 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:23 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:23 --> Controller Class Initialized
INFO - 2022-04-21 10:36:23 --> Model "M_todo_list" initialized
INFO - 2022-04-21 10:36:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:36:23 --> Model "M_todo_group" initialized
INFO - 2022-04-21 10:36:23 --> Model "M_todo_task" initialized
INFO - 2022-04-21 10:36:23 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:36:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:36:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:36:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 10:36:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:36:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:36:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:36:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:36:23 --> Final output sent to browser
INFO - 2022-04-21 10:36:29 --> Config Class Initialized
INFO - 2022-04-21 10:36:29 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:29 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:29 --> URI Class Initialized
INFO - 2022-04-21 10:36:29 --> Router Class Initialized
INFO - 2022-04-21 10:36:29 --> Output Class Initialized
INFO - 2022-04-21 10:36:29 --> Security Class Initialized
INFO - 2022-04-21 10:36:29 --> Input Class Initialized
INFO - 2022-04-21 10:36:29 --> Language Class Initialized
INFO - 2022-04-21 10:36:29 --> Loader Class Initialized
INFO - 2022-04-21 10:36:29 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:29 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:29 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:29 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:29 --> Controller Class Initialized
INFO - 2022-04-21 10:36:29 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:36:29 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:36:29 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:36:29 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:36:29 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_ubah.php
INFO - 2022-04-21 10:36:29 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:36:29 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:36:29 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:36:29 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 10:36:29 --> Final output sent to browser
INFO - 2022-04-21 10:36:38 --> Config Class Initialized
INFO - 2022-04-21 10:36:38 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:38 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:38 --> URI Class Initialized
INFO - 2022-04-21 10:36:38 --> Router Class Initialized
INFO - 2022-04-21 10:36:38 --> Output Class Initialized
INFO - 2022-04-21 10:36:38 --> Security Class Initialized
INFO - 2022-04-21 10:36:38 --> Input Class Initialized
INFO - 2022-04-21 10:36:38 --> Language Class Initialized
INFO - 2022-04-21 10:36:38 --> Loader Class Initialized
INFO - 2022-04-21 10:36:38 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:38 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:38 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:38 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:38 --> Controller Class Initialized
INFO - 2022-04-21 10:36:38 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:36:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:36:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:36:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:36:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:36:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:36:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:36:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:36:38 --> Final output sent to browser
INFO - 2022-04-21 10:36:43 --> Config Class Initialized
INFO - 2022-04-21 10:36:43 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:43 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:43 --> URI Class Initialized
INFO - 2022-04-21 10:36:43 --> Router Class Initialized
INFO - 2022-04-21 10:36:43 --> Output Class Initialized
INFO - 2022-04-21 10:36:43 --> Security Class Initialized
INFO - 2022-04-21 10:36:43 --> Input Class Initialized
INFO - 2022-04-21 10:36:43 --> Language Class Initialized
INFO - 2022-04-21 10:36:43 --> Loader Class Initialized
INFO - 2022-04-21 10:36:43 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:43 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:43 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:43 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:43 --> Controller Class Initialized
INFO - 2022-04-21 10:36:43 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:36:43 --> Config Class Initialized
INFO - 2022-04-21 10:36:43 --> Hooks Class Initialized
INFO - 2022-04-21 10:36:43 --> Utf8 Class Initialized
INFO - 2022-04-21 10:36:43 --> URI Class Initialized
INFO - 2022-04-21 10:36:43 --> Router Class Initialized
INFO - 2022-04-21 10:36:43 --> Output Class Initialized
INFO - 2022-04-21 10:36:43 --> Security Class Initialized
INFO - 2022-04-21 10:36:43 --> Input Class Initialized
INFO - 2022-04-21 10:36:43 --> Language Class Initialized
INFO - 2022-04-21 10:36:43 --> Loader Class Initialized
INFO - 2022-04-21 10:36:43 --> Helper loaded: url_helper
INFO - 2022-04-21 10:36:43 --> Helper loaded: form_helper
INFO - 2022-04-21 10:36:43 --> Database Driver Class Initialized
INFO - 2022-04-21 10:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:36:43 --> Form Validation Class Initialized
INFO - 2022-04-21 10:36:43 --> Controller Class Initialized
INFO - 2022-04-21 10:36:43 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:36:43 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:36:43 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:36:43 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:36:43 --> Final output sent to browser
INFO - 2022-04-21 10:41:33 --> Config Class Initialized
INFO - 2022-04-21 10:41:33 --> Hooks Class Initialized
INFO - 2022-04-21 10:41:33 --> Utf8 Class Initialized
INFO - 2022-04-21 10:41:33 --> URI Class Initialized
INFO - 2022-04-21 10:41:33 --> Router Class Initialized
INFO - 2022-04-21 10:41:33 --> Output Class Initialized
INFO - 2022-04-21 10:41:33 --> Security Class Initialized
INFO - 2022-04-21 10:41:33 --> Input Class Initialized
INFO - 2022-04-21 10:41:33 --> Language Class Initialized
INFO - 2022-04-21 10:41:33 --> Loader Class Initialized
INFO - 2022-04-21 10:41:33 --> Helper loaded: url_helper
INFO - 2022-04-21 10:41:33 --> Helper loaded: form_helper
INFO - 2022-04-21 10:41:33 --> Database Driver Class Initialized
INFO - 2022-04-21 10:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:41:33 --> Form Validation Class Initialized
INFO - 2022-04-21 10:41:33 --> Controller Class Initialized
INFO - 2022-04-21 10:41:33 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:41:33 --> Config Class Initialized
INFO - 2022-04-21 10:41:33 --> Hooks Class Initialized
INFO - 2022-04-21 10:41:33 --> Utf8 Class Initialized
INFO - 2022-04-21 10:41:33 --> URI Class Initialized
INFO - 2022-04-21 10:41:33 --> Router Class Initialized
INFO - 2022-04-21 10:41:33 --> Output Class Initialized
INFO - 2022-04-21 10:41:33 --> Security Class Initialized
INFO - 2022-04-21 10:41:33 --> Input Class Initialized
INFO - 2022-04-21 10:41:33 --> Language Class Initialized
INFO - 2022-04-21 10:41:33 --> Loader Class Initialized
INFO - 2022-04-21 10:41:33 --> Helper loaded: url_helper
INFO - 2022-04-21 10:41:33 --> Helper loaded: form_helper
INFO - 2022-04-21 10:41:33 --> Database Driver Class Initialized
INFO - 2022-04-21 10:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:41:33 --> Form Validation Class Initialized
INFO - 2022-04-21 10:41:33 --> Controller Class Initialized
INFO - 2022-04-21 10:41:33 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:41:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:41:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:41:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:41:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:41:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:41:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:41:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:41:33 --> Final output sent to browser
INFO - 2022-04-21 10:41:35 --> Config Class Initialized
INFO - 2022-04-21 10:41:35 --> Hooks Class Initialized
INFO - 2022-04-21 10:41:35 --> Utf8 Class Initialized
INFO - 2022-04-21 10:41:35 --> URI Class Initialized
INFO - 2022-04-21 10:41:35 --> Router Class Initialized
INFO - 2022-04-21 10:41:35 --> Output Class Initialized
INFO - 2022-04-21 10:41:35 --> Security Class Initialized
INFO - 2022-04-21 10:41:35 --> Input Class Initialized
INFO - 2022-04-21 10:41:35 --> Language Class Initialized
INFO - 2022-04-21 10:41:35 --> Loader Class Initialized
INFO - 2022-04-21 10:41:35 --> Helper loaded: url_helper
INFO - 2022-04-21 10:41:35 --> Helper loaded: form_helper
INFO - 2022-04-21 10:41:35 --> Database Driver Class Initialized
INFO - 2022-04-21 10:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:41:35 --> Form Validation Class Initialized
INFO - 2022-04-21 10:41:35 --> Controller Class Initialized
INFO - 2022-04-21 10:41:35 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:41:35 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:41:35 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:41:35 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:41:35 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:41:35 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:41:35 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:41:35 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:41:35 --> Final output sent to browser
INFO - 2022-04-21 10:41:42 --> Config Class Initialized
INFO - 2022-04-21 10:41:42 --> Hooks Class Initialized
INFO - 2022-04-21 10:41:42 --> Utf8 Class Initialized
INFO - 2022-04-21 10:41:42 --> URI Class Initialized
INFO - 2022-04-21 10:41:42 --> Router Class Initialized
INFO - 2022-04-21 10:41:42 --> Output Class Initialized
INFO - 2022-04-21 10:41:42 --> Security Class Initialized
INFO - 2022-04-21 10:41:42 --> Input Class Initialized
INFO - 2022-04-21 10:41:42 --> Language Class Initialized
INFO - 2022-04-21 10:41:42 --> Loader Class Initialized
INFO - 2022-04-21 10:41:42 --> Helper loaded: url_helper
INFO - 2022-04-21 10:41:42 --> Helper loaded: form_helper
INFO - 2022-04-21 10:41:42 --> Database Driver Class Initialized
INFO - 2022-04-21 10:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:41:42 --> Form Validation Class Initialized
INFO - 2022-04-21 10:41:42 --> Controller Class Initialized
INFO - 2022-04-21 10:41:42 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:41:42 --> Config Class Initialized
INFO - 2022-04-21 10:41:42 --> Hooks Class Initialized
INFO - 2022-04-21 10:41:42 --> Utf8 Class Initialized
INFO - 2022-04-21 10:41:42 --> URI Class Initialized
INFO - 2022-04-21 10:41:42 --> Router Class Initialized
INFO - 2022-04-21 10:41:42 --> Output Class Initialized
INFO - 2022-04-21 10:41:42 --> Security Class Initialized
INFO - 2022-04-21 10:41:42 --> Input Class Initialized
INFO - 2022-04-21 10:41:42 --> Language Class Initialized
INFO - 2022-04-21 10:41:42 --> Loader Class Initialized
INFO - 2022-04-21 10:41:42 --> Helper loaded: url_helper
INFO - 2022-04-21 10:41:42 --> Helper loaded: form_helper
INFO - 2022-04-21 10:41:42 --> Database Driver Class Initialized
INFO - 2022-04-21 10:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:41:42 --> Form Validation Class Initialized
INFO - 2022-04-21 10:41:42 --> Controller Class Initialized
INFO - 2022-04-21 10:41:42 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:41:42 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2022-04-21 10:41:42 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2022-04-21 10:41:42 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2022-04-21 10:41:42 --> Final output sent to browser
INFO - 2022-04-21 10:41:45 --> Config Class Initialized
INFO - 2022-04-21 10:41:45 --> Hooks Class Initialized
INFO - 2022-04-21 10:41:45 --> Utf8 Class Initialized
INFO - 2022-04-21 10:41:45 --> URI Class Initialized
INFO - 2022-04-21 10:41:45 --> Router Class Initialized
INFO - 2022-04-21 10:41:45 --> Output Class Initialized
INFO - 2022-04-21 10:41:45 --> Security Class Initialized
INFO - 2022-04-21 10:41:45 --> Input Class Initialized
INFO - 2022-04-21 10:41:45 --> Language Class Initialized
INFO - 2022-04-21 10:41:45 --> Loader Class Initialized
INFO - 2022-04-21 10:41:45 --> Helper loaded: url_helper
INFO - 2022-04-21 10:41:45 --> Helper loaded: form_helper
INFO - 2022-04-21 10:41:45 --> Database Driver Class Initialized
INFO - 2022-04-21 10:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:41:45 --> Form Validation Class Initialized
INFO - 2022-04-21 10:41:45 --> Controller Class Initialized
INFO - 2022-04-21 10:41:45 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:41:45 --> Config Class Initialized
INFO - 2022-04-21 10:41:45 --> Hooks Class Initialized
INFO - 2022-04-21 10:41:45 --> Utf8 Class Initialized
INFO - 2022-04-21 10:41:45 --> URI Class Initialized
INFO - 2022-04-21 10:41:45 --> Router Class Initialized
INFO - 2022-04-21 10:41:45 --> Output Class Initialized
INFO - 2022-04-21 10:41:45 --> Security Class Initialized
INFO - 2022-04-21 10:41:45 --> Input Class Initialized
INFO - 2022-04-21 10:41:45 --> Language Class Initialized
INFO - 2022-04-21 10:41:45 --> Loader Class Initialized
INFO - 2022-04-21 10:41:45 --> Helper loaded: url_helper
INFO - 2022-04-21 10:41:45 --> Helper loaded: form_helper
INFO - 2022-04-21 10:41:45 --> Database Driver Class Initialized
INFO - 2022-04-21 10:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 10:41:45 --> Form Validation Class Initialized
INFO - 2022-04-21 10:41:45 --> Controller Class Initialized
INFO - 2022-04-21 10:41:45 --> Model "M_tutor" initialized
INFO - 2022-04-21 10:41:45 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 10:41:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 10:41:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 10:41:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 10:41:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 10:41:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 10:41:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 10:41:45 --> Final output sent to browser
INFO - 2022-04-21 11:04:39 --> Config Class Initialized
INFO - 2022-04-21 11:04:39 --> Hooks Class Initialized
INFO - 2022-04-21 11:04:39 --> Utf8 Class Initialized
INFO - 2022-04-21 11:04:39 --> URI Class Initialized
INFO - 2022-04-21 11:04:39 --> Router Class Initialized
INFO - 2022-04-21 11:04:39 --> Output Class Initialized
INFO - 2022-04-21 11:04:39 --> Security Class Initialized
INFO - 2022-04-21 11:04:39 --> Input Class Initialized
INFO - 2022-04-21 11:04:39 --> Language Class Initialized
INFO - 2022-04-21 11:04:39 --> Loader Class Initialized
INFO - 2022-04-21 11:04:39 --> Helper loaded: url_helper
INFO - 2022-04-21 11:04:39 --> Helper loaded: form_helper
INFO - 2022-04-21 11:04:39 --> Database Driver Class Initialized
INFO - 2022-04-21 11:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:04:39 --> Form Validation Class Initialized
INFO - 2022-04-21 11:04:39 --> Controller Class Initialized
INFO - 2022-04-21 11:04:39 --> Model "M_todo_list" initialized
INFO - 2022-04-21 11:04:39 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:04:39 --> Model "M_todo_group" initialized
INFO - 2022-04-21 11:04:39 --> Model "M_todo_task" initialized
INFO - 2022-04-21 11:04:39 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:04:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:04:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:04:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 11:04:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:04:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:04:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:04:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:04:39 --> Final output sent to browser
INFO - 2022-04-21 11:04:44 --> Config Class Initialized
INFO - 2022-04-21 11:04:44 --> Hooks Class Initialized
INFO - 2022-04-21 11:04:44 --> Utf8 Class Initialized
INFO - 2022-04-21 11:04:44 --> URI Class Initialized
INFO - 2022-04-21 11:04:44 --> Router Class Initialized
INFO - 2022-04-21 11:04:44 --> Output Class Initialized
INFO - 2022-04-21 11:04:44 --> Security Class Initialized
INFO - 2022-04-21 11:04:44 --> Input Class Initialized
INFO - 2022-04-21 11:04:44 --> Language Class Initialized
INFO - 2022-04-21 11:04:44 --> Loader Class Initialized
INFO - 2022-04-21 11:04:44 --> Helper loaded: url_helper
INFO - 2022-04-21 11:04:44 --> Helper loaded: form_helper
INFO - 2022-04-21 11:04:44 --> Database Driver Class Initialized
INFO - 2022-04-21 11:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:04:44 --> Form Validation Class Initialized
INFO - 2022-04-21 11:04:44 --> Controller Class Initialized
INFO - 2022-04-21 11:04:44 --> Model "M_todo_list" initialized
INFO - 2022-04-21 11:04:44 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:04:44 --> Model "M_todo_group" initialized
INFO - 2022-04-21 11:04:44 --> Model "M_todo_task" initialized
INFO - 2022-04-21 11:04:44 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:04:44 --> Config Class Initialized
INFO - 2022-04-21 11:04:44 --> Hooks Class Initialized
INFO - 2022-04-21 11:04:44 --> Utf8 Class Initialized
INFO - 2022-04-21 11:04:44 --> URI Class Initialized
INFO - 2022-04-21 11:04:44 --> Router Class Initialized
INFO - 2022-04-21 11:04:44 --> Output Class Initialized
INFO - 2022-04-21 11:04:44 --> Security Class Initialized
INFO - 2022-04-21 11:04:44 --> Input Class Initialized
INFO - 2022-04-21 11:04:44 --> Language Class Initialized
INFO - 2022-04-21 11:04:44 --> Loader Class Initialized
INFO - 2022-04-21 11:04:44 --> Helper loaded: url_helper
INFO - 2022-04-21 11:04:44 --> Helper loaded: form_helper
INFO - 2022-04-21 11:04:44 --> Database Driver Class Initialized
INFO - 2022-04-21 11:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:04:44 --> Form Validation Class Initialized
INFO - 2022-04-21 11:04:44 --> Controller Class Initialized
INFO - 2022-04-21 11:04:44 --> Model "M_todo_list" initialized
INFO - 2022-04-21 11:04:44 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:04:44 --> Model "M_todo_group" initialized
INFO - 2022-04-21 11:04:44 --> Model "M_todo_task" initialized
INFO - 2022-04-21 11:04:44 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:04:44 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:04:44 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:04:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 11:04:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:04:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:04:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:04:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:04:45 --> Final output sent to browser
INFO - 2022-04-21 11:04:58 --> Config Class Initialized
INFO - 2022-04-21 11:04:58 --> Hooks Class Initialized
INFO - 2022-04-21 11:04:58 --> Utf8 Class Initialized
INFO - 2022-04-21 11:04:58 --> URI Class Initialized
INFO - 2022-04-21 11:04:58 --> Router Class Initialized
INFO - 2022-04-21 11:04:58 --> Output Class Initialized
INFO - 2022-04-21 11:04:59 --> Security Class Initialized
INFO - 2022-04-21 11:04:59 --> Input Class Initialized
INFO - 2022-04-21 11:04:59 --> Language Class Initialized
INFO - 2022-04-21 11:04:59 --> Loader Class Initialized
INFO - 2022-04-21 11:04:59 --> Helper loaded: url_helper
INFO - 2022-04-21 11:04:59 --> Helper loaded: form_helper
INFO - 2022-04-21 11:04:59 --> Database Driver Class Initialized
INFO - 2022-04-21 11:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:04:59 --> Form Validation Class Initialized
INFO - 2022-04-21 11:04:59 --> Controller Class Initialized
INFO - 2022-04-21 11:04:59 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:04:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:04:59 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:04:59 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:04:59 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 11:04:59 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:04:59 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:04:59 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:04:59 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:04:59 --> Final output sent to browser
INFO - 2022-04-21 11:05:00 --> Config Class Initialized
INFO - 2022-04-21 11:05:00 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:00 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:00 --> URI Class Initialized
INFO - 2022-04-21 11:05:00 --> Router Class Initialized
INFO - 2022-04-21 11:05:00 --> Output Class Initialized
INFO - 2022-04-21 11:05:00 --> Security Class Initialized
INFO - 2022-04-21 11:05:00 --> Input Class Initialized
INFO - 2022-04-21 11:05:00 --> Language Class Initialized
INFO - 2022-04-21 11:05:00 --> Loader Class Initialized
INFO - 2022-04-21 11:05:00 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:00 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:00 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:00 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:00 --> Controller Class Initialized
INFO - 2022-04-21 11:05:00 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_admin/v_index.php
INFO - 2022-04-21 11:05:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:00 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:00 --> Final output sent to browser
INFO - 2022-04-21 11:05:01 --> Config Class Initialized
INFO - 2022-04-21 11:05:01 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:01 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:01 --> URI Class Initialized
INFO - 2022-04-21 11:05:01 --> Router Class Initialized
INFO - 2022-04-21 11:05:01 --> Output Class Initialized
INFO - 2022-04-21 11:05:01 --> Security Class Initialized
INFO - 2022-04-21 11:05:01 --> Input Class Initialized
INFO - 2022-04-21 11:05:01 --> Language Class Initialized
INFO - 2022-04-21 11:05:01 --> Loader Class Initialized
INFO - 2022-04-21 11:05:01 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:01 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:01 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:01 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:01 --> Controller Class Initialized
INFO - 2022-04-21 11:05:01 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:01 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:05:01 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:01 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:01 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 11:05:01 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:01 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:01 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:01 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:01 --> Final output sent to browser
INFO - 2022-04-21 11:05:02 --> Config Class Initialized
INFO - 2022-04-21 11:05:02 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:02 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:02 --> URI Class Initialized
INFO - 2022-04-21 11:05:02 --> Router Class Initialized
INFO - 2022-04-21 11:05:02 --> Output Class Initialized
INFO - 2022-04-21 11:05:02 --> Security Class Initialized
INFO - 2022-04-21 11:05:02 --> Input Class Initialized
INFO - 2022-04-21 11:05:02 --> Language Class Initialized
INFO - 2022-04-21 11:05:02 --> Loader Class Initialized
INFO - 2022-04-21 11:05:02 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:02 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:02 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:02 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:02 --> Controller Class Initialized
INFO - 2022-04-21 11:05:02 --> Model "M_todo_group" initialized
INFO - 2022-04-21 11:05:02 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:05:02 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:02 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:02 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:02 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_group/v_index.php
INFO - 2022-04-21 11:05:02 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:02 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:02 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:02 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:02 --> Final output sent to browser
INFO - 2022-04-21 11:05:04 --> Config Class Initialized
INFO - 2022-04-21 11:05:04 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:04 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:04 --> URI Class Initialized
INFO - 2022-04-21 11:05:04 --> Router Class Initialized
INFO - 2022-04-21 11:05:04 --> Output Class Initialized
INFO - 2022-04-21 11:05:04 --> Security Class Initialized
INFO - 2022-04-21 11:05:04 --> Input Class Initialized
INFO - 2022-04-21 11:05:04 --> Language Class Initialized
INFO - 2022-04-21 11:05:04 --> Loader Class Initialized
INFO - 2022-04-21 11:05:04 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:04 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:04 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:04 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:04 --> Controller Class Initialized
INFO - 2022-04-21 11:05:04 --> Model "M_todo_list" initialized
INFO - 2022-04-21 11:05:04 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:05:04 --> Model "M_todo_group" initialized
INFO - 2022-04-21 11:05:04 --> Model "M_todo_task" initialized
INFO - 2022-04-21 11:05:04 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:04 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:04 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:04 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 11:05:04 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:04 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:04 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:04 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:04 --> Final output sent to browser
INFO - 2022-04-21 11:05:23 --> Config Class Initialized
INFO - 2022-04-21 11:05:23 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:23 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:23 --> URI Class Initialized
INFO - 2022-04-21 11:05:23 --> Router Class Initialized
INFO - 2022-04-21 11:05:23 --> Output Class Initialized
INFO - 2022-04-21 11:05:23 --> Security Class Initialized
INFO - 2022-04-21 11:05:23 --> Input Class Initialized
INFO - 2022-04-21 11:05:23 --> Language Class Initialized
INFO - 2022-04-21 11:05:23 --> Loader Class Initialized
INFO - 2022-04-21 11:05:23 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:23 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:23 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:23 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:23 --> Controller Class Initialized
INFO - 2022-04-21 11:05:23 --> Model "M_todo_group" initialized
INFO - 2022-04-21 11:05:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:05:23 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-04-21 11:05:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:23 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:23 --> Final output sent to browser
INFO - 2022-04-21 11:05:31 --> Config Class Initialized
INFO - 2022-04-21 11:05:31 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:31 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:31 --> URI Class Initialized
INFO - 2022-04-21 11:05:31 --> Router Class Initialized
INFO - 2022-04-21 11:05:31 --> Output Class Initialized
INFO - 2022-04-21 11:05:31 --> Security Class Initialized
INFO - 2022-04-21 11:05:31 --> Input Class Initialized
INFO - 2022-04-21 11:05:31 --> Language Class Initialized
INFO - 2022-04-21 11:05:31 --> Loader Class Initialized
INFO - 2022-04-21 11:05:31 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:31 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:31 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:32 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:32 --> Controller Class Initialized
INFO - 2022-04-21 11:05:32 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:32 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:05:32 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:32 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:32 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:32 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:32 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:32 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\home.php
INFO - 2022-04-21 11:05:32 --> Final output sent to browser
INFO - 2022-04-21 11:05:33 --> Config Class Initialized
INFO - 2022-04-21 11:05:33 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:33 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:33 --> URI Class Initialized
INFO - 2022-04-21 11:05:33 --> Router Class Initialized
INFO - 2022-04-21 11:05:33 --> Output Class Initialized
INFO - 2022-04-21 11:05:33 --> Security Class Initialized
INFO - 2022-04-21 11:05:33 --> Input Class Initialized
INFO - 2022-04-21 11:05:33 --> Language Class Initialized
INFO - 2022-04-21 11:05:33 --> Loader Class Initialized
INFO - 2022-04-21 11:05:33 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:33 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:33 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:33 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:33 --> Controller Class Initialized
INFO - 2022-04-21 11:05:33 --> Model "M_todo_list" initialized
INFO - 2022-04-21 11:05:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:05:33 --> Model "M_todo_group" initialized
INFO - 2022-04-21 11:05:33 --> Model "M_todo_task" initialized
INFO - 2022-04-21 11:05:33 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_list/v_index.php
INFO - 2022-04-21 11:05:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:33 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:33 --> Final output sent to browser
INFO - 2022-04-21 11:05:36 --> Config Class Initialized
INFO - 2022-04-21 11:05:36 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:36 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:36 --> URI Class Initialized
INFO - 2022-04-21 11:05:36 --> Router Class Initialized
INFO - 2022-04-21 11:05:36 --> Output Class Initialized
INFO - 2022-04-21 11:05:36 --> Security Class Initialized
INFO - 2022-04-21 11:05:36 --> Input Class Initialized
INFO - 2022-04-21 11:05:36 --> Language Class Initialized
INFO - 2022-04-21 11:05:36 --> Loader Class Initialized
INFO - 2022-04-21 11:05:36 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:36 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:36 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:36 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:36 --> Controller Class Initialized
INFO - 2022-04-21 11:05:36 --> Model "M_todo_group" initialized
INFO - 2022-04-21 11:05:36 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:05:36 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:36 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:36 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:36 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_group/v_index.php
INFO - 2022-04-21 11:05:36 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:36 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:36 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:36 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:36 --> Final output sent to browser
INFO - 2022-04-21 11:05:38 --> Config Class Initialized
INFO - 2022-04-21 11:05:38 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:38 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:38 --> URI Class Initialized
INFO - 2022-04-21 11:05:38 --> Router Class Initialized
INFO - 2022-04-21 11:05:38 --> Output Class Initialized
INFO - 2022-04-21 11:05:38 --> Security Class Initialized
INFO - 2022-04-21 11:05:38 --> Input Class Initialized
INFO - 2022-04-21 11:05:38 --> Language Class Initialized
INFO - 2022-04-21 11:05:38 --> Loader Class Initialized
INFO - 2022-04-21 11:05:38 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:38 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:38 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:38 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:38 --> Controller Class Initialized
INFO - 2022-04-21 11:05:38 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:05:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 11:05:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:38 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:38 --> Final output sent to browser
INFO - 2022-04-21 11:05:39 --> Config Class Initialized
INFO - 2022-04-21 11:05:39 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:39 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:39 --> URI Class Initialized
INFO - 2022-04-21 11:05:39 --> Router Class Initialized
INFO - 2022-04-21 11:05:39 --> Output Class Initialized
INFO - 2022-04-21 11:05:39 --> Security Class Initialized
INFO - 2022-04-21 11:05:39 --> Input Class Initialized
INFO - 2022-04-21 11:05:39 --> Language Class Initialized
INFO - 2022-04-21 11:05:39 --> Loader Class Initialized
INFO - 2022-04-21 11:05:39 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:39 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:39 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:39 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:39 --> Controller Class Initialized
INFO - 2022-04-21 11:05:39 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_admin/v_index.php
INFO - 2022-04-21 11:05:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:39 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:39 --> Final output sent to browser
INFO - 2022-04-21 11:05:44 --> Config Class Initialized
INFO - 2022-04-21 11:05:44 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:44 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:44 --> URI Class Initialized
INFO - 2022-04-21 11:05:44 --> Router Class Initialized
INFO - 2022-04-21 11:05:44 --> Output Class Initialized
INFO - 2022-04-21 11:05:44 --> Security Class Initialized
INFO - 2022-04-21 11:05:44 --> Input Class Initialized
INFO - 2022-04-21 11:05:44 --> Language Class Initialized
INFO - 2022-04-21 11:05:44 --> Loader Class Initialized
INFO - 2022-04-21 11:05:44 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:44 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:44 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:44 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:44 --> Controller Class Initialized
INFO - 2022-04-21 11:05:44 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:44 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:44 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:44 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_admin/v_index.php
INFO - 2022-04-21 11:05:44 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:44 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:44 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:44 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:44 --> Final output sent to browser
INFO - 2022-04-21 11:05:45 --> Config Class Initialized
INFO - 2022-04-21 11:05:45 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:45 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:45 --> URI Class Initialized
INFO - 2022-04-21 11:05:45 --> Router Class Initialized
INFO - 2022-04-21 11:05:45 --> Output Class Initialized
INFO - 2022-04-21 11:05:45 --> Security Class Initialized
INFO - 2022-04-21 11:05:45 --> Input Class Initialized
INFO - 2022-04-21 11:05:45 --> Language Class Initialized
INFO - 2022-04-21 11:05:45 --> Loader Class Initialized
INFO - 2022-04-21 11:05:45 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:45 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:45 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:45 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:45 --> Controller Class Initialized
INFO - 2022-04-21 11:05:45 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_admin/v_index.php
INFO - 2022-04-21 11:05:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:45 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:45 --> Final output sent to browser
INFO - 2022-04-21 11:05:49 --> Config Class Initialized
INFO - 2022-04-21 11:05:49 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:49 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:49 --> URI Class Initialized
INFO - 2022-04-21 11:05:49 --> Router Class Initialized
INFO - 2022-04-21 11:05:49 --> Output Class Initialized
INFO - 2022-04-21 11:05:49 --> Security Class Initialized
INFO - 2022-04-21 11:05:49 --> Input Class Initialized
INFO - 2022-04-21 11:05:49 --> Language Class Initialized
INFO - 2022-04-21 11:05:49 --> Loader Class Initialized
INFO - 2022-04-21 11:05:49 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:49 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:49 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:49 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:49 --> Controller Class Initialized
INFO - 2022-04-21 11:05:49 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:49 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:05:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 11:05:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:49 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:49 --> Final output sent to browser
INFO - 2022-04-21 11:05:51 --> Config Class Initialized
INFO - 2022-04-21 11:05:51 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:51 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:51 --> URI Class Initialized
INFO - 2022-04-21 11:05:51 --> Router Class Initialized
INFO - 2022-04-21 11:05:51 --> Output Class Initialized
INFO - 2022-04-21 11:05:51 --> Security Class Initialized
INFO - 2022-04-21 11:05:51 --> Input Class Initialized
INFO - 2022-04-21 11:05:51 --> Language Class Initialized
INFO - 2022-04-21 11:05:51 --> Loader Class Initialized
INFO - 2022-04-21 11:05:51 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:51 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:51 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:51 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:51 --> Controller Class Initialized
INFO - 2022-04-21 11:05:51 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:51 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:05:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_tambah.php
INFO - 2022-04-21 11:05:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:51 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:51 --> Final output sent to browser
INFO - 2022-04-21 11:05:53 --> Config Class Initialized
INFO - 2022-04-21 11:05:53 --> Hooks Class Initialized
INFO - 2022-04-21 11:05:53 --> Utf8 Class Initialized
INFO - 2022-04-21 11:05:53 --> URI Class Initialized
INFO - 2022-04-21 11:05:53 --> Router Class Initialized
INFO - 2022-04-21 11:05:53 --> Output Class Initialized
INFO - 2022-04-21 11:05:53 --> Security Class Initialized
INFO - 2022-04-21 11:05:53 --> Input Class Initialized
INFO - 2022-04-21 11:05:53 --> Language Class Initialized
INFO - 2022-04-21 11:05:53 --> Loader Class Initialized
INFO - 2022-04-21 11:05:53 --> Helper loaded: url_helper
INFO - 2022-04-21 11:05:53 --> Helper loaded: form_helper
INFO - 2022-04-21 11:05:53 --> Database Driver Class Initialized
INFO - 2022-04-21 11:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-21 11:05:53 --> Form Validation Class Initialized
INFO - 2022-04-21 11:05:53 --> Controller Class Initialized
INFO - 2022-04-21 11:05:53 --> Model "M_tutor" initialized
INFO - 2022-04-21 11:05:53 --> Model "M_todo_group_ptk" initialized
INFO - 2022-04-21 11:05:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/head.php
INFO - 2022-04-21 11:05:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/navbar.php
INFO - 2022-04-21 11:05:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\todo_tutor/v_index.php
INFO - 2022-04-21 11:05:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/sidebar.php
INFO - 2022-04-21 11:05:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/footer.php
INFO - 2022-04-21 11:05:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\_partials/script.php
INFO - 2022-04-21 11:05:53 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\template.php
INFO - 2022-04-21 11:05:53 --> Final output sent to browser
