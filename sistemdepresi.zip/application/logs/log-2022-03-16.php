<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-16 19:55:45 --> Config Class Initialized
INFO - 2022-03-16 19:55:45 --> Hooks Class Initialized
INFO - 2022-03-16 19:55:46 --> Utf8 Class Initialized
INFO - 2022-03-16 19:55:46 --> URI Class Initialized
INFO - 2022-03-16 19:55:46 --> Router Class Initialized
INFO - 2022-03-16 19:55:46 --> Output Class Initialized
INFO - 2022-03-16 19:55:46 --> Security Class Initialized
INFO - 2022-03-16 19:55:46 --> Input Class Initialized
INFO - 2022-03-16 19:55:46 --> Language Class Initialized
INFO - 2022-03-16 19:55:46 --> Loader Class Initialized
INFO - 2022-03-16 19:55:47 --> Helper loaded: url_helper
INFO - 2022-03-16 19:55:47 --> Helper loaded: form_helper
INFO - 2022-03-16 19:55:47 --> Database Driver Class Initialized
INFO - 2022-03-16 19:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 19:55:47 --> Controller Class Initialized
INFO - 2022-03-16 19:55:47 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-16 19:55:47 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-16 19:55:47 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-16 19:55:47 --> Final output sent to browser
INFO - 2022-03-16 19:56:15 --> Config Class Initialized
INFO - 2022-03-16 19:56:15 --> Hooks Class Initialized
INFO - 2022-03-16 19:56:15 --> Utf8 Class Initialized
INFO - 2022-03-16 19:56:15 --> URI Class Initialized
INFO - 2022-03-16 19:56:15 --> Router Class Initialized
INFO - 2022-03-16 19:56:15 --> Output Class Initialized
INFO - 2022-03-16 19:56:15 --> Security Class Initialized
INFO - 2022-03-16 19:56:15 --> Input Class Initialized
INFO - 2022-03-16 19:56:15 --> Language Class Initialized
INFO - 2022-03-16 19:56:15 --> Loader Class Initialized
INFO - 2022-03-16 19:56:15 --> Helper loaded: url_helper
INFO - 2022-03-16 19:56:15 --> Helper loaded: form_helper
INFO - 2022-03-16 19:56:15 --> Database Driver Class Initialized
INFO - 2022-03-16 19:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 19:56:15 --> Controller Class Initialized
INFO - 2022-03-16 19:56:15 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-16 19:56:15 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-16 19:56:15 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-16 19:56:15 --> Final output sent to browser
INFO - 2022-03-16 19:56:24 --> Config Class Initialized
INFO - 2022-03-16 19:56:24 --> Hooks Class Initialized
INFO - 2022-03-16 19:56:24 --> Utf8 Class Initialized
INFO - 2022-03-16 19:56:24 --> URI Class Initialized
INFO - 2022-03-16 19:56:24 --> Router Class Initialized
INFO - 2022-03-16 19:56:24 --> Output Class Initialized
INFO - 2022-03-16 19:56:24 --> Security Class Initialized
INFO - 2022-03-16 19:56:24 --> Input Class Initialized
INFO - 2022-03-16 19:56:24 --> Language Class Initialized
INFO - 2022-03-16 19:56:24 --> Loader Class Initialized
INFO - 2022-03-16 19:56:24 --> Helper loaded: url_helper
INFO - 2022-03-16 19:56:24 --> Helper loaded: form_helper
INFO - 2022-03-16 19:56:24 --> Database Driver Class Initialized
INFO - 2022-03-16 19:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 19:56:24 --> Controller Class Initialized
INFO - 2022-03-16 19:56:24 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-16 19:56:24 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-16 19:56:24 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-16 19:56:24 --> Final output sent to browser
INFO - 2022-03-16 19:56:50 --> Config Class Initialized
INFO - 2022-03-16 19:56:50 --> Hooks Class Initialized
INFO - 2022-03-16 19:56:50 --> Utf8 Class Initialized
INFO - 2022-03-16 19:56:50 --> URI Class Initialized
INFO - 2022-03-16 19:56:50 --> Router Class Initialized
INFO - 2022-03-16 19:56:50 --> Output Class Initialized
INFO - 2022-03-16 19:56:50 --> Security Class Initialized
INFO - 2022-03-16 19:56:50 --> Input Class Initialized
INFO - 2022-03-16 19:56:50 --> Language Class Initialized
INFO - 2022-03-16 19:56:50 --> Loader Class Initialized
INFO - 2022-03-16 19:56:50 --> Helper loaded: url_helper
INFO - 2022-03-16 19:56:50 --> Helper loaded: form_helper
INFO - 2022-03-16 19:56:50 --> Database Driver Class Initialized
INFO - 2022-03-16 19:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 19:56:50 --> Controller Class Initialized
INFO - 2022-03-16 19:56:50 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-16 19:56:50 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-16 19:56:50 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-16 19:56:50 --> Final output sent to browser
INFO - 2022-03-16 19:56:59 --> Config Class Initialized
INFO - 2022-03-16 19:56:59 --> Hooks Class Initialized
INFO - 2022-03-16 19:56:59 --> Utf8 Class Initialized
INFO - 2022-03-16 19:56:59 --> URI Class Initialized
INFO - 2022-03-16 19:56:59 --> Router Class Initialized
INFO - 2022-03-16 19:56:59 --> Output Class Initialized
INFO - 2022-03-16 19:56:59 --> Security Class Initialized
INFO - 2022-03-16 19:56:59 --> Input Class Initialized
INFO - 2022-03-16 19:56:59 --> Language Class Initialized
ERROR - 2022-03-16 19:56:59 --> 404 Page Not Found: Products/index
INFO - 2022-03-16 19:57:51 --> Config Class Initialized
INFO - 2022-03-16 19:57:51 --> Hooks Class Initialized
INFO - 2022-03-16 19:57:51 --> Utf8 Class Initialized
INFO - 2022-03-16 19:57:51 --> URI Class Initialized
INFO - 2022-03-16 19:57:51 --> Router Class Initialized
INFO - 2022-03-16 19:57:51 --> Output Class Initialized
INFO - 2022-03-16 19:57:51 --> Security Class Initialized
INFO - 2022-03-16 19:57:51 --> Input Class Initialized
INFO - 2022-03-16 19:57:51 --> Language Class Initialized
ERROR - 2022-03-16 19:57:51 --> 404 Page Not Found: Groups/index
INFO - 2022-03-16 19:57:56 --> Config Class Initialized
INFO - 2022-03-16 19:57:56 --> Hooks Class Initialized
INFO - 2022-03-16 19:57:56 --> Utf8 Class Initialized
INFO - 2022-03-16 19:57:57 --> URI Class Initialized
INFO - 2022-03-16 19:57:57 --> Router Class Initialized
INFO - 2022-03-16 19:57:57 --> Output Class Initialized
INFO - 2022-03-16 19:57:57 --> Security Class Initialized
INFO - 2022-03-16 19:57:57 --> Input Class Initialized
INFO - 2022-03-16 19:57:57 --> Language Class Initialized
INFO - 2022-03-16 19:57:57 --> Loader Class Initialized
INFO - 2022-03-16 19:57:57 --> Helper loaded: url_helper
INFO - 2022-03-16 19:57:57 --> Helper loaded: form_helper
INFO - 2022-03-16 19:57:57 --> Database Driver Class Initialized
INFO - 2022-03-16 19:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 19:57:57 --> Controller Class Initialized
INFO - 2022-03-16 19:57:57 --> Model "M_todo_group" initialized
INFO - 2022-03-16 19:57:57 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 19:57:57 --> Form Validation Class Initialized
INFO - 2022-03-16 19:57:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 19:57:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 19:57:57 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-16 19:57:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 19:57:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 19:57:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 19:57:57 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 19:57:57 --> Final output sent to browser
INFO - 2022-03-16 19:58:04 --> Config Class Initialized
INFO - 2022-03-16 19:58:04 --> Hooks Class Initialized
INFO - 2022-03-16 19:58:04 --> Utf8 Class Initialized
INFO - 2022-03-16 19:58:04 --> URI Class Initialized
INFO - 2022-03-16 19:58:04 --> Router Class Initialized
INFO - 2022-03-16 19:58:04 --> Output Class Initialized
INFO - 2022-03-16 19:58:04 --> Security Class Initialized
INFO - 2022-03-16 19:58:04 --> Input Class Initialized
INFO - 2022-03-16 19:58:04 --> Language Class Initialized
INFO - 2022-03-16 19:58:04 --> Loader Class Initialized
INFO - 2022-03-16 19:58:04 --> Helper loaded: url_helper
INFO - 2022-03-16 19:58:04 --> Helper loaded: form_helper
INFO - 2022-03-16 19:58:04 --> Database Driver Class Initialized
INFO - 2022-03-16 19:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 19:58:04 --> Controller Class Initialized
INFO - 2022-03-16 19:58:04 --> Model "M_todo_group" initialized
INFO - 2022-03-16 19:58:04 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 19:58:04 --> Form Validation Class Initialized
INFO - 2022-03-16 19:58:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 19:58:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 19:58:04 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 19:58:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 19:58:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 19:58:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 19:58:04 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 19:58:04 --> Final output sent to browser
INFO - 2022-03-16 19:58:11 --> Config Class Initialized
INFO - 2022-03-16 19:58:11 --> Hooks Class Initialized
INFO - 2022-03-16 19:58:11 --> Utf8 Class Initialized
INFO - 2022-03-16 19:58:11 --> URI Class Initialized
INFO - 2022-03-16 19:58:12 --> Router Class Initialized
INFO - 2022-03-16 19:58:12 --> Output Class Initialized
INFO - 2022-03-16 19:58:12 --> Security Class Initialized
INFO - 2022-03-16 19:58:12 --> Input Class Initialized
INFO - 2022-03-16 19:58:12 --> Language Class Initialized
ERROR - 2022-03-16 19:58:12 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 19:58:20 --> Config Class Initialized
INFO - 2022-03-16 19:58:20 --> Hooks Class Initialized
INFO - 2022-03-16 19:58:20 --> Utf8 Class Initialized
INFO - 2022-03-16 19:58:20 --> URI Class Initialized
INFO - 2022-03-16 19:58:20 --> Router Class Initialized
INFO - 2022-03-16 19:58:20 --> Output Class Initialized
INFO - 2022-03-16 19:58:20 --> Security Class Initialized
INFO - 2022-03-16 19:58:20 --> Input Class Initialized
INFO - 2022-03-16 19:58:20 --> Language Class Initialized
ERROR - 2022-03-16 19:58:20 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 19:58:28 --> Config Class Initialized
INFO - 2022-03-16 19:58:28 --> Hooks Class Initialized
INFO - 2022-03-16 19:58:28 --> Utf8 Class Initialized
INFO - 2022-03-16 19:58:28 --> URI Class Initialized
INFO - 2022-03-16 19:58:28 --> Router Class Initialized
INFO - 2022-03-16 19:58:28 --> Output Class Initialized
INFO - 2022-03-16 19:58:28 --> Security Class Initialized
INFO - 2022-03-16 19:58:28 --> Input Class Initialized
INFO - 2022-03-16 19:58:28 --> Language Class Initialized
ERROR - 2022-03-16 19:58:28 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 20:04:36 --> Config Class Initialized
INFO - 2022-03-16 20:04:36 --> Hooks Class Initialized
INFO - 2022-03-16 20:04:36 --> Utf8 Class Initialized
INFO - 2022-03-16 20:04:36 --> URI Class Initialized
INFO - 2022-03-16 20:04:36 --> Router Class Initialized
INFO - 2022-03-16 20:04:36 --> Output Class Initialized
INFO - 2022-03-16 20:04:36 --> Security Class Initialized
INFO - 2022-03-16 20:04:36 --> Input Class Initialized
INFO - 2022-03-16 20:04:36 --> Language Class Initialized
ERROR - 2022-03-16 20:04:36 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 20:05:46 --> Config Class Initialized
INFO - 2022-03-16 20:05:46 --> Hooks Class Initialized
INFO - 2022-03-16 20:05:46 --> Utf8 Class Initialized
INFO - 2022-03-16 20:05:46 --> URI Class Initialized
INFO - 2022-03-16 20:05:46 --> Router Class Initialized
INFO - 2022-03-16 20:05:46 --> Output Class Initialized
INFO - 2022-03-16 20:05:46 --> Security Class Initialized
INFO - 2022-03-16 20:05:46 --> Input Class Initialized
INFO - 2022-03-16 20:05:46 --> Language Class Initialized
INFO - 2022-03-16 20:05:46 --> Loader Class Initialized
INFO - 2022-03-16 20:05:46 --> Helper loaded: url_helper
INFO - 2022-03-16 20:05:46 --> Helper loaded: form_helper
INFO - 2022-03-16 20:05:46 --> Database Driver Class Initialized
INFO - 2022-03-16 20:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:05:46 --> Controller Class Initialized
INFO - 2022-03-16 20:05:46 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:05:46 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:05:46 --> Form Validation Class Initialized
INFO - 2022-03-16 20:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:05:46 --> Final output sent to browser
INFO - 2022-03-16 20:05:49 --> Config Class Initialized
INFO - 2022-03-16 20:05:49 --> Hooks Class Initialized
INFO - 2022-03-16 20:05:49 --> Utf8 Class Initialized
INFO - 2022-03-16 20:05:49 --> URI Class Initialized
INFO - 2022-03-16 20:05:49 --> Router Class Initialized
INFO - 2022-03-16 20:05:49 --> Output Class Initialized
INFO - 2022-03-16 20:05:49 --> Security Class Initialized
INFO - 2022-03-16 20:05:49 --> Input Class Initialized
INFO - 2022-03-16 20:05:49 --> Language Class Initialized
ERROR - 2022-03-16 20:05:49 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 20:05:53 --> Config Class Initialized
INFO - 2022-03-16 20:05:53 --> Hooks Class Initialized
INFO - 2022-03-16 20:05:53 --> Utf8 Class Initialized
INFO - 2022-03-16 20:05:53 --> URI Class Initialized
INFO - 2022-03-16 20:05:53 --> Router Class Initialized
INFO - 2022-03-16 20:05:53 --> Output Class Initialized
INFO - 2022-03-16 20:05:53 --> Security Class Initialized
INFO - 2022-03-16 20:05:53 --> Input Class Initialized
INFO - 2022-03-16 20:05:53 --> Language Class Initialized
ERROR - 2022-03-16 20:05:53 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 20:05:54 --> Config Class Initialized
INFO - 2022-03-16 20:05:54 --> Hooks Class Initialized
INFO - 2022-03-16 20:05:54 --> Utf8 Class Initialized
INFO - 2022-03-16 20:05:54 --> URI Class Initialized
INFO - 2022-03-16 20:05:54 --> Router Class Initialized
INFO - 2022-03-16 20:05:54 --> Output Class Initialized
INFO - 2022-03-16 20:05:54 --> Security Class Initialized
INFO - 2022-03-16 20:05:54 --> Input Class Initialized
INFO - 2022-03-16 20:05:54 --> Language Class Initialized
ERROR - 2022-03-16 20:05:54 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 20:05:55 --> Config Class Initialized
INFO - 2022-03-16 20:05:55 --> Hooks Class Initialized
INFO - 2022-03-16 20:05:56 --> Utf8 Class Initialized
INFO - 2022-03-16 20:05:56 --> URI Class Initialized
INFO - 2022-03-16 20:05:56 --> Router Class Initialized
INFO - 2022-03-16 20:05:56 --> Output Class Initialized
INFO - 2022-03-16 20:05:56 --> Security Class Initialized
INFO - 2022-03-16 20:05:56 --> Input Class Initialized
INFO - 2022-03-16 20:05:56 --> Language Class Initialized
ERROR - 2022-03-16 20:05:56 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 20:05:56 --> Config Class Initialized
INFO - 2022-03-16 20:05:56 --> Hooks Class Initialized
INFO - 2022-03-16 20:05:56 --> Utf8 Class Initialized
INFO - 2022-03-16 20:05:56 --> URI Class Initialized
INFO - 2022-03-16 20:05:56 --> Router Class Initialized
INFO - 2022-03-16 20:05:56 --> Output Class Initialized
INFO - 2022-03-16 20:05:56 --> Security Class Initialized
INFO - 2022-03-16 20:05:56 --> Input Class Initialized
INFO - 2022-03-16 20:05:56 --> Language Class Initialized
ERROR - 2022-03-16 20:05:56 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 20:05:57 --> Config Class Initialized
INFO - 2022-03-16 20:05:57 --> Hooks Class Initialized
INFO - 2022-03-16 20:05:57 --> Utf8 Class Initialized
INFO - 2022-03-16 20:05:57 --> URI Class Initialized
INFO - 2022-03-16 20:05:57 --> Router Class Initialized
INFO - 2022-03-16 20:05:57 --> Output Class Initialized
INFO - 2022-03-16 20:05:57 --> Security Class Initialized
INFO - 2022-03-16 20:05:57 --> Input Class Initialized
INFO - 2022-03-16 20:05:57 --> Language Class Initialized
ERROR - 2022-03-16 20:05:57 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 20:06:06 --> Config Class Initialized
INFO - 2022-03-16 20:06:06 --> Hooks Class Initialized
INFO - 2022-03-16 20:06:06 --> Utf8 Class Initialized
INFO - 2022-03-16 20:06:06 --> URI Class Initialized
INFO - 2022-03-16 20:06:06 --> Router Class Initialized
INFO - 2022-03-16 20:06:07 --> Output Class Initialized
INFO - 2022-03-16 20:06:07 --> Security Class Initialized
INFO - 2022-03-16 20:06:07 --> Input Class Initialized
INFO - 2022-03-16 20:06:07 --> Language Class Initialized
ERROR - 2022-03-16 20:06:07 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 20:06:52 --> Config Class Initialized
INFO - 2022-03-16 20:06:52 --> Hooks Class Initialized
INFO - 2022-03-16 20:06:52 --> Utf8 Class Initialized
INFO - 2022-03-16 20:06:52 --> URI Class Initialized
INFO - 2022-03-16 20:06:52 --> Router Class Initialized
INFO - 2022-03-16 20:06:52 --> Output Class Initialized
INFO - 2022-03-16 20:06:52 --> Security Class Initialized
INFO - 2022-03-16 20:06:52 --> Input Class Initialized
INFO - 2022-03-16 20:06:52 --> Language Class Initialized
ERROR - 2022-03-16 20:06:52 --> 404 Page Not Found: Api/get_tutor
INFO - 2022-03-16 20:07:59 --> Config Class Initialized
INFO - 2022-03-16 20:07:59 --> Hooks Class Initialized
INFO - 2022-03-16 20:07:59 --> Utf8 Class Initialized
INFO - 2022-03-16 20:07:59 --> URI Class Initialized
INFO - 2022-03-16 20:07:59 --> Router Class Initialized
INFO - 2022-03-16 20:07:59 --> Output Class Initialized
INFO - 2022-03-16 20:07:59 --> Security Class Initialized
INFO - 2022-03-16 20:07:59 --> Input Class Initialized
INFO - 2022-03-16 20:07:59 --> Language Class Initialized
INFO - 2022-03-16 20:07:59 --> Loader Class Initialized
INFO - 2022-03-16 20:07:59 --> Helper loaded: url_helper
INFO - 2022-03-16 20:07:59 --> Helper loaded: form_helper
INFO - 2022-03-16 20:07:59 --> Database Driver Class Initialized
INFO - 2022-03-16 20:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:07:59 --> Controller Class Initialized
INFO - 2022-03-16 20:07:59 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:07:59 --> Final output sent to browser
INFO - 2022-03-16 20:08:02 --> Config Class Initialized
INFO - 2022-03-16 20:08:02 --> Hooks Class Initialized
INFO - 2022-03-16 20:08:02 --> Utf8 Class Initialized
INFO - 2022-03-16 20:08:02 --> URI Class Initialized
INFO - 2022-03-16 20:08:02 --> Router Class Initialized
INFO - 2022-03-16 20:08:02 --> Output Class Initialized
INFO - 2022-03-16 20:08:02 --> Security Class Initialized
INFO - 2022-03-16 20:08:02 --> Input Class Initialized
INFO - 2022-03-16 20:08:03 --> Language Class Initialized
INFO - 2022-03-16 20:08:03 --> Loader Class Initialized
INFO - 2022-03-16 20:08:03 --> Helper loaded: url_helper
INFO - 2022-03-16 20:08:03 --> Helper loaded: form_helper
INFO - 2022-03-16 20:08:03 --> Database Driver Class Initialized
INFO - 2022-03-16 20:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:08:03 --> Controller Class Initialized
INFO - 2022-03-16 20:08:03 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:08:03 --> Final output sent to browser
INFO - 2022-03-16 20:08:06 --> Config Class Initialized
INFO - 2022-03-16 20:08:06 --> Hooks Class Initialized
INFO - 2022-03-16 20:08:06 --> Utf8 Class Initialized
INFO - 2022-03-16 20:08:06 --> URI Class Initialized
INFO - 2022-03-16 20:08:06 --> Router Class Initialized
INFO - 2022-03-16 20:08:06 --> Output Class Initialized
INFO - 2022-03-16 20:08:06 --> Security Class Initialized
INFO - 2022-03-16 20:08:06 --> Input Class Initialized
INFO - 2022-03-16 20:08:06 --> Language Class Initialized
INFO - 2022-03-16 20:08:06 --> Loader Class Initialized
INFO - 2022-03-16 20:08:06 --> Helper loaded: url_helper
INFO - 2022-03-16 20:08:06 --> Helper loaded: form_helper
INFO - 2022-03-16 20:08:06 --> Database Driver Class Initialized
INFO - 2022-03-16 20:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:08:06 --> Controller Class Initialized
INFO - 2022-03-16 20:08:06 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:08:06 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:08:06 --> Form Validation Class Initialized
INFO - 2022-03-16 20:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:08:06 --> Final output sent to browser
INFO - 2022-03-16 20:08:25 --> Config Class Initialized
INFO - 2022-03-16 20:08:25 --> Hooks Class Initialized
INFO - 2022-03-16 20:08:25 --> Utf8 Class Initialized
INFO - 2022-03-16 20:08:25 --> URI Class Initialized
INFO - 2022-03-16 20:08:25 --> Router Class Initialized
INFO - 2022-03-16 20:08:25 --> Output Class Initialized
INFO - 2022-03-16 20:08:25 --> Security Class Initialized
INFO - 2022-03-16 20:08:25 --> Input Class Initialized
INFO - 2022-03-16 20:08:25 --> Language Class Initialized
INFO - 2022-03-16 20:08:25 --> Loader Class Initialized
INFO - 2022-03-16 20:08:25 --> Helper loaded: url_helper
INFO - 2022-03-16 20:08:25 --> Helper loaded: form_helper
INFO - 2022-03-16 20:08:25 --> Database Driver Class Initialized
INFO - 2022-03-16 20:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:08:25 --> Controller Class Initialized
INFO - 2022-03-16 20:08:25 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:08:25 --> Final output sent to browser
INFO - 2022-03-16 20:10:01 --> Config Class Initialized
INFO - 2022-03-16 20:10:01 --> Hooks Class Initialized
INFO - 2022-03-16 20:10:01 --> Utf8 Class Initialized
INFO - 2022-03-16 20:10:01 --> URI Class Initialized
INFO - 2022-03-16 20:10:01 --> Router Class Initialized
INFO - 2022-03-16 20:10:01 --> Output Class Initialized
INFO - 2022-03-16 20:10:01 --> Security Class Initialized
INFO - 2022-03-16 20:10:01 --> Input Class Initialized
INFO - 2022-03-16 20:10:01 --> Language Class Initialized
INFO - 2022-03-16 20:10:01 --> Loader Class Initialized
INFO - 2022-03-16 20:10:01 --> Helper loaded: url_helper
INFO - 2022-03-16 20:10:01 --> Helper loaded: form_helper
INFO - 2022-03-16 20:10:01 --> Database Driver Class Initialized
INFO - 2022-03-16 20:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:10:01 --> Controller Class Initialized
INFO - 2022-03-16 20:10:01 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:10:01 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:10:01 --> Form Validation Class Initialized
INFO - 2022-03-16 20:10:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:10:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:10:01 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:10:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:10:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:10:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:10:01 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:10:01 --> Final output sent to browser
INFO - 2022-03-16 20:10:07 --> Config Class Initialized
INFO - 2022-03-16 20:10:07 --> Hooks Class Initialized
INFO - 2022-03-16 20:10:07 --> Utf8 Class Initialized
INFO - 2022-03-16 20:10:07 --> URI Class Initialized
INFO - 2022-03-16 20:10:07 --> Router Class Initialized
INFO - 2022-03-16 20:10:07 --> Output Class Initialized
INFO - 2022-03-16 20:10:07 --> Security Class Initialized
INFO - 2022-03-16 20:10:07 --> Input Class Initialized
INFO - 2022-03-16 20:10:07 --> Language Class Initialized
INFO - 2022-03-16 20:10:07 --> Loader Class Initialized
INFO - 2022-03-16 20:10:07 --> Helper loaded: url_helper
INFO - 2022-03-16 20:10:07 --> Helper loaded: form_helper
INFO - 2022-03-16 20:10:07 --> Database Driver Class Initialized
INFO - 2022-03-16 20:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:10:07 --> Controller Class Initialized
INFO - 2022-03-16 20:10:07 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:10:07 --> Final output sent to browser
INFO - 2022-03-16 20:12:28 --> Config Class Initialized
INFO - 2022-03-16 20:12:28 --> Hooks Class Initialized
INFO - 2022-03-16 20:12:28 --> Utf8 Class Initialized
INFO - 2022-03-16 20:12:28 --> URI Class Initialized
INFO - 2022-03-16 20:12:28 --> Router Class Initialized
INFO - 2022-03-16 20:12:28 --> Output Class Initialized
INFO - 2022-03-16 20:12:28 --> Security Class Initialized
INFO - 2022-03-16 20:12:28 --> Input Class Initialized
INFO - 2022-03-16 20:12:28 --> Language Class Initialized
INFO - 2022-03-16 20:12:28 --> Loader Class Initialized
INFO - 2022-03-16 20:12:28 --> Helper loaded: url_helper
INFO - 2022-03-16 20:12:28 --> Helper loaded: form_helper
INFO - 2022-03-16 20:12:28 --> Database Driver Class Initialized
INFO - 2022-03-16 20:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:12:28 --> Controller Class Initialized
INFO - 2022-03-16 20:12:28 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:12:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:12:28 --> Form Validation Class Initialized
INFO - 2022-03-16 20:12:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:12:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:12:28 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:12:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:12:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:12:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:12:28 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:12:28 --> Final output sent to browser
INFO - 2022-03-16 20:13:16 --> Config Class Initialized
INFO - 2022-03-16 20:13:16 --> Hooks Class Initialized
INFO - 2022-03-16 20:13:16 --> Utf8 Class Initialized
INFO - 2022-03-16 20:13:16 --> URI Class Initialized
INFO - 2022-03-16 20:13:16 --> Router Class Initialized
INFO - 2022-03-16 20:13:16 --> Output Class Initialized
INFO - 2022-03-16 20:13:16 --> Security Class Initialized
INFO - 2022-03-16 20:13:16 --> Input Class Initialized
INFO - 2022-03-16 20:13:16 --> Language Class Initialized
INFO - 2022-03-16 20:13:16 --> Loader Class Initialized
INFO - 2022-03-16 20:13:16 --> Helper loaded: url_helper
INFO - 2022-03-16 20:13:16 --> Helper loaded: form_helper
INFO - 2022-03-16 20:13:16 --> Database Driver Class Initialized
INFO - 2022-03-16 20:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:13:16 --> Controller Class Initialized
INFO - 2022-03-16 20:13:16 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:13:16 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:13:16 --> Form Validation Class Initialized
INFO - 2022-03-16 20:13:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:13:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:13:16 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:13:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:13:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:13:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:13:16 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:13:16 --> Final output sent to browser
INFO - 2022-03-16 20:13:21 --> Config Class Initialized
INFO - 2022-03-16 20:13:21 --> Hooks Class Initialized
INFO - 2022-03-16 20:13:21 --> Utf8 Class Initialized
INFO - 2022-03-16 20:13:21 --> URI Class Initialized
INFO - 2022-03-16 20:13:21 --> Router Class Initialized
INFO - 2022-03-16 20:13:21 --> Output Class Initialized
INFO - 2022-03-16 20:13:21 --> Security Class Initialized
INFO - 2022-03-16 20:13:21 --> Input Class Initialized
INFO - 2022-03-16 20:13:21 --> Language Class Initialized
INFO - 2022-03-16 20:13:21 --> Loader Class Initialized
INFO - 2022-03-16 20:13:21 --> Helper loaded: url_helper
INFO - 2022-03-16 20:13:21 --> Helper loaded: form_helper
INFO - 2022-03-16 20:13:21 --> Database Driver Class Initialized
INFO - 2022-03-16 20:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:13:21 --> Controller Class Initialized
INFO - 2022-03-16 20:13:21 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:13:21 --> Final output sent to browser
INFO - 2022-03-16 20:13:43 --> Config Class Initialized
INFO - 2022-03-16 20:13:43 --> Hooks Class Initialized
INFO - 2022-03-16 20:13:43 --> Utf8 Class Initialized
INFO - 2022-03-16 20:13:43 --> URI Class Initialized
INFO - 2022-03-16 20:13:43 --> Router Class Initialized
INFO - 2022-03-16 20:13:43 --> Output Class Initialized
INFO - 2022-03-16 20:13:43 --> Security Class Initialized
INFO - 2022-03-16 20:13:43 --> Input Class Initialized
INFO - 2022-03-16 20:13:43 --> Language Class Initialized
INFO - 2022-03-16 20:13:43 --> Loader Class Initialized
INFO - 2022-03-16 20:13:43 --> Helper loaded: url_helper
INFO - 2022-03-16 20:13:43 --> Helper loaded: form_helper
INFO - 2022-03-16 20:13:43 --> Database Driver Class Initialized
INFO - 2022-03-16 20:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:13:43 --> Controller Class Initialized
INFO - 2022-03-16 20:13:43 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:13:43 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:13:43 --> Form Validation Class Initialized
INFO - 2022-03-16 20:13:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:13:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:13:43 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:13:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:13:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:13:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:13:43 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:13:43 --> Final output sent to browser
INFO - 2022-03-16 20:13:57 --> Config Class Initialized
INFO - 2022-03-16 20:13:57 --> Hooks Class Initialized
INFO - 2022-03-16 20:13:57 --> Utf8 Class Initialized
INFO - 2022-03-16 20:13:57 --> URI Class Initialized
INFO - 2022-03-16 20:13:57 --> Router Class Initialized
INFO - 2022-03-16 20:13:57 --> Output Class Initialized
INFO - 2022-03-16 20:13:57 --> Security Class Initialized
INFO - 2022-03-16 20:13:57 --> Input Class Initialized
INFO - 2022-03-16 20:13:57 --> Language Class Initialized
INFO - 2022-03-16 20:13:57 --> Loader Class Initialized
INFO - 2022-03-16 20:13:57 --> Helper loaded: url_helper
INFO - 2022-03-16 20:13:57 --> Helper loaded: form_helper
INFO - 2022-03-16 20:13:57 --> Database Driver Class Initialized
INFO - 2022-03-16 20:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:13:57 --> Controller Class Initialized
INFO - 2022-03-16 20:13:57 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:13:57 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:13:57 --> Form Validation Class Initialized
INFO - 2022-03-16 20:13:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:13:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:13:58 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:13:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:13:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:13:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:13:58 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:13:58 --> Final output sent to browser
INFO - 2022-03-16 20:14:03 --> Config Class Initialized
INFO - 2022-03-16 20:14:03 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:03 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:03 --> URI Class Initialized
INFO - 2022-03-16 20:14:03 --> Router Class Initialized
INFO - 2022-03-16 20:14:03 --> Output Class Initialized
INFO - 2022-03-16 20:14:03 --> Security Class Initialized
INFO - 2022-03-16 20:14:03 --> Input Class Initialized
INFO - 2022-03-16 20:14:03 --> Language Class Initialized
INFO - 2022-03-16 20:14:03 --> Loader Class Initialized
INFO - 2022-03-16 20:14:03 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:03 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:03 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:03 --> Controller Class Initialized
INFO - 2022-03-16 20:14:03 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:14:03 --> Final output sent to browser
INFO - 2022-03-16 20:14:09 --> Config Class Initialized
INFO - 2022-03-16 20:14:09 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:09 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:09 --> URI Class Initialized
INFO - 2022-03-16 20:14:09 --> Router Class Initialized
INFO - 2022-03-16 20:14:09 --> Output Class Initialized
INFO - 2022-03-16 20:14:09 --> Security Class Initialized
INFO - 2022-03-16 20:14:09 --> Input Class Initialized
INFO - 2022-03-16 20:14:09 --> Language Class Initialized
INFO - 2022-03-16 20:14:09 --> Loader Class Initialized
INFO - 2022-03-16 20:14:09 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:09 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:09 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:09 --> Controller Class Initialized
INFO - 2022-03-16 20:14:09 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:14:09 --> Final output sent to browser
INFO - 2022-03-16 20:14:23 --> Config Class Initialized
INFO - 2022-03-16 20:14:23 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:23 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:23 --> URI Class Initialized
INFO - 2022-03-16 20:14:23 --> Router Class Initialized
INFO - 2022-03-16 20:14:23 --> Output Class Initialized
INFO - 2022-03-16 20:14:23 --> Security Class Initialized
INFO - 2022-03-16 20:14:23 --> Input Class Initialized
INFO - 2022-03-16 20:14:23 --> Language Class Initialized
INFO - 2022-03-16 20:14:23 --> Loader Class Initialized
INFO - 2022-03-16 20:14:23 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:23 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:23 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:23 --> Controller Class Initialized
INFO - 2022-03-16 20:14:23 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:14:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:14:23 --> Form Validation Class Initialized
INFO - 2022-03-16 20:14:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:14:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:14:23 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:14:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:14:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:14:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:14:23 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:14:23 --> Final output sent to browser
INFO - 2022-03-16 20:14:29 --> Config Class Initialized
INFO - 2022-03-16 20:14:29 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:29 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:29 --> URI Class Initialized
INFO - 2022-03-16 20:14:29 --> Router Class Initialized
INFO - 2022-03-16 20:14:29 --> Output Class Initialized
INFO - 2022-03-16 20:14:29 --> Security Class Initialized
INFO - 2022-03-16 20:14:29 --> Input Class Initialized
INFO - 2022-03-16 20:14:29 --> Language Class Initialized
INFO - 2022-03-16 20:14:29 --> Loader Class Initialized
INFO - 2022-03-16 20:14:29 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:29 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:29 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:29 --> Controller Class Initialized
INFO - 2022-03-16 20:14:29 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:14:29 --> Final output sent to browser
INFO - 2022-03-16 20:14:34 --> Config Class Initialized
INFO - 2022-03-16 20:14:34 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:34 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:34 --> URI Class Initialized
INFO - 2022-03-16 20:14:34 --> Router Class Initialized
INFO - 2022-03-16 20:14:35 --> Output Class Initialized
INFO - 2022-03-16 20:14:35 --> Security Class Initialized
INFO - 2022-03-16 20:14:35 --> Input Class Initialized
INFO - 2022-03-16 20:14:35 --> Language Class Initialized
INFO - 2022-03-16 20:14:35 --> Loader Class Initialized
INFO - 2022-03-16 20:14:35 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:35 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:35 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:35 --> Controller Class Initialized
INFO - 2022-03-16 20:14:35 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:14:35 --> Final output sent to browser
INFO - 2022-03-16 20:14:38 --> Config Class Initialized
INFO - 2022-03-16 20:14:38 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:38 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:38 --> URI Class Initialized
INFO - 2022-03-16 20:14:38 --> Router Class Initialized
INFO - 2022-03-16 20:14:38 --> Output Class Initialized
INFO - 2022-03-16 20:14:38 --> Security Class Initialized
INFO - 2022-03-16 20:14:38 --> Input Class Initialized
INFO - 2022-03-16 20:14:38 --> Language Class Initialized
INFO - 2022-03-16 20:14:38 --> Loader Class Initialized
INFO - 2022-03-16 20:14:38 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:38 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:38 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:38 --> Controller Class Initialized
INFO - 2022-03-16 20:14:38 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:14:38 --> Final output sent to browser
INFO - 2022-03-16 20:14:39 --> Config Class Initialized
INFO - 2022-03-16 20:14:39 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:39 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:39 --> URI Class Initialized
INFO - 2022-03-16 20:14:39 --> Router Class Initialized
INFO - 2022-03-16 20:14:39 --> Output Class Initialized
INFO - 2022-03-16 20:14:39 --> Security Class Initialized
INFO - 2022-03-16 20:14:39 --> Input Class Initialized
INFO - 2022-03-16 20:14:39 --> Language Class Initialized
INFO - 2022-03-16 20:14:39 --> Loader Class Initialized
INFO - 2022-03-16 20:14:39 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:39 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:39 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:39 --> Controller Class Initialized
INFO - 2022-03-16 20:14:39 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:14:39 --> Final output sent to browser
INFO - 2022-03-16 20:14:40 --> Config Class Initialized
INFO - 2022-03-16 20:14:40 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:40 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:40 --> URI Class Initialized
INFO - 2022-03-16 20:14:40 --> Router Class Initialized
INFO - 2022-03-16 20:14:40 --> Output Class Initialized
INFO - 2022-03-16 20:14:40 --> Security Class Initialized
INFO - 2022-03-16 20:14:40 --> Input Class Initialized
INFO - 2022-03-16 20:14:40 --> Language Class Initialized
INFO - 2022-03-16 20:14:40 --> Loader Class Initialized
INFO - 2022-03-16 20:14:40 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:40 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:40 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:40 --> Controller Class Initialized
INFO - 2022-03-16 20:14:40 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:14:40 --> Final output sent to browser
INFO - 2022-03-16 20:14:42 --> Config Class Initialized
INFO - 2022-03-16 20:14:42 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:42 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:42 --> URI Class Initialized
INFO - 2022-03-16 20:14:42 --> Router Class Initialized
INFO - 2022-03-16 20:14:42 --> Output Class Initialized
INFO - 2022-03-16 20:14:42 --> Security Class Initialized
INFO - 2022-03-16 20:14:42 --> Input Class Initialized
INFO - 2022-03-16 20:14:42 --> Language Class Initialized
INFO - 2022-03-16 20:14:42 --> Loader Class Initialized
INFO - 2022-03-16 20:14:42 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:42 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:42 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:42 --> Controller Class Initialized
INFO - 2022-03-16 20:14:42 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:14:42 --> Final output sent to browser
INFO - 2022-03-16 20:14:44 --> Config Class Initialized
INFO - 2022-03-16 20:14:44 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:44 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:44 --> URI Class Initialized
INFO - 2022-03-16 20:14:44 --> Router Class Initialized
INFO - 2022-03-16 20:14:44 --> Output Class Initialized
INFO - 2022-03-16 20:14:44 --> Security Class Initialized
INFO - 2022-03-16 20:14:44 --> Input Class Initialized
INFO - 2022-03-16 20:14:44 --> Language Class Initialized
INFO - 2022-03-16 20:14:44 --> Loader Class Initialized
INFO - 2022-03-16 20:14:44 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:44 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:44 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:44 --> Controller Class Initialized
INFO - 2022-03-16 20:14:44 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:14:44 --> Final output sent to browser
INFO - 2022-03-16 20:14:44 --> Config Class Initialized
INFO - 2022-03-16 20:14:44 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:44 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:44 --> URI Class Initialized
INFO - 2022-03-16 20:14:44 --> Router Class Initialized
INFO - 2022-03-16 20:14:44 --> Output Class Initialized
INFO - 2022-03-16 20:14:44 --> Security Class Initialized
INFO - 2022-03-16 20:14:44 --> Input Class Initialized
INFO - 2022-03-16 20:14:44 --> Language Class Initialized
INFO - 2022-03-16 20:14:44 --> Loader Class Initialized
INFO - 2022-03-16 20:14:44 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:44 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:44 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:44 --> Controller Class Initialized
INFO - 2022-03-16 20:14:44 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:14:44 --> Final output sent to browser
INFO - 2022-03-16 20:14:45 --> Config Class Initialized
INFO - 2022-03-16 20:14:45 --> Hooks Class Initialized
INFO - 2022-03-16 20:14:45 --> Utf8 Class Initialized
INFO - 2022-03-16 20:14:45 --> URI Class Initialized
INFO - 2022-03-16 20:14:45 --> Router Class Initialized
INFO - 2022-03-16 20:14:45 --> Output Class Initialized
INFO - 2022-03-16 20:14:45 --> Security Class Initialized
INFO - 2022-03-16 20:14:45 --> Input Class Initialized
INFO - 2022-03-16 20:14:45 --> Language Class Initialized
INFO - 2022-03-16 20:14:45 --> Loader Class Initialized
INFO - 2022-03-16 20:14:45 --> Helper loaded: url_helper
INFO - 2022-03-16 20:14:45 --> Helper loaded: form_helper
INFO - 2022-03-16 20:14:45 --> Database Driver Class Initialized
INFO - 2022-03-16 20:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:14:45 --> Controller Class Initialized
INFO - 2022-03-16 20:14:45 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:14:45 --> Final output sent to browser
INFO - 2022-03-16 20:18:19 --> Config Class Initialized
INFO - 2022-03-16 20:18:19 --> Hooks Class Initialized
INFO - 2022-03-16 20:18:19 --> Utf8 Class Initialized
INFO - 2022-03-16 20:18:19 --> URI Class Initialized
INFO - 2022-03-16 20:18:19 --> Router Class Initialized
INFO - 2022-03-16 20:18:19 --> Output Class Initialized
INFO - 2022-03-16 20:18:19 --> Security Class Initialized
INFO - 2022-03-16 20:18:19 --> Input Class Initialized
INFO - 2022-03-16 20:18:19 --> Language Class Initialized
INFO - 2022-03-16 20:18:19 --> Loader Class Initialized
INFO - 2022-03-16 20:18:19 --> Helper loaded: url_helper
INFO - 2022-03-16 20:18:19 --> Helper loaded: form_helper
INFO - 2022-03-16 20:18:19 --> Database Driver Class Initialized
INFO - 2022-03-16 20:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:18:19 --> Controller Class Initialized
INFO - 2022-03-16 20:18:19 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:18:19 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:18:19 --> Form Validation Class Initialized
INFO - 2022-03-16 20:18:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:18:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:18:19 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:18:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:18:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:18:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:18:19 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:18:19 --> Final output sent to browser
INFO - 2022-03-16 20:20:34 --> Config Class Initialized
INFO - 2022-03-16 20:20:34 --> Hooks Class Initialized
INFO - 2022-03-16 20:20:34 --> Utf8 Class Initialized
INFO - 2022-03-16 20:20:34 --> URI Class Initialized
INFO - 2022-03-16 20:20:34 --> Router Class Initialized
INFO - 2022-03-16 20:20:34 --> Output Class Initialized
INFO - 2022-03-16 20:20:34 --> Security Class Initialized
INFO - 2022-03-16 20:20:34 --> Input Class Initialized
INFO - 2022-03-16 20:20:34 --> Language Class Initialized
INFO - 2022-03-16 20:20:34 --> Loader Class Initialized
INFO - 2022-03-16 20:20:34 --> Helper loaded: url_helper
INFO - 2022-03-16 20:20:34 --> Helper loaded: form_helper
INFO - 2022-03-16 20:20:34 --> Database Driver Class Initialized
INFO - 2022-03-16 20:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:20:34 --> Controller Class Initialized
INFO - 2022-03-16 20:20:34 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:20:34 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:20:34 --> Form Validation Class Initialized
INFO - 2022-03-16 20:20:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:20:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:20:34 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:20:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:20:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:20:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:20:34 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:20:34 --> Final output sent to browser
INFO - 2022-03-16 20:20:39 --> Config Class Initialized
INFO - 2022-03-16 20:20:39 --> Hooks Class Initialized
INFO - 2022-03-16 20:20:39 --> Utf8 Class Initialized
INFO - 2022-03-16 20:20:39 --> URI Class Initialized
INFO - 2022-03-16 20:20:39 --> Router Class Initialized
INFO - 2022-03-16 20:20:39 --> Output Class Initialized
INFO - 2022-03-16 20:20:39 --> Security Class Initialized
INFO - 2022-03-16 20:20:39 --> Input Class Initialized
INFO - 2022-03-16 20:20:39 --> Language Class Initialized
INFO - 2022-03-16 20:20:39 --> Loader Class Initialized
INFO - 2022-03-16 20:20:39 --> Helper loaded: url_helper
INFO - 2022-03-16 20:20:39 --> Helper loaded: form_helper
INFO - 2022-03-16 20:20:39 --> Database Driver Class Initialized
INFO - 2022-03-16 20:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:20:39 --> Controller Class Initialized
INFO - 2022-03-16 20:20:39 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:20:39 --> Final output sent to browser
INFO - 2022-03-16 20:20:44 --> Config Class Initialized
INFO - 2022-03-16 20:20:44 --> Hooks Class Initialized
INFO - 2022-03-16 20:20:44 --> Utf8 Class Initialized
INFO - 2022-03-16 20:20:44 --> URI Class Initialized
INFO - 2022-03-16 20:20:44 --> Router Class Initialized
INFO - 2022-03-16 20:20:44 --> Output Class Initialized
INFO - 2022-03-16 20:20:44 --> Security Class Initialized
INFO - 2022-03-16 20:20:44 --> Input Class Initialized
INFO - 2022-03-16 20:20:44 --> Language Class Initialized
INFO - 2022-03-16 20:20:44 --> Loader Class Initialized
INFO - 2022-03-16 20:20:44 --> Helper loaded: url_helper
INFO - 2022-03-16 20:20:45 --> Helper loaded: form_helper
INFO - 2022-03-16 20:20:45 --> Database Driver Class Initialized
INFO - 2022-03-16 20:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:20:45 --> Controller Class Initialized
INFO - 2022-03-16 20:20:45 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:20:45 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:20:45 --> Form Validation Class Initialized
INFO - 2022-03-16 20:20:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:20:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:20:45 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:20:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:20:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:20:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:20:45 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:20:45 --> Final output sent to browser
INFO - 2022-03-16 20:26:49 --> Config Class Initialized
INFO - 2022-03-16 20:26:49 --> Hooks Class Initialized
INFO - 2022-03-16 20:26:49 --> Utf8 Class Initialized
INFO - 2022-03-16 20:26:49 --> URI Class Initialized
INFO - 2022-03-16 20:26:49 --> Router Class Initialized
INFO - 2022-03-16 20:26:49 --> Output Class Initialized
INFO - 2022-03-16 20:26:49 --> Security Class Initialized
INFO - 2022-03-16 20:26:49 --> Input Class Initialized
INFO - 2022-03-16 20:26:49 --> Language Class Initialized
INFO - 2022-03-16 20:26:49 --> Loader Class Initialized
INFO - 2022-03-16 20:26:49 --> Helper loaded: url_helper
INFO - 2022-03-16 20:26:49 --> Helper loaded: form_helper
INFO - 2022-03-16 20:26:49 --> Database Driver Class Initialized
INFO - 2022-03-16 20:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:26:49 --> Controller Class Initialized
INFO - 2022-03-16 20:26:49 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:26:49 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:26:49 --> Form Validation Class Initialized
INFO - 2022-03-16 20:26:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:26:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:26:49 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:26:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:26:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:26:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:26:49 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:26:49 --> Final output sent to browser
INFO - 2022-03-16 20:26:53 --> Config Class Initialized
INFO - 2022-03-16 20:26:53 --> Hooks Class Initialized
INFO - 2022-03-16 20:26:53 --> Utf8 Class Initialized
INFO - 2022-03-16 20:26:53 --> URI Class Initialized
INFO - 2022-03-16 20:26:53 --> Router Class Initialized
INFO - 2022-03-16 20:26:53 --> Output Class Initialized
INFO - 2022-03-16 20:26:53 --> Security Class Initialized
INFO - 2022-03-16 20:26:53 --> Input Class Initialized
INFO - 2022-03-16 20:26:53 --> Language Class Initialized
INFO - 2022-03-16 20:26:53 --> Loader Class Initialized
INFO - 2022-03-16 20:26:53 --> Helper loaded: url_helper
INFO - 2022-03-16 20:26:53 --> Helper loaded: form_helper
INFO - 2022-03-16 20:26:53 --> Database Driver Class Initialized
INFO - 2022-03-16 20:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:26:53 --> Controller Class Initialized
INFO - 2022-03-16 20:26:53 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:26:53 --> Final output sent to browser
INFO - 2022-03-16 20:26:58 --> Config Class Initialized
INFO - 2022-03-16 20:26:58 --> Hooks Class Initialized
INFO - 2022-03-16 20:26:58 --> Utf8 Class Initialized
INFO - 2022-03-16 20:26:58 --> URI Class Initialized
INFO - 2022-03-16 20:26:58 --> Router Class Initialized
INFO - 2022-03-16 20:26:58 --> Output Class Initialized
INFO - 2022-03-16 20:26:58 --> Security Class Initialized
INFO - 2022-03-16 20:26:58 --> Input Class Initialized
INFO - 2022-03-16 20:26:58 --> Language Class Initialized
INFO - 2022-03-16 20:26:58 --> Loader Class Initialized
INFO - 2022-03-16 20:26:58 --> Helper loaded: url_helper
INFO - 2022-03-16 20:26:58 --> Helper loaded: form_helper
INFO - 2022-03-16 20:26:58 --> Database Driver Class Initialized
INFO - 2022-03-16 20:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:26:58 --> Controller Class Initialized
INFO - 2022-03-16 20:26:58 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:26:58 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:26:58 --> Form Validation Class Initialized
INFO - 2022-03-16 20:26:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:26:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:26:58 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:26:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:26:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:26:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:26:58 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:26:58 --> Final output sent to browser
INFO - 2022-03-16 20:29:58 --> Config Class Initialized
INFO - 2022-03-16 20:29:58 --> Hooks Class Initialized
INFO - 2022-03-16 20:29:58 --> Utf8 Class Initialized
INFO - 2022-03-16 20:29:58 --> URI Class Initialized
INFO - 2022-03-16 20:29:58 --> Router Class Initialized
INFO - 2022-03-16 20:29:58 --> Output Class Initialized
INFO - 2022-03-16 20:29:58 --> Security Class Initialized
INFO - 2022-03-16 20:29:58 --> Input Class Initialized
INFO - 2022-03-16 20:29:58 --> Language Class Initialized
INFO - 2022-03-16 20:29:58 --> Loader Class Initialized
INFO - 2022-03-16 20:29:58 --> Helper loaded: url_helper
INFO - 2022-03-16 20:29:58 --> Helper loaded: form_helper
INFO - 2022-03-16 20:29:58 --> Database Driver Class Initialized
INFO - 2022-03-16 20:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:29:58 --> Controller Class Initialized
INFO - 2022-03-16 20:29:58 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:29:58 --> Final output sent to browser
INFO - 2022-03-16 20:30:00 --> Config Class Initialized
INFO - 2022-03-16 20:30:00 --> Hooks Class Initialized
INFO - 2022-03-16 20:30:00 --> Utf8 Class Initialized
INFO - 2022-03-16 20:30:00 --> URI Class Initialized
INFO - 2022-03-16 20:30:00 --> Router Class Initialized
INFO - 2022-03-16 20:30:00 --> Output Class Initialized
INFO - 2022-03-16 20:30:00 --> Security Class Initialized
INFO - 2022-03-16 20:30:00 --> Input Class Initialized
INFO - 2022-03-16 20:30:00 --> Language Class Initialized
INFO - 2022-03-16 20:30:00 --> Loader Class Initialized
INFO - 2022-03-16 20:30:00 --> Helper loaded: url_helper
INFO - 2022-03-16 20:30:00 --> Helper loaded: form_helper
INFO - 2022-03-16 20:30:00 --> Database Driver Class Initialized
INFO - 2022-03-16 20:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:30:00 --> Controller Class Initialized
INFO - 2022-03-16 20:30:00 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:30:00 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:30:00 --> Form Validation Class Initialized
INFO - 2022-03-16 20:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:30:00 --> Final output sent to browser
INFO - 2022-03-16 20:30:14 --> Config Class Initialized
INFO - 2022-03-16 20:30:14 --> Hooks Class Initialized
INFO - 2022-03-16 20:30:14 --> Utf8 Class Initialized
INFO - 2022-03-16 20:30:14 --> URI Class Initialized
INFO - 2022-03-16 20:30:14 --> Router Class Initialized
INFO - 2022-03-16 20:30:14 --> Output Class Initialized
INFO - 2022-03-16 20:30:14 --> Security Class Initialized
INFO - 2022-03-16 20:30:14 --> Input Class Initialized
INFO - 2022-03-16 20:30:14 --> Language Class Initialized
INFO - 2022-03-16 20:30:14 --> Loader Class Initialized
INFO - 2022-03-16 20:30:15 --> Helper loaded: url_helper
INFO - 2022-03-16 20:30:15 --> Helper loaded: form_helper
INFO - 2022-03-16 20:30:15 --> Database Driver Class Initialized
INFO - 2022-03-16 20:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:30:15 --> Controller Class Initialized
INFO - 2022-03-16 20:30:15 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:30:15 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:30:15 --> Form Validation Class Initialized
INFO - 2022-03-16 20:30:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:30:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:30:15 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:30:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:30:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:30:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:30:15 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:30:15 --> Final output sent to browser
INFO - 2022-03-16 20:30:47 --> Config Class Initialized
INFO - 2022-03-16 20:30:47 --> Hooks Class Initialized
INFO - 2022-03-16 20:30:47 --> Utf8 Class Initialized
INFO - 2022-03-16 20:30:47 --> URI Class Initialized
INFO - 2022-03-16 20:30:47 --> Router Class Initialized
INFO - 2022-03-16 20:30:48 --> Output Class Initialized
INFO - 2022-03-16 20:30:48 --> Security Class Initialized
INFO - 2022-03-16 20:30:48 --> Input Class Initialized
INFO - 2022-03-16 20:30:48 --> Language Class Initialized
INFO - 2022-03-16 20:30:48 --> Loader Class Initialized
INFO - 2022-03-16 20:30:48 --> Helper loaded: url_helper
INFO - 2022-03-16 20:30:48 --> Helper loaded: form_helper
INFO - 2022-03-16 20:30:48 --> Database Driver Class Initialized
INFO - 2022-03-16 20:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:30:48 --> Controller Class Initialized
INFO - 2022-03-16 20:30:48 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:30:48 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:30:48 --> Form Validation Class Initialized
INFO - 2022-03-16 20:30:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:30:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:30:48 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-16 20:30:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:30:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:30:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:30:48 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:30:48 --> Final output sent to browser
INFO - 2022-03-16 20:30:53 --> Config Class Initialized
INFO - 2022-03-16 20:30:53 --> Hooks Class Initialized
INFO - 2022-03-16 20:30:53 --> Utf8 Class Initialized
INFO - 2022-03-16 20:30:53 --> URI Class Initialized
INFO - 2022-03-16 20:30:53 --> Router Class Initialized
INFO - 2022-03-16 20:30:53 --> Output Class Initialized
INFO - 2022-03-16 20:30:53 --> Security Class Initialized
INFO - 2022-03-16 20:30:53 --> Input Class Initialized
INFO - 2022-03-16 20:30:53 --> Language Class Initialized
INFO - 2022-03-16 20:30:53 --> Loader Class Initialized
INFO - 2022-03-16 20:30:53 --> Helper loaded: url_helper
INFO - 2022-03-16 20:30:53 --> Helper loaded: form_helper
INFO - 2022-03-16 20:30:53 --> Database Driver Class Initialized
INFO - 2022-03-16 20:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:30:53 --> Controller Class Initialized
INFO - 2022-03-16 20:30:53 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:30:53 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:30:53 --> Form Validation Class Initialized
INFO - 2022-03-16 20:30:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:30:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:30:53 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:30:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:30:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:30:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:30:53 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:30:53 --> Final output sent to browser
INFO - 2022-03-16 20:31:52 --> Config Class Initialized
INFO - 2022-03-16 20:31:52 --> Hooks Class Initialized
INFO - 2022-03-16 20:31:53 --> Utf8 Class Initialized
INFO - 2022-03-16 20:31:53 --> URI Class Initialized
INFO - 2022-03-16 20:31:53 --> Router Class Initialized
INFO - 2022-03-16 20:31:53 --> Output Class Initialized
INFO - 2022-03-16 20:31:53 --> Security Class Initialized
INFO - 2022-03-16 20:31:53 --> Input Class Initialized
INFO - 2022-03-16 20:31:53 --> Language Class Initialized
INFO - 2022-03-16 20:31:53 --> Loader Class Initialized
INFO - 2022-03-16 20:31:53 --> Helper loaded: url_helper
INFO - 2022-03-16 20:31:53 --> Helper loaded: form_helper
INFO - 2022-03-16 20:31:53 --> Database Driver Class Initialized
INFO - 2022-03-16 20:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:31:53 --> Controller Class Initialized
INFO - 2022-03-16 20:31:53 --> Model "M_tutor" initialized
INFO - 2022-03-16 20:31:53 --> Final output sent to browser
INFO - 2022-03-16 20:31:54 --> Config Class Initialized
INFO - 2022-03-16 20:31:54 --> Hooks Class Initialized
INFO - 2022-03-16 20:31:54 --> Utf8 Class Initialized
INFO - 2022-03-16 20:31:54 --> URI Class Initialized
INFO - 2022-03-16 20:31:54 --> Router Class Initialized
INFO - 2022-03-16 20:31:54 --> Output Class Initialized
INFO - 2022-03-16 20:31:54 --> Security Class Initialized
INFO - 2022-03-16 20:31:54 --> Input Class Initialized
INFO - 2022-03-16 20:31:54 --> Language Class Initialized
INFO - 2022-03-16 20:31:54 --> Loader Class Initialized
INFO - 2022-03-16 20:31:54 --> Helper loaded: url_helper
INFO - 2022-03-16 20:31:54 --> Helper loaded: form_helper
INFO - 2022-03-16 20:31:54 --> Database Driver Class Initialized
INFO - 2022-03-16 20:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 20:31:54 --> Controller Class Initialized
INFO - 2022-03-16 20:31:54 --> Model "M_todo_group" initialized
INFO - 2022-03-16 20:31:54 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-16 20:31:54 --> Form Validation Class Initialized
INFO - 2022-03-16 20:31:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-16 20:31:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-16 20:31:54 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-16 20:31:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-16 20:31:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-16 20:31:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-16 20:31:54 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-16 20:31:54 --> Final output sent to browser
