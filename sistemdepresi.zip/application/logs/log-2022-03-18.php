<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-18 03:24:25 --> Config Class Initialized
INFO - 2022-03-18 03:24:25 --> Hooks Class Initialized
INFO - 2022-03-18 03:24:25 --> Utf8 Class Initialized
INFO - 2022-03-18 03:24:25 --> URI Class Initialized
INFO - 2022-03-18 03:24:25 --> Router Class Initialized
INFO - 2022-03-18 03:24:25 --> Output Class Initialized
INFO - 2022-03-18 03:24:25 --> Security Class Initialized
INFO - 2022-03-18 03:24:25 --> Input Class Initialized
INFO - 2022-03-18 03:24:25 --> Language Class Initialized
INFO - 2022-03-18 03:24:25 --> Loader Class Initialized
INFO - 2022-03-18 03:24:25 --> Helper loaded: url_helper
INFO - 2022-03-18 03:24:25 --> Helper loaded: form_helper
INFO - 2022-03-18 03:24:25 --> Database Driver Class Initialized
INFO - 2022-03-18 03:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:24:25 --> Controller Class Initialized
INFO - 2022-03-18 03:24:25 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:24:25 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:24:25 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:24:25 --> Form Validation Class Initialized
INFO - 2022-03-18 03:24:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:24:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:24:25 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:24:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:24:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:24:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:24:25 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:24:25 --> Final output sent to browser
INFO - 2022-03-18 03:26:57 --> Config Class Initialized
INFO - 2022-03-18 03:26:57 --> Hooks Class Initialized
INFO - 2022-03-18 03:26:57 --> Utf8 Class Initialized
INFO - 2022-03-18 03:26:57 --> URI Class Initialized
INFO - 2022-03-18 03:26:57 --> Router Class Initialized
INFO - 2022-03-18 03:26:57 --> Output Class Initialized
INFO - 2022-03-18 03:26:57 --> Security Class Initialized
INFO - 2022-03-18 03:26:57 --> Input Class Initialized
INFO - 2022-03-18 03:26:57 --> Language Class Initialized
ERROR - 2022-03-18 03:26:57 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\laragon\www\list-todo\application\controllers\C_todo_group.php 58
INFO - 2022-03-18 03:27:19 --> Config Class Initialized
INFO - 2022-03-18 03:27:19 --> Hooks Class Initialized
INFO - 2022-03-18 03:27:19 --> Utf8 Class Initialized
INFO - 2022-03-18 03:27:19 --> URI Class Initialized
INFO - 2022-03-18 03:27:19 --> Router Class Initialized
INFO - 2022-03-18 03:27:19 --> Output Class Initialized
INFO - 2022-03-18 03:27:19 --> Security Class Initialized
INFO - 2022-03-18 03:27:20 --> Input Class Initialized
INFO - 2022-03-18 03:27:20 --> Language Class Initialized
INFO - 2022-03-18 03:27:20 --> Loader Class Initialized
INFO - 2022-03-18 03:27:20 --> Helper loaded: url_helper
INFO - 2022-03-18 03:27:20 --> Helper loaded: form_helper
INFO - 2022-03-18 03:27:20 --> Database Driver Class Initialized
INFO - 2022-03-18 03:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:27:20 --> Controller Class Initialized
INFO - 2022-03-18 03:27:20 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:27:20 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:27:20 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:27:20 --> Form Validation Class Initialized
INFO - 2022-03-18 03:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_tambah.php
INFO - 2022-03-18 03:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:27:21 --> Final output sent to browser
INFO - 2022-03-18 03:27:26 --> Config Class Initialized
INFO - 2022-03-18 03:27:26 --> Hooks Class Initialized
INFO - 2022-03-18 03:27:26 --> Utf8 Class Initialized
INFO - 2022-03-18 03:27:26 --> URI Class Initialized
INFO - 2022-03-18 03:27:26 --> Router Class Initialized
INFO - 2022-03-18 03:27:26 --> Output Class Initialized
INFO - 2022-03-18 03:27:27 --> Security Class Initialized
INFO - 2022-03-18 03:27:27 --> Input Class Initialized
INFO - 2022-03-18 03:27:27 --> Language Class Initialized
INFO - 2022-03-18 03:27:27 --> Loader Class Initialized
INFO - 2022-03-18 03:27:27 --> Helper loaded: url_helper
INFO - 2022-03-18 03:27:27 --> Helper loaded: form_helper
INFO - 2022-03-18 03:27:27 --> Database Driver Class Initialized
INFO - 2022-03-18 03:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:27:27 --> Controller Class Initialized
INFO - 2022-03-18 03:27:27 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:27:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:27:27 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:27:27 --> Form Validation Class Initialized
INFO - 2022-03-18 03:27:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:27:27 --> Config Class Initialized
INFO - 2022-03-18 03:27:27 --> Hooks Class Initialized
INFO - 2022-03-18 03:27:27 --> Utf8 Class Initialized
INFO - 2022-03-18 03:27:27 --> URI Class Initialized
INFO - 2022-03-18 03:27:27 --> Router Class Initialized
INFO - 2022-03-18 03:27:27 --> Output Class Initialized
INFO - 2022-03-18 03:27:27 --> Security Class Initialized
INFO - 2022-03-18 03:27:27 --> Input Class Initialized
INFO - 2022-03-18 03:27:27 --> Language Class Initialized
INFO - 2022-03-18 03:27:27 --> Loader Class Initialized
INFO - 2022-03-18 03:27:27 --> Helper loaded: url_helper
INFO - 2022-03-18 03:27:27 --> Helper loaded: form_helper
INFO - 2022-03-18 03:27:27 --> Database Driver Class Initialized
INFO - 2022-03-18 03:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:27:27 --> Controller Class Initialized
INFO - 2022-03-18 03:27:27 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:27:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:27:27 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:27:27 --> Form Validation Class Initialized
INFO - 2022-03-18 03:27:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:27:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:27:27 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:27:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:27:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:27:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:27:27 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:27:27 --> Final output sent to browser
INFO - 2022-03-18 03:27:30 --> Config Class Initialized
INFO - 2022-03-18 03:27:30 --> Hooks Class Initialized
INFO - 2022-03-18 03:27:30 --> Utf8 Class Initialized
INFO - 2022-03-18 03:27:30 --> URI Class Initialized
INFO - 2022-03-18 03:27:30 --> Router Class Initialized
INFO - 2022-03-18 03:27:30 --> Output Class Initialized
INFO - 2022-03-18 03:27:30 --> Security Class Initialized
INFO - 2022-03-18 03:27:30 --> Input Class Initialized
INFO - 2022-03-18 03:27:30 --> Language Class Initialized
INFO - 2022-03-18 03:27:30 --> Loader Class Initialized
INFO - 2022-03-18 03:27:30 --> Helper loaded: url_helper
INFO - 2022-03-18 03:27:30 --> Helper loaded: form_helper
INFO - 2022-03-18 03:27:30 --> Database Driver Class Initialized
INFO - 2022-03-18 03:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:27:30 --> Controller Class Initialized
INFO - 2022-03-18 03:27:30 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:27:30 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:27:30 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:27:30 --> Form Validation Class Initialized
INFO - 2022-03-18 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:27:30 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:27:30 --> Final output sent to browser
INFO - 2022-03-18 03:27:36 --> Config Class Initialized
INFO - 2022-03-18 03:27:36 --> Hooks Class Initialized
INFO - 2022-03-18 03:27:36 --> Utf8 Class Initialized
INFO - 2022-03-18 03:27:36 --> URI Class Initialized
INFO - 2022-03-18 03:27:36 --> Router Class Initialized
INFO - 2022-03-18 03:27:36 --> Output Class Initialized
INFO - 2022-03-18 03:27:36 --> Security Class Initialized
INFO - 2022-03-18 03:27:36 --> Input Class Initialized
INFO - 2022-03-18 03:27:36 --> Language Class Initialized
INFO - 2022-03-18 03:27:37 --> Loader Class Initialized
INFO - 2022-03-18 03:27:37 --> Helper loaded: url_helper
INFO - 2022-03-18 03:27:37 --> Helper loaded: form_helper
INFO - 2022-03-18 03:27:37 --> Database Driver Class Initialized
INFO - 2022-03-18 03:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:27:37 --> Controller Class Initialized
INFO - 2022-03-18 03:27:37 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:27:37 --> Final output sent to browser
INFO - 2022-03-18 03:27:39 --> Config Class Initialized
INFO - 2022-03-18 03:27:39 --> Hooks Class Initialized
INFO - 2022-03-18 03:27:39 --> Utf8 Class Initialized
INFO - 2022-03-18 03:27:39 --> URI Class Initialized
INFO - 2022-03-18 03:27:39 --> Router Class Initialized
INFO - 2022-03-18 03:27:39 --> Output Class Initialized
INFO - 2022-03-18 03:27:39 --> Security Class Initialized
INFO - 2022-03-18 03:27:39 --> Input Class Initialized
INFO - 2022-03-18 03:27:39 --> Language Class Initialized
INFO - 2022-03-18 03:27:39 --> Loader Class Initialized
INFO - 2022-03-18 03:27:39 --> Helper loaded: url_helper
INFO - 2022-03-18 03:27:39 --> Helper loaded: form_helper
INFO - 2022-03-18 03:27:39 --> Database Driver Class Initialized
INFO - 2022-03-18 03:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:27:39 --> Controller Class Initialized
INFO - 2022-03-18 03:27:39 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:27:39 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:27:39 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:27:39 --> Form Validation Class Initialized
INFO - 2022-03-18 03:27:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:27:39 --> Config Class Initialized
INFO - 2022-03-18 03:27:39 --> Hooks Class Initialized
INFO - 2022-03-18 03:27:39 --> Utf8 Class Initialized
INFO - 2022-03-18 03:27:39 --> URI Class Initialized
INFO - 2022-03-18 03:27:39 --> Router Class Initialized
INFO - 2022-03-18 03:27:39 --> Output Class Initialized
INFO - 2022-03-18 03:27:39 --> Security Class Initialized
INFO - 2022-03-18 03:27:39 --> Input Class Initialized
INFO - 2022-03-18 03:27:39 --> Language Class Initialized
INFO - 2022-03-18 03:27:39 --> Loader Class Initialized
INFO - 2022-03-18 03:27:39 --> Helper loaded: url_helper
INFO - 2022-03-18 03:27:39 --> Helper loaded: form_helper
INFO - 2022-03-18 03:27:39 --> Database Driver Class Initialized
INFO - 2022-03-18 03:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:27:39 --> Controller Class Initialized
INFO - 2022-03-18 03:27:39 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:27:39 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:27:39 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:27:39 --> Form Validation Class Initialized
INFO - 2022-03-18 03:27:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:27:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:27:39 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:27:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:27:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:27:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:27:39 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:27:39 --> Final output sent to browser
INFO - 2022-03-18 03:27:43 --> Config Class Initialized
INFO - 2022-03-18 03:27:43 --> Hooks Class Initialized
INFO - 2022-03-18 03:27:43 --> Utf8 Class Initialized
INFO - 2022-03-18 03:27:43 --> URI Class Initialized
INFO - 2022-03-18 03:27:43 --> Router Class Initialized
INFO - 2022-03-18 03:27:43 --> Output Class Initialized
INFO - 2022-03-18 03:27:43 --> Security Class Initialized
INFO - 2022-03-18 03:27:43 --> Input Class Initialized
INFO - 2022-03-18 03:27:43 --> Language Class Initialized
INFO - 2022-03-18 03:27:43 --> Loader Class Initialized
INFO - 2022-03-18 03:27:43 --> Helper loaded: url_helper
INFO - 2022-03-18 03:27:43 --> Helper loaded: form_helper
INFO - 2022-03-18 03:27:43 --> Database Driver Class Initialized
INFO - 2022-03-18 03:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:27:43 --> Controller Class Initialized
INFO - 2022-03-18 03:27:43 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:27:43 --> Final output sent to browser
INFO - 2022-03-18 03:27:48 --> Config Class Initialized
INFO - 2022-03-18 03:27:48 --> Hooks Class Initialized
INFO - 2022-03-18 03:27:48 --> Utf8 Class Initialized
INFO - 2022-03-18 03:27:48 --> URI Class Initialized
INFO - 2022-03-18 03:27:48 --> Router Class Initialized
INFO - 2022-03-18 03:27:48 --> Output Class Initialized
INFO - 2022-03-18 03:27:48 --> Security Class Initialized
INFO - 2022-03-18 03:27:48 --> Input Class Initialized
INFO - 2022-03-18 03:27:48 --> Language Class Initialized
INFO - 2022-03-18 03:27:48 --> Loader Class Initialized
INFO - 2022-03-18 03:27:48 --> Helper loaded: url_helper
INFO - 2022-03-18 03:27:48 --> Helper loaded: form_helper
INFO - 2022-03-18 03:27:48 --> Database Driver Class Initialized
INFO - 2022-03-18 03:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:27:48 --> Controller Class Initialized
INFO - 2022-03-18 03:27:48 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:27:48 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:27:48 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:27:48 --> Form Validation Class Initialized
INFO - 2022-03-18 03:27:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:27:48 --> Config Class Initialized
INFO - 2022-03-18 03:27:48 --> Hooks Class Initialized
INFO - 2022-03-18 03:27:48 --> Utf8 Class Initialized
INFO - 2022-03-18 03:27:48 --> URI Class Initialized
INFO - 2022-03-18 03:27:48 --> Router Class Initialized
INFO - 2022-03-18 03:27:48 --> Output Class Initialized
INFO - 2022-03-18 03:27:48 --> Security Class Initialized
INFO - 2022-03-18 03:27:48 --> Input Class Initialized
INFO - 2022-03-18 03:27:48 --> Language Class Initialized
INFO - 2022-03-18 03:27:48 --> Loader Class Initialized
INFO - 2022-03-18 03:27:48 --> Helper loaded: url_helper
INFO - 2022-03-18 03:27:48 --> Helper loaded: form_helper
INFO - 2022-03-18 03:27:48 --> Database Driver Class Initialized
INFO - 2022-03-18 03:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:27:48 --> Controller Class Initialized
INFO - 2022-03-18 03:27:48 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:27:48 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:27:48 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:27:48 --> Form Validation Class Initialized
INFO - 2022-03-18 03:27:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:27:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:27:48 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:27:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:27:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:27:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:27:48 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:27:48 --> Final output sent to browser
INFO - 2022-03-18 03:28:26 --> Config Class Initialized
INFO - 2022-03-18 03:28:26 --> Hooks Class Initialized
INFO - 2022-03-18 03:28:26 --> Utf8 Class Initialized
INFO - 2022-03-18 03:28:26 --> URI Class Initialized
INFO - 2022-03-18 03:28:26 --> Router Class Initialized
INFO - 2022-03-18 03:28:26 --> Output Class Initialized
INFO - 2022-03-18 03:28:26 --> Security Class Initialized
INFO - 2022-03-18 03:28:26 --> Input Class Initialized
INFO - 2022-03-18 03:28:26 --> Language Class Initialized
INFO - 2022-03-18 03:28:26 --> Loader Class Initialized
INFO - 2022-03-18 03:28:26 --> Helper loaded: url_helper
INFO - 2022-03-18 03:28:26 --> Helper loaded: form_helper
INFO - 2022-03-18 03:28:26 --> Database Driver Class Initialized
INFO - 2022-03-18 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:28:26 --> Controller Class Initialized
INFO - 2022-03-18 03:28:26 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:28:26 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:28:26 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:28:26 --> Form Validation Class Initialized
INFO - 2022-03-18 03:28:26 --> Config Class Initialized
INFO - 2022-03-18 03:28:26 --> Hooks Class Initialized
INFO - 2022-03-18 03:28:26 --> Utf8 Class Initialized
INFO - 2022-03-18 03:28:26 --> URI Class Initialized
INFO - 2022-03-18 03:28:26 --> Router Class Initialized
INFO - 2022-03-18 03:28:26 --> Output Class Initialized
INFO - 2022-03-18 03:28:26 --> Security Class Initialized
INFO - 2022-03-18 03:28:26 --> Input Class Initialized
INFO - 2022-03-18 03:28:26 --> Language Class Initialized
INFO - 2022-03-18 03:28:26 --> Loader Class Initialized
INFO - 2022-03-18 03:28:26 --> Helper loaded: url_helper
INFO - 2022-03-18 03:28:26 --> Helper loaded: form_helper
INFO - 2022-03-18 03:28:26 --> Database Driver Class Initialized
INFO - 2022-03-18 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:28:26 --> Controller Class Initialized
INFO - 2022-03-18 03:28:26 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:28:26 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:28:26 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:28:26 --> Form Validation Class Initialized
ERROR - 2022-03-18 03:28:26 --> 404 Page Not Found: 
INFO - 2022-03-18 03:28:35 --> Config Class Initialized
INFO - 2022-03-18 03:28:35 --> Hooks Class Initialized
INFO - 2022-03-18 03:28:35 --> Utf8 Class Initialized
INFO - 2022-03-18 03:28:35 --> URI Class Initialized
INFO - 2022-03-18 03:28:35 --> Router Class Initialized
INFO - 2022-03-18 03:28:35 --> Output Class Initialized
INFO - 2022-03-18 03:28:35 --> Security Class Initialized
INFO - 2022-03-18 03:28:35 --> Input Class Initialized
INFO - 2022-03-18 03:28:35 --> Language Class Initialized
INFO - 2022-03-18 03:28:35 --> Loader Class Initialized
INFO - 2022-03-18 03:28:35 --> Helper loaded: url_helper
INFO - 2022-03-18 03:28:35 --> Helper loaded: form_helper
INFO - 2022-03-18 03:28:35 --> Database Driver Class Initialized
INFO - 2022-03-18 03:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:28:35 --> Controller Class Initialized
INFO - 2022-03-18 03:28:35 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:28:35 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:28:35 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:28:35 --> Form Validation Class Initialized
INFO - 2022-03-18 03:28:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:28:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:28:35 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:28:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:28:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:28:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:28:35 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:28:35 --> Final output sent to browser
INFO - 2022-03-18 03:28:52 --> Config Class Initialized
INFO - 2022-03-18 03:28:52 --> Hooks Class Initialized
INFO - 2022-03-18 03:28:52 --> Utf8 Class Initialized
INFO - 2022-03-18 03:28:52 --> URI Class Initialized
INFO - 2022-03-18 03:28:52 --> Router Class Initialized
INFO - 2022-03-18 03:28:52 --> Output Class Initialized
INFO - 2022-03-18 03:28:52 --> Security Class Initialized
INFO - 2022-03-18 03:28:52 --> Input Class Initialized
INFO - 2022-03-18 03:28:52 --> Language Class Initialized
INFO - 2022-03-18 03:28:52 --> Loader Class Initialized
INFO - 2022-03-18 03:28:52 --> Helper loaded: url_helper
INFO - 2022-03-18 03:28:52 --> Helper loaded: form_helper
INFO - 2022-03-18 03:28:52 --> Database Driver Class Initialized
INFO - 2022-03-18 03:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:28:52 --> Controller Class Initialized
INFO - 2022-03-18 03:28:52 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:28:52 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:28:52 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:28:52 --> Form Validation Class Initialized
INFO - 2022-03-18 03:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:28:52 --> Final output sent to browser
INFO - 2022-03-18 03:29:40 --> Config Class Initialized
INFO - 2022-03-18 03:29:40 --> Hooks Class Initialized
INFO - 2022-03-18 03:29:41 --> Utf8 Class Initialized
INFO - 2022-03-18 03:29:41 --> URI Class Initialized
INFO - 2022-03-18 03:29:41 --> Router Class Initialized
INFO - 2022-03-18 03:29:41 --> Output Class Initialized
INFO - 2022-03-18 03:29:41 --> Security Class Initialized
INFO - 2022-03-18 03:29:41 --> Input Class Initialized
INFO - 2022-03-18 03:29:41 --> Language Class Initialized
INFO - 2022-03-18 03:29:41 --> Loader Class Initialized
INFO - 2022-03-18 03:29:41 --> Helper loaded: url_helper
INFO - 2022-03-18 03:29:41 --> Helper loaded: form_helper
INFO - 2022-03-18 03:29:41 --> Database Driver Class Initialized
INFO - 2022-03-18 03:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:29:41 --> Controller Class Initialized
INFO - 2022-03-18 03:29:41 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:29:41 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:29:41 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:29:41 --> Form Validation Class Initialized
INFO - 2022-03-18 03:29:41 --> Config Class Initialized
INFO - 2022-03-18 03:29:41 --> Hooks Class Initialized
INFO - 2022-03-18 03:29:41 --> Utf8 Class Initialized
INFO - 2022-03-18 03:29:41 --> URI Class Initialized
INFO - 2022-03-18 03:29:41 --> Router Class Initialized
INFO - 2022-03-18 03:29:41 --> Output Class Initialized
INFO - 2022-03-18 03:29:41 --> Security Class Initialized
INFO - 2022-03-18 03:29:41 --> Input Class Initialized
INFO - 2022-03-18 03:29:41 --> Language Class Initialized
INFO - 2022-03-18 03:29:41 --> Loader Class Initialized
INFO - 2022-03-18 03:29:41 --> Helper loaded: url_helper
INFO - 2022-03-18 03:29:41 --> Helper loaded: form_helper
INFO - 2022-03-18 03:29:41 --> Database Driver Class Initialized
INFO - 2022-03-18 03:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:29:41 --> Controller Class Initialized
INFO - 2022-03-18 03:29:41 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:29:41 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:29:41 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:29:41 --> Form Validation Class Initialized
ERROR - 2022-03-18 03:29:41 --> 404 Page Not Found: 
INFO - 2022-03-18 03:29:55 --> Config Class Initialized
INFO - 2022-03-18 03:29:55 --> Hooks Class Initialized
INFO - 2022-03-18 03:29:55 --> Utf8 Class Initialized
INFO - 2022-03-18 03:29:55 --> URI Class Initialized
INFO - 2022-03-18 03:29:55 --> Router Class Initialized
INFO - 2022-03-18 03:29:55 --> Output Class Initialized
INFO - 2022-03-18 03:29:55 --> Security Class Initialized
INFO - 2022-03-18 03:29:55 --> Input Class Initialized
INFO - 2022-03-18 03:29:55 --> Language Class Initialized
INFO - 2022-03-18 03:29:55 --> Loader Class Initialized
INFO - 2022-03-18 03:29:55 --> Helper loaded: url_helper
INFO - 2022-03-18 03:29:55 --> Helper loaded: form_helper
INFO - 2022-03-18 03:29:55 --> Database Driver Class Initialized
INFO - 2022-03-18 03:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:29:55 --> Controller Class Initialized
INFO - 2022-03-18 03:29:55 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:29:55 --> Final output sent to browser
INFO - 2022-03-18 03:29:57 --> Config Class Initialized
INFO - 2022-03-18 03:29:57 --> Hooks Class Initialized
INFO - 2022-03-18 03:29:57 --> Utf8 Class Initialized
INFO - 2022-03-18 03:29:57 --> URI Class Initialized
INFO - 2022-03-18 03:29:57 --> Router Class Initialized
INFO - 2022-03-18 03:29:57 --> Output Class Initialized
INFO - 2022-03-18 03:29:57 --> Security Class Initialized
INFO - 2022-03-18 03:29:57 --> Input Class Initialized
INFO - 2022-03-18 03:29:57 --> Language Class Initialized
INFO - 2022-03-18 03:29:57 --> Loader Class Initialized
INFO - 2022-03-18 03:29:57 --> Helper loaded: url_helper
INFO - 2022-03-18 03:29:57 --> Helper loaded: form_helper
INFO - 2022-03-18 03:29:57 --> Database Driver Class Initialized
INFO - 2022-03-18 03:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:29:57 --> Controller Class Initialized
INFO - 2022-03-18 03:29:57 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:29:57 --> Final output sent to browser
INFO - 2022-03-18 03:29:59 --> Config Class Initialized
INFO - 2022-03-18 03:29:59 --> Hooks Class Initialized
INFO - 2022-03-18 03:29:59 --> Utf8 Class Initialized
INFO - 2022-03-18 03:29:59 --> URI Class Initialized
INFO - 2022-03-18 03:29:59 --> Router Class Initialized
INFO - 2022-03-18 03:29:59 --> Output Class Initialized
INFO - 2022-03-18 03:29:59 --> Security Class Initialized
INFO - 2022-03-18 03:29:59 --> Input Class Initialized
INFO - 2022-03-18 03:29:59 --> Language Class Initialized
INFO - 2022-03-18 03:29:59 --> Loader Class Initialized
INFO - 2022-03-18 03:29:59 --> Helper loaded: url_helper
INFO - 2022-03-18 03:29:59 --> Helper loaded: form_helper
INFO - 2022-03-18 03:29:59 --> Database Driver Class Initialized
INFO - 2022-03-18 03:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:29:59 --> Controller Class Initialized
INFO - 2022-03-18 03:29:59 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:29:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:29:59 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:29:59 --> Form Validation Class Initialized
INFO - 2022-03-18 03:29:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:29:59 --> Config Class Initialized
INFO - 2022-03-18 03:29:59 --> Hooks Class Initialized
INFO - 2022-03-18 03:29:59 --> Utf8 Class Initialized
INFO - 2022-03-18 03:29:59 --> URI Class Initialized
INFO - 2022-03-18 03:29:59 --> Router Class Initialized
INFO - 2022-03-18 03:29:59 --> Output Class Initialized
INFO - 2022-03-18 03:29:59 --> Security Class Initialized
INFO - 2022-03-18 03:29:59 --> Input Class Initialized
INFO - 2022-03-18 03:29:59 --> Language Class Initialized
INFO - 2022-03-18 03:29:59 --> Loader Class Initialized
INFO - 2022-03-18 03:29:59 --> Helper loaded: url_helper
INFO - 2022-03-18 03:29:59 --> Helper loaded: form_helper
INFO - 2022-03-18 03:29:59 --> Database Driver Class Initialized
INFO - 2022-03-18 03:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:29:59 --> Controller Class Initialized
INFO - 2022-03-18 03:29:59 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:29:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:29:59 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:29:59 --> Form Validation Class Initialized
INFO - 2022-03-18 03:29:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:29:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:29:59 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:29:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:29:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:29:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:29:59 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:29:59 --> Final output sent to browser
INFO - 2022-03-18 03:30:06 --> Config Class Initialized
INFO - 2022-03-18 03:30:06 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:06 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:06 --> URI Class Initialized
INFO - 2022-03-18 03:30:06 --> Router Class Initialized
INFO - 2022-03-18 03:30:06 --> Output Class Initialized
INFO - 2022-03-18 03:30:06 --> Security Class Initialized
INFO - 2022-03-18 03:30:06 --> Input Class Initialized
INFO - 2022-03-18 03:30:06 --> Language Class Initialized
INFO - 2022-03-18 03:30:06 --> Loader Class Initialized
INFO - 2022-03-18 03:30:06 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:06 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:06 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:06 --> Controller Class Initialized
INFO - 2022-03-18 03:30:06 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:06 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:06 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:06 --> Form Validation Class Initialized
ERROR - 2022-03-18 03:30:06 --> 404 Page Not Found: 
INFO - 2022-03-18 03:30:16 --> Config Class Initialized
INFO - 2022-03-18 03:30:16 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:16 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:16 --> URI Class Initialized
INFO - 2022-03-18 03:30:16 --> Router Class Initialized
INFO - 2022-03-18 03:30:16 --> Output Class Initialized
INFO - 2022-03-18 03:30:16 --> Security Class Initialized
INFO - 2022-03-18 03:30:16 --> Input Class Initialized
INFO - 2022-03-18 03:30:16 --> Language Class Initialized
INFO - 2022-03-18 03:30:16 --> Loader Class Initialized
INFO - 2022-03-18 03:30:16 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:16 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:17 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:17 --> Controller Class Initialized
INFO - 2022-03-18 03:30:17 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:17 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:17 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:17 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:30:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:30:17 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:30:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:30:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:30:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:30:17 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:30:17 --> Final output sent to browser
INFO - 2022-03-18 03:30:19 --> Config Class Initialized
INFO - 2022-03-18 03:30:19 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:19 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:19 --> URI Class Initialized
INFO - 2022-03-18 03:30:19 --> Router Class Initialized
INFO - 2022-03-18 03:30:19 --> Output Class Initialized
INFO - 2022-03-18 03:30:19 --> Security Class Initialized
INFO - 2022-03-18 03:30:19 --> Input Class Initialized
INFO - 2022-03-18 03:30:19 --> Language Class Initialized
INFO - 2022-03-18 03:30:19 --> Loader Class Initialized
INFO - 2022-03-18 03:30:19 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:19 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:19 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:19 --> Controller Class Initialized
INFO - 2022-03-18 03:30:19 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:19 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:19 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:19 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:30:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:30:19 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:30:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:30:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:30:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:30:19 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:30:19 --> Final output sent to browser
INFO - 2022-03-18 03:30:22 --> Config Class Initialized
INFO - 2022-03-18 03:30:22 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:22 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:22 --> URI Class Initialized
INFO - 2022-03-18 03:30:22 --> Router Class Initialized
INFO - 2022-03-18 03:30:22 --> Output Class Initialized
INFO - 2022-03-18 03:30:22 --> Security Class Initialized
INFO - 2022-03-18 03:30:22 --> Input Class Initialized
INFO - 2022-03-18 03:30:22 --> Language Class Initialized
INFO - 2022-03-18 03:30:22 --> Loader Class Initialized
INFO - 2022-03-18 03:30:22 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:22 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:22 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:22 --> Controller Class Initialized
INFO - 2022-03-18 03:30:22 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:22 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:22 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:22 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:30:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:30:22 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:30:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:30:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:30:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:30:22 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:30:22 --> Final output sent to browser
INFO - 2022-03-18 03:30:24 --> Config Class Initialized
INFO - 2022-03-18 03:30:24 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:24 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:24 --> URI Class Initialized
INFO - 2022-03-18 03:30:24 --> Router Class Initialized
INFO - 2022-03-18 03:30:24 --> Output Class Initialized
INFO - 2022-03-18 03:30:24 --> Security Class Initialized
INFO - 2022-03-18 03:30:24 --> Input Class Initialized
INFO - 2022-03-18 03:30:24 --> Language Class Initialized
INFO - 2022-03-18 03:30:24 --> Loader Class Initialized
INFO - 2022-03-18 03:30:24 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:24 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:24 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:24 --> Controller Class Initialized
INFO - 2022-03-18 03:30:24 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:24 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:24 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:24 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:24 --> Config Class Initialized
INFO - 2022-03-18 03:30:24 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:24 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:24 --> URI Class Initialized
INFO - 2022-03-18 03:30:24 --> Router Class Initialized
INFO - 2022-03-18 03:30:24 --> Output Class Initialized
INFO - 2022-03-18 03:30:24 --> Security Class Initialized
INFO - 2022-03-18 03:30:24 --> Input Class Initialized
INFO - 2022-03-18 03:30:24 --> Language Class Initialized
INFO - 2022-03-18 03:30:24 --> Loader Class Initialized
INFO - 2022-03-18 03:30:24 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:25 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:25 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:25 --> Controller Class Initialized
INFO - 2022-03-18 03:30:25 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:25 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:25 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:25 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:30:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:30:25 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:30:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:30:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:30:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:30:25 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:30:25 --> Final output sent to browser
INFO - 2022-03-18 03:30:35 --> Config Class Initialized
INFO - 2022-03-18 03:30:35 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:35 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:35 --> URI Class Initialized
INFO - 2022-03-18 03:30:35 --> Router Class Initialized
INFO - 2022-03-18 03:30:35 --> Output Class Initialized
INFO - 2022-03-18 03:30:35 --> Security Class Initialized
INFO - 2022-03-18 03:30:35 --> Input Class Initialized
INFO - 2022-03-18 03:30:35 --> Language Class Initialized
INFO - 2022-03-18 03:30:35 --> Loader Class Initialized
INFO - 2022-03-18 03:30:35 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:35 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:35 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:35 --> Controller Class Initialized
INFO - 2022-03-18 03:30:35 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:35 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:35 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:35 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:30:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:30:35 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_tambah.php
INFO - 2022-03-18 03:30:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:30:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:30:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:30:35 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:30:35 --> Final output sent to browser
INFO - 2022-03-18 03:30:40 --> Config Class Initialized
INFO - 2022-03-18 03:30:40 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:40 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:40 --> URI Class Initialized
INFO - 2022-03-18 03:30:40 --> Router Class Initialized
INFO - 2022-03-18 03:30:40 --> Output Class Initialized
INFO - 2022-03-18 03:30:40 --> Security Class Initialized
INFO - 2022-03-18 03:30:40 --> Input Class Initialized
INFO - 2022-03-18 03:30:40 --> Language Class Initialized
INFO - 2022-03-18 03:30:40 --> Loader Class Initialized
INFO - 2022-03-18 03:30:40 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:40 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:40 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:40 --> Controller Class Initialized
INFO - 2022-03-18 03:30:40 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:40 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:40 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:40 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:30:41 --> Config Class Initialized
INFO - 2022-03-18 03:30:41 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:41 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:41 --> URI Class Initialized
INFO - 2022-03-18 03:30:41 --> Router Class Initialized
INFO - 2022-03-18 03:30:41 --> Output Class Initialized
INFO - 2022-03-18 03:30:41 --> Security Class Initialized
INFO - 2022-03-18 03:30:41 --> Input Class Initialized
INFO - 2022-03-18 03:30:41 --> Language Class Initialized
INFO - 2022-03-18 03:30:41 --> Loader Class Initialized
INFO - 2022-03-18 03:30:41 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:41 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:41 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:41 --> Controller Class Initialized
INFO - 2022-03-18 03:30:41 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:41 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:41 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:41 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:30:41 --> Final output sent to browser
INFO - 2022-03-18 03:30:43 --> Config Class Initialized
INFO - 2022-03-18 03:30:43 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:43 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:43 --> URI Class Initialized
INFO - 2022-03-18 03:30:43 --> Router Class Initialized
INFO - 2022-03-18 03:30:43 --> Output Class Initialized
INFO - 2022-03-18 03:30:43 --> Security Class Initialized
INFO - 2022-03-18 03:30:43 --> Input Class Initialized
INFO - 2022-03-18 03:30:43 --> Language Class Initialized
INFO - 2022-03-18 03:30:43 --> Loader Class Initialized
INFO - 2022-03-18 03:30:43 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:43 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:43 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:43 --> Controller Class Initialized
INFO - 2022-03-18 03:30:43 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:43 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:43 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:43 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:30:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:30:43 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_tambah.php
INFO - 2022-03-18 03:30:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:30:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:30:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:30:43 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:30:43 --> Final output sent to browser
INFO - 2022-03-18 03:30:49 --> Config Class Initialized
INFO - 2022-03-18 03:30:49 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:49 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:49 --> URI Class Initialized
INFO - 2022-03-18 03:30:49 --> Router Class Initialized
INFO - 2022-03-18 03:30:49 --> Output Class Initialized
INFO - 2022-03-18 03:30:49 --> Security Class Initialized
INFO - 2022-03-18 03:30:49 --> Input Class Initialized
INFO - 2022-03-18 03:30:49 --> Language Class Initialized
INFO - 2022-03-18 03:30:49 --> Loader Class Initialized
INFO - 2022-03-18 03:30:49 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:49 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:49 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:49 --> Controller Class Initialized
INFO - 2022-03-18 03:30:49 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:49 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:49 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:49 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:30:49 --> Config Class Initialized
INFO - 2022-03-18 03:30:49 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:49 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:49 --> URI Class Initialized
INFO - 2022-03-18 03:30:49 --> Router Class Initialized
INFO - 2022-03-18 03:30:49 --> Output Class Initialized
INFO - 2022-03-18 03:30:49 --> Security Class Initialized
INFO - 2022-03-18 03:30:49 --> Input Class Initialized
INFO - 2022-03-18 03:30:49 --> Language Class Initialized
INFO - 2022-03-18 03:30:49 --> Loader Class Initialized
INFO - 2022-03-18 03:30:49 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:49 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:49 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:49 --> Controller Class Initialized
INFO - 2022-03-18 03:30:49 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:49 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:49 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:49 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:30:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:30:49 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:30:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:30:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:30:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:30:49 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:30:49 --> Final output sent to browser
INFO - 2022-03-18 03:30:52 --> Config Class Initialized
INFO - 2022-03-18 03:30:52 --> Hooks Class Initialized
INFO - 2022-03-18 03:30:52 --> Utf8 Class Initialized
INFO - 2022-03-18 03:30:52 --> URI Class Initialized
INFO - 2022-03-18 03:30:52 --> Router Class Initialized
INFO - 2022-03-18 03:30:52 --> Output Class Initialized
INFO - 2022-03-18 03:30:52 --> Security Class Initialized
INFO - 2022-03-18 03:30:52 --> Input Class Initialized
INFO - 2022-03-18 03:30:52 --> Language Class Initialized
INFO - 2022-03-18 03:30:52 --> Loader Class Initialized
INFO - 2022-03-18 03:30:52 --> Helper loaded: url_helper
INFO - 2022-03-18 03:30:52 --> Helper loaded: form_helper
INFO - 2022-03-18 03:30:52 --> Database Driver Class Initialized
INFO - 2022-03-18 03:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:30:52 --> Controller Class Initialized
INFO - 2022-03-18 03:30:52 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:30:52 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:30:52 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:30:52 --> Form Validation Class Initialized
INFO - 2022-03-18 03:30:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:30:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:30:52 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:30:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:30:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:30:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:30:53 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:30:53 --> Final output sent to browser
INFO - 2022-03-18 03:31:00 --> Config Class Initialized
INFO - 2022-03-18 03:31:00 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:00 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:00 --> URI Class Initialized
INFO - 2022-03-18 03:31:00 --> Router Class Initialized
INFO - 2022-03-18 03:31:00 --> Output Class Initialized
INFO - 2022-03-18 03:31:00 --> Security Class Initialized
INFO - 2022-03-18 03:31:00 --> Input Class Initialized
INFO - 2022-03-18 03:31:00 --> Language Class Initialized
INFO - 2022-03-18 03:31:00 --> Loader Class Initialized
INFO - 2022-03-18 03:31:00 --> Helper loaded: url_helper
INFO - 2022-03-18 03:31:00 --> Helper loaded: form_helper
INFO - 2022-03-18 03:31:00 --> Database Driver Class Initialized
INFO - 2022-03-18 03:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:31:00 --> Controller Class Initialized
INFO - 2022-03-18 03:31:00 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:31:00 --> Final output sent to browser
INFO - 2022-03-18 03:31:02 --> Config Class Initialized
INFO - 2022-03-18 03:31:02 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:02 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:02 --> URI Class Initialized
INFO - 2022-03-18 03:31:02 --> Router Class Initialized
INFO - 2022-03-18 03:31:02 --> Output Class Initialized
INFO - 2022-03-18 03:31:02 --> Security Class Initialized
INFO - 2022-03-18 03:31:02 --> Input Class Initialized
INFO - 2022-03-18 03:31:02 --> Language Class Initialized
INFO - 2022-03-18 03:31:02 --> Loader Class Initialized
INFO - 2022-03-18 03:31:02 --> Helper loaded: url_helper
INFO - 2022-03-18 03:31:02 --> Helper loaded: form_helper
INFO - 2022-03-18 03:31:02 --> Database Driver Class Initialized
INFO - 2022-03-18 03:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:31:02 --> Controller Class Initialized
INFO - 2022-03-18 03:31:02 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:31:02 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:31:02 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:31:02 --> Form Validation Class Initialized
INFO - 2022-03-18 03:31:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:31:02 --> Config Class Initialized
INFO - 2022-03-18 03:31:02 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:02 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:02 --> URI Class Initialized
INFO - 2022-03-18 03:31:02 --> Router Class Initialized
INFO - 2022-03-18 03:31:02 --> Output Class Initialized
INFO - 2022-03-18 03:31:02 --> Security Class Initialized
INFO - 2022-03-18 03:31:02 --> Input Class Initialized
INFO - 2022-03-18 03:31:02 --> Language Class Initialized
INFO - 2022-03-18 03:31:02 --> Loader Class Initialized
INFO - 2022-03-18 03:31:02 --> Helper loaded: url_helper
INFO - 2022-03-18 03:31:02 --> Helper loaded: form_helper
INFO - 2022-03-18 03:31:02 --> Database Driver Class Initialized
INFO - 2022-03-18 03:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:31:02 --> Controller Class Initialized
INFO - 2022-03-18 03:31:02 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:31:02 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:31:02 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:31:02 --> Form Validation Class Initialized
INFO - 2022-03-18 03:31:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:31:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:31:02 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:31:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:31:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:31:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:31:02 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:31:02 --> Final output sent to browser
INFO - 2022-03-18 03:31:08 --> Config Class Initialized
INFO - 2022-03-18 03:31:08 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:08 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:08 --> URI Class Initialized
INFO - 2022-03-18 03:31:08 --> Router Class Initialized
INFO - 2022-03-18 03:31:08 --> Output Class Initialized
INFO - 2022-03-18 03:31:08 --> Security Class Initialized
INFO - 2022-03-18 03:31:08 --> Input Class Initialized
INFO - 2022-03-18 03:31:08 --> Language Class Initialized
ERROR - 2022-03-18 03:31:08 --> 404 Page Not Found: Tutor/index
INFO - 2022-03-18 03:31:09 --> Config Class Initialized
INFO - 2022-03-18 03:31:09 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:09 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:09 --> URI Class Initialized
INFO - 2022-03-18 03:31:09 --> Router Class Initialized
INFO - 2022-03-18 03:31:09 --> Output Class Initialized
INFO - 2022-03-18 03:31:09 --> Security Class Initialized
INFO - 2022-03-18 03:31:09 --> Input Class Initialized
INFO - 2022-03-18 03:31:09 --> Language Class Initialized
INFO - 2022-03-18 03:31:09 --> Loader Class Initialized
INFO - 2022-03-18 03:31:09 --> Helper loaded: url_helper
INFO - 2022-03-18 03:31:09 --> Helper loaded: form_helper
INFO - 2022-03-18 03:31:09 --> Database Driver Class Initialized
INFO - 2022-03-18 03:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:31:09 --> Controller Class Initialized
INFO - 2022-03-18 03:31:09 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:31:09 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:31:09 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:31:09 --> Form Validation Class Initialized
INFO - 2022-03-18 03:31:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:31:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:31:09 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:31:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:31:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:31:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:31:09 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:31:09 --> Final output sent to browser
INFO - 2022-03-18 03:31:12 --> Config Class Initialized
INFO - 2022-03-18 03:31:12 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:12 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:12 --> URI Class Initialized
INFO - 2022-03-18 03:31:12 --> Router Class Initialized
INFO - 2022-03-18 03:31:12 --> Output Class Initialized
INFO - 2022-03-18 03:31:12 --> Security Class Initialized
INFO - 2022-03-18 03:31:12 --> Input Class Initialized
INFO - 2022-03-18 03:31:12 --> Language Class Initialized
INFO - 2022-03-18 03:31:12 --> Loader Class Initialized
INFO - 2022-03-18 03:31:12 --> Helper loaded: url_helper
INFO - 2022-03-18 03:31:12 --> Helper loaded: form_helper
INFO - 2022-03-18 03:31:12 --> Database Driver Class Initialized
INFO - 2022-03-18 03:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:31:12 --> Controller Class Initialized
INFO - 2022-03-18 03:31:12 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:31:12 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:31:12 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:31:12 --> Form Validation Class Initialized
INFO - 2022-03-18 03:31:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:31:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:31:12 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:31:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:31:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:31:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:31:12 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:31:12 --> Final output sent to browser
INFO - 2022-03-18 03:31:18 --> Config Class Initialized
INFO - 2022-03-18 03:31:18 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:18 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:18 --> URI Class Initialized
INFO - 2022-03-18 03:31:18 --> Router Class Initialized
INFO - 2022-03-18 03:31:18 --> Output Class Initialized
INFO - 2022-03-18 03:31:18 --> Security Class Initialized
INFO - 2022-03-18 03:31:18 --> Input Class Initialized
INFO - 2022-03-18 03:31:18 --> Language Class Initialized
INFO - 2022-03-18 03:31:18 --> Loader Class Initialized
INFO - 2022-03-18 03:31:18 --> Helper loaded: url_helper
INFO - 2022-03-18 03:31:18 --> Helper loaded: form_helper
INFO - 2022-03-18 03:31:18 --> Database Driver Class Initialized
INFO - 2022-03-18 03:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:31:18 --> Controller Class Initialized
INFO - 2022-03-18 03:31:18 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:31:18 --> Final output sent to browser
INFO - 2022-03-18 03:31:20 --> Config Class Initialized
INFO - 2022-03-18 03:31:20 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:20 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:20 --> URI Class Initialized
INFO - 2022-03-18 03:31:20 --> Router Class Initialized
INFO - 2022-03-18 03:31:20 --> Output Class Initialized
INFO - 2022-03-18 03:31:20 --> Security Class Initialized
INFO - 2022-03-18 03:31:20 --> Input Class Initialized
INFO - 2022-03-18 03:31:20 --> Language Class Initialized
INFO - 2022-03-18 03:31:20 --> Loader Class Initialized
INFO - 2022-03-18 03:31:20 --> Helper loaded: url_helper
INFO - 2022-03-18 03:31:20 --> Helper loaded: form_helper
INFO - 2022-03-18 03:31:20 --> Database Driver Class Initialized
INFO - 2022-03-18 03:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:31:20 --> Controller Class Initialized
INFO - 2022-03-18 03:31:20 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:31:20 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:31:20 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:31:20 --> Form Validation Class Initialized
INFO - 2022-03-18 03:31:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:31:20 --> Config Class Initialized
INFO - 2022-03-18 03:31:20 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:20 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:20 --> URI Class Initialized
INFO - 2022-03-18 03:31:20 --> Router Class Initialized
INFO - 2022-03-18 03:31:20 --> Output Class Initialized
INFO - 2022-03-18 03:31:20 --> Security Class Initialized
INFO - 2022-03-18 03:31:20 --> Input Class Initialized
INFO - 2022-03-18 03:31:20 --> Language Class Initialized
INFO - 2022-03-18 03:31:20 --> Loader Class Initialized
INFO - 2022-03-18 03:31:20 --> Helper loaded: url_helper
INFO - 2022-03-18 03:31:20 --> Helper loaded: form_helper
INFO - 2022-03-18 03:31:20 --> Database Driver Class Initialized
INFO - 2022-03-18 03:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:31:20 --> Controller Class Initialized
INFO - 2022-03-18 03:31:20 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:31:20 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:31:20 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:31:20 --> Form Validation Class Initialized
INFO - 2022-03-18 03:31:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:31:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:31:20 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:31:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:31:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:31:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:31:20 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:31:20 --> Final output sent to browser
INFO - 2022-03-18 03:31:30 --> Config Class Initialized
INFO - 2022-03-18 03:31:30 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:30 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:30 --> URI Class Initialized
INFO - 2022-03-18 03:31:30 --> Router Class Initialized
INFO - 2022-03-18 03:31:30 --> Output Class Initialized
INFO - 2022-03-18 03:31:30 --> Security Class Initialized
INFO - 2022-03-18 03:31:30 --> Input Class Initialized
INFO - 2022-03-18 03:31:30 --> Language Class Initialized
INFO - 2022-03-18 03:31:30 --> Loader Class Initialized
INFO - 2022-03-18 03:31:30 --> Helper loaded: url_helper
INFO - 2022-03-18 03:31:30 --> Helper loaded: form_helper
INFO - 2022-03-18 03:31:30 --> Database Driver Class Initialized
INFO - 2022-03-18 03:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:31:30 --> Controller Class Initialized
INFO - 2022-03-18 03:31:30 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:31:30 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:31:30 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:31:30 --> Form Validation Class Initialized
INFO - 2022-03-18 03:31:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:31:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:31:30 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:31:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:31:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:31:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:31:30 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:31:30 --> Final output sent to browser
INFO - 2022-03-18 03:31:38 --> Config Class Initialized
INFO - 2022-03-18 03:31:38 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:39 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:39 --> URI Class Initialized
INFO - 2022-03-18 03:31:39 --> Router Class Initialized
INFO - 2022-03-18 03:31:39 --> Output Class Initialized
INFO - 2022-03-18 03:31:39 --> Security Class Initialized
INFO - 2022-03-18 03:31:39 --> Input Class Initialized
INFO - 2022-03-18 03:31:39 --> Language Class Initialized
INFO - 2022-03-18 03:31:39 --> Loader Class Initialized
INFO - 2022-03-18 03:31:39 --> Helper loaded: url_helper
INFO - 2022-03-18 03:31:39 --> Helper loaded: form_helper
INFO - 2022-03-18 03:31:39 --> Database Driver Class Initialized
INFO - 2022-03-18 03:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:31:39 --> Controller Class Initialized
INFO - 2022-03-18 03:31:39 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:31:39 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:31:39 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:31:39 --> Form Validation Class Initialized
INFO - 2022-03-18 03:31:39 --> Config Class Initialized
INFO - 2022-03-18 03:31:39 --> Hooks Class Initialized
INFO - 2022-03-18 03:31:39 --> Utf8 Class Initialized
INFO - 2022-03-18 03:31:39 --> URI Class Initialized
INFO - 2022-03-18 03:31:39 --> Router Class Initialized
INFO - 2022-03-18 03:31:39 --> Output Class Initialized
INFO - 2022-03-18 03:31:39 --> Security Class Initialized
INFO - 2022-03-18 03:31:39 --> Input Class Initialized
INFO - 2022-03-18 03:31:39 --> Language Class Initialized
INFO - 2022-03-18 03:31:39 --> Loader Class Initialized
INFO - 2022-03-18 03:31:39 --> Helper loaded: url_helper
INFO - 2022-03-18 03:31:39 --> Helper loaded: form_helper
INFO - 2022-03-18 03:31:39 --> Database Driver Class Initialized
INFO - 2022-03-18 03:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:31:39 --> Controller Class Initialized
INFO - 2022-03-18 03:31:39 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:31:39 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:31:39 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:31:39 --> Form Validation Class Initialized
INFO - 2022-03-18 03:31:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:31:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:31:39 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:31:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:31:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:31:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:31:39 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:31:39 --> Final output sent to browser
INFO - 2022-03-18 03:33:00 --> Config Class Initialized
INFO - 2022-03-18 03:33:00 --> Hooks Class Initialized
INFO - 2022-03-18 03:33:00 --> Utf8 Class Initialized
INFO - 2022-03-18 03:33:00 --> URI Class Initialized
INFO - 2022-03-18 03:33:00 --> Router Class Initialized
INFO - 2022-03-18 03:33:00 --> Output Class Initialized
INFO - 2022-03-18 03:33:00 --> Security Class Initialized
INFO - 2022-03-18 03:33:00 --> Input Class Initialized
INFO - 2022-03-18 03:33:00 --> Language Class Initialized
INFO - 2022-03-18 03:33:00 --> Loader Class Initialized
INFO - 2022-03-18 03:33:00 --> Helper loaded: url_helper
INFO - 2022-03-18 03:33:00 --> Helper loaded: form_helper
INFO - 2022-03-18 03:33:00 --> Database Driver Class Initialized
INFO - 2022-03-18 03:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:33:00 --> Controller Class Initialized
INFO - 2022-03-18 03:33:00 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:33:00 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:33:00 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:33:00 --> Form Validation Class Initialized
INFO - 2022-03-18 03:33:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:33:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:33:00 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:33:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:33:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:33:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:33:00 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:33:00 --> Final output sent to browser
INFO - 2022-03-18 03:41:42 --> Config Class Initialized
INFO - 2022-03-18 03:41:42 --> Hooks Class Initialized
INFO - 2022-03-18 03:41:42 --> Utf8 Class Initialized
INFO - 2022-03-18 03:41:42 --> URI Class Initialized
INFO - 2022-03-18 03:41:42 --> Router Class Initialized
INFO - 2022-03-18 03:41:42 --> Output Class Initialized
INFO - 2022-03-18 03:41:42 --> Security Class Initialized
INFO - 2022-03-18 03:41:42 --> Input Class Initialized
INFO - 2022-03-18 03:41:42 --> Language Class Initialized
INFO - 2022-03-18 03:41:42 --> Loader Class Initialized
INFO - 2022-03-18 03:41:42 --> Helper loaded: url_helper
INFO - 2022-03-18 03:41:42 --> Helper loaded: form_helper
INFO - 2022-03-18 03:41:42 --> Database Driver Class Initialized
INFO - 2022-03-18 03:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:41:42 --> Controller Class Initialized
INFO - 2022-03-18 03:41:42 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:41:42 --> Final output sent to browser
INFO - 2022-03-18 03:41:44 --> Config Class Initialized
INFO - 2022-03-18 03:41:44 --> Hooks Class Initialized
INFO - 2022-03-18 03:41:44 --> Utf8 Class Initialized
INFO - 2022-03-18 03:41:44 --> URI Class Initialized
INFO - 2022-03-18 03:41:44 --> Router Class Initialized
INFO - 2022-03-18 03:41:44 --> Output Class Initialized
INFO - 2022-03-18 03:41:44 --> Security Class Initialized
INFO - 2022-03-18 03:41:44 --> Input Class Initialized
INFO - 2022-03-18 03:41:44 --> Language Class Initialized
INFO - 2022-03-18 03:41:44 --> Loader Class Initialized
INFO - 2022-03-18 03:41:44 --> Helper loaded: url_helper
INFO - 2022-03-18 03:41:44 --> Helper loaded: form_helper
INFO - 2022-03-18 03:41:44 --> Database Driver Class Initialized
INFO - 2022-03-18 03:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:41:44 --> Controller Class Initialized
INFO - 2022-03-18 03:41:44 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:41:44 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:41:44 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:41:44 --> Form Validation Class Initialized
INFO - 2022-03-18 03:41:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:41:44 --> Config Class Initialized
INFO - 2022-03-18 03:41:44 --> Hooks Class Initialized
INFO - 2022-03-18 03:41:44 --> Utf8 Class Initialized
INFO - 2022-03-18 03:41:44 --> URI Class Initialized
INFO - 2022-03-18 03:41:44 --> Router Class Initialized
INFO - 2022-03-18 03:41:44 --> Output Class Initialized
INFO - 2022-03-18 03:41:44 --> Security Class Initialized
INFO - 2022-03-18 03:41:44 --> Input Class Initialized
INFO - 2022-03-18 03:41:44 --> Language Class Initialized
INFO - 2022-03-18 03:41:44 --> Loader Class Initialized
INFO - 2022-03-18 03:41:44 --> Helper loaded: url_helper
INFO - 2022-03-18 03:41:44 --> Helper loaded: form_helper
INFO - 2022-03-18 03:41:44 --> Database Driver Class Initialized
INFO - 2022-03-18 03:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:41:44 --> Controller Class Initialized
INFO - 2022-03-18 03:41:44 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:41:44 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:41:44 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:41:44 --> Form Validation Class Initialized
INFO - 2022-03-18 03:41:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:41:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:41:44 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:41:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:41:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:41:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:41:44 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:41:44 --> Final output sent to browser
INFO - 2022-03-18 03:41:59 --> Config Class Initialized
INFO - 2022-03-18 03:41:59 --> Hooks Class Initialized
INFO - 2022-03-18 03:41:59 --> Utf8 Class Initialized
INFO - 2022-03-18 03:41:59 --> URI Class Initialized
INFO - 2022-03-18 03:41:59 --> Router Class Initialized
INFO - 2022-03-18 03:41:59 --> Output Class Initialized
INFO - 2022-03-18 03:41:59 --> Security Class Initialized
INFO - 2022-03-18 03:41:59 --> Input Class Initialized
INFO - 2022-03-18 03:41:59 --> Language Class Initialized
INFO - 2022-03-18 03:41:59 --> Loader Class Initialized
INFO - 2022-03-18 03:41:59 --> Helper loaded: url_helper
INFO - 2022-03-18 03:41:59 --> Helper loaded: form_helper
INFO - 2022-03-18 03:41:59 --> Database Driver Class Initialized
INFO - 2022-03-18 03:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:41:59 --> Controller Class Initialized
INFO - 2022-03-18 03:41:59 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:41:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:41:59 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:41:59 --> Form Validation Class Initialized
INFO - 2022-03-18 03:41:59 --> Config Class Initialized
INFO - 2022-03-18 03:41:59 --> Hooks Class Initialized
INFO - 2022-03-18 03:41:59 --> Utf8 Class Initialized
INFO - 2022-03-18 03:41:59 --> URI Class Initialized
INFO - 2022-03-18 03:41:59 --> Router Class Initialized
INFO - 2022-03-18 03:41:59 --> Output Class Initialized
INFO - 2022-03-18 03:41:59 --> Security Class Initialized
INFO - 2022-03-18 03:41:59 --> Input Class Initialized
INFO - 2022-03-18 03:41:59 --> Language Class Initialized
INFO - 2022-03-18 03:41:59 --> Loader Class Initialized
INFO - 2022-03-18 03:41:59 --> Helper loaded: url_helper
INFO - 2022-03-18 03:41:59 --> Helper loaded: form_helper
INFO - 2022-03-18 03:41:59 --> Database Driver Class Initialized
INFO - 2022-03-18 03:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:41:59 --> Controller Class Initialized
INFO - 2022-03-18 03:41:59 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:41:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:41:59 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:41:59 --> Form Validation Class Initialized
INFO - 2022-03-18 03:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:42:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:42:00 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:42:00 --> Final output sent to browser
INFO - 2022-03-18 03:42:03 --> Config Class Initialized
INFO - 2022-03-18 03:42:03 --> Hooks Class Initialized
INFO - 2022-03-18 03:42:03 --> Utf8 Class Initialized
INFO - 2022-03-18 03:42:03 --> URI Class Initialized
INFO - 2022-03-18 03:42:03 --> Router Class Initialized
INFO - 2022-03-18 03:42:03 --> Output Class Initialized
INFO - 2022-03-18 03:42:03 --> Security Class Initialized
INFO - 2022-03-18 03:42:03 --> Input Class Initialized
INFO - 2022-03-18 03:42:03 --> Language Class Initialized
INFO - 2022-03-18 03:42:03 --> Loader Class Initialized
INFO - 2022-03-18 03:42:03 --> Helper loaded: url_helper
INFO - 2022-03-18 03:42:03 --> Helper loaded: form_helper
INFO - 2022-03-18 03:42:03 --> Database Driver Class Initialized
INFO - 2022-03-18 03:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:42:04 --> Controller Class Initialized
INFO - 2022-03-18 03:42:04 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:42:04 --> Final output sent to browser
INFO - 2022-03-18 03:42:08 --> Config Class Initialized
INFO - 2022-03-18 03:42:08 --> Hooks Class Initialized
INFO - 2022-03-18 03:42:08 --> Utf8 Class Initialized
INFO - 2022-03-18 03:42:08 --> URI Class Initialized
INFO - 2022-03-18 03:42:08 --> Router Class Initialized
INFO - 2022-03-18 03:42:08 --> Output Class Initialized
INFO - 2022-03-18 03:42:08 --> Security Class Initialized
INFO - 2022-03-18 03:42:08 --> Input Class Initialized
INFO - 2022-03-18 03:42:08 --> Language Class Initialized
INFO - 2022-03-18 03:42:08 --> Loader Class Initialized
INFO - 2022-03-18 03:42:08 --> Helper loaded: url_helper
INFO - 2022-03-18 03:42:08 --> Helper loaded: form_helper
INFO - 2022-03-18 03:42:08 --> Database Driver Class Initialized
INFO - 2022-03-18 03:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:42:08 --> Controller Class Initialized
INFO - 2022-03-18 03:42:08 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:42:08 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:42:08 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:42:08 --> Form Validation Class Initialized
ERROR - 2022-03-18 03:42:08 --> Severity: Notice --> Undefined variable: data C:\laragon\www\list-todo\application\controllers\C_todo_group.php 95
INFO - 2022-03-18 03:42:09 --> Config Class Initialized
INFO - 2022-03-18 03:42:09 --> Hooks Class Initialized
INFO - 2022-03-18 03:42:09 --> Utf8 Class Initialized
INFO - 2022-03-18 03:42:09 --> URI Class Initialized
INFO - 2022-03-18 03:42:09 --> Router Class Initialized
INFO - 2022-03-18 03:42:09 --> Output Class Initialized
INFO - 2022-03-18 03:42:09 --> Security Class Initialized
INFO - 2022-03-18 03:42:09 --> Input Class Initialized
INFO - 2022-03-18 03:42:09 --> Language Class Initialized
INFO - 2022-03-18 03:42:09 --> Loader Class Initialized
INFO - 2022-03-18 03:42:09 --> Helper loaded: url_helper
INFO - 2022-03-18 03:42:09 --> Helper loaded: form_helper
INFO - 2022-03-18 03:42:09 --> Database Driver Class Initialized
INFO - 2022-03-18 03:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:42:09 --> Controller Class Initialized
INFO - 2022-03-18 03:42:09 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:42:09 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:42:09 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:42:09 --> Form Validation Class Initialized
ERROR - 2022-03-18 03:42:09 --> Severity: Warning --> Missing argument 1 for C_todo_group::list_tutor() C:\laragon\www\list-todo\application\controllers\C_todo_group.php 62
ERROR - 2022-03-18 03:42:09 --> Severity: Notice --> Undefined variable: id C:\laragon\www\list-todo\application\controllers\C_todo_group.php 64
ERROR - 2022-03-18 03:42:09 --> 404 Page Not Found: 
INFO - 2022-03-18 03:43:30 --> Config Class Initialized
INFO - 2022-03-18 03:43:30 --> Hooks Class Initialized
INFO - 2022-03-18 03:43:30 --> Utf8 Class Initialized
INFO - 2022-03-18 03:43:30 --> URI Class Initialized
INFO - 2022-03-18 03:43:30 --> Router Class Initialized
INFO - 2022-03-18 03:43:30 --> Output Class Initialized
INFO - 2022-03-18 03:43:30 --> Security Class Initialized
INFO - 2022-03-18 03:43:30 --> Input Class Initialized
INFO - 2022-03-18 03:43:30 --> Language Class Initialized
INFO - 2022-03-18 03:43:30 --> Loader Class Initialized
INFO - 2022-03-18 03:43:30 --> Helper loaded: url_helper
INFO - 2022-03-18 03:43:30 --> Helper loaded: form_helper
INFO - 2022-03-18 03:43:30 --> Database Driver Class Initialized
INFO - 2022-03-18 03:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:43:30 --> Controller Class Initialized
INFO - 2022-03-18 03:43:30 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:43:30 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:43:30 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:43:30 --> Form Validation Class Initialized
INFO - 2022-03-18 03:43:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:43:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:43:30 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:43:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:43:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:43:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:43:30 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:43:30 --> Final output sent to browser
INFO - 2022-03-18 03:43:36 --> Config Class Initialized
INFO - 2022-03-18 03:43:36 --> Hooks Class Initialized
INFO - 2022-03-18 03:43:36 --> Utf8 Class Initialized
INFO - 2022-03-18 03:43:36 --> URI Class Initialized
INFO - 2022-03-18 03:43:36 --> Router Class Initialized
INFO - 2022-03-18 03:43:36 --> Output Class Initialized
INFO - 2022-03-18 03:43:36 --> Security Class Initialized
INFO - 2022-03-18 03:43:36 --> Input Class Initialized
INFO - 2022-03-18 03:43:36 --> Language Class Initialized
INFO - 2022-03-18 03:43:36 --> Loader Class Initialized
INFO - 2022-03-18 03:43:36 --> Helper loaded: url_helper
INFO - 2022-03-18 03:43:36 --> Helper loaded: form_helper
INFO - 2022-03-18 03:43:36 --> Database Driver Class Initialized
INFO - 2022-03-18 03:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:43:37 --> Controller Class Initialized
INFO - 2022-03-18 03:43:37 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:43:37 --> Final output sent to browser
INFO - 2022-03-18 03:43:38 --> Config Class Initialized
INFO - 2022-03-18 03:43:38 --> Hooks Class Initialized
INFO - 2022-03-18 03:43:38 --> Utf8 Class Initialized
INFO - 2022-03-18 03:43:38 --> URI Class Initialized
INFO - 2022-03-18 03:43:38 --> Router Class Initialized
INFO - 2022-03-18 03:43:38 --> Output Class Initialized
INFO - 2022-03-18 03:43:38 --> Security Class Initialized
INFO - 2022-03-18 03:43:38 --> Input Class Initialized
INFO - 2022-03-18 03:43:38 --> Language Class Initialized
INFO - 2022-03-18 03:43:38 --> Loader Class Initialized
INFO - 2022-03-18 03:43:38 --> Helper loaded: url_helper
INFO - 2022-03-18 03:43:38 --> Helper loaded: form_helper
INFO - 2022-03-18 03:43:38 --> Database Driver Class Initialized
INFO - 2022-03-18 03:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:43:38 --> Controller Class Initialized
INFO - 2022-03-18 03:43:38 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:43:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:43:38 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:43:38 --> Form Validation Class Initialized
INFO - 2022-03-18 03:43:38 --> Config Class Initialized
INFO - 2022-03-18 03:43:38 --> Hooks Class Initialized
INFO - 2022-03-18 03:43:38 --> Utf8 Class Initialized
INFO - 2022-03-18 03:43:38 --> URI Class Initialized
INFO - 2022-03-18 03:43:39 --> Router Class Initialized
INFO - 2022-03-18 03:43:39 --> Output Class Initialized
INFO - 2022-03-18 03:43:39 --> Security Class Initialized
INFO - 2022-03-18 03:43:39 --> Input Class Initialized
INFO - 2022-03-18 03:43:39 --> Language Class Initialized
INFO - 2022-03-18 03:43:39 --> Loader Class Initialized
INFO - 2022-03-18 03:43:39 --> Helper loaded: url_helper
INFO - 2022-03-18 03:43:39 --> Helper loaded: form_helper
INFO - 2022-03-18 03:43:39 --> Database Driver Class Initialized
INFO - 2022-03-18 03:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:43:39 --> Controller Class Initialized
INFO - 2022-03-18 03:43:39 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:43:39 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:43:39 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:43:39 --> Form Validation Class Initialized
INFO - 2022-03-18 03:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:43:39 --> Final output sent to browser
INFO - 2022-03-18 03:44:08 --> Config Class Initialized
INFO - 2022-03-18 03:44:08 --> Hooks Class Initialized
INFO - 2022-03-18 03:44:08 --> Utf8 Class Initialized
INFO - 2022-03-18 03:44:08 --> URI Class Initialized
INFO - 2022-03-18 03:44:08 --> Router Class Initialized
INFO - 2022-03-18 03:44:08 --> Output Class Initialized
INFO - 2022-03-18 03:44:08 --> Security Class Initialized
INFO - 2022-03-18 03:44:08 --> Input Class Initialized
INFO - 2022-03-18 03:44:08 --> Language Class Initialized
INFO - 2022-03-18 03:44:08 --> Loader Class Initialized
INFO - 2022-03-18 03:44:08 --> Helper loaded: url_helper
INFO - 2022-03-18 03:44:08 --> Helper loaded: form_helper
INFO - 2022-03-18 03:44:08 --> Database Driver Class Initialized
INFO - 2022-03-18 03:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:44:08 --> Controller Class Initialized
INFO - 2022-03-18 03:44:08 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:44:08 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:44:08 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:44:08 --> Form Validation Class Initialized
INFO - 2022-03-18 03:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:44:08 --> Final output sent to browser
INFO - 2022-03-18 03:44:10 --> Config Class Initialized
INFO - 2022-03-18 03:44:11 --> Hooks Class Initialized
INFO - 2022-03-18 03:44:11 --> Utf8 Class Initialized
INFO - 2022-03-18 03:44:11 --> URI Class Initialized
INFO - 2022-03-18 03:44:11 --> Router Class Initialized
INFO - 2022-03-18 03:44:11 --> Output Class Initialized
INFO - 2022-03-18 03:44:11 --> Security Class Initialized
INFO - 2022-03-18 03:44:11 --> Input Class Initialized
INFO - 2022-03-18 03:44:11 --> Language Class Initialized
INFO - 2022-03-18 03:44:11 --> Loader Class Initialized
INFO - 2022-03-18 03:44:11 --> Helper loaded: url_helper
INFO - 2022-03-18 03:44:11 --> Helper loaded: form_helper
INFO - 2022-03-18 03:44:11 --> Database Driver Class Initialized
INFO - 2022-03-18 03:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:44:11 --> Controller Class Initialized
INFO - 2022-03-18 03:44:11 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:44:11 --> Final output sent to browser
INFO - 2022-03-18 03:44:15 --> Config Class Initialized
INFO - 2022-03-18 03:44:15 --> Hooks Class Initialized
INFO - 2022-03-18 03:44:15 --> Utf8 Class Initialized
INFO - 2022-03-18 03:44:15 --> URI Class Initialized
INFO - 2022-03-18 03:44:15 --> Router Class Initialized
INFO - 2022-03-18 03:44:15 --> Output Class Initialized
INFO - 2022-03-18 03:44:15 --> Security Class Initialized
INFO - 2022-03-18 03:44:15 --> Input Class Initialized
INFO - 2022-03-18 03:44:15 --> Language Class Initialized
INFO - 2022-03-18 03:44:15 --> Loader Class Initialized
INFO - 2022-03-18 03:44:15 --> Helper loaded: url_helper
INFO - 2022-03-18 03:44:15 --> Helper loaded: form_helper
INFO - 2022-03-18 03:44:15 --> Database Driver Class Initialized
INFO - 2022-03-18 03:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:44:15 --> Controller Class Initialized
INFO - 2022-03-18 03:44:15 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:44:15 --> Final output sent to browser
INFO - 2022-03-18 03:44:17 --> Config Class Initialized
INFO - 2022-03-18 03:44:17 --> Hooks Class Initialized
INFO - 2022-03-18 03:44:17 --> Utf8 Class Initialized
INFO - 2022-03-18 03:44:17 --> URI Class Initialized
INFO - 2022-03-18 03:44:17 --> Router Class Initialized
INFO - 2022-03-18 03:44:17 --> Output Class Initialized
INFO - 2022-03-18 03:44:17 --> Security Class Initialized
INFO - 2022-03-18 03:44:17 --> Input Class Initialized
INFO - 2022-03-18 03:44:17 --> Language Class Initialized
INFO - 2022-03-18 03:44:17 --> Loader Class Initialized
INFO - 2022-03-18 03:44:17 --> Helper loaded: url_helper
INFO - 2022-03-18 03:44:17 --> Helper loaded: form_helper
INFO - 2022-03-18 03:44:17 --> Database Driver Class Initialized
INFO - 2022-03-18 03:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:44:17 --> Controller Class Initialized
INFO - 2022-03-18 03:44:17 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:44:17 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:44:17 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:44:17 --> Form Validation Class Initialized
INFO - 2022-03-18 03:44:17 --> Config Class Initialized
INFO - 2022-03-18 03:44:17 --> Hooks Class Initialized
INFO - 2022-03-18 03:44:17 --> Utf8 Class Initialized
INFO - 2022-03-18 03:44:17 --> URI Class Initialized
INFO - 2022-03-18 03:44:17 --> Router Class Initialized
INFO - 2022-03-18 03:44:17 --> Output Class Initialized
INFO - 2022-03-18 03:44:17 --> Security Class Initialized
INFO - 2022-03-18 03:44:17 --> Input Class Initialized
INFO - 2022-03-18 03:44:17 --> Language Class Initialized
INFO - 2022-03-18 03:44:17 --> Loader Class Initialized
INFO - 2022-03-18 03:44:17 --> Helper loaded: url_helper
INFO - 2022-03-18 03:44:17 --> Helper loaded: form_helper
INFO - 2022-03-18 03:44:17 --> Database Driver Class Initialized
INFO - 2022-03-18 03:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:44:17 --> Controller Class Initialized
INFO - 2022-03-18 03:44:17 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:44:17 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:44:17 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:44:17 --> Form Validation Class Initialized
INFO - 2022-03-18 03:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:44:17 --> Final output sent to browser
INFO - 2022-03-18 03:46:15 --> Config Class Initialized
INFO - 2022-03-18 03:46:15 --> Hooks Class Initialized
INFO - 2022-03-18 03:46:15 --> Utf8 Class Initialized
INFO - 2022-03-18 03:46:15 --> URI Class Initialized
INFO - 2022-03-18 03:46:15 --> Router Class Initialized
INFO - 2022-03-18 03:46:15 --> Output Class Initialized
INFO - 2022-03-18 03:46:15 --> Security Class Initialized
INFO - 2022-03-18 03:46:15 --> Input Class Initialized
INFO - 2022-03-18 03:46:15 --> Language Class Initialized
INFO - 2022-03-18 03:46:15 --> Loader Class Initialized
INFO - 2022-03-18 03:46:15 --> Helper loaded: url_helper
INFO - 2022-03-18 03:46:15 --> Helper loaded: form_helper
INFO - 2022-03-18 03:46:15 --> Database Driver Class Initialized
INFO - 2022-03-18 03:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:46:15 --> Controller Class Initialized
INFO - 2022-03-18 03:46:15 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:46:15 --> Final output sent to browser
INFO - 2022-03-18 03:46:16 --> Config Class Initialized
INFO - 2022-03-18 03:46:16 --> Hooks Class Initialized
INFO - 2022-03-18 03:46:16 --> Utf8 Class Initialized
INFO - 2022-03-18 03:46:16 --> URI Class Initialized
INFO - 2022-03-18 03:46:16 --> Router Class Initialized
INFO - 2022-03-18 03:46:16 --> Output Class Initialized
INFO - 2022-03-18 03:46:16 --> Security Class Initialized
INFO - 2022-03-18 03:46:16 --> Input Class Initialized
INFO - 2022-03-18 03:46:16 --> Language Class Initialized
INFO - 2022-03-18 03:46:16 --> Loader Class Initialized
INFO - 2022-03-18 03:46:16 --> Helper loaded: url_helper
INFO - 2022-03-18 03:46:16 --> Helper loaded: form_helper
INFO - 2022-03-18 03:46:17 --> Database Driver Class Initialized
INFO - 2022-03-18 03:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:46:17 --> Controller Class Initialized
INFO - 2022-03-18 03:46:17 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:46:17 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:46:17 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:46:17 --> Form Validation Class Initialized
INFO - 2022-03-18 03:46:17 --> Config Class Initialized
INFO - 2022-03-18 03:46:17 --> Hooks Class Initialized
INFO - 2022-03-18 03:46:17 --> Utf8 Class Initialized
INFO - 2022-03-18 03:46:17 --> URI Class Initialized
INFO - 2022-03-18 03:46:17 --> Router Class Initialized
INFO - 2022-03-18 03:46:17 --> Output Class Initialized
INFO - 2022-03-18 03:46:17 --> Security Class Initialized
INFO - 2022-03-18 03:46:17 --> Input Class Initialized
INFO - 2022-03-18 03:46:17 --> Language Class Initialized
INFO - 2022-03-18 03:46:17 --> Loader Class Initialized
INFO - 2022-03-18 03:46:17 --> Helper loaded: url_helper
INFO - 2022-03-18 03:46:17 --> Helper loaded: form_helper
INFO - 2022-03-18 03:46:17 --> Database Driver Class Initialized
INFO - 2022-03-18 03:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:46:17 --> Controller Class Initialized
INFO - 2022-03-18 03:46:17 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:46:17 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:46:17 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:46:17 --> Form Validation Class Initialized
INFO - 2022-03-18 03:46:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:46:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:46:17 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:46:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:46:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:46:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:46:17 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:46:17 --> Final output sent to browser
INFO - 2022-03-18 03:46:23 --> Config Class Initialized
INFO - 2022-03-18 03:46:23 --> Hooks Class Initialized
INFO - 2022-03-18 03:46:23 --> Utf8 Class Initialized
INFO - 2022-03-18 03:46:23 --> URI Class Initialized
INFO - 2022-03-18 03:46:23 --> Router Class Initialized
INFO - 2022-03-18 03:46:23 --> Output Class Initialized
INFO - 2022-03-18 03:46:23 --> Security Class Initialized
INFO - 2022-03-18 03:46:23 --> Input Class Initialized
INFO - 2022-03-18 03:46:23 --> Language Class Initialized
INFO - 2022-03-18 03:46:23 --> Loader Class Initialized
INFO - 2022-03-18 03:46:23 --> Helper loaded: url_helper
INFO - 2022-03-18 03:46:23 --> Helper loaded: form_helper
INFO - 2022-03-18 03:46:23 --> Database Driver Class Initialized
INFO - 2022-03-18 03:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:46:23 --> Controller Class Initialized
INFO - 2022-03-18 03:46:23 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:46:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:46:23 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:46:23 --> Form Validation Class Initialized
INFO - 2022-03-18 03:46:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:46:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:46:23 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:46:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:46:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:46:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:46:23 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:46:23 --> Final output sent to browser
INFO - 2022-03-18 03:46:26 --> Config Class Initialized
INFO - 2022-03-18 03:46:26 --> Hooks Class Initialized
INFO - 2022-03-18 03:46:26 --> Utf8 Class Initialized
INFO - 2022-03-18 03:46:26 --> URI Class Initialized
INFO - 2022-03-18 03:46:26 --> Router Class Initialized
INFO - 2022-03-18 03:46:26 --> Output Class Initialized
INFO - 2022-03-18 03:46:26 --> Security Class Initialized
INFO - 2022-03-18 03:46:26 --> Input Class Initialized
INFO - 2022-03-18 03:46:26 --> Language Class Initialized
INFO - 2022-03-18 03:46:26 --> Loader Class Initialized
INFO - 2022-03-18 03:46:26 --> Helper loaded: url_helper
INFO - 2022-03-18 03:46:26 --> Helper loaded: form_helper
INFO - 2022-03-18 03:46:26 --> Database Driver Class Initialized
INFO - 2022-03-18 03:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:46:26 --> Controller Class Initialized
INFO - 2022-03-18 03:46:26 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:46:26 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:46:26 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:46:26 --> Form Validation Class Initialized
INFO - 2022-03-18 03:46:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:46:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:46:26 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_tambah.php
INFO - 2022-03-18 03:46:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:46:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:46:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:46:26 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:46:26 --> Final output sent to browser
INFO - 2022-03-18 03:46:31 --> Config Class Initialized
INFO - 2022-03-18 03:46:31 --> Hooks Class Initialized
INFO - 2022-03-18 03:46:31 --> Utf8 Class Initialized
INFO - 2022-03-18 03:46:31 --> URI Class Initialized
INFO - 2022-03-18 03:46:31 --> Router Class Initialized
INFO - 2022-03-18 03:46:32 --> Output Class Initialized
INFO - 2022-03-18 03:46:32 --> Security Class Initialized
INFO - 2022-03-18 03:46:32 --> Input Class Initialized
INFO - 2022-03-18 03:46:32 --> Language Class Initialized
INFO - 2022-03-18 03:46:32 --> Loader Class Initialized
INFO - 2022-03-18 03:46:32 --> Helper loaded: url_helper
INFO - 2022-03-18 03:46:32 --> Helper loaded: form_helper
INFO - 2022-03-18 03:46:32 --> Database Driver Class Initialized
INFO - 2022-03-18 03:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:46:32 --> Controller Class Initialized
INFO - 2022-03-18 03:46:32 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:46:32 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:46:32 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:46:32 --> Form Validation Class Initialized
INFO - 2022-03-18 03:46:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:46:32 --> Config Class Initialized
INFO - 2022-03-18 03:46:32 --> Hooks Class Initialized
INFO - 2022-03-18 03:46:32 --> Utf8 Class Initialized
INFO - 2022-03-18 03:46:32 --> URI Class Initialized
INFO - 2022-03-18 03:46:32 --> Router Class Initialized
INFO - 2022-03-18 03:46:32 --> Output Class Initialized
INFO - 2022-03-18 03:46:32 --> Security Class Initialized
INFO - 2022-03-18 03:46:32 --> Input Class Initialized
INFO - 2022-03-18 03:46:32 --> Language Class Initialized
INFO - 2022-03-18 03:46:32 --> Loader Class Initialized
INFO - 2022-03-18 03:46:32 --> Helper loaded: url_helper
INFO - 2022-03-18 03:46:32 --> Helper loaded: form_helper
INFO - 2022-03-18 03:46:32 --> Database Driver Class Initialized
INFO - 2022-03-18 03:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:46:32 --> Controller Class Initialized
INFO - 2022-03-18 03:46:32 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:46:32 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:46:32 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:46:32 --> Form Validation Class Initialized
INFO - 2022-03-18 03:46:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:46:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:46:32 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:46:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:46:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:46:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:46:32 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:46:32 --> Final output sent to browser
INFO - 2022-03-18 03:46:38 --> Config Class Initialized
INFO - 2022-03-18 03:46:38 --> Hooks Class Initialized
INFO - 2022-03-18 03:46:38 --> Utf8 Class Initialized
INFO - 2022-03-18 03:46:38 --> URI Class Initialized
INFO - 2022-03-18 03:46:38 --> Router Class Initialized
INFO - 2022-03-18 03:46:38 --> Output Class Initialized
INFO - 2022-03-18 03:46:38 --> Security Class Initialized
INFO - 2022-03-18 03:46:38 --> Input Class Initialized
INFO - 2022-03-18 03:46:38 --> Language Class Initialized
INFO - 2022-03-18 03:46:38 --> Loader Class Initialized
INFO - 2022-03-18 03:46:38 --> Helper loaded: url_helper
INFO - 2022-03-18 03:46:38 --> Helper loaded: form_helper
INFO - 2022-03-18 03:46:38 --> Database Driver Class Initialized
INFO - 2022-03-18 03:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:46:38 --> Controller Class Initialized
INFO - 2022-03-18 03:46:38 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:46:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:46:38 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:46:38 --> Form Validation Class Initialized
INFO - 2022-03-18 03:46:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:46:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:46:38 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:46:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:46:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:46:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:46:38 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:46:38 --> Final output sent to browser
INFO - 2022-03-18 03:46:44 --> Config Class Initialized
INFO - 2022-03-18 03:46:44 --> Hooks Class Initialized
INFO - 2022-03-18 03:46:44 --> Utf8 Class Initialized
INFO - 2022-03-18 03:46:44 --> URI Class Initialized
INFO - 2022-03-18 03:46:44 --> Router Class Initialized
INFO - 2022-03-18 03:46:44 --> Output Class Initialized
INFO - 2022-03-18 03:46:44 --> Security Class Initialized
INFO - 2022-03-18 03:46:44 --> Input Class Initialized
INFO - 2022-03-18 03:46:44 --> Language Class Initialized
INFO - 2022-03-18 03:46:44 --> Loader Class Initialized
INFO - 2022-03-18 03:46:44 --> Helper loaded: url_helper
INFO - 2022-03-18 03:46:44 --> Helper loaded: form_helper
INFO - 2022-03-18 03:46:44 --> Database Driver Class Initialized
INFO - 2022-03-18 03:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:46:44 --> Controller Class Initialized
INFO - 2022-03-18 03:46:44 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:46:44 --> Final output sent to browser
INFO - 2022-03-18 03:46:46 --> Config Class Initialized
INFO - 2022-03-18 03:46:46 --> Hooks Class Initialized
INFO - 2022-03-18 03:46:46 --> Utf8 Class Initialized
INFO - 2022-03-18 03:46:46 --> URI Class Initialized
INFO - 2022-03-18 03:46:46 --> Router Class Initialized
INFO - 2022-03-18 03:46:46 --> Output Class Initialized
INFO - 2022-03-18 03:46:46 --> Security Class Initialized
INFO - 2022-03-18 03:46:46 --> Input Class Initialized
INFO - 2022-03-18 03:46:46 --> Language Class Initialized
INFO - 2022-03-18 03:46:46 --> Loader Class Initialized
INFO - 2022-03-18 03:46:46 --> Helper loaded: url_helper
INFO - 2022-03-18 03:46:46 --> Helper loaded: form_helper
INFO - 2022-03-18 03:46:46 --> Database Driver Class Initialized
INFO - 2022-03-18 03:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:46:46 --> Controller Class Initialized
INFO - 2022-03-18 03:46:46 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:46:46 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:46:46 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:46:46 --> Form Validation Class Initialized
INFO - 2022-03-18 03:46:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:46:47 --> Config Class Initialized
INFO - 2022-03-18 03:46:47 --> Hooks Class Initialized
INFO - 2022-03-18 03:46:47 --> Utf8 Class Initialized
INFO - 2022-03-18 03:46:47 --> URI Class Initialized
INFO - 2022-03-18 03:46:47 --> Router Class Initialized
INFO - 2022-03-18 03:46:47 --> Output Class Initialized
INFO - 2022-03-18 03:46:47 --> Security Class Initialized
INFO - 2022-03-18 03:46:47 --> Input Class Initialized
INFO - 2022-03-18 03:46:47 --> Language Class Initialized
INFO - 2022-03-18 03:46:47 --> Loader Class Initialized
INFO - 2022-03-18 03:46:47 --> Helper loaded: url_helper
INFO - 2022-03-18 03:46:47 --> Helper loaded: form_helper
INFO - 2022-03-18 03:46:47 --> Database Driver Class Initialized
INFO - 2022-03-18 03:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:46:47 --> Controller Class Initialized
INFO - 2022-03-18 03:46:47 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:46:47 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:46:47 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:46:47 --> Form Validation Class Initialized
INFO - 2022-03-18 03:46:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:46:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:46:47 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:46:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:46:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:46:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:46:47 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:46:47 --> Final output sent to browser
INFO - 2022-03-18 03:47:00 --> Config Class Initialized
INFO - 2022-03-18 03:47:00 --> Hooks Class Initialized
INFO - 2022-03-18 03:47:00 --> Utf8 Class Initialized
INFO - 2022-03-18 03:47:00 --> URI Class Initialized
INFO - 2022-03-18 03:47:00 --> Router Class Initialized
INFO - 2022-03-18 03:47:00 --> Output Class Initialized
INFO - 2022-03-18 03:47:00 --> Security Class Initialized
INFO - 2022-03-18 03:47:00 --> Input Class Initialized
INFO - 2022-03-18 03:47:00 --> Language Class Initialized
INFO - 2022-03-18 03:47:00 --> Loader Class Initialized
INFO - 2022-03-18 03:47:00 --> Helper loaded: url_helper
INFO - 2022-03-18 03:47:00 --> Helper loaded: form_helper
INFO - 2022-03-18 03:47:00 --> Database Driver Class Initialized
INFO - 2022-03-18 03:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:47:00 --> Controller Class Initialized
INFO - 2022-03-18 03:47:00 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:47:00 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:47:00 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:47:00 --> Form Validation Class Initialized
INFO - 2022-03-18 03:47:00 --> Config Class Initialized
INFO - 2022-03-18 03:47:00 --> Hooks Class Initialized
INFO - 2022-03-18 03:47:00 --> Utf8 Class Initialized
INFO - 2022-03-18 03:47:00 --> URI Class Initialized
INFO - 2022-03-18 03:47:00 --> Router Class Initialized
INFO - 2022-03-18 03:47:00 --> Output Class Initialized
INFO - 2022-03-18 03:47:00 --> Security Class Initialized
INFO - 2022-03-18 03:47:00 --> Input Class Initialized
INFO - 2022-03-18 03:47:00 --> Language Class Initialized
INFO - 2022-03-18 03:47:00 --> Loader Class Initialized
INFO - 2022-03-18 03:47:00 --> Helper loaded: url_helper
INFO - 2022-03-18 03:47:00 --> Helper loaded: form_helper
INFO - 2022-03-18 03:47:00 --> Database Driver Class Initialized
INFO - 2022-03-18 03:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:47:00 --> Controller Class Initialized
INFO - 2022-03-18 03:47:00 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:47:00 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:47:00 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:47:00 --> Form Validation Class Initialized
INFO - 2022-03-18 03:47:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:47:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:47:00 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:47:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:47:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:47:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:47:00 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:47:00 --> Final output sent to browser
INFO - 2022-03-18 03:47:22 --> Config Class Initialized
INFO - 2022-03-18 03:47:22 --> Hooks Class Initialized
INFO - 2022-03-18 03:47:22 --> Utf8 Class Initialized
INFO - 2022-03-18 03:47:22 --> URI Class Initialized
INFO - 2022-03-18 03:47:22 --> Router Class Initialized
INFO - 2022-03-18 03:47:22 --> Output Class Initialized
INFO - 2022-03-18 03:47:22 --> Security Class Initialized
INFO - 2022-03-18 03:47:22 --> Input Class Initialized
INFO - 2022-03-18 03:47:22 --> Language Class Initialized
INFO - 2022-03-18 03:47:22 --> Loader Class Initialized
INFO - 2022-03-18 03:47:22 --> Helper loaded: url_helper
INFO - 2022-03-18 03:47:23 --> Helper loaded: form_helper
INFO - 2022-03-18 03:47:23 --> Database Driver Class Initialized
INFO - 2022-03-18 03:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:47:23 --> Controller Class Initialized
INFO - 2022-03-18 03:47:23 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:47:23 --> Final output sent to browser
INFO - 2022-03-18 03:47:25 --> Config Class Initialized
INFO - 2022-03-18 03:47:25 --> Hooks Class Initialized
INFO - 2022-03-18 03:47:25 --> Utf8 Class Initialized
INFO - 2022-03-18 03:47:25 --> URI Class Initialized
INFO - 2022-03-18 03:47:25 --> Router Class Initialized
INFO - 2022-03-18 03:47:25 --> Output Class Initialized
INFO - 2022-03-18 03:47:25 --> Security Class Initialized
INFO - 2022-03-18 03:47:25 --> Input Class Initialized
INFO - 2022-03-18 03:47:25 --> Language Class Initialized
INFO - 2022-03-18 03:47:25 --> Loader Class Initialized
INFO - 2022-03-18 03:47:25 --> Helper loaded: url_helper
INFO - 2022-03-18 03:47:25 --> Helper loaded: form_helper
INFO - 2022-03-18 03:47:25 --> Database Driver Class Initialized
INFO - 2022-03-18 03:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:47:25 --> Controller Class Initialized
INFO - 2022-03-18 03:47:25 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:47:25 --> Final output sent to browser
INFO - 2022-03-18 03:47:28 --> Config Class Initialized
INFO - 2022-03-18 03:47:28 --> Hooks Class Initialized
INFO - 2022-03-18 03:47:28 --> Utf8 Class Initialized
INFO - 2022-03-18 03:47:28 --> URI Class Initialized
INFO - 2022-03-18 03:47:28 --> Router Class Initialized
INFO - 2022-03-18 03:47:28 --> Output Class Initialized
INFO - 2022-03-18 03:47:28 --> Security Class Initialized
INFO - 2022-03-18 03:47:28 --> Input Class Initialized
INFO - 2022-03-18 03:47:28 --> Language Class Initialized
INFO - 2022-03-18 03:47:28 --> Loader Class Initialized
INFO - 2022-03-18 03:47:28 --> Helper loaded: url_helper
INFO - 2022-03-18 03:47:28 --> Helper loaded: form_helper
INFO - 2022-03-18 03:47:28 --> Database Driver Class Initialized
INFO - 2022-03-18 03:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:47:28 --> Controller Class Initialized
INFO - 2022-03-18 03:47:28 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:47:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:47:28 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:47:28 --> Form Validation Class Initialized
INFO - 2022-03-18 03:47:28 --> Config Class Initialized
INFO - 2022-03-18 03:47:28 --> Hooks Class Initialized
INFO - 2022-03-18 03:47:28 --> Utf8 Class Initialized
INFO - 2022-03-18 03:47:28 --> URI Class Initialized
INFO - 2022-03-18 03:47:28 --> Router Class Initialized
INFO - 2022-03-18 03:47:28 --> Output Class Initialized
INFO - 2022-03-18 03:47:28 --> Security Class Initialized
INFO - 2022-03-18 03:47:28 --> Input Class Initialized
INFO - 2022-03-18 03:47:28 --> Language Class Initialized
INFO - 2022-03-18 03:47:28 --> Loader Class Initialized
INFO - 2022-03-18 03:47:28 --> Helper loaded: url_helper
INFO - 2022-03-18 03:47:28 --> Helper loaded: form_helper
INFO - 2022-03-18 03:47:28 --> Database Driver Class Initialized
INFO - 2022-03-18 03:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:47:28 --> Controller Class Initialized
INFO - 2022-03-18 03:47:28 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:47:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:47:28 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:47:28 --> Form Validation Class Initialized
INFO - 2022-03-18 03:47:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:47:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:47:28 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:47:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:47:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:47:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:47:28 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:47:28 --> Final output sent to browser
INFO - 2022-03-18 03:47:37 --> Config Class Initialized
INFO - 2022-03-18 03:47:37 --> Hooks Class Initialized
INFO - 2022-03-18 03:47:37 --> Utf8 Class Initialized
INFO - 2022-03-18 03:47:37 --> URI Class Initialized
INFO - 2022-03-18 03:47:37 --> Router Class Initialized
INFO - 2022-03-18 03:47:37 --> Output Class Initialized
INFO - 2022-03-18 03:47:37 --> Security Class Initialized
INFO - 2022-03-18 03:47:37 --> Input Class Initialized
INFO - 2022-03-18 03:47:37 --> Language Class Initialized
INFO - 2022-03-18 03:47:37 --> Loader Class Initialized
INFO - 2022-03-18 03:47:37 --> Helper loaded: url_helper
INFO - 2022-03-18 03:47:37 --> Helper loaded: form_helper
INFO - 2022-03-18 03:47:37 --> Database Driver Class Initialized
INFO - 2022-03-18 03:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:47:37 --> Controller Class Initialized
INFO - 2022-03-18 03:47:37 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:47:37 --> Final output sent to browser
INFO - 2022-03-18 03:47:41 --> Config Class Initialized
INFO - 2022-03-18 03:47:41 --> Hooks Class Initialized
INFO - 2022-03-18 03:47:41 --> Utf8 Class Initialized
INFO - 2022-03-18 03:47:41 --> URI Class Initialized
INFO - 2022-03-18 03:47:41 --> Router Class Initialized
INFO - 2022-03-18 03:47:41 --> Output Class Initialized
INFO - 2022-03-18 03:47:41 --> Security Class Initialized
INFO - 2022-03-18 03:47:41 --> Input Class Initialized
INFO - 2022-03-18 03:47:41 --> Language Class Initialized
INFO - 2022-03-18 03:47:41 --> Loader Class Initialized
INFO - 2022-03-18 03:47:41 --> Helper loaded: url_helper
INFO - 2022-03-18 03:47:41 --> Helper loaded: form_helper
INFO - 2022-03-18 03:47:41 --> Database Driver Class Initialized
INFO - 2022-03-18 03:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:47:41 --> Controller Class Initialized
INFO - 2022-03-18 03:47:41 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:47:41 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:47:41 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:47:41 --> Form Validation Class Initialized
INFO - 2022-03-18 03:47:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-18 03:47:41 --> Config Class Initialized
INFO - 2022-03-18 03:47:41 --> Hooks Class Initialized
INFO - 2022-03-18 03:47:41 --> Utf8 Class Initialized
INFO - 2022-03-18 03:47:41 --> URI Class Initialized
INFO - 2022-03-18 03:47:41 --> Router Class Initialized
INFO - 2022-03-18 03:47:41 --> Output Class Initialized
INFO - 2022-03-18 03:47:41 --> Security Class Initialized
INFO - 2022-03-18 03:47:41 --> Input Class Initialized
INFO - 2022-03-18 03:47:41 --> Language Class Initialized
INFO - 2022-03-18 03:47:41 --> Loader Class Initialized
INFO - 2022-03-18 03:47:41 --> Helper loaded: url_helper
INFO - 2022-03-18 03:47:41 --> Helper loaded: form_helper
INFO - 2022-03-18 03:47:41 --> Database Driver Class Initialized
INFO - 2022-03-18 03:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:47:41 --> Controller Class Initialized
INFO - 2022-03-18 03:47:41 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:47:41 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:47:41 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:47:41 --> Form Validation Class Initialized
INFO - 2022-03-18 03:47:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:47:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:47:41 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 03:47:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:47:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:47:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:47:41 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:47:41 --> Final output sent to browser
INFO - 2022-03-18 03:48:38 --> Config Class Initialized
INFO - 2022-03-18 03:48:38 --> Hooks Class Initialized
INFO - 2022-03-18 03:48:38 --> Utf8 Class Initialized
INFO - 2022-03-18 03:48:38 --> URI Class Initialized
INFO - 2022-03-18 03:48:38 --> Router Class Initialized
INFO - 2022-03-18 03:48:38 --> Output Class Initialized
INFO - 2022-03-18 03:48:38 --> Security Class Initialized
INFO - 2022-03-18 03:48:38 --> Input Class Initialized
INFO - 2022-03-18 03:48:38 --> Language Class Initialized
INFO - 2022-03-18 03:48:38 --> Loader Class Initialized
INFO - 2022-03-18 03:48:38 --> Helper loaded: url_helper
INFO - 2022-03-18 03:48:38 --> Helper loaded: form_helper
INFO - 2022-03-18 03:48:38 --> Database Driver Class Initialized
INFO - 2022-03-18 03:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:48:38 --> Controller Class Initialized
INFO - 2022-03-18 03:48:38 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:48:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:48:38 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:48:38 --> Form Validation Class Initialized
INFO - 2022-03-18 03:48:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:48:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:48:38 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:48:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:48:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:48:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:48:38 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:48:38 --> Final output sent to browser
INFO - 2022-03-18 03:48:45 --> Config Class Initialized
INFO - 2022-03-18 03:48:45 --> Hooks Class Initialized
INFO - 2022-03-18 03:48:45 --> Utf8 Class Initialized
INFO - 2022-03-18 03:48:45 --> URI Class Initialized
INFO - 2022-03-18 03:48:45 --> Router Class Initialized
INFO - 2022-03-18 03:48:45 --> Output Class Initialized
INFO - 2022-03-18 03:48:45 --> Security Class Initialized
INFO - 2022-03-18 03:48:45 --> Input Class Initialized
INFO - 2022-03-18 03:48:45 --> Language Class Initialized
INFO - 2022-03-18 03:48:45 --> Loader Class Initialized
INFO - 2022-03-18 03:48:45 --> Helper loaded: url_helper
INFO - 2022-03-18 03:48:45 --> Helper loaded: form_helper
INFO - 2022-03-18 03:48:45 --> Database Driver Class Initialized
INFO - 2022-03-18 03:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:48:45 --> Controller Class Initialized
INFO - 2022-03-18 03:48:45 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:48:45 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:48:45 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:48:45 --> Form Validation Class Initialized
INFO - 2022-03-18 03:48:45 --> Config Class Initialized
INFO - 2022-03-18 03:48:45 --> Hooks Class Initialized
INFO - 2022-03-18 03:48:45 --> Utf8 Class Initialized
INFO - 2022-03-18 03:48:45 --> URI Class Initialized
INFO - 2022-03-18 03:48:45 --> Router Class Initialized
INFO - 2022-03-18 03:48:45 --> Output Class Initialized
INFO - 2022-03-18 03:48:45 --> Security Class Initialized
INFO - 2022-03-18 03:48:45 --> Input Class Initialized
INFO - 2022-03-18 03:48:45 --> Language Class Initialized
INFO - 2022-03-18 03:48:45 --> Loader Class Initialized
INFO - 2022-03-18 03:48:45 --> Helper loaded: url_helper
INFO - 2022-03-18 03:48:45 --> Helper loaded: form_helper
INFO - 2022-03-18 03:48:45 --> Database Driver Class Initialized
INFO - 2022-03-18 03:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:48:45 --> Controller Class Initialized
INFO - 2022-03-18 03:48:45 --> Model "M_todo_group" initialized
INFO - 2022-03-18 03:48:45 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:48:45 --> Model "M_tutor" initialized
INFO - 2022-03-18 03:48:45 --> Form Validation Class Initialized
INFO - 2022-03-18 03:48:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:48:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:48:45 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 03:48:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:48:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:48:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:48:45 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:48:45 --> Final output sent to browser
INFO - 2022-03-18 03:49:25 --> Config Class Initialized
INFO - 2022-03-18 03:49:25 --> Hooks Class Initialized
INFO - 2022-03-18 03:49:25 --> Utf8 Class Initialized
INFO - 2022-03-18 03:49:25 --> URI Class Initialized
INFO - 2022-03-18 03:49:25 --> Router Class Initialized
INFO - 2022-03-18 03:49:25 --> Output Class Initialized
INFO - 2022-03-18 03:49:25 --> Security Class Initialized
INFO - 2022-03-18 03:49:25 --> Input Class Initialized
INFO - 2022-03-18 03:49:25 --> Language Class Initialized
INFO - 2022-03-18 03:49:26 --> Loader Class Initialized
INFO - 2022-03-18 03:49:26 --> Helper loaded: url_helper
INFO - 2022-03-18 03:49:26 --> Helper loaded: form_helper
INFO - 2022-03-18 03:49:26 --> Database Driver Class Initialized
INFO - 2022-03-18 03:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:49:26 --> Controller Class Initialized
INFO - 2022-03-18 03:49:26 --> Model "M_todo_list" initialized
INFO - 2022-03-18 03:49:26 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:49:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:49:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:49:26 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 03:49:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:49:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:49:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:49:26 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:49:26 --> Final output sent to browser
INFO - 2022-03-18 03:49:45 --> Config Class Initialized
INFO - 2022-03-18 03:49:45 --> Hooks Class Initialized
INFO - 2022-03-18 03:49:45 --> Utf8 Class Initialized
INFO - 2022-03-18 03:49:45 --> URI Class Initialized
INFO - 2022-03-18 03:49:45 --> Router Class Initialized
INFO - 2022-03-18 03:49:45 --> Output Class Initialized
INFO - 2022-03-18 03:49:45 --> Security Class Initialized
INFO - 2022-03-18 03:49:45 --> Input Class Initialized
INFO - 2022-03-18 03:49:45 --> Language Class Initialized
INFO - 2022-03-18 03:49:45 --> Loader Class Initialized
INFO - 2022-03-18 03:49:45 --> Helper loaded: url_helper
INFO - 2022-03-18 03:49:45 --> Helper loaded: form_helper
INFO - 2022-03-18 03:49:45 --> Database Driver Class Initialized
INFO - 2022-03-18 03:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:49:45 --> Controller Class Initialized
INFO - 2022-03-18 03:49:45 --> Model "M_todo_list" initialized
INFO - 2022-03-18 03:49:45 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:49:45 --> Final output sent to browser
INFO - 2022-03-18 03:49:56 --> Config Class Initialized
INFO - 2022-03-18 03:49:56 --> Hooks Class Initialized
INFO - 2022-03-18 03:49:56 --> Utf8 Class Initialized
INFO - 2022-03-18 03:49:56 --> URI Class Initialized
INFO - 2022-03-18 03:49:56 --> Router Class Initialized
INFO - 2022-03-18 03:49:56 --> Output Class Initialized
INFO - 2022-03-18 03:49:56 --> Security Class Initialized
INFO - 2022-03-18 03:49:56 --> Input Class Initialized
INFO - 2022-03-18 03:49:56 --> Language Class Initialized
INFO - 2022-03-18 03:49:56 --> Loader Class Initialized
INFO - 2022-03-18 03:49:56 --> Helper loaded: url_helper
INFO - 2022-03-18 03:49:56 --> Helper loaded: form_helper
INFO - 2022-03-18 03:49:56 --> Database Driver Class Initialized
INFO - 2022-03-18 03:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:49:56 --> Controller Class Initialized
INFO - 2022-03-18 03:49:56 --> Model "M_todo_list" initialized
INFO - 2022-03-18 03:49:56 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 03:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 03:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 03:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 03:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 03:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 03:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 03:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 03:49:56 --> Final output sent to browser
INFO - 2022-03-18 03:51:03 --> Config Class Initialized
INFO - 2022-03-18 03:51:03 --> Hooks Class Initialized
INFO - 2022-03-18 03:51:03 --> Utf8 Class Initialized
INFO - 2022-03-18 03:51:03 --> URI Class Initialized
INFO - 2022-03-18 03:51:03 --> Router Class Initialized
INFO - 2022-03-18 03:51:03 --> Output Class Initialized
INFO - 2022-03-18 03:51:03 --> Security Class Initialized
INFO - 2022-03-18 03:51:03 --> Input Class Initialized
INFO - 2022-03-18 03:51:03 --> Language Class Initialized
INFO - 2022-03-18 03:51:03 --> Loader Class Initialized
INFO - 2022-03-18 03:51:03 --> Helper loaded: url_helper
INFO - 2022-03-18 03:51:03 --> Helper loaded: form_helper
INFO - 2022-03-18 03:51:03 --> Database Driver Class Initialized
INFO - 2022-03-18 03:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 03:51:03 --> Controller Class Initialized
INFO - 2022-03-18 03:51:03 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 03:51:03 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 03:51:03 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 03:51:03 --> Final output sent to browser
INFO - 2022-03-18 04:05:01 --> Config Class Initialized
INFO - 2022-03-18 04:05:01 --> Hooks Class Initialized
INFO - 2022-03-18 04:05:01 --> Utf8 Class Initialized
INFO - 2022-03-18 04:05:01 --> URI Class Initialized
INFO - 2022-03-18 04:05:01 --> Router Class Initialized
INFO - 2022-03-18 04:05:01 --> Output Class Initialized
INFO - 2022-03-18 04:05:01 --> Security Class Initialized
INFO - 2022-03-18 04:05:01 --> Input Class Initialized
INFO - 2022-03-18 04:05:01 --> Language Class Initialized
ERROR - 2022-03-18 04:05:01 --> 404 Page Not Found: Tutor/index
INFO - 2022-03-18 04:05:09 --> Config Class Initialized
INFO - 2022-03-18 04:05:09 --> Hooks Class Initialized
INFO - 2022-03-18 04:05:09 --> Utf8 Class Initialized
INFO - 2022-03-18 04:05:09 --> URI Class Initialized
INFO - 2022-03-18 04:05:09 --> Router Class Initialized
INFO - 2022-03-18 04:05:09 --> Output Class Initialized
INFO - 2022-03-18 04:05:09 --> Security Class Initialized
INFO - 2022-03-18 04:05:09 --> Input Class Initialized
INFO - 2022-03-18 04:05:09 --> Language Class Initialized
INFO - 2022-03-18 04:05:09 --> Loader Class Initialized
INFO - 2022-03-18 04:05:09 --> Helper loaded: url_helper
INFO - 2022-03-18 04:05:09 --> Helper loaded: form_helper
INFO - 2022-03-18 04:05:09 --> Database Driver Class Initialized
INFO - 2022-03-18 04:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 04:05:09 --> Form Validation Class Initialized
INFO - 2022-03-18 04:05:09 --> Controller Class Initialized
INFO - 2022-03-18 04:05:09 --> Model "M_tutor" initialized
INFO - 2022-03-18 04:05:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 04:05:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 04:05:09 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 04:05:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 04:05:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 04:05:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 04:05:09 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 04:05:09 --> Final output sent to browser
INFO - 2022-03-18 04:05:12 --> Config Class Initialized
INFO - 2022-03-18 04:05:12 --> Hooks Class Initialized
INFO - 2022-03-18 04:05:12 --> Utf8 Class Initialized
INFO - 2022-03-18 04:05:12 --> URI Class Initialized
INFO - 2022-03-18 04:05:12 --> Router Class Initialized
INFO - 2022-03-18 04:05:12 --> Output Class Initialized
INFO - 2022-03-18 04:05:12 --> Security Class Initialized
INFO - 2022-03-18 04:05:12 --> Input Class Initialized
INFO - 2022-03-18 04:05:12 --> Language Class Initialized
INFO - 2022-03-18 04:05:12 --> Loader Class Initialized
INFO - 2022-03-18 04:05:12 --> Helper loaded: url_helper
INFO - 2022-03-18 04:05:12 --> Helper loaded: form_helper
INFO - 2022-03-18 04:05:12 --> Database Driver Class Initialized
INFO - 2022-03-18 04:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 04:05:12 --> Form Validation Class Initialized
INFO - 2022-03-18 04:05:12 --> Controller Class Initialized
INFO - 2022-03-18 04:05:12 --> Model "M_tutor" initialized
INFO - 2022-03-18 04:05:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 04:05:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 04:05:12 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_tambah.php
INFO - 2022-03-18 04:05:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 04:05:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 04:05:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 04:05:12 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 04:05:12 --> Final output sent to browser
INFO - 2022-03-18 04:05:18 --> Config Class Initialized
INFO - 2022-03-18 04:05:18 --> Hooks Class Initialized
INFO - 2022-03-18 04:05:18 --> Utf8 Class Initialized
INFO - 2022-03-18 04:05:18 --> URI Class Initialized
INFO - 2022-03-18 04:05:18 --> Router Class Initialized
INFO - 2022-03-18 04:05:18 --> Output Class Initialized
INFO - 2022-03-18 04:05:18 --> Security Class Initialized
INFO - 2022-03-18 04:05:18 --> Input Class Initialized
INFO - 2022-03-18 04:05:18 --> Language Class Initialized
INFO - 2022-03-18 04:05:18 --> Loader Class Initialized
INFO - 2022-03-18 04:05:18 --> Helper loaded: url_helper
INFO - 2022-03-18 04:05:18 --> Helper loaded: form_helper
INFO - 2022-03-18 04:05:18 --> Database Driver Class Initialized
INFO - 2022-03-18 04:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 04:05:18 --> Form Validation Class Initialized
INFO - 2022-03-18 04:05:18 --> Controller Class Initialized
INFO - 2022-03-18 04:05:18 --> Model "M_tutor" initialized
ERROR - 2022-03-18 04:05:19 --> Query error: Unknown column 'user' in 'field list' - Invalid query: INSERT INTO `tutor` (`nama`, `user`, `pass`, `jabatan`) VALUES ('tes', 'tes', '$2y$10$szbblEUvYsNRygHMUm4pWeq9XCV3bUQ5ohvNSl28RJOtEF97.p8OS', 'T')
INFO - 2022-03-18 04:05:19 --> Language file loaded: language/english/db_lang.php
INFO - 2022-03-18 04:06:18 --> Config Class Initialized
INFO - 2022-03-18 04:06:18 --> Hooks Class Initialized
INFO - 2022-03-18 04:06:18 --> Utf8 Class Initialized
INFO - 2022-03-18 04:06:18 --> URI Class Initialized
INFO - 2022-03-18 04:06:18 --> Router Class Initialized
INFO - 2022-03-18 04:06:18 --> Output Class Initialized
INFO - 2022-03-18 04:06:18 --> Security Class Initialized
INFO - 2022-03-18 04:06:18 --> Input Class Initialized
INFO - 2022-03-18 04:06:18 --> Language Class Initialized
INFO - 2022-03-18 04:06:18 --> Loader Class Initialized
INFO - 2022-03-18 04:06:18 --> Helper loaded: url_helper
INFO - 2022-03-18 04:06:18 --> Helper loaded: form_helper
INFO - 2022-03-18 04:06:18 --> Database Driver Class Initialized
INFO - 2022-03-18 04:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 04:06:18 --> Form Validation Class Initialized
INFO - 2022-03-18 04:06:18 --> Controller Class Initialized
INFO - 2022-03-18 04:06:18 --> Model "M_tutor" initialized
INFO - 2022-03-18 04:06:18 --> Config Class Initialized
INFO - 2022-03-18 04:06:18 --> Hooks Class Initialized
INFO - 2022-03-18 04:06:18 --> Utf8 Class Initialized
INFO - 2022-03-18 04:06:18 --> URI Class Initialized
INFO - 2022-03-18 04:06:18 --> Router Class Initialized
INFO - 2022-03-18 04:06:18 --> Output Class Initialized
INFO - 2022-03-18 04:06:18 --> Security Class Initialized
INFO - 2022-03-18 04:06:18 --> Input Class Initialized
INFO - 2022-03-18 04:06:18 --> Language Class Initialized
ERROR - 2022-03-18 04:06:18 --> 404 Page Not Found: Tutor/index
INFO - 2022-03-18 04:07:11 --> Config Class Initialized
INFO - 2022-03-18 04:07:11 --> Hooks Class Initialized
INFO - 2022-03-18 04:07:11 --> Utf8 Class Initialized
INFO - 2022-03-18 04:07:11 --> URI Class Initialized
INFO - 2022-03-18 04:07:11 --> Router Class Initialized
INFO - 2022-03-18 04:07:11 --> Output Class Initialized
INFO - 2022-03-18 04:07:11 --> Security Class Initialized
INFO - 2022-03-18 04:07:11 --> Input Class Initialized
INFO - 2022-03-18 04:07:11 --> Language Class Initialized
INFO - 2022-03-18 04:07:11 --> Loader Class Initialized
INFO - 2022-03-18 04:07:11 --> Helper loaded: url_helper
INFO - 2022-03-18 04:07:11 --> Helper loaded: form_helper
INFO - 2022-03-18 04:07:11 --> Database Driver Class Initialized
INFO - 2022-03-18 04:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 04:07:11 --> Form Validation Class Initialized
INFO - 2022-03-18 04:07:11 --> Controller Class Initialized
INFO - 2022-03-18 04:07:11 --> Model "M_tutor" initialized
INFO - 2022-03-18 04:07:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 04:07:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 04:07:11 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 04:07:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 04:07:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 04:07:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 04:07:11 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 04:07:11 --> Final output sent to browser
INFO - 2022-03-18 04:07:17 --> Config Class Initialized
INFO - 2022-03-18 04:07:17 --> Hooks Class Initialized
INFO - 2022-03-18 04:07:17 --> Utf8 Class Initialized
INFO - 2022-03-18 04:07:17 --> URI Class Initialized
INFO - 2022-03-18 04:07:17 --> Router Class Initialized
INFO - 2022-03-18 04:07:18 --> Output Class Initialized
INFO - 2022-03-18 04:07:18 --> Security Class Initialized
INFO - 2022-03-18 04:07:18 --> Input Class Initialized
INFO - 2022-03-18 04:07:18 --> Language Class Initialized
INFO - 2022-03-18 04:07:18 --> Loader Class Initialized
INFO - 2022-03-18 04:07:18 --> Helper loaded: url_helper
INFO - 2022-03-18 04:07:18 --> Helper loaded: form_helper
INFO - 2022-03-18 04:07:18 --> Database Driver Class Initialized
INFO - 2022-03-18 04:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 04:07:18 --> Form Validation Class Initialized
INFO - 2022-03-18 04:07:18 --> Controller Class Initialized
INFO - 2022-03-18 04:07:18 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 04:07:18 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 04:07:18 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 04:07:18 --> Final output sent to browser
INFO - 2022-03-18 04:07:23 --> Config Class Initialized
INFO - 2022-03-18 04:07:23 --> Hooks Class Initialized
INFO - 2022-03-18 04:07:24 --> Utf8 Class Initialized
INFO - 2022-03-18 04:07:24 --> URI Class Initialized
INFO - 2022-03-18 04:07:24 --> Router Class Initialized
INFO - 2022-03-18 04:07:24 --> Output Class Initialized
INFO - 2022-03-18 04:07:24 --> Security Class Initialized
INFO - 2022-03-18 04:07:24 --> Input Class Initialized
INFO - 2022-03-18 04:07:24 --> Language Class Initialized
INFO - 2022-03-18 04:07:24 --> Loader Class Initialized
INFO - 2022-03-18 04:07:24 --> Helper loaded: url_helper
INFO - 2022-03-18 04:07:24 --> Helper loaded: form_helper
INFO - 2022-03-18 04:07:24 --> Database Driver Class Initialized
INFO - 2022-03-18 04:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 04:07:24 --> Form Validation Class Initialized
INFO - 2022-03-18 04:07:24 --> Controller Class Initialized
INFO - 2022-03-18 04:07:24 --> Model "M_tutor" initialized
INFO - 2022-03-18 04:07:24 --> Config Class Initialized
INFO - 2022-03-18 04:07:24 --> Hooks Class Initialized
INFO - 2022-03-18 04:07:24 --> Utf8 Class Initialized
INFO - 2022-03-18 04:07:24 --> URI Class Initialized
INFO - 2022-03-18 04:07:24 --> Router Class Initialized
INFO - 2022-03-18 04:07:24 --> Output Class Initialized
INFO - 2022-03-18 04:07:24 --> Security Class Initialized
INFO - 2022-03-18 04:07:24 --> Input Class Initialized
INFO - 2022-03-18 04:07:24 --> Language Class Initialized
ERROR - 2022-03-18 04:07:24 --> 404 Page Not Found: Home/index
INFO - 2022-03-18 04:10:35 --> Config Class Initialized
INFO - 2022-03-18 04:10:35 --> Hooks Class Initialized
INFO - 2022-03-18 04:10:35 --> Utf8 Class Initialized
INFO - 2022-03-18 04:10:35 --> URI Class Initialized
INFO - 2022-03-18 04:10:35 --> Router Class Initialized
INFO - 2022-03-18 04:10:35 --> Output Class Initialized
INFO - 2022-03-18 04:10:35 --> Security Class Initialized
INFO - 2022-03-18 04:10:35 --> Input Class Initialized
INFO - 2022-03-18 04:10:35 --> Language Class Initialized
ERROR - 2022-03-18 04:10:35 --> 404 Page Not Found: Home/index
INFO - 2022-03-18 04:10:39 --> Config Class Initialized
INFO - 2022-03-18 04:10:39 --> Hooks Class Initialized
INFO - 2022-03-18 04:10:39 --> Utf8 Class Initialized
INFO - 2022-03-18 04:10:39 --> URI Class Initialized
INFO - 2022-03-18 04:10:39 --> Router Class Initialized
INFO - 2022-03-18 04:10:39 --> Output Class Initialized
INFO - 2022-03-18 04:10:39 --> Security Class Initialized
INFO - 2022-03-18 04:10:39 --> Input Class Initialized
INFO - 2022-03-18 04:10:39 --> Language Class Initialized
INFO - 2022-03-18 04:10:39 --> Loader Class Initialized
INFO - 2022-03-18 04:10:39 --> Helper loaded: url_helper
INFO - 2022-03-18 04:10:39 --> Helper loaded: form_helper
INFO - 2022-03-18 04:10:39 --> Database Driver Class Initialized
INFO - 2022-03-18 04:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 04:10:39 --> Form Validation Class Initialized
INFO - 2022-03-18 04:10:39 --> Controller Class Initialized
INFO - 2022-03-18 04:10:39 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 04:10:39 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 04:10:39 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 04:10:39 --> Final output sent to browser
INFO - 2022-03-18 04:10:43 --> Config Class Initialized
INFO - 2022-03-18 04:10:43 --> Hooks Class Initialized
INFO - 2022-03-18 04:10:43 --> Utf8 Class Initialized
INFO - 2022-03-18 04:10:43 --> URI Class Initialized
INFO - 2022-03-18 04:10:43 --> Router Class Initialized
INFO - 2022-03-18 04:10:43 --> Output Class Initialized
INFO - 2022-03-18 04:10:43 --> Security Class Initialized
INFO - 2022-03-18 04:10:43 --> Input Class Initialized
INFO - 2022-03-18 04:10:43 --> Language Class Initialized
INFO - 2022-03-18 04:10:43 --> Loader Class Initialized
INFO - 2022-03-18 04:10:43 --> Helper loaded: url_helper
INFO - 2022-03-18 04:10:43 --> Helper loaded: form_helper
INFO - 2022-03-18 04:10:43 --> Database Driver Class Initialized
INFO - 2022-03-18 04:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 04:10:44 --> Form Validation Class Initialized
INFO - 2022-03-18 04:10:44 --> Controller Class Initialized
INFO - 2022-03-18 04:10:44 --> Model "M_tutor" initialized
INFO - 2022-03-18 04:10:44 --> Final output sent to browser
INFO - 2022-03-18 17:59:05 --> Config Class Initialized
INFO - 2022-03-18 17:59:05 --> Hooks Class Initialized
INFO - 2022-03-18 17:59:05 --> Utf8 Class Initialized
INFO - 2022-03-18 17:59:05 --> URI Class Initialized
INFO - 2022-03-18 17:59:05 --> Router Class Initialized
INFO - 2022-03-18 17:59:05 --> Output Class Initialized
INFO - 2022-03-18 17:59:05 --> Security Class Initialized
INFO - 2022-03-18 17:59:05 --> Input Class Initialized
INFO - 2022-03-18 17:59:05 --> Language Class Initialized
INFO - 2022-03-18 17:59:05 --> Loader Class Initialized
INFO - 2022-03-18 17:59:05 --> Helper loaded: url_helper
INFO - 2022-03-18 17:59:05 --> Helper loaded: form_helper
INFO - 2022-03-18 17:59:05 --> Database Driver Class Initialized
INFO - 2022-03-18 17:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 17:59:05 --> Form Validation Class Initialized
INFO - 2022-03-18 17:59:05 --> Controller Class Initialized
INFO - 2022-03-18 17:59:05 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 17:59:05 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 17:59:05 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 17:59:05 --> Final output sent to browser
INFO - 2022-03-18 17:59:15 --> Config Class Initialized
INFO - 2022-03-18 17:59:15 --> Hooks Class Initialized
INFO - 2022-03-18 17:59:15 --> Utf8 Class Initialized
INFO - 2022-03-18 17:59:15 --> URI Class Initialized
INFO - 2022-03-18 17:59:15 --> Router Class Initialized
INFO - 2022-03-18 17:59:15 --> Output Class Initialized
INFO - 2022-03-18 17:59:15 --> Security Class Initialized
INFO - 2022-03-18 17:59:15 --> Input Class Initialized
INFO - 2022-03-18 17:59:15 --> Language Class Initialized
ERROR - 2022-03-18 17:59:15 --> 404 Page Not Found: Home/index
INFO - 2022-03-18 18:00:40 --> Config Class Initialized
INFO - 2022-03-18 18:00:40 --> Hooks Class Initialized
INFO - 2022-03-18 18:00:40 --> Utf8 Class Initialized
INFO - 2022-03-18 18:00:40 --> URI Class Initialized
INFO - 2022-03-18 18:00:40 --> Router Class Initialized
INFO - 2022-03-18 18:00:40 --> Output Class Initialized
INFO - 2022-03-18 18:00:40 --> Security Class Initialized
INFO - 2022-03-18 18:00:40 --> Input Class Initialized
INFO - 2022-03-18 18:00:40 --> Language Class Initialized
ERROR - 2022-03-18 18:00:40 --> 404 Page Not Found: Login/index
INFO - 2022-03-18 18:00:45 --> Config Class Initialized
INFO - 2022-03-18 18:00:45 --> Hooks Class Initialized
INFO - 2022-03-18 18:00:45 --> Utf8 Class Initialized
INFO - 2022-03-18 18:00:45 --> URI Class Initialized
INFO - 2022-03-18 18:00:45 --> Router Class Initialized
INFO - 2022-03-18 18:00:45 --> Output Class Initialized
INFO - 2022-03-18 18:00:45 --> Security Class Initialized
INFO - 2022-03-18 18:00:45 --> Input Class Initialized
INFO - 2022-03-18 18:00:45 --> Language Class Initialized
INFO - 2022-03-18 18:00:45 --> Loader Class Initialized
INFO - 2022-03-18 18:00:45 --> Helper loaded: url_helper
INFO - 2022-03-18 18:00:45 --> Helper loaded: form_helper
INFO - 2022-03-18 18:00:45 --> Database Driver Class Initialized
INFO - 2022-03-18 18:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:00:45 --> Form Validation Class Initialized
INFO - 2022-03-18 18:00:45 --> Controller Class Initialized
INFO - 2022-03-18 18:00:45 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:00:45 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:00:45 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:00:45 --> Final output sent to browser
INFO - 2022-03-18 18:00:56 --> Config Class Initialized
INFO - 2022-03-18 18:00:56 --> Hooks Class Initialized
INFO - 2022-03-18 18:00:56 --> Utf8 Class Initialized
INFO - 2022-03-18 18:00:56 --> URI Class Initialized
INFO - 2022-03-18 18:00:56 --> Router Class Initialized
INFO - 2022-03-18 18:00:56 --> Output Class Initialized
INFO - 2022-03-18 18:00:56 --> Security Class Initialized
INFO - 2022-03-18 18:00:56 --> Input Class Initialized
INFO - 2022-03-18 18:00:56 --> Language Class Initialized
INFO - 2022-03-18 18:00:56 --> Loader Class Initialized
INFO - 2022-03-18 18:00:56 --> Helper loaded: url_helper
INFO - 2022-03-18 18:00:56 --> Helper loaded: form_helper
INFO - 2022-03-18 18:00:56 --> Database Driver Class Initialized
INFO - 2022-03-18 18:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:00:56 --> Form Validation Class Initialized
INFO - 2022-03-18 18:00:56 --> Controller Class Initialized
INFO - 2022-03-18 18:00:56 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:00:57 --> Config Class Initialized
INFO - 2022-03-18 18:00:57 --> Hooks Class Initialized
INFO - 2022-03-18 18:00:57 --> Utf8 Class Initialized
INFO - 2022-03-18 18:00:57 --> URI Class Initialized
INFO - 2022-03-18 18:00:57 --> Router Class Initialized
INFO - 2022-03-18 18:00:57 --> Output Class Initialized
INFO - 2022-03-18 18:00:57 --> Security Class Initialized
INFO - 2022-03-18 18:00:57 --> Input Class Initialized
INFO - 2022-03-18 18:00:57 --> Language Class Initialized
ERROR - 2022-03-18 18:00:57 --> 404 Page Not Found: Login/index
INFO - 2022-03-18 18:01:45 --> Config Class Initialized
INFO - 2022-03-18 18:01:45 --> Hooks Class Initialized
INFO - 2022-03-18 18:01:45 --> Utf8 Class Initialized
INFO - 2022-03-18 18:01:45 --> URI Class Initialized
INFO - 2022-03-18 18:01:45 --> Router Class Initialized
INFO - 2022-03-18 18:01:45 --> Output Class Initialized
INFO - 2022-03-18 18:01:45 --> Security Class Initialized
INFO - 2022-03-18 18:01:45 --> Input Class Initialized
INFO - 2022-03-18 18:01:45 --> Language Class Initialized
ERROR - 2022-03-18 18:01:45 --> 404 Page Not Found: Login/index
INFO - 2022-03-18 18:01:46 --> Config Class Initialized
INFO - 2022-03-18 18:01:46 --> Hooks Class Initialized
INFO - 2022-03-18 18:01:46 --> Utf8 Class Initialized
INFO - 2022-03-18 18:01:46 --> URI Class Initialized
INFO - 2022-03-18 18:01:46 --> Router Class Initialized
INFO - 2022-03-18 18:01:47 --> Output Class Initialized
INFO - 2022-03-18 18:01:47 --> Security Class Initialized
INFO - 2022-03-18 18:01:47 --> Input Class Initialized
INFO - 2022-03-18 18:01:47 --> Language Class Initialized
INFO - 2022-03-18 18:01:47 --> Loader Class Initialized
INFO - 2022-03-18 18:01:47 --> Helper loaded: url_helper
INFO - 2022-03-18 18:01:47 --> Helper loaded: form_helper
INFO - 2022-03-18 18:01:47 --> Database Driver Class Initialized
INFO - 2022-03-18 18:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:01:47 --> Form Validation Class Initialized
INFO - 2022-03-18 18:01:47 --> Controller Class Initialized
INFO - 2022-03-18 18:01:47 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:01:47 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:01:47 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:01:47 --> Final output sent to browser
INFO - 2022-03-18 18:01:52 --> Config Class Initialized
INFO - 2022-03-18 18:01:52 --> Hooks Class Initialized
INFO - 2022-03-18 18:01:52 --> Utf8 Class Initialized
INFO - 2022-03-18 18:01:52 --> URI Class Initialized
INFO - 2022-03-18 18:01:52 --> Router Class Initialized
INFO - 2022-03-18 18:01:52 --> Output Class Initialized
INFO - 2022-03-18 18:01:52 --> Security Class Initialized
INFO - 2022-03-18 18:01:52 --> Input Class Initialized
INFO - 2022-03-18 18:01:52 --> Language Class Initialized
INFO - 2022-03-18 18:01:52 --> Loader Class Initialized
INFO - 2022-03-18 18:01:52 --> Helper loaded: url_helper
INFO - 2022-03-18 18:01:52 --> Helper loaded: form_helper
INFO - 2022-03-18 18:01:52 --> Database Driver Class Initialized
INFO - 2022-03-18 18:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:01:52 --> Form Validation Class Initialized
INFO - 2022-03-18 18:01:52 --> Controller Class Initialized
INFO - 2022-03-18 18:01:52 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:01:52 --> Config Class Initialized
INFO - 2022-03-18 18:01:52 --> Hooks Class Initialized
INFO - 2022-03-18 18:01:52 --> Utf8 Class Initialized
INFO - 2022-03-18 18:01:52 --> URI Class Initialized
INFO - 2022-03-18 18:01:52 --> Router Class Initialized
INFO - 2022-03-18 18:01:52 --> Output Class Initialized
INFO - 2022-03-18 18:01:52 --> Security Class Initialized
INFO - 2022-03-18 18:01:52 --> Input Class Initialized
INFO - 2022-03-18 18:01:52 --> Language Class Initialized
INFO - 2022-03-18 18:01:52 --> Loader Class Initialized
INFO - 2022-03-18 18:01:52 --> Helper loaded: url_helper
INFO - 2022-03-18 18:01:52 --> Helper loaded: form_helper
INFO - 2022-03-18 18:01:52 --> Database Driver Class Initialized
INFO - 2022-03-18 18:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:01:52 --> Form Validation Class Initialized
INFO - 2022-03-18 18:01:52 --> Controller Class Initialized
INFO - 2022-03-18 18:01:52 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:01:52 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:01:52 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:01:52 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:01:52 --> Final output sent to browser
INFO - 2022-03-18 18:03:03 --> Config Class Initialized
INFO - 2022-03-18 18:03:03 --> Hooks Class Initialized
INFO - 2022-03-18 18:03:03 --> Utf8 Class Initialized
INFO - 2022-03-18 18:03:03 --> URI Class Initialized
INFO - 2022-03-18 18:03:03 --> Router Class Initialized
INFO - 2022-03-18 18:03:03 --> Output Class Initialized
INFO - 2022-03-18 18:03:03 --> Security Class Initialized
INFO - 2022-03-18 18:03:03 --> Input Class Initialized
INFO - 2022-03-18 18:03:03 --> Language Class Initialized
INFO - 2022-03-18 18:03:03 --> Loader Class Initialized
INFO - 2022-03-18 18:03:03 --> Helper loaded: url_helper
INFO - 2022-03-18 18:03:03 --> Helper loaded: form_helper
INFO - 2022-03-18 18:03:03 --> Database Driver Class Initialized
INFO - 2022-03-18 18:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:03:03 --> Form Validation Class Initialized
INFO - 2022-03-18 18:03:03 --> Controller Class Initialized
INFO - 2022-03-18 18:03:03 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:03:03 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:03:03 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:03:03 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:03:03 --> Final output sent to browser
INFO - 2022-03-18 18:03:08 --> Config Class Initialized
INFO - 2022-03-18 18:03:08 --> Hooks Class Initialized
INFO - 2022-03-18 18:03:08 --> Utf8 Class Initialized
INFO - 2022-03-18 18:03:08 --> URI Class Initialized
INFO - 2022-03-18 18:03:08 --> Router Class Initialized
INFO - 2022-03-18 18:03:08 --> Output Class Initialized
INFO - 2022-03-18 18:03:08 --> Security Class Initialized
INFO - 2022-03-18 18:03:08 --> Input Class Initialized
INFO - 2022-03-18 18:03:08 --> Language Class Initialized
INFO - 2022-03-18 18:03:08 --> Loader Class Initialized
INFO - 2022-03-18 18:03:08 --> Helper loaded: url_helper
INFO - 2022-03-18 18:03:08 --> Helper loaded: form_helper
INFO - 2022-03-18 18:03:08 --> Database Driver Class Initialized
INFO - 2022-03-18 18:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:03:08 --> Form Validation Class Initialized
INFO - 2022-03-18 18:03:08 --> Controller Class Initialized
INFO - 2022-03-18 18:03:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:03:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:03:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:03:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:03:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:03:08 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:03:08 --> Final output sent to browser
INFO - 2022-03-18 18:03:09 --> Config Class Initialized
INFO - 2022-03-18 18:03:09 --> Hooks Class Initialized
INFO - 2022-03-18 18:03:09 --> Utf8 Class Initialized
INFO - 2022-03-18 18:03:09 --> URI Class Initialized
INFO - 2022-03-18 18:03:09 --> Config Class Initialized
INFO - 2022-03-18 18:03:09 --> Hooks Class Initialized
INFO - 2022-03-18 18:03:09 --> Router Class Initialized
INFO - 2022-03-18 18:03:09 --> Output Class Initialized
INFO - 2022-03-18 18:03:09 --> Utf8 Class Initialized
INFO - 2022-03-18 18:03:09 --> Security Class Initialized
INFO - 2022-03-18 18:03:09 --> URI Class Initialized
INFO - 2022-03-18 18:03:09 --> Input Class Initialized
INFO - 2022-03-18 18:03:09 --> Language Class Initialized
ERROR - 2022-03-18 18:03:09 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:03:09 --> Router Class Initialized
INFO - 2022-03-18 18:03:09 --> Output Class Initialized
INFO - 2022-03-18 18:03:09 --> Security Class Initialized
INFO - 2022-03-18 18:03:09 --> Input Class Initialized
INFO - 2022-03-18 18:03:09 --> Language Class Initialized
ERROR - 2022-03-18 18:03:09 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:05:41 --> Config Class Initialized
INFO - 2022-03-18 18:05:41 --> Hooks Class Initialized
INFO - 2022-03-18 18:05:41 --> Utf8 Class Initialized
INFO - 2022-03-18 18:05:41 --> URI Class Initialized
INFO - 2022-03-18 18:05:41 --> Router Class Initialized
INFO - 2022-03-18 18:05:41 --> Output Class Initialized
INFO - 2022-03-18 18:05:41 --> Security Class Initialized
INFO - 2022-03-18 18:05:41 --> Input Class Initialized
INFO - 2022-03-18 18:05:41 --> Language Class Initialized
INFO - 2022-03-18 18:05:41 --> Loader Class Initialized
INFO - 2022-03-18 18:05:41 --> Helper loaded: url_helper
INFO - 2022-03-18 18:05:41 --> Helper loaded: form_helper
INFO - 2022-03-18 18:05:41 --> Database Driver Class Initialized
INFO - 2022-03-18 18:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:05:41 --> Form Validation Class Initialized
INFO - 2022-03-18 18:05:41 --> Controller Class Initialized
INFO - 2022-03-18 18:05:41 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:05:41 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:05:41 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:05:41 --> Final output sent to browser
INFO - 2022-03-18 18:05:46 --> Config Class Initialized
INFO - 2022-03-18 18:05:46 --> Hooks Class Initialized
INFO - 2022-03-18 18:05:46 --> Utf8 Class Initialized
INFO - 2022-03-18 18:05:46 --> URI Class Initialized
INFO - 2022-03-18 18:05:46 --> Router Class Initialized
INFO - 2022-03-18 18:05:46 --> Output Class Initialized
INFO - 2022-03-18 18:05:46 --> Security Class Initialized
INFO - 2022-03-18 18:05:46 --> Input Class Initialized
INFO - 2022-03-18 18:05:46 --> Language Class Initialized
INFO - 2022-03-18 18:05:46 --> Loader Class Initialized
INFO - 2022-03-18 18:05:46 --> Helper loaded: url_helper
INFO - 2022-03-18 18:05:46 --> Helper loaded: form_helper
INFO - 2022-03-18 18:05:46 --> Database Driver Class Initialized
INFO - 2022-03-18 18:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:05:46 --> Form Validation Class Initialized
INFO - 2022-03-18 18:05:46 --> Controller Class Initialized
INFO - 2022-03-18 18:05:46 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:05:46 --> Config Class Initialized
INFO - 2022-03-18 18:05:46 --> Hooks Class Initialized
INFO - 2022-03-18 18:05:46 --> Utf8 Class Initialized
INFO - 2022-03-18 18:05:46 --> URI Class Initialized
INFO - 2022-03-18 18:05:46 --> Router Class Initialized
INFO - 2022-03-18 18:05:46 --> Output Class Initialized
INFO - 2022-03-18 18:05:46 --> Security Class Initialized
INFO - 2022-03-18 18:05:46 --> Input Class Initialized
INFO - 2022-03-18 18:05:46 --> Language Class Initialized
INFO - 2022-03-18 18:05:46 --> Loader Class Initialized
INFO - 2022-03-18 18:05:46 --> Helper loaded: url_helper
INFO - 2022-03-18 18:05:46 --> Helper loaded: form_helper
INFO - 2022-03-18 18:05:46 --> Database Driver Class Initialized
INFO - 2022-03-18 18:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:05:46 --> Form Validation Class Initialized
INFO - 2022-03-18 18:05:46 --> Controller Class Initialized
INFO - 2022-03-18 18:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:05:46 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:05:46 --> Final output sent to browser
INFO - 2022-03-18 18:05:47 --> Config Class Initialized
INFO - 2022-03-18 18:05:47 --> Config Class Initialized
INFO - 2022-03-18 18:05:47 --> Hooks Class Initialized
INFO - 2022-03-18 18:05:47 --> Hooks Class Initialized
INFO - 2022-03-18 18:05:47 --> Utf8 Class Initialized
INFO - 2022-03-18 18:05:47 --> URI Class Initialized
INFO - 2022-03-18 18:05:48 --> Router Class Initialized
INFO - 2022-03-18 18:05:48 --> Utf8 Class Initialized
INFO - 2022-03-18 18:05:48 --> URI Class Initialized
INFO - 2022-03-18 18:05:48 --> Output Class Initialized
INFO - 2022-03-18 18:05:48 --> Router Class Initialized
INFO - 2022-03-18 18:05:48 --> Output Class Initialized
INFO - 2022-03-18 18:05:48 --> Security Class Initialized
INFO - 2022-03-18 18:05:48 --> Input Class Initialized
INFO - 2022-03-18 18:05:48 --> Security Class Initialized
INFO - 2022-03-18 18:05:48 --> Language Class Initialized
INFO - 2022-03-18 18:05:48 --> Input Class Initialized
ERROR - 2022-03-18 18:05:48 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:05:48 --> Language Class Initialized
ERROR - 2022-03-18 18:05:48 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:07:28 --> Config Class Initialized
INFO - 2022-03-18 18:07:28 --> Hooks Class Initialized
INFO - 2022-03-18 18:07:28 --> Utf8 Class Initialized
INFO - 2022-03-18 18:07:28 --> URI Class Initialized
INFO - 2022-03-18 18:07:28 --> Router Class Initialized
INFO - 2022-03-18 18:07:28 --> Output Class Initialized
INFO - 2022-03-18 18:07:28 --> Security Class Initialized
INFO - 2022-03-18 18:07:28 --> Input Class Initialized
INFO - 2022-03-18 18:07:28 --> Language Class Initialized
INFO - 2022-03-18 18:07:28 --> Loader Class Initialized
INFO - 2022-03-18 18:07:28 --> Helper loaded: url_helper
INFO - 2022-03-18 18:07:28 --> Helper loaded: form_helper
INFO - 2022-03-18 18:07:28 --> Database Driver Class Initialized
INFO - 2022-03-18 18:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:07:28 --> Form Validation Class Initialized
INFO - 2022-03-18 18:07:28 --> Controller Class Initialized
ERROR - 2022-03-18 18:07:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth C:\laragon\www\list-todo\system\core\Loader.php 348
INFO - 2022-03-18 18:09:08 --> Config Class Initialized
INFO - 2022-03-18 18:09:08 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:08 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:08 --> URI Class Initialized
INFO - 2022-03-18 18:09:08 --> Router Class Initialized
INFO - 2022-03-18 18:09:08 --> Output Class Initialized
INFO - 2022-03-18 18:09:08 --> Security Class Initialized
INFO - 2022-03-18 18:09:08 --> Input Class Initialized
INFO - 2022-03-18 18:09:08 --> Language Class Initialized
INFO - 2022-03-18 18:09:08 --> Loader Class Initialized
INFO - 2022-03-18 18:09:08 --> Helper loaded: url_helper
INFO - 2022-03-18 18:09:08 --> Helper loaded: form_helper
INFO - 2022-03-18 18:09:08 --> Database Driver Class Initialized
INFO - 2022-03-18 18:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:09:08 --> Form Validation Class Initialized
INFO - 2022-03-18 18:09:08 --> Controller Class Initialized
INFO - 2022-03-18 18:09:08 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:09:08 --> Config Class Initialized
INFO - 2022-03-18 18:09:08 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:08 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:08 --> URI Class Initialized
INFO - 2022-03-18 18:09:08 --> Router Class Initialized
INFO - 2022-03-18 18:09:08 --> Output Class Initialized
INFO - 2022-03-18 18:09:08 --> Security Class Initialized
INFO - 2022-03-18 18:09:08 --> Input Class Initialized
INFO - 2022-03-18 18:09:08 --> Language Class Initialized
INFO - 2022-03-18 18:09:08 --> Loader Class Initialized
INFO - 2022-03-18 18:09:08 --> Helper loaded: url_helper
INFO - 2022-03-18 18:09:08 --> Helper loaded: form_helper
INFO - 2022-03-18 18:09:08 --> Database Driver Class Initialized
INFO - 2022-03-18 18:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:09:09 --> Form Validation Class Initialized
INFO - 2022-03-18 18:09:09 --> Controller Class Initialized
INFO - 2022-03-18 18:09:09 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:09:09 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:09:09 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:09:09 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:09:09 --> Final output sent to browser
INFO - 2022-03-18 18:09:13 --> Config Class Initialized
INFO - 2022-03-18 18:09:13 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:13 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:13 --> URI Class Initialized
INFO - 2022-03-18 18:09:13 --> Router Class Initialized
INFO - 2022-03-18 18:09:13 --> Output Class Initialized
INFO - 2022-03-18 18:09:13 --> Security Class Initialized
INFO - 2022-03-18 18:09:13 --> Input Class Initialized
INFO - 2022-03-18 18:09:13 --> Language Class Initialized
INFO - 2022-03-18 18:09:13 --> Loader Class Initialized
INFO - 2022-03-18 18:09:13 --> Helper loaded: url_helper
INFO - 2022-03-18 18:09:13 --> Helper loaded: form_helper
INFO - 2022-03-18 18:09:13 --> Database Driver Class Initialized
INFO - 2022-03-18 18:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:09:13 --> Form Validation Class Initialized
INFO - 2022-03-18 18:09:13 --> Controller Class Initialized
INFO - 2022-03-18 18:09:13 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:09:13 --> Config Class Initialized
INFO - 2022-03-18 18:09:13 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:13 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:13 --> URI Class Initialized
INFO - 2022-03-18 18:09:13 --> Router Class Initialized
INFO - 2022-03-18 18:09:13 --> Output Class Initialized
INFO - 2022-03-18 18:09:13 --> Security Class Initialized
INFO - 2022-03-18 18:09:13 --> Input Class Initialized
INFO - 2022-03-18 18:09:13 --> Language Class Initialized
INFO - 2022-03-18 18:09:13 --> Loader Class Initialized
INFO - 2022-03-18 18:09:13 --> Helper loaded: url_helper
INFO - 2022-03-18 18:09:13 --> Helper loaded: form_helper
INFO - 2022-03-18 18:09:13 --> Database Driver Class Initialized
INFO - 2022-03-18 18:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:09:13 --> Form Validation Class Initialized
INFO - 2022-03-18 18:09:13 --> Controller Class Initialized
INFO - 2022-03-18 18:09:13 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:09:13 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:09:13 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:09:13 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:09:13 --> Final output sent to browser
INFO - 2022-03-18 18:09:19 --> Config Class Initialized
INFO - 2022-03-18 18:09:19 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:19 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:19 --> URI Class Initialized
INFO - 2022-03-18 18:09:19 --> Router Class Initialized
INFO - 2022-03-18 18:09:19 --> Output Class Initialized
INFO - 2022-03-18 18:09:19 --> Security Class Initialized
INFO - 2022-03-18 18:09:19 --> Input Class Initialized
INFO - 2022-03-18 18:09:19 --> Language Class Initialized
INFO - 2022-03-18 18:09:19 --> Loader Class Initialized
INFO - 2022-03-18 18:09:19 --> Helper loaded: url_helper
INFO - 2022-03-18 18:09:19 --> Helper loaded: form_helper
INFO - 2022-03-18 18:09:19 --> Database Driver Class Initialized
INFO - 2022-03-18 18:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:09:19 --> Form Validation Class Initialized
INFO - 2022-03-18 18:09:19 --> Controller Class Initialized
INFO - 2022-03-18 18:09:19 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:09:20 --> Config Class Initialized
INFO - 2022-03-18 18:09:20 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:20 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:20 --> URI Class Initialized
INFO - 2022-03-18 18:09:20 --> Router Class Initialized
INFO - 2022-03-18 18:09:20 --> Output Class Initialized
INFO - 2022-03-18 18:09:20 --> Security Class Initialized
INFO - 2022-03-18 18:09:20 --> Input Class Initialized
INFO - 2022-03-18 18:09:20 --> Language Class Initialized
INFO - 2022-03-18 18:09:20 --> Loader Class Initialized
INFO - 2022-03-18 18:09:20 --> Helper loaded: url_helper
INFO - 2022-03-18 18:09:20 --> Helper loaded: form_helper
INFO - 2022-03-18 18:09:20 --> Database Driver Class Initialized
INFO - 2022-03-18 18:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:09:20 --> Form Validation Class Initialized
INFO - 2022-03-18 18:09:20 --> Controller Class Initialized
INFO - 2022-03-18 18:09:20 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:09:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:09:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:09:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:09:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:09:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:09:20 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:09:20 --> Final output sent to browser
INFO - 2022-03-18 18:09:20 --> Config Class Initialized
INFO - 2022-03-18 18:09:20 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:20 --> Config Class Initialized
INFO - 2022-03-18 18:09:20 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:20 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:20 --> URI Class Initialized
INFO - 2022-03-18 18:09:20 --> Router Class Initialized
INFO - 2022-03-18 18:09:20 --> Output Class Initialized
INFO - 2022-03-18 18:09:20 --> Security Class Initialized
INFO - 2022-03-18 18:09:20 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:20 --> Input Class Initialized
INFO - 2022-03-18 18:09:20 --> Language Class Initialized
INFO - 2022-03-18 18:09:20 --> URI Class Initialized
INFO - 2022-03-18 18:09:20 --> Router Class Initialized
ERROR - 2022-03-18 18:09:20 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:09:21 --> Output Class Initialized
INFO - 2022-03-18 18:09:21 --> Security Class Initialized
INFO - 2022-03-18 18:09:21 --> Input Class Initialized
INFO - 2022-03-18 18:09:21 --> Language Class Initialized
ERROR - 2022-03-18 18:09:21 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:09:55 --> Config Class Initialized
INFO - 2022-03-18 18:09:55 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:55 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:55 --> URI Class Initialized
INFO - 2022-03-18 18:09:55 --> Router Class Initialized
INFO - 2022-03-18 18:09:55 --> Output Class Initialized
INFO - 2022-03-18 18:09:55 --> Security Class Initialized
INFO - 2022-03-18 18:09:55 --> Input Class Initialized
INFO - 2022-03-18 18:09:55 --> Language Class Initialized
INFO - 2022-03-18 18:09:55 --> Loader Class Initialized
INFO - 2022-03-18 18:09:55 --> Helper loaded: url_helper
INFO - 2022-03-18 18:09:55 --> Helper loaded: form_helper
INFO - 2022-03-18 18:09:55 --> Database Driver Class Initialized
INFO - 2022-03-18 18:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:09:55 --> Form Validation Class Initialized
INFO - 2022-03-18 18:09:55 --> Controller Class Initialized
INFO - 2022-03-18 18:09:55 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:09:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:09:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:09:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:09:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:09:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:09:55 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:09:55 --> Final output sent to browser
INFO - 2022-03-18 18:09:56 --> Config Class Initialized
INFO - 2022-03-18 18:09:56 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:56 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:56 --> URI Class Initialized
INFO - 2022-03-18 18:09:56 --> Router Class Initialized
INFO - 2022-03-18 18:09:56 --> Output Class Initialized
INFO - 2022-03-18 18:09:56 --> Security Class Initialized
INFO - 2022-03-18 18:09:56 --> Config Class Initialized
INFO - 2022-03-18 18:09:56 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:56 --> Input Class Initialized
INFO - 2022-03-18 18:09:56 --> Language Class Initialized
INFO - 2022-03-18 18:09:56 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:56 --> URI Class Initialized
ERROR - 2022-03-18 18:09:56 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:09:56 --> Router Class Initialized
INFO - 2022-03-18 18:09:56 --> Output Class Initialized
INFO - 2022-03-18 18:09:56 --> Security Class Initialized
INFO - 2022-03-18 18:09:56 --> Input Class Initialized
INFO - 2022-03-18 18:09:56 --> Language Class Initialized
ERROR - 2022-03-18 18:09:56 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:09:59 --> Config Class Initialized
INFO - 2022-03-18 18:09:59 --> Hooks Class Initialized
INFO - 2022-03-18 18:09:59 --> Utf8 Class Initialized
INFO - 2022-03-18 18:09:59 --> URI Class Initialized
INFO - 2022-03-18 18:09:59 --> Router Class Initialized
INFO - 2022-03-18 18:09:59 --> Output Class Initialized
INFO - 2022-03-18 18:09:59 --> Security Class Initialized
INFO - 2022-03-18 18:09:59 --> Input Class Initialized
INFO - 2022-03-18 18:09:59 --> Language Class Initialized
INFO - 2022-03-18 18:09:59 --> Loader Class Initialized
INFO - 2022-03-18 18:09:59 --> Helper loaded: url_helper
INFO - 2022-03-18 18:09:59 --> Helper loaded: form_helper
INFO - 2022-03-18 18:09:59 --> Database Driver Class Initialized
INFO - 2022-03-18 18:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:09:59 --> Form Validation Class Initialized
INFO - 2022-03-18 18:09:59 --> Controller Class Initialized
INFO - 2022-03-18 18:09:59 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:09:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:09:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:09:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:09:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:09:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:09:59 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:09:59 --> Final output sent to browser
INFO - 2022-03-18 18:10:00 --> Config Class Initialized
INFO - 2022-03-18 18:10:00 --> Hooks Class Initialized
INFO - 2022-03-18 18:10:00 --> Utf8 Class Initialized
INFO - 2022-03-18 18:10:00 --> URI Class Initialized
INFO - 2022-03-18 18:10:00 --> Router Class Initialized
INFO - 2022-03-18 18:10:00 --> Output Class Initialized
INFO - 2022-03-18 18:10:00 --> Security Class Initialized
INFO - 2022-03-18 18:10:00 --> Input Class Initialized
INFO - 2022-03-18 18:10:00 --> Language Class Initialized
ERROR - 2022-03-18 18:10:00 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:10:00 --> Config Class Initialized
INFO - 2022-03-18 18:10:00 --> Hooks Class Initialized
INFO - 2022-03-18 18:10:00 --> Utf8 Class Initialized
INFO - 2022-03-18 18:10:00 --> URI Class Initialized
INFO - 2022-03-18 18:10:00 --> Router Class Initialized
INFO - 2022-03-18 18:10:00 --> Output Class Initialized
INFO - 2022-03-18 18:10:00 --> Security Class Initialized
INFO - 2022-03-18 18:10:00 --> Input Class Initialized
INFO - 2022-03-18 18:10:00 --> Language Class Initialized
ERROR - 2022-03-18 18:10:00 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:10:01 --> Config Class Initialized
INFO - 2022-03-18 18:10:01 --> Hooks Class Initialized
INFO - 2022-03-18 18:10:01 --> Utf8 Class Initialized
INFO - 2022-03-18 18:10:01 --> URI Class Initialized
INFO - 2022-03-18 18:10:01 --> Router Class Initialized
INFO - 2022-03-18 18:10:01 --> Output Class Initialized
INFO - 2022-03-18 18:10:01 --> Security Class Initialized
INFO - 2022-03-18 18:10:01 --> Input Class Initialized
INFO - 2022-03-18 18:10:01 --> Language Class Initialized
ERROR - 2022-03-18 18:10:01 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:10:52 --> Config Class Initialized
INFO - 2022-03-18 18:10:52 --> Hooks Class Initialized
INFO - 2022-03-18 18:10:52 --> Utf8 Class Initialized
INFO - 2022-03-18 18:10:52 --> URI Class Initialized
INFO - 2022-03-18 18:10:52 --> Router Class Initialized
INFO - 2022-03-18 18:10:52 --> Output Class Initialized
INFO - 2022-03-18 18:10:52 --> Security Class Initialized
INFO - 2022-03-18 18:10:52 --> Input Class Initialized
INFO - 2022-03-18 18:10:52 --> Language Class Initialized
INFO - 2022-03-18 18:10:52 --> Loader Class Initialized
INFO - 2022-03-18 18:10:52 --> Helper loaded: url_helper
INFO - 2022-03-18 18:10:52 --> Helper loaded: form_helper
INFO - 2022-03-18 18:10:52 --> Database Driver Class Initialized
INFO - 2022-03-18 18:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:10:52 --> Form Validation Class Initialized
INFO - 2022-03-18 18:10:52 --> Controller Class Initialized
INFO - 2022-03-18 18:10:52 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:10:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:10:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:10:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:10:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:10:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:10:52 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:10:52 --> Final output sent to browser
INFO - 2022-03-18 18:10:53 --> Config Class Initialized
INFO - 2022-03-18 18:10:53 --> Hooks Class Initialized
INFO - 2022-03-18 18:10:53 --> Config Class Initialized
INFO - 2022-03-18 18:10:53 --> Hooks Class Initialized
INFO - 2022-03-18 18:10:53 --> Utf8 Class Initialized
INFO - 2022-03-18 18:10:53 --> Utf8 Class Initialized
INFO - 2022-03-18 18:10:53 --> URI Class Initialized
INFO - 2022-03-18 18:10:53 --> URI Class Initialized
INFO - 2022-03-18 18:10:53 --> Router Class Initialized
INFO - 2022-03-18 18:10:53 --> Router Class Initialized
INFO - 2022-03-18 18:10:53 --> Output Class Initialized
INFO - 2022-03-18 18:10:53 --> Output Class Initialized
INFO - 2022-03-18 18:10:53 --> Security Class Initialized
INFO - 2022-03-18 18:10:53 --> Input Class Initialized
INFO - 2022-03-18 18:10:53 --> Language Class Initialized
ERROR - 2022-03-18 18:10:53 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:10:53 --> Security Class Initialized
INFO - 2022-03-18 18:10:53 --> Input Class Initialized
INFO - 2022-03-18 18:10:53 --> Language Class Initialized
ERROR - 2022-03-18 18:10:53 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:11:34 --> Config Class Initialized
INFO - 2022-03-18 18:11:34 --> Hooks Class Initialized
INFO - 2022-03-18 18:11:34 --> Utf8 Class Initialized
INFO - 2022-03-18 18:11:34 --> URI Class Initialized
INFO - 2022-03-18 18:11:34 --> Router Class Initialized
INFO - 2022-03-18 18:11:34 --> Output Class Initialized
INFO - 2022-03-18 18:11:34 --> Security Class Initialized
INFO - 2022-03-18 18:11:34 --> Input Class Initialized
INFO - 2022-03-18 18:11:34 --> Language Class Initialized
INFO - 2022-03-18 18:11:34 --> Loader Class Initialized
INFO - 2022-03-18 18:11:34 --> Helper loaded: url_helper
INFO - 2022-03-18 18:11:34 --> Helper loaded: form_helper
INFO - 2022-03-18 18:11:34 --> Database Driver Class Initialized
INFO - 2022-03-18 18:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:11:34 --> Form Validation Class Initialized
INFO - 2022-03-18 18:11:34 --> Controller Class Initialized
INFO - 2022-03-18 18:11:34 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:11:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:11:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:11:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:11:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:11:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:11:34 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:11:34 --> Final output sent to browser
INFO - 2022-03-18 18:11:34 --> Config Class Initialized
INFO - 2022-03-18 18:11:34 --> Hooks Class Initialized
INFO - 2022-03-18 18:11:34 --> Utf8 Class Initialized
INFO - 2022-03-18 18:11:35 --> URI Class Initialized
INFO - 2022-03-18 18:11:35 --> Router Class Initialized
INFO - 2022-03-18 18:11:35 --> Output Class Initialized
INFO - 2022-03-18 18:11:35 --> Security Class Initialized
INFO - 2022-03-18 18:11:35 --> Input Class Initialized
INFO - 2022-03-18 18:11:35 --> Config Class Initialized
INFO - 2022-03-18 18:11:35 --> Hooks Class Initialized
INFO - 2022-03-18 18:11:35 --> Language Class Initialized
INFO - 2022-03-18 18:11:35 --> Utf8 Class Initialized
ERROR - 2022-03-18 18:11:35 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:11:35 --> URI Class Initialized
INFO - 2022-03-18 18:11:35 --> Router Class Initialized
INFO - 2022-03-18 18:11:35 --> Output Class Initialized
INFO - 2022-03-18 18:11:35 --> Security Class Initialized
INFO - 2022-03-18 18:11:35 --> Input Class Initialized
INFO - 2022-03-18 18:11:35 --> Language Class Initialized
ERROR - 2022-03-18 18:11:35 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:11:48 --> Config Class Initialized
INFO - 2022-03-18 18:11:48 --> Hooks Class Initialized
INFO - 2022-03-18 18:11:48 --> Utf8 Class Initialized
INFO - 2022-03-18 18:11:48 --> URI Class Initialized
INFO - 2022-03-18 18:11:48 --> Router Class Initialized
INFO - 2022-03-18 18:11:48 --> Output Class Initialized
INFO - 2022-03-18 18:11:48 --> Security Class Initialized
INFO - 2022-03-18 18:11:48 --> Input Class Initialized
INFO - 2022-03-18 18:11:48 --> Language Class Initialized
INFO - 2022-03-18 18:11:48 --> Loader Class Initialized
INFO - 2022-03-18 18:11:48 --> Helper loaded: url_helper
INFO - 2022-03-18 18:11:48 --> Helper loaded: form_helper
INFO - 2022-03-18 18:11:48 --> Database Driver Class Initialized
INFO - 2022-03-18 18:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:11:48 --> Form Validation Class Initialized
INFO - 2022-03-18 18:11:48 --> Controller Class Initialized
INFO - 2022-03-18 18:11:48 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:11:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:11:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:11:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:11:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:11:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:11:48 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:11:48 --> Final output sent to browser
INFO - 2022-03-18 18:11:49 --> Config Class Initialized
INFO - 2022-03-18 18:11:49 --> Hooks Class Initialized
INFO - 2022-03-18 18:11:49 --> Utf8 Class Initialized
INFO - 2022-03-18 18:11:49 --> URI Class Initialized
INFO - 2022-03-18 18:11:49 --> Router Class Initialized
INFO - 2022-03-18 18:11:49 --> Config Class Initialized
INFO - 2022-03-18 18:11:49 --> Hooks Class Initialized
INFO - 2022-03-18 18:11:49 --> Output Class Initialized
INFO - 2022-03-18 18:11:49 --> Security Class Initialized
INFO - 2022-03-18 18:11:49 --> Utf8 Class Initialized
INFO - 2022-03-18 18:11:49 --> Input Class Initialized
INFO - 2022-03-18 18:11:49 --> URI Class Initialized
INFO - 2022-03-18 18:11:49 --> Language Class Initialized
ERROR - 2022-03-18 18:11:49 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:11:49 --> Router Class Initialized
INFO - 2022-03-18 18:11:49 --> Output Class Initialized
INFO - 2022-03-18 18:11:49 --> Security Class Initialized
INFO - 2022-03-18 18:11:49 --> Input Class Initialized
INFO - 2022-03-18 18:11:49 --> Language Class Initialized
ERROR - 2022-03-18 18:11:49 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:13:36 --> Config Class Initialized
INFO - 2022-03-18 18:13:36 --> Hooks Class Initialized
INFO - 2022-03-18 18:13:36 --> Utf8 Class Initialized
INFO - 2022-03-18 18:13:36 --> URI Class Initialized
INFO - 2022-03-18 18:13:36 --> Router Class Initialized
INFO - 2022-03-18 18:13:36 --> Output Class Initialized
INFO - 2022-03-18 18:13:36 --> Security Class Initialized
INFO - 2022-03-18 18:13:36 --> Input Class Initialized
INFO - 2022-03-18 18:13:36 --> Language Class Initialized
INFO - 2022-03-18 18:13:36 --> Loader Class Initialized
INFO - 2022-03-18 18:13:36 --> Helper loaded: url_helper
INFO - 2022-03-18 18:13:36 --> Helper loaded: form_helper
INFO - 2022-03-18 18:13:36 --> Database Driver Class Initialized
INFO - 2022-03-18 18:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:13:36 --> Form Validation Class Initialized
INFO - 2022-03-18 18:13:36 --> Controller Class Initialized
INFO - 2022-03-18 18:13:36 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:13:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:13:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:13:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:13:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:13:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:13:36 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:13:36 --> Final output sent to browser
INFO - 2022-03-18 18:13:37 --> Config Class Initialized
INFO - 2022-03-18 18:13:37 --> Hooks Class Initialized
INFO - 2022-03-18 18:13:37 --> Config Class Initialized
INFO - 2022-03-18 18:13:37 --> Hooks Class Initialized
INFO - 2022-03-18 18:13:37 --> Utf8 Class Initialized
INFO - 2022-03-18 18:13:37 --> Utf8 Class Initialized
INFO - 2022-03-18 18:13:37 --> URI Class Initialized
INFO - 2022-03-18 18:13:37 --> URI Class Initialized
INFO - 2022-03-18 18:13:37 --> Router Class Initialized
INFO - 2022-03-18 18:13:37 --> Router Class Initialized
INFO - 2022-03-18 18:13:37 --> Output Class Initialized
INFO - 2022-03-18 18:13:37 --> Output Class Initialized
INFO - 2022-03-18 18:13:37 --> Security Class Initialized
INFO - 2022-03-18 18:13:37 --> Security Class Initialized
INFO - 2022-03-18 18:13:37 --> Input Class Initialized
INFO - 2022-03-18 18:13:37 --> Language Class Initialized
INFO - 2022-03-18 18:13:37 --> Input Class Initialized
INFO - 2022-03-18 18:13:37 --> Language Class Initialized
ERROR - 2022-03-18 18:13:37 --> 404 Page Not Found: Img/av1.png
ERROR - 2022-03-18 18:13:37 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:13:40 --> Config Class Initialized
INFO - 2022-03-18 18:13:40 --> Hooks Class Initialized
INFO - 2022-03-18 18:13:40 --> Utf8 Class Initialized
INFO - 2022-03-18 18:13:40 --> URI Class Initialized
INFO - 2022-03-18 18:13:40 --> Router Class Initialized
INFO - 2022-03-18 18:13:40 --> Output Class Initialized
INFO - 2022-03-18 18:13:40 --> Security Class Initialized
INFO - 2022-03-18 18:13:40 --> Input Class Initialized
INFO - 2022-03-18 18:13:40 --> Language Class Initialized
INFO - 2022-03-18 18:13:40 --> Loader Class Initialized
INFO - 2022-03-18 18:13:40 --> Helper loaded: url_helper
INFO - 2022-03-18 18:13:40 --> Helper loaded: form_helper
INFO - 2022-03-18 18:13:40 --> Database Driver Class Initialized
INFO - 2022-03-18 18:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:13:41 --> Form Validation Class Initialized
INFO - 2022-03-18 18:13:41 --> Controller Class Initialized
INFO - 2022-03-18 18:13:41 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:13:41 --> Config Class Initialized
INFO - 2022-03-18 18:13:41 --> Hooks Class Initialized
INFO - 2022-03-18 18:13:41 --> Utf8 Class Initialized
INFO - 2022-03-18 18:13:41 --> URI Class Initialized
INFO - 2022-03-18 18:13:41 --> Router Class Initialized
INFO - 2022-03-18 18:13:41 --> Output Class Initialized
INFO - 2022-03-18 18:13:41 --> Security Class Initialized
INFO - 2022-03-18 18:13:41 --> Input Class Initialized
INFO - 2022-03-18 18:13:41 --> Language Class Initialized
ERROR - 2022-03-18 18:13:41 --> 404 Page Not Found: Login/index
INFO - 2022-03-18 18:13:50 --> Config Class Initialized
INFO - 2022-03-18 18:13:50 --> Hooks Class Initialized
INFO - 2022-03-18 18:13:50 --> Utf8 Class Initialized
INFO - 2022-03-18 18:13:51 --> URI Class Initialized
INFO - 2022-03-18 18:13:51 --> Router Class Initialized
INFO - 2022-03-18 18:13:51 --> Output Class Initialized
INFO - 2022-03-18 18:13:51 --> Security Class Initialized
INFO - 2022-03-18 18:13:51 --> Input Class Initialized
INFO - 2022-03-18 18:13:51 --> Language Class Initialized
INFO - 2022-03-18 18:13:51 --> Loader Class Initialized
INFO - 2022-03-18 18:13:51 --> Helper loaded: url_helper
INFO - 2022-03-18 18:13:51 --> Helper loaded: form_helper
INFO - 2022-03-18 18:13:51 --> Database Driver Class Initialized
INFO - 2022-03-18 18:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:13:51 --> Form Validation Class Initialized
INFO - 2022-03-18 18:13:51 --> Controller Class Initialized
INFO - 2022-03-18 18:13:51 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:13:51 --> Config Class Initialized
INFO - 2022-03-18 18:13:51 --> Hooks Class Initialized
INFO - 2022-03-18 18:13:51 --> Utf8 Class Initialized
INFO - 2022-03-18 18:13:51 --> URI Class Initialized
INFO - 2022-03-18 18:13:51 --> Router Class Initialized
INFO - 2022-03-18 18:13:51 --> Output Class Initialized
INFO - 2022-03-18 18:13:51 --> Security Class Initialized
INFO - 2022-03-18 18:13:51 --> Input Class Initialized
INFO - 2022-03-18 18:13:51 --> Language Class Initialized
INFO - 2022-03-18 18:13:51 --> Loader Class Initialized
INFO - 2022-03-18 18:13:51 --> Helper loaded: url_helper
INFO - 2022-03-18 18:13:51 --> Helper loaded: form_helper
INFO - 2022-03-18 18:13:51 --> Database Driver Class Initialized
INFO - 2022-03-18 18:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:13:51 --> Form Validation Class Initialized
INFO - 2022-03-18 18:13:51 --> Controller Class Initialized
INFO - 2022-03-18 18:13:51 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:13:51 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:13:51 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:13:51 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:13:51 --> Final output sent to browser
INFO - 2022-03-18 18:14:18 --> Config Class Initialized
INFO - 2022-03-18 18:14:18 --> Hooks Class Initialized
INFO - 2022-03-18 18:14:18 --> Utf8 Class Initialized
INFO - 2022-03-18 18:14:18 --> URI Class Initialized
INFO - 2022-03-18 18:14:18 --> Router Class Initialized
INFO - 2022-03-18 18:14:18 --> Output Class Initialized
INFO - 2022-03-18 18:14:18 --> Security Class Initialized
INFO - 2022-03-18 18:14:18 --> Input Class Initialized
INFO - 2022-03-18 18:14:18 --> Language Class Initialized
INFO - 2022-03-18 18:14:18 --> Loader Class Initialized
INFO - 2022-03-18 18:14:18 --> Helper loaded: url_helper
INFO - 2022-03-18 18:14:18 --> Helper loaded: form_helper
INFO - 2022-03-18 18:14:19 --> Database Driver Class Initialized
INFO - 2022-03-18 18:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:14:19 --> Form Validation Class Initialized
INFO - 2022-03-18 18:14:19 --> Controller Class Initialized
INFO - 2022-03-18 18:14:19 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:14:19 --> Config Class Initialized
INFO - 2022-03-18 18:14:19 --> Hooks Class Initialized
INFO - 2022-03-18 18:14:19 --> Utf8 Class Initialized
INFO - 2022-03-18 18:14:19 --> URI Class Initialized
INFO - 2022-03-18 18:14:19 --> Router Class Initialized
INFO - 2022-03-18 18:14:19 --> Output Class Initialized
INFO - 2022-03-18 18:14:19 --> Security Class Initialized
INFO - 2022-03-18 18:14:19 --> Input Class Initialized
INFO - 2022-03-18 18:14:19 --> Language Class Initialized
INFO - 2022-03-18 18:14:19 --> Loader Class Initialized
INFO - 2022-03-18 18:14:19 --> Helper loaded: url_helper
INFO - 2022-03-18 18:14:19 --> Helper loaded: form_helper
INFO - 2022-03-18 18:14:19 --> Database Driver Class Initialized
INFO - 2022-03-18 18:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:14:19 --> Form Validation Class Initialized
INFO - 2022-03-18 18:14:19 --> Controller Class Initialized
INFO - 2022-03-18 18:14:19 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:14:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:14:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:14:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:14:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:14:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:14:19 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:14:19 --> Final output sent to browser
INFO - 2022-03-18 18:14:20 --> Config Class Initialized
INFO - 2022-03-18 18:14:20 --> Hooks Class Initialized
INFO - 2022-03-18 18:14:20 --> Utf8 Class Initialized
INFO - 2022-03-18 18:14:20 --> URI Class Initialized
INFO - 2022-03-18 18:14:20 --> Router Class Initialized
INFO - 2022-03-18 18:14:20 --> Config Class Initialized
INFO - 2022-03-18 18:14:20 --> Hooks Class Initialized
INFO - 2022-03-18 18:14:20 --> Utf8 Class Initialized
INFO - 2022-03-18 18:14:20 --> URI Class Initialized
INFO - 2022-03-18 18:14:20 --> Router Class Initialized
INFO - 2022-03-18 18:14:20 --> Output Class Initialized
INFO - 2022-03-18 18:14:20 --> Output Class Initialized
INFO - 2022-03-18 18:14:20 --> Security Class Initialized
INFO - 2022-03-18 18:14:20 --> Input Class Initialized
INFO - 2022-03-18 18:14:20 --> Security Class Initialized
INFO - 2022-03-18 18:14:20 --> Language Class Initialized
INFO - 2022-03-18 18:14:20 --> Input Class Initialized
ERROR - 2022-03-18 18:14:20 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:14:20 --> Language Class Initialized
ERROR - 2022-03-18 18:14:20 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:14:23 --> Config Class Initialized
INFO - 2022-03-18 18:14:23 --> Hooks Class Initialized
INFO - 2022-03-18 18:14:23 --> Utf8 Class Initialized
INFO - 2022-03-18 18:14:23 --> URI Class Initialized
INFO - 2022-03-18 18:14:23 --> Router Class Initialized
INFO - 2022-03-18 18:14:23 --> Output Class Initialized
INFO - 2022-03-18 18:14:23 --> Security Class Initialized
INFO - 2022-03-18 18:14:23 --> Input Class Initialized
INFO - 2022-03-18 18:14:23 --> Language Class Initialized
INFO - 2022-03-18 18:14:23 --> Loader Class Initialized
INFO - 2022-03-18 18:14:23 --> Helper loaded: url_helper
INFO - 2022-03-18 18:14:23 --> Helper loaded: form_helper
INFO - 2022-03-18 18:14:23 --> Database Driver Class Initialized
INFO - 2022-03-18 18:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:14:23 --> Form Validation Class Initialized
INFO - 2022-03-18 18:14:23 --> Controller Class Initialized
INFO - 2022-03-18 18:14:23 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:14:23 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:14:23 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:14:23 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:14:23 --> Final output sent to browser
INFO - 2022-03-18 18:14:27 --> Config Class Initialized
INFO - 2022-03-18 18:14:27 --> Hooks Class Initialized
INFO - 2022-03-18 18:14:27 --> Utf8 Class Initialized
INFO - 2022-03-18 18:14:27 --> URI Class Initialized
INFO - 2022-03-18 18:14:27 --> Router Class Initialized
INFO - 2022-03-18 18:14:27 --> Output Class Initialized
INFO - 2022-03-18 18:14:27 --> Security Class Initialized
INFO - 2022-03-18 18:14:27 --> Input Class Initialized
INFO - 2022-03-18 18:14:27 --> Language Class Initialized
INFO - 2022-03-18 18:14:27 --> Loader Class Initialized
INFO - 2022-03-18 18:14:27 --> Helper loaded: url_helper
INFO - 2022-03-18 18:14:27 --> Helper loaded: form_helper
INFO - 2022-03-18 18:14:27 --> Database Driver Class Initialized
INFO - 2022-03-18 18:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:14:27 --> Form Validation Class Initialized
INFO - 2022-03-18 18:14:27 --> Controller Class Initialized
INFO - 2022-03-18 18:14:27 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:14:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:14:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:14:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:14:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:14:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:14:27 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:14:27 --> Final output sent to browser
INFO - 2022-03-18 18:14:28 --> Config Class Initialized
INFO - 2022-03-18 18:14:28 --> Config Class Initialized
INFO - 2022-03-18 18:14:28 --> Hooks Class Initialized
INFO - 2022-03-18 18:14:28 --> Hooks Class Initialized
INFO - 2022-03-18 18:14:28 --> Utf8 Class Initialized
INFO - 2022-03-18 18:14:28 --> Utf8 Class Initialized
INFO - 2022-03-18 18:14:28 --> URI Class Initialized
INFO - 2022-03-18 18:14:28 --> URI Class Initialized
INFO - 2022-03-18 18:14:28 --> Router Class Initialized
INFO - 2022-03-18 18:14:28 --> Output Class Initialized
INFO - 2022-03-18 18:14:28 --> Security Class Initialized
INFO - 2022-03-18 18:14:28 --> Input Class Initialized
INFO - 2022-03-18 18:14:28 --> Router Class Initialized
INFO - 2022-03-18 18:14:28 --> Output Class Initialized
INFO - 2022-03-18 18:14:28 --> Language Class Initialized
INFO - 2022-03-18 18:14:28 --> Security Class Initialized
ERROR - 2022-03-18 18:14:28 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:14:28 --> Input Class Initialized
INFO - 2022-03-18 18:14:28 --> Language Class Initialized
ERROR - 2022-03-18 18:14:28 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:15:59 --> Config Class Initialized
INFO - 2022-03-18 18:15:59 --> Hooks Class Initialized
INFO - 2022-03-18 18:15:59 --> Utf8 Class Initialized
INFO - 2022-03-18 18:15:59 --> URI Class Initialized
INFO - 2022-03-18 18:15:59 --> Router Class Initialized
INFO - 2022-03-18 18:15:59 --> Output Class Initialized
INFO - 2022-03-18 18:15:59 --> Security Class Initialized
INFO - 2022-03-18 18:15:59 --> Input Class Initialized
INFO - 2022-03-18 18:15:59 --> Language Class Initialized
INFO - 2022-03-18 18:15:59 --> Loader Class Initialized
INFO - 2022-03-18 18:15:59 --> Helper loaded: url_helper
INFO - 2022-03-18 18:15:59 --> Helper loaded: form_helper
INFO - 2022-03-18 18:15:59 --> Database Driver Class Initialized
INFO - 2022-03-18 18:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:15:59 --> Form Validation Class Initialized
INFO - 2022-03-18 18:15:59 --> Controller Class Initialized
INFO - 2022-03-18 18:15:59 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:15:59 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:15:59 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:15:59 --> Final output sent to browser
INFO - 2022-03-18 18:16:14 --> Config Class Initialized
INFO - 2022-03-18 18:16:14 --> Hooks Class Initialized
INFO - 2022-03-18 18:16:14 --> Utf8 Class Initialized
INFO - 2022-03-18 18:16:14 --> URI Class Initialized
INFO - 2022-03-18 18:16:14 --> Router Class Initialized
INFO - 2022-03-18 18:16:14 --> Output Class Initialized
INFO - 2022-03-18 18:16:14 --> Security Class Initialized
INFO - 2022-03-18 18:16:14 --> Input Class Initialized
INFO - 2022-03-18 18:16:14 --> Language Class Initialized
INFO - 2022-03-18 18:16:14 --> Loader Class Initialized
INFO - 2022-03-18 18:16:14 --> Helper loaded: url_helper
INFO - 2022-03-18 18:16:14 --> Helper loaded: form_helper
INFO - 2022-03-18 18:16:14 --> Database Driver Class Initialized
INFO - 2022-03-18 18:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:16:14 --> Form Validation Class Initialized
INFO - 2022-03-18 18:16:14 --> Controller Class Initialized
INFO - 2022-03-18 18:16:14 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:16:14 --> Config Class Initialized
INFO - 2022-03-18 18:16:14 --> Hooks Class Initialized
INFO - 2022-03-18 18:16:14 --> Utf8 Class Initialized
INFO - 2022-03-18 18:16:14 --> URI Class Initialized
INFO - 2022-03-18 18:16:14 --> Router Class Initialized
INFO - 2022-03-18 18:16:14 --> Output Class Initialized
INFO - 2022-03-18 18:16:14 --> Security Class Initialized
INFO - 2022-03-18 18:16:14 --> Input Class Initialized
INFO - 2022-03-18 18:16:14 --> Language Class Initialized
INFO - 2022-03-18 18:16:14 --> Loader Class Initialized
INFO - 2022-03-18 18:16:14 --> Helper loaded: url_helper
INFO - 2022-03-18 18:16:14 --> Helper loaded: form_helper
INFO - 2022-03-18 18:16:15 --> Database Driver Class Initialized
INFO - 2022-03-18 18:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:16:15 --> Form Validation Class Initialized
INFO - 2022-03-18 18:16:15 --> Controller Class Initialized
INFO - 2022-03-18 18:16:15 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:16:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:16:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:16:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:16:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:16:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:16:15 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:16:15 --> Final output sent to browser
INFO - 2022-03-18 18:16:15 --> Config Class Initialized
INFO - 2022-03-18 18:16:15 --> Hooks Class Initialized
INFO - 2022-03-18 18:16:15 --> Utf8 Class Initialized
INFO - 2022-03-18 18:16:15 --> URI Class Initialized
INFO - 2022-03-18 18:16:15 --> Router Class Initialized
INFO - 2022-03-18 18:16:15 --> Output Class Initialized
INFO - 2022-03-18 18:16:15 --> Config Class Initialized
INFO - 2022-03-18 18:16:15 --> Hooks Class Initialized
INFO - 2022-03-18 18:16:15 --> Security Class Initialized
INFO - 2022-03-18 18:16:15 --> Input Class Initialized
INFO - 2022-03-18 18:16:15 --> Language Class Initialized
ERROR - 2022-03-18 18:16:15 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:16:15 --> Utf8 Class Initialized
INFO - 2022-03-18 18:16:15 --> URI Class Initialized
INFO - 2022-03-18 18:16:15 --> Router Class Initialized
INFO - 2022-03-18 18:16:15 --> Output Class Initialized
INFO - 2022-03-18 18:16:15 --> Security Class Initialized
INFO - 2022-03-18 18:16:15 --> Input Class Initialized
INFO - 2022-03-18 18:16:15 --> Language Class Initialized
ERROR - 2022-03-18 18:16:15 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:17:04 --> Config Class Initialized
INFO - 2022-03-18 18:17:04 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:04 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:04 --> URI Class Initialized
INFO - 2022-03-18 18:17:04 --> Router Class Initialized
INFO - 2022-03-18 18:17:04 --> Output Class Initialized
INFO - 2022-03-18 18:17:04 --> Security Class Initialized
INFO - 2022-03-18 18:17:04 --> Input Class Initialized
INFO - 2022-03-18 18:17:04 --> Language Class Initialized
INFO - 2022-03-18 18:17:04 --> Loader Class Initialized
INFO - 2022-03-18 18:17:04 --> Helper loaded: url_helper
INFO - 2022-03-18 18:17:04 --> Helper loaded: form_helper
INFO - 2022-03-18 18:17:04 --> Database Driver Class Initialized
INFO - 2022-03-18 18:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:17:04 --> Form Validation Class Initialized
INFO - 2022-03-18 18:17:04 --> Controller Class Initialized
INFO - 2022-03-18 18:17:04 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:17:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:17:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:17:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:17:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:17:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:17:04 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:17:04 --> Final output sent to browser
INFO - 2022-03-18 18:17:04 --> Config Class Initialized
INFO - 2022-03-18 18:17:04 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:04 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:04 --> URI Class Initialized
INFO - 2022-03-18 18:17:04 --> Router Class Initialized
INFO - 2022-03-18 18:17:04 --> Config Class Initialized
INFO - 2022-03-18 18:17:04 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:04 --> Output Class Initialized
INFO - 2022-03-18 18:17:05 --> Security Class Initialized
INFO - 2022-03-18 18:17:05 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:05 --> Input Class Initialized
INFO - 2022-03-18 18:17:05 --> URI Class Initialized
INFO - 2022-03-18 18:17:05 --> Router Class Initialized
INFO - 2022-03-18 18:17:05 --> Language Class Initialized
ERROR - 2022-03-18 18:17:05 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:17:05 --> Output Class Initialized
INFO - 2022-03-18 18:17:05 --> Security Class Initialized
INFO - 2022-03-18 18:17:05 --> Input Class Initialized
INFO - 2022-03-18 18:17:05 --> Language Class Initialized
ERROR - 2022-03-18 18:17:05 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:17:13 --> Config Class Initialized
INFO - 2022-03-18 18:17:13 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:13 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:13 --> URI Class Initialized
INFO - 2022-03-18 18:17:13 --> Router Class Initialized
INFO - 2022-03-18 18:17:13 --> Output Class Initialized
INFO - 2022-03-18 18:17:13 --> Security Class Initialized
INFO - 2022-03-18 18:17:13 --> Input Class Initialized
INFO - 2022-03-18 18:17:13 --> Language Class Initialized
INFO - 2022-03-18 18:17:13 --> Loader Class Initialized
INFO - 2022-03-18 18:17:13 --> Helper loaded: url_helper
INFO - 2022-03-18 18:17:13 --> Helper loaded: form_helper
INFO - 2022-03-18 18:17:13 --> Database Driver Class Initialized
INFO - 2022-03-18 18:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:17:13 --> Form Validation Class Initialized
INFO - 2022-03-18 18:17:13 --> Controller Class Initialized
INFO - 2022-03-18 18:17:13 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:17:13 --> Config Class Initialized
INFO - 2022-03-18 18:17:13 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:13 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:13 --> URI Class Initialized
INFO - 2022-03-18 18:17:13 --> Router Class Initialized
INFO - 2022-03-18 18:17:13 --> Output Class Initialized
INFO - 2022-03-18 18:17:13 --> Security Class Initialized
INFO - 2022-03-18 18:17:13 --> Input Class Initialized
INFO - 2022-03-18 18:17:13 --> Language Class Initialized
INFO - 2022-03-18 18:17:13 --> Loader Class Initialized
INFO - 2022-03-18 18:17:13 --> Helper loaded: url_helper
INFO - 2022-03-18 18:17:13 --> Helper loaded: form_helper
INFO - 2022-03-18 18:17:13 --> Database Driver Class Initialized
INFO - 2022-03-18 18:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:17:13 --> Form Validation Class Initialized
INFO - 2022-03-18 18:17:13 --> Controller Class Initialized
INFO - 2022-03-18 18:17:13 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:17:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:17:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:17:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:17:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:17:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:17:13 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:17:13 --> Final output sent to browser
INFO - 2022-03-18 18:17:14 --> Config Class Initialized
INFO - 2022-03-18 18:17:14 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:14 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:14 --> Config Class Initialized
INFO - 2022-03-18 18:17:14 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:14 --> URI Class Initialized
INFO - 2022-03-18 18:17:14 --> Router Class Initialized
INFO - 2022-03-18 18:17:14 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:14 --> Output Class Initialized
INFO - 2022-03-18 18:17:14 --> URI Class Initialized
INFO - 2022-03-18 18:17:14 --> Security Class Initialized
INFO - 2022-03-18 18:17:14 --> Input Class Initialized
INFO - 2022-03-18 18:17:14 --> Language Class Initialized
ERROR - 2022-03-18 18:17:14 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:17:14 --> Router Class Initialized
INFO - 2022-03-18 18:17:14 --> Output Class Initialized
INFO - 2022-03-18 18:17:14 --> Security Class Initialized
INFO - 2022-03-18 18:17:14 --> Input Class Initialized
INFO - 2022-03-18 18:17:14 --> Language Class Initialized
ERROR - 2022-03-18 18:17:14 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:17:22 --> Config Class Initialized
INFO - 2022-03-18 18:17:22 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:22 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:22 --> URI Class Initialized
INFO - 2022-03-18 18:17:22 --> Router Class Initialized
INFO - 2022-03-18 18:17:22 --> Output Class Initialized
INFO - 2022-03-18 18:17:22 --> Security Class Initialized
INFO - 2022-03-18 18:17:22 --> Input Class Initialized
INFO - 2022-03-18 18:17:22 --> Language Class Initialized
INFO - 2022-03-18 18:17:22 --> Loader Class Initialized
INFO - 2022-03-18 18:17:22 --> Helper loaded: url_helper
INFO - 2022-03-18 18:17:22 --> Helper loaded: form_helper
INFO - 2022-03-18 18:17:22 --> Database Driver Class Initialized
INFO - 2022-03-18 18:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:17:22 --> Form Validation Class Initialized
INFO - 2022-03-18 18:17:22 --> Controller Class Initialized
INFO - 2022-03-18 18:17:22 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:17:22 --> Config Class Initialized
INFO - 2022-03-18 18:17:22 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:22 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:22 --> URI Class Initialized
INFO - 2022-03-18 18:17:22 --> Router Class Initialized
INFO - 2022-03-18 18:17:22 --> Output Class Initialized
INFO - 2022-03-18 18:17:22 --> Security Class Initialized
INFO - 2022-03-18 18:17:22 --> Input Class Initialized
INFO - 2022-03-18 18:17:22 --> Language Class Initialized
INFO - 2022-03-18 18:17:22 --> Loader Class Initialized
INFO - 2022-03-18 18:17:22 --> Helper loaded: url_helper
INFO - 2022-03-18 18:17:22 --> Helper loaded: form_helper
INFO - 2022-03-18 18:17:22 --> Database Driver Class Initialized
INFO - 2022-03-18 18:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:17:22 --> Form Validation Class Initialized
INFO - 2022-03-18 18:17:22 --> Controller Class Initialized
INFO - 2022-03-18 18:17:22 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:17:22 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:17:22 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:17:22 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:17:22 --> Final output sent to browser
INFO - 2022-03-18 18:17:28 --> Config Class Initialized
INFO - 2022-03-18 18:17:28 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:28 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:28 --> URI Class Initialized
INFO - 2022-03-18 18:17:28 --> Router Class Initialized
INFO - 2022-03-18 18:17:28 --> Output Class Initialized
INFO - 2022-03-18 18:17:28 --> Security Class Initialized
INFO - 2022-03-18 18:17:28 --> Input Class Initialized
INFO - 2022-03-18 18:17:28 --> Language Class Initialized
INFO - 2022-03-18 18:17:28 --> Loader Class Initialized
INFO - 2022-03-18 18:17:28 --> Helper loaded: url_helper
INFO - 2022-03-18 18:17:28 --> Helper loaded: form_helper
INFO - 2022-03-18 18:17:28 --> Database Driver Class Initialized
INFO - 2022-03-18 18:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:17:28 --> Form Validation Class Initialized
INFO - 2022-03-18 18:17:28 --> Controller Class Initialized
INFO - 2022-03-18 18:17:28 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:17:28 --> Config Class Initialized
INFO - 2022-03-18 18:17:28 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:28 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:28 --> URI Class Initialized
INFO - 2022-03-18 18:17:28 --> Router Class Initialized
INFO - 2022-03-18 18:17:28 --> Output Class Initialized
INFO - 2022-03-18 18:17:28 --> Security Class Initialized
INFO - 2022-03-18 18:17:28 --> Input Class Initialized
INFO - 2022-03-18 18:17:28 --> Language Class Initialized
INFO - 2022-03-18 18:17:28 --> Loader Class Initialized
INFO - 2022-03-18 18:17:28 --> Helper loaded: url_helper
INFO - 2022-03-18 18:17:28 --> Helper loaded: form_helper
INFO - 2022-03-18 18:17:28 --> Database Driver Class Initialized
INFO - 2022-03-18 18:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:17:28 --> Form Validation Class Initialized
INFO - 2022-03-18 18:17:28 --> Controller Class Initialized
INFO - 2022-03-18 18:17:28 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:17:28 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 18:17:28 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 18:17:28 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 18:17:28 --> Final output sent to browser
INFO - 2022-03-18 18:17:35 --> Config Class Initialized
INFO - 2022-03-18 18:17:35 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:35 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:35 --> URI Class Initialized
INFO - 2022-03-18 18:17:35 --> Router Class Initialized
INFO - 2022-03-18 18:17:35 --> Output Class Initialized
INFO - 2022-03-18 18:17:35 --> Security Class Initialized
INFO - 2022-03-18 18:17:35 --> Input Class Initialized
INFO - 2022-03-18 18:17:35 --> Language Class Initialized
INFO - 2022-03-18 18:17:35 --> Loader Class Initialized
INFO - 2022-03-18 18:17:35 --> Helper loaded: url_helper
INFO - 2022-03-18 18:17:35 --> Helper loaded: form_helper
INFO - 2022-03-18 18:17:35 --> Database Driver Class Initialized
INFO - 2022-03-18 18:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:17:36 --> Form Validation Class Initialized
INFO - 2022-03-18 18:17:36 --> Controller Class Initialized
INFO - 2022-03-18 18:17:36 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:17:36 --> Config Class Initialized
INFO - 2022-03-18 18:17:36 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:36 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:36 --> URI Class Initialized
INFO - 2022-03-18 18:17:36 --> Router Class Initialized
INFO - 2022-03-18 18:17:36 --> Output Class Initialized
INFO - 2022-03-18 18:17:36 --> Security Class Initialized
INFO - 2022-03-18 18:17:36 --> Input Class Initialized
INFO - 2022-03-18 18:17:36 --> Language Class Initialized
INFO - 2022-03-18 18:17:36 --> Loader Class Initialized
INFO - 2022-03-18 18:17:36 --> Helper loaded: url_helper
INFO - 2022-03-18 18:17:36 --> Helper loaded: form_helper
INFO - 2022-03-18 18:17:36 --> Database Driver Class Initialized
INFO - 2022-03-18 18:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:17:36 --> Form Validation Class Initialized
INFO - 2022-03-18 18:17:36 --> Controller Class Initialized
INFO - 2022-03-18 18:17:36 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:17:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:17:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:17:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:17:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:17:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:17:36 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:17:36 --> Final output sent to browser
INFO - 2022-03-18 18:17:37 --> Config Class Initialized
INFO - 2022-03-18 18:17:37 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:37 --> Utf8 Class Initialized
INFO - 2022-03-18 18:17:37 --> URI Class Initialized
INFO - 2022-03-18 18:17:37 --> Router Class Initialized
INFO - 2022-03-18 18:17:37 --> Output Class Initialized
INFO - 2022-03-18 18:17:37 --> Config Class Initialized
INFO - 2022-03-18 18:17:37 --> Hooks Class Initialized
INFO - 2022-03-18 18:17:37 --> Security Class Initialized
INFO - 2022-03-18 18:17:37 --> Input Class Initialized
INFO - 2022-03-18 18:17:37 --> Language Class Initialized
INFO - 2022-03-18 18:17:37 --> Utf8 Class Initialized
ERROR - 2022-03-18 18:17:37 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:17:37 --> URI Class Initialized
INFO - 2022-03-18 18:17:37 --> Router Class Initialized
INFO - 2022-03-18 18:17:37 --> Output Class Initialized
INFO - 2022-03-18 18:17:37 --> Security Class Initialized
INFO - 2022-03-18 18:17:37 --> Input Class Initialized
INFO - 2022-03-18 18:17:37 --> Language Class Initialized
ERROR - 2022-03-18 18:17:37 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:18:12 --> Config Class Initialized
INFO - 2022-03-18 18:18:12 --> Hooks Class Initialized
INFO - 2022-03-18 18:18:12 --> Utf8 Class Initialized
INFO - 2022-03-18 18:18:12 --> URI Class Initialized
INFO - 2022-03-18 18:18:12 --> Router Class Initialized
INFO - 2022-03-18 18:18:12 --> Output Class Initialized
INFO - 2022-03-18 18:18:12 --> Security Class Initialized
INFO - 2022-03-18 18:18:12 --> Input Class Initialized
INFO - 2022-03-18 18:18:12 --> Language Class Initialized
INFO - 2022-03-18 18:18:12 --> Loader Class Initialized
INFO - 2022-03-18 18:18:12 --> Helper loaded: url_helper
INFO - 2022-03-18 18:18:12 --> Helper loaded: form_helper
INFO - 2022-03-18 18:18:12 --> Database Driver Class Initialized
INFO - 2022-03-18 18:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:18:12 --> Form Validation Class Initialized
INFO - 2022-03-18 18:18:12 --> Controller Class Initialized
INFO - 2022-03-18 18:18:12 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:18:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:18:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:18:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:18:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:18:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:18:12 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 18:18:12 --> Final output sent to browser
INFO - 2022-03-18 18:18:14 --> Config Class Initialized
INFO - 2022-03-18 18:18:14 --> Hooks Class Initialized
INFO - 2022-03-18 18:18:14 --> Utf8 Class Initialized
INFO - 2022-03-18 18:18:14 --> URI Class Initialized
INFO - 2022-03-18 18:18:14 --> Router Class Initialized
INFO - 2022-03-18 18:18:14 --> Output Class Initialized
INFO - 2022-03-18 18:18:14 --> Security Class Initialized
INFO - 2022-03-18 18:18:14 --> Input Class Initialized
INFO - 2022-03-18 18:18:14 --> Language Class Initialized
ERROR - 2022-03-18 18:18:14 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 18:18:14 --> Config Class Initialized
INFO - 2022-03-18 18:18:14 --> Hooks Class Initialized
INFO - 2022-03-18 18:18:14 --> Utf8 Class Initialized
INFO - 2022-03-18 18:18:14 --> URI Class Initialized
INFO - 2022-03-18 18:18:14 --> Router Class Initialized
INFO - 2022-03-18 18:18:14 --> Output Class Initialized
INFO - 2022-03-18 18:18:14 --> Security Class Initialized
INFO - 2022-03-18 18:18:14 --> Input Class Initialized
INFO - 2022-03-18 18:18:14 --> Language Class Initialized
ERROR - 2022-03-18 18:18:14 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 18:18:27 --> Config Class Initialized
INFO - 2022-03-18 18:18:27 --> Hooks Class Initialized
INFO - 2022-03-18 18:18:27 --> Utf8 Class Initialized
INFO - 2022-03-18 18:18:27 --> URI Class Initialized
INFO - 2022-03-18 18:18:27 --> Router Class Initialized
INFO - 2022-03-18 18:18:27 --> Output Class Initialized
INFO - 2022-03-18 18:18:27 --> Security Class Initialized
INFO - 2022-03-18 18:18:27 --> Input Class Initialized
INFO - 2022-03-18 18:18:27 --> Language Class Initialized
INFO - 2022-03-18 18:18:27 --> Loader Class Initialized
INFO - 2022-03-18 18:18:27 --> Helper loaded: url_helper
INFO - 2022-03-18 18:18:27 --> Helper loaded: form_helper
INFO - 2022-03-18 18:18:27 --> Database Driver Class Initialized
INFO - 2022-03-18 18:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:18:27 --> Form Validation Class Initialized
INFO - 2022-03-18 18:18:27 --> Controller Class Initialized
INFO - 2022-03-18 18:18:27 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:18:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:18:27 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:18:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:18:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:18:27 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 18:18:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:18:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:18:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:18:27 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:18:27 --> Final output sent to browser
INFO - 2022-03-18 18:18:34 --> Config Class Initialized
INFO - 2022-03-18 18:18:34 --> Hooks Class Initialized
INFO - 2022-03-18 18:18:34 --> Utf8 Class Initialized
INFO - 2022-03-18 18:18:34 --> URI Class Initialized
INFO - 2022-03-18 18:18:34 --> Router Class Initialized
INFO - 2022-03-18 18:18:34 --> Output Class Initialized
INFO - 2022-03-18 18:18:34 --> Security Class Initialized
INFO - 2022-03-18 18:18:34 --> Input Class Initialized
INFO - 2022-03-18 18:18:34 --> Language Class Initialized
INFO - 2022-03-18 18:18:34 --> Loader Class Initialized
INFO - 2022-03-18 18:18:34 --> Helper loaded: url_helper
INFO - 2022-03-18 18:18:34 --> Helper loaded: form_helper
INFO - 2022-03-18 18:18:34 --> Database Driver Class Initialized
INFO - 2022-03-18 18:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:18:34 --> Form Validation Class Initialized
INFO - 2022-03-18 18:18:34 --> Controller Class Initialized
INFO - 2022-03-18 18:18:34 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:18:34 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:18:34 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:18:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:18:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:18:34 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 18:18:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:18:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:18:34 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:18:34 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:18:34 --> Final output sent to browser
INFO - 2022-03-18 18:18:41 --> Config Class Initialized
INFO - 2022-03-18 18:18:41 --> Hooks Class Initialized
INFO - 2022-03-18 18:18:41 --> Utf8 Class Initialized
INFO - 2022-03-18 18:18:41 --> URI Class Initialized
INFO - 2022-03-18 18:18:41 --> Router Class Initialized
INFO - 2022-03-18 18:18:41 --> Output Class Initialized
INFO - 2022-03-18 18:18:41 --> Security Class Initialized
INFO - 2022-03-18 18:18:41 --> Input Class Initialized
INFO - 2022-03-18 18:18:41 --> Language Class Initialized
INFO - 2022-03-18 18:18:41 --> Loader Class Initialized
INFO - 2022-03-18 18:18:41 --> Helper loaded: url_helper
INFO - 2022-03-18 18:18:41 --> Helper loaded: form_helper
INFO - 2022-03-18 18:18:41 --> Database Driver Class Initialized
INFO - 2022-03-18 18:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:18:41 --> Form Validation Class Initialized
INFO - 2022-03-18 18:18:41 --> Controller Class Initialized
INFO - 2022-03-18 18:18:41 --> Model "M_tutor" initialized
INFO - 2022-03-18 18:18:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:18:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:18:41 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 18:18:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:18:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:18:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:18:41 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:18:41 --> Final output sent to browser
INFO - 2022-03-18 18:18:58 --> Config Class Initialized
INFO - 2022-03-18 18:18:58 --> Hooks Class Initialized
INFO - 2022-03-18 18:18:58 --> Utf8 Class Initialized
INFO - 2022-03-18 18:18:58 --> URI Class Initialized
INFO - 2022-03-18 18:18:58 --> Router Class Initialized
INFO - 2022-03-18 18:18:58 --> Output Class Initialized
INFO - 2022-03-18 18:18:58 --> Security Class Initialized
INFO - 2022-03-18 18:18:59 --> Input Class Initialized
INFO - 2022-03-18 18:18:59 --> Language Class Initialized
INFO - 2022-03-18 18:18:59 --> Loader Class Initialized
INFO - 2022-03-18 18:18:59 --> Helper loaded: url_helper
INFO - 2022-03-18 18:18:59 --> Helper loaded: form_helper
INFO - 2022-03-18 18:18:59 --> Database Driver Class Initialized
INFO - 2022-03-18 18:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:18:59 --> Form Validation Class Initialized
INFO - 2022-03-18 18:18:59 --> Controller Class Initialized
INFO - 2022-03-18 18:18:59 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:18:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:18:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:18:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:18:59 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:18:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:18:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:18:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:18:59 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:18:59 --> Final output sent to browser
INFO - 2022-03-18 18:23:19 --> Config Class Initialized
INFO - 2022-03-18 18:23:19 --> Hooks Class Initialized
INFO - 2022-03-18 18:23:19 --> Utf8 Class Initialized
INFO - 2022-03-18 18:23:19 --> URI Class Initialized
INFO - 2022-03-18 18:23:19 --> Router Class Initialized
INFO - 2022-03-18 18:23:19 --> Output Class Initialized
INFO - 2022-03-18 18:23:19 --> Security Class Initialized
INFO - 2022-03-18 18:23:19 --> Input Class Initialized
INFO - 2022-03-18 18:23:19 --> Language Class Initialized
INFO - 2022-03-18 18:23:19 --> Loader Class Initialized
INFO - 2022-03-18 18:23:19 --> Helper loaded: url_helper
INFO - 2022-03-18 18:23:19 --> Helper loaded: form_helper
INFO - 2022-03-18 18:23:19 --> Database Driver Class Initialized
INFO - 2022-03-18 18:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:23:19 --> Form Validation Class Initialized
INFO - 2022-03-18 18:23:19 --> Controller Class Initialized
INFO - 2022-03-18 18:23:19 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:23:19 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:23:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:23:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli_result::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli_result::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli_result::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined property: mysqli_result::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:19 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:20 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
INFO - 2022-03-18 18:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:23:20 --> Final output sent to browser
INFO - 2022-03-18 18:23:35 --> Config Class Initialized
INFO - 2022-03-18 18:23:35 --> Hooks Class Initialized
INFO - 2022-03-18 18:23:35 --> Utf8 Class Initialized
INFO - 2022-03-18 18:23:35 --> URI Class Initialized
INFO - 2022-03-18 18:23:35 --> Router Class Initialized
INFO - 2022-03-18 18:23:35 --> Output Class Initialized
INFO - 2022-03-18 18:23:35 --> Security Class Initialized
INFO - 2022-03-18 18:23:35 --> Input Class Initialized
INFO - 2022-03-18 18:23:35 --> Language Class Initialized
INFO - 2022-03-18 18:23:35 --> Loader Class Initialized
INFO - 2022-03-18 18:23:35 --> Helper loaded: url_helper
INFO - 2022-03-18 18:23:35 --> Helper loaded: form_helper
INFO - 2022-03-18 18:23:35 --> Database Driver Class Initialized
INFO - 2022-03-18 18:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:23:35 --> Form Validation Class Initialized
INFO - 2022-03-18 18:23:35 --> Controller Class Initialized
INFO - 2022-03-18 18:23:35 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:23:35 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:23:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:23:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli_result::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli_result::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli_result::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined property: mysqli_result::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:35 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:23:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
INFO - 2022-03-18 18:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:23:36 --> Final output sent to browser
INFO - 2022-03-18 18:26:40 --> Config Class Initialized
INFO - 2022-03-18 18:26:40 --> Hooks Class Initialized
INFO - 2022-03-18 18:26:40 --> Utf8 Class Initialized
INFO - 2022-03-18 18:26:40 --> URI Class Initialized
INFO - 2022-03-18 18:26:40 --> Router Class Initialized
INFO - 2022-03-18 18:26:40 --> Output Class Initialized
INFO - 2022-03-18 18:26:40 --> Security Class Initialized
INFO - 2022-03-18 18:26:40 --> Input Class Initialized
INFO - 2022-03-18 18:26:40 --> Language Class Initialized
INFO - 2022-03-18 18:26:40 --> Loader Class Initialized
INFO - 2022-03-18 18:26:40 --> Helper loaded: url_helper
INFO - 2022-03-18 18:26:40 --> Helper loaded: form_helper
INFO - 2022-03-18 18:26:40 --> Database Driver Class Initialized
INFO - 2022-03-18 18:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:26:40 --> Form Validation Class Initialized
INFO - 2022-03-18 18:26:40 --> Controller Class Initialized
INFO - 2022-03-18 18:26:40 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:26:40 --> Model "M_todo_group_ptk" initialized
ERROR - 2022-03-18 18:26:40 --> Severity: Notice --> Undefined property: C_todo_list::$m_todo_group C:\laragon\www\list-todo\application\controllers\C_todo_list.php 15
ERROR - 2022-03-18 18:26:40 --> Severity: Error --> Call to a member function getAll() on null C:\laragon\www\list-todo\application\controllers\C_todo_list.php 15
INFO - 2022-03-18 18:26:52 --> Config Class Initialized
INFO - 2022-03-18 18:26:52 --> Hooks Class Initialized
INFO - 2022-03-18 18:26:52 --> Utf8 Class Initialized
INFO - 2022-03-18 18:26:52 --> URI Class Initialized
INFO - 2022-03-18 18:26:52 --> Router Class Initialized
INFO - 2022-03-18 18:26:52 --> Output Class Initialized
INFO - 2022-03-18 18:26:52 --> Security Class Initialized
INFO - 2022-03-18 18:26:52 --> Input Class Initialized
INFO - 2022-03-18 18:26:52 --> Language Class Initialized
INFO - 2022-03-18 18:26:52 --> Loader Class Initialized
INFO - 2022-03-18 18:26:52 --> Helper loaded: url_helper
INFO - 2022-03-18 18:26:52 --> Helper loaded: form_helper
INFO - 2022-03-18 18:26:52 --> Database Driver Class Initialized
INFO - 2022-03-18 18:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:26:52 --> Form Validation Class Initialized
INFO - 2022-03-18 18:26:52 --> Controller Class Initialized
INFO - 2022-03-18 18:26:52 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:26:52 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:26:52 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli_result::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli_result::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli_result::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Undefined property: mysqli_result::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:26:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
INFO - 2022-03-18 18:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:26:52 --> Final output sent to browser
INFO - 2022-03-18 18:27:51 --> Config Class Initialized
INFO - 2022-03-18 18:27:51 --> Hooks Class Initialized
INFO - 2022-03-18 18:27:51 --> Utf8 Class Initialized
INFO - 2022-03-18 18:27:51 --> URI Class Initialized
INFO - 2022-03-18 18:27:51 --> Router Class Initialized
INFO - 2022-03-18 18:27:51 --> Output Class Initialized
INFO - 2022-03-18 18:27:51 --> Security Class Initialized
INFO - 2022-03-18 18:27:51 --> Input Class Initialized
INFO - 2022-03-18 18:27:51 --> Language Class Initialized
INFO - 2022-03-18 18:27:51 --> Loader Class Initialized
INFO - 2022-03-18 18:27:51 --> Helper loaded: url_helper
INFO - 2022-03-18 18:27:51 --> Helper loaded: form_helper
INFO - 2022-03-18 18:27:51 --> Database Driver Class Initialized
INFO - 2022-03-18 18:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:27:51 --> Form Validation Class Initialized
INFO - 2022-03-18 18:27:51 --> Controller Class Initialized
INFO - 2022-03-18 18:27:51 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:27:51 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:27:51 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:27:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:27:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli_result::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli_result::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli_result::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Undefined property: mysqli_result::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:27:52 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
INFO - 2022-03-18 18:27:52 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:27:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:27:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:27:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:27:52 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:27:52 --> Final output sent to browser
INFO - 2022-03-18 18:28:30 --> Config Class Initialized
INFO - 2022-03-18 18:28:30 --> Hooks Class Initialized
INFO - 2022-03-18 18:28:31 --> Utf8 Class Initialized
INFO - 2022-03-18 18:28:31 --> URI Class Initialized
INFO - 2022-03-18 18:28:31 --> Router Class Initialized
INFO - 2022-03-18 18:28:31 --> Output Class Initialized
INFO - 2022-03-18 18:28:31 --> Security Class Initialized
INFO - 2022-03-18 18:28:31 --> Input Class Initialized
INFO - 2022-03-18 18:28:31 --> Language Class Initialized
INFO - 2022-03-18 18:28:31 --> Loader Class Initialized
INFO - 2022-03-18 18:28:31 --> Helper loaded: url_helper
INFO - 2022-03-18 18:28:31 --> Helper loaded: form_helper
INFO - 2022-03-18 18:28:31 --> Database Driver Class Initialized
INFO - 2022-03-18 18:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:28:31 --> Form Validation Class Initialized
INFO - 2022-03-18 18:28:31 --> Controller Class Initialized
INFO - 2022-03-18 18:28:31 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:28:31 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:28:31 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli_result::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli_result::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli_result::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Undefined property: mysqli_result::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:28:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
INFO - 2022-03-18 18:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:28:31 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:28:31 --> Final output sent to browser
INFO - 2022-03-18 18:30:30 --> Config Class Initialized
INFO - 2022-03-18 18:30:30 --> Hooks Class Initialized
INFO - 2022-03-18 18:30:30 --> Utf8 Class Initialized
INFO - 2022-03-18 18:30:30 --> URI Class Initialized
INFO - 2022-03-18 18:30:30 --> Router Class Initialized
INFO - 2022-03-18 18:30:30 --> Output Class Initialized
INFO - 2022-03-18 18:30:30 --> Security Class Initialized
INFO - 2022-03-18 18:30:30 --> Input Class Initialized
INFO - 2022-03-18 18:30:30 --> Language Class Initialized
INFO - 2022-03-18 18:30:30 --> Loader Class Initialized
INFO - 2022-03-18 18:30:30 --> Helper loaded: url_helper
INFO - 2022-03-18 18:30:30 --> Helper loaded: form_helper
INFO - 2022-03-18 18:30:30 --> Database Driver Class Initialized
INFO - 2022-03-18 18:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:30:30 --> Form Validation Class Initialized
INFO - 2022-03-18 18:30:30 --> Controller Class Initialized
INFO - 2022-03-18 18:30:30 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:30:30 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:30:30 --> Model "M_todo_group" initialized
ERROR - 2022-03-18 18:30:30 --> Severity: Notice --> Undefined index: user C:\laragon\www\list-todo\application\models\M_todo_list.php 27
ERROR - 2022-03-18 18:30:30 --> Query error: Column 'user' cannot be null - Invalid query: INSERT INTO `todo_list` (`todo_group`, `tgl_mulai`, `tgl_akhir`, `tgl_selesai`, `todo`, `user`) VALUES ('4', '2022-03-18', '2022-03-24', '2022-03-25', 'Tes Tes', NULL)
INFO - 2022-03-18 18:30:30 --> Language file loaded: language/english/db_lang.php
INFO - 2022-03-18 18:30:43 --> Config Class Initialized
INFO - 2022-03-18 18:30:43 --> Hooks Class Initialized
INFO - 2022-03-18 18:30:43 --> Utf8 Class Initialized
INFO - 2022-03-18 18:30:43 --> URI Class Initialized
INFO - 2022-03-18 18:30:43 --> Router Class Initialized
INFO - 2022-03-18 18:30:43 --> Output Class Initialized
INFO - 2022-03-18 18:30:43 --> Security Class Initialized
INFO - 2022-03-18 18:30:43 --> Input Class Initialized
INFO - 2022-03-18 18:30:43 --> Language Class Initialized
INFO - 2022-03-18 18:30:43 --> Loader Class Initialized
INFO - 2022-03-18 18:30:43 --> Helper loaded: url_helper
INFO - 2022-03-18 18:30:43 --> Helper loaded: form_helper
INFO - 2022-03-18 18:30:43 --> Database Driver Class Initialized
INFO - 2022-03-18 18:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:30:43 --> Form Validation Class Initialized
INFO - 2022-03-18 18:30:43 --> Controller Class Initialized
INFO - 2022-03-18 18:30:43 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:30:43 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:30:43 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:30:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:30:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 18:30:43 --> Severity: Notice --> Undefined property: mysqli::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:30:43 --> Severity: Notice --> Undefined property: mysqli::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:30:43 --> Severity: Notice --> Undefined property: mysqli::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:30:43 --> Severity: Notice --> Undefined property: mysqli::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:30:43 --> Severity: Notice --> Undefined property: mysqli::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:30:43 --> Severity: Notice --> Undefined property: mysqli::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:30:43 --> Severity: Notice --> Undefined property: mysqli::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:30:43 --> Severity: Notice --> Undefined property: mysqli::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Undefined property: mysqli_result::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Undefined property: mysqli_result::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Undefined property: mysqli_result::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Undefined property: mysqli_result::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:30:44 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
INFO - 2022-03-18 18:30:44 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:30:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:30:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:30:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:30:44 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:30:44 --> Final output sent to browser
INFO - 2022-03-18 18:30:55 --> Config Class Initialized
INFO - 2022-03-18 18:30:55 --> Hooks Class Initialized
INFO - 2022-03-18 18:30:55 --> Utf8 Class Initialized
INFO - 2022-03-18 18:30:55 --> URI Class Initialized
INFO - 2022-03-18 18:30:55 --> Router Class Initialized
INFO - 2022-03-18 18:30:55 --> Output Class Initialized
INFO - 2022-03-18 18:30:55 --> Security Class Initialized
INFO - 2022-03-18 18:30:55 --> Input Class Initialized
INFO - 2022-03-18 18:30:55 --> Language Class Initialized
INFO - 2022-03-18 18:30:55 --> Loader Class Initialized
INFO - 2022-03-18 18:30:55 --> Helper loaded: url_helper
INFO - 2022-03-18 18:30:55 --> Helper loaded: form_helper
INFO - 2022-03-18 18:30:55 --> Database Driver Class Initialized
INFO - 2022-03-18 18:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:30:55 --> Form Validation Class Initialized
INFO - 2022-03-18 18:30:55 --> Controller Class Initialized
INFO - 2022-03-18 18:30:55 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:30:55 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:30:55 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:30:55 --> Final output sent to browser
INFO - 2022-03-18 18:32:14 --> Config Class Initialized
INFO - 2022-03-18 18:32:14 --> Hooks Class Initialized
INFO - 2022-03-18 18:32:14 --> Utf8 Class Initialized
INFO - 2022-03-18 18:32:14 --> URI Class Initialized
INFO - 2022-03-18 18:32:14 --> Router Class Initialized
INFO - 2022-03-18 18:32:14 --> Output Class Initialized
INFO - 2022-03-18 18:32:14 --> Security Class Initialized
INFO - 2022-03-18 18:32:14 --> Input Class Initialized
INFO - 2022-03-18 18:32:14 --> Language Class Initialized
INFO - 2022-03-18 18:32:14 --> Loader Class Initialized
INFO - 2022-03-18 18:32:14 --> Helper loaded: url_helper
INFO - 2022-03-18 18:32:14 --> Helper loaded: form_helper
INFO - 2022-03-18 18:32:14 --> Database Driver Class Initialized
INFO - 2022-03-18 18:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:32:14 --> Form Validation Class Initialized
INFO - 2022-03-18 18:32:14 --> Controller Class Initialized
INFO - 2022-03-18 18:32:14 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:32:14 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:32:14 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:32:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:32:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 18:32:14 --> Severity: Notice --> Undefined property: mysqli::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:14 --> Severity: Notice --> Undefined property: mysqli::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli_result::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli_result::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli_result::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Undefined property: mysqli_result::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
INFO - 2022-03-18 18:32:15 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:32:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:32:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:32:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:32:15 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:32:15 --> Final output sent to browser
INFO - 2022-03-18 18:32:29 --> Config Class Initialized
INFO - 2022-03-18 18:32:29 --> Hooks Class Initialized
INFO - 2022-03-18 18:32:29 --> Utf8 Class Initialized
INFO - 2022-03-18 18:32:29 --> URI Class Initialized
INFO - 2022-03-18 18:32:29 --> Router Class Initialized
INFO - 2022-03-18 18:32:29 --> Output Class Initialized
INFO - 2022-03-18 18:32:29 --> Security Class Initialized
INFO - 2022-03-18 18:32:29 --> Input Class Initialized
INFO - 2022-03-18 18:32:29 --> Language Class Initialized
INFO - 2022-03-18 18:32:29 --> Loader Class Initialized
INFO - 2022-03-18 18:32:29 --> Helper loaded: url_helper
INFO - 2022-03-18 18:32:29 --> Helper loaded: form_helper
INFO - 2022-03-18 18:32:29 --> Database Driver Class Initialized
INFO - 2022-03-18 18:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:32:29 --> Form Validation Class Initialized
INFO - 2022-03-18 18:32:29 --> Controller Class Initialized
INFO - 2022-03-18 18:32:29 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:32:29 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:32:29 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:32:29 --> Config Class Initialized
INFO - 2022-03-18 18:32:29 --> Hooks Class Initialized
INFO - 2022-03-18 18:32:29 --> Utf8 Class Initialized
INFO - 2022-03-18 18:32:29 --> URI Class Initialized
INFO - 2022-03-18 18:32:29 --> Router Class Initialized
INFO - 2022-03-18 18:32:29 --> Output Class Initialized
INFO - 2022-03-18 18:32:29 --> Security Class Initialized
INFO - 2022-03-18 18:32:29 --> Input Class Initialized
INFO - 2022-03-18 18:32:29 --> Language Class Initialized
INFO - 2022-03-18 18:32:29 --> Loader Class Initialized
INFO - 2022-03-18 18:32:29 --> Helper loaded: url_helper
INFO - 2022-03-18 18:32:29 --> Helper loaded: form_helper
INFO - 2022-03-18 18:32:29 --> Database Driver Class Initialized
INFO - 2022-03-18 18:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:32:29 --> Form Validation Class Initialized
INFO - 2022-03-18 18:32:29 --> Controller Class Initialized
INFO - 2022-03-18 18:32:29 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:32:29 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:32:29 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:32:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:32:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli_result::$todo_group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_akhir C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli_result::$todo C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli_result::$status C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Undefined property: mysqli_result::$user C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:29 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 49
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 52
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 55
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 58
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 61
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 64
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 67
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 70
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:32:30 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
INFO - 2022-03-18 18:32:30 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:32:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:32:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:32:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:32:30 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:32:30 --> Final output sent to browser
INFO - 2022-03-18 18:35:02 --> Config Class Initialized
INFO - 2022-03-18 18:35:02 --> Hooks Class Initialized
INFO - 2022-03-18 18:35:02 --> Utf8 Class Initialized
INFO - 2022-03-18 18:35:02 --> URI Class Initialized
INFO - 2022-03-18 18:35:02 --> Router Class Initialized
INFO - 2022-03-18 18:35:02 --> Output Class Initialized
INFO - 2022-03-18 18:35:02 --> Security Class Initialized
INFO - 2022-03-18 18:35:02 --> Input Class Initialized
INFO - 2022-03-18 18:35:02 --> Language Class Initialized
INFO - 2022-03-18 18:35:02 --> Loader Class Initialized
INFO - 2022-03-18 18:35:02 --> Helper loaded: url_helper
INFO - 2022-03-18 18:35:02 --> Helper loaded: form_helper
INFO - 2022-03-18 18:35:02 --> Database Driver Class Initialized
INFO - 2022-03-18 18:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:35:02 --> Form Validation Class Initialized
INFO - 2022-03-18 18:35:02 --> Controller Class Initialized
INFO - 2022-03-18 18:35:02 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:35:02 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:35:02 --> Model "M_todo_group" initialized
ERROR - 2022-03-18 18:35:02 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::return() C:\laragon\www\list-todo\application\models\M_todo_list.php 10
INFO - 2022-03-18 18:35:15 --> Config Class Initialized
INFO - 2022-03-18 18:35:15 --> Hooks Class Initialized
INFO - 2022-03-18 18:35:15 --> Utf8 Class Initialized
INFO - 2022-03-18 18:35:15 --> URI Class Initialized
INFO - 2022-03-18 18:35:15 --> Router Class Initialized
INFO - 2022-03-18 18:35:15 --> Output Class Initialized
INFO - 2022-03-18 18:35:15 --> Security Class Initialized
INFO - 2022-03-18 18:35:15 --> Input Class Initialized
INFO - 2022-03-18 18:35:15 --> Language Class Initialized
INFO - 2022-03-18 18:35:15 --> Loader Class Initialized
INFO - 2022-03-18 18:35:15 --> Helper loaded: url_helper
INFO - 2022-03-18 18:35:15 --> Helper loaded: form_helper
INFO - 2022-03-18 18:35:15 --> Database Driver Class Initialized
INFO - 2022-03-18 18:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:35:15 --> Form Validation Class Initialized
INFO - 2022-03-18 18:35:15 --> Controller Class Initialized
INFO - 2022-03-18 18:35:15 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:35:15 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:35:15 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:35:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:35:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 18:35:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:35:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:35:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
ERROR - 2022-03-18 18:35:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 74
ERROR - 2022-03-18 18:35:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 76
ERROR - 2022-03-18 18:35:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_index.php 78
INFO - 2022-03-18 18:35:15 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:35:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:35:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:35:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:35:15 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:35:15 --> Final output sent to browser
INFO - 2022-03-18 18:35:41 --> Config Class Initialized
INFO - 2022-03-18 18:35:41 --> Hooks Class Initialized
INFO - 2022-03-18 18:35:41 --> Utf8 Class Initialized
INFO - 2022-03-18 18:35:41 --> URI Class Initialized
INFO - 2022-03-18 18:35:41 --> Router Class Initialized
INFO - 2022-03-18 18:35:41 --> Output Class Initialized
INFO - 2022-03-18 18:35:41 --> Security Class Initialized
INFO - 2022-03-18 18:35:41 --> Input Class Initialized
INFO - 2022-03-18 18:35:41 --> Language Class Initialized
INFO - 2022-03-18 18:35:41 --> Loader Class Initialized
INFO - 2022-03-18 18:35:41 --> Helper loaded: url_helper
INFO - 2022-03-18 18:35:41 --> Helper loaded: form_helper
INFO - 2022-03-18 18:35:41 --> Database Driver Class Initialized
INFO - 2022-03-18 18:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:35:41 --> Form Validation Class Initialized
INFO - 2022-03-18 18:35:41 --> Controller Class Initialized
INFO - 2022-03-18 18:35:41 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:35:41 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:35:41 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:35:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:35:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:35:41 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:35:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:35:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:35:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:35:41 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:35:41 --> Final output sent to browser
INFO - 2022-03-18 18:35:56 --> Config Class Initialized
INFO - 2022-03-18 18:35:56 --> Hooks Class Initialized
INFO - 2022-03-18 18:35:56 --> Utf8 Class Initialized
INFO - 2022-03-18 18:35:56 --> URI Class Initialized
INFO - 2022-03-18 18:35:56 --> Router Class Initialized
INFO - 2022-03-18 18:35:56 --> Output Class Initialized
INFO - 2022-03-18 18:35:56 --> Security Class Initialized
INFO - 2022-03-18 18:35:56 --> Input Class Initialized
INFO - 2022-03-18 18:35:56 --> Language Class Initialized
INFO - 2022-03-18 18:35:56 --> Loader Class Initialized
INFO - 2022-03-18 18:35:56 --> Helper loaded: url_helper
INFO - 2022-03-18 18:35:56 --> Helper loaded: form_helper
INFO - 2022-03-18 18:35:56 --> Database Driver Class Initialized
INFO - 2022-03-18 18:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:35:56 --> Form Validation Class Initialized
INFO - 2022-03-18 18:35:56 --> Controller Class Initialized
INFO - 2022-03-18 18:35:56 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:35:56 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:35:56 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:35:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:35:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:35:56 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:35:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:35:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:35:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:35:56 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:35:56 --> Final output sent to browser
INFO - 2022-03-18 18:36:13 --> Config Class Initialized
INFO - 2022-03-18 18:36:13 --> Hooks Class Initialized
INFO - 2022-03-18 18:36:13 --> Utf8 Class Initialized
INFO - 2022-03-18 18:36:13 --> URI Class Initialized
INFO - 2022-03-18 18:36:13 --> Router Class Initialized
INFO - 2022-03-18 18:36:13 --> Output Class Initialized
INFO - 2022-03-18 18:36:13 --> Security Class Initialized
INFO - 2022-03-18 18:36:13 --> Input Class Initialized
INFO - 2022-03-18 18:36:13 --> Language Class Initialized
INFO - 2022-03-18 18:36:13 --> Loader Class Initialized
INFO - 2022-03-18 18:36:13 --> Helper loaded: url_helper
INFO - 2022-03-18 18:36:13 --> Helper loaded: form_helper
INFO - 2022-03-18 18:36:13 --> Database Driver Class Initialized
INFO - 2022-03-18 18:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:36:13 --> Form Validation Class Initialized
INFO - 2022-03-18 18:36:13 --> Controller Class Initialized
INFO - 2022-03-18 18:36:13 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:36:13 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:36:13 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:36:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:36:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:36:13 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:36:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:36:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:36:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:36:13 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:36:13 --> Final output sent to browser
INFO - 2022-03-18 18:36:26 --> Config Class Initialized
INFO - 2022-03-18 18:36:26 --> Hooks Class Initialized
INFO - 2022-03-18 18:36:26 --> Utf8 Class Initialized
INFO - 2022-03-18 18:36:26 --> URI Class Initialized
INFO - 2022-03-18 18:36:26 --> Router Class Initialized
INFO - 2022-03-18 18:36:26 --> Output Class Initialized
INFO - 2022-03-18 18:36:26 --> Security Class Initialized
INFO - 2022-03-18 18:36:26 --> Input Class Initialized
INFO - 2022-03-18 18:36:26 --> Language Class Initialized
INFO - 2022-03-18 18:36:26 --> Loader Class Initialized
INFO - 2022-03-18 18:36:26 --> Helper loaded: url_helper
INFO - 2022-03-18 18:36:26 --> Helper loaded: form_helper
INFO - 2022-03-18 18:36:26 --> Database Driver Class Initialized
INFO - 2022-03-18 18:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:36:26 --> Form Validation Class Initialized
INFO - 2022-03-18 18:36:26 --> Controller Class Initialized
INFO - 2022-03-18 18:36:26 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:36:26 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:36:26 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:36:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:36:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:36:26 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:36:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:36:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:36:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:36:26 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:36:26 --> Final output sent to browser
INFO - 2022-03-18 18:36:28 --> Config Class Initialized
INFO - 2022-03-18 18:36:28 --> Hooks Class Initialized
INFO - 2022-03-18 18:36:28 --> Utf8 Class Initialized
INFO - 2022-03-18 18:36:28 --> URI Class Initialized
INFO - 2022-03-18 18:36:28 --> Router Class Initialized
INFO - 2022-03-18 18:36:28 --> Output Class Initialized
INFO - 2022-03-18 18:36:29 --> Security Class Initialized
INFO - 2022-03-18 18:36:29 --> Input Class Initialized
INFO - 2022-03-18 18:36:29 --> Language Class Initialized
ERROR - 2022-03-18 18:36:29 --> 404 Page Not Found: C_todo_group/todo_task
INFO - 2022-03-18 18:36:45 --> Config Class Initialized
INFO - 2022-03-18 18:36:45 --> Hooks Class Initialized
INFO - 2022-03-18 18:36:45 --> Utf8 Class Initialized
INFO - 2022-03-18 18:36:45 --> URI Class Initialized
INFO - 2022-03-18 18:36:46 --> Router Class Initialized
INFO - 2022-03-18 18:36:46 --> Output Class Initialized
INFO - 2022-03-18 18:36:46 --> Security Class Initialized
INFO - 2022-03-18 18:36:46 --> Input Class Initialized
INFO - 2022-03-18 18:36:46 --> Language Class Initialized
INFO - 2022-03-18 18:36:46 --> Loader Class Initialized
INFO - 2022-03-18 18:36:46 --> Helper loaded: url_helper
INFO - 2022-03-18 18:36:46 --> Helper loaded: form_helper
INFO - 2022-03-18 18:36:46 --> Database Driver Class Initialized
INFO - 2022-03-18 18:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:36:46 --> Form Validation Class Initialized
INFO - 2022-03-18 18:36:46 --> Controller Class Initialized
INFO - 2022-03-18 18:36:46 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:36:46 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:36:46 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:36:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:36:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:36:46 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:36:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:36:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:36:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:36:46 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:36:46 --> Final output sent to browser
INFO - 2022-03-18 18:36:48 --> Config Class Initialized
INFO - 2022-03-18 18:36:48 --> Hooks Class Initialized
INFO - 2022-03-18 18:36:48 --> Utf8 Class Initialized
INFO - 2022-03-18 18:36:48 --> URI Class Initialized
INFO - 2022-03-18 18:36:48 --> Router Class Initialized
INFO - 2022-03-18 18:36:48 --> Output Class Initialized
INFO - 2022-03-18 18:36:48 --> Security Class Initialized
INFO - 2022-03-18 18:36:48 --> Input Class Initialized
INFO - 2022-03-18 18:36:48 --> Language Class Initialized
INFO - 2022-03-18 18:36:48 --> Loader Class Initialized
INFO - 2022-03-18 18:36:48 --> Helper loaded: url_helper
INFO - 2022-03-18 18:36:48 --> Helper loaded: form_helper
INFO - 2022-03-18 18:36:48 --> Database Driver Class Initialized
INFO - 2022-03-18 18:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:36:48 --> Form Validation Class Initialized
INFO - 2022-03-18 18:36:48 --> Controller Class Initialized
INFO - 2022-03-18 18:36:48 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:36:48 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:36:48 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:36:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:36:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:36:48 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 18:36:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:36:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:36:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:36:48 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:36:48 --> Final output sent to browser
INFO - 2022-03-18 18:36:54 --> Config Class Initialized
INFO - 2022-03-18 18:36:54 --> Hooks Class Initialized
INFO - 2022-03-18 18:36:54 --> Utf8 Class Initialized
INFO - 2022-03-18 18:36:54 --> URI Class Initialized
INFO - 2022-03-18 18:36:54 --> Router Class Initialized
INFO - 2022-03-18 18:36:54 --> Output Class Initialized
INFO - 2022-03-18 18:36:54 --> Security Class Initialized
INFO - 2022-03-18 18:36:54 --> Input Class Initialized
INFO - 2022-03-18 18:36:54 --> Language Class Initialized
INFO - 2022-03-18 18:36:54 --> Loader Class Initialized
INFO - 2022-03-18 18:36:54 --> Helper loaded: url_helper
INFO - 2022-03-18 18:36:54 --> Helper loaded: form_helper
INFO - 2022-03-18 18:36:54 --> Database Driver Class Initialized
INFO - 2022-03-18 18:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:36:54 --> Form Validation Class Initialized
INFO - 2022-03-18 18:36:54 --> Controller Class Initialized
INFO - 2022-03-18 18:36:54 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:36:54 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:36:54 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:36:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:36:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:36:54 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 18:36:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:36:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:36:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:36:54 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:36:54 --> Final output sent to browser
INFO - 2022-03-18 18:41:41 --> Config Class Initialized
INFO - 2022-03-18 18:41:41 --> Hooks Class Initialized
INFO - 2022-03-18 18:41:41 --> Utf8 Class Initialized
INFO - 2022-03-18 18:41:41 --> URI Class Initialized
INFO - 2022-03-18 18:41:41 --> Router Class Initialized
INFO - 2022-03-18 18:41:41 --> Output Class Initialized
INFO - 2022-03-18 18:41:41 --> Security Class Initialized
INFO - 2022-03-18 18:41:41 --> Input Class Initialized
INFO - 2022-03-18 18:41:41 --> Language Class Initialized
INFO - 2022-03-18 18:41:41 --> Loader Class Initialized
INFO - 2022-03-18 18:41:41 --> Helper loaded: url_helper
INFO - 2022-03-18 18:41:41 --> Helper loaded: form_helper
INFO - 2022-03-18 18:41:41 --> Database Driver Class Initialized
INFO - 2022-03-18 18:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:41:41 --> Form Validation Class Initialized
INFO - 2022-03-18 18:41:41 --> Controller Class Initialized
INFO - 2022-03-18 18:41:41 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:41:41 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:41:41 --> Model "M_todo_group" initialized
ERROR - 2022-03-18 18:41:41 --> Severity: Warning --> Missing argument 1 for C_todo_list::tambah_task() C:\laragon\www\list-todo\application\controllers\C_todo_list.php 62
ERROR - 2022-03-18 18:41:41 --> Severity: Notice --> Undefined property: C_todo_list::$m_todo_task C:\laragon\www\list-todo\application\controllers\C_todo_list.php 64
ERROR - 2022-03-18 18:41:41 --> Severity: Error --> Call to a member function tambah() on null C:\laragon\www\list-todo\application\controllers\C_todo_list.php 64
INFO - 2022-03-18 18:42:30 --> Config Class Initialized
INFO - 2022-03-18 18:42:30 --> Hooks Class Initialized
INFO - 2022-03-18 18:42:30 --> Utf8 Class Initialized
INFO - 2022-03-18 18:42:30 --> URI Class Initialized
INFO - 2022-03-18 18:42:30 --> Router Class Initialized
INFO - 2022-03-18 18:42:30 --> Output Class Initialized
INFO - 2022-03-18 18:42:30 --> Security Class Initialized
INFO - 2022-03-18 18:42:30 --> Input Class Initialized
INFO - 2022-03-18 18:42:30 --> Language Class Initialized
INFO - 2022-03-18 18:42:30 --> Loader Class Initialized
INFO - 2022-03-18 18:42:30 --> Helper loaded: url_helper
INFO - 2022-03-18 18:42:30 --> Helper loaded: form_helper
INFO - 2022-03-18 18:42:30 --> Database Driver Class Initialized
INFO - 2022-03-18 18:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:42:30 --> Form Validation Class Initialized
INFO - 2022-03-18 18:42:30 --> Controller Class Initialized
INFO - 2022-03-18 18:42:30 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:42:30 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:42:30 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:42:30 --> Model "M_todo_task" initialized
ERROR - 2022-03-18 18:42:30 --> Severity: Warning --> Missing argument 1 for C_todo_list::tambah_task() C:\laragon\www\list-todo\application\controllers\C_todo_list.php 63
ERROR - 2022-03-18 18:42:30 --> Severity: Notice --> Undefined index: user C:\laragon\www\list-todo\application\models\M_todo_task.php 28
ERROR - 2022-03-18 18:42:30 --> Query error: Unknown column 'user' in 'field list' - Invalid query: INSERT INTO `todo_task` (`id`, `todo`, `task`, `tgl_mulai`, `tgl_selesai`, `status`, `user`) VALUES ('', '1', 'task 1', '2022-03-18', '2022-03-25', 'B', NULL)
INFO - 2022-03-18 18:42:30 --> Language file loaded: language/english/db_lang.php
INFO - 2022-03-18 18:43:06 --> Config Class Initialized
INFO - 2022-03-18 18:43:06 --> Hooks Class Initialized
INFO - 2022-03-18 18:43:06 --> Utf8 Class Initialized
INFO - 2022-03-18 18:43:06 --> URI Class Initialized
INFO - 2022-03-18 18:43:06 --> Router Class Initialized
INFO - 2022-03-18 18:43:06 --> Output Class Initialized
INFO - 2022-03-18 18:43:06 --> Security Class Initialized
INFO - 2022-03-18 18:43:06 --> Input Class Initialized
INFO - 2022-03-18 18:43:06 --> Language Class Initialized
INFO - 2022-03-18 18:43:06 --> Loader Class Initialized
INFO - 2022-03-18 18:43:06 --> Helper loaded: url_helper
INFO - 2022-03-18 18:43:06 --> Helper loaded: form_helper
INFO - 2022-03-18 18:43:06 --> Database Driver Class Initialized
INFO - 2022-03-18 18:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:43:06 --> Form Validation Class Initialized
INFO - 2022-03-18 18:43:06 --> Controller Class Initialized
INFO - 2022-03-18 18:43:06 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:43:06 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:43:06 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:43:06 --> Model "M_todo_task" initialized
ERROR - 2022-03-18 18:43:06 --> Severity: Warning --> Missing argument 1 for C_todo_list::tambah_task() C:\laragon\www\list-todo\application\controllers\C_todo_list.php 63
ERROR - 2022-03-18 18:43:06 --> Severity: Notice --> Undefined variable: id C:\laragon\www\list-todo\application\controllers\C_todo_list.php 66
INFO - 2022-03-18 18:43:06 --> Config Class Initialized
INFO - 2022-03-18 18:43:06 --> Hooks Class Initialized
INFO - 2022-03-18 18:43:06 --> Utf8 Class Initialized
INFO - 2022-03-18 18:43:06 --> URI Class Initialized
INFO - 2022-03-18 18:43:06 --> Router Class Initialized
INFO - 2022-03-18 18:43:06 --> Output Class Initialized
INFO - 2022-03-18 18:43:06 --> Security Class Initialized
INFO - 2022-03-18 18:43:06 --> Input Class Initialized
INFO - 2022-03-18 18:43:06 --> Language Class Initialized
INFO - 2022-03-18 18:43:06 --> Loader Class Initialized
INFO - 2022-03-18 18:43:06 --> Helper loaded: url_helper
INFO - 2022-03-18 18:43:06 --> Helper loaded: form_helper
INFO - 2022-03-18 18:43:06 --> Database Driver Class Initialized
INFO - 2022-03-18 18:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:43:06 --> Form Validation Class Initialized
INFO - 2022-03-18 18:43:06 --> Controller Class Initialized
INFO - 2022-03-18 18:43:06 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:43:06 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:43:06 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:43:06 --> Model "M_todo_task" initialized
INFO - 2022-03-18 18:43:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:43:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:43:06 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 18:43:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:43:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:43:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:43:06 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:43:06 --> Final output sent to browser
INFO - 2022-03-18 18:43:13 --> Config Class Initialized
INFO - 2022-03-18 18:43:13 --> Hooks Class Initialized
INFO - 2022-03-18 18:43:13 --> Utf8 Class Initialized
INFO - 2022-03-18 18:43:13 --> URI Class Initialized
INFO - 2022-03-18 18:43:13 --> Router Class Initialized
INFO - 2022-03-18 18:43:13 --> Output Class Initialized
INFO - 2022-03-18 18:43:13 --> Security Class Initialized
INFO - 2022-03-18 18:43:13 --> Input Class Initialized
INFO - 2022-03-18 18:43:13 --> Language Class Initialized
INFO - 2022-03-18 18:43:13 --> Loader Class Initialized
INFO - 2022-03-18 18:43:13 --> Helper loaded: url_helper
INFO - 2022-03-18 18:43:13 --> Helper loaded: form_helper
INFO - 2022-03-18 18:43:13 --> Database Driver Class Initialized
INFO - 2022-03-18 18:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:43:13 --> Form Validation Class Initialized
INFO - 2022-03-18 18:43:13 --> Controller Class Initialized
INFO - 2022-03-18 18:43:13 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:43:13 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:43:13 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:43:13 --> Model "M_todo_task" initialized
INFO - 2022-03-18 18:43:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:43:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:43:13 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 18:43:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:43:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:43:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:43:13 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:43:13 --> Final output sent to browser
INFO - 2022-03-18 18:44:38 --> Config Class Initialized
INFO - 2022-03-18 18:44:38 --> Hooks Class Initialized
INFO - 2022-03-18 18:44:38 --> Utf8 Class Initialized
INFO - 2022-03-18 18:44:38 --> URI Class Initialized
INFO - 2022-03-18 18:44:38 --> Router Class Initialized
INFO - 2022-03-18 18:44:38 --> Output Class Initialized
INFO - 2022-03-18 18:44:38 --> Security Class Initialized
INFO - 2022-03-18 18:44:38 --> Input Class Initialized
INFO - 2022-03-18 18:44:38 --> Language Class Initialized
INFO - 2022-03-18 18:44:38 --> Loader Class Initialized
INFO - 2022-03-18 18:44:38 --> Helper loaded: url_helper
INFO - 2022-03-18 18:44:38 --> Helper loaded: form_helper
INFO - 2022-03-18 18:44:38 --> Database Driver Class Initialized
INFO - 2022-03-18 18:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:44:38 --> Form Validation Class Initialized
INFO - 2022-03-18 18:44:38 --> Controller Class Initialized
INFO - 2022-03-18 18:44:38 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:44:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:44:38 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:44:38 --> Model "M_todo_task" initialized
INFO - 2022-03-18 18:44:38 --> Config Class Initialized
INFO - 2022-03-18 18:44:38 --> Hooks Class Initialized
INFO - 2022-03-18 18:44:38 --> Utf8 Class Initialized
INFO - 2022-03-18 18:44:38 --> URI Class Initialized
INFO - 2022-03-18 18:44:38 --> Router Class Initialized
INFO - 2022-03-18 18:44:38 --> Output Class Initialized
INFO - 2022-03-18 18:44:38 --> Security Class Initialized
INFO - 2022-03-18 18:44:38 --> Input Class Initialized
INFO - 2022-03-18 18:44:38 --> Language Class Initialized
INFO - 2022-03-18 18:44:38 --> Loader Class Initialized
INFO - 2022-03-18 18:44:38 --> Helper loaded: url_helper
INFO - 2022-03-18 18:44:38 --> Helper loaded: form_helper
INFO - 2022-03-18 18:44:38 --> Database Driver Class Initialized
INFO - 2022-03-18 18:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:44:38 --> Form Validation Class Initialized
INFO - 2022-03-18 18:44:38 --> Controller Class Initialized
INFO - 2022-03-18 18:44:38 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:44:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:44:38 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:44:38 --> Model "M_todo_task" initialized
INFO - 2022-03-18 18:44:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:44:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:44:38 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 18:44:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:44:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:44:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:44:38 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:44:38 --> Final output sent to browser
INFO - 2022-03-18 18:45:48 --> Config Class Initialized
INFO - 2022-03-18 18:45:48 --> Hooks Class Initialized
INFO - 2022-03-18 18:45:48 --> Utf8 Class Initialized
INFO - 2022-03-18 18:45:48 --> URI Class Initialized
INFO - 2022-03-18 18:45:48 --> Router Class Initialized
INFO - 2022-03-18 18:45:48 --> Output Class Initialized
INFO - 2022-03-18 18:45:48 --> Security Class Initialized
INFO - 2022-03-18 18:45:48 --> Input Class Initialized
INFO - 2022-03-18 18:45:49 --> Language Class Initialized
INFO - 2022-03-18 18:45:49 --> Loader Class Initialized
INFO - 2022-03-18 18:45:49 --> Helper loaded: url_helper
INFO - 2022-03-18 18:45:49 --> Helper loaded: form_helper
INFO - 2022-03-18 18:45:49 --> Database Driver Class Initialized
INFO - 2022-03-18 18:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:45:49 --> Form Validation Class Initialized
INFO - 2022-03-18 18:45:49 --> Controller Class Initialized
INFO - 2022-03-18 18:45:49 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:45:49 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:45:49 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:45:49 --> Model "M_todo_task" initialized
INFO - 2022-03-18 18:45:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:45:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:45:49 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 18:45:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:45:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:45:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:45:49 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:45:49 --> Final output sent to browser
INFO - 2022-03-18 18:45:59 --> Config Class Initialized
INFO - 2022-03-18 18:45:59 --> Hooks Class Initialized
INFO - 2022-03-18 18:45:59 --> Utf8 Class Initialized
INFO - 2022-03-18 18:45:59 --> URI Class Initialized
INFO - 2022-03-18 18:45:59 --> Router Class Initialized
INFO - 2022-03-18 18:45:59 --> Output Class Initialized
INFO - 2022-03-18 18:45:59 --> Security Class Initialized
INFO - 2022-03-18 18:45:59 --> Input Class Initialized
INFO - 2022-03-18 18:45:59 --> Language Class Initialized
INFO - 2022-03-18 18:46:00 --> Loader Class Initialized
INFO - 2022-03-18 18:46:00 --> Helper loaded: url_helper
INFO - 2022-03-18 18:46:00 --> Helper loaded: form_helper
INFO - 2022-03-18 18:46:00 --> Database Driver Class Initialized
INFO - 2022-03-18 18:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:46:00 --> Form Validation Class Initialized
INFO - 2022-03-18 18:46:00 --> Controller Class Initialized
INFO - 2022-03-18 18:46:00 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:46:00 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:46:00 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:46:00 --> Model "M_todo_task" initialized
INFO - 2022-03-18 18:46:00 --> Config Class Initialized
INFO - 2022-03-18 18:46:00 --> Hooks Class Initialized
INFO - 2022-03-18 18:46:00 --> Utf8 Class Initialized
INFO - 2022-03-18 18:46:00 --> URI Class Initialized
INFO - 2022-03-18 18:46:00 --> Router Class Initialized
INFO - 2022-03-18 18:46:00 --> Output Class Initialized
INFO - 2022-03-18 18:46:00 --> Security Class Initialized
INFO - 2022-03-18 18:46:00 --> Input Class Initialized
INFO - 2022-03-18 18:46:00 --> Language Class Initialized
INFO - 2022-03-18 18:46:00 --> Loader Class Initialized
INFO - 2022-03-18 18:46:00 --> Helper loaded: url_helper
INFO - 2022-03-18 18:46:00 --> Helper loaded: form_helper
INFO - 2022-03-18 18:46:00 --> Database Driver Class Initialized
INFO - 2022-03-18 18:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:46:00 --> Form Validation Class Initialized
INFO - 2022-03-18 18:46:00 --> Controller Class Initialized
INFO - 2022-03-18 18:46:00 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:46:00 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:46:00 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:46:00 --> Model "M_todo_task" initialized
INFO - 2022-03-18 18:46:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:46:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:46:00 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 18:46:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:46:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:46:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:46:00 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:46:00 --> Final output sent to browser
INFO - 2022-03-18 18:47:13 --> Config Class Initialized
INFO - 2022-03-18 18:47:13 --> Hooks Class Initialized
INFO - 2022-03-18 18:47:13 --> Utf8 Class Initialized
INFO - 2022-03-18 18:47:13 --> URI Class Initialized
INFO - 2022-03-18 18:47:13 --> Router Class Initialized
INFO - 2022-03-18 18:47:13 --> Output Class Initialized
INFO - 2022-03-18 18:47:13 --> Security Class Initialized
INFO - 2022-03-18 18:47:13 --> Input Class Initialized
INFO - 2022-03-18 18:47:13 --> Language Class Initialized
INFO - 2022-03-18 18:47:13 --> Loader Class Initialized
INFO - 2022-03-18 18:47:13 --> Helper loaded: url_helper
INFO - 2022-03-18 18:47:13 --> Helper loaded: form_helper
INFO - 2022-03-18 18:47:13 --> Database Driver Class Initialized
INFO - 2022-03-18 18:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:47:13 --> Form Validation Class Initialized
INFO - 2022-03-18 18:47:13 --> Controller Class Initialized
INFO - 2022-03-18 18:47:13 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:47:13 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:47:13 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:47:13 --> Model "M_todo_task" initialized
INFO - 2022-03-18 18:47:13 --> Config Class Initialized
INFO - 2022-03-18 18:47:13 --> Hooks Class Initialized
INFO - 2022-03-18 18:47:13 --> Utf8 Class Initialized
INFO - 2022-03-18 18:47:13 --> URI Class Initialized
INFO - 2022-03-18 18:47:13 --> Router Class Initialized
INFO - 2022-03-18 18:47:13 --> Output Class Initialized
INFO - 2022-03-18 18:47:13 --> Security Class Initialized
INFO - 2022-03-18 18:47:13 --> Input Class Initialized
INFO - 2022-03-18 18:47:13 --> Language Class Initialized
INFO - 2022-03-18 18:47:13 --> Loader Class Initialized
INFO - 2022-03-18 18:47:13 --> Helper loaded: url_helper
INFO - 2022-03-18 18:47:13 --> Helper loaded: form_helper
INFO - 2022-03-18 18:47:13 --> Database Driver Class Initialized
INFO - 2022-03-18 18:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 18:47:13 --> Form Validation Class Initialized
INFO - 2022-03-18 18:47:13 --> Controller Class Initialized
INFO - 2022-03-18 18:47:13 --> Model "M_todo_list" initialized
INFO - 2022-03-18 18:47:13 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 18:47:13 --> Model "M_todo_group" initialized
INFO - 2022-03-18 18:47:13 --> Model "M_todo_task" initialized
INFO - 2022-03-18 18:47:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 18:47:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 18:47:13 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 18:47:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 18:47:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 18:47:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 18:47:13 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 18:47:13 --> Final output sent to browser
INFO - 2022-03-18 19:56:08 --> Config Class Initialized
INFO - 2022-03-18 19:56:08 --> Hooks Class Initialized
INFO - 2022-03-18 19:56:08 --> Utf8 Class Initialized
INFO - 2022-03-18 19:56:08 --> URI Class Initialized
INFO - 2022-03-18 19:56:08 --> Router Class Initialized
INFO - 2022-03-18 19:56:08 --> Output Class Initialized
INFO - 2022-03-18 19:56:08 --> Security Class Initialized
INFO - 2022-03-18 19:56:08 --> Input Class Initialized
INFO - 2022-03-18 19:56:08 --> Language Class Initialized
INFO - 2022-03-18 19:56:08 --> Loader Class Initialized
INFO - 2022-03-18 19:56:08 --> Helper loaded: url_helper
INFO - 2022-03-18 19:56:08 --> Helper loaded: form_helper
INFO - 2022-03-18 19:56:08 --> Database Driver Class Initialized
INFO - 2022-03-18 19:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 19:56:08 --> Form Validation Class Initialized
INFO - 2022-03-18 19:56:08 --> Controller Class Initialized
INFO - 2022-03-18 19:56:08 --> Model "M_todo_list" initialized
INFO - 2022-03-18 19:56:08 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 19:56:08 --> Model "M_todo_group" initialized
INFO - 2022-03-18 19:56:08 --> Model "M_todo_task" initialized
INFO - 2022-03-18 19:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 19:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 19:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 19:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 19:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 19:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 19:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 19:56:08 --> Final output sent to browser
INFO - 2022-03-18 19:56:29 --> Config Class Initialized
INFO - 2022-03-18 19:56:29 --> Hooks Class Initialized
INFO - 2022-03-18 19:56:30 --> Utf8 Class Initialized
INFO - 2022-03-18 19:56:30 --> URI Class Initialized
INFO - 2022-03-18 19:56:30 --> Router Class Initialized
INFO - 2022-03-18 19:56:30 --> Output Class Initialized
INFO - 2022-03-18 19:56:30 --> Security Class Initialized
INFO - 2022-03-18 19:56:30 --> Input Class Initialized
INFO - 2022-03-18 19:56:30 --> Language Class Initialized
INFO - 2022-03-18 19:56:30 --> Loader Class Initialized
INFO - 2022-03-18 19:56:30 --> Helper loaded: url_helper
INFO - 2022-03-18 19:56:30 --> Helper loaded: form_helper
INFO - 2022-03-18 19:56:30 --> Database Driver Class Initialized
INFO - 2022-03-18 19:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 19:56:30 --> Form Validation Class Initialized
INFO - 2022-03-18 19:56:30 --> Controller Class Initialized
INFO - 2022-03-18 19:56:30 --> Model "M_todo_list" initialized
INFO - 2022-03-18 19:56:30 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 19:56:30 --> Model "M_todo_group" initialized
INFO - 2022-03-18 19:56:30 --> Model "M_todo_task" initialized
INFO - 2022-03-18 19:56:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 19:56:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 19:56:30 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 19:56:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 19:56:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 19:56:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 19:56:30 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 19:56:30 --> Final output sent to browser
INFO - 2022-03-18 19:57:39 --> Config Class Initialized
INFO - 2022-03-18 19:57:39 --> Hooks Class Initialized
INFO - 2022-03-18 19:57:40 --> Utf8 Class Initialized
INFO - 2022-03-18 19:57:40 --> URI Class Initialized
INFO - 2022-03-18 19:57:40 --> Router Class Initialized
INFO - 2022-03-18 19:57:40 --> Output Class Initialized
INFO - 2022-03-18 19:57:40 --> Security Class Initialized
INFO - 2022-03-18 19:57:40 --> Input Class Initialized
INFO - 2022-03-18 19:57:40 --> Language Class Initialized
INFO - 2022-03-18 19:57:40 --> Loader Class Initialized
INFO - 2022-03-18 19:57:40 --> Helper loaded: url_helper
INFO - 2022-03-18 19:57:40 --> Helper loaded: form_helper
INFO - 2022-03-18 19:57:40 --> Database Driver Class Initialized
INFO - 2022-03-18 19:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 19:57:40 --> Form Validation Class Initialized
INFO - 2022-03-18 19:57:40 --> Controller Class Initialized
INFO - 2022-03-18 19:57:40 --> Model "M_todo_list" initialized
INFO - 2022-03-18 19:57:40 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 19:57:40 --> Model "M_todo_group" initialized
INFO - 2022-03-18 19:57:40 --> Model "M_todo_task" initialized
INFO - 2022-03-18 19:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 19:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 19:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 19:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 19:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 19:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 19:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 19:57:40 --> Final output sent to browser
INFO - 2022-03-18 19:57:59 --> Config Class Initialized
INFO - 2022-03-18 19:57:59 --> Hooks Class Initialized
INFO - 2022-03-18 19:57:59 --> Utf8 Class Initialized
INFO - 2022-03-18 19:57:59 --> URI Class Initialized
INFO - 2022-03-18 19:57:59 --> Router Class Initialized
INFO - 2022-03-18 19:57:59 --> Output Class Initialized
INFO - 2022-03-18 19:57:59 --> Security Class Initialized
INFO - 2022-03-18 19:57:59 --> Input Class Initialized
INFO - 2022-03-18 19:57:59 --> Language Class Initialized
INFO - 2022-03-18 19:57:59 --> Loader Class Initialized
INFO - 2022-03-18 19:57:59 --> Helper loaded: url_helper
INFO - 2022-03-18 19:57:59 --> Helper loaded: form_helper
INFO - 2022-03-18 19:57:59 --> Database Driver Class Initialized
INFO - 2022-03-18 19:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 19:57:59 --> Form Validation Class Initialized
INFO - 2022-03-18 19:57:59 --> Controller Class Initialized
INFO - 2022-03-18 19:57:59 --> Model "M_todo_list" initialized
INFO - 2022-03-18 19:57:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 19:57:59 --> Model "M_todo_group" initialized
INFO - 2022-03-18 19:57:59 --> Model "M_todo_task" initialized
INFO - 2022-03-18 19:57:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 19:57:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 19:57:59 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 19:57:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 19:57:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 19:57:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 19:57:59 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 19:57:59 --> Final output sent to browser
INFO - 2022-03-18 19:59:09 --> Config Class Initialized
INFO - 2022-03-18 19:59:09 --> Hooks Class Initialized
INFO - 2022-03-18 19:59:09 --> Utf8 Class Initialized
INFO - 2022-03-18 19:59:09 --> URI Class Initialized
INFO - 2022-03-18 19:59:09 --> Router Class Initialized
INFO - 2022-03-18 19:59:09 --> Output Class Initialized
INFO - 2022-03-18 19:59:09 --> Security Class Initialized
INFO - 2022-03-18 19:59:09 --> Input Class Initialized
INFO - 2022-03-18 19:59:09 --> Language Class Initialized
INFO - 2022-03-18 19:59:09 --> Loader Class Initialized
INFO - 2022-03-18 19:59:09 --> Helper loaded: url_helper
INFO - 2022-03-18 19:59:09 --> Helper loaded: form_helper
INFO - 2022-03-18 19:59:09 --> Database Driver Class Initialized
INFO - 2022-03-18 19:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 19:59:09 --> Form Validation Class Initialized
INFO - 2022-03-18 19:59:09 --> Controller Class Initialized
INFO - 2022-03-18 19:59:09 --> Model "M_todo_list" initialized
INFO - 2022-03-18 19:59:09 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 19:59:09 --> Model "M_todo_group" initialized
INFO - 2022-03-18 19:59:09 --> Model "M_todo_task" initialized
INFO - 2022-03-18 19:59:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 19:59:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 19:59:09 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 19:59:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 19:59:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 19:59:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 19:59:09 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 19:59:09 --> Final output sent to browser
INFO - 2022-03-18 19:59:15 --> Config Class Initialized
INFO - 2022-03-18 19:59:15 --> Hooks Class Initialized
INFO - 2022-03-18 19:59:15 --> Utf8 Class Initialized
INFO - 2022-03-18 19:59:15 --> URI Class Initialized
INFO - 2022-03-18 19:59:15 --> Router Class Initialized
INFO - 2022-03-18 19:59:15 --> Output Class Initialized
INFO - 2022-03-18 19:59:15 --> Security Class Initialized
INFO - 2022-03-18 19:59:15 --> Input Class Initialized
INFO - 2022-03-18 19:59:15 --> Language Class Initialized
INFO - 2022-03-18 19:59:15 --> Loader Class Initialized
INFO - 2022-03-18 19:59:15 --> Helper loaded: url_helper
INFO - 2022-03-18 19:59:15 --> Helper loaded: form_helper
INFO - 2022-03-18 19:59:15 --> Database Driver Class Initialized
INFO - 2022-03-18 19:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 19:59:15 --> Form Validation Class Initialized
INFO - 2022-03-18 19:59:15 --> Controller Class Initialized
INFO - 2022-03-18 19:59:15 --> Model "M_todo_list" initialized
INFO - 2022-03-18 19:59:15 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 19:59:15 --> Model "M_todo_group" initialized
INFO - 2022-03-18 19:59:15 --> Model "M_todo_task" initialized
INFO - 2022-03-18 19:59:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 19:59:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 19:59:15 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 19:59:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 19:59:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 19:59:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 19:59:15 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 19:59:15 --> Final output sent to browser
INFO - 2022-03-18 20:01:33 --> Config Class Initialized
INFO - 2022-03-18 20:01:33 --> Hooks Class Initialized
INFO - 2022-03-18 20:01:33 --> Utf8 Class Initialized
INFO - 2022-03-18 20:01:33 --> URI Class Initialized
INFO - 2022-03-18 20:01:33 --> Router Class Initialized
INFO - 2022-03-18 20:01:33 --> Output Class Initialized
INFO - 2022-03-18 20:01:33 --> Security Class Initialized
INFO - 2022-03-18 20:01:33 --> Input Class Initialized
INFO - 2022-03-18 20:01:33 --> Language Class Initialized
INFO - 2022-03-18 20:01:33 --> Loader Class Initialized
INFO - 2022-03-18 20:01:33 --> Helper loaded: url_helper
INFO - 2022-03-18 20:01:33 --> Helper loaded: form_helper
INFO - 2022-03-18 20:01:33 --> Database Driver Class Initialized
INFO - 2022-03-18 20:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:01:33 --> Form Validation Class Initialized
INFO - 2022-03-18 20:01:33 --> Controller Class Initialized
INFO - 2022-03-18 20:01:33 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:01:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:01:33 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:01:33 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:01:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:01:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:01:33 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:01:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:01:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:01:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:01:33 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:01:33 --> Final output sent to browser
INFO - 2022-03-18 20:03:04 --> Config Class Initialized
INFO - 2022-03-18 20:03:04 --> Hooks Class Initialized
INFO - 2022-03-18 20:03:04 --> Utf8 Class Initialized
INFO - 2022-03-18 20:03:04 --> URI Class Initialized
INFO - 2022-03-18 20:03:04 --> Router Class Initialized
INFO - 2022-03-18 20:03:04 --> Output Class Initialized
INFO - 2022-03-18 20:03:04 --> Security Class Initialized
INFO - 2022-03-18 20:03:04 --> Input Class Initialized
INFO - 2022-03-18 20:03:04 --> Language Class Initialized
INFO - 2022-03-18 20:03:04 --> Loader Class Initialized
INFO - 2022-03-18 20:03:04 --> Helper loaded: url_helper
INFO - 2022-03-18 20:03:04 --> Helper loaded: form_helper
INFO - 2022-03-18 20:03:04 --> Database Driver Class Initialized
INFO - 2022-03-18 20:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:03:04 --> Form Validation Class Initialized
INFO - 2022-03-18 20:03:04 --> Controller Class Initialized
INFO - 2022-03-18 20:03:04 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:03:04 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:03:04 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:03:04 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:03:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:03:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:03:04 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:03:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:03:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:03:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:03:04 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:03:04 --> Final output sent to browser
INFO - 2022-03-18 20:04:13 --> Config Class Initialized
INFO - 2022-03-18 20:04:13 --> Hooks Class Initialized
INFO - 2022-03-18 20:04:13 --> Utf8 Class Initialized
INFO - 2022-03-18 20:04:13 --> URI Class Initialized
INFO - 2022-03-18 20:04:13 --> Router Class Initialized
INFO - 2022-03-18 20:04:13 --> Output Class Initialized
INFO - 2022-03-18 20:04:13 --> Security Class Initialized
INFO - 2022-03-18 20:04:13 --> Input Class Initialized
INFO - 2022-03-18 20:04:13 --> Language Class Initialized
INFO - 2022-03-18 20:04:13 --> Loader Class Initialized
INFO - 2022-03-18 20:04:13 --> Helper loaded: url_helper
INFO - 2022-03-18 20:04:13 --> Helper loaded: form_helper
INFO - 2022-03-18 20:04:13 --> Database Driver Class Initialized
INFO - 2022-03-18 20:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:04:13 --> Form Validation Class Initialized
INFO - 2022-03-18 20:04:13 --> Controller Class Initialized
INFO - 2022-03-18 20:04:13 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:04:13 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:04:13 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:04:14 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:04:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:04:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:04:14 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:04:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:04:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:04:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:04:14 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:04:14 --> Final output sent to browser
INFO - 2022-03-18 20:06:58 --> Config Class Initialized
INFO - 2022-03-18 20:06:58 --> Hooks Class Initialized
INFO - 2022-03-18 20:06:58 --> Utf8 Class Initialized
INFO - 2022-03-18 20:06:58 --> URI Class Initialized
INFO - 2022-03-18 20:06:58 --> Router Class Initialized
INFO - 2022-03-18 20:06:58 --> Output Class Initialized
INFO - 2022-03-18 20:06:58 --> Security Class Initialized
INFO - 2022-03-18 20:06:58 --> Input Class Initialized
INFO - 2022-03-18 20:06:58 --> Language Class Initialized
INFO - 2022-03-18 20:06:58 --> Loader Class Initialized
INFO - 2022-03-18 20:06:58 --> Helper loaded: url_helper
INFO - 2022-03-18 20:06:58 --> Helper loaded: form_helper
INFO - 2022-03-18 20:06:58 --> Database Driver Class Initialized
INFO - 2022-03-18 20:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:06:58 --> Form Validation Class Initialized
INFO - 2022-03-18 20:06:58 --> Controller Class Initialized
INFO - 2022-03-18 20:06:58 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:06:58 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:06:58 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:06:58 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:06:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:06:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:06:58 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:06:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:06:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:06:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:06:58 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:06:59 --> Final output sent to browser
INFO - 2022-03-18 20:07:37 --> Config Class Initialized
INFO - 2022-03-18 20:07:37 --> Hooks Class Initialized
INFO - 2022-03-18 20:07:37 --> Utf8 Class Initialized
INFO - 2022-03-18 20:07:37 --> URI Class Initialized
INFO - 2022-03-18 20:07:37 --> Router Class Initialized
INFO - 2022-03-18 20:07:37 --> Output Class Initialized
INFO - 2022-03-18 20:07:37 --> Security Class Initialized
INFO - 2022-03-18 20:07:37 --> Input Class Initialized
INFO - 2022-03-18 20:07:37 --> Language Class Initialized
INFO - 2022-03-18 20:07:37 --> Loader Class Initialized
INFO - 2022-03-18 20:07:38 --> Helper loaded: url_helper
INFO - 2022-03-18 20:07:38 --> Helper loaded: form_helper
INFO - 2022-03-18 20:07:38 --> Database Driver Class Initialized
INFO - 2022-03-18 20:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:07:38 --> Form Validation Class Initialized
INFO - 2022-03-18 20:07:38 --> Controller Class Initialized
INFO - 2022-03-18 20:07:38 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:07:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:07:38 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:07:38 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:07:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:07:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:07:38 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:07:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:07:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:07:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:07:38 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:07:38 --> Final output sent to browser
INFO - 2022-03-18 20:07:55 --> Config Class Initialized
INFO - 2022-03-18 20:07:55 --> Hooks Class Initialized
INFO - 2022-03-18 20:07:55 --> Utf8 Class Initialized
INFO - 2022-03-18 20:07:55 --> URI Class Initialized
INFO - 2022-03-18 20:07:55 --> Router Class Initialized
INFO - 2022-03-18 20:07:55 --> Output Class Initialized
INFO - 2022-03-18 20:07:55 --> Security Class Initialized
INFO - 2022-03-18 20:07:55 --> Input Class Initialized
INFO - 2022-03-18 20:07:55 --> Language Class Initialized
INFO - 2022-03-18 20:07:55 --> Loader Class Initialized
INFO - 2022-03-18 20:07:55 --> Helper loaded: url_helper
INFO - 2022-03-18 20:07:55 --> Helper loaded: form_helper
INFO - 2022-03-18 20:07:55 --> Database Driver Class Initialized
INFO - 2022-03-18 20:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:07:55 --> Form Validation Class Initialized
INFO - 2022-03-18 20:07:55 --> Controller Class Initialized
INFO - 2022-03-18 20:07:55 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:07:55 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:07:55 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:07:55 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:07:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:07:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:07:55 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:07:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:07:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:07:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:07:55 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:07:55 --> Final output sent to browser
INFO - 2022-03-18 20:07:59 --> Config Class Initialized
INFO - 2022-03-18 20:07:59 --> Hooks Class Initialized
INFO - 2022-03-18 20:07:59 --> Utf8 Class Initialized
INFO - 2022-03-18 20:07:59 --> URI Class Initialized
INFO - 2022-03-18 20:07:59 --> Router Class Initialized
INFO - 2022-03-18 20:07:59 --> Output Class Initialized
INFO - 2022-03-18 20:07:59 --> Security Class Initialized
INFO - 2022-03-18 20:07:59 --> Input Class Initialized
INFO - 2022-03-18 20:07:59 --> Language Class Initialized
INFO - 2022-03-18 20:07:59 --> Loader Class Initialized
INFO - 2022-03-18 20:07:59 --> Helper loaded: url_helper
INFO - 2022-03-18 20:07:59 --> Helper loaded: form_helper
INFO - 2022-03-18 20:08:00 --> Database Driver Class Initialized
INFO - 2022-03-18 20:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:08:00 --> Form Validation Class Initialized
INFO - 2022-03-18 20:08:00 --> Controller Class Initialized
INFO - 2022-03-18 20:08:00 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:08:00 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:08:00 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:08:00 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:08:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:08:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:08:00 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:08:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:08:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:08:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:08:00 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:08:00 --> Final output sent to browser
INFO - 2022-03-18 20:08:14 --> Config Class Initialized
INFO - 2022-03-18 20:08:14 --> Hooks Class Initialized
INFO - 2022-03-18 20:08:14 --> Utf8 Class Initialized
INFO - 2022-03-18 20:08:14 --> URI Class Initialized
INFO - 2022-03-18 20:08:14 --> Router Class Initialized
INFO - 2022-03-18 20:08:14 --> Output Class Initialized
INFO - 2022-03-18 20:08:14 --> Security Class Initialized
INFO - 2022-03-18 20:08:14 --> Input Class Initialized
INFO - 2022-03-18 20:08:14 --> Language Class Initialized
INFO - 2022-03-18 20:08:14 --> Loader Class Initialized
INFO - 2022-03-18 20:08:14 --> Helper loaded: url_helper
INFO - 2022-03-18 20:08:14 --> Helper loaded: form_helper
INFO - 2022-03-18 20:08:14 --> Database Driver Class Initialized
INFO - 2022-03-18 20:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:08:14 --> Form Validation Class Initialized
INFO - 2022-03-18 20:08:14 --> Controller Class Initialized
INFO - 2022-03-18 20:08:14 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:08:14 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:08:14 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:08:14 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:08:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:08:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:08:14 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:08:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:08:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:08:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:08:14 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:08:14 --> Final output sent to browser
INFO - 2022-03-18 20:08:17 --> Config Class Initialized
INFO - 2022-03-18 20:08:17 --> Hooks Class Initialized
INFO - 2022-03-18 20:08:17 --> Utf8 Class Initialized
INFO - 2022-03-18 20:08:17 --> URI Class Initialized
INFO - 2022-03-18 20:08:17 --> Router Class Initialized
INFO - 2022-03-18 20:08:17 --> Output Class Initialized
INFO - 2022-03-18 20:08:17 --> Security Class Initialized
INFO - 2022-03-18 20:08:17 --> Input Class Initialized
INFO - 2022-03-18 20:08:17 --> Language Class Initialized
INFO - 2022-03-18 20:08:17 --> Loader Class Initialized
INFO - 2022-03-18 20:08:17 --> Helper loaded: url_helper
INFO - 2022-03-18 20:08:17 --> Helper loaded: form_helper
INFO - 2022-03-18 20:08:17 --> Database Driver Class Initialized
INFO - 2022-03-18 20:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:08:17 --> Form Validation Class Initialized
INFO - 2022-03-18 20:08:17 --> Controller Class Initialized
INFO - 2022-03-18 20:08:17 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:08:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:08:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:08:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:08:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:08:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:08:17 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-18 20:08:17 --> Final output sent to browser
INFO - 2022-03-18 20:08:20 --> Config Class Initialized
INFO - 2022-03-18 20:08:20 --> Hooks Class Initialized
INFO - 2022-03-18 20:08:20 --> Config Class Initialized
INFO - 2022-03-18 20:08:20 --> Hooks Class Initialized
INFO - 2022-03-18 20:08:20 --> Utf8 Class Initialized
INFO - 2022-03-18 20:08:20 --> URI Class Initialized
INFO - 2022-03-18 20:08:20 --> Router Class Initialized
INFO - 2022-03-18 20:08:20 --> Output Class Initialized
INFO - 2022-03-18 20:08:20 --> Utf8 Class Initialized
INFO - 2022-03-18 20:08:20 --> Security Class Initialized
INFO - 2022-03-18 20:08:20 --> Input Class Initialized
INFO - 2022-03-18 20:08:20 --> URI Class Initialized
INFO - 2022-03-18 20:08:20 --> Language Class Initialized
INFO - 2022-03-18 20:08:20 --> Router Class Initialized
ERROR - 2022-03-18 20:08:20 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-18 20:08:20 --> Output Class Initialized
INFO - 2022-03-18 20:08:20 --> Security Class Initialized
INFO - 2022-03-18 20:08:20 --> Input Class Initialized
INFO - 2022-03-18 20:08:20 --> Language Class Initialized
ERROR - 2022-03-18 20:08:20 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-18 20:08:22 --> Config Class Initialized
INFO - 2022-03-18 20:08:22 --> Hooks Class Initialized
INFO - 2022-03-18 20:08:22 --> Utf8 Class Initialized
INFO - 2022-03-18 20:08:22 --> URI Class Initialized
INFO - 2022-03-18 20:08:22 --> Router Class Initialized
INFO - 2022-03-18 20:08:22 --> Output Class Initialized
INFO - 2022-03-18 20:08:22 --> Security Class Initialized
INFO - 2022-03-18 20:08:22 --> Input Class Initialized
INFO - 2022-03-18 20:08:22 --> Language Class Initialized
INFO - 2022-03-18 20:08:22 --> Loader Class Initialized
INFO - 2022-03-18 20:08:22 --> Helper loaded: url_helper
INFO - 2022-03-18 20:08:22 --> Helper loaded: form_helper
INFO - 2022-03-18 20:08:22 --> Database Driver Class Initialized
INFO - 2022-03-18 20:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:08:22 --> Form Validation Class Initialized
INFO - 2022-03-18 20:08:22 --> Controller Class Initialized
INFO - 2022-03-18 20:08:22 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:08:22 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:08:22 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:08:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:08:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:08:22 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:08:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:08:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:08:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:08:22 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:08:22 --> Final output sent to browser
INFO - 2022-03-18 20:08:28 --> Config Class Initialized
INFO - 2022-03-18 20:08:28 --> Hooks Class Initialized
INFO - 2022-03-18 20:08:28 --> Utf8 Class Initialized
INFO - 2022-03-18 20:08:28 --> URI Class Initialized
INFO - 2022-03-18 20:08:28 --> Router Class Initialized
INFO - 2022-03-18 20:08:28 --> Output Class Initialized
INFO - 2022-03-18 20:08:28 --> Security Class Initialized
INFO - 2022-03-18 20:08:28 --> Input Class Initialized
INFO - 2022-03-18 20:08:28 --> Language Class Initialized
INFO - 2022-03-18 20:08:28 --> Loader Class Initialized
INFO - 2022-03-18 20:08:28 --> Helper loaded: url_helper
INFO - 2022-03-18 20:08:28 --> Helper loaded: form_helper
INFO - 2022-03-18 20:08:28 --> Database Driver Class Initialized
INFO - 2022-03-18 20:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:08:28 --> Form Validation Class Initialized
INFO - 2022-03-18 20:08:28 --> Controller Class Initialized
INFO - 2022-03-18 20:08:28 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:08:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:08:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:08:28 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:08:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:08:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:08:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:08:28 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:08:28 --> Final output sent to browser
INFO - 2022-03-18 20:08:36 --> Config Class Initialized
INFO - 2022-03-18 20:08:36 --> Hooks Class Initialized
INFO - 2022-03-18 20:08:36 --> Utf8 Class Initialized
INFO - 2022-03-18 20:08:36 --> URI Class Initialized
INFO - 2022-03-18 20:08:36 --> Router Class Initialized
INFO - 2022-03-18 20:08:36 --> Output Class Initialized
INFO - 2022-03-18 20:08:36 --> Security Class Initialized
INFO - 2022-03-18 20:08:36 --> Input Class Initialized
INFO - 2022-03-18 20:08:36 --> Language Class Initialized
INFO - 2022-03-18 20:08:36 --> Loader Class Initialized
INFO - 2022-03-18 20:08:36 --> Helper loaded: url_helper
INFO - 2022-03-18 20:08:36 --> Helper loaded: form_helper
INFO - 2022-03-18 20:08:37 --> Database Driver Class Initialized
INFO - 2022-03-18 20:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:08:37 --> Form Validation Class Initialized
INFO - 2022-03-18 20:08:37 --> Controller Class Initialized
INFO - 2022-03-18 20:08:37 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:08:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:08:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:08:37 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:08:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:08:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:08:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:08:37 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:08:37 --> Final output sent to browser
INFO - 2022-03-18 20:09:11 --> Config Class Initialized
INFO - 2022-03-18 20:09:11 --> Hooks Class Initialized
INFO - 2022-03-18 20:09:11 --> Utf8 Class Initialized
INFO - 2022-03-18 20:09:11 --> URI Class Initialized
INFO - 2022-03-18 20:09:11 --> Router Class Initialized
INFO - 2022-03-18 20:09:11 --> Output Class Initialized
INFO - 2022-03-18 20:09:11 --> Security Class Initialized
INFO - 2022-03-18 20:09:11 --> Input Class Initialized
INFO - 2022-03-18 20:09:11 --> Language Class Initialized
INFO - 2022-03-18 20:09:11 --> Loader Class Initialized
INFO - 2022-03-18 20:09:11 --> Helper loaded: url_helper
INFO - 2022-03-18 20:09:11 --> Helper loaded: form_helper
INFO - 2022-03-18 20:09:11 --> Database Driver Class Initialized
INFO - 2022-03-18 20:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:09:11 --> Form Validation Class Initialized
INFO - 2022-03-18 20:09:11 --> Controller Class Initialized
INFO - 2022-03-18 20:09:11 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:09:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:09:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:09:11 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:09:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:09:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:09:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:09:11 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:09:11 --> Final output sent to browser
INFO - 2022-03-18 20:09:24 --> Config Class Initialized
INFO - 2022-03-18 20:09:24 --> Hooks Class Initialized
INFO - 2022-03-18 20:09:24 --> Utf8 Class Initialized
INFO - 2022-03-18 20:09:24 --> URI Class Initialized
INFO - 2022-03-18 20:09:24 --> Router Class Initialized
INFO - 2022-03-18 20:09:24 --> Output Class Initialized
INFO - 2022-03-18 20:09:24 --> Security Class Initialized
INFO - 2022-03-18 20:09:24 --> Input Class Initialized
INFO - 2022-03-18 20:09:24 --> Language Class Initialized
INFO - 2022-03-18 20:09:24 --> Loader Class Initialized
INFO - 2022-03-18 20:09:24 --> Helper loaded: url_helper
INFO - 2022-03-18 20:09:24 --> Helper loaded: form_helper
INFO - 2022-03-18 20:09:24 --> Database Driver Class Initialized
INFO - 2022-03-18 20:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:09:24 --> Form Validation Class Initialized
INFO - 2022-03-18 20:09:24 --> Controller Class Initialized
INFO - 2022-03-18 20:09:24 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:09:24 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:09:25 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:09:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:09:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:09:25 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:09:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:09:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:09:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:09:25 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:09:25 --> Final output sent to browser
INFO - 2022-03-18 20:09:27 --> Config Class Initialized
INFO - 2022-03-18 20:09:27 --> Hooks Class Initialized
INFO - 2022-03-18 20:09:27 --> Utf8 Class Initialized
INFO - 2022-03-18 20:09:27 --> URI Class Initialized
INFO - 2022-03-18 20:09:27 --> Router Class Initialized
INFO - 2022-03-18 20:09:27 --> Output Class Initialized
INFO - 2022-03-18 20:09:27 --> Security Class Initialized
INFO - 2022-03-18 20:09:27 --> Input Class Initialized
INFO - 2022-03-18 20:09:27 --> Language Class Initialized
INFO - 2022-03-18 20:09:27 --> Loader Class Initialized
INFO - 2022-03-18 20:09:27 --> Helper loaded: url_helper
INFO - 2022-03-18 20:09:27 --> Helper loaded: form_helper
INFO - 2022-03-18 20:09:27 --> Database Driver Class Initialized
INFO - 2022-03-18 20:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:09:28 --> Form Validation Class Initialized
INFO - 2022-03-18 20:09:28 --> Controller Class Initialized
INFO - 2022-03-18 20:09:28 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:09:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:09:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:09:28 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:09:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:09:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:09:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:09:28 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:09:28 --> Final output sent to browser
INFO - 2022-03-18 20:09:37 --> Config Class Initialized
INFO - 2022-03-18 20:09:37 --> Hooks Class Initialized
INFO - 2022-03-18 20:09:37 --> Utf8 Class Initialized
INFO - 2022-03-18 20:09:37 --> URI Class Initialized
INFO - 2022-03-18 20:09:38 --> Router Class Initialized
INFO - 2022-03-18 20:09:38 --> Output Class Initialized
INFO - 2022-03-18 20:09:38 --> Security Class Initialized
INFO - 2022-03-18 20:09:38 --> Input Class Initialized
INFO - 2022-03-18 20:09:38 --> Language Class Initialized
INFO - 2022-03-18 20:09:38 --> Loader Class Initialized
INFO - 2022-03-18 20:09:38 --> Helper loaded: url_helper
INFO - 2022-03-18 20:09:38 --> Helper loaded: form_helper
INFO - 2022-03-18 20:09:38 --> Database Driver Class Initialized
INFO - 2022-03-18 20:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:09:38 --> Form Validation Class Initialized
INFO - 2022-03-18 20:09:38 --> Controller Class Initialized
INFO - 2022-03-18 20:09:38 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:09:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:09:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:09:38 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:09:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:09:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:09:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:09:38 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:09:38 --> Final output sent to browser
INFO - 2022-03-18 20:09:51 --> Config Class Initialized
INFO - 2022-03-18 20:09:51 --> Hooks Class Initialized
INFO - 2022-03-18 20:09:51 --> Utf8 Class Initialized
INFO - 2022-03-18 20:09:51 --> URI Class Initialized
INFO - 2022-03-18 20:09:51 --> Router Class Initialized
INFO - 2022-03-18 20:09:51 --> Output Class Initialized
INFO - 2022-03-18 20:09:51 --> Security Class Initialized
INFO - 2022-03-18 20:09:51 --> Input Class Initialized
INFO - 2022-03-18 20:09:51 --> Language Class Initialized
INFO - 2022-03-18 20:09:51 --> Loader Class Initialized
INFO - 2022-03-18 20:09:51 --> Helper loaded: url_helper
INFO - 2022-03-18 20:09:51 --> Helper loaded: form_helper
INFO - 2022-03-18 20:09:51 --> Database Driver Class Initialized
INFO - 2022-03-18 20:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:09:51 --> Form Validation Class Initialized
INFO - 2022-03-18 20:09:51 --> Controller Class Initialized
INFO - 2022-03-18 20:09:51 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:09:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:09:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:09:51 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:09:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:09:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:09:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:09:51 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:09:51 --> Final output sent to browser
INFO - 2022-03-18 20:10:20 --> Config Class Initialized
INFO - 2022-03-18 20:10:20 --> Hooks Class Initialized
INFO - 2022-03-18 20:10:20 --> Utf8 Class Initialized
INFO - 2022-03-18 20:10:20 --> URI Class Initialized
INFO - 2022-03-18 20:10:20 --> Router Class Initialized
INFO - 2022-03-18 20:10:20 --> Output Class Initialized
INFO - 2022-03-18 20:10:20 --> Security Class Initialized
INFO - 2022-03-18 20:10:20 --> Input Class Initialized
INFO - 2022-03-18 20:10:20 --> Language Class Initialized
INFO - 2022-03-18 20:10:20 --> Loader Class Initialized
INFO - 2022-03-18 20:10:20 --> Helper loaded: url_helper
INFO - 2022-03-18 20:10:20 --> Helper loaded: form_helper
INFO - 2022-03-18 20:10:20 --> Database Driver Class Initialized
INFO - 2022-03-18 20:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:10:20 --> Form Validation Class Initialized
INFO - 2022-03-18 20:10:20 --> Controller Class Initialized
INFO - 2022-03-18 20:10:20 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:10:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:10:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:10:20 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:10:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:10:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:10:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:10:20 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:10:20 --> Final output sent to browser
INFO - 2022-03-18 20:10:56 --> Config Class Initialized
INFO - 2022-03-18 20:10:56 --> Hooks Class Initialized
INFO - 2022-03-18 20:10:56 --> Utf8 Class Initialized
INFO - 2022-03-18 20:10:56 --> URI Class Initialized
INFO - 2022-03-18 20:10:56 --> Router Class Initialized
INFO - 2022-03-18 20:10:56 --> Output Class Initialized
INFO - 2022-03-18 20:10:56 --> Security Class Initialized
INFO - 2022-03-18 20:10:56 --> Input Class Initialized
INFO - 2022-03-18 20:10:56 --> Language Class Initialized
INFO - 2022-03-18 20:10:56 --> Loader Class Initialized
INFO - 2022-03-18 20:10:56 --> Helper loaded: url_helper
INFO - 2022-03-18 20:10:56 --> Helper loaded: form_helper
INFO - 2022-03-18 20:10:56 --> Database Driver Class Initialized
INFO - 2022-03-18 20:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:10:56 --> Form Validation Class Initialized
INFO - 2022-03-18 20:10:56 --> Controller Class Initialized
INFO - 2022-03-18 20:10:56 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:10:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:10:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:10:56 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:10:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:10:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:10:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:10:56 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:10:56 --> Final output sent to browser
INFO - 2022-03-18 20:11:12 --> Config Class Initialized
INFO - 2022-03-18 20:11:12 --> Hooks Class Initialized
INFO - 2022-03-18 20:11:12 --> Utf8 Class Initialized
INFO - 2022-03-18 20:11:12 --> URI Class Initialized
INFO - 2022-03-18 20:11:12 --> Router Class Initialized
INFO - 2022-03-18 20:11:12 --> Output Class Initialized
INFO - 2022-03-18 20:11:12 --> Security Class Initialized
INFO - 2022-03-18 20:11:12 --> Input Class Initialized
INFO - 2022-03-18 20:11:12 --> Language Class Initialized
INFO - 2022-03-18 20:11:12 --> Loader Class Initialized
INFO - 2022-03-18 20:11:12 --> Helper loaded: url_helper
INFO - 2022-03-18 20:11:12 --> Helper loaded: form_helper
INFO - 2022-03-18 20:11:12 --> Database Driver Class Initialized
INFO - 2022-03-18 20:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:11:12 --> Form Validation Class Initialized
INFO - 2022-03-18 20:11:12 --> Controller Class Initialized
INFO - 2022-03-18 20:11:12 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:11:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:11:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:11:12 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:11:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:11:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:11:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:11:12 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:11:12 --> Final output sent to browser
INFO - 2022-03-18 20:11:15 --> Config Class Initialized
INFO - 2022-03-18 20:11:15 --> Hooks Class Initialized
INFO - 2022-03-18 20:11:15 --> Utf8 Class Initialized
INFO - 2022-03-18 20:11:15 --> URI Class Initialized
INFO - 2022-03-18 20:11:15 --> Router Class Initialized
INFO - 2022-03-18 20:11:15 --> Output Class Initialized
INFO - 2022-03-18 20:11:15 --> Security Class Initialized
INFO - 2022-03-18 20:11:15 --> Input Class Initialized
INFO - 2022-03-18 20:11:15 --> Language Class Initialized
INFO - 2022-03-18 20:11:15 --> Loader Class Initialized
INFO - 2022-03-18 20:11:15 --> Helper loaded: url_helper
INFO - 2022-03-18 20:11:15 --> Helper loaded: form_helper
INFO - 2022-03-18 20:11:15 --> Database Driver Class Initialized
INFO - 2022-03-18 20:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:11:15 --> Form Validation Class Initialized
INFO - 2022-03-18 20:11:15 --> Controller Class Initialized
INFO - 2022-03-18 20:11:15 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:11:15 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:11:15 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:11:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:11:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:11:15 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:11:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:11:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:11:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:11:15 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:11:15 --> Final output sent to browser
INFO - 2022-03-18 20:12:20 --> Config Class Initialized
INFO - 2022-03-18 20:12:20 --> Hooks Class Initialized
INFO - 2022-03-18 20:12:20 --> Utf8 Class Initialized
INFO - 2022-03-18 20:12:20 --> URI Class Initialized
INFO - 2022-03-18 20:12:20 --> Router Class Initialized
INFO - 2022-03-18 20:12:20 --> Output Class Initialized
INFO - 2022-03-18 20:12:20 --> Security Class Initialized
INFO - 2022-03-18 20:12:20 --> Input Class Initialized
INFO - 2022-03-18 20:12:20 --> Language Class Initialized
INFO - 2022-03-18 20:12:20 --> Loader Class Initialized
INFO - 2022-03-18 20:12:20 --> Helper loaded: url_helper
INFO - 2022-03-18 20:12:20 --> Helper loaded: form_helper
INFO - 2022-03-18 20:12:20 --> Database Driver Class Initialized
INFO - 2022-03-18 20:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:12:20 --> Form Validation Class Initialized
INFO - 2022-03-18 20:12:20 --> Controller Class Initialized
INFO - 2022-03-18 20:12:20 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:12:20 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-18 20:12:20 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-18 20:12:20 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-18 20:12:20 --> Final output sent to browser
INFO - 2022-03-18 20:12:29 --> Config Class Initialized
INFO - 2022-03-18 20:12:29 --> Hooks Class Initialized
INFO - 2022-03-18 20:12:29 --> Utf8 Class Initialized
INFO - 2022-03-18 20:12:29 --> URI Class Initialized
INFO - 2022-03-18 20:12:29 --> Router Class Initialized
INFO - 2022-03-18 20:12:29 --> Output Class Initialized
INFO - 2022-03-18 20:12:29 --> Security Class Initialized
INFO - 2022-03-18 20:12:29 --> Input Class Initialized
INFO - 2022-03-18 20:12:29 --> Language Class Initialized
INFO - 2022-03-18 20:12:29 --> Loader Class Initialized
INFO - 2022-03-18 20:12:29 --> Helper loaded: url_helper
INFO - 2022-03-18 20:12:29 --> Helper loaded: form_helper
INFO - 2022-03-18 20:12:29 --> Database Driver Class Initialized
INFO - 2022-03-18 20:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:12:29 --> Form Validation Class Initialized
INFO - 2022-03-18 20:12:29 --> Controller Class Initialized
INFO - 2022-03-18 20:12:29 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:12:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:12:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:12:29 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:12:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:12:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:12:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:12:29 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:12:29 --> Final output sent to browser
INFO - 2022-03-18 20:13:27 --> Config Class Initialized
INFO - 2022-03-18 20:13:27 --> Hooks Class Initialized
INFO - 2022-03-18 20:13:27 --> Utf8 Class Initialized
INFO - 2022-03-18 20:13:27 --> URI Class Initialized
INFO - 2022-03-18 20:13:27 --> Router Class Initialized
INFO - 2022-03-18 20:13:27 --> Output Class Initialized
INFO - 2022-03-18 20:13:27 --> Security Class Initialized
INFO - 2022-03-18 20:13:27 --> Input Class Initialized
INFO - 2022-03-18 20:13:27 --> Language Class Initialized
INFO - 2022-03-18 20:13:27 --> Loader Class Initialized
INFO - 2022-03-18 20:13:27 --> Helper loaded: url_helper
INFO - 2022-03-18 20:13:27 --> Helper loaded: form_helper
INFO - 2022-03-18 20:13:27 --> Database Driver Class Initialized
INFO - 2022-03-18 20:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:13:27 --> Form Validation Class Initialized
INFO - 2022-03-18 20:13:27 --> Controller Class Initialized
INFO - 2022-03-18 20:13:27 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:13:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:13:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:13:27 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:13:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:13:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:13:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:13:27 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:13:27 --> Final output sent to browser
INFO - 2022-03-18 20:13:36 --> Config Class Initialized
INFO - 2022-03-18 20:13:36 --> Hooks Class Initialized
INFO - 2022-03-18 20:13:36 --> Utf8 Class Initialized
INFO - 2022-03-18 20:13:36 --> URI Class Initialized
INFO - 2022-03-18 20:13:36 --> Router Class Initialized
INFO - 2022-03-18 20:13:36 --> Output Class Initialized
INFO - 2022-03-18 20:13:36 --> Security Class Initialized
INFO - 2022-03-18 20:13:36 --> Input Class Initialized
INFO - 2022-03-18 20:13:36 --> Language Class Initialized
INFO - 2022-03-18 20:13:36 --> Loader Class Initialized
INFO - 2022-03-18 20:13:36 --> Helper loaded: url_helper
INFO - 2022-03-18 20:13:36 --> Helper loaded: form_helper
INFO - 2022-03-18 20:13:37 --> Database Driver Class Initialized
INFO - 2022-03-18 20:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:13:37 --> Form Validation Class Initialized
INFO - 2022-03-18 20:13:37 --> Controller Class Initialized
INFO - 2022-03-18 20:13:37 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:13:37 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:13:37 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:13:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:13:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:13:37 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:13:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:13:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:13:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:13:37 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:13:37 --> Final output sent to browser
INFO - 2022-03-18 20:13:47 --> Config Class Initialized
INFO - 2022-03-18 20:13:47 --> Hooks Class Initialized
INFO - 2022-03-18 20:13:47 --> Utf8 Class Initialized
INFO - 2022-03-18 20:13:47 --> URI Class Initialized
INFO - 2022-03-18 20:13:47 --> Router Class Initialized
INFO - 2022-03-18 20:13:47 --> Output Class Initialized
INFO - 2022-03-18 20:13:47 --> Security Class Initialized
INFO - 2022-03-18 20:13:47 --> Input Class Initialized
INFO - 2022-03-18 20:13:47 --> Language Class Initialized
INFO - 2022-03-18 20:13:47 --> Loader Class Initialized
INFO - 2022-03-18 20:13:47 --> Helper loaded: url_helper
INFO - 2022-03-18 20:13:47 --> Helper loaded: form_helper
INFO - 2022-03-18 20:13:47 --> Database Driver Class Initialized
INFO - 2022-03-18 20:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:13:47 --> Form Validation Class Initialized
INFO - 2022-03-18 20:13:47 --> Controller Class Initialized
INFO - 2022-03-18 20:13:47 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:13:47 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:13:47 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:13:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:13:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:13:47 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:13:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:13:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:13:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:13:47 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:13:47 --> Final output sent to browser
INFO - 2022-03-18 20:14:28 --> Config Class Initialized
INFO - 2022-03-18 20:14:28 --> Hooks Class Initialized
INFO - 2022-03-18 20:14:28 --> Utf8 Class Initialized
INFO - 2022-03-18 20:14:28 --> URI Class Initialized
INFO - 2022-03-18 20:14:28 --> Router Class Initialized
INFO - 2022-03-18 20:14:28 --> Output Class Initialized
INFO - 2022-03-18 20:14:28 --> Security Class Initialized
INFO - 2022-03-18 20:14:28 --> Input Class Initialized
INFO - 2022-03-18 20:14:28 --> Language Class Initialized
INFO - 2022-03-18 20:14:28 --> Loader Class Initialized
INFO - 2022-03-18 20:14:28 --> Helper loaded: url_helper
INFO - 2022-03-18 20:14:28 --> Helper loaded: form_helper
INFO - 2022-03-18 20:14:28 --> Database Driver Class Initialized
INFO - 2022-03-18 20:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:14:28 --> Form Validation Class Initialized
INFO - 2022-03-18 20:14:28 --> Controller Class Initialized
INFO - 2022-03-18 20:14:28 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:14:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:14:28 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:14:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:14:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:14:28 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:14:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:14:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:14:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:14:28 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:14:28 --> Final output sent to browser
INFO - 2022-03-18 20:14:45 --> Config Class Initialized
INFO - 2022-03-18 20:14:45 --> Hooks Class Initialized
INFO - 2022-03-18 20:14:45 --> Utf8 Class Initialized
INFO - 2022-03-18 20:14:45 --> URI Class Initialized
INFO - 2022-03-18 20:14:46 --> Router Class Initialized
INFO - 2022-03-18 20:14:46 --> Output Class Initialized
INFO - 2022-03-18 20:14:46 --> Security Class Initialized
INFO - 2022-03-18 20:14:46 --> Input Class Initialized
INFO - 2022-03-18 20:14:46 --> Language Class Initialized
INFO - 2022-03-18 20:14:46 --> Loader Class Initialized
INFO - 2022-03-18 20:14:46 --> Helper loaded: url_helper
INFO - 2022-03-18 20:14:46 --> Helper loaded: form_helper
INFO - 2022-03-18 20:14:46 --> Database Driver Class Initialized
INFO - 2022-03-18 20:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:14:46 --> Form Validation Class Initialized
INFO - 2022-03-18 20:14:46 --> Controller Class Initialized
INFO - 2022-03-18 20:14:46 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:14:46 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:14:46 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:14:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:14:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:14:46 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:14:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:14:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:14:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:14:46 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:14:46 --> Final output sent to browser
INFO - 2022-03-18 20:16:11 --> Config Class Initialized
INFO - 2022-03-18 20:16:11 --> Hooks Class Initialized
INFO - 2022-03-18 20:16:11 --> Utf8 Class Initialized
INFO - 2022-03-18 20:16:11 --> URI Class Initialized
INFO - 2022-03-18 20:16:11 --> Router Class Initialized
INFO - 2022-03-18 20:16:11 --> Output Class Initialized
INFO - 2022-03-18 20:16:11 --> Security Class Initialized
INFO - 2022-03-18 20:16:11 --> Input Class Initialized
INFO - 2022-03-18 20:16:11 --> Language Class Initialized
INFO - 2022-03-18 20:16:11 --> Loader Class Initialized
INFO - 2022-03-18 20:16:11 --> Helper loaded: url_helper
INFO - 2022-03-18 20:16:11 --> Helper loaded: form_helper
INFO - 2022-03-18 20:16:11 --> Database Driver Class Initialized
INFO - 2022-03-18 20:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:16:11 --> Form Validation Class Initialized
INFO - 2022-03-18 20:16:11 --> Controller Class Initialized
INFO - 2022-03-18 20:16:11 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:16:11 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:16:11 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:16:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:16:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:16:11 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:16:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:16:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:16:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:16:11 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:16:11 --> Final output sent to browser
INFO - 2022-03-18 20:16:14 --> Config Class Initialized
INFO - 2022-03-18 20:16:14 --> Hooks Class Initialized
INFO - 2022-03-18 20:16:14 --> Utf8 Class Initialized
INFO - 2022-03-18 20:16:14 --> URI Class Initialized
INFO - 2022-03-18 20:16:14 --> Router Class Initialized
INFO - 2022-03-18 20:16:14 --> Output Class Initialized
INFO - 2022-03-18 20:16:14 --> Security Class Initialized
INFO - 2022-03-18 20:16:14 --> Input Class Initialized
INFO - 2022-03-18 20:16:14 --> Language Class Initialized
INFO - 2022-03-18 20:16:14 --> Loader Class Initialized
INFO - 2022-03-18 20:16:14 --> Helper loaded: url_helper
INFO - 2022-03-18 20:16:14 --> Helper loaded: form_helper
INFO - 2022-03-18 20:16:14 --> Database Driver Class Initialized
INFO - 2022-03-18 20:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:16:14 --> Form Validation Class Initialized
INFO - 2022-03-18 20:16:14 --> Controller Class Initialized
INFO - 2022-03-18 20:16:14 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:16:14 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:16:14 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:16:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:16:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:16:14 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:16:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:16:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:16:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:16:14 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:16:14 --> Final output sent to browser
INFO - 2022-03-18 20:16:16 --> Config Class Initialized
INFO - 2022-03-18 20:16:16 --> Hooks Class Initialized
INFO - 2022-03-18 20:16:16 --> Utf8 Class Initialized
INFO - 2022-03-18 20:16:16 --> URI Class Initialized
INFO - 2022-03-18 20:16:16 --> Router Class Initialized
INFO - 2022-03-18 20:16:16 --> Output Class Initialized
INFO - 2022-03-18 20:16:16 --> Security Class Initialized
INFO - 2022-03-18 20:16:16 --> Input Class Initialized
INFO - 2022-03-18 20:16:16 --> Language Class Initialized
INFO - 2022-03-18 20:16:16 --> Loader Class Initialized
INFO - 2022-03-18 20:16:16 --> Helper loaded: url_helper
INFO - 2022-03-18 20:16:16 --> Helper loaded: form_helper
INFO - 2022-03-18 20:16:16 --> Database Driver Class Initialized
INFO - 2022-03-18 20:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:16:16 --> Form Validation Class Initialized
INFO - 2022-03-18 20:16:16 --> Controller Class Initialized
INFO - 2022-03-18 20:16:16 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:16:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:16:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:16:16 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:16:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:16:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:16:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:16:16 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:16:16 --> Final output sent to browser
INFO - 2022-03-18 20:16:37 --> Config Class Initialized
INFO - 2022-03-18 20:16:37 --> Hooks Class Initialized
INFO - 2022-03-18 20:16:37 --> Utf8 Class Initialized
INFO - 2022-03-18 20:16:37 --> URI Class Initialized
INFO - 2022-03-18 20:16:37 --> Router Class Initialized
INFO - 2022-03-18 20:16:37 --> Output Class Initialized
INFO - 2022-03-18 20:16:37 --> Security Class Initialized
INFO - 2022-03-18 20:16:37 --> Input Class Initialized
INFO - 2022-03-18 20:16:37 --> Language Class Initialized
INFO - 2022-03-18 20:16:37 --> Loader Class Initialized
INFO - 2022-03-18 20:16:37 --> Helper loaded: url_helper
INFO - 2022-03-18 20:16:37 --> Helper loaded: form_helper
INFO - 2022-03-18 20:16:37 --> Database Driver Class Initialized
INFO - 2022-03-18 20:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:16:37 --> Form Validation Class Initialized
INFO - 2022-03-18 20:16:37 --> Controller Class Initialized
INFO - 2022-03-18 20:16:37 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:16:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:16:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:16:37 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:16:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:16:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:16:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:16:37 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:16:37 --> Final output sent to browser
INFO - 2022-03-18 20:21:52 --> Config Class Initialized
INFO - 2022-03-18 20:21:52 --> Hooks Class Initialized
INFO - 2022-03-18 20:21:52 --> Utf8 Class Initialized
INFO - 2022-03-18 20:21:52 --> URI Class Initialized
INFO - 2022-03-18 20:21:52 --> Router Class Initialized
INFO - 2022-03-18 20:21:52 --> Output Class Initialized
INFO - 2022-03-18 20:21:52 --> Security Class Initialized
INFO - 2022-03-18 20:21:52 --> Input Class Initialized
INFO - 2022-03-18 20:21:52 --> Language Class Initialized
INFO - 2022-03-18 20:21:52 --> Loader Class Initialized
INFO - 2022-03-18 20:21:52 --> Helper loaded: url_helper
INFO - 2022-03-18 20:21:52 --> Helper loaded: form_helper
INFO - 2022-03-18 20:21:52 --> Database Driver Class Initialized
INFO - 2022-03-18 20:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:21:52 --> Form Validation Class Initialized
INFO - 2022-03-18 20:21:52 --> Controller Class Initialized
INFO - 2022-03-18 20:21:52 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:21:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:21:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:21:52 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:21:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:21:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:21:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:21:52 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:21:52 --> Final output sent to browser
INFO - 2022-03-18 20:21:54 --> Config Class Initialized
INFO - 2022-03-18 20:21:54 --> Hooks Class Initialized
INFO - 2022-03-18 20:21:54 --> Utf8 Class Initialized
INFO - 2022-03-18 20:21:54 --> URI Class Initialized
INFO - 2022-03-18 20:21:54 --> Router Class Initialized
INFO - 2022-03-18 20:21:54 --> Output Class Initialized
INFO - 2022-03-18 20:21:54 --> Security Class Initialized
INFO - 2022-03-18 20:21:54 --> Input Class Initialized
INFO - 2022-03-18 20:21:54 --> Language Class Initialized
ERROR - 2022-03-18 20:21:54 --> 404 Page Not Found: Img/favicon.ico
INFO - 2022-03-18 20:22:06 --> Config Class Initialized
INFO - 2022-03-18 20:22:06 --> Hooks Class Initialized
INFO - 2022-03-18 20:22:06 --> Utf8 Class Initialized
INFO - 2022-03-18 20:22:06 --> URI Class Initialized
INFO - 2022-03-18 20:22:06 --> Router Class Initialized
INFO - 2022-03-18 20:22:06 --> Output Class Initialized
INFO - 2022-03-18 20:22:06 --> Security Class Initialized
INFO - 2022-03-18 20:22:06 --> Input Class Initialized
INFO - 2022-03-18 20:22:06 --> Language Class Initialized
INFO - 2022-03-18 20:22:06 --> Loader Class Initialized
INFO - 2022-03-18 20:22:06 --> Helper loaded: url_helper
INFO - 2022-03-18 20:22:06 --> Helper loaded: form_helper
INFO - 2022-03-18 20:22:06 --> Database Driver Class Initialized
INFO - 2022-03-18 20:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:22:06 --> Form Validation Class Initialized
INFO - 2022-03-18 20:22:06 --> Controller Class Initialized
INFO - 2022-03-18 20:22:06 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:22:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:22:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:22:06 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:22:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:22:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:22:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:22:06 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:22:06 --> Final output sent to browser
INFO - 2022-03-18 20:22:14 --> Config Class Initialized
INFO - 2022-03-18 20:22:14 --> Hooks Class Initialized
INFO - 2022-03-18 20:22:14 --> Utf8 Class Initialized
INFO - 2022-03-18 20:22:14 --> URI Class Initialized
INFO - 2022-03-18 20:22:14 --> Router Class Initialized
INFO - 2022-03-18 20:22:14 --> Output Class Initialized
INFO - 2022-03-18 20:22:14 --> Security Class Initialized
INFO - 2022-03-18 20:22:14 --> Input Class Initialized
INFO - 2022-03-18 20:22:14 --> Language Class Initialized
INFO - 2022-03-18 20:22:14 --> Loader Class Initialized
INFO - 2022-03-18 20:22:14 --> Helper loaded: url_helper
INFO - 2022-03-18 20:22:14 --> Helper loaded: form_helper
INFO - 2022-03-18 20:22:14 --> Database Driver Class Initialized
INFO - 2022-03-18 20:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:22:14 --> Form Validation Class Initialized
INFO - 2022-03-18 20:22:14 --> Controller Class Initialized
INFO - 2022-03-18 20:22:14 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:22:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:22:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:22:14 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:22:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:22:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:22:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:22:14 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:22:14 --> Final output sent to browser
INFO - 2022-03-18 20:22:16 --> Config Class Initialized
INFO - 2022-03-18 20:22:16 --> Hooks Class Initialized
INFO - 2022-03-18 20:22:16 --> Utf8 Class Initialized
INFO - 2022-03-18 20:22:16 --> URI Class Initialized
INFO - 2022-03-18 20:22:16 --> Router Class Initialized
INFO - 2022-03-18 20:22:16 --> Output Class Initialized
INFO - 2022-03-18 20:22:16 --> Security Class Initialized
INFO - 2022-03-18 20:22:17 --> Input Class Initialized
INFO - 2022-03-18 20:22:17 --> Language Class Initialized
INFO - 2022-03-18 20:22:17 --> Loader Class Initialized
INFO - 2022-03-18 20:22:17 --> Helper loaded: url_helper
INFO - 2022-03-18 20:22:17 --> Helper loaded: form_helper
INFO - 2022-03-18 20:22:17 --> Database Driver Class Initialized
INFO - 2022-03-18 20:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:22:17 --> Form Validation Class Initialized
INFO - 2022-03-18 20:22:17 --> Controller Class Initialized
INFO - 2022-03-18 20:22:17 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:22:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:22:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:22:17 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:22:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:22:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:22:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:22:17 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:22:17 --> Final output sent to browser
INFO - 2022-03-18 20:22:24 --> Config Class Initialized
INFO - 2022-03-18 20:22:24 --> Hooks Class Initialized
INFO - 2022-03-18 20:22:24 --> Utf8 Class Initialized
INFO - 2022-03-18 20:22:24 --> URI Class Initialized
INFO - 2022-03-18 20:22:24 --> Router Class Initialized
INFO - 2022-03-18 20:22:24 --> Output Class Initialized
INFO - 2022-03-18 20:22:24 --> Security Class Initialized
INFO - 2022-03-18 20:22:24 --> Input Class Initialized
INFO - 2022-03-18 20:22:24 --> Language Class Initialized
INFO - 2022-03-18 20:22:24 --> Loader Class Initialized
INFO - 2022-03-18 20:22:24 --> Helper loaded: url_helper
INFO - 2022-03-18 20:22:24 --> Helper loaded: form_helper
INFO - 2022-03-18 20:22:24 --> Database Driver Class Initialized
INFO - 2022-03-18 20:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:22:24 --> Form Validation Class Initialized
INFO - 2022-03-18 20:22:24 --> Controller Class Initialized
INFO - 2022-03-18 20:22:24 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:22:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:22:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:22:24 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:22:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:22:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:22:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:22:24 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:22:24 --> Final output sent to browser
INFO - 2022-03-18 20:22:42 --> Config Class Initialized
INFO - 2022-03-18 20:22:42 --> Hooks Class Initialized
INFO - 2022-03-18 20:22:42 --> Utf8 Class Initialized
INFO - 2022-03-18 20:22:42 --> URI Class Initialized
INFO - 2022-03-18 20:22:42 --> Router Class Initialized
INFO - 2022-03-18 20:22:42 --> Output Class Initialized
INFO - 2022-03-18 20:22:42 --> Security Class Initialized
INFO - 2022-03-18 20:22:42 --> Input Class Initialized
INFO - 2022-03-18 20:22:42 --> Language Class Initialized
INFO - 2022-03-18 20:22:42 --> Loader Class Initialized
INFO - 2022-03-18 20:22:42 --> Helper loaded: url_helper
INFO - 2022-03-18 20:22:42 --> Helper loaded: form_helper
INFO - 2022-03-18 20:22:42 --> Database Driver Class Initialized
INFO - 2022-03-18 20:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:22:42 --> Form Validation Class Initialized
INFO - 2022-03-18 20:22:42 --> Controller Class Initialized
INFO - 2022-03-18 20:22:42 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:22:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:22:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:22:42 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:22:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:22:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:22:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:22:42 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:22:42 --> Final output sent to browser
INFO - 2022-03-18 20:23:00 --> Config Class Initialized
INFO - 2022-03-18 20:23:00 --> Hooks Class Initialized
INFO - 2022-03-18 20:23:00 --> Utf8 Class Initialized
INFO - 2022-03-18 20:23:00 --> URI Class Initialized
INFO - 2022-03-18 20:23:00 --> Router Class Initialized
INFO - 2022-03-18 20:23:00 --> Output Class Initialized
INFO - 2022-03-18 20:23:00 --> Security Class Initialized
INFO - 2022-03-18 20:23:00 --> Input Class Initialized
INFO - 2022-03-18 20:23:00 --> Language Class Initialized
INFO - 2022-03-18 20:23:00 --> Loader Class Initialized
INFO - 2022-03-18 20:23:00 --> Helper loaded: url_helper
INFO - 2022-03-18 20:23:00 --> Helper loaded: form_helper
INFO - 2022-03-18 20:23:01 --> Database Driver Class Initialized
INFO - 2022-03-18 20:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:23:01 --> Form Validation Class Initialized
INFO - 2022-03-18 20:23:01 --> Controller Class Initialized
INFO - 2022-03-18 20:23:01 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:23:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:23:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:23:01 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:23:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:23:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:23:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:23:01 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:23:01 --> Final output sent to browser
INFO - 2022-03-18 20:23:19 --> Config Class Initialized
INFO - 2022-03-18 20:23:19 --> Hooks Class Initialized
INFO - 2022-03-18 20:23:19 --> Utf8 Class Initialized
INFO - 2022-03-18 20:23:19 --> URI Class Initialized
INFO - 2022-03-18 20:23:19 --> Router Class Initialized
INFO - 2022-03-18 20:23:19 --> Output Class Initialized
INFO - 2022-03-18 20:23:19 --> Security Class Initialized
INFO - 2022-03-18 20:23:19 --> Input Class Initialized
INFO - 2022-03-18 20:23:19 --> Language Class Initialized
INFO - 2022-03-18 20:23:19 --> Loader Class Initialized
INFO - 2022-03-18 20:23:19 --> Helper loaded: url_helper
INFO - 2022-03-18 20:23:19 --> Helper loaded: form_helper
INFO - 2022-03-18 20:23:20 --> Database Driver Class Initialized
INFO - 2022-03-18 20:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:23:20 --> Form Validation Class Initialized
INFO - 2022-03-18 20:23:20 --> Controller Class Initialized
INFO - 2022-03-18 20:23:20 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:23:20 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:23:20 --> Final output sent to browser
INFO - 2022-03-18 20:23:29 --> Config Class Initialized
INFO - 2022-03-18 20:23:29 --> Hooks Class Initialized
INFO - 2022-03-18 20:23:29 --> Utf8 Class Initialized
INFO - 2022-03-18 20:23:29 --> URI Class Initialized
INFO - 2022-03-18 20:23:29 --> Router Class Initialized
INFO - 2022-03-18 20:23:29 --> Output Class Initialized
INFO - 2022-03-18 20:23:29 --> Security Class Initialized
INFO - 2022-03-18 20:23:29 --> Input Class Initialized
INFO - 2022-03-18 20:23:29 --> Language Class Initialized
INFO - 2022-03-18 20:23:29 --> Loader Class Initialized
INFO - 2022-03-18 20:23:29 --> Helper loaded: url_helper
INFO - 2022-03-18 20:23:29 --> Helper loaded: form_helper
INFO - 2022-03-18 20:23:29 --> Database Driver Class Initialized
INFO - 2022-03-18 20:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:23:29 --> Form Validation Class Initialized
INFO - 2022-03-18 20:23:29 --> Controller Class Initialized
INFO - 2022-03-18 20:23:29 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:23:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:23:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:23:29 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:23:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:23:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:23:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:23:29 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:23:29 --> Final output sent to browser
INFO - 2022-03-18 20:23:36 --> Config Class Initialized
INFO - 2022-03-18 20:23:36 --> Hooks Class Initialized
INFO - 2022-03-18 20:23:36 --> Utf8 Class Initialized
INFO - 2022-03-18 20:23:36 --> URI Class Initialized
INFO - 2022-03-18 20:23:36 --> Router Class Initialized
INFO - 2022-03-18 20:23:36 --> Output Class Initialized
INFO - 2022-03-18 20:23:36 --> Security Class Initialized
INFO - 2022-03-18 20:23:36 --> Input Class Initialized
INFO - 2022-03-18 20:23:36 --> Language Class Initialized
INFO - 2022-03-18 20:23:36 --> Loader Class Initialized
INFO - 2022-03-18 20:23:36 --> Helper loaded: url_helper
INFO - 2022-03-18 20:23:36 --> Helper loaded: form_helper
INFO - 2022-03-18 20:23:36 --> Database Driver Class Initialized
INFO - 2022-03-18 20:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:23:36 --> Form Validation Class Initialized
INFO - 2022-03-18 20:23:36 --> Controller Class Initialized
INFO - 2022-03-18 20:23:36 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:23:36 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:23:36 --> Final output sent to browser
INFO - 2022-03-18 20:23:45 --> Config Class Initialized
INFO - 2022-03-18 20:23:45 --> Hooks Class Initialized
INFO - 2022-03-18 20:23:45 --> Utf8 Class Initialized
INFO - 2022-03-18 20:23:45 --> URI Class Initialized
INFO - 2022-03-18 20:23:45 --> Router Class Initialized
INFO - 2022-03-18 20:23:45 --> Output Class Initialized
INFO - 2022-03-18 20:23:45 --> Security Class Initialized
INFO - 2022-03-18 20:23:45 --> Input Class Initialized
INFO - 2022-03-18 20:23:45 --> Language Class Initialized
INFO - 2022-03-18 20:23:45 --> Loader Class Initialized
INFO - 2022-03-18 20:23:45 --> Helper loaded: url_helper
INFO - 2022-03-18 20:23:45 --> Helper loaded: form_helper
INFO - 2022-03-18 20:23:45 --> Database Driver Class Initialized
INFO - 2022-03-18 20:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:23:45 --> Form Validation Class Initialized
INFO - 2022-03-18 20:23:45 --> Controller Class Initialized
INFO - 2022-03-18 20:23:45 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:23:45 --> Final output sent to browser
INFO - 2022-03-18 20:23:57 --> Config Class Initialized
INFO - 2022-03-18 20:23:57 --> Hooks Class Initialized
INFO - 2022-03-18 20:23:57 --> Utf8 Class Initialized
INFO - 2022-03-18 20:23:57 --> URI Class Initialized
INFO - 2022-03-18 20:23:57 --> Router Class Initialized
INFO - 2022-03-18 20:23:57 --> Output Class Initialized
INFO - 2022-03-18 20:23:57 --> Security Class Initialized
INFO - 2022-03-18 20:23:57 --> Input Class Initialized
INFO - 2022-03-18 20:23:57 --> Language Class Initialized
INFO - 2022-03-18 20:23:57 --> Loader Class Initialized
INFO - 2022-03-18 20:23:57 --> Helper loaded: url_helper
INFO - 2022-03-18 20:23:57 --> Helper loaded: form_helper
INFO - 2022-03-18 20:23:57 --> Database Driver Class Initialized
INFO - 2022-03-18 20:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:23:57 --> Form Validation Class Initialized
INFO - 2022-03-18 20:23:57 --> Controller Class Initialized
INFO - 2022-03-18 20:23:57 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:23:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:23:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:23:57 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:23:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:23:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:23:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:23:57 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:23:57 --> Final output sent to browser
INFO - 2022-03-18 20:24:06 --> Config Class Initialized
INFO - 2022-03-18 20:24:06 --> Hooks Class Initialized
INFO - 2022-03-18 20:24:06 --> Utf8 Class Initialized
INFO - 2022-03-18 20:24:06 --> URI Class Initialized
INFO - 2022-03-18 20:24:06 --> Router Class Initialized
INFO - 2022-03-18 20:24:06 --> Output Class Initialized
INFO - 2022-03-18 20:24:06 --> Security Class Initialized
INFO - 2022-03-18 20:24:06 --> Input Class Initialized
INFO - 2022-03-18 20:24:06 --> Language Class Initialized
INFO - 2022-03-18 20:24:06 --> Loader Class Initialized
INFO - 2022-03-18 20:24:06 --> Helper loaded: url_helper
INFO - 2022-03-18 20:24:06 --> Helper loaded: form_helper
INFO - 2022-03-18 20:24:06 --> Database Driver Class Initialized
INFO - 2022-03-18 20:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:24:06 --> Form Validation Class Initialized
INFO - 2022-03-18 20:24:06 --> Controller Class Initialized
INFO - 2022-03-18 20:24:06 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:24:06 --> Final output sent to browser
INFO - 2022-03-18 20:24:13 --> Config Class Initialized
INFO - 2022-03-18 20:24:13 --> Hooks Class Initialized
INFO - 2022-03-18 20:24:13 --> Utf8 Class Initialized
INFO - 2022-03-18 20:24:13 --> URI Class Initialized
INFO - 2022-03-18 20:24:13 --> Router Class Initialized
INFO - 2022-03-18 20:24:13 --> Output Class Initialized
INFO - 2022-03-18 20:24:13 --> Security Class Initialized
INFO - 2022-03-18 20:24:13 --> Input Class Initialized
INFO - 2022-03-18 20:24:13 --> Language Class Initialized
INFO - 2022-03-18 20:24:13 --> Loader Class Initialized
INFO - 2022-03-18 20:24:13 --> Helper loaded: url_helper
INFO - 2022-03-18 20:24:13 --> Helper loaded: form_helper
INFO - 2022-03-18 20:24:13 --> Database Driver Class Initialized
INFO - 2022-03-18 20:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:24:13 --> Form Validation Class Initialized
INFO - 2022-03-18 20:24:13 --> Controller Class Initialized
INFO - 2022-03-18 20:24:13 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:24:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:24:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:24:13 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:24:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:24:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:24:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:24:13 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:24:13 --> Final output sent to browser
INFO - 2022-03-18 20:24:23 --> Config Class Initialized
INFO - 2022-03-18 20:24:23 --> Hooks Class Initialized
INFO - 2022-03-18 20:24:23 --> Utf8 Class Initialized
INFO - 2022-03-18 20:24:23 --> URI Class Initialized
INFO - 2022-03-18 20:24:23 --> Router Class Initialized
INFO - 2022-03-18 20:24:23 --> Output Class Initialized
INFO - 2022-03-18 20:24:23 --> Security Class Initialized
INFO - 2022-03-18 20:24:23 --> Input Class Initialized
INFO - 2022-03-18 20:24:23 --> Language Class Initialized
INFO - 2022-03-18 20:24:23 --> Loader Class Initialized
INFO - 2022-03-18 20:24:23 --> Helper loaded: url_helper
INFO - 2022-03-18 20:24:23 --> Helper loaded: form_helper
INFO - 2022-03-18 20:24:23 --> Database Driver Class Initialized
INFO - 2022-03-18 20:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:24:23 --> Form Validation Class Initialized
INFO - 2022-03-18 20:24:23 --> Controller Class Initialized
INFO - 2022-03-18 20:24:23 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:24:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:24:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:24:23 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:24:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:24:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:24:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:24:23 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:24:23 --> Final output sent to browser
INFO - 2022-03-18 20:24:53 --> Config Class Initialized
INFO - 2022-03-18 20:24:53 --> Hooks Class Initialized
INFO - 2022-03-18 20:24:53 --> Utf8 Class Initialized
INFO - 2022-03-18 20:24:53 --> URI Class Initialized
INFO - 2022-03-18 20:24:53 --> Router Class Initialized
INFO - 2022-03-18 20:24:53 --> Output Class Initialized
INFO - 2022-03-18 20:24:53 --> Security Class Initialized
INFO - 2022-03-18 20:24:53 --> Input Class Initialized
INFO - 2022-03-18 20:24:53 --> Language Class Initialized
INFO - 2022-03-18 20:24:53 --> Loader Class Initialized
INFO - 2022-03-18 20:24:54 --> Helper loaded: url_helper
INFO - 2022-03-18 20:24:54 --> Helper loaded: form_helper
INFO - 2022-03-18 20:24:54 --> Database Driver Class Initialized
INFO - 2022-03-18 20:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:24:54 --> Form Validation Class Initialized
INFO - 2022-03-18 20:24:54 --> Controller Class Initialized
INFO - 2022-03-18 20:24:54 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:24:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:24:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:24:54 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:24:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:24:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:24:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:24:54 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:24:54 --> Final output sent to browser
INFO - 2022-03-18 20:25:01 --> Config Class Initialized
INFO - 2022-03-18 20:25:01 --> Hooks Class Initialized
INFO - 2022-03-18 20:25:01 --> Utf8 Class Initialized
INFO - 2022-03-18 20:25:01 --> URI Class Initialized
INFO - 2022-03-18 20:25:01 --> Router Class Initialized
INFO - 2022-03-18 20:25:01 --> Output Class Initialized
INFO - 2022-03-18 20:25:01 --> Security Class Initialized
INFO - 2022-03-18 20:25:01 --> Input Class Initialized
INFO - 2022-03-18 20:25:01 --> Language Class Initialized
INFO - 2022-03-18 20:25:01 --> Loader Class Initialized
INFO - 2022-03-18 20:25:01 --> Helper loaded: url_helper
INFO - 2022-03-18 20:25:01 --> Helper loaded: form_helper
INFO - 2022-03-18 20:25:01 --> Database Driver Class Initialized
INFO - 2022-03-18 20:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:25:01 --> Form Validation Class Initialized
INFO - 2022-03-18 20:25:01 --> Controller Class Initialized
INFO - 2022-03-18 20:25:01 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:25:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:25:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:25:01 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:25:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:25:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:25:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:25:01 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:25:01 --> Final output sent to browser
INFO - 2022-03-18 20:25:07 --> Config Class Initialized
INFO - 2022-03-18 20:25:07 --> Hooks Class Initialized
INFO - 2022-03-18 20:25:07 --> Utf8 Class Initialized
INFO - 2022-03-18 20:25:07 --> URI Class Initialized
INFO - 2022-03-18 20:25:07 --> Router Class Initialized
INFO - 2022-03-18 20:25:07 --> Output Class Initialized
INFO - 2022-03-18 20:25:07 --> Security Class Initialized
INFO - 2022-03-18 20:25:07 --> Input Class Initialized
INFO - 2022-03-18 20:25:07 --> Language Class Initialized
INFO - 2022-03-18 20:25:07 --> Loader Class Initialized
INFO - 2022-03-18 20:25:07 --> Helper loaded: url_helper
INFO - 2022-03-18 20:25:07 --> Helper loaded: form_helper
INFO - 2022-03-18 20:25:07 --> Database Driver Class Initialized
INFO - 2022-03-18 20:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:25:07 --> Form Validation Class Initialized
INFO - 2022-03-18 20:25:07 --> Controller Class Initialized
INFO - 2022-03-18 20:25:07 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:25:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:25:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:25:07 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-18 20:25:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:25:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:25:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:25:07 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:25:07 --> Final output sent to browser
INFO - 2022-03-18 20:25:33 --> Config Class Initialized
INFO - 2022-03-18 20:25:33 --> Hooks Class Initialized
INFO - 2022-03-18 20:25:33 --> Utf8 Class Initialized
INFO - 2022-03-18 20:25:33 --> URI Class Initialized
INFO - 2022-03-18 20:25:33 --> Router Class Initialized
INFO - 2022-03-18 20:25:33 --> Output Class Initialized
INFO - 2022-03-18 20:25:33 --> Security Class Initialized
INFO - 2022-03-18 20:25:33 --> Input Class Initialized
INFO - 2022-03-18 20:25:33 --> Language Class Initialized
INFO - 2022-03-18 20:25:33 --> Loader Class Initialized
INFO - 2022-03-18 20:25:33 --> Helper loaded: url_helper
INFO - 2022-03-18 20:25:33 --> Helper loaded: form_helper
INFO - 2022-03-18 20:25:33 --> Database Driver Class Initialized
INFO - 2022-03-18 20:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:25:33 --> Form Validation Class Initialized
INFO - 2022-03-18 20:25:33 --> Controller Class Initialized
INFO - 2022-03-18 20:25:33 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:25:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:25:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:25:33 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_tambah.php
INFO - 2022-03-18 20:25:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:25:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:25:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:25:33 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:25:33 --> Final output sent to browser
INFO - 2022-03-18 20:25:40 --> Config Class Initialized
INFO - 2022-03-18 20:25:40 --> Hooks Class Initialized
INFO - 2022-03-18 20:25:40 --> Utf8 Class Initialized
INFO - 2022-03-18 20:25:40 --> URI Class Initialized
INFO - 2022-03-18 20:25:40 --> Router Class Initialized
INFO - 2022-03-18 20:25:40 --> Output Class Initialized
INFO - 2022-03-18 20:25:40 --> Security Class Initialized
INFO - 2022-03-18 20:25:40 --> Input Class Initialized
INFO - 2022-03-18 20:25:40 --> Language Class Initialized
INFO - 2022-03-18 20:25:40 --> Loader Class Initialized
INFO - 2022-03-18 20:25:40 --> Helper loaded: url_helper
INFO - 2022-03-18 20:25:40 --> Helper loaded: form_helper
INFO - 2022-03-18 20:25:40 --> Database Driver Class Initialized
INFO - 2022-03-18 20:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:25:40 --> Form Validation Class Initialized
INFO - 2022-03-18 20:25:40 --> Controller Class Initialized
INFO - 2022-03-18 20:25:40 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:25:40 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:25:40 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:25:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:25:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:25:40 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:25:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:25:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:25:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:25:40 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:25:40 --> Final output sent to browser
INFO - 2022-03-18 20:26:05 --> Config Class Initialized
INFO - 2022-03-18 20:26:05 --> Hooks Class Initialized
INFO - 2022-03-18 20:26:05 --> Utf8 Class Initialized
INFO - 2022-03-18 20:26:05 --> URI Class Initialized
INFO - 2022-03-18 20:26:05 --> Router Class Initialized
INFO - 2022-03-18 20:26:05 --> Output Class Initialized
INFO - 2022-03-18 20:26:05 --> Security Class Initialized
INFO - 2022-03-18 20:26:05 --> Input Class Initialized
INFO - 2022-03-18 20:26:05 --> Language Class Initialized
INFO - 2022-03-18 20:26:05 --> Loader Class Initialized
INFO - 2022-03-18 20:26:05 --> Helper loaded: url_helper
INFO - 2022-03-18 20:26:05 --> Helper loaded: form_helper
INFO - 2022-03-18 20:26:05 --> Database Driver Class Initialized
INFO - 2022-03-18 20:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:26:05 --> Form Validation Class Initialized
INFO - 2022-03-18 20:26:05 --> Controller Class Initialized
INFO - 2022-03-18 20:26:05 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:26:05 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:26:05 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:26:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:26:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:26:05 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:26:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:26:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:26:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:26:05 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:26:05 --> Final output sent to browser
INFO - 2022-03-18 20:26:14 --> Config Class Initialized
INFO - 2022-03-18 20:26:14 --> Hooks Class Initialized
INFO - 2022-03-18 20:26:14 --> Utf8 Class Initialized
INFO - 2022-03-18 20:26:14 --> URI Class Initialized
INFO - 2022-03-18 20:26:14 --> Router Class Initialized
INFO - 2022-03-18 20:26:14 --> Output Class Initialized
INFO - 2022-03-18 20:26:14 --> Security Class Initialized
INFO - 2022-03-18 20:26:14 --> Input Class Initialized
INFO - 2022-03-18 20:26:14 --> Language Class Initialized
INFO - 2022-03-18 20:26:14 --> Loader Class Initialized
INFO - 2022-03-18 20:26:14 --> Helper loaded: url_helper
INFO - 2022-03-18 20:26:14 --> Helper loaded: form_helper
INFO - 2022-03-18 20:26:14 --> Database Driver Class Initialized
INFO - 2022-03-18 20:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:26:14 --> Form Validation Class Initialized
INFO - 2022-03-18 20:26:14 --> Controller Class Initialized
INFO - 2022-03-18 20:26:14 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:26:14 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:26:14 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:26:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:26:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:26:14 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_tambah.php
INFO - 2022-03-18 20:26:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:26:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:26:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:26:14 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:26:14 --> Final output sent to browser
INFO - 2022-03-18 20:26:20 --> Config Class Initialized
INFO - 2022-03-18 20:26:20 --> Hooks Class Initialized
INFO - 2022-03-18 20:26:20 --> Utf8 Class Initialized
INFO - 2022-03-18 20:26:20 --> URI Class Initialized
INFO - 2022-03-18 20:26:20 --> Router Class Initialized
INFO - 2022-03-18 20:26:20 --> Output Class Initialized
INFO - 2022-03-18 20:26:20 --> Security Class Initialized
INFO - 2022-03-18 20:26:20 --> Input Class Initialized
INFO - 2022-03-18 20:26:20 --> Language Class Initialized
INFO - 2022-03-18 20:26:20 --> Loader Class Initialized
INFO - 2022-03-18 20:26:20 --> Helper loaded: url_helper
INFO - 2022-03-18 20:26:20 --> Helper loaded: form_helper
INFO - 2022-03-18 20:26:20 --> Database Driver Class Initialized
INFO - 2022-03-18 20:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:26:20 --> Form Validation Class Initialized
INFO - 2022-03-18 20:26:20 --> Controller Class Initialized
INFO - 2022-03-18 20:26:20 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:26:20 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:26:20 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:26:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:26:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:26:20 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-18 20:26:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:26:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:26:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:26:20 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:26:20 --> Final output sent to browser
INFO - 2022-03-18 20:26:23 --> Config Class Initialized
INFO - 2022-03-18 20:26:23 --> Hooks Class Initialized
INFO - 2022-03-18 20:26:23 --> Utf8 Class Initialized
INFO - 2022-03-18 20:26:23 --> URI Class Initialized
INFO - 2022-03-18 20:26:23 --> Router Class Initialized
INFO - 2022-03-18 20:26:23 --> Output Class Initialized
INFO - 2022-03-18 20:26:23 --> Security Class Initialized
INFO - 2022-03-18 20:26:23 --> Input Class Initialized
INFO - 2022-03-18 20:26:23 --> Language Class Initialized
INFO - 2022-03-18 20:26:23 --> Loader Class Initialized
INFO - 2022-03-18 20:26:23 --> Helper loaded: url_helper
INFO - 2022-03-18 20:26:23 --> Helper loaded: form_helper
INFO - 2022-03-18 20:26:23 --> Database Driver Class Initialized
INFO - 2022-03-18 20:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:26:23 --> Form Validation Class Initialized
INFO - 2022-03-18 20:26:23 --> Controller Class Initialized
INFO - 2022-03-18 20:26:23 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:26:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:26:23 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:26:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:26:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:26:23 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 20:26:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:26:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:26:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:26:23 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:26:23 --> Final output sent to browser
INFO - 2022-03-18 20:26:29 --> Config Class Initialized
INFO - 2022-03-18 20:26:29 --> Hooks Class Initialized
INFO - 2022-03-18 20:26:29 --> Utf8 Class Initialized
INFO - 2022-03-18 20:26:29 --> URI Class Initialized
INFO - 2022-03-18 20:26:29 --> Router Class Initialized
INFO - 2022-03-18 20:26:29 --> Output Class Initialized
INFO - 2022-03-18 20:26:29 --> Security Class Initialized
INFO - 2022-03-18 20:26:29 --> Input Class Initialized
INFO - 2022-03-18 20:26:29 --> Language Class Initialized
INFO - 2022-03-18 20:26:29 --> Loader Class Initialized
INFO - 2022-03-18 20:26:29 --> Helper loaded: url_helper
INFO - 2022-03-18 20:26:29 --> Helper loaded: form_helper
INFO - 2022-03-18 20:26:29 --> Database Driver Class Initialized
INFO - 2022-03-18 20:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:26:29 --> Form Validation Class Initialized
INFO - 2022-03-18 20:26:29 --> Controller Class Initialized
INFO - 2022-03-18 20:26:29 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:26:29 --> Final output sent to browser
INFO - 2022-03-18 20:26:31 --> Config Class Initialized
INFO - 2022-03-18 20:26:31 --> Hooks Class Initialized
INFO - 2022-03-18 20:26:31 --> Utf8 Class Initialized
INFO - 2022-03-18 20:26:31 --> URI Class Initialized
INFO - 2022-03-18 20:26:31 --> Router Class Initialized
INFO - 2022-03-18 20:26:31 --> Output Class Initialized
INFO - 2022-03-18 20:26:31 --> Security Class Initialized
INFO - 2022-03-18 20:26:31 --> Input Class Initialized
INFO - 2022-03-18 20:26:31 --> Language Class Initialized
INFO - 2022-03-18 20:26:31 --> Loader Class Initialized
INFO - 2022-03-18 20:26:31 --> Helper loaded: url_helper
INFO - 2022-03-18 20:26:31 --> Helper loaded: form_helper
INFO - 2022-03-18 20:26:31 --> Database Driver Class Initialized
INFO - 2022-03-18 20:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:26:31 --> Form Validation Class Initialized
INFO - 2022-03-18 20:26:31 --> Controller Class Initialized
INFO - 2022-03-18 20:26:31 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:26:31 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:26:31 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:26:32 --> Config Class Initialized
INFO - 2022-03-18 20:26:32 --> Hooks Class Initialized
INFO - 2022-03-18 20:26:32 --> Utf8 Class Initialized
INFO - 2022-03-18 20:26:32 --> URI Class Initialized
INFO - 2022-03-18 20:26:32 --> Router Class Initialized
INFO - 2022-03-18 20:26:32 --> Output Class Initialized
INFO - 2022-03-18 20:26:32 --> Security Class Initialized
INFO - 2022-03-18 20:26:32 --> Input Class Initialized
INFO - 2022-03-18 20:26:32 --> Language Class Initialized
INFO - 2022-03-18 20:26:32 --> Loader Class Initialized
INFO - 2022-03-18 20:26:32 --> Helper loaded: url_helper
INFO - 2022-03-18 20:26:32 --> Helper loaded: form_helper
INFO - 2022-03-18 20:26:32 --> Database Driver Class Initialized
INFO - 2022-03-18 20:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:26:32 --> Form Validation Class Initialized
INFO - 2022-03-18 20:26:32 --> Controller Class Initialized
INFO - 2022-03-18 20:26:32 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:26:32 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:26:32 --> Model "M_tutor" initialized
INFO - 2022-03-18 20:26:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:26:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:26:32 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-18 20:26:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:26:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:26:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:26:32 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:26:32 --> Final output sent to browser
INFO - 2022-03-18 20:26:48 --> Config Class Initialized
INFO - 2022-03-18 20:26:48 --> Hooks Class Initialized
INFO - 2022-03-18 20:26:48 --> Utf8 Class Initialized
INFO - 2022-03-18 20:26:48 --> URI Class Initialized
INFO - 2022-03-18 20:26:48 --> Router Class Initialized
INFO - 2022-03-18 20:26:48 --> Output Class Initialized
INFO - 2022-03-18 20:26:48 --> Security Class Initialized
INFO - 2022-03-18 20:26:48 --> Input Class Initialized
INFO - 2022-03-18 20:26:48 --> Language Class Initialized
INFO - 2022-03-18 20:26:48 --> Loader Class Initialized
INFO - 2022-03-18 20:26:48 --> Helper loaded: url_helper
INFO - 2022-03-18 20:26:48 --> Helper loaded: form_helper
INFO - 2022-03-18 20:26:48 --> Database Driver Class Initialized
INFO - 2022-03-18 20:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:26:48 --> Form Validation Class Initialized
INFO - 2022-03-18 20:26:48 --> Controller Class Initialized
INFO - 2022-03-18 20:26:48 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:26:48 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:26:48 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:26:48 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:26:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:26:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:26:48 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 20:26:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:26:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:26:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:26:48 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:26:48 --> Final output sent to browser
INFO - 2022-03-18 20:26:55 --> Config Class Initialized
INFO - 2022-03-18 20:26:55 --> Hooks Class Initialized
INFO - 2022-03-18 20:26:55 --> Utf8 Class Initialized
INFO - 2022-03-18 20:26:55 --> URI Class Initialized
INFO - 2022-03-18 20:26:55 --> Router Class Initialized
INFO - 2022-03-18 20:26:55 --> Output Class Initialized
INFO - 2022-03-18 20:26:55 --> Security Class Initialized
INFO - 2022-03-18 20:26:55 --> Input Class Initialized
INFO - 2022-03-18 20:26:55 --> Language Class Initialized
INFO - 2022-03-18 20:26:55 --> Loader Class Initialized
INFO - 2022-03-18 20:26:55 --> Helper loaded: url_helper
INFO - 2022-03-18 20:26:55 --> Helper loaded: form_helper
INFO - 2022-03-18 20:26:55 --> Database Driver Class Initialized
INFO - 2022-03-18 20:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:26:55 --> Form Validation Class Initialized
INFO - 2022-03-18 20:26:55 --> Controller Class Initialized
INFO - 2022-03-18 20:26:55 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:26:55 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:26:55 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:26:55 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:26:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:26:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:26:55 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:26:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:26:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:26:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:26:55 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:26:55 --> Final output sent to browser
INFO - 2022-03-18 20:27:01 --> Config Class Initialized
INFO - 2022-03-18 20:27:01 --> Hooks Class Initialized
INFO - 2022-03-18 20:27:01 --> Utf8 Class Initialized
INFO - 2022-03-18 20:27:01 --> URI Class Initialized
INFO - 2022-03-18 20:27:01 --> Router Class Initialized
INFO - 2022-03-18 20:27:01 --> Output Class Initialized
INFO - 2022-03-18 20:27:01 --> Security Class Initialized
INFO - 2022-03-18 20:27:01 --> Input Class Initialized
INFO - 2022-03-18 20:27:01 --> Language Class Initialized
INFO - 2022-03-18 20:27:01 --> Loader Class Initialized
INFO - 2022-03-18 20:27:01 --> Helper loaded: url_helper
INFO - 2022-03-18 20:27:01 --> Helper loaded: form_helper
INFO - 2022-03-18 20:27:01 --> Database Driver Class Initialized
INFO - 2022-03-18 20:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:27:01 --> Form Validation Class Initialized
INFO - 2022-03-18 20:27:01 --> Controller Class Initialized
INFO - 2022-03-18 20:27:01 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:27:01 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:27:01 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:27:01 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:27:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:27:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:27:02 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 20:27:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:27:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:27:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:27:02 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:27:02 --> Final output sent to browser
INFO - 2022-03-18 20:27:04 --> Config Class Initialized
INFO - 2022-03-18 20:27:04 --> Hooks Class Initialized
INFO - 2022-03-18 20:27:04 --> Utf8 Class Initialized
INFO - 2022-03-18 20:27:04 --> URI Class Initialized
INFO - 2022-03-18 20:27:04 --> Router Class Initialized
INFO - 2022-03-18 20:27:04 --> Output Class Initialized
INFO - 2022-03-18 20:27:04 --> Security Class Initialized
INFO - 2022-03-18 20:27:04 --> Input Class Initialized
INFO - 2022-03-18 20:27:04 --> Language Class Initialized
INFO - 2022-03-18 20:27:04 --> Loader Class Initialized
INFO - 2022-03-18 20:27:04 --> Helper loaded: url_helper
INFO - 2022-03-18 20:27:04 --> Helper loaded: form_helper
INFO - 2022-03-18 20:27:04 --> Database Driver Class Initialized
INFO - 2022-03-18 20:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:27:04 --> Form Validation Class Initialized
INFO - 2022-03-18 20:27:04 --> Controller Class Initialized
INFO - 2022-03-18 20:27:04 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:27:04 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:27:04 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:27:04 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:27:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:27:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:27:04 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:27:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:27:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:27:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:27:04 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:27:04 --> Final output sent to browser
INFO - 2022-03-18 20:27:07 --> Config Class Initialized
INFO - 2022-03-18 20:27:07 --> Hooks Class Initialized
INFO - 2022-03-18 20:27:07 --> Utf8 Class Initialized
INFO - 2022-03-18 20:27:07 --> URI Class Initialized
INFO - 2022-03-18 20:27:07 --> Router Class Initialized
INFO - 2022-03-18 20:27:07 --> Output Class Initialized
INFO - 2022-03-18 20:27:07 --> Security Class Initialized
INFO - 2022-03-18 20:27:07 --> Input Class Initialized
INFO - 2022-03-18 20:27:07 --> Language Class Initialized
INFO - 2022-03-18 20:27:07 --> Loader Class Initialized
INFO - 2022-03-18 20:27:07 --> Helper loaded: url_helper
INFO - 2022-03-18 20:27:07 --> Helper loaded: form_helper
INFO - 2022-03-18 20:27:07 --> Database Driver Class Initialized
INFO - 2022-03-18 20:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:27:07 --> Form Validation Class Initialized
INFO - 2022-03-18 20:27:07 --> Controller Class Initialized
INFO - 2022-03-18 20:27:07 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:27:07 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:27:07 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:27:07 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:27:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:27:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:27:07 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-18 20:27:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:27:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:27:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:27:07 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:27:07 --> Final output sent to browser
INFO - 2022-03-18 20:27:13 --> Config Class Initialized
INFO - 2022-03-18 20:27:13 --> Hooks Class Initialized
INFO - 2022-03-18 20:27:13 --> Utf8 Class Initialized
INFO - 2022-03-18 20:27:13 --> URI Class Initialized
INFO - 2022-03-18 20:27:13 --> Router Class Initialized
INFO - 2022-03-18 20:27:13 --> Output Class Initialized
INFO - 2022-03-18 20:27:13 --> Security Class Initialized
INFO - 2022-03-18 20:27:13 --> Input Class Initialized
INFO - 2022-03-18 20:27:13 --> Language Class Initialized
INFO - 2022-03-18 20:27:13 --> Loader Class Initialized
INFO - 2022-03-18 20:27:13 --> Helper loaded: url_helper
INFO - 2022-03-18 20:27:13 --> Helper loaded: form_helper
INFO - 2022-03-18 20:27:13 --> Database Driver Class Initialized
INFO - 2022-03-18 20:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:27:13 --> Form Validation Class Initialized
INFO - 2022-03-18 20:27:13 --> Controller Class Initialized
INFO - 2022-03-18 20:27:13 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:27:13 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:27:13 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:27:13 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:27:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:27:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:27:13 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:27:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:27:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:27:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:27:13 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:27:13 --> Final output sent to browser
INFO - 2022-03-18 20:30:26 --> Config Class Initialized
INFO - 2022-03-18 20:30:26 --> Hooks Class Initialized
INFO - 2022-03-18 20:30:26 --> Utf8 Class Initialized
INFO - 2022-03-18 20:30:26 --> URI Class Initialized
INFO - 2022-03-18 20:30:26 --> Router Class Initialized
INFO - 2022-03-18 20:30:26 --> Output Class Initialized
INFO - 2022-03-18 20:30:26 --> Security Class Initialized
INFO - 2022-03-18 20:30:26 --> Input Class Initialized
INFO - 2022-03-18 20:30:26 --> Language Class Initialized
INFO - 2022-03-18 20:30:26 --> Loader Class Initialized
INFO - 2022-03-18 20:30:26 --> Helper loaded: url_helper
INFO - 2022-03-18 20:30:26 --> Helper loaded: form_helper
INFO - 2022-03-18 20:30:26 --> Database Driver Class Initialized
INFO - 2022-03-18 20:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:30:26 --> Form Validation Class Initialized
INFO - 2022-03-18 20:30:26 --> Controller Class Initialized
INFO - 2022-03-18 20:30:26 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:30:26 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:30:26 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:30:26 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:30:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:30:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 20:30:26 --> Severity: Notice --> Undefined variable: i C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 39
ERROR - 2022-03-18 20:30:26 --> Severity: Notice --> Undefined variable: task C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 42
ERROR - 2022-03-18 20:30:26 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 42
ERROR - 2022-03-18 20:30:26 --> Severity: Notice --> Undefined variable: task C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 45
ERROR - 2022-03-18 20:30:26 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 45
ERROR - 2022-03-18 20:30:26 --> Severity: Notice --> Undefined variable: task C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 48
ERROR - 2022-03-18 20:30:26 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 48
ERROR - 2022-03-18 20:30:26 --> Severity: Notice --> Undefined variable: task C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 51
ERROR - 2022-03-18 20:30:26 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 51
INFO - 2022-03-18 20:30:26 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:30:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:30:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:30:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:30:26 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:30:26 --> Final output sent to browser
INFO - 2022-03-18 20:31:15 --> Config Class Initialized
INFO - 2022-03-18 20:31:15 --> Hooks Class Initialized
INFO - 2022-03-18 20:31:15 --> Utf8 Class Initialized
INFO - 2022-03-18 20:31:15 --> URI Class Initialized
INFO - 2022-03-18 20:31:15 --> Router Class Initialized
INFO - 2022-03-18 20:31:15 --> Output Class Initialized
INFO - 2022-03-18 20:31:15 --> Security Class Initialized
INFO - 2022-03-18 20:31:15 --> Input Class Initialized
INFO - 2022-03-18 20:31:15 --> Language Class Initialized
INFO - 2022-03-18 20:31:15 --> Loader Class Initialized
INFO - 2022-03-18 20:31:15 --> Helper loaded: url_helper
INFO - 2022-03-18 20:31:15 --> Helper loaded: form_helper
INFO - 2022-03-18 20:31:15 --> Database Driver Class Initialized
INFO - 2022-03-18 20:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:31:15 --> Form Validation Class Initialized
INFO - 2022-03-18 20:31:15 --> Controller Class Initialized
INFO - 2022-03-18 20:31:15 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:31:15 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:31:15 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:31:15 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:31:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:31:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:31:15 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:31:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:31:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:31:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:31:15 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:31:15 --> Final output sent to browser
INFO - 2022-03-18 20:31:21 --> Config Class Initialized
INFO - 2022-03-18 20:31:21 --> Hooks Class Initialized
INFO - 2022-03-18 20:31:21 --> Utf8 Class Initialized
INFO - 2022-03-18 20:31:21 --> URI Class Initialized
INFO - 2022-03-18 20:31:21 --> Router Class Initialized
INFO - 2022-03-18 20:31:21 --> Output Class Initialized
INFO - 2022-03-18 20:31:21 --> Security Class Initialized
INFO - 2022-03-18 20:31:21 --> Input Class Initialized
INFO - 2022-03-18 20:31:21 --> Language Class Initialized
INFO - 2022-03-18 20:31:21 --> Loader Class Initialized
INFO - 2022-03-18 20:31:21 --> Helper loaded: url_helper
INFO - 2022-03-18 20:31:21 --> Helper loaded: form_helper
INFO - 2022-03-18 20:31:21 --> Database Driver Class Initialized
INFO - 2022-03-18 20:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:31:21 --> Form Validation Class Initialized
INFO - 2022-03-18 20:31:21 --> Controller Class Initialized
INFO - 2022-03-18 20:31:21 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:31:21 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:31:21 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:31:21 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:31:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:31:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:31:21 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:31:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:31:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:31:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:31:21 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:31:21 --> Final output sent to browser
INFO - 2022-03-18 20:31:40 --> Config Class Initialized
INFO - 2022-03-18 20:31:40 --> Hooks Class Initialized
INFO - 2022-03-18 20:31:40 --> Utf8 Class Initialized
INFO - 2022-03-18 20:31:40 --> URI Class Initialized
INFO - 2022-03-18 20:31:40 --> Router Class Initialized
INFO - 2022-03-18 20:31:40 --> Output Class Initialized
INFO - 2022-03-18 20:31:40 --> Security Class Initialized
INFO - 2022-03-18 20:31:40 --> Input Class Initialized
INFO - 2022-03-18 20:31:40 --> Language Class Initialized
INFO - 2022-03-18 20:31:40 --> Loader Class Initialized
INFO - 2022-03-18 20:31:40 --> Helper loaded: url_helper
INFO - 2022-03-18 20:31:40 --> Helper loaded: form_helper
INFO - 2022-03-18 20:31:40 --> Database Driver Class Initialized
INFO - 2022-03-18 20:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:31:40 --> Form Validation Class Initialized
INFO - 2022-03-18 20:31:40 --> Controller Class Initialized
INFO - 2022-03-18 20:31:40 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:31:40 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:31:40 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:31:40 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:31:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:31:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:31:40 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:31:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:31:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:31:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:31:40 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:31:40 --> Final output sent to browser
INFO - 2022-03-18 20:32:36 --> Config Class Initialized
INFO - 2022-03-18 20:32:36 --> Hooks Class Initialized
INFO - 2022-03-18 20:32:36 --> Utf8 Class Initialized
INFO - 2022-03-18 20:32:36 --> URI Class Initialized
INFO - 2022-03-18 20:32:36 --> Router Class Initialized
INFO - 2022-03-18 20:32:36 --> Output Class Initialized
INFO - 2022-03-18 20:32:36 --> Security Class Initialized
INFO - 2022-03-18 20:32:36 --> Input Class Initialized
INFO - 2022-03-18 20:32:36 --> Language Class Initialized
INFO - 2022-03-18 20:32:36 --> Loader Class Initialized
INFO - 2022-03-18 20:32:36 --> Helper loaded: url_helper
INFO - 2022-03-18 20:32:36 --> Helper loaded: form_helper
INFO - 2022-03-18 20:32:37 --> Database Driver Class Initialized
INFO - 2022-03-18 20:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:32:37 --> Form Validation Class Initialized
INFO - 2022-03-18 20:32:37 --> Controller Class Initialized
INFO - 2022-03-18 20:32:37 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:32:37 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:32:37 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:32:37 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:32:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:32:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:32:37 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:32:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:32:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:32:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:32:37 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:32:37 --> Final output sent to browser
INFO - 2022-03-18 20:33:28 --> Config Class Initialized
INFO - 2022-03-18 20:33:28 --> Hooks Class Initialized
INFO - 2022-03-18 20:33:28 --> Utf8 Class Initialized
INFO - 2022-03-18 20:33:28 --> URI Class Initialized
INFO - 2022-03-18 20:33:28 --> Router Class Initialized
INFO - 2022-03-18 20:33:28 --> Output Class Initialized
INFO - 2022-03-18 20:33:28 --> Security Class Initialized
INFO - 2022-03-18 20:33:28 --> Input Class Initialized
INFO - 2022-03-18 20:33:28 --> Language Class Initialized
INFO - 2022-03-18 20:33:28 --> Loader Class Initialized
INFO - 2022-03-18 20:33:28 --> Helper loaded: url_helper
INFO - 2022-03-18 20:33:28 --> Helper loaded: form_helper
INFO - 2022-03-18 20:33:28 --> Database Driver Class Initialized
INFO - 2022-03-18 20:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:33:28 --> Form Validation Class Initialized
INFO - 2022-03-18 20:33:28 --> Controller Class Initialized
INFO - 2022-03-18 20:33:28 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:33:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:33:28 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:33:28 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:33:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:33:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:33:28 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:33:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:33:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:33:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:33:28 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:33:28 --> Final output sent to browser
INFO - 2022-03-18 20:34:11 --> Config Class Initialized
INFO - 2022-03-18 20:34:11 --> Hooks Class Initialized
INFO - 2022-03-18 20:34:11 --> Utf8 Class Initialized
INFO - 2022-03-18 20:34:11 --> URI Class Initialized
INFO - 2022-03-18 20:34:11 --> Router Class Initialized
INFO - 2022-03-18 20:34:11 --> Output Class Initialized
INFO - 2022-03-18 20:34:11 --> Security Class Initialized
INFO - 2022-03-18 20:34:11 --> Input Class Initialized
INFO - 2022-03-18 20:34:11 --> Language Class Initialized
INFO - 2022-03-18 20:34:11 --> Loader Class Initialized
INFO - 2022-03-18 20:34:11 --> Helper loaded: url_helper
INFO - 2022-03-18 20:34:11 --> Helper loaded: form_helper
INFO - 2022-03-18 20:34:11 --> Database Driver Class Initialized
INFO - 2022-03-18 20:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:34:11 --> Form Validation Class Initialized
INFO - 2022-03-18 20:34:11 --> Controller Class Initialized
INFO - 2022-03-18 20:34:11 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:34:11 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:34:11 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:34:11 --> Model "M_todo_task" initialized
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Undefined variable: id C:\laragon\www\list-todo\application\controllers\C_todo_list.php 59
INFO - 2022-03-18 20:34:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:34:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Undefined property: mysqli::$task C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 47
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Undefined property: mysqli::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 50
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Undefined property: mysqli::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 53
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Undefined property: mysqli::$status C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 56
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Undefined property: mysqli_result::$task C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 47
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_mulai C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 50
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Undefined property: mysqli_result::$tgl_selesai C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 53
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Undefined property: mysqli_result::$status C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 56
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 47
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 50
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 53
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 56
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 47
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 50
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 53
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 56
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 47
ERROR - 2022-03-18 20:34:11 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 50
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 53
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 56
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 47
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 50
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 53
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 56
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 47
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 50
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 53
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 56
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 47
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 50
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 53
ERROR - 2022-03-18 20:34:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 56
INFO - 2022-03-18 20:34:12 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:34:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:34:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:34:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:34:12 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:34:12 --> Final output sent to browser
INFO - 2022-03-18 20:34:33 --> Config Class Initialized
INFO - 2022-03-18 20:34:33 --> Hooks Class Initialized
INFO - 2022-03-18 20:34:33 --> Utf8 Class Initialized
INFO - 2022-03-18 20:34:33 --> URI Class Initialized
INFO - 2022-03-18 20:34:33 --> Router Class Initialized
INFO - 2022-03-18 20:34:33 --> Output Class Initialized
INFO - 2022-03-18 20:34:33 --> Security Class Initialized
INFO - 2022-03-18 20:34:33 --> Input Class Initialized
INFO - 2022-03-18 20:34:33 --> Language Class Initialized
INFO - 2022-03-18 20:34:33 --> Loader Class Initialized
INFO - 2022-03-18 20:34:33 --> Helper loaded: url_helper
INFO - 2022-03-18 20:34:33 --> Helper loaded: form_helper
INFO - 2022-03-18 20:34:33 --> Database Driver Class Initialized
INFO - 2022-03-18 20:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:34:33 --> Form Validation Class Initialized
INFO - 2022-03-18 20:34:33 --> Controller Class Initialized
INFO - 2022-03-18 20:34:33 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:34:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:34:33 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:34:33 --> Model "M_todo_task" initialized
ERROR - 2022-03-18 20:34:33 --> Severity: Notice --> Undefined variable: id C:\laragon\www\list-todo\application\controllers\C_todo_list.php 59
INFO - 2022-03-18 20:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:34:33 --> Final output sent to browser
INFO - 2022-03-18 20:35:01 --> Config Class Initialized
INFO - 2022-03-18 20:35:01 --> Hooks Class Initialized
INFO - 2022-03-18 20:35:01 --> Utf8 Class Initialized
INFO - 2022-03-18 20:35:01 --> URI Class Initialized
INFO - 2022-03-18 20:35:01 --> Router Class Initialized
INFO - 2022-03-18 20:35:01 --> Output Class Initialized
INFO - 2022-03-18 20:35:01 --> Security Class Initialized
INFO - 2022-03-18 20:35:01 --> Input Class Initialized
INFO - 2022-03-18 20:35:01 --> Language Class Initialized
INFO - 2022-03-18 20:35:01 --> Loader Class Initialized
INFO - 2022-03-18 20:35:01 --> Helper loaded: url_helper
INFO - 2022-03-18 20:35:01 --> Helper loaded: form_helper
INFO - 2022-03-18 20:35:01 --> Database Driver Class Initialized
INFO - 2022-03-18 20:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:35:01 --> Form Validation Class Initialized
INFO - 2022-03-18 20:35:01 --> Controller Class Initialized
INFO - 2022-03-18 20:35:01 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:35:01 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:35:01 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:35:01 --> Model "M_todo_task" initialized
ERROR - 2022-03-18 20:35:01 --> Severity: Notice --> Undefined variable: id C:\laragon\www\list-todo\application\controllers\C_todo_list.php 59
INFO - 2022-03-18 20:35:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:35:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:35:01 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:35:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:35:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:35:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:35:01 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:35:01 --> Final output sent to browser
INFO - 2022-03-18 20:35:46 --> Config Class Initialized
INFO - 2022-03-18 20:35:46 --> Hooks Class Initialized
INFO - 2022-03-18 20:35:46 --> Utf8 Class Initialized
INFO - 2022-03-18 20:35:46 --> URI Class Initialized
INFO - 2022-03-18 20:35:46 --> Router Class Initialized
INFO - 2022-03-18 20:35:46 --> Output Class Initialized
INFO - 2022-03-18 20:35:46 --> Security Class Initialized
INFO - 2022-03-18 20:35:46 --> Input Class Initialized
INFO - 2022-03-18 20:35:46 --> Language Class Initialized
INFO - 2022-03-18 20:35:46 --> Loader Class Initialized
INFO - 2022-03-18 20:35:46 --> Helper loaded: url_helper
INFO - 2022-03-18 20:35:46 --> Helper loaded: form_helper
INFO - 2022-03-18 20:35:46 --> Database Driver Class Initialized
INFO - 2022-03-18 20:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:35:46 --> Form Validation Class Initialized
INFO - 2022-03-18 20:35:46 --> Controller Class Initialized
INFO - 2022-03-18 20:35:46 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:35:46 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:35:46 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:35:46 --> Model "M_todo_task" initialized
ERROR - 2022-03-18 20:35:46 --> Severity: Notice --> Undefined variable: id C:\laragon\www\list-todo\application\controllers\C_todo_list.php 59
INFO - 2022-03-18 20:35:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:35:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:35:46 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:35:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:35:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:35:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:35:46 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:35:46 --> Final output sent to browser
INFO - 2022-03-18 20:36:01 --> Config Class Initialized
INFO - 2022-03-18 20:36:01 --> Hooks Class Initialized
INFO - 2022-03-18 20:36:01 --> Utf8 Class Initialized
INFO - 2022-03-18 20:36:01 --> URI Class Initialized
INFO - 2022-03-18 20:36:01 --> Router Class Initialized
INFO - 2022-03-18 20:36:01 --> Output Class Initialized
INFO - 2022-03-18 20:36:01 --> Security Class Initialized
INFO - 2022-03-18 20:36:01 --> Input Class Initialized
INFO - 2022-03-18 20:36:01 --> Language Class Initialized
INFO - 2022-03-18 20:36:01 --> Loader Class Initialized
INFO - 2022-03-18 20:36:01 --> Helper loaded: url_helper
INFO - 2022-03-18 20:36:01 --> Helper loaded: form_helper
INFO - 2022-03-18 20:36:01 --> Database Driver Class Initialized
INFO - 2022-03-18 20:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:36:01 --> Form Validation Class Initialized
INFO - 2022-03-18 20:36:01 --> Controller Class Initialized
INFO - 2022-03-18 20:36:01 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:36:01 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:36:01 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:36:01 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:36:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:36:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:36:01 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:36:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:36:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:36:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:36:01 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:36:01 --> Final output sent to browser
INFO - 2022-03-18 20:36:12 --> Config Class Initialized
INFO - 2022-03-18 20:36:12 --> Hooks Class Initialized
INFO - 2022-03-18 20:36:12 --> Utf8 Class Initialized
INFO - 2022-03-18 20:36:12 --> URI Class Initialized
INFO - 2022-03-18 20:36:12 --> Router Class Initialized
INFO - 2022-03-18 20:36:12 --> Output Class Initialized
INFO - 2022-03-18 20:36:12 --> Security Class Initialized
INFO - 2022-03-18 20:36:12 --> Input Class Initialized
INFO - 2022-03-18 20:36:12 --> Language Class Initialized
INFO - 2022-03-18 20:36:12 --> Loader Class Initialized
INFO - 2022-03-18 20:36:12 --> Helper loaded: url_helper
INFO - 2022-03-18 20:36:12 --> Helper loaded: form_helper
INFO - 2022-03-18 20:36:12 --> Database Driver Class Initialized
INFO - 2022-03-18 20:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:36:12 --> Form Validation Class Initialized
INFO - 2022-03-18 20:36:12 --> Controller Class Initialized
INFO - 2022-03-18 20:36:12 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:36:12 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:36:12 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:36:12 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:36:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:36:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 48
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 51
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 54
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 57
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 48
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 51
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 54
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 57
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 48
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 51
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 54
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 57
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 48
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 51
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 54
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 57
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 48
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 51
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 54
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 57
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 48
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 51
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 54
ERROR - 2022-03-18 20:36:12 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 57
INFO - 2022-03-18 20:36:12 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:36:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:36:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:36:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:36:12 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:36:12 --> Final output sent to browser
INFO - 2022-03-18 20:37:25 --> Config Class Initialized
INFO - 2022-03-18 20:37:25 --> Hooks Class Initialized
INFO - 2022-03-18 20:37:25 --> Utf8 Class Initialized
INFO - 2022-03-18 20:37:25 --> URI Class Initialized
INFO - 2022-03-18 20:37:25 --> Router Class Initialized
INFO - 2022-03-18 20:37:25 --> Output Class Initialized
INFO - 2022-03-18 20:37:25 --> Security Class Initialized
INFO - 2022-03-18 20:37:25 --> Input Class Initialized
INFO - 2022-03-18 20:37:25 --> Language Class Initialized
INFO - 2022-03-18 20:37:25 --> Loader Class Initialized
INFO - 2022-03-18 20:37:25 --> Helper loaded: url_helper
INFO - 2022-03-18 20:37:25 --> Helper loaded: form_helper
INFO - 2022-03-18 20:37:25 --> Database Driver Class Initialized
INFO - 2022-03-18 20:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:37:26 --> Form Validation Class Initialized
INFO - 2022-03-18 20:37:26 --> Controller Class Initialized
INFO - 2022-03-18 20:37:26 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:37:26 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:37:26 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:37:26 --> Model "M_todo_task" initialized
ERROR - 2022-03-18 20:37:26 --> Severity: Error --> Call to a member function row_array() on array C:\laragon\www\list-todo\application\controllers\C_todo_list.php 59
INFO - 2022-03-18 20:37:37 --> Config Class Initialized
INFO - 2022-03-18 20:37:37 --> Hooks Class Initialized
INFO - 2022-03-18 20:37:37 --> Utf8 Class Initialized
INFO - 2022-03-18 20:37:37 --> URI Class Initialized
INFO - 2022-03-18 20:37:37 --> Router Class Initialized
INFO - 2022-03-18 20:37:37 --> Output Class Initialized
INFO - 2022-03-18 20:37:37 --> Security Class Initialized
INFO - 2022-03-18 20:37:37 --> Input Class Initialized
INFO - 2022-03-18 20:37:37 --> Language Class Initialized
INFO - 2022-03-18 20:37:37 --> Loader Class Initialized
INFO - 2022-03-18 20:37:37 --> Helper loaded: url_helper
INFO - 2022-03-18 20:37:37 --> Helper loaded: form_helper
INFO - 2022-03-18 20:37:37 --> Database Driver Class Initialized
INFO - 2022-03-18 20:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:37:37 --> Form Validation Class Initialized
INFO - 2022-03-18 20:37:37 --> Controller Class Initialized
INFO - 2022-03-18 20:37:37 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:37:37 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:37:37 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:37:37 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:37:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:37:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:37:37 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:37:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:37:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:37:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:37:37 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:37:37 --> Final output sent to browser
INFO - 2022-03-18 20:38:59 --> Config Class Initialized
INFO - 2022-03-18 20:38:59 --> Hooks Class Initialized
INFO - 2022-03-18 20:38:59 --> Utf8 Class Initialized
INFO - 2022-03-18 20:38:59 --> URI Class Initialized
INFO - 2022-03-18 20:38:59 --> Router Class Initialized
INFO - 2022-03-18 20:38:59 --> Output Class Initialized
INFO - 2022-03-18 20:38:59 --> Security Class Initialized
INFO - 2022-03-18 20:38:59 --> Input Class Initialized
INFO - 2022-03-18 20:38:59 --> Language Class Initialized
INFO - 2022-03-18 20:39:00 --> Loader Class Initialized
INFO - 2022-03-18 20:39:00 --> Helper loaded: url_helper
INFO - 2022-03-18 20:39:00 --> Helper loaded: form_helper
INFO - 2022-03-18 20:39:00 --> Database Driver Class Initialized
INFO - 2022-03-18 20:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:39:00 --> Form Validation Class Initialized
INFO - 2022-03-18 20:39:00 --> Controller Class Initialized
INFO - 2022-03-18 20:39:00 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:39:00 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:39:00 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:39:00 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:39:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:39:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:39:00 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:39:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:39:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:39:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:39:00 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:39:00 --> Final output sent to browser
INFO - 2022-03-18 20:40:39 --> Config Class Initialized
INFO - 2022-03-18 20:40:39 --> Hooks Class Initialized
INFO - 2022-03-18 20:40:39 --> Utf8 Class Initialized
INFO - 2022-03-18 20:40:39 --> URI Class Initialized
INFO - 2022-03-18 20:40:39 --> Router Class Initialized
INFO - 2022-03-18 20:40:39 --> Output Class Initialized
INFO - 2022-03-18 20:40:39 --> Security Class Initialized
INFO - 2022-03-18 20:40:39 --> Input Class Initialized
INFO - 2022-03-18 20:40:39 --> Language Class Initialized
INFO - 2022-03-18 20:40:39 --> Loader Class Initialized
INFO - 2022-03-18 20:40:39 --> Helper loaded: url_helper
INFO - 2022-03-18 20:40:39 --> Helper loaded: form_helper
INFO - 2022-03-18 20:40:39 --> Database Driver Class Initialized
INFO - 2022-03-18 20:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:40:39 --> Form Validation Class Initialized
INFO - 2022-03-18 20:40:39 --> Controller Class Initialized
INFO - 2022-03-18 20:40:39 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:40:39 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:40:39 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:40:39 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:40:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:40:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-18 20:40:39 --> Severity: Error --> Cannot use object of type CI_DB_mysqli_result as array C:\laragon\www\list-todo\application\views\todo_list\v_todo_task.php 2
INFO - 2022-03-18 20:40:51 --> Config Class Initialized
INFO - 2022-03-18 20:40:51 --> Hooks Class Initialized
INFO - 2022-03-18 20:40:51 --> Utf8 Class Initialized
INFO - 2022-03-18 20:40:51 --> URI Class Initialized
INFO - 2022-03-18 20:40:51 --> Router Class Initialized
INFO - 2022-03-18 20:40:51 --> Output Class Initialized
INFO - 2022-03-18 20:40:51 --> Security Class Initialized
INFO - 2022-03-18 20:40:51 --> Input Class Initialized
INFO - 2022-03-18 20:40:51 --> Language Class Initialized
INFO - 2022-03-18 20:40:51 --> Loader Class Initialized
INFO - 2022-03-18 20:40:51 --> Helper loaded: url_helper
INFO - 2022-03-18 20:40:51 --> Helper loaded: form_helper
INFO - 2022-03-18 20:40:51 --> Database Driver Class Initialized
INFO - 2022-03-18 20:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:40:51 --> Form Validation Class Initialized
INFO - 2022-03-18 20:40:51 --> Controller Class Initialized
INFO - 2022-03-18 20:40:51 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:40:51 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:40:51 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:40:51 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:40:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:40:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:40:51 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:40:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:40:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:40:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:40:51 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:40:51 --> Final output sent to browser
INFO - 2022-03-18 20:41:05 --> Config Class Initialized
INFO - 2022-03-18 20:41:05 --> Hooks Class Initialized
INFO - 2022-03-18 20:41:05 --> Utf8 Class Initialized
INFO - 2022-03-18 20:41:05 --> URI Class Initialized
INFO - 2022-03-18 20:41:05 --> Router Class Initialized
INFO - 2022-03-18 20:41:05 --> Output Class Initialized
INFO - 2022-03-18 20:41:05 --> Security Class Initialized
INFO - 2022-03-18 20:41:05 --> Input Class Initialized
INFO - 2022-03-18 20:41:05 --> Language Class Initialized
INFO - 2022-03-18 20:41:05 --> Loader Class Initialized
INFO - 2022-03-18 20:41:05 --> Helper loaded: url_helper
INFO - 2022-03-18 20:41:05 --> Helper loaded: form_helper
INFO - 2022-03-18 20:41:05 --> Database Driver Class Initialized
INFO - 2022-03-18 20:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:41:05 --> Form Validation Class Initialized
INFO - 2022-03-18 20:41:05 --> Controller Class Initialized
INFO - 2022-03-18 20:41:05 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:41:05 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:41:05 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:41:05 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:41:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:41:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:41:05 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:41:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:41:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:41:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:41:05 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:41:05 --> Final output sent to browser
INFO - 2022-03-18 20:41:47 --> Config Class Initialized
INFO - 2022-03-18 20:41:47 --> Hooks Class Initialized
INFO - 2022-03-18 20:41:47 --> Utf8 Class Initialized
INFO - 2022-03-18 20:41:47 --> URI Class Initialized
INFO - 2022-03-18 20:41:47 --> Router Class Initialized
INFO - 2022-03-18 20:41:47 --> Output Class Initialized
INFO - 2022-03-18 20:41:47 --> Security Class Initialized
INFO - 2022-03-18 20:41:47 --> Input Class Initialized
INFO - 2022-03-18 20:41:47 --> Language Class Initialized
INFO - 2022-03-18 20:41:47 --> Loader Class Initialized
INFO - 2022-03-18 20:41:47 --> Helper loaded: url_helper
INFO - 2022-03-18 20:41:47 --> Helper loaded: form_helper
INFO - 2022-03-18 20:41:47 --> Database Driver Class Initialized
INFO - 2022-03-18 20:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:41:47 --> Form Validation Class Initialized
INFO - 2022-03-18 20:41:47 --> Controller Class Initialized
INFO - 2022-03-18 20:41:47 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:41:47 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:41:47 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:41:47 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:41:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:41:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:41:47 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:41:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:41:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:41:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:41:47 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:41:47 --> Final output sent to browser
INFO - 2022-03-18 20:41:59 --> Config Class Initialized
INFO - 2022-03-18 20:41:59 --> Hooks Class Initialized
INFO - 2022-03-18 20:41:59 --> Utf8 Class Initialized
INFO - 2022-03-18 20:41:59 --> URI Class Initialized
INFO - 2022-03-18 20:41:59 --> Router Class Initialized
INFO - 2022-03-18 20:41:59 --> Output Class Initialized
INFO - 2022-03-18 20:41:59 --> Security Class Initialized
INFO - 2022-03-18 20:41:59 --> Input Class Initialized
INFO - 2022-03-18 20:41:59 --> Language Class Initialized
INFO - 2022-03-18 20:41:59 --> Loader Class Initialized
INFO - 2022-03-18 20:41:59 --> Helper loaded: url_helper
INFO - 2022-03-18 20:41:59 --> Helper loaded: form_helper
INFO - 2022-03-18 20:41:59 --> Database Driver Class Initialized
INFO - 2022-03-18 20:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:41:59 --> Form Validation Class Initialized
INFO - 2022-03-18 20:41:59 --> Controller Class Initialized
INFO - 2022-03-18 20:41:59 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:41:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:41:59 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:41:59 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:41:59 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:41:59 --> Final output sent to browser
INFO - 2022-03-18 20:52:26 --> Config Class Initialized
INFO - 2022-03-18 20:52:26 --> Hooks Class Initialized
INFO - 2022-03-18 20:52:26 --> Utf8 Class Initialized
INFO - 2022-03-18 20:52:26 --> URI Class Initialized
INFO - 2022-03-18 20:52:26 --> Router Class Initialized
INFO - 2022-03-18 20:52:26 --> Output Class Initialized
INFO - 2022-03-18 20:52:26 --> Security Class Initialized
INFO - 2022-03-18 20:52:26 --> Input Class Initialized
INFO - 2022-03-18 20:52:26 --> Language Class Initialized
INFO - 2022-03-18 20:52:26 --> Loader Class Initialized
INFO - 2022-03-18 20:52:26 --> Helper loaded: url_helper
INFO - 2022-03-18 20:52:26 --> Helper loaded: form_helper
INFO - 2022-03-18 20:52:26 --> Database Driver Class Initialized
INFO - 2022-03-18 20:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:52:26 --> Form Validation Class Initialized
INFO - 2022-03-18 20:52:26 --> Controller Class Initialized
INFO - 2022-03-18 20:52:26 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:52:26 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:52:26 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:52:26 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:52:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:52:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:52:26 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:52:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:52:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:52:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:52:26 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:52:26 --> Final output sent to browser
INFO - 2022-03-18 20:55:04 --> Config Class Initialized
INFO - 2022-03-18 20:55:04 --> Hooks Class Initialized
INFO - 2022-03-18 20:55:04 --> Utf8 Class Initialized
INFO - 2022-03-18 20:55:04 --> URI Class Initialized
INFO - 2022-03-18 20:55:04 --> Router Class Initialized
INFO - 2022-03-18 20:55:04 --> Output Class Initialized
INFO - 2022-03-18 20:55:04 --> Security Class Initialized
INFO - 2022-03-18 20:55:04 --> Input Class Initialized
INFO - 2022-03-18 20:55:04 --> Language Class Initialized
INFO - 2022-03-18 20:55:04 --> Loader Class Initialized
INFO - 2022-03-18 20:55:04 --> Helper loaded: url_helper
INFO - 2022-03-18 20:55:04 --> Helper loaded: form_helper
INFO - 2022-03-18 20:55:04 --> Database Driver Class Initialized
INFO - 2022-03-18 20:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:55:04 --> Form Validation Class Initialized
INFO - 2022-03-18 20:55:04 --> Controller Class Initialized
INFO - 2022-03-18 20:55:04 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:55:04 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:55:04 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:55:04 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:55:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:55:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:55:04 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:55:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:55:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:55:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:55:04 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:55:04 --> Final output sent to browser
INFO - 2022-03-18 20:55:42 --> Config Class Initialized
INFO - 2022-03-18 20:55:42 --> Hooks Class Initialized
INFO - 2022-03-18 20:55:42 --> Utf8 Class Initialized
INFO - 2022-03-18 20:55:42 --> URI Class Initialized
INFO - 2022-03-18 20:55:42 --> Router Class Initialized
INFO - 2022-03-18 20:55:42 --> Output Class Initialized
INFO - 2022-03-18 20:55:42 --> Security Class Initialized
INFO - 2022-03-18 20:55:42 --> Input Class Initialized
INFO - 2022-03-18 20:55:42 --> Language Class Initialized
INFO - 2022-03-18 20:55:42 --> Loader Class Initialized
INFO - 2022-03-18 20:55:42 --> Helper loaded: url_helper
INFO - 2022-03-18 20:55:42 --> Helper loaded: form_helper
INFO - 2022-03-18 20:55:42 --> Database Driver Class Initialized
INFO - 2022-03-18 20:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:55:42 --> Form Validation Class Initialized
INFO - 2022-03-18 20:55:42 --> Controller Class Initialized
INFO - 2022-03-18 20:55:42 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:55:42 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:55:42 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:55:42 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:55:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:55:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:55:42 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:55:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:55:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:55:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:55:42 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:55:42 --> Final output sent to browser
INFO - 2022-03-18 20:56:54 --> Config Class Initialized
INFO - 2022-03-18 20:56:54 --> Hooks Class Initialized
INFO - 2022-03-18 20:56:54 --> Utf8 Class Initialized
INFO - 2022-03-18 20:56:54 --> URI Class Initialized
INFO - 2022-03-18 20:56:54 --> Router Class Initialized
INFO - 2022-03-18 20:56:54 --> Output Class Initialized
INFO - 2022-03-18 20:56:54 --> Security Class Initialized
INFO - 2022-03-18 20:56:55 --> Input Class Initialized
INFO - 2022-03-18 20:56:55 --> Language Class Initialized
INFO - 2022-03-18 20:56:55 --> Loader Class Initialized
INFO - 2022-03-18 20:56:55 --> Helper loaded: url_helper
INFO - 2022-03-18 20:56:55 --> Helper loaded: form_helper
INFO - 2022-03-18 20:56:55 --> Database Driver Class Initialized
INFO - 2022-03-18 20:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:56:55 --> Form Validation Class Initialized
INFO - 2022-03-18 20:56:55 --> Controller Class Initialized
INFO - 2022-03-18 20:56:55 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:56:55 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:56:55 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:56:55 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:56:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:56:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:56:55 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:56:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:56:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:56:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:56:55 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:56:55 --> Final output sent to browser
INFO - 2022-03-18 20:57:11 --> Config Class Initialized
INFO - 2022-03-18 20:57:11 --> Hooks Class Initialized
INFO - 2022-03-18 20:57:11 --> Utf8 Class Initialized
INFO - 2022-03-18 20:57:11 --> URI Class Initialized
INFO - 2022-03-18 20:57:11 --> Router Class Initialized
INFO - 2022-03-18 20:57:11 --> Output Class Initialized
INFO - 2022-03-18 20:57:11 --> Security Class Initialized
INFO - 2022-03-18 20:57:11 --> Input Class Initialized
INFO - 2022-03-18 20:57:11 --> Language Class Initialized
INFO - 2022-03-18 20:57:11 --> Loader Class Initialized
INFO - 2022-03-18 20:57:11 --> Helper loaded: url_helper
INFO - 2022-03-18 20:57:11 --> Helper loaded: form_helper
INFO - 2022-03-18 20:57:11 --> Database Driver Class Initialized
INFO - 2022-03-18 20:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:57:11 --> Form Validation Class Initialized
INFO - 2022-03-18 20:57:11 --> Controller Class Initialized
INFO - 2022-03-18 20:57:11 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:57:11 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:57:11 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:57:11 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:57:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:57:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:57:11 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:57:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:57:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:57:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:57:11 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:57:11 --> Final output sent to browser
INFO - 2022-03-18 20:57:40 --> Config Class Initialized
INFO - 2022-03-18 20:57:40 --> Hooks Class Initialized
INFO - 2022-03-18 20:57:40 --> Utf8 Class Initialized
INFO - 2022-03-18 20:57:40 --> URI Class Initialized
INFO - 2022-03-18 20:57:40 --> Router Class Initialized
INFO - 2022-03-18 20:57:40 --> Output Class Initialized
INFO - 2022-03-18 20:57:40 --> Security Class Initialized
INFO - 2022-03-18 20:57:40 --> Input Class Initialized
INFO - 2022-03-18 20:57:40 --> Language Class Initialized
INFO - 2022-03-18 20:57:40 --> Loader Class Initialized
INFO - 2022-03-18 20:57:40 --> Helper loaded: url_helper
INFO - 2022-03-18 20:57:40 --> Helper loaded: form_helper
INFO - 2022-03-18 20:57:40 --> Database Driver Class Initialized
INFO - 2022-03-18 20:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:57:40 --> Form Validation Class Initialized
INFO - 2022-03-18 20:57:40 --> Controller Class Initialized
INFO - 2022-03-18 20:57:40 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:57:40 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:57:40 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:57:40 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:57:40 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:57:40 --> Final output sent to browser
INFO - 2022-03-18 20:58:17 --> Config Class Initialized
INFO - 2022-03-18 20:58:17 --> Hooks Class Initialized
INFO - 2022-03-18 20:58:17 --> Utf8 Class Initialized
INFO - 2022-03-18 20:58:17 --> URI Class Initialized
INFO - 2022-03-18 20:58:17 --> Router Class Initialized
INFO - 2022-03-18 20:58:17 --> Output Class Initialized
INFO - 2022-03-18 20:58:17 --> Security Class Initialized
INFO - 2022-03-18 20:58:17 --> Input Class Initialized
INFO - 2022-03-18 20:58:17 --> Language Class Initialized
INFO - 2022-03-18 20:58:17 --> Loader Class Initialized
INFO - 2022-03-18 20:58:17 --> Helper loaded: url_helper
INFO - 2022-03-18 20:58:17 --> Helper loaded: form_helper
INFO - 2022-03-18 20:58:17 --> Database Driver Class Initialized
INFO - 2022-03-18 20:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 20:58:17 --> Form Validation Class Initialized
INFO - 2022-03-18 20:58:17 --> Controller Class Initialized
INFO - 2022-03-18 20:58:17 --> Model "M_todo_list" initialized
INFO - 2022-03-18 20:58:17 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 20:58:17 --> Model "M_todo_group" initialized
INFO - 2022-03-18 20:58:17 --> Model "M_todo_task" initialized
INFO - 2022-03-18 20:58:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 20:58:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 20:58:17 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 20:58:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 20:58:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 20:58:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 20:58:17 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 20:58:17 --> Final output sent to browser
INFO - 2022-03-18 21:00:35 --> Config Class Initialized
INFO - 2022-03-18 21:00:35 --> Hooks Class Initialized
INFO - 2022-03-18 21:00:35 --> Utf8 Class Initialized
INFO - 2022-03-18 21:00:35 --> URI Class Initialized
INFO - 2022-03-18 21:00:35 --> Router Class Initialized
INFO - 2022-03-18 21:00:35 --> Output Class Initialized
INFO - 2022-03-18 21:00:35 --> Security Class Initialized
INFO - 2022-03-18 21:00:35 --> Input Class Initialized
INFO - 2022-03-18 21:00:35 --> Language Class Initialized
INFO - 2022-03-18 21:00:35 --> Loader Class Initialized
INFO - 2022-03-18 21:00:35 --> Helper loaded: url_helper
INFO - 2022-03-18 21:00:35 --> Helper loaded: form_helper
INFO - 2022-03-18 21:00:35 --> Database Driver Class Initialized
INFO - 2022-03-18 21:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 21:00:35 --> Form Validation Class Initialized
INFO - 2022-03-18 21:00:35 --> Controller Class Initialized
INFO - 2022-03-18 21:00:35 --> Model "M_todo_list" initialized
INFO - 2022-03-18 21:00:35 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 21:00:35 --> Model "M_todo_group" initialized
INFO - 2022-03-18 21:00:35 --> Model "M_todo_task" initialized
INFO - 2022-03-18 21:00:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 21:00:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 21:00:35 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 21:00:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 21:00:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 21:00:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 21:00:35 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 21:00:35 --> Final output sent to browser
INFO - 2022-03-18 21:00:51 --> Config Class Initialized
INFO - 2022-03-18 21:00:51 --> Hooks Class Initialized
INFO - 2022-03-18 21:00:51 --> Utf8 Class Initialized
INFO - 2022-03-18 21:00:51 --> URI Class Initialized
INFO - 2022-03-18 21:00:51 --> Router Class Initialized
INFO - 2022-03-18 21:00:51 --> Output Class Initialized
INFO - 2022-03-18 21:00:51 --> Security Class Initialized
INFO - 2022-03-18 21:00:51 --> Input Class Initialized
INFO - 2022-03-18 21:00:51 --> Language Class Initialized
INFO - 2022-03-18 21:00:51 --> Loader Class Initialized
INFO - 2022-03-18 21:00:51 --> Helper loaded: url_helper
INFO - 2022-03-18 21:00:51 --> Helper loaded: form_helper
INFO - 2022-03-18 21:00:51 --> Database Driver Class Initialized
INFO - 2022-03-18 21:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 21:00:51 --> Form Validation Class Initialized
INFO - 2022-03-18 21:00:51 --> Controller Class Initialized
INFO - 2022-03-18 21:00:51 --> Model "M_todo_list" initialized
INFO - 2022-03-18 21:00:51 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 21:00:51 --> Model "M_todo_group" initialized
INFO - 2022-03-18 21:00:51 --> Model "M_todo_task" initialized
INFO - 2022-03-18 21:00:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 21:00:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 21:00:51 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 21:00:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 21:00:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 21:00:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 21:00:51 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 21:00:51 --> Final output sent to browser
INFO - 2022-03-18 21:01:05 --> Config Class Initialized
INFO - 2022-03-18 21:01:05 --> Hooks Class Initialized
INFO - 2022-03-18 21:01:05 --> Utf8 Class Initialized
INFO - 2022-03-18 21:01:05 --> URI Class Initialized
INFO - 2022-03-18 21:01:05 --> Router Class Initialized
INFO - 2022-03-18 21:01:05 --> Output Class Initialized
INFO - 2022-03-18 21:01:05 --> Security Class Initialized
INFO - 2022-03-18 21:01:05 --> Input Class Initialized
INFO - 2022-03-18 21:01:05 --> Language Class Initialized
INFO - 2022-03-18 21:01:05 --> Loader Class Initialized
INFO - 2022-03-18 21:01:05 --> Helper loaded: url_helper
INFO - 2022-03-18 21:01:05 --> Helper loaded: form_helper
INFO - 2022-03-18 21:01:05 --> Database Driver Class Initialized
INFO - 2022-03-18 21:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 21:01:05 --> Form Validation Class Initialized
INFO - 2022-03-18 21:01:05 --> Controller Class Initialized
INFO - 2022-03-18 21:01:05 --> Model "M_todo_list" initialized
INFO - 2022-03-18 21:01:05 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 21:01:05 --> Model "M_todo_group" initialized
INFO - 2022-03-18 21:01:05 --> Model "M_todo_task" initialized
INFO - 2022-03-18 21:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 21:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 21:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 21:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 21:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 21:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 21:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 21:01:05 --> Final output sent to browser
INFO - 2022-03-18 21:01:24 --> Config Class Initialized
INFO - 2022-03-18 21:01:24 --> Hooks Class Initialized
INFO - 2022-03-18 21:01:24 --> Utf8 Class Initialized
INFO - 2022-03-18 21:01:24 --> URI Class Initialized
INFO - 2022-03-18 21:01:24 --> Router Class Initialized
INFO - 2022-03-18 21:01:24 --> Output Class Initialized
INFO - 2022-03-18 21:01:24 --> Security Class Initialized
INFO - 2022-03-18 21:01:24 --> Input Class Initialized
INFO - 2022-03-18 21:01:24 --> Language Class Initialized
INFO - 2022-03-18 21:01:24 --> Loader Class Initialized
INFO - 2022-03-18 21:01:24 --> Helper loaded: url_helper
INFO - 2022-03-18 21:01:24 --> Helper loaded: form_helper
INFO - 2022-03-18 21:01:24 --> Database Driver Class Initialized
INFO - 2022-03-18 21:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 21:01:24 --> Form Validation Class Initialized
INFO - 2022-03-18 21:01:24 --> Controller Class Initialized
INFO - 2022-03-18 21:01:24 --> Model "M_todo_list" initialized
INFO - 2022-03-18 21:01:24 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 21:01:24 --> Model "M_todo_group" initialized
INFO - 2022-03-18 21:01:24 --> Model "M_todo_task" initialized
INFO - 2022-03-18 21:01:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 21:01:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 21:01:24 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 21:01:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 21:01:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 21:01:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 21:01:24 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 21:01:24 --> Final output sent to browser
INFO - 2022-03-18 21:01:54 --> Config Class Initialized
INFO - 2022-03-18 21:01:54 --> Hooks Class Initialized
INFO - 2022-03-18 21:01:54 --> Utf8 Class Initialized
INFO - 2022-03-18 21:01:54 --> URI Class Initialized
INFO - 2022-03-18 21:01:54 --> Router Class Initialized
INFO - 2022-03-18 21:01:54 --> Output Class Initialized
INFO - 2022-03-18 21:01:54 --> Security Class Initialized
INFO - 2022-03-18 21:01:54 --> Input Class Initialized
INFO - 2022-03-18 21:01:54 --> Language Class Initialized
INFO - 2022-03-18 21:01:54 --> Loader Class Initialized
INFO - 2022-03-18 21:01:54 --> Helper loaded: url_helper
INFO - 2022-03-18 21:01:54 --> Helper loaded: form_helper
INFO - 2022-03-18 21:01:54 --> Database Driver Class Initialized
INFO - 2022-03-18 21:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 21:01:54 --> Form Validation Class Initialized
INFO - 2022-03-18 21:01:54 --> Controller Class Initialized
INFO - 2022-03-18 21:01:54 --> Model "M_todo_list" initialized
INFO - 2022-03-18 21:01:54 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 21:01:54 --> Model "M_todo_group" initialized
INFO - 2022-03-18 21:01:54 --> Model "M_todo_task" initialized
INFO - 2022-03-18 21:01:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 21:01:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 21:01:54 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 21:01:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 21:01:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 21:01:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 21:01:54 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 21:01:54 --> Final output sent to browser
INFO - 2022-03-18 21:02:16 --> Config Class Initialized
INFO - 2022-03-18 21:02:16 --> Hooks Class Initialized
INFO - 2022-03-18 21:02:16 --> Utf8 Class Initialized
INFO - 2022-03-18 21:02:16 --> URI Class Initialized
INFO - 2022-03-18 21:02:16 --> Router Class Initialized
INFO - 2022-03-18 21:02:16 --> Output Class Initialized
INFO - 2022-03-18 21:02:16 --> Security Class Initialized
INFO - 2022-03-18 21:02:16 --> Input Class Initialized
INFO - 2022-03-18 21:02:16 --> Language Class Initialized
INFO - 2022-03-18 21:02:16 --> Loader Class Initialized
INFO - 2022-03-18 21:02:16 --> Helper loaded: url_helper
INFO - 2022-03-18 21:02:16 --> Helper loaded: form_helper
INFO - 2022-03-18 21:02:16 --> Database Driver Class Initialized
INFO - 2022-03-18 21:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 21:02:16 --> Form Validation Class Initialized
INFO - 2022-03-18 21:02:16 --> Controller Class Initialized
INFO - 2022-03-18 21:02:16 --> Model "M_todo_list" initialized
INFO - 2022-03-18 21:02:16 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 21:02:16 --> Model "M_todo_group" initialized
INFO - 2022-03-18 21:02:16 --> Model "M_todo_task" initialized
INFO - 2022-03-18 21:02:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 21:02:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 21:02:16 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 21:02:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 21:02:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 21:02:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 21:02:16 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 21:02:16 --> Final output sent to browser
INFO - 2022-03-18 21:02:50 --> Config Class Initialized
INFO - 2022-03-18 21:02:50 --> Hooks Class Initialized
INFO - 2022-03-18 21:02:50 --> Utf8 Class Initialized
INFO - 2022-03-18 21:02:50 --> URI Class Initialized
INFO - 2022-03-18 21:02:50 --> Router Class Initialized
INFO - 2022-03-18 21:02:50 --> Output Class Initialized
INFO - 2022-03-18 21:02:50 --> Security Class Initialized
INFO - 2022-03-18 21:02:50 --> Input Class Initialized
INFO - 2022-03-18 21:02:50 --> Language Class Initialized
INFO - 2022-03-18 21:02:50 --> Loader Class Initialized
INFO - 2022-03-18 21:02:50 --> Helper loaded: url_helper
INFO - 2022-03-18 21:02:50 --> Helper loaded: form_helper
INFO - 2022-03-18 21:02:50 --> Database Driver Class Initialized
INFO - 2022-03-18 21:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 21:02:50 --> Form Validation Class Initialized
INFO - 2022-03-18 21:02:50 --> Controller Class Initialized
INFO - 2022-03-18 21:02:50 --> Model "M_todo_list" initialized
INFO - 2022-03-18 21:02:50 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 21:02:50 --> Model "M_todo_group" initialized
INFO - 2022-03-18 21:02:50 --> Model "M_todo_task" initialized
INFO - 2022-03-18 21:02:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 21:02:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 21:02:50 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 21:02:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 21:02:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 21:02:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 21:02:50 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 21:02:50 --> Final output sent to browser
INFO - 2022-03-18 21:03:03 --> Config Class Initialized
INFO - 2022-03-18 21:03:03 --> Hooks Class Initialized
INFO - 2022-03-18 21:03:03 --> Utf8 Class Initialized
INFO - 2022-03-18 21:03:03 --> URI Class Initialized
INFO - 2022-03-18 21:03:03 --> Router Class Initialized
INFO - 2022-03-18 21:03:03 --> Output Class Initialized
INFO - 2022-03-18 21:03:03 --> Security Class Initialized
INFO - 2022-03-18 21:03:03 --> Input Class Initialized
INFO - 2022-03-18 21:03:03 --> Language Class Initialized
INFO - 2022-03-18 21:03:03 --> Loader Class Initialized
INFO - 2022-03-18 21:03:03 --> Helper loaded: url_helper
INFO - 2022-03-18 21:03:03 --> Helper loaded: form_helper
INFO - 2022-03-18 21:03:03 --> Database Driver Class Initialized
INFO - 2022-03-18 21:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 21:03:03 --> Form Validation Class Initialized
INFO - 2022-03-18 21:03:03 --> Controller Class Initialized
INFO - 2022-03-18 21:03:03 --> Model "M_todo_list" initialized
INFO - 2022-03-18 21:03:03 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 21:03:03 --> Model "M_todo_group" initialized
INFO - 2022-03-18 21:03:03 --> Model "M_todo_task" initialized
INFO - 2022-03-18 21:03:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 21:03:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 21:03:03 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 21:03:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 21:03:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 21:03:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 21:03:03 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 21:03:03 --> Final output sent to browser
INFO - 2022-03-18 21:04:46 --> Config Class Initialized
INFO - 2022-03-18 21:04:46 --> Hooks Class Initialized
INFO - 2022-03-18 21:04:46 --> Utf8 Class Initialized
INFO - 2022-03-18 21:04:46 --> URI Class Initialized
INFO - 2022-03-18 21:04:46 --> Router Class Initialized
INFO - 2022-03-18 21:04:46 --> Output Class Initialized
INFO - 2022-03-18 21:04:46 --> Security Class Initialized
INFO - 2022-03-18 21:04:46 --> Input Class Initialized
INFO - 2022-03-18 21:04:46 --> Language Class Initialized
INFO - 2022-03-18 21:04:46 --> Loader Class Initialized
INFO - 2022-03-18 21:04:46 --> Helper loaded: url_helper
INFO - 2022-03-18 21:04:46 --> Helper loaded: form_helper
INFO - 2022-03-18 21:04:46 --> Database Driver Class Initialized
INFO - 2022-03-18 21:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 21:04:46 --> Form Validation Class Initialized
INFO - 2022-03-18 21:04:46 --> Controller Class Initialized
INFO - 2022-03-18 21:04:46 --> Model "M_todo_list" initialized
INFO - 2022-03-18 21:04:46 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 21:04:46 --> Model "M_todo_group" initialized
INFO - 2022-03-18 21:04:46 --> Model "M_todo_task" initialized
INFO - 2022-03-18 21:04:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 21:04:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 21:04:46 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 21:04:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 21:04:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 21:04:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 21:04:46 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 21:04:46 --> Final output sent to browser
INFO - 2022-03-18 21:05:23 --> Config Class Initialized
INFO - 2022-03-18 21:05:23 --> Hooks Class Initialized
INFO - 2022-03-18 21:05:23 --> Utf8 Class Initialized
INFO - 2022-03-18 21:05:23 --> URI Class Initialized
INFO - 2022-03-18 21:05:24 --> Router Class Initialized
INFO - 2022-03-18 21:05:24 --> Output Class Initialized
INFO - 2022-03-18 21:05:24 --> Security Class Initialized
INFO - 2022-03-18 21:05:24 --> Input Class Initialized
INFO - 2022-03-18 21:05:24 --> Language Class Initialized
INFO - 2022-03-18 21:05:24 --> Loader Class Initialized
INFO - 2022-03-18 21:05:24 --> Helper loaded: url_helper
INFO - 2022-03-18 21:05:24 --> Helper loaded: form_helper
INFO - 2022-03-18 21:05:24 --> Database Driver Class Initialized
INFO - 2022-03-18 21:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 21:05:24 --> Form Validation Class Initialized
INFO - 2022-03-18 21:05:24 --> Controller Class Initialized
INFO - 2022-03-18 21:05:24 --> Model "M_todo_list" initialized
INFO - 2022-03-18 21:05:24 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 21:05:24 --> Model "M_todo_group" initialized
INFO - 2022-03-18 21:05:24 --> Model "M_todo_task" initialized
INFO - 2022-03-18 21:05:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 21:05:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 21:05:24 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 21:05:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 21:05:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 21:05:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 21:05:24 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 21:05:24 --> Final output sent to browser
INFO - 2022-03-18 21:05:36 --> Config Class Initialized
INFO - 2022-03-18 21:05:36 --> Hooks Class Initialized
INFO - 2022-03-18 21:05:36 --> Utf8 Class Initialized
INFO - 2022-03-18 21:05:36 --> URI Class Initialized
INFO - 2022-03-18 21:05:36 --> Router Class Initialized
INFO - 2022-03-18 21:05:36 --> Output Class Initialized
INFO - 2022-03-18 21:05:36 --> Security Class Initialized
INFO - 2022-03-18 21:05:36 --> Input Class Initialized
INFO - 2022-03-18 21:05:36 --> Language Class Initialized
INFO - 2022-03-18 21:05:36 --> Loader Class Initialized
INFO - 2022-03-18 21:05:36 --> Helper loaded: url_helper
INFO - 2022-03-18 21:05:36 --> Helper loaded: form_helper
INFO - 2022-03-18 21:05:36 --> Database Driver Class Initialized
INFO - 2022-03-18 21:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 21:05:36 --> Form Validation Class Initialized
INFO - 2022-03-18 21:05:36 --> Controller Class Initialized
INFO - 2022-03-18 21:05:36 --> Model "M_todo_list" initialized
INFO - 2022-03-18 21:05:36 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-18 21:05:36 --> Model "M_todo_group" initialized
INFO - 2022-03-18 21:05:36 --> Model "M_todo_task" initialized
INFO - 2022-03-18 21:05:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-18 21:05:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-18 21:05:36 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-18 21:05:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-18 21:05:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-18 21:05:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-18 21:05:36 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-18 21:05:36 --> Final output sent to browser
