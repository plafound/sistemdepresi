<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-20 10:11:37 --> Config Class Initialized
INFO - 2023-06-20 10:11:37 --> Hooks Class Initialized
INFO - 2023-06-20 10:11:37 --> Utf8 Class Initialized
INFO - 2023-06-20 10:11:37 --> URI Class Initialized
INFO - 2023-06-20 10:11:37 --> Router Class Initialized
INFO - 2023-06-20 10:11:37 --> Output Class Initialized
INFO - 2023-06-20 10:11:37 --> Security Class Initialized
INFO - 2023-06-20 10:11:37 --> Input Class Initialized
INFO - 2023-06-20 10:11:37 --> Language Class Initialized
INFO - 2023-06-20 10:11:37 --> Loader Class Initialized
INFO - 2023-06-20 10:11:37 --> Helper loaded: url_helper
INFO - 2023-06-20 10:11:37 --> Helper loaded: form_helper
INFO - 2023-06-20 10:11:37 --> Database Driver Class Initialized
INFO - 2023-06-20 10:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:11:37 --> Form Validation Class Initialized
INFO - 2023-06-20 10:11:37 --> Controller Class Initialized
INFO - 2023-06-20 10:11:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-20 10:11:37 --> Final output sent to browser
INFO - 2023-06-20 10:11:39 --> Config Class Initialized
INFO - 2023-06-20 10:11:39 --> Hooks Class Initialized
INFO - 2023-06-20 10:11:39 --> Utf8 Class Initialized
INFO - 2023-06-20 10:11:39 --> URI Class Initialized
INFO - 2023-06-20 10:11:39 --> Router Class Initialized
INFO - 2023-06-20 10:11:39 --> Output Class Initialized
INFO - 2023-06-20 10:11:39 --> Security Class Initialized
INFO - 2023-06-20 10:11:39 --> Input Class Initialized
INFO - 2023-06-20 10:11:39 --> Language Class Initialized
INFO - 2023-06-20 10:11:39 --> Loader Class Initialized
INFO - 2023-06-20 10:11:39 --> Helper loaded: url_helper
INFO - 2023-06-20 10:11:39 --> Helper loaded: form_helper
INFO - 2023-06-20 10:11:39 --> Database Driver Class Initialized
INFO - 2023-06-20 10:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:11:39 --> Form Validation Class Initialized
INFO - 2023-06-20 10:11:39 --> Controller Class Initialized
INFO - 2023-06-20 10:11:39 --> Model "m_user" initialized
INFO - 2023-06-20 10:11:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-20 10:11:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-20 10:11:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-20 10:11:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-20 10:11:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-20 10:11:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-20 10:11:39 --> Final output sent to browser
INFO - 2023-06-20 10:11:40 --> Config Class Initialized
INFO - 2023-06-20 10:11:40 --> Hooks Class Initialized
INFO - 2023-06-20 10:11:40 --> Utf8 Class Initialized
INFO - 2023-06-20 10:11:40 --> URI Class Initialized
INFO - 2023-06-20 10:11:40 --> Router Class Initialized
INFO - 2023-06-20 10:11:40 --> Output Class Initialized
INFO - 2023-06-20 10:11:41 --> Security Class Initialized
INFO - 2023-06-20 10:11:41 --> Input Class Initialized
INFO - 2023-06-20 10:11:41 --> Language Class Initialized
INFO - 2023-06-20 10:11:41 --> Loader Class Initialized
INFO - 2023-06-20 10:11:41 --> Helper loaded: url_helper
INFO - 2023-06-20 10:11:41 --> Helper loaded: form_helper
INFO - 2023-06-20 10:11:41 --> Database Driver Class Initialized
INFO - 2023-06-20 10:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:11:41 --> Form Validation Class Initialized
INFO - 2023-06-20 10:11:41 --> Controller Class Initialized
INFO - 2023-06-20 10:11:41 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:11:41 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:11:41 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:11:41 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:11:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-20 10:11:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-20 10:11:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-20 10:11:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-20 10:11:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-20 10:11:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-20 10:11:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-20 10:11:41 --> Final output sent to browser
INFO - 2023-06-20 10:12:22 --> Config Class Initialized
INFO - 2023-06-20 10:12:22 --> Hooks Class Initialized
INFO - 2023-06-20 10:12:22 --> Utf8 Class Initialized
INFO - 2023-06-20 10:12:22 --> URI Class Initialized
INFO - 2023-06-20 10:12:22 --> Router Class Initialized
INFO - 2023-06-20 10:12:22 --> Output Class Initialized
INFO - 2023-06-20 10:12:22 --> Security Class Initialized
INFO - 2023-06-20 10:12:22 --> Input Class Initialized
INFO - 2023-06-20 10:12:22 --> Language Class Initialized
INFO - 2023-06-20 10:12:22 --> Loader Class Initialized
INFO - 2023-06-20 10:12:22 --> Helper loaded: url_helper
INFO - 2023-06-20 10:12:22 --> Helper loaded: form_helper
INFO - 2023-06-20 10:12:22 --> Database Driver Class Initialized
INFO - 2023-06-20 10:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:12:22 --> Form Validation Class Initialized
INFO - 2023-06-20 10:12:22 --> Controller Class Initialized
INFO - 2023-06-20 10:12:22 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:12:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:12:22 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:12:22 --> Model "M_solusi" initialized
ERROR - 2023-06-20 10:12:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2023
ERROR - 2023-06-20 10:12:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2024
ERROR - 2023-06-20 10:12:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2025
ERROR - 2023-06-20 10:12:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2026
INFO - 2023-06-20 10:12:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-20 10:12:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-20 10:12:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-20 10:12:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-20 10:12:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-20 10:12:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-20 10:12:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-20 10:12:23 --> Final output sent to browser
INFO - 2023-06-20 10:15:08 --> Config Class Initialized
INFO - 2023-06-20 10:15:08 --> Hooks Class Initialized
INFO - 2023-06-20 10:15:08 --> Utf8 Class Initialized
INFO - 2023-06-20 10:15:08 --> URI Class Initialized
INFO - 2023-06-20 10:15:08 --> Router Class Initialized
INFO - 2023-06-20 10:15:08 --> Output Class Initialized
INFO - 2023-06-20 10:15:08 --> Security Class Initialized
INFO - 2023-06-20 10:15:08 --> Input Class Initialized
INFO - 2023-06-20 10:15:08 --> Language Class Initialized
INFO - 2023-06-20 10:15:08 --> Loader Class Initialized
INFO - 2023-06-20 10:15:08 --> Helper loaded: url_helper
INFO - 2023-06-20 10:15:08 --> Helper loaded: form_helper
INFO - 2023-06-20 10:15:08 --> Database Driver Class Initialized
INFO - 2023-06-20 10:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:15:08 --> Form Validation Class Initialized
INFO - 2023-06-20 10:15:08 --> Controller Class Initialized
INFO - 2023-06-20 10:15:08 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:15:08 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:15:08 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:15:08 --> Model "M_solusi" initialized
ERROR - 2023-06-20 10:15:08 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2023
ERROR - 2023-06-20 10:15:08 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2024
ERROR - 2023-06-20 10:15:08 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2025
ERROR - 2023-06-20 10:15:08 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2026
INFO - 2023-06-20 10:15:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-20 10:15:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-20 10:15:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-20 10:15:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-20 10:15:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-20 10:15:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-20 10:15:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-20 10:15:08 --> Final output sent to browser
INFO - 2023-06-20 10:17:13 --> Config Class Initialized
INFO - 2023-06-20 10:17:13 --> Hooks Class Initialized
INFO - 2023-06-20 10:17:13 --> Utf8 Class Initialized
INFO - 2023-06-20 10:17:13 --> URI Class Initialized
INFO - 2023-06-20 10:17:13 --> Router Class Initialized
INFO - 2023-06-20 10:17:13 --> Output Class Initialized
INFO - 2023-06-20 10:17:13 --> Security Class Initialized
INFO - 2023-06-20 10:17:13 --> Input Class Initialized
INFO - 2023-06-20 10:17:13 --> Language Class Initialized
INFO - 2023-06-20 10:17:13 --> Loader Class Initialized
INFO - 2023-06-20 10:17:13 --> Helper loaded: url_helper
INFO - 2023-06-20 10:17:13 --> Helper loaded: form_helper
INFO - 2023-06-20 10:17:13 --> Database Driver Class Initialized
INFO - 2023-06-20 10:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:17:13 --> Form Validation Class Initialized
INFO - 2023-06-20 10:17:13 --> Controller Class Initialized
INFO - 2023-06-20 10:17:13 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:17:13 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:17:13 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:17:13 --> Model "M_solusi" initialized
ERROR - 2023-06-20 10:17:13 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2023
ERROR - 2023-06-20 10:17:13 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2024
ERROR - 2023-06-20 10:17:13 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2025
ERROR - 2023-06-20 10:17:13 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2026
INFO - 2023-06-20 10:17:13 --> Final output sent to browser
INFO - 2023-06-20 10:18:23 --> Config Class Initialized
INFO - 2023-06-20 10:18:23 --> Hooks Class Initialized
INFO - 2023-06-20 10:18:23 --> Utf8 Class Initialized
INFO - 2023-06-20 10:18:23 --> URI Class Initialized
INFO - 2023-06-20 10:18:23 --> Router Class Initialized
INFO - 2023-06-20 10:18:23 --> Output Class Initialized
INFO - 2023-06-20 10:18:23 --> Security Class Initialized
INFO - 2023-06-20 10:18:23 --> Input Class Initialized
INFO - 2023-06-20 10:18:23 --> Language Class Initialized
INFO - 2023-06-20 10:18:23 --> Loader Class Initialized
INFO - 2023-06-20 10:18:23 --> Helper loaded: url_helper
INFO - 2023-06-20 10:18:23 --> Helper loaded: form_helper
INFO - 2023-06-20 10:18:23 --> Database Driver Class Initialized
INFO - 2023-06-20 10:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:18:23 --> Form Validation Class Initialized
INFO - 2023-06-20 10:18:23 --> Controller Class Initialized
INFO - 2023-06-20 10:18:23 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:18:23 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:18:23 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:18:23 --> Model "M_solusi" initialized
ERROR - 2023-06-20 10:18:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2023
ERROR - 2023-06-20 10:18:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2024
ERROR - 2023-06-20 10:18:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2025
ERROR - 2023-06-20 10:18:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2026
INFO - 2023-06-20 10:18:23 --> Final output sent to browser
INFO - 2023-06-20 10:18:53 --> Config Class Initialized
INFO - 2023-06-20 10:18:53 --> Hooks Class Initialized
INFO - 2023-06-20 10:18:53 --> Utf8 Class Initialized
INFO - 2023-06-20 10:18:53 --> URI Class Initialized
INFO - 2023-06-20 10:18:53 --> Router Class Initialized
INFO - 2023-06-20 10:18:53 --> Output Class Initialized
INFO - 2023-06-20 10:18:53 --> Security Class Initialized
INFO - 2023-06-20 10:18:53 --> Input Class Initialized
INFO - 2023-06-20 10:18:53 --> Language Class Initialized
INFO - 2023-06-20 10:18:53 --> Loader Class Initialized
INFO - 2023-06-20 10:18:53 --> Helper loaded: url_helper
INFO - 2023-06-20 10:18:53 --> Helper loaded: form_helper
INFO - 2023-06-20 10:18:53 --> Database Driver Class Initialized
INFO - 2023-06-20 10:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:18:53 --> Form Validation Class Initialized
INFO - 2023-06-20 10:18:53 --> Controller Class Initialized
INFO - 2023-06-20 10:18:53 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:18:53 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:18:53 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:18:53 --> Model "M_solusi" initialized
ERROR - 2023-06-20 10:18:53 --> Severity: Notice --> Undefined variable: prob_GangguanMood_percent C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2028
ERROR - 2023-06-20 10:18:53 --> Severity: Notice --> Undefined variable: prob_Ringan_percent C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2029
ERROR - 2023-06-20 10:18:53 --> Severity: Notice --> Undefined variable: prob_Sedang_percent C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2030
ERROR - 2023-06-20 10:18:53 --> Severity: Notice --> Undefined variable: prob_Berat_percent C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2031
INFO - 2023-06-20 10:18:53 --> Final output sent to browser
INFO - 2023-06-20 10:19:10 --> Config Class Initialized
INFO - 2023-06-20 10:19:10 --> Hooks Class Initialized
INFO - 2023-06-20 10:19:10 --> Utf8 Class Initialized
INFO - 2023-06-20 10:19:10 --> URI Class Initialized
INFO - 2023-06-20 10:19:10 --> Router Class Initialized
INFO - 2023-06-20 10:19:10 --> Output Class Initialized
INFO - 2023-06-20 10:19:10 --> Security Class Initialized
INFO - 2023-06-20 10:19:10 --> Input Class Initialized
INFO - 2023-06-20 10:19:10 --> Language Class Initialized
INFO - 2023-06-20 10:19:10 --> Loader Class Initialized
INFO - 2023-06-20 10:19:10 --> Helper loaded: url_helper
INFO - 2023-06-20 10:19:10 --> Helper loaded: form_helper
INFO - 2023-06-20 10:19:10 --> Database Driver Class Initialized
INFO - 2023-06-20 10:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:19:10 --> Form Validation Class Initialized
INFO - 2023-06-20 10:19:10 --> Controller Class Initialized
INFO - 2023-06-20 10:19:10 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:19:10 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:19:10 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:19:10 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:19:10 --> Final output sent to browser
INFO - 2023-06-20 10:19:45 --> Config Class Initialized
INFO - 2023-06-20 10:19:45 --> Hooks Class Initialized
INFO - 2023-06-20 10:19:45 --> Utf8 Class Initialized
INFO - 2023-06-20 10:19:45 --> URI Class Initialized
INFO - 2023-06-20 10:19:45 --> Router Class Initialized
INFO - 2023-06-20 10:19:45 --> Output Class Initialized
INFO - 2023-06-20 10:19:45 --> Security Class Initialized
INFO - 2023-06-20 10:19:45 --> Input Class Initialized
INFO - 2023-06-20 10:19:45 --> Language Class Initialized
INFO - 2023-06-20 10:19:45 --> Loader Class Initialized
INFO - 2023-06-20 10:19:45 --> Helper loaded: url_helper
INFO - 2023-06-20 10:19:45 --> Helper loaded: form_helper
INFO - 2023-06-20 10:19:45 --> Database Driver Class Initialized
INFO - 2023-06-20 10:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:19:45 --> Form Validation Class Initialized
INFO - 2023-06-20 10:19:45 --> Controller Class Initialized
INFO - 2023-06-20 10:19:45 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:19:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:19:45 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:19:45 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:19:45 --> Final output sent to browser
INFO - 2023-06-20 10:20:02 --> Config Class Initialized
INFO - 2023-06-20 10:20:02 --> Hooks Class Initialized
INFO - 2023-06-20 10:20:02 --> Utf8 Class Initialized
INFO - 2023-06-20 10:20:02 --> URI Class Initialized
INFO - 2023-06-20 10:20:02 --> Router Class Initialized
INFO - 2023-06-20 10:20:02 --> Output Class Initialized
INFO - 2023-06-20 10:20:02 --> Security Class Initialized
INFO - 2023-06-20 10:20:02 --> Input Class Initialized
INFO - 2023-06-20 10:20:02 --> Language Class Initialized
INFO - 2023-06-20 10:20:02 --> Loader Class Initialized
INFO - 2023-06-20 10:20:02 --> Helper loaded: url_helper
INFO - 2023-06-20 10:20:02 --> Helper loaded: form_helper
INFO - 2023-06-20 10:20:02 --> Database Driver Class Initialized
INFO - 2023-06-20 10:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:20:02 --> Form Validation Class Initialized
INFO - 2023-06-20 10:20:02 --> Controller Class Initialized
INFO - 2023-06-20 10:20:02 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:20:02 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:20:02 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:20:02 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:20:02 --> Final output sent to browser
INFO - 2023-06-20 10:20:42 --> Config Class Initialized
INFO - 2023-06-20 10:20:42 --> Hooks Class Initialized
INFO - 2023-06-20 10:20:42 --> Utf8 Class Initialized
INFO - 2023-06-20 10:20:42 --> URI Class Initialized
INFO - 2023-06-20 10:20:42 --> Router Class Initialized
INFO - 2023-06-20 10:20:42 --> Output Class Initialized
INFO - 2023-06-20 10:20:42 --> Security Class Initialized
INFO - 2023-06-20 10:20:42 --> Input Class Initialized
INFO - 2023-06-20 10:20:42 --> Language Class Initialized
INFO - 2023-06-20 10:20:42 --> Loader Class Initialized
INFO - 2023-06-20 10:20:42 --> Helper loaded: url_helper
INFO - 2023-06-20 10:20:42 --> Helper loaded: form_helper
INFO - 2023-06-20 10:20:42 --> Database Driver Class Initialized
INFO - 2023-06-20 10:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:20:42 --> Form Validation Class Initialized
INFO - 2023-06-20 10:20:42 --> Controller Class Initialized
INFO - 2023-06-20 10:20:42 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:20:43 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:20:43 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:20:43 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:20:43 --> Final output sent to browser
INFO - 2023-06-20 10:21:59 --> Config Class Initialized
INFO - 2023-06-20 10:21:59 --> Hooks Class Initialized
INFO - 2023-06-20 10:21:59 --> Utf8 Class Initialized
INFO - 2023-06-20 10:21:59 --> URI Class Initialized
INFO - 2023-06-20 10:21:59 --> Router Class Initialized
INFO - 2023-06-20 10:21:59 --> Output Class Initialized
INFO - 2023-06-20 10:21:59 --> Security Class Initialized
INFO - 2023-06-20 10:21:59 --> Input Class Initialized
INFO - 2023-06-20 10:21:59 --> Language Class Initialized
INFO - 2023-06-20 10:21:59 --> Loader Class Initialized
INFO - 2023-06-20 10:21:59 --> Helper loaded: url_helper
INFO - 2023-06-20 10:21:59 --> Helper loaded: form_helper
INFO - 2023-06-20 10:21:59 --> Database Driver Class Initialized
INFO - 2023-06-20 10:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:21:59 --> Form Validation Class Initialized
INFO - 2023-06-20 10:21:59 --> Controller Class Initialized
INFO - 2023-06-20 10:21:59 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:21:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:21:59 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:21:59 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:21:59 --> Final output sent to browser
INFO - 2023-06-20 10:23:00 --> Config Class Initialized
INFO - 2023-06-20 10:23:00 --> Hooks Class Initialized
INFO - 2023-06-20 10:23:00 --> Utf8 Class Initialized
INFO - 2023-06-20 10:23:00 --> URI Class Initialized
INFO - 2023-06-20 10:23:00 --> Router Class Initialized
INFO - 2023-06-20 10:23:00 --> Output Class Initialized
INFO - 2023-06-20 10:23:00 --> Security Class Initialized
INFO - 2023-06-20 10:23:00 --> Input Class Initialized
INFO - 2023-06-20 10:23:00 --> Language Class Initialized
INFO - 2023-06-20 10:23:00 --> Loader Class Initialized
INFO - 2023-06-20 10:23:00 --> Helper loaded: url_helper
INFO - 2023-06-20 10:23:00 --> Helper loaded: form_helper
INFO - 2023-06-20 10:23:00 --> Database Driver Class Initialized
INFO - 2023-06-20 10:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:23:00 --> Form Validation Class Initialized
INFO - 2023-06-20 10:23:00 --> Controller Class Initialized
INFO - 2023-06-20 10:23:00 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:23:00 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:23:00 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:23:00 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:23:00 --> Final output sent to browser
INFO - 2023-06-20 10:23:23 --> Config Class Initialized
INFO - 2023-06-20 10:23:23 --> Hooks Class Initialized
INFO - 2023-06-20 10:23:23 --> Utf8 Class Initialized
INFO - 2023-06-20 10:23:23 --> URI Class Initialized
INFO - 2023-06-20 10:23:23 --> Router Class Initialized
INFO - 2023-06-20 10:23:23 --> Output Class Initialized
INFO - 2023-06-20 10:23:23 --> Security Class Initialized
INFO - 2023-06-20 10:23:23 --> Input Class Initialized
INFO - 2023-06-20 10:23:23 --> Language Class Initialized
INFO - 2023-06-20 10:23:23 --> Loader Class Initialized
INFO - 2023-06-20 10:23:23 --> Helper loaded: url_helper
INFO - 2023-06-20 10:23:23 --> Helper loaded: form_helper
INFO - 2023-06-20 10:23:23 --> Database Driver Class Initialized
INFO - 2023-06-20 10:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:23:23 --> Form Validation Class Initialized
INFO - 2023-06-20 10:23:23 --> Controller Class Initialized
INFO - 2023-06-20 10:23:23 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:23:23 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:23:23 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:23:23 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:23:23 --> Final output sent to browser
INFO - 2023-06-20 10:26:19 --> Config Class Initialized
INFO - 2023-06-20 10:26:19 --> Hooks Class Initialized
INFO - 2023-06-20 10:26:19 --> Utf8 Class Initialized
INFO - 2023-06-20 10:26:19 --> URI Class Initialized
INFO - 2023-06-20 10:26:19 --> Router Class Initialized
INFO - 2023-06-20 10:26:19 --> Output Class Initialized
INFO - 2023-06-20 10:26:19 --> Security Class Initialized
INFO - 2023-06-20 10:26:19 --> Input Class Initialized
INFO - 2023-06-20 10:26:19 --> Language Class Initialized
INFO - 2023-06-20 10:26:19 --> Loader Class Initialized
INFO - 2023-06-20 10:26:19 --> Helper loaded: url_helper
INFO - 2023-06-20 10:26:19 --> Helper loaded: form_helper
INFO - 2023-06-20 10:26:19 --> Database Driver Class Initialized
INFO - 2023-06-20 10:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:26:19 --> Form Validation Class Initialized
INFO - 2023-06-20 10:26:19 --> Controller Class Initialized
INFO - 2023-06-20 10:26:19 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:26:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:26:19 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:26:19 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:26:20 --> Final output sent to browser
INFO - 2023-06-20 10:27:46 --> Config Class Initialized
INFO - 2023-06-20 10:27:46 --> Hooks Class Initialized
INFO - 2023-06-20 10:27:46 --> Utf8 Class Initialized
INFO - 2023-06-20 10:27:46 --> URI Class Initialized
INFO - 2023-06-20 10:27:46 --> Router Class Initialized
INFO - 2023-06-20 10:27:46 --> Output Class Initialized
INFO - 2023-06-20 10:27:46 --> Security Class Initialized
INFO - 2023-06-20 10:27:46 --> Input Class Initialized
INFO - 2023-06-20 10:27:46 --> Language Class Initialized
INFO - 2023-06-20 10:27:46 --> Loader Class Initialized
INFO - 2023-06-20 10:27:46 --> Helper loaded: url_helper
INFO - 2023-06-20 10:27:46 --> Helper loaded: form_helper
INFO - 2023-06-20 10:27:46 --> Database Driver Class Initialized
INFO - 2023-06-20 10:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:27:46 --> Form Validation Class Initialized
INFO - 2023-06-20 10:27:46 --> Controller Class Initialized
INFO - 2023-06-20 10:27:46 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:27:46 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:27:46 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:27:46 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:27:46 --> Final output sent to browser
INFO - 2023-06-20 10:45:09 --> Config Class Initialized
INFO - 2023-06-20 10:45:09 --> Hooks Class Initialized
INFO - 2023-06-20 10:45:09 --> Utf8 Class Initialized
INFO - 2023-06-20 10:45:09 --> URI Class Initialized
INFO - 2023-06-20 10:45:09 --> Router Class Initialized
INFO - 2023-06-20 10:45:09 --> Output Class Initialized
INFO - 2023-06-20 10:45:09 --> Security Class Initialized
INFO - 2023-06-20 10:45:09 --> Input Class Initialized
INFO - 2023-06-20 10:45:09 --> Language Class Initialized
INFO - 2023-06-20 10:45:09 --> Loader Class Initialized
INFO - 2023-06-20 10:45:09 --> Helper loaded: url_helper
INFO - 2023-06-20 10:45:09 --> Helper loaded: form_helper
INFO - 2023-06-20 10:45:09 --> Database Driver Class Initialized
INFO - 2023-06-20 10:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:45:09 --> Form Validation Class Initialized
INFO - 2023-06-20 10:45:09 --> Controller Class Initialized
INFO - 2023-06-20 10:45:09 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:45:09 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:45:09 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:45:09 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:45:09 --> Final output sent to browser
INFO - 2023-06-20 10:45:13 --> Config Class Initialized
INFO - 2023-06-20 10:45:13 --> Hooks Class Initialized
INFO - 2023-06-20 10:45:13 --> Utf8 Class Initialized
INFO - 2023-06-20 10:45:13 --> URI Class Initialized
INFO - 2023-06-20 10:45:13 --> Router Class Initialized
INFO - 2023-06-20 10:45:13 --> Output Class Initialized
INFO - 2023-06-20 10:45:13 --> Security Class Initialized
INFO - 2023-06-20 10:45:13 --> Input Class Initialized
INFO - 2023-06-20 10:45:13 --> Language Class Initialized
INFO - 2023-06-20 10:45:13 --> Loader Class Initialized
INFO - 2023-06-20 10:45:13 --> Helper loaded: url_helper
INFO - 2023-06-20 10:45:13 --> Helper loaded: form_helper
INFO - 2023-06-20 10:45:13 --> Database Driver Class Initialized
INFO - 2023-06-20 10:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:45:13 --> Form Validation Class Initialized
INFO - 2023-06-20 10:45:13 --> Controller Class Initialized
INFO - 2023-06-20 10:45:13 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:45:13 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:45:13 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:45:13 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:45:13 --> Final output sent to browser
INFO - 2023-06-20 10:45:43 --> Config Class Initialized
INFO - 2023-06-20 10:45:43 --> Hooks Class Initialized
INFO - 2023-06-20 10:45:43 --> Utf8 Class Initialized
INFO - 2023-06-20 10:45:43 --> URI Class Initialized
INFO - 2023-06-20 10:45:43 --> Router Class Initialized
INFO - 2023-06-20 10:45:43 --> Output Class Initialized
INFO - 2023-06-20 10:45:43 --> Security Class Initialized
INFO - 2023-06-20 10:45:43 --> Input Class Initialized
INFO - 2023-06-20 10:45:43 --> Language Class Initialized
INFO - 2023-06-20 10:45:43 --> Loader Class Initialized
INFO - 2023-06-20 10:45:43 --> Helper loaded: url_helper
INFO - 2023-06-20 10:45:43 --> Helper loaded: form_helper
INFO - 2023-06-20 10:45:43 --> Database Driver Class Initialized
INFO - 2023-06-20 10:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:45:43 --> Form Validation Class Initialized
INFO - 2023-06-20 10:45:43 --> Controller Class Initialized
INFO - 2023-06-20 10:45:43 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:45:43 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:45:43 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:45:43 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:45:43 --> Final output sent to browser
INFO - 2023-06-20 10:46:56 --> Config Class Initialized
INFO - 2023-06-20 10:46:56 --> Hooks Class Initialized
INFO - 2023-06-20 10:46:56 --> Utf8 Class Initialized
INFO - 2023-06-20 10:46:56 --> URI Class Initialized
INFO - 2023-06-20 10:46:56 --> Router Class Initialized
INFO - 2023-06-20 10:46:56 --> Output Class Initialized
INFO - 2023-06-20 10:46:56 --> Security Class Initialized
INFO - 2023-06-20 10:46:56 --> Input Class Initialized
INFO - 2023-06-20 10:46:56 --> Language Class Initialized
INFO - 2023-06-20 10:46:56 --> Loader Class Initialized
INFO - 2023-06-20 10:46:56 --> Helper loaded: url_helper
INFO - 2023-06-20 10:46:56 --> Helper loaded: form_helper
INFO - 2023-06-20 10:46:56 --> Database Driver Class Initialized
INFO - 2023-06-20 10:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:46:56 --> Form Validation Class Initialized
INFO - 2023-06-20 10:46:56 --> Controller Class Initialized
INFO - 2023-06-20 10:46:56 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:46:57 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:46:57 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:46:57 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:46:57 --> Final output sent to browser
INFO - 2023-06-20 10:47:26 --> Config Class Initialized
INFO - 2023-06-20 10:47:26 --> Hooks Class Initialized
INFO - 2023-06-20 10:47:26 --> Utf8 Class Initialized
INFO - 2023-06-20 10:47:26 --> URI Class Initialized
INFO - 2023-06-20 10:47:26 --> Router Class Initialized
INFO - 2023-06-20 10:47:26 --> Output Class Initialized
INFO - 2023-06-20 10:47:26 --> Security Class Initialized
INFO - 2023-06-20 10:47:26 --> Input Class Initialized
INFO - 2023-06-20 10:47:26 --> Language Class Initialized
INFO - 2023-06-20 10:47:26 --> Loader Class Initialized
INFO - 2023-06-20 10:47:26 --> Helper loaded: url_helper
INFO - 2023-06-20 10:47:26 --> Helper loaded: form_helper
INFO - 2023-06-20 10:47:26 --> Database Driver Class Initialized
INFO - 2023-06-20 10:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:47:26 --> Form Validation Class Initialized
INFO - 2023-06-20 10:47:26 --> Controller Class Initialized
INFO - 2023-06-20 10:47:26 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:47:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:47:26 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:47:26 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:47:26 --> Final output sent to browser
INFO - 2023-06-20 10:48:53 --> Config Class Initialized
INFO - 2023-06-20 10:48:53 --> Hooks Class Initialized
INFO - 2023-06-20 10:48:53 --> Utf8 Class Initialized
INFO - 2023-06-20 10:48:53 --> URI Class Initialized
INFO - 2023-06-20 10:48:53 --> Router Class Initialized
INFO - 2023-06-20 10:48:53 --> Output Class Initialized
INFO - 2023-06-20 10:48:53 --> Security Class Initialized
INFO - 2023-06-20 10:48:53 --> Input Class Initialized
INFO - 2023-06-20 10:48:53 --> Language Class Initialized
INFO - 2023-06-20 10:48:53 --> Loader Class Initialized
INFO - 2023-06-20 10:48:53 --> Helper loaded: url_helper
INFO - 2023-06-20 10:48:53 --> Helper loaded: form_helper
INFO - 2023-06-20 10:48:53 --> Database Driver Class Initialized
INFO - 2023-06-20 10:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:48:53 --> Form Validation Class Initialized
INFO - 2023-06-20 10:48:53 --> Controller Class Initialized
INFO - 2023-06-20 10:48:53 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:48:53 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:48:53 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:48:53 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:48:53 --> Final output sent to browser
INFO - 2023-06-20 10:49:00 --> Config Class Initialized
INFO - 2023-06-20 10:49:00 --> Hooks Class Initialized
INFO - 2023-06-20 10:49:00 --> Utf8 Class Initialized
INFO - 2023-06-20 10:49:00 --> URI Class Initialized
INFO - 2023-06-20 10:49:00 --> Router Class Initialized
INFO - 2023-06-20 10:49:00 --> Output Class Initialized
INFO - 2023-06-20 10:49:00 --> Security Class Initialized
INFO - 2023-06-20 10:49:00 --> Input Class Initialized
INFO - 2023-06-20 10:49:00 --> Language Class Initialized
INFO - 2023-06-20 10:49:00 --> Loader Class Initialized
INFO - 2023-06-20 10:49:00 --> Helper loaded: url_helper
INFO - 2023-06-20 10:49:00 --> Helper loaded: form_helper
INFO - 2023-06-20 10:49:00 --> Database Driver Class Initialized
INFO - 2023-06-20 10:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:49:00 --> Form Validation Class Initialized
INFO - 2023-06-20 10:49:00 --> Controller Class Initialized
INFO - 2023-06-20 10:49:00 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:49:00 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:49:00 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:49:00 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:49:00 --> Final output sent to browser
INFO - 2023-06-20 10:52:03 --> Config Class Initialized
INFO - 2023-06-20 10:52:03 --> Hooks Class Initialized
INFO - 2023-06-20 10:52:03 --> Utf8 Class Initialized
INFO - 2023-06-20 10:52:03 --> URI Class Initialized
INFO - 2023-06-20 10:52:03 --> Router Class Initialized
INFO - 2023-06-20 10:52:03 --> Output Class Initialized
INFO - 2023-06-20 10:52:03 --> Security Class Initialized
INFO - 2023-06-20 10:52:03 --> Input Class Initialized
INFO - 2023-06-20 10:52:03 --> Language Class Initialized
INFO - 2023-06-20 10:52:03 --> Loader Class Initialized
INFO - 2023-06-20 10:52:03 --> Helper loaded: url_helper
INFO - 2023-06-20 10:52:03 --> Helper loaded: form_helper
INFO - 2023-06-20 10:52:03 --> Database Driver Class Initialized
INFO - 2023-06-20 10:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:52:03 --> Form Validation Class Initialized
INFO - 2023-06-20 10:52:03 --> Controller Class Initialized
INFO - 2023-06-20 10:52:03 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:52:03 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:52:03 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:52:03 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:52:03 --> Final output sent to browser
INFO - 2023-06-20 10:54:36 --> Config Class Initialized
INFO - 2023-06-20 10:54:36 --> Hooks Class Initialized
INFO - 2023-06-20 10:54:36 --> Utf8 Class Initialized
INFO - 2023-06-20 10:54:36 --> URI Class Initialized
INFO - 2023-06-20 10:54:36 --> Router Class Initialized
INFO - 2023-06-20 10:54:36 --> Output Class Initialized
INFO - 2023-06-20 10:54:36 --> Security Class Initialized
INFO - 2023-06-20 10:54:36 --> Input Class Initialized
INFO - 2023-06-20 10:54:36 --> Language Class Initialized
INFO - 2023-06-20 10:54:36 --> Loader Class Initialized
INFO - 2023-06-20 10:54:36 --> Helper loaded: url_helper
INFO - 2023-06-20 10:54:36 --> Helper loaded: form_helper
INFO - 2023-06-20 10:54:36 --> Database Driver Class Initialized
INFO - 2023-06-20 10:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:54:36 --> Form Validation Class Initialized
INFO - 2023-06-20 10:54:36 --> Controller Class Initialized
INFO - 2023-06-20 10:54:36 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:54:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:54:36 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:54:36 --> Model "M_solusi" initialized
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilGangguanMoodB3_A C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2008
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilGangguanMoodB3_B C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2008
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilGangguanMoodB3_C C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2008
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilRinganB3_A C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2009
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilRinganB3_B C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2009
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilRinganB3_C C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2009
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilSedangB3_A C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2010
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilSedangB3_B C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2010
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilSedangB3_C C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2010
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilBeratB3_A C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2011
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilBeratB3_B C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2011
ERROR - 2023-06-20 10:54:36 --> Severity: Notice --> Undefined variable: HasilBeratB3_C C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2011
INFO - 2023-06-20 10:54:36 --> Final output sent to browser
INFO - 2023-06-20 10:54:48 --> Config Class Initialized
INFO - 2023-06-20 10:54:48 --> Hooks Class Initialized
INFO - 2023-06-20 10:54:48 --> Utf8 Class Initialized
INFO - 2023-06-20 10:54:48 --> URI Class Initialized
INFO - 2023-06-20 10:54:48 --> Router Class Initialized
INFO - 2023-06-20 10:54:48 --> Output Class Initialized
INFO - 2023-06-20 10:54:48 --> Security Class Initialized
INFO - 2023-06-20 10:54:48 --> Input Class Initialized
INFO - 2023-06-20 10:54:48 --> Language Class Initialized
INFO - 2023-06-20 10:54:48 --> Loader Class Initialized
INFO - 2023-06-20 10:54:48 --> Helper loaded: url_helper
INFO - 2023-06-20 10:54:48 --> Helper loaded: form_helper
INFO - 2023-06-20 10:54:48 --> Database Driver Class Initialized
INFO - 2023-06-20 10:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:54:48 --> Form Validation Class Initialized
INFO - 2023-06-20 10:54:48 --> Controller Class Initialized
INFO - 2023-06-20 10:54:48 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:54:48 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:54:48 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:54:48 --> Model "M_solusi" initialized
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilGangguanMoodB3_A C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2008
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilGangguanMoodB3_B C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2008
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilGangguanMoodB3_C C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2008
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilRinganB3_A C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2009
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilRinganB3_B C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2009
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilRinganB3_C C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2009
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilSedangB3_A C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2010
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilSedangB3_B C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2010
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilSedangB3_C C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2010
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilBeratB3_A C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2011
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilBeratB3_B C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2011
ERROR - 2023-06-20 10:54:49 --> Severity: Notice --> Undefined variable: HasilBeratB3_C C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2011
INFO - 2023-06-20 10:54:49 --> Final output sent to browser
INFO - 2023-06-20 10:57:23 --> Config Class Initialized
INFO - 2023-06-20 10:57:23 --> Hooks Class Initialized
INFO - 2023-06-20 10:57:23 --> Utf8 Class Initialized
INFO - 2023-06-20 10:57:23 --> URI Class Initialized
INFO - 2023-06-20 10:57:23 --> Router Class Initialized
INFO - 2023-06-20 10:57:23 --> Output Class Initialized
INFO - 2023-06-20 10:57:23 --> Security Class Initialized
INFO - 2023-06-20 10:57:23 --> Input Class Initialized
INFO - 2023-06-20 10:57:23 --> Language Class Initialized
INFO - 2023-06-20 10:57:23 --> Loader Class Initialized
INFO - 2023-06-20 10:57:23 --> Helper loaded: url_helper
INFO - 2023-06-20 10:57:23 --> Helper loaded: form_helper
INFO - 2023-06-20 10:57:23 --> Database Driver Class Initialized
INFO - 2023-06-20 10:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:57:23 --> Form Validation Class Initialized
INFO - 2023-06-20 10:57:23 --> Controller Class Initialized
INFO - 2023-06-20 10:57:23 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:57:23 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:57:23 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:57:23 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:57:23 --> Final output sent to browser
INFO - 2023-06-20 10:59:56 --> Config Class Initialized
INFO - 2023-06-20 10:59:56 --> Hooks Class Initialized
INFO - 2023-06-20 10:59:56 --> Utf8 Class Initialized
INFO - 2023-06-20 10:59:56 --> URI Class Initialized
INFO - 2023-06-20 10:59:56 --> Router Class Initialized
INFO - 2023-06-20 10:59:56 --> Output Class Initialized
INFO - 2023-06-20 10:59:56 --> Security Class Initialized
INFO - 2023-06-20 10:59:56 --> Input Class Initialized
INFO - 2023-06-20 10:59:56 --> Language Class Initialized
INFO - 2023-06-20 10:59:56 --> Loader Class Initialized
INFO - 2023-06-20 10:59:56 --> Helper loaded: url_helper
INFO - 2023-06-20 10:59:56 --> Helper loaded: form_helper
INFO - 2023-06-20 10:59:56 --> Database Driver Class Initialized
INFO - 2023-06-20 10:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 10:59:56 --> Form Validation Class Initialized
INFO - 2023-06-20 10:59:56 --> Controller Class Initialized
INFO - 2023-06-20 10:59:56 --> Model "m_datatrain" initialized
INFO - 2023-06-20 10:59:56 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 10:59:56 --> Model "m_datatest" initialized
INFO - 2023-06-20 10:59:56 --> Model "M_solusi" initialized
INFO - 2023-06-20 10:59:56 --> Final output sent to browser
INFO - 2023-06-20 11:02:59 --> Config Class Initialized
INFO - 2023-06-20 11:02:59 --> Hooks Class Initialized
INFO - 2023-06-20 11:02:59 --> Utf8 Class Initialized
INFO - 2023-06-20 11:02:59 --> URI Class Initialized
INFO - 2023-06-20 11:02:59 --> Router Class Initialized
INFO - 2023-06-20 11:02:59 --> Output Class Initialized
INFO - 2023-06-20 11:02:59 --> Security Class Initialized
INFO - 2023-06-20 11:02:59 --> Input Class Initialized
INFO - 2023-06-20 11:02:59 --> Language Class Initialized
ERROR - 2023-06-20 11:02:59 --> 404 Page Not Found: Test/index
INFO - 2023-06-20 11:03:17 --> Config Class Initialized
INFO - 2023-06-20 11:03:17 --> Hooks Class Initialized
INFO - 2023-06-20 11:03:17 --> Utf8 Class Initialized
INFO - 2023-06-20 11:03:17 --> URI Class Initialized
INFO - 2023-06-20 11:03:17 --> Router Class Initialized
INFO - 2023-06-20 11:03:17 --> Output Class Initialized
INFO - 2023-06-20 11:03:17 --> Security Class Initialized
INFO - 2023-06-20 11:03:17 --> Input Class Initialized
INFO - 2023-06-20 11:03:17 --> Language Class Initialized
INFO - 2023-06-20 11:03:17 --> Loader Class Initialized
INFO - 2023-06-20 11:03:17 --> Helper loaded: url_helper
INFO - 2023-06-20 11:03:17 --> Helper loaded: form_helper
INFO - 2023-06-20 11:03:17 --> Database Driver Class Initialized
INFO - 2023-06-20 11:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:03:17 --> Form Validation Class Initialized
INFO - 2023-06-20 11:03:17 --> Controller Class Initialized
INFO - 2023-06-20 11:03:17 --> Model "m_user" initialized
INFO - 2023-06-20 11:03:17 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:03:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:03:17 --> Final output sent to browser
INFO - 2023-06-20 11:04:32 --> Config Class Initialized
INFO - 2023-06-20 11:04:32 --> Hooks Class Initialized
INFO - 2023-06-20 11:04:32 --> Utf8 Class Initialized
INFO - 2023-06-20 11:04:32 --> URI Class Initialized
INFO - 2023-06-20 11:04:32 --> Router Class Initialized
INFO - 2023-06-20 11:04:32 --> Output Class Initialized
INFO - 2023-06-20 11:04:32 --> Security Class Initialized
INFO - 2023-06-20 11:04:32 --> Input Class Initialized
INFO - 2023-06-20 11:04:32 --> Language Class Initialized
INFO - 2023-06-20 11:04:32 --> Loader Class Initialized
INFO - 2023-06-20 11:04:32 --> Helper loaded: url_helper
INFO - 2023-06-20 11:04:32 --> Helper loaded: form_helper
INFO - 2023-06-20 11:04:32 --> Database Driver Class Initialized
INFO - 2023-06-20 11:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:04:32 --> Form Validation Class Initialized
INFO - 2023-06-20 11:04:32 --> Controller Class Initialized
INFO - 2023-06-20 11:04:32 --> Model "m_user" initialized
INFO - 2023-06-20 11:04:32 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:04:32 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:04:32 --> Final output sent to browser
INFO - 2023-06-20 11:04:34 --> Config Class Initialized
INFO - 2023-06-20 11:04:34 --> Hooks Class Initialized
INFO - 2023-06-20 11:04:34 --> Utf8 Class Initialized
INFO - 2023-06-20 11:04:34 --> URI Class Initialized
INFO - 2023-06-20 11:04:34 --> Router Class Initialized
INFO - 2023-06-20 11:04:34 --> Output Class Initialized
INFO - 2023-06-20 11:04:34 --> Security Class Initialized
INFO - 2023-06-20 11:04:34 --> Input Class Initialized
INFO - 2023-06-20 11:04:34 --> Language Class Initialized
INFO - 2023-06-20 11:04:34 --> Loader Class Initialized
INFO - 2023-06-20 11:04:34 --> Helper loaded: url_helper
INFO - 2023-06-20 11:04:34 --> Helper loaded: form_helper
INFO - 2023-06-20 11:04:34 --> Database Driver Class Initialized
INFO - 2023-06-20 11:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:04:34 --> Form Validation Class Initialized
INFO - 2023-06-20 11:04:34 --> Controller Class Initialized
INFO - 2023-06-20 11:04:34 --> Model "m_user" initialized
INFO - 2023-06-20 11:04:34 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:04:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:04:34 --> Final output sent to browser
INFO - 2023-06-20 11:04:34 --> Config Class Initialized
INFO - 2023-06-20 11:04:34 --> Hooks Class Initialized
INFO - 2023-06-20 11:04:34 --> Utf8 Class Initialized
INFO - 2023-06-20 11:04:34 --> URI Class Initialized
INFO - 2023-06-20 11:04:34 --> Router Class Initialized
INFO - 2023-06-20 11:04:34 --> Output Class Initialized
INFO - 2023-06-20 11:04:34 --> Security Class Initialized
INFO - 2023-06-20 11:04:34 --> Input Class Initialized
INFO - 2023-06-20 11:04:34 --> Language Class Initialized
INFO - 2023-06-20 11:04:34 --> Loader Class Initialized
INFO - 2023-06-20 11:04:34 --> Helper loaded: url_helper
INFO - 2023-06-20 11:04:34 --> Helper loaded: form_helper
INFO - 2023-06-20 11:04:34 --> Database Driver Class Initialized
INFO - 2023-06-20 11:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:04:34 --> Form Validation Class Initialized
INFO - 2023-06-20 11:04:34 --> Controller Class Initialized
INFO - 2023-06-20 11:04:34 --> Model "m_user" initialized
INFO - 2023-06-20 11:04:34 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:04:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:04:34 --> Final output sent to browser
INFO - 2023-06-20 11:04:34 --> Config Class Initialized
INFO - 2023-06-20 11:04:34 --> Hooks Class Initialized
INFO - 2023-06-20 11:04:34 --> Utf8 Class Initialized
INFO - 2023-06-20 11:04:34 --> URI Class Initialized
INFO - 2023-06-20 11:04:34 --> Router Class Initialized
INFO - 2023-06-20 11:04:34 --> Output Class Initialized
INFO - 2023-06-20 11:04:34 --> Security Class Initialized
INFO - 2023-06-20 11:04:34 --> Input Class Initialized
INFO - 2023-06-20 11:04:34 --> Language Class Initialized
INFO - 2023-06-20 11:04:34 --> Loader Class Initialized
INFO - 2023-06-20 11:04:34 --> Helper loaded: url_helper
INFO - 2023-06-20 11:04:34 --> Helper loaded: form_helper
INFO - 2023-06-20 11:04:34 --> Database Driver Class Initialized
INFO - 2023-06-20 11:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:04:34 --> Form Validation Class Initialized
INFO - 2023-06-20 11:04:34 --> Controller Class Initialized
INFO - 2023-06-20 11:04:34 --> Model "m_user" initialized
INFO - 2023-06-20 11:04:34 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:04:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:04:34 --> Final output sent to browser
INFO - 2023-06-20 11:04:34 --> Config Class Initialized
INFO - 2023-06-20 11:04:34 --> Hooks Class Initialized
INFO - 2023-06-20 11:04:34 --> Utf8 Class Initialized
INFO - 2023-06-20 11:04:34 --> URI Class Initialized
INFO - 2023-06-20 11:04:34 --> Router Class Initialized
INFO - 2023-06-20 11:04:34 --> Output Class Initialized
INFO - 2023-06-20 11:04:34 --> Security Class Initialized
INFO - 2023-06-20 11:04:34 --> Input Class Initialized
INFO - 2023-06-20 11:04:34 --> Language Class Initialized
INFO - 2023-06-20 11:04:34 --> Loader Class Initialized
INFO - 2023-06-20 11:04:34 --> Helper loaded: url_helper
INFO - 2023-06-20 11:04:34 --> Helper loaded: form_helper
INFO - 2023-06-20 11:04:34 --> Database Driver Class Initialized
INFO - 2023-06-20 11:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:04:34 --> Form Validation Class Initialized
INFO - 2023-06-20 11:04:34 --> Controller Class Initialized
INFO - 2023-06-20 11:04:34 --> Model "m_user" initialized
INFO - 2023-06-20 11:04:34 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:04:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:04:34 --> Final output sent to browser
INFO - 2023-06-20 11:10:16 --> Config Class Initialized
INFO - 2023-06-20 11:10:16 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:16 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:16 --> URI Class Initialized
INFO - 2023-06-20 11:10:16 --> Router Class Initialized
INFO - 2023-06-20 11:10:16 --> Output Class Initialized
INFO - 2023-06-20 11:10:16 --> Security Class Initialized
INFO - 2023-06-20 11:10:16 --> Input Class Initialized
INFO - 2023-06-20 11:10:16 --> Language Class Initialized
INFO - 2023-06-20 11:10:16 --> Loader Class Initialized
INFO - 2023-06-20 11:10:16 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:16 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:16 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:16 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:16 --> Controller Class Initialized
INFO - 2023-06-20 11:10:16 --> Model "m_user" initialized
INFO - 2023-06-20 11:10:16 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:16 --> Final output sent to browser
INFO - 2023-06-20 11:10:17 --> Config Class Initialized
INFO - 2023-06-20 11:10:17 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:17 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:17 --> URI Class Initialized
INFO - 2023-06-20 11:10:17 --> Router Class Initialized
INFO - 2023-06-20 11:10:17 --> Output Class Initialized
INFO - 2023-06-20 11:10:17 --> Security Class Initialized
INFO - 2023-06-20 11:10:17 --> Input Class Initialized
INFO - 2023-06-20 11:10:17 --> Language Class Initialized
INFO - 2023-06-20 11:10:17 --> Loader Class Initialized
INFO - 2023-06-20 11:10:17 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:17 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:17 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:17 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:17 --> Controller Class Initialized
INFO - 2023-06-20 11:10:17 --> Model "m_user" initialized
INFO - 2023-06-20 11:10:17 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:17 --> Final output sent to browser
INFO - 2023-06-20 11:10:18 --> Config Class Initialized
INFO - 2023-06-20 11:10:18 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:18 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:18 --> URI Class Initialized
INFO - 2023-06-20 11:10:18 --> Router Class Initialized
INFO - 2023-06-20 11:10:18 --> Output Class Initialized
INFO - 2023-06-20 11:10:18 --> Security Class Initialized
INFO - 2023-06-20 11:10:18 --> Input Class Initialized
INFO - 2023-06-20 11:10:18 --> Language Class Initialized
INFO - 2023-06-20 11:10:18 --> Loader Class Initialized
INFO - 2023-06-20 11:10:18 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:18 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:18 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:18 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:18 --> Controller Class Initialized
INFO - 2023-06-20 11:10:18 --> Model "m_user" initialized
INFO - 2023-06-20 11:10:18 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:18 --> Final output sent to browser
INFO - 2023-06-20 11:10:18 --> Config Class Initialized
INFO - 2023-06-20 11:10:18 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:18 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:18 --> URI Class Initialized
INFO - 2023-06-20 11:10:18 --> Router Class Initialized
INFO - 2023-06-20 11:10:18 --> Output Class Initialized
INFO - 2023-06-20 11:10:18 --> Security Class Initialized
INFO - 2023-06-20 11:10:18 --> Input Class Initialized
INFO - 2023-06-20 11:10:18 --> Language Class Initialized
INFO - 2023-06-20 11:10:18 --> Loader Class Initialized
INFO - 2023-06-20 11:10:18 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:18 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:18 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:18 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:18 --> Controller Class Initialized
INFO - 2023-06-20 11:10:18 --> Model "m_user" initialized
INFO - 2023-06-20 11:10:18 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:18 --> Final output sent to browser
INFO - 2023-06-20 11:10:18 --> Config Class Initialized
INFO - 2023-06-20 11:10:18 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:18 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:18 --> URI Class Initialized
INFO - 2023-06-20 11:10:18 --> Router Class Initialized
INFO - 2023-06-20 11:10:18 --> Output Class Initialized
INFO - 2023-06-20 11:10:18 --> Security Class Initialized
INFO - 2023-06-20 11:10:18 --> Input Class Initialized
INFO - 2023-06-20 11:10:18 --> Language Class Initialized
INFO - 2023-06-20 11:10:18 --> Loader Class Initialized
INFO - 2023-06-20 11:10:18 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:18 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:18 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:18 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:18 --> Controller Class Initialized
INFO - 2023-06-20 11:10:18 --> Model "m_user" initialized
INFO - 2023-06-20 11:10:18 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:18 --> Final output sent to browser
INFO - 2023-06-20 11:10:18 --> Config Class Initialized
INFO - 2023-06-20 11:10:18 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:18 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:18 --> URI Class Initialized
INFO - 2023-06-20 11:10:18 --> Router Class Initialized
INFO - 2023-06-20 11:10:18 --> Output Class Initialized
INFO - 2023-06-20 11:10:18 --> Security Class Initialized
INFO - 2023-06-20 11:10:18 --> Input Class Initialized
INFO - 2023-06-20 11:10:18 --> Language Class Initialized
INFO - 2023-06-20 11:10:18 --> Loader Class Initialized
INFO - 2023-06-20 11:10:18 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:18 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:18 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:18 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:18 --> Controller Class Initialized
INFO - 2023-06-20 11:10:18 --> Model "m_user" initialized
INFO - 2023-06-20 11:10:18 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:18 --> Final output sent to browser
INFO - 2023-06-20 11:10:19 --> Config Class Initialized
INFO - 2023-06-20 11:10:19 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:19 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:19 --> URI Class Initialized
INFO - 2023-06-20 11:10:19 --> Router Class Initialized
INFO - 2023-06-20 11:10:19 --> Output Class Initialized
INFO - 2023-06-20 11:10:19 --> Security Class Initialized
INFO - 2023-06-20 11:10:19 --> Input Class Initialized
INFO - 2023-06-20 11:10:19 --> Language Class Initialized
INFO - 2023-06-20 11:10:19 --> Loader Class Initialized
INFO - 2023-06-20 11:10:19 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:19 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:19 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:19 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:19 --> Controller Class Initialized
INFO - 2023-06-20 11:10:19 --> Model "m_user" initialized
INFO - 2023-06-20 11:10:19 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:19 --> Final output sent to browser
INFO - 2023-06-20 11:10:19 --> Config Class Initialized
INFO - 2023-06-20 11:10:19 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:19 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:19 --> URI Class Initialized
INFO - 2023-06-20 11:10:19 --> Router Class Initialized
INFO - 2023-06-20 11:10:19 --> Output Class Initialized
INFO - 2023-06-20 11:10:19 --> Security Class Initialized
INFO - 2023-06-20 11:10:19 --> Input Class Initialized
INFO - 2023-06-20 11:10:19 --> Language Class Initialized
INFO - 2023-06-20 11:10:19 --> Loader Class Initialized
INFO - 2023-06-20 11:10:19 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:19 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:19 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:19 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:19 --> Controller Class Initialized
INFO - 2023-06-20 11:10:19 --> Model "m_user" initialized
INFO - 2023-06-20 11:10:19 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:19 --> Final output sent to browser
INFO - 2023-06-20 11:10:19 --> Config Class Initialized
INFO - 2023-06-20 11:10:19 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:19 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:19 --> URI Class Initialized
INFO - 2023-06-20 11:10:19 --> Router Class Initialized
INFO - 2023-06-20 11:10:19 --> Output Class Initialized
INFO - 2023-06-20 11:10:19 --> Security Class Initialized
INFO - 2023-06-20 11:10:19 --> Input Class Initialized
INFO - 2023-06-20 11:10:19 --> Language Class Initialized
INFO - 2023-06-20 11:10:19 --> Loader Class Initialized
INFO - 2023-06-20 11:10:19 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:19 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:19 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:19 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:19 --> Controller Class Initialized
INFO - 2023-06-20 11:10:19 --> Model "m_user" initialized
INFO - 2023-06-20 11:10:19 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:19 --> Final output sent to browser
INFO - 2023-06-20 11:10:19 --> Config Class Initialized
INFO - 2023-06-20 11:10:19 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:19 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:19 --> URI Class Initialized
INFO - 2023-06-20 11:10:19 --> Router Class Initialized
INFO - 2023-06-20 11:10:19 --> Output Class Initialized
INFO - 2023-06-20 11:10:19 --> Security Class Initialized
INFO - 2023-06-20 11:10:19 --> Input Class Initialized
INFO - 2023-06-20 11:10:19 --> Language Class Initialized
INFO - 2023-06-20 11:10:19 --> Loader Class Initialized
INFO - 2023-06-20 11:10:19 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:19 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:19 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:19 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:19 --> Controller Class Initialized
INFO - 2023-06-20 11:10:19 --> Model "m_user" initialized
INFO - 2023-06-20 11:10:19 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:19 --> Final output sent to browser
INFO - 2023-06-20 11:10:20 --> Config Class Initialized
INFO - 2023-06-20 11:10:20 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:20 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:20 --> URI Class Initialized
INFO - 2023-06-20 11:10:20 --> Router Class Initialized
INFO - 2023-06-20 11:10:20 --> Output Class Initialized
INFO - 2023-06-20 11:10:20 --> Security Class Initialized
INFO - 2023-06-20 11:10:20 --> Input Class Initialized
INFO - 2023-06-20 11:10:20 --> Language Class Initialized
INFO - 2023-06-20 11:10:20 --> Loader Class Initialized
INFO - 2023-06-20 11:10:20 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:20 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:20 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:20 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:20 --> Controller Class Initialized
INFO - 2023-06-20 11:10:20 --> Model "m_user" initialized
INFO - 2023-06-20 11:10:20 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:20 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:20 --> Final output sent to browser
INFO - 2023-06-20 11:10:38 --> Config Class Initialized
INFO - 2023-06-20 11:10:38 --> Hooks Class Initialized
INFO - 2023-06-20 11:10:38 --> Utf8 Class Initialized
INFO - 2023-06-20 11:10:38 --> URI Class Initialized
INFO - 2023-06-20 11:10:38 --> Router Class Initialized
INFO - 2023-06-20 11:10:38 --> Output Class Initialized
INFO - 2023-06-20 11:10:38 --> Security Class Initialized
INFO - 2023-06-20 11:10:38 --> Input Class Initialized
INFO - 2023-06-20 11:10:38 --> Language Class Initialized
INFO - 2023-06-20 11:10:38 --> Loader Class Initialized
INFO - 2023-06-20 11:10:38 --> Helper loaded: url_helper
INFO - 2023-06-20 11:10:38 --> Helper loaded: form_helper
INFO - 2023-06-20 11:10:38 --> Database Driver Class Initialized
INFO - 2023-06-20 11:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:10:38 --> Form Validation Class Initialized
INFO - 2023-06-20 11:10:38 --> Controller Class Initialized
INFO - 2023-06-20 11:10:38 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:10:38 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:10:38 --> Model "m_datatest" initialized
INFO - 2023-06-20 11:10:38 --> Model "M_solusi" initialized
INFO - 2023-06-20 11:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-20 11:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-20 11:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-20 11:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-20 11:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-20 11:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-20 11:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-20 11:10:38 --> Final output sent to browser
INFO - 2023-06-20 11:11:17 --> Config Class Initialized
INFO - 2023-06-20 11:11:17 --> Hooks Class Initialized
INFO - 2023-06-20 11:11:17 --> Utf8 Class Initialized
INFO - 2023-06-20 11:11:17 --> URI Class Initialized
INFO - 2023-06-20 11:11:17 --> Router Class Initialized
INFO - 2023-06-20 11:11:17 --> Output Class Initialized
INFO - 2023-06-20 11:11:17 --> Security Class Initialized
INFO - 2023-06-20 11:11:17 --> Input Class Initialized
INFO - 2023-06-20 11:11:17 --> Language Class Initialized
INFO - 2023-06-20 11:11:17 --> Loader Class Initialized
INFO - 2023-06-20 11:11:17 --> Helper loaded: url_helper
INFO - 2023-06-20 11:11:17 --> Helper loaded: form_helper
INFO - 2023-06-20 11:11:17 --> Database Driver Class Initialized
INFO - 2023-06-20 11:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:11:17 --> Form Validation Class Initialized
INFO - 2023-06-20 11:11:17 --> Controller Class Initialized
INFO - 2023-06-20 11:11:17 --> Model "m_user" initialized
INFO - 2023-06-20 11:11:17 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:11:17 --> Model "m_penghitungan" initialized
ERROR - 2023-06-20 11:11:17 --> Severity: Error --> Call to undefined method m_penghitungan::getHasilGangguanMoodB1Cukup() C:\xampp\htdocs\sistemdepresi\application\controllers\Test.php 15
INFO - 2023-06-20 11:11:58 --> Config Class Initialized
INFO - 2023-06-20 11:11:58 --> Hooks Class Initialized
INFO - 2023-06-20 11:11:58 --> Utf8 Class Initialized
INFO - 2023-06-20 11:11:58 --> URI Class Initialized
INFO - 2023-06-20 11:11:58 --> Router Class Initialized
INFO - 2023-06-20 11:11:58 --> Output Class Initialized
INFO - 2023-06-20 11:11:58 --> Security Class Initialized
INFO - 2023-06-20 11:11:58 --> Input Class Initialized
INFO - 2023-06-20 11:11:58 --> Language Class Initialized
INFO - 2023-06-20 11:11:58 --> Loader Class Initialized
INFO - 2023-06-20 11:11:58 --> Helper loaded: url_helper
INFO - 2023-06-20 11:11:58 --> Helper loaded: form_helper
INFO - 2023-06-20 11:11:58 --> Database Driver Class Initialized
INFO - 2023-06-20 11:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:11:58 --> Form Validation Class Initialized
INFO - 2023-06-20 11:11:58 --> Controller Class Initialized
INFO - 2023-06-20 11:11:58 --> Model "m_user" initialized
INFO - 2023-06-20 11:11:58 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:11:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:11:58 --> Final output sent to browser
INFO - 2023-06-20 11:13:15 --> Config Class Initialized
INFO - 2023-06-20 11:13:15 --> Hooks Class Initialized
INFO - 2023-06-20 11:13:15 --> Utf8 Class Initialized
INFO - 2023-06-20 11:13:15 --> URI Class Initialized
INFO - 2023-06-20 11:13:15 --> Router Class Initialized
INFO - 2023-06-20 11:13:15 --> Output Class Initialized
INFO - 2023-06-20 11:13:15 --> Security Class Initialized
INFO - 2023-06-20 11:13:15 --> Input Class Initialized
INFO - 2023-06-20 11:13:15 --> Language Class Initialized
INFO - 2023-06-20 11:13:15 --> Loader Class Initialized
INFO - 2023-06-20 11:13:15 --> Helper loaded: url_helper
INFO - 2023-06-20 11:13:15 --> Helper loaded: form_helper
INFO - 2023-06-20 11:13:15 --> Database Driver Class Initialized
INFO - 2023-06-20 11:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:13:15 --> Form Validation Class Initialized
INFO - 2023-06-20 11:13:15 --> Controller Class Initialized
INFO - 2023-06-20 11:13:15 --> Model "m_user" initialized
INFO - 2023-06-20 11:13:15 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:13:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:13:15 --> Final output sent to browser
INFO - 2023-06-20 11:13:35 --> Config Class Initialized
INFO - 2023-06-20 11:13:35 --> Hooks Class Initialized
INFO - 2023-06-20 11:13:35 --> Utf8 Class Initialized
INFO - 2023-06-20 11:13:35 --> URI Class Initialized
INFO - 2023-06-20 11:13:35 --> Router Class Initialized
INFO - 2023-06-20 11:13:35 --> Output Class Initialized
INFO - 2023-06-20 11:13:35 --> Security Class Initialized
INFO - 2023-06-20 11:13:35 --> Input Class Initialized
INFO - 2023-06-20 11:13:35 --> Language Class Initialized
INFO - 2023-06-20 11:13:35 --> Loader Class Initialized
INFO - 2023-06-20 11:13:35 --> Helper loaded: url_helper
INFO - 2023-06-20 11:13:35 --> Helper loaded: form_helper
INFO - 2023-06-20 11:13:35 --> Database Driver Class Initialized
INFO - 2023-06-20 11:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:13:35 --> Form Validation Class Initialized
INFO - 2023-06-20 11:13:35 --> Controller Class Initialized
INFO - 2023-06-20 11:13:35 --> Model "m_user" initialized
INFO - 2023-06-20 11:13:35 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:13:35 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:13:35 --> Final output sent to browser
INFO - 2023-06-20 11:14:12 --> Config Class Initialized
INFO - 2023-06-20 11:14:12 --> Hooks Class Initialized
INFO - 2023-06-20 11:14:12 --> Utf8 Class Initialized
INFO - 2023-06-20 11:14:12 --> URI Class Initialized
INFO - 2023-06-20 11:14:12 --> Router Class Initialized
INFO - 2023-06-20 11:14:12 --> Output Class Initialized
INFO - 2023-06-20 11:14:12 --> Security Class Initialized
INFO - 2023-06-20 11:14:12 --> Input Class Initialized
INFO - 2023-06-20 11:14:12 --> Language Class Initialized
INFO - 2023-06-20 11:14:12 --> Loader Class Initialized
INFO - 2023-06-20 11:14:12 --> Helper loaded: url_helper
INFO - 2023-06-20 11:14:12 --> Helper loaded: form_helper
INFO - 2023-06-20 11:14:12 --> Database Driver Class Initialized
INFO - 2023-06-20 11:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:14:12 --> Form Validation Class Initialized
INFO - 2023-06-20 11:14:12 --> Controller Class Initialized
INFO - 2023-06-20 11:14:12 --> Model "m_user" initialized
INFO - 2023-06-20 11:14:12 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:14:12 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:14:12 --> Final output sent to browser
INFO - 2023-06-20 11:14:24 --> Config Class Initialized
INFO - 2023-06-20 11:14:24 --> Hooks Class Initialized
INFO - 2023-06-20 11:14:24 --> Utf8 Class Initialized
INFO - 2023-06-20 11:14:24 --> URI Class Initialized
INFO - 2023-06-20 11:14:24 --> Router Class Initialized
INFO - 2023-06-20 11:14:24 --> Output Class Initialized
INFO - 2023-06-20 11:14:24 --> Security Class Initialized
INFO - 2023-06-20 11:14:24 --> Input Class Initialized
INFO - 2023-06-20 11:14:24 --> Language Class Initialized
INFO - 2023-06-20 11:14:24 --> Loader Class Initialized
INFO - 2023-06-20 11:14:24 --> Helper loaded: url_helper
INFO - 2023-06-20 11:14:24 --> Helper loaded: form_helper
INFO - 2023-06-20 11:14:24 --> Database Driver Class Initialized
INFO - 2023-06-20 11:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:14:24 --> Form Validation Class Initialized
INFO - 2023-06-20 11:14:24 --> Controller Class Initialized
INFO - 2023-06-20 11:14:24 --> Model "m_user" initialized
INFO - 2023-06-20 11:14:24 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:14:24 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:14:24 --> Final output sent to browser
INFO - 2023-06-20 11:14:32 --> Config Class Initialized
INFO - 2023-06-20 11:14:32 --> Hooks Class Initialized
INFO - 2023-06-20 11:14:32 --> Utf8 Class Initialized
INFO - 2023-06-20 11:14:32 --> URI Class Initialized
INFO - 2023-06-20 11:14:32 --> Router Class Initialized
INFO - 2023-06-20 11:14:32 --> Output Class Initialized
INFO - 2023-06-20 11:14:32 --> Security Class Initialized
INFO - 2023-06-20 11:14:32 --> Input Class Initialized
INFO - 2023-06-20 11:14:32 --> Language Class Initialized
INFO - 2023-06-20 11:14:32 --> Loader Class Initialized
INFO - 2023-06-20 11:14:32 --> Helper loaded: url_helper
INFO - 2023-06-20 11:14:32 --> Helper loaded: form_helper
INFO - 2023-06-20 11:14:32 --> Database Driver Class Initialized
INFO - 2023-06-20 11:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:14:32 --> Form Validation Class Initialized
INFO - 2023-06-20 11:14:32 --> Controller Class Initialized
INFO - 2023-06-20 11:14:32 --> Model "m_user" initialized
INFO - 2023-06-20 11:14:32 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:14:32 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:14:32 --> Final output sent to browser
INFO - 2023-06-20 11:14:40 --> Config Class Initialized
INFO - 2023-06-20 11:14:40 --> Hooks Class Initialized
INFO - 2023-06-20 11:14:40 --> Utf8 Class Initialized
INFO - 2023-06-20 11:14:40 --> URI Class Initialized
INFO - 2023-06-20 11:14:40 --> Router Class Initialized
INFO - 2023-06-20 11:14:40 --> Output Class Initialized
INFO - 2023-06-20 11:14:40 --> Security Class Initialized
INFO - 2023-06-20 11:14:40 --> Input Class Initialized
INFO - 2023-06-20 11:14:40 --> Language Class Initialized
INFO - 2023-06-20 11:14:40 --> Loader Class Initialized
INFO - 2023-06-20 11:14:40 --> Helper loaded: url_helper
INFO - 2023-06-20 11:14:40 --> Helper loaded: form_helper
INFO - 2023-06-20 11:14:40 --> Database Driver Class Initialized
INFO - 2023-06-20 11:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:14:40 --> Form Validation Class Initialized
INFO - 2023-06-20 11:14:40 --> Controller Class Initialized
INFO - 2023-06-20 11:14:40 --> Model "m_user" initialized
INFO - 2023-06-20 11:14:40 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:14:40 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:14:40 --> Final output sent to browser
INFO - 2023-06-20 11:14:48 --> Config Class Initialized
INFO - 2023-06-20 11:14:48 --> Hooks Class Initialized
INFO - 2023-06-20 11:14:48 --> Utf8 Class Initialized
INFO - 2023-06-20 11:14:48 --> URI Class Initialized
INFO - 2023-06-20 11:14:48 --> Router Class Initialized
INFO - 2023-06-20 11:14:48 --> Output Class Initialized
INFO - 2023-06-20 11:14:48 --> Security Class Initialized
INFO - 2023-06-20 11:14:48 --> Input Class Initialized
INFO - 2023-06-20 11:14:48 --> Language Class Initialized
INFO - 2023-06-20 11:14:48 --> Loader Class Initialized
INFO - 2023-06-20 11:14:48 --> Helper loaded: url_helper
INFO - 2023-06-20 11:14:48 --> Helper loaded: form_helper
INFO - 2023-06-20 11:14:48 --> Database Driver Class Initialized
INFO - 2023-06-20 11:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:14:48 --> Form Validation Class Initialized
INFO - 2023-06-20 11:14:48 --> Controller Class Initialized
INFO - 2023-06-20 11:14:48 --> Model "m_user" initialized
INFO - 2023-06-20 11:14:48 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:14:48 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:14:48 --> Final output sent to browser
INFO - 2023-06-20 11:18:14 --> Config Class Initialized
INFO - 2023-06-20 11:18:14 --> Hooks Class Initialized
INFO - 2023-06-20 11:18:14 --> Utf8 Class Initialized
INFO - 2023-06-20 11:18:14 --> URI Class Initialized
INFO - 2023-06-20 11:18:14 --> Router Class Initialized
INFO - 2023-06-20 11:18:14 --> Output Class Initialized
INFO - 2023-06-20 11:18:14 --> Security Class Initialized
INFO - 2023-06-20 11:18:14 --> Input Class Initialized
INFO - 2023-06-20 11:18:14 --> Language Class Initialized
INFO - 2023-06-20 11:18:14 --> Loader Class Initialized
INFO - 2023-06-20 11:18:14 --> Helper loaded: url_helper
INFO - 2023-06-20 11:18:14 --> Helper loaded: form_helper
INFO - 2023-06-20 11:18:14 --> Database Driver Class Initialized
INFO - 2023-06-20 11:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:18:14 --> Form Validation Class Initialized
INFO - 2023-06-20 11:18:14 --> Controller Class Initialized
INFO - 2023-06-20 11:18:14 --> Model "m_user" initialized
INFO - 2023-06-20 11:18:14 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:18:14 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:18:14 --> Final output sent to browser
INFO - 2023-06-20 11:18:14 --> Config Class Initialized
INFO - 2023-06-20 11:18:14 --> Hooks Class Initialized
INFO - 2023-06-20 11:18:14 --> Utf8 Class Initialized
INFO - 2023-06-20 11:18:14 --> URI Class Initialized
INFO - 2023-06-20 11:18:14 --> Router Class Initialized
INFO - 2023-06-20 11:18:14 --> Output Class Initialized
INFO - 2023-06-20 11:18:14 --> Security Class Initialized
INFO - 2023-06-20 11:18:14 --> Input Class Initialized
INFO - 2023-06-20 11:18:14 --> Language Class Initialized
INFO - 2023-06-20 11:18:14 --> Loader Class Initialized
INFO - 2023-06-20 11:18:14 --> Helper loaded: url_helper
INFO - 2023-06-20 11:18:14 --> Helper loaded: form_helper
INFO - 2023-06-20 11:18:14 --> Database Driver Class Initialized
INFO - 2023-06-20 11:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:18:14 --> Form Validation Class Initialized
INFO - 2023-06-20 11:18:14 --> Controller Class Initialized
INFO - 2023-06-20 11:18:14 --> Model "m_user" initialized
INFO - 2023-06-20 11:18:14 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:18:14 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:18:14 --> Final output sent to browser
INFO - 2023-06-20 11:18:15 --> Config Class Initialized
INFO - 2023-06-20 11:18:15 --> Hooks Class Initialized
INFO - 2023-06-20 11:18:15 --> Utf8 Class Initialized
INFO - 2023-06-20 11:18:15 --> URI Class Initialized
INFO - 2023-06-20 11:18:15 --> Router Class Initialized
INFO - 2023-06-20 11:18:15 --> Output Class Initialized
INFO - 2023-06-20 11:18:15 --> Security Class Initialized
INFO - 2023-06-20 11:18:15 --> Input Class Initialized
INFO - 2023-06-20 11:18:15 --> Language Class Initialized
INFO - 2023-06-20 11:18:15 --> Loader Class Initialized
INFO - 2023-06-20 11:18:15 --> Helper loaded: url_helper
INFO - 2023-06-20 11:18:15 --> Helper loaded: form_helper
INFO - 2023-06-20 11:18:15 --> Database Driver Class Initialized
INFO - 2023-06-20 11:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:18:15 --> Form Validation Class Initialized
INFO - 2023-06-20 11:18:15 --> Controller Class Initialized
INFO - 2023-06-20 11:18:15 --> Model "m_user" initialized
INFO - 2023-06-20 11:18:15 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:18:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:18:15 --> Final output sent to browser
INFO - 2023-06-20 11:18:15 --> Config Class Initialized
INFO - 2023-06-20 11:18:15 --> Hooks Class Initialized
INFO - 2023-06-20 11:18:15 --> Utf8 Class Initialized
INFO - 2023-06-20 11:18:15 --> URI Class Initialized
INFO - 2023-06-20 11:18:15 --> Router Class Initialized
INFO - 2023-06-20 11:18:15 --> Output Class Initialized
INFO - 2023-06-20 11:18:15 --> Security Class Initialized
INFO - 2023-06-20 11:18:15 --> Input Class Initialized
INFO - 2023-06-20 11:18:15 --> Language Class Initialized
INFO - 2023-06-20 11:18:15 --> Loader Class Initialized
INFO - 2023-06-20 11:18:15 --> Helper loaded: url_helper
INFO - 2023-06-20 11:18:15 --> Helper loaded: form_helper
INFO - 2023-06-20 11:18:15 --> Database Driver Class Initialized
INFO - 2023-06-20 11:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:18:15 --> Form Validation Class Initialized
INFO - 2023-06-20 11:18:15 --> Controller Class Initialized
INFO - 2023-06-20 11:18:15 --> Model "m_user" initialized
INFO - 2023-06-20 11:18:15 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:18:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:18:15 --> Final output sent to browser
INFO - 2023-06-20 11:18:15 --> Config Class Initialized
INFO - 2023-06-20 11:18:15 --> Hooks Class Initialized
INFO - 2023-06-20 11:18:15 --> Utf8 Class Initialized
INFO - 2023-06-20 11:18:15 --> URI Class Initialized
INFO - 2023-06-20 11:18:15 --> Router Class Initialized
INFO - 2023-06-20 11:18:15 --> Output Class Initialized
INFO - 2023-06-20 11:18:15 --> Security Class Initialized
INFO - 2023-06-20 11:18:15 --> Input Class Initialized
INFO - 2023-06-20 11:18:15 --> Language Class Initialized
INFO - 2023-06-20 11:18:15 --> Loader Class Initialized
INFO - 2023-06-20 11:18:15 --> Helper loaded: url_helper
INFO - 2023-06-20 11:18:15 --> Helper loaded: form_helper
INFO - 2023-06-20 11:18:15 --> Database Driver Class Initialized
INFO - 2023-06-20 11:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:18:15 --> Form Validation Class Initialized
INFO - 2023-06-20 11:18:15 --> Controller Class Initialized
INFO - 2023-06-20 11:18:15 --> Model "m_user" initialized
INFO - 2023-06-20 11:18:15 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:18:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:18:15 --> Final output sent to browser
INFO - 2023-06-20 11:18:15 --> Config Class Initialized
INFO - 2023-06-20 11:18:15 --> Hooks Class Initialized
INFO - 2023-06-20 11:18:15 --> Utf8 Class Initialized
INFO - 2023-06-20 11:18:15 --> URI Class Initialized
INFO - 2023-06-20 11:18:15 --> Router Class Initialized
INFO - 2023-06-20 11:18:15 --> Output Class Initialized
INFO - 2023-06-20 11:18:15 --> Security Class Initialized
INFO - 2023-06-20 11:18:15 --> Input Class Initialized
INFO - 2023-06-20 11:18:15 --> Language Class Initialized
INFO - 2023-06-20 11:18:15 --> Loader Class Initialized
INFO - 2023-06-20 11:18:15 --> Helper loaded: url_helper
INFO - 2023-06-20 11:18:15 --> Helper loaded: form_helper
INFO - 2023-06-20 11:18:15 --> Database Driver Class Initialized
INFO - 2023-06-20 11:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:18:15 --> Form Validation Class Initialized
INFO - 2023-06-20 11:18:15 --> Controller Class Initialized
INFO - 2023-06-20 11:18:15 --> Model "m_user" initialized
INFO - 2023-06-20 11:18:15 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:18:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:18:15 --> Final output sent to browser
INFO - 2023-06-20 11:19:35 --> Config Class Initialized
INFO - 2023-06-20 11:19:35 --> Hooks Class Initialized
INFO - 2023-06-20 11:19:35 --> Utf8 Class Initialized
INFO - 2023-06-20 11:19:35 --> URI Class Initialized
INFO - 2023-06-20 11:19:35 --> Router Class Initialized
INFO - 2023-06-20 11:19:35 --> Output Class Initialized
INFO - 2023-06-20 11:19:35 --> Security Class Initialized
INFO - 2023-06-20 11:19:35 --> Input Class Initialized
INFO - 2023-06-20 11:19:35 --> Language Class Initialized
INFO - 2023-06-20 11:19:35 --> Loader Class Initialized
INFO - 2023-06-20 11:19:35 --> Helper loaded: url_helper
INFO - 2023-06-20 11:19:35 --> Helper loaded: form_helper
INFO - 2023-06-20 11:19:35 --> Database Driver Class Initialized
INFO - 2023-06-20 11:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:19:35 --> Form Validation Class Initialized
INFO - 2023-06-20 11:19:35 --> Controller Class Initialized
INFO - 2023-06-20 11:19:35 --> Model "m_user" initialized
INFO - 2023-06-20 11:19:35 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:19:35 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:19:35 --> Final output sent to browser
INFO - 2023-06-20 11:19:44 --> Config Class Initialized
INFO - 2023-06-20 11:19:44 --> Hooks Class Initialized
INFO - 2023-06-20 11:19:45 --> Utf8 Class Initialized
INFO - 2023-06-20 11:19:45 --> URI Class Initialized
INFO - 2023-06-20 11:19:45 --> Router Class Initialized
INFO - 2023-06-20 11:19:45 --> Output Class Initialized
INFO - 2023-06-20 11:19:45 --> Security Class Initialized
INFO - 2023-06-20 11:19:45 --> Input Class Initialized
INFO - 2023-06-20 11:19:45 --> Language Class Initialized
INFO - 2023-06-20 11:19:45 --> Loader Class Initialized
INFO - 2023-06-20 11:19:45 --> Helper loaded: url_helper
INFO - 2023-06-20 11:19:45 --> Helper loaded: form_helper
INFO - 2023-06-20 11:19:45 --> Database Driver Class Initialized
INFO - 2023-06-20 11:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:19:45 --> Form Validation Class Initialized
INFO - 2023-06-20 11:19:45 --> Controller Class Initialized
INFO - 2023-06-20 11:19:45 --> Model "m_user" initialized
INFO - 2023-06-20 11:19:45 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:19:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:19:45 --> Final output sent to browser
INFO - 2023-06-20 11:19:53 --> Config Class Initialized
INFO - 2023-06-20 11:19:53 --> Hooks Class Initialized
INFO - 2023-06-20 11:19:53 --> Utf8 Class Initialized
INFO - 2023-06-20 11:19:53 --> URI Class Initialized
INFO - 2023-06-20 11:19:53 --> Router Class Initialized
INFO - 2023-06-20 11:19:53 --> Output Class Initialized
INFO - 2023-06-20 11:19:53 --> Security Class Initialized
INFO - 2023-06-20 11:19:53 --> Input Class Initialized
INFO - 2023-06-20 11:19:53 --> Language Class Initialized
INFO - 2023-06-20 11:19:53 --> Loader Class Initialized
INFO - 2023-06-20 11:19:53 --> Helper loaded: url_helper
INFO - 2023-06-20 11:19:53 --> Helper loaded: form_helper
INFO - 2023-06-20 11:19:53 --> Database Driver Class Initialized
INFO - 2023-06-20 11:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:19:53 --> Form Validation Class Initialized
INFO - 2023-06-20 11:19:53 --> Controller Class Initialized
INFO - 2023-06-20 11:19:53 --> Model "m_user" initialized
INFO - 2023-06-20 11:19:53 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:19:53 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:19:53 --> Final output sent to browser
INFO - 2023-06-20 11:31:50 --> Config Class Initialized
INFO - 2023-06-20 11:31:50 --> Hooks Class Initialized
INFO - 2023-06-20 11:31:50 --> Utf8 Class Initialized
INFO - 2023-06-20 11:31:50 --> URI Class Initialized
INFO - 2023-06-20 11:31:50 --> Router Class Initialized
INFO - 2023-06-20 11:31:50 --> Output Class Initialized
INFO - 2023-06-20 11:31:50 --> Security Class Initialized
INFO - 2023-06-20 11:31:50 --> Input Class Initialized
INFO - 2023-06-20 11:31:50 --> Language Class Initialized
INFO - 2023-06-20 11:31:50 --> Loader Class Initialized
INFO - 2023-06-20 11:31:50 --> Helper loaded: url_helper
INFO - 2023-06-20 11:31:50 --> Helper loaded: form_helper
INFO - 2023-06-20 11:31:50 --> Database Driver Class Initialized
INFO - 2023-06-20 11:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:31:50 --> Form Validation Class Initialized
INFO - 2023-06-20 11:31:50 --> Controller Class Initialized
INFO - 2023-06-20 11:31:50 --> Model "m_user" initialized
INFO - 2023-06-20 11:31:50 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:31:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:31:50 --> Final output sent to browser
INFO - 2023-06-20 11:37:56 --> Config Class Initialized
INFO - 2023-06-20 11:37:56 --> Hooks Class Initialized
INFO - 2023-06-20 11:37:57 --> Utf8 Class Initialized
INFO - 2023-06-20 11:37:57 --> URI Class Initialized
INFO - 2023-06-20 11:37:57 --> Router Class Initialized
INFO - 2023-06-20 11:37:57 --> Output Class Initialized
INFO - 2023-06-20 11:37:57 --> Security Class Initialized
INFO - 2023-06-20 11:37:57 --> Input Class Initialized
INFO - 2023-06-20 11:37:57 --> Language Class Initialized
INFO - 2023-06-20 11:37:57 --> Loader Class Initialized
INFO - 2023-06-20 11:37:57 --> Helper loaded: url_helper
INFO - 2023-06-20 11:37:57 --> Helper loaded: form_helper
INFO - 2023-06-20 11:37:57 --> Database Driver Class Initialized
INFO - 2023-06-20 11:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:37:57 --> Form Validation Class Initialized
INFO - 2023-06-20 11:37:57 --> Controller Class Initialized
INFO - 2023-06-20 11:37:57 --> Model "m_user" initialized
INFO - 2023-06-20 11:37:57 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:37:57 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:37:57 --> Final output sent to browser
INFO - 2023-06-20 11:39:41 --> Config Class Initialized
INFO - 2023-06-20 11:39:41 --> Hooks Class Initialized
INFO - 2023-06-20 11:39:41 --> Utf8 Class Initialized
INFO - 2023-06-20 11:39:41 --> URI Class Initialized
INFO - 2023-06-20 11:39:41 --> Router Class Initialized
INFO - 2023-06-20 11:39:41 --> Output Class Initialized
INFO - 2023-06-20 11:39:41 --> Security Class Initialized
INFO - 2023-06-20 11:39:41 --> Input Class Initialized
INFO - 2023-06-20 11:39:41 --> Language Class Initialized
INFO - 2023-06-20 11:39:41 --> Loader Class Initialized
INFO - 2023-06-20 11:39:41 --> Helper loaded: url_helper
INFO - 2023-06-20 11:39:41 --> Helper loaded: form_helper
INFO - 2023-06-20 11:39:41 --> Database Driver Class Initialized
INFO - 2023-06-20 11:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:39:41 --> Form Validation Class Initialized
INFO - 2023-06-20 11:39:41 --> Controller Class Initialized
INFO - 2023-06-20 11:39:41 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:39:41 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:39:41 --> Model "m_datatest" initialized
INFO - 2023-06-20 11:39:41 --> Model "M_solusi" initialized
INFO - 2023-06-20 11:39:41 --> Final output sent to browser
INFO - 2023-06-20 11:40:32 --> Config Class Initialized
INFO - 2023-06-20 11:40:32 --> Hooks Class Initialized
INFO - 2023-06-20 11:40:32 --> Utf8 Class Initialized
INFO - 2023-06-20 11:40:32 --> URI Class Initialized
INFO - 2023-06-20 11:40:32 --> Router Class Initialized
INFO - 2023-06-20 11:40:32 --> Output Class Initialized
INFO - 2023-06-20 11:40:32 --> Security Class Initialized
INFO - 2023-06-20 11:40:32 --> Input Class Initialized
INFO - 2023-06-20 11:40:32 --> Language Class Initialized
INFO - 2023-06-20 11:40:32 --> Loader Class Initialized
INFO - 2023-06-20 11:40:32 --> Helper loaded: url_helper
INFO - 2023-06-20 11:40:32 --> Helper loaded: form_helper
INFO - 2023-06-20 11:40:32 --> Database Driver Class Initialized
INFO - 2023-06-20 11:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:40:32 --> Form Validation Class Initialized
INFO - 2023-06-20 11:40:32 --> Controller Class Initialized
INFO - 2023-06-20 11:40:32 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:40:32 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:40:32 --> Model "m_datatest" initialized
INFO - 2023-06-20 11:40:32 --> Model "M_solusi" initialized
INFO - 2023-06-20 11:40:32 --> Final output sent to browser
INFO - 2023-06-20 11:41:06 --> Config Class Initialized
INFO - 2023-06-20 11:41:06 --> Hooks Class Initialized
INFO - 2023-06-20 11:41:06 --> Utf8 Class Initialized
INFO - 2023-06-20 11:41:06 --> URI Class Initialized
INFO - 2023-06-20 11:41:06 --> Router Class Initialized
INFO - 2023-06-20 11:41:06 --> Output Class Initialized
INFO - 2023-06-20 11:41:06 --> Security Class Initialized
INFO - 2023-06-20 11:41:06 --> Input Class Initialized
INFO - 2023-06-20 11:41:06 --> Language Class Initialized
INFO - 2023-06-20 11:41:06 --> Loader Class Initialized
INFO - 2023-06-20 11:41:06 --> Helper loaded: url_helper
INFO - 2023-06-20 11:41:06 --> Helper loaded: form_helper
INFO - 2023-06-20 11:41:06 --> Database Driver Class Initialized
INFO - 2023-06-20 11:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:41:06 --> Form Validation Class Initialized
INFO - 2023-06-20 11:41:06 --> Controller Class Initialized
INFO - 2023-06-20 11:41:06 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:41:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:41:06 --> Model "m_datatest" initialized
INFO - 2023-06-20 11:41:06 --> Model "M_solusi" initialized
INFO - 2023-06-20 11:41:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-20 11:41:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-20 11:41:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-20 11:41:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-20 11:41:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-20 11:41:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-20 11:41:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-20 11:41:06 --> Final output sent to browser
INFO - 2023-06-20 11:42:26 --> Config Class Initialized
INFO - 2023-06-20 11:42:26 --> Hooks Class Initialized
INFO - 2023-06-20 11:42:26 --> Utf8 Class Initialized
INFO - 2023-06-20 11:42:26 --> URI Class Initialized
INFO - 2023-06-20 11:42:26 --> Router Class Initialized
INFO - 2023-06-20 11:42:26 --> Output Class Initialized
INFO - 2023-06-20 11:42:26 --> Security Class Initialized
INFO - 2023-06-20 11:42:26 --> Input Class Initialized
INFO - 2023-06-20 11:42:26 --> Language Class Initialized
INFO - 2023-06-20 11:42:26 --> Loader Class Initialized
INFO - 2023-06-20 11:42:26 --> Helper loaded: url_helper
INFO - 2023-06-20 11:42:26 --> Helper loaded: form_helper
INFO - 2023-06-20 11:42:26 --> Database Driver Class Initialized
INFO - 2023-06-20 11:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:42:26 --> Form Validation Class Initialized
INFO - 2023-06-20 11:42:26 --> Controller Class Initialized
INFO - 2023-06-20 11:42:26 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:42:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:42:26 --> Model "m_datatest" initialized
INFO - 2023-06-20 11:42:26 --> Model "M_solusi" initialized
INFO - 2023-06-20 11:42:26 --> Final output sent to browser
INFO - 2023-06-20 11:43:15 --> Config Class Initialized
INFO - 2023-06-20 11:43:15 --> Hooks Class Initialized
INFO - 2023-06-20 11:43:15 --> Utf8 Class Initialized
INFO - 2023-06-20 11:43:15 --> URI Class Initialized
INFO - 2023-06-20 11:43:15 --> Router Class Initialized
INFO - 2023-06-20 11:43:15 --> Output Class Initialized
INFO - 2023-06-20 11:43:15 --> Security Class Initialized
INFO - 2023-06-20 11:43:15 --> Input Class Initialized
INFO - 2023-06-20 11:43:15 --> Language Class Initialized
INFO - 2023-06-20 11:43:15 --> Loader Class Initialized
INFO - 2023-06-20 11:43:15 --> Helper loaded: url_helper
INFO - 2023-06-20 11:43:15 --> Helper loaded: form_helper
INFO - 2023-06-20 11:43:15 --> Database Driver Class Initialized
INFO - 2023-06-20 11:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:43:15 --> Form Validation Class Initialized
INFO - 2023-06-20 11:43:15 --> Controller Class Initialized
INFO - 2023-06-20 11:43:15 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:43:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:43:15 --> Model "m_datatest" initialized
INFO - 2023-06-20 11:43:15 --> Model "M_solusi" initialized
INFO - 2023-06-20 11:43:16 --> Final output sent to browser
INFO - 2023-06-20 11:43:47 --> Config Class Initialized
INFO - 2023-06-20 11:43:47 --> Hooks Class Initialized
INFO - 2023-06-20 11:43:47 --> Utf8 Class Initialized
INFO - 2023-06-20 11:43:47 --> URI Class Initialized
INFO - 2023-06-20 11:43:47 --> Router Class Initialized
INFO - 2023-06-20 11:43:47 --> Output Class Initialized
INFO - 2023-06-20 11:43:47 --> Security Class Initialized
INFO - 2023-06-20 11:43:47 --> Input Class Initialized
INFO - 2023-06-20 11:43:47 --> Language Class Initialized
INFO - 2023-06-20 11:43:47 --> Loader Class Initialized
INFO - 2023-06-20 11:43:47 --> Helper loaded: url_helper
INFO - 2023-06-20 11:43:47 --> Helper loaded: form_helper
INFO - 2023-06-20 11:43:47 --> Database Driver Class Initialized
INFO - 2023-06-20 11:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:43:47 --> Form Validation Class Initialized
INFO - 2023-06-20 11:43:47 --> Controller Class Initialized
INFO - 2023-06-20 11:43:47 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:43:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:43:47 --> Model "m_datatest" initialized
INFO - 2023-06-20 11:43:47 --> Model "M_solusi" initialized
INFO - 2023-06-20 11:43:47 --> Final output sent to browser
INFO - 2023-06-20 11:43:52 --> Config Class Initialized
INFO - 2023-06-20 11:43:52 --> Hooks Class Initialized
INFO - 2023-06-20 11:43:52 --> Utf8 Class Initialized
INFO - 2023-06-20 11:43:52 --> URI Class Initialized
INFO - 2023-06-20 11:43:52 --> Router Class Initialized
INFO - 2023-06-20 11:43:52 --> Output Class Initialized
INFO - 2023-06-20 11:43:52 --> Security Class Initialized
INFO - 2023-06-20 11:43:52 --> Input Class Initialized
INFO - 2023-06-20 11:43:52 --> Language Class Initialized
INFO - 2023-06-20 11:43:52 --> Loader Class Initialized
INFO - 2023-06-20 11:43:52 --> Helper loaded: url_helper
INFO - 2023-06-20 11:43:52 --> Helper loaded: form_helper
INFO - 2023-06-20 11:43:52 --> Database Driver Class Initialized
INFO - 2023-06-20 11:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:43:52 --> Form Validation Class Initialized
INFO - 2023-06-20 11:43:52 --> Controller Class Initialized
INFO - 2023-06-20 11:43:52 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:43:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:43:52 --> Model "m_datatest" initialized
INFO - 2023-06-20 11:43:52 --> Model "M_solusi" initialized
INFO - 2023-06-20 11:43:53 --> Final output sent to browser
INFO - 2023-06-20 11:44:30 --> Config Class Initialized
INFO - 2023-06-20 11:44:30 --> Hooks Class Initialized
INFO - 2023-06-20 11:44:30 --> Utf8 Class Initialized
INFO - 2023-06-20 11:44:30 --> URI Class Initialized
INFO - 2023-06-20 11:44:30 --> Router Class Initialized
INFO - 2023-06-20 11:44:30 --> Output Class Initialized
INFO - 2023-06-20 11:44:30 --> Security Class Initialized
INFO - 2023-06-20 11:44:30 --> Input Class Initialized
INFO - 2023-06-20 11:44:30 --> Language Class Initialized
INFO - 2023-06-20 11:44:30 --> Loader Class Initialized
INFO - 2023-06-20 11:44:30 --> Helper loaded: url_helper
INFO - 2023-06-20 11:44:30 --> Helper loaded: form_helper
INFO - 2023-06-20 11:44:30 --> Database Driver Class Initialized
INFO - 2023-06-20 11:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:44:30 --> Form Validation Class Initialized
INFO - 2023-06-20 11:44:30 --> Controller Class Initialized
INFO - 2023-06-20 11:44:30 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:44:30 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:44:30 --> Model "m_datatest" initialized
INFO - 2023-06-20 11:44:30 --> Model "M_solusi" initialized
INFO - 2023-06-20 11:44:30 --> Final output sent to browser
INFO - 2023-06-20 11:45:09 --> Config Class Initialized
INFO - 2023-06-20 11:45:09 --> Hooks Class Initialized
INFO - 2023-06-20 11:45:09 --> Utf8 Class Initialized
INFO - 2023-06-20 11:45:09 --> URI Class Initialized
INFO - 2023-06-20 11:45:09 --> Router Class Initialized
INFO - 2023-06-20 11:45:09 --> Output Class Initialized
INFO - 2023-06-20 11:45:09 --> Security Class Initialized
INFO - 2023-06-20 11:45:09 --> Input Class Initialized
INFO - 2023-06-20 11:45:09 --> Language Class Initialized
INFO - 2023-06-20 11:45:09 --> Loader Class Initialized
INFO - 2023-06-20 11:45:09 --> Helper loaded: url_helper
INFO - 2023-06-20 11:45:09 --> Helper loaded: form_helper
INFO - 2023-06-20 11:45:09 --> Database Driver Class Initialized
INFO - 2023-06-20 11:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:45:09 --> Form Validation Class Initialized
INFO - 2023-06-20 11:45:09 --> Controller Class Initialized
INFO - 2023-06-20 11:45:09 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:45:09 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:45:09 --> Model "m_datatest" initialized
INFO - 2023-06-20 11:45:09 --> Model "M_solusi" initialized
INFO - 2023-06-20 11:45:10 --> Final output sent to browser
INFO - 2023-06-20 11:47:22 --> Config Class Initialized
INFO - 2023-06-20 11:47:22 --> Hooks Class Initialized
INFO - 2023-06-20 11:47:22 --> Utf8 Class Initialized
INFO - 2023-06-20 11:47:22 --> URI Class Initialized
INFO - 2023-06-20 11:47:22 --> Router Class Initialized
INFO - 2023-06-20 11:47:22 --> Output Class Initialized
INFO - 2023-06-20 11:47:22 --> Security Class Initialized
INFO - 2023-06-20 11:47:22 --> Input Class Initialized
INFO - 2023-06-20 11:47:22 --> Language Class Initialized
INFO - 2023-06-20 11:47:22 --> Loader Class Initialized
INFO - 2023-06-20 11:47:22 --> Helper loaded: url_helper
INFO - 2023-06-20 11:47:22 --> Helper loaded: form_helper
INFO - 2023-06-20 11:47:22 --> Database Driver Class Initialized
INFO - 2023-06-20 11:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-20 11:47:22 --> Form Validation Class Initialized
INFO - 2023-06-20 11:47:22 --> Controller Class Initialized
INFO - 2023-06-20 11:47:22 --> Model "m_datatrain" initialized
INFO - 2023-06-20 11:47:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-20 11:47:22 --> Model "m_datatest" initialized
INFO - 2023-06-20 11:47:22 --> Model "M_solusi" initialized
INFO - 2023-06-20 11:47:23 --> Final output sent to browser
