<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-28 15:47:28 --> Config Class Initialized
INFO - 2023-05-28 15:47:28 --> Hooks Class Initialized
INFO - 2023-05-28 15:47:28 --> Utf8 Class Initialized
INFO - 2023-05-28 15:47:28 --> URI Class Initialized
INFO - 2023-05-28 15:47:28 --> Router Class Initialized
INFO - 2023-05-28 15:47:28 --> Output Class Initialized
INFO - 2023-05-28 15:47:28 --> Security Class Initialized
INFO - 2023-05-28 15:47:28 --> Input Class Initialized
INFO - 2023-05-28 15:47:28 --> Language Class Initialized
INFO - 2023-05-28 15:47:29 --> Loader Class Initialized
INFO - 2023-05-28 15:47:29 --> Helper loaded: url_helper
INFO - 2023-05-28 15:47:29 --> Helper loaded: form_helper
INFO - 2023-05-28 15:47:29 --> Database Driver Class Initialized
INFO - 2023-05-28 15:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:47:29 --> Form Validation Class Initialized
INFO - 2023-05-28 15:47:29 --> Controller Class Initialized
INFO - 2023-05-28 15:47:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 15:47:29 --> Final output sent to browser
INFO - 2023-05-28 15:54:07 --> Config Class Initialized
INFO - 2023-05-28 15:54:07 --> Hooks Class Initialized
INFO - 2023-05-28 15:54:07 --> Utf8 Class Initialized
INFO - 2023-05-28 15:54:07 --> URI Class Initialized
INFO - 2023-05-28 15:54:07 --> Router Class Initialized
INFO - 2023-05-28 15:54:07 --> Output Class Initialized
INFO - 2023-05-28 15:54:07 --> Security Class Initialized
INFO - 2023-05-28 15:54:07 --> Input Class Initialized
INFO - 2023-05-28 15:54:07 --> Language Class Initialized
INFO - 2023-05-28 15:54:07 --> Loader Class Initialized
INFO - 2023-05-28 15:54:07 --> Helper loaded: url_helper
INFO - 2023-05-28 15:54:07 --> Helper loaded: form_helper
INFO - 2023-05-28 15:54:07 --> Database Driver Class Initialized
INFO - 2023-05-28 15:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:54:07 --> Form Validation Class Initialized
INFO - 2023-05-28 15:54:07 --> Controller Class Initialized
INFO - 2023-05-28 15:54:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 15:54:07 --> Final output sent to browser
INFO - 2023-05-28 15:54:09 --> Config Class Initialized
INFO - 2023-05-28 15:54:09 --> Hooks Class Initialized
INFO - 2023-05-28 15:54:09 --> Utf8 Class Initialized
INFO - 2023-05-28 15:54:09 --> URI Class Initialized
INFO - 2023-05-28 15:54:09 --> Router Class Initialized
INFO - 2023-05-28 15:54:09 --> Output Class Initialized
INFO - 2023-05-28 15:54:09 --> Security Class Initialized
INFO - 2023-05-28 15:54:09 --> Input Class Initialized
INFO - 2023-05-28 15:54:09 --> Language Class Initialized
INFO - 2023-05-28 15:54:09 --> Loader Class Initialized
INFO - 2023-05-28 15:54:09 --> Helper loaded: url_helper
INFO - 2023-05-28 15:54:09 --> Helper loaded: form_helper
INFO - 2023-05-28 15:54:09 --> Database Driver Class Initialized
INFO - 2023-05-28 15:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:54:09 --> Form Validation Class Initialized
INFO - 2023-05-28 15:54:09 --> Controller Class Initialized
INFO - 2023-05-28 15:54:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 15:54:09 --> Final output sent to browser
INFO - 2023-05-28 15:54:19 --> Config Class Initialized
INFO - 2023-05-28 15:54:19 --> Hooks Class Initialized
INFO - 2023-05-28 15:54:19 --> Utf8 Class Initialized
INFO - 2023-05-28 15:54:19 --> URI Class Initialized
INFO - 2023-05-28 15:54:19 --> Router Class Initialized
INFO - 2023-05-28 15:54:19 --> Output Class Initialized
INFO - 2023-05-28 15:54:19 --> Security Class Initialized
INFO - 2023-05-28 15:54:19 --> Input Class Initialized
INFO - 2023-05-28 15:54:19 --> Language Class Initialized
INFO - 2023-05-28 15:54:19 --> Loader Class Initialized
INFO - 2023-05-28 15:54:19 --> Helper loaded: url_helper
INFO - 2023-05-28 15:54:19 --> Helper loaded: form_helper
INFO - 2023-05-28 15:54:19 --> Database Driver Class Initialized
INFO - 2023-05-28 15:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:54:19 --> Form Validation Class Initialized
INFO - 2023-05-28 15:54:19 --> Controller Class Initialized
INFO - 2023-05-28 15:54:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 15:54:19 --> Final output sent to browser
INFO - 2023-05-28 15:54:21 --> Config Class Initialized
INFO - 2023-05-28 15:54:21 --> Hooks Class Initialized
INFO - 2023-05-28 15:54:21 --> Utf8 Class Initialized
INFO - 2023-05-28 15:54:21 --> URI Class Initialized
INFO - 2023-05-28 15:54:21 --> Router Class Initialized
INFO - 2023-05-28 15:54:21 --> Output Class Initialized
INFO - 2023-05-28 15:54:21 --> Security Class Initialized
INFO - 2023-05-28 15:54:21 --> Input Class Initialized
INFO - 2023-05-28 15:54:21 --> Language Class Initialized
INFO - 2023-05-28 15:54:21 --> Loader Class Initialized
INFO - 2023-05-28 15:54:21 --> Helper loaded: url_helper
INFO - 2023-05-28 15:54:21 --> Helper loaded: form_helper
INFO - 2023-05-28 15:54:21 --> Database Driver Class Initialized
INFO - 2023-05-28 15:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:54:21 --> Form Validation Class Initialized
INFO - 2023-05-28 15:54:21 --> Controller Class Initialized
INFO - 2023-05-28 15:54:21 --> Model "m_user" initialized
INFO - 2023-05-28 15:54:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-28 15:54:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-28 15:54:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-28 15:54:22 --> Final output sent to browser
INFO - 2023-05-28 15:54:24 --> Config Class Initialized
INFO - 2023-05-28 15:54:24 --> Hooks Class Initialized
INFO - 2023-05-28 15:54:24 --> Utf8 Class Initialized
INFO - 2023-05-28 15:54:25 --> URI Class Initialized
INFO - 2023-05-28 15:54:25 --> Router Class Initialized
INFO - 2023-05-28 15:54:25 --> Output Class Initialized
INFO - 2023-05-28 15:54:25 --> Security Class Initialized
INFO - 2023-05-28 15:54:25 --> Input Class Initialized
INFO - 2023-05-28 15:54:25 --> Language Class Initialized
INFO - 2023-05-28 15:54:25 --> Loader Class Initialized
INFO - 2023-05-28 15:54:25 --> Helper loaded: url_helper
INFO - 2023-05-28 15:54:25 --> Helper loaded: form_helper
INFO - 2023-05-28 15:54:25 --> Database Driver Class Initialized
INFO - 2023-05-28 15:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:54:25 --> Form Validation Class Initialized
INFO - 2023-05-28 15:54:25 --> Controller Class Initialized
INFO - 2023-05-28 15:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 15:54:25 --> Final output sent to browser
INFO - 2023-05-28 15:54:27 --> Config Class Initialized
INFO - 2023-05-28 15:54:27 --> Hooks Class Initialized
INFO - 2023-05-28 15:54:27 --> Utf8 Class Initialized
INFO - 2023-05-28 15:54:27 --> URI Class Initialized
INFO - 2023-05-28 15:54:27 --> Router Class Initialized
INFO - 2023-05-28 15:54:27 --> Output Class Initialized
INFO - 2023-05-28 15:54:27 --> Security Class Initialized
INFO - 2023-05-28 15:54:27 --> Input Class Initialized
INFO - 2023-05-28 15:54:27 --> Language Class Initialized
INFO - 2023-05-28 15:54:27 --> Loader Class Initialized
INFO - 2023-05-28 15:54:27 --> Helper loaded: url_helper
INFO - 2023-05-28 15:54:27 --> Helper loaded: form_helper
INFO - 2023-05-28 15:54:27 --> Database Driver Class Initialized
INFO - 2023-05-28 15:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:54:27 --> Form Validation Class Initialized
INFO - 2023-05-28 15:54:27 --> Controller Class Initialized
INFO - 2023-05-28 15:54:27 --> Model "m_user" initialized
INFO - 2023-05-28 15:54:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 15:54:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-28 15:54:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-28 15:54:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-28 15:54:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-28 15:54:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-28 15:54:27 --> Final output sent to browser
INFO - 2023-05-28 15:54:33 --> Config Class Initialized
INFO - 2023-05-28 15:54:33 --> Hooks Class Initialized
INFO - 2023-05-28 15:54:33 --> Utf8 Class Initialized
INFO - 2023-05-28 15:54:34 --> URI Class Initialized
INFO - 2023-05-28 15:54:34 --> Router Class Initialized
INFO - 2023-05-28 15:54:34 --> Output Class Initialized
INFO - 2023-05-28 15:54:34 --> Security Class Initialized
INFO - 2023-05-28 15:54:34 --> Input Class Initialized
INFO - 2023-05-28 15:54:34 --> Language Class Initialized
INFO - 2023-05-28 15:54:34 --> Loader Class Initialized
INFO - 2023-05-28 15:54:34 --> Helper loaded: url_helper
INFO - 2023-05-28 15:54:34 --> Helper loaded: form_helper
INFO - 2023-05-28 15:54:34 --> Database Driver Class Initialized
INFO - 2023-05-28 15:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:54:34 --> Form Validation Class Initialized
INFO - 2023-05-28 15:54:34 --> Controller Class Initialized
INFO - 2023-05-28 15:54:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 15:54:34 --> Final output sent to browser
INFO - 2023-05-28 15:54:35 --> Config Class Initialized
INFO - 2023-05-28 15:54:35 --> Hooks Class Initialized
INFO - 2023-05-28 15:54:35 --> Utf8 Class Initialized
INFO - 2023-05-28 15:54:35 --> URI Class Initialized
INFO - 2023-05-28 15:54:35 --> Router Class Initialized
INFO - 2023-05-28 15:54:35 --> Output Class Initialized
INFO - 2023-05-28 15:54:35 --> Security Class Initialized
INFO - 2023-05-28 15:54:35 --> Input Class Initialized
INFO - 2023-05-28 15:54:35 --> Language Class Initialized
INFO - 2023-05-28 15:54:35 --> Loader Class Initialized
INFO - 2023-05-28 15:54:35 --> Helper loaded: url_helper
INFO - 2023-05-28 15:54:35 --> Helper loaded: form_helper
INFO - 2023-05-28 15:54:35 --> Database Driver Class Initialized
INFO - 2023-05-28 15:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:54:35 --> Form Validation Class Initialized
INFO - 2023-05-28 15:54:35 --> Controller Class Initialized
INFO - 2023-05-28 15:54:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 15:54:35 --> Final output sent to browser
INFO - 2023-05-28 15:55:29 --> Config Class Initialized
INFO - 2023-05-28 15:55:29 --> Hooks Class Initialized
INFO - 2023-05-28 15:55:29 --> Utf8 Class Initialized
INFO - 2023-05-28 15:55:29 --> URI Class Initialized
INFO - 2023-05-28 15:55:29 --> Router Class Initialized
INFO - 2023-05-28 15:55:29 --> Output Class Initialized
INFO - 2023-05-28 15:55:29 --> Security Class Initialized
INFO - 2023-05-28 15:55:29 --> Input Class Initialized
INFO - 2023-05-28 15:55:29 --> Language Class Initialized
INFO - 2023-05-28 15:55:29 --> Loader Class Initialized
INFO - 2023-05-28 15:55:29 --> Helper loaded: url_helper
INFO - 2023-05-28 15:55:29 --> Helper loaded: form_helper
INFO - 2023-05-28 15:55:29 --> Database Driver Class Initialized
INFO - 2023-05-28 15:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:55:29 --> Form Validation Class Initialized
INFO - 2023-05-28 15:55:29 --> Controller Class Initialized
INFO - 2023-05-28 15:55:29 --> Model "m_user" initialized
INFO - 2023-05-28 15:55:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 15:55:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-28 15:55:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-28 15:55:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-28 15:55:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-28 15:55:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-28 15:55:29 --> Final output sent to browser
INFO - 2023-05-28 15:56:45 --> Config Class Initialized
INFO - 2023-05-28 15:56:45 --> Hooks Class Initialized
INFO - 2023-05-28 15:56:45 --> Utf8 Class Initialized
INFO - 2023-05-28 15:56:45 --> URI Class Initialized
INFO - 2023-05-28 15:56:45 --> Router Class Initialized
INFO - 2023-05-28 15:56:45 --> Output Class Initialized
INFO - 2023-05-28 15:56:45 --> Security Class Initialized
INFO - 2023-05-28 15:56:45 --> Input Class Initialized
INFO - 2023-05-28 15:56:45 --> Language Class Initialized
INFO - 2023-05-28 15:56:45 --> Loader Class Initialized
INFO - 2023-05-28 15:56:45 --> Helper loaded: url_helper
INFO - 2023-05-28 15:56:45 --> Helper loaded: form_helper
INFO - 2023-05-28 15:56:45 --> Database Driver Class Initialized
INFO - 2023-05-28 15:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:56:45 --> Form Validation Class Initialized
INFO - 2023-05-28 15:56:45 --> Controller Class Initialized
INFO - 2023-05-28 15:56:45 --> Model "m_user" initialized
INFO - 2023-05-28 15:56:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 15:56:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-28 15:56:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-28 15:56:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-28 15:56:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-28 15:56:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-28 15:56:45 --> Final output sent to browser
INFO - 2023-05-28 15:57:16 --> Config Class Initialized
INFO - 2023-05-28 15:57:16 --> Hooks Class Initialized
INFO - 2023-05-28 15:57:16 --> Utf8 Class Initialized
INFO - 2023-05-28 15:57:16 --> URI Class Initialized
INFO - 2023-05-28 15:57:16 --> Router Class Initialized
INFO - 2023-05-28 15:57:16 --> Output Class Initialized
INFO - 2023-05-28 15:57:16 --> Security Class Initialized
INFO - 2023-05-28 15:57:16 --> Input Class Initialized
INFO - 2023-05-28 15:57:16 --> Language Class Initialized
INFO - 2023-05-28 15:57:16 --> Loader Class Initialized
INFO - 2023-05-28 15:57:16 --> Helper loaded: url_helper
INFO - 2023-05-28 15:57:16 --> Helper loaded: form_helper
INFO - 2023-05-28 15:57:16 --> Database Driver Class Initialized
INFO - 2023-05-28 15:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:57:17 --> Form Validation Class Initialized
INFO - 2023-05-28 15:57:17 --> Controller Class Initialized
INFO - 2023-05-28 15:57:17 --> Model "m_user" initialized
INFO - 2023-05-28 15:57:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 15:57:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-28 15:57:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-28 15:57:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-28 15:57:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-28 15:57:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-28 15:57:17 --> Final output sent to browser
INFO - 2023-05-28 15:57:32 --> Config Class Initialized
INFO - 2023-05-28 15:57:32 --> Hooks Class Initialized
INFO - 2023-05-28 15:57:32 --> Utf8 Class Initialized
INFO - 2023-05-28 15:57:32 --> URI Class Initialized
INFO - 2023-05-28 15:57:32 --> Router Class Initialized
INFO - 2023-05-28 15:57:32 --> Output Class Initialized
INFO - 2023-05-28 15:57:32 --> Security Class Initialized
INFO - 2023-05-28 15:57:32 --> Input Class Initialized
INFO - 2023-05-28 15:57:32 --> Language Class Initialized
INFO - 2023-05-28 15:57:32 --> Loader Class Initialized
INFO - 2023-05-28 15:57:32 --> Helper loaded: url_helper
INFO - 2023-05-28 15:57:32 --> Helper loaded: form_helper
INFO - 2023-05-28 15:57:32 --> Database Driver Class Initialized
INFO - 2023-05-28 15:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:57:32 --> Form Validation Class Initialized
INFO - 2023-05-28 15:57:32 --> Controller Class Initialized
INFO - 2023-05-28 15:57:32 --> Model "m_user" initialized
INFO - 2023-05-28 15:57:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 15:57:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-28 15:57:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-28 15:57:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-28 15:57:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-28 15:57:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-28 15:57:32 --> Final output sent to browser
INFO - 2023-05-28 15:57:47 --> Config Class Initialized
INFO - 2023-05-28 15:57:47 --> Hooks Class Initialized
INFO - 2023-05-28 15:57:47 --> Utf8 Class Initialized
INFO - 2023-05-28 15:57:47 --> URI Class Initialized
INFO - 2023-05-28 15:57:47 --> Router Class Initialized
INFO - 2023-05-28 15:57:48 --> Output Class Initialized
INFO - 2023-05-28 15:57:48 --> Security Class Initialized
INFO - 2023-05-28 15:57:48 --> Input Class Initialized
INFO - 2023-05-28 15:57:48 --> Language Class Initialized
INFO - 2023-05-28 15:57:48 --> Loader Class Initialized
INFO - 2023-05-28 15:57:48 --> Helper loaded: url_helper
INFO - 2023-05-28 15:57:48 --> Helper loaded: form_helper
INFO - 2023-05-28 15:57:48 --> Database Driver Class Initialized
INFO - 2023-05-28 15:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:57:48 --> Form Validation Class Initialized
INFO - 2023-05-28 15:57:48 --> Controller Class Initialized
INFO - 2023-05-28 15:57:48 --> Model "m_user" initialized
INFO - 2023-05-28 15:57:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 15:57:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-28 15:57:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-28 15:57:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-28 15:57:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-28 15:57:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-28 15:57:48 --> Final output sent to browser
INFO - 2023-05-28 15:58:35 --> Config Class Initialized
INFO - 2023-05-28 15:58:35 --> Hooks Class Initialized
INFO - 2023-05-28 15:58:35 --> Utf8 Class Initialized
INFO - 2023-05-28 15:58:35 --> URI Class Initialized
INFO - 2023-05-28 15:58:35 --> Router Class Initialized
INFO - 2023-05-28 15:58:35 --> Output Class Initialized
INFO - 2023-05-28 15:58:35 --> Security Class Initialized
INFO - 2023-05-28 15:58:35 --> Input Class Initialized
INFO - 2023-05-28 15:58:35 --> Language Class Initialized
INFO - 2023-05-28 15:58:35 --> Loader Class Initialized
INFO - 2023-05-28 15:58:35 --> Helper loaded: url_helper
INFO - 2023-05-28 15:58:35 --> Helper loaded: form_helper
INFO - 2023-05-28 15:58:35 --> Database Driver Class Initialized
INFO - 2023-05-28 15:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:58:35 --> Form Validation Class Initialized
INFO - 2023-05-28 15:58:35 --> Controller Class Initialized
INFO - 2023-05-28 15:58:35 --> Model "m_user" initialized
INFO - 2023-05-28 15:58:35 --> Config Class Initialized
INFO - 2023-05-28 15:58:35 --> Hooks Class Initialized
INFO - 2023-05-28 15:58:35 --> Utf8 Class Initialized
INFO - 2023-05-28 15:58:35 --> URI Class Initialized
INFO - 2023-05-28 15:58:35 --> Router Class Initialized
INFO - 2023-05-28 15:58:35 --> Output Class Initialized
INFO - 2023-05-28 15:58:35 --> Security Class Initialized
INFO - 2023-05-28 15:58:35 --> Input Class Initialized
INFO - 2023-05-28 15:58:35 --> Language Class Initialized
INFO - 2023-05-28 15:58:35 --> Loader Class Initialized
INFO - 2023-05-28 15:58:35 --> Helper loaded: url_helper
INFO - 2023-05-28 15:58:35 --> Helper loaded: form_helper
INFO - 2023-05-28 15:58:35 --> Database Driver Class Initialized
INFO - 2023-05-28 15:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:58:35 --> Form Validation Class Initialized
INFO - 2023-05-28 15:58:35 --> Controller Class Initialized
INFO - 2023-05-28 15:58:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 15:58:35 --> Final output sent to browser
INFO - 2023-05-28 15:58:48 --> Config Class Initialized
INFO - 2023-05-28 15:58:48 --> Hooks Class Initialized
INFO - 2023-05-28 15:58:48 --> Utf8 Class Initialized
INFO - 2023-05-28 15:58:48 --> URI Class Initialized
INFO - 2023-05-28 15:58:48 --> Router Class Initialized
INFO - 2023-05-28 15:58:48 --> Output Class Initialized
INFO - 2023-05-28 15:58:48 --> Security Class Initialized
INFO - 2023-05-28 15:58:48 --> Input Class Initialized
INFO - 2023-05-28 15:58:48 --> Language Class Initialized
INFO - 2023-05-28 15:58:48 --> Loader Class Initialized
INFO - 2023-05-28 15:58:48 --> Helper loaded: url_helper
INFO - 2023-05-28 15:58:48 --> Helper loaded: form_helper
INFO - 2023-05-28 15:58:48 --> Database Driver Class Initialized
INFO - 2023-05-28 15:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:58:48 --> Form Validation Class Initialized
INFO - 2023-05-28 15:58:48 --> Controller Class Initialized
INFO - 2023-05-28 15:58:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 15:58:48 --> Final output sent to browser
INFO - 2023-05-28 15:58:49 --> Config Class Initialized
INFO - 2023-05-28 15:58:49 --> Hooks Class Initialized
INFO - 2023-05-28 15:58:49 --> Utf8 Class Initialized
INFO - 2023-05-28 15:58:49 --> URI Class Initialized
INFO - 2023-05-28 15:58:49 --> Router Class Initialized
INFO - 2023-05-28 15:58:49 --> Output Class Initialized
INFO - 2023-05-28 15:58:49 --> Security Class Initialized
INFO - 2023-05-28 15:58:49 --> Input Class Initialized
INFO - 2023-05-28 15:58:49 --> Language Class Initialized
INFO - 2023-05-28 15:58:49 --> Loader Class Initialized
INFO - 2023-05-28 15:58:49 --> Helper loaded: url_helper
INFO - 2023-05-28 15:58:49 --> Helper loaded: form_helper
INFO - 2023-05-28 15:58:49 --> Database Driver Class Initialized
INFO - 2023-05-28 15:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 15:58:49 --> Form Validation Class Initialized
INFO - 2023-05-28 15:58:49 --> Controller Class Initialized
INFO - 2023-05-28 15:58:49 --> Model "m_user" initialized
INFO - 2023-05-28 15:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 15:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-28 15:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-28 15:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-28 15:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-28 15:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-28 15:58:49 --> Final output sent to browser
INFO - 2023-05-28 16:00:10 --> Config Class Initialized
INFO - 2023-05-28 16:00:10 --> Hooks Class Initialized
INFO - 2023-05-28 16:00:10 --> Utf8 Class Initialized
INFO - 2023-05-28 16:00:10 --> URI Class Initialized
INFO - 2023-05-28 16:00:10 --> Router Class Initialized
INFO - 2023-05-28 16:00:10 --> Output Class Initialized
INFO - 2023-05-28 16:00:10 --> Security Class Initialized
INFO - 2023-05-28 16:00:10 --> Input Class Initialized
INFO - 2023-05-28 16:00:10 --> Language Class Initialized
INFO - 2023-05-28 16:00:10 --> Loader Class Initialized
INFO - 2023-05-28 16:00:10 --> Helper loaded: url_helper
INFO - 2023-05-28 16:00:10 --> Helper loaded: form_helper
INFO - 2023-05-28 16:00:10 --> Database Driver Class Initialized
INFO - 2023-05-28 16:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 16:00:10 --> Form Validation Class Initialized
INFO - 2023-05-28 16:00:10 --> Controller Class Initialized
INFO - 2023-05-28 16:00:10 --> Model "m_user" initialized
INFO - 2023-05-28 16:00:10 --> Config Class Initialized
INFO - 2023-05-28 16:00:10 --> Hooks Class Initialized
INFO - 2023-05-28 16:00:10 --> Utf8 Class Initialized
INFO - 2023-05-28 16:00:10 --> URI Class Initialized
INFO - 2023-05-28 16:00:10 --> Router Class Initialized
INFO - 2023-05-28 16:00:10 --> Output Class Initialized
INFO - 2023-05-28 16:00:10 --> Security Class Initialized
INFO - 2023-05-28 16:00:10 --> Input Class Initialized
INFO - 2023-05-28 16:00:10 --> Language Class Initialized
INFO - 2023-05-28 16:00:10 --> Loader Class Initialized
INFO - 2023-05-28 16:00:10 --> Helper loaded: url_helper
INFO - 2023-05-28 16:00:10 --> Helper loaded: form_helper
INFO - 2023-05-28 16:00:10 --> Database Driver Class Initialized
INFO - 2023-05-28 16:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 16:00:10 --> Form Validation Class Initialized
INFO - 2023-05-28 16:00:10 --> Controller Class Initialized
INFO - 2023-05-28 16:00:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 16:00:10 --> Final output sent to browser
INFO - 2023-05-28 16:00:13 --> Config Class Initialized
INFO - 2023-05-28 16:00:13 --> Hooks Class Initialized
INFO - 2023-05-28 16:00:13 --> Utf8 Class Initialized
INFO - 2023-05-28 16:00:13 --> URI Class Initialized
INFO - 2023-05-28 16:00:13 --> Router Class Initialized
INFO - 2023-05-28 16:00:13 --> Output Class Initialized
INFO - 2023-05-28 16:00:13 --> Security Class Initialized
INFO - 2023-05-28 16:00:13 --> Input Class Initialized
INFO - 2023-05-28 16:00:13 --> Language Class Initialized
INFO - 2023-05-28 16:00:13 --> Loader Class Initialized
INFO - 2023-05-28 16:00:13 --> Helper loaded: url_helper
INFO - 2023-05-28 16:00:13 --> Helper loaded: form_helper
INFO - 2023-05-28 16:00:13 --> Database Driver Class Initialized
INFO - 2023-05-28 16:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 16:00:13 --> Form Validation Class Initialized
INFO - 2023-05-28 16:00:13 --> Controller Class Initialized
INFO - 2023-05-28 16:00:13 --> Model "m_user" initialized
INFO - 2023-05-28 16:00:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-28 16:00:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-28 16:00:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-28 16:00:13 --> Final output sent to browser
INFO - 2023-05-28 16:00:51 --> Config Class Initialized
INFO - 2023-05-28 16:00:51 --> Hooks Class Initialized
INFO - 2023-05-28 16:00:51 --> Utf8 Class Initialized
INFO - 2023-05-28 16:00:51 --> URI Class Initialized
INFO - 2023-05-28 16:00:51 --> Router Class Initialized
INFO - 2023-05-28 16:00:51 --> Output Class Initialized
INFO - 2023-05-28 16:00:51 --> Security Class Initialized
INFO - 2023-05-28 16:00:51 --> Input Class Initialized
INFO - 2023-05-28 16:00:51 --> Language Class Initialized
INFO - 2023-05-28 16:00:51 --> Loader Class Initialized
INFO - 2023-05-28 16:00:51 --> Helper loaded: url_helper
INFO - 2023-05-28 16:00:51 --> Helper loaded: form_helper
INFO - 2023-05-28 16:00:51 --> Database Driver Class Initialized
INFO - 2023-05-28 16:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 16:00:51 --> Form Validation Class Initialized
INFO - 2023-05-28 16:00:51 --> Controller Class Initialized
INFO - 2023-05-28 16:00:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 16:00:51 --> Final output sent to browser
INFO - 2023-05-28 16:01:30 --> Config Class Initialized
INFO - 2023-05-28 16:01:30 --> Hooks Class Initialized
INFO - 2023-05-28 16:01:30 --> Utf8 Class Initialized
INFO - 2023-05-28 16:01:30 --> URI Class Initialized
INFO - 2023-05-28 16:01:30 --> Router Class Initialized
INFO - 2023-05-28 16:01:30 --> Output Class Initialized
INFO - 2023-05-28 16:01:30 --> Security Class Initialized
INFO - 2023-05-28 16:01:30 --> Input Class Initialized
INFO - 2023-05-28 16:01:30 --> Language Class Initialized
INFO - 2023-05-28 16:01:30 --> Loader Class Initialized
INFO - 2023-05-28 16:01:30 --> Helper loaded: url_helper
INFO - 2023-05-28 16:01:30 --> Helper loaded: form_helper
INFO - 2023-05-28 16:01:30 --> Database Driver Class Initialized
INFO - 2023-05-28 16:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 16:01:30 --> Form Validation Class Initialized
INFO - 2023-05-28 16:01:30 --> Controller Class Initialized
INFO - 2023-05-28 16:01:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 16:01:30 --> Final output sent to browser
INFO - 2023-05-28 17:07:41 --> Config Class Initialized
INFO - 2023-05-28 17:07:41 --> Hooks Class Initialized
INFO - 2023-05-28 17:07:41 --> Utf8 Class Initialized
INFO - 2023-05-28 17:07:41 --> URI Class Initialized
INFO - 2023-05-28 17:07:41 --> Router Class Initialized
INFO - 2023-05-28 17:07:41 --> Output Class Initialized
INFO - 2023-05-28 17:07:41 --> Security Class Initialized
INFO - 2023-05-28 17:07:41 --> Input Class Initialized
INFO - 2023-05-28 17:07:41 --> Language Class Initialized
INFO - 2023-05-28 17:07:41 --> Loader Class Initialized
INFO - 2023-05-28 17:07:41 --> Helper loaded: url_helper
INFO - 2023-05-28 17:07:41 --> Helper loaded: form_helper
INFO - 2023-05-28 17:07:41 --> Database Driver Class Initialized
INFO - 2023-05-28 17:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 17:07:41 --> Form Validation Class Initialized
INFO - 2023-05-28 17:07:41 --> Controller Class Initialized
INFO - 2023-05-28 17:07:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 17:07:41 --> Final output sent to browser
INFO - 2023-05-28 17:07:44 --> Config Class Initialized
INFO - 2023-05-28 17:07:44 --> Hooks Class Initialized
INFO - 2023-05-28 17:07:44 --> Utf8 Class Initialized
INFO - 2023-05-28 17:07:44 --> URI Class Initialized
INFO - 2023-05-28 17:07:44 --> Router Class Initialized
INFO - 2023-05-28 17:07:44 --> Output Class Initialized
INFO - 2023-05-28 17:07:44 --> Security Class Initialized
INFO - 2023-05-28 17:07:44 --> Input Class Initialized
INFO - 2023-05-28 17:07:44 --> Language Class Initialized
INFO - 2023-05-28 17:07:44 --> Loader Class Initialized
INFO - 2023-05-28 17:07:44 --> Helper loaded: url_helper
INFO - 2023-05-28 17:07:44 --> Helper loaded: form_helper
INFO - 2023-05-28 17:07:44 --> Database Driver Class Initialized
INFO - 2023-05-28 17:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 17:07:44 --> Form Validation Class Initialized
INFO - 2023-05-28 17:07:44 --> Controller Class Initialized
INFO - 2023-05-28 17:07:44 --> Model "m_user" initialized
INFO - 2023-05-28 17:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-28 17:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-28 17:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-28 17:07:44 --> Final output sent to browser
INFO - 2023-05-28 17:08:42 --> Config Class Initialized
INFO - 2023-05-28 17:08:42 --> Hooks Class Initialized
INFO - 2023-05-28 17:08:42 --> Utf8 Class Initialized
INFO - 2023-05-28 17:08:42 --> URI Class Initialized
INFO - 2023-05-28 17:08:42 --> Router Class Initialized
INFO - 2023-05-28 17:08:42 --> Output Class Initialized
INFO - 2023-05-28 17:08:42 --> Security Class Initialized
INFO - 2023-05-28 17:08:42 --> Input Class Initialized
INFO - 2023-05-28 17:08:42 --> Language Class Initialized
INFO - 2023-05-28 17:08:42 --> Loader Class Initialized
INFO - 2023-05-28 17:08:42 --> Helper loaded: url_helper
INFO - 2023-05-28 17:08:42 --> Helper loaded: form_helper
INFO - 2023-05-28 17:08:42 --> Database Driver Class Initialized
INFO - 2023-05-28 17:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 17:08:42 --> Form Validation Class Initialized
INFO - 2023-05-28 17:08:42 --> Controller Class Initialized
INFO - 2023-05-28 17:08:42 --> Model "m_user" initialized
INFO - 2023-05-28 17:08:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-28 17:08:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-28 17:08:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-28 17:08:42 --> Final output sent to browser
INFO - 2023-05-28 17:15:06 --> Config Class Initialized
INFO - 2023-05-28 17:15:06 --> Hooks Class Initialized
INFO - 2023-05-28 17:15:06 --> Utf8 Class Initialized
INFO - 2023-05-28 17:15:06 --> URI Class Initialized
INFO - 2023-05-28 17:15:06 --> Router Class Initialized
INFO - 2023-05-28 17:15:06 --> Output Class Initialized
INFO - 2023-05-28 17:15:06 --> Security Class Initialized
INFO - 2023-05-28 17:15:06 --> Input Class Initialized
INFO - 2023-05-28 17:15:06 --> Language Class Initialized
INFO - 2023-05-28 17:15:06 --> Loader Class Initialized
INFO - 2023-05-28 17:15:06 --> Helper loaded: url_helper
INFO - 2023-05-28 17:15:06 --> Helper loaded: form_helper
INFO - 2023-05-28 17:15:06 --> Database Driver Class Initialized
INFO - 2023-05-28 17:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 17:15:06 --> Form Validation Class Initialized
INFO - 2023-05-28 17:15:06 --> Controller Class Initialized
INFO - 2023-05-28 17:15:06 --> Model "m_user" initialized
INFO - 2023-05-28 17:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-28 17:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-28 17:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-28 17:15:06 --> Final output sent to browser
INFO - 2023-05-28 18:36:01 --> Config Class Initialized
INFO - 2023-05-28 18:36:01 --> Hooks Class Initialized
INFO - 2023-05-28 18:36:01 --> Utf8 Class Initialized
INFO - 2023-05-28 18:36:01 --> URI Class Initialized
INFO - 2023-05-28 18:36:01 --> Router Class Initialized
INFO - 2023-05-28 18:36:01 --> Output Class Initialized
INFO - 2023-05-28 18:36:01 --> Security Class Initialized
INFO - 2023-05-28 18:36:01 --> Input Class Initialized
INFO - 2023-05-28 18:36:01 --> Language Class Initialized
INFO - 2023-05-28 18:36:01 --> Loader Class Initialized
INFO - 2023-05-28 18:36:01 --> Helper loaded: url_helper
INFO - 2023-05-28 18:36:01 --> Helper loaded: form_helper
INFO - 2023-05-28 18:36:01 --> Database Driver Class Initialized
INFO - 2023-05-28 18:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:36:01 --> Form Validation Class Initialized
INFO - 2023-05-28 18:36:01 --> Controller Class Initialized
INFO - 2023-05-28 18:36:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-28 18:36:01 --> Final output sent to browser
INFO - 2023-05-28 18:36:03 --> Config Class Initialized
INFO - 2023-05-28 18:36:03 --> Hooks Class Initialized
INFO - 2023-05-28 18:36:03 --> Utf8 Class Initialized
INFO - 2023-05-28 18:36:03 --> URI Class Initialized
INFO - 2023-05-28 18:36:03 --> Router Class Initialized
INFO - 2023-05-28 18:36:03 --> Output Class Initialized
INFO - 2023-05-28 18:36:03 --> Security Class Initialized
INFO - 2023-05-28 18:36:03 --> Input Class Initialized
INFO - 2023-05-28 18:36:03 --> Language Class Initialized
INFO - 2023-05-28 18:36:03 --> Loader Class Initialized
INFO - 2023-05-28 18:36:03 --> Helper loaded: url_helper
INFO - 2023-05-28 18:36:03 --> Helper loaded: form_helper
INFO - 2023-05-28 18:36:03 --> Database Driver Class Initialized
INFO - 2023-05-28 18:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:36:03 --> Form Validation Class Initialized
INFO - 2023-05-28 18:36:03 --> Controller Class Initialized
INFO - 2023-05-28 18:36:03 --> Model "m_user" initialized
INFO - 2023-05-28 18:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 18:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-28 18:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-28 18:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-28 18:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-28 18:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-28 18:36:03 --> Final output sent to browser
INFO - 2023-05-28 18:36:15 --> Config Class Initialized
INFO - 2023-05-28 18:36:15 --> Hooks Class Initialized
INFO - 2023-05-28 18:36:15 --> Utf8 Class Initialized
INFO - 2023-05-28 18:36:15 --> URI Class Initialized
INFO - 2023-05-28 18:36:15 --> Router Class Initialized
INFO - 2023-05-28 18:36:15 --> Output Class Initialized
INFO - 2023-05-28 18:36:15 --> Security Class Initialized
INFO - 2023-05-28 18:36:15 --> Input Class Initialized
INFO - 2023-05-28 18:36:15 --> Language Class Initialized
ERROR - 2023-05-28 18:36:15 --> 404 Page Not Found: Diagnosa/cek
INFO - 2023-05-28 18:36:22 --> Config Class Initialized
INFO - 2023-05-28 18:36:22 --> Hooks Class Initialized
INFO - 2023-05-28 18:36:22 --> Utf8 Class Initialized
INFO - 2023-05-28 18:36:22 --> URI Class Initialized
INFO - 2023-05-28 18:36:22 --> Router Class Initialized
INFO - 2023-05-28 18:36:22 --> Output Class Initialized
INFO - 2023-05-28 18:36:22 --> Security Class Initialized
INFO - 2023-05-28 18:36:22 --> Input Class Initialized
INFO - 2023-05-28 18:36:22 --> Language Class Initialized
INFO - 2023-05-28 18:36:22 --> Loader Class Initialized
INFO - 2023-05-28 18:36:22 --> Helper loaded: url_helper
INFO - 2023-05-28 18:36:22 --> Helper loaded: form_helper
INFO - 2023-05-28 18:36:22 --> Database Driver Class Initialized
INFO - 2023-05-28 18:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:36:22 --> Form Validation Class Initialized
INFO - 2023-05-28 18:36:22 --> Controller Class Initialized
INFO - 2023-05-28 18:36:22 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:36:22 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:36:22 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:36:22 --> Model "M_solusi" initialized
INFO - 2023-05-28 18:36:22 --> Final output sent to browser
INFO - 2023-05-28 18:36:55 --> Config Class Initialized
INFO - 2023-05-28 18:36:55 --> Hooks Class Initialized
INFO - 2023-05-28 18:36:55 --> Utf8 Class Initialized
INFO - 2023-05-28 18:36:55 --> URI Class Initialized
INFO - 2023-05-28 18:36:55 --> Router Class Initialized
INFO - 2023-05-28 18:36:55 --> Output Class Initialized
INFO - 2023-05-28 18:36:55 --> Security Class Initialized
INFO - 2023-05-28 18:36:55 --> Input Class Initialized
INFO - 2023-05-28 18:36:55 --> Language Class Initialized
INFO - 2023-05-28 18:36:55 --> Loader Class Initialized
INFO - 2023-05-28 18:36:55 --> Helper loaded: url_helper
INFO - 2023-05-28 18:36:55 --> Helper loaded: form_helper
INFO - 2023-05-28 18:36:55 --> Database Driver Class Initialized
INFO - 2023-05-28 18:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:36:55 --> Form Validation Class Initialized
INFO - 2023-05-28 18:36:55 --> Controller Class Initialized
INFO - 2023-05-28 18:36:55 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:36:55 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:36:55 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:36:55 --> Model "M_solusi" initialized
INFO - 2023-05-28 18:36:55 --> Final output sent to browser
INFO - 2023-05-28 18:43:46 --> Config Class Initialized
INFO - 2023-05-28 18:43:46 --> Hooks Class Initialized
INFO - 2023-05-28 18:43:46 --> Utf8 Class Initialized
INFO - 2023-05-28 18:43:46 --> URI Class Initialized
INFO - 2023-05-28 18:43:46 --> Router Class Initialized
INFO - 2023-05-28 18:43:46 --> Output Class Initialized
INFO - 2023-05-28 18:43:46 --> Security Class Initialized
INFO - 2023-05-28 18:43:46 --> Input Class Initialized
INFO - 2023-05-28 18:43:46 --> Language Class Initialized
INFO - 2023-05-28 18:43:46 --> Loader Class Initialized
INFO - 2023-05-28 18:43:46 --> Helper loaded: url_helper
INFO - 2023-05-28 18:43:46 --> Helper loaded: form_helper
INFO - 2023-05-28 18:43:46 --> Database Driver Class Initialized
INFO - 2023-05-28 18:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:43:46 --> Form Validation Class Initialized
INFO - 2023-05-28 18:43:46 --> Controller Class Initialized
INFO - 2023-05-28 18:43:46 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:43:46 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:43:46 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:43:46 --> Model "M_solusi" initialized
INFO - 2023-05-28 18:43:46 --> Final output sent to browser
INFO - 2023-05-28 18:50:52 --> Config Class Initialized
INFO - 2023-05-28 18:50:52 --> Hooks Class Initialized
INFO - 2023-05-28 18:50:52 --> Utf8 Class Initialized
INFO - 2023-05-28 18:50:52 --> URI Class Initialized
INFO - 2023-05-28 18:50:52 --> Router Class Initialized
INFO - 2023-05-28 18:50:52 --> Output Class Initialized
INFO - 2023-05-28 18:50:52 --> Security Class Initialized
INFO - 2023-05-28 18:50:52 --> Input Class Initialized
INFO - 2023-05-28 18:50:52 --> Language Class Initialized
INFO - 2023-05-28 18:50:52 --> Loader Class Initialized
INFO - 2023-05-28 18:50:52 --> Helper loaded: url_helper
INFO - 2023-05-28 18:50:52 --> Helper loaded: form_helper
INFO - 2023-05-28 18:50:52 --> Database Driver Class Initialized
INFO - 2023-05-28 18:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:50:52 --> Form Validation Class Initialized
INFO - 2023-05-28 18:50:52 --> Controller Class Initialized
INFO - 2023-05-28 18:50:52 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:50:52 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:50:52 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:50:52 --> Model "M_solusi" initialized
ERROR - 2023-05-28 18:50:52 --> Severity: Error --> Call to undefined method M_solusi::getA1() C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 815
INFO - 2023-05-28 18:51:20 --> Config Class Initialized
INFO - 2023-05-28 18:51:20 --> Hooks Class Initialized
INFO - 2023-05-28 18:51:20 --> Utf8 Class Initialized
INFO - 2023-05-28 18:51:20 --> URI Class Initialized
INFO - 2023-05-28 18:51:20 --> Router Class Initialized
INFO - 2023-05-28 18:51:20 --> Output Class Initialized
INFO - 2023-05-28 18:51:20 --> Security Class Initialized
INFO - 2023-05-28 18:51:20 --> Input Class Initialized
INFO - 2023-05-28 18:51:20 --> Language Class Initialized
INFO - 2023-05-28 18:51:20 --> Loader Class Initialized
INFO - 2023-05-28 18:51:20 --> Helper loaded: url_helper
INFO - 2023-05-28 18:51:20 --> Helper loaded: form_helper
INFO - 2023-05-28 18:51:20 --> Database Driver Class Initialized
INFO - 2023-05-28 18:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:51:20 --> Form Validation Class Initialized
INFO - 2023-05-28 18:51:20 --> Controller Class Initialized
INFO - 2023-05-28 18:51:20 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:51:20 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:51:20 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:51:20 --> Model "M_solusi" initialized
ERROR - 2023-05-28 18:51:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:51:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:51:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:51:20 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:51:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:51:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:51:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:51:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:51:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
INFO - 2023-05-28 18:51:20 --> Final output sent to browser
INFO - 2023-05-28 18:52:29 --> Config Class Initialized
INFO - 2023-05-28 18:52:29 --> Hooks Class Initialized
INFO - 2023-05-28 18:52:29 --> Utf8 Class Initialized
INFO - 2023-05-28 18:52:29 --> URI Class Initialized
INFO - 2023-05-28 18:52:29 --> Router Class Initialized
INFO - 2023-05-28 18:52:29 --> Output Class Initialized
INFO - 2023-05-28 18:52:29 --> Security Class Initialized
INFO - 2023-05-28 18:52:29 --> Input Class Initialized
INFO - 2023-05-28 18:52:29 --> Language Class Initialized
ERROR - 2023-05-28 18:52:29 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
INFO - 2023-05-28 18:52:58 --> Config Class Initialized
INFO - 2023-05-28 18:52:58 --> Hooks Class Initialized
INFO - 2023-05-28 18:52:58 --> Utf8 Class Initialized
INFO - 2023-05-28 18:52:58 --> URI Class Initialized
INFO - 2023-05-28 18:52:58 --> Router Class Initialized
INFO - 2023-05-28 18:52:58 --> Output Class Initialized
INFO - 2023-05-28 18:52:58 --> Security Class Initialized
INFO - 2023-05-28 18:52:58 --> Input Class Initialized
INFO - 2023-05-28 18:52:58 --> Language Class Initialized
INFO - 2023-05-28 18:52:58 --> Loader Class Initialized
INFO - 2023-05-28 18:52:58 --> Helper loaded: url_helper
INFO - 2023-05-28 18:52:58 --> Helper loaded: form_helper
INFO - 2023-05-28 18:52:58 --> Database Driver Class Initialized
INFO - 2023-05-28 18:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:52:58 --> Form Validation Class Initialized
INFO - 2023-05-28 18:52:58 --> Controller Class Initialized
INFO - 2023-05-28 18:52:58 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:52:58 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:52:58 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:52:58 --> Model "M_solusi" initialized
ERROR - 2023-05-28 18:52:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:52:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:52:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:52:59 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:52:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:52:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:52:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:52:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
ERROR - 2023-05-28 18:52:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
INFO - 2023-05-28 18:52:59 --> Final output sent to browser
INFO - 2023-05-28 18:54:18 --> Config Class Initialized
INFO - 2023-05-28 18:54:18 --> Hooks Class Initialized
INFO - 2023-05-28 18:54:18 --> Utf8 Class Initialized
INFO - 2023-05-28 18:54:18 --> URI Class Initialized
INFO - 2023-05-28 18:54:18 --> Router Class Initialized
INFO - 2023-05-28 18:54:18 --> Output Class Initialized
INFO - 2023-05-28 18:54:18 --> Security Class Initialized
INFO - 2023-05-28 18:54:18 --> Input Class Initialized
INFO - 2023-05-28 18:54:18 --> Language Class Initialized
INFO - 2023-05-28 18:54:18 --> Loader Class Initialized
INFO - 2023-05-28 18:54:18 --> Helper loaded: url_helper
INFO - 2023-05-28 18:54:18 --> Helper loaded: form_helper
INFO - 2023-05-28 18:54:18 --> Database Driver Class Initialized
INFO - 2023-05-28 18:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:54:18 --> Form Validation Class Initialized
INFO - 2023-05-28 18:54:18 --> Controller Class Initialized
INFO - 2023-05-28 18:54:18 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:54:18 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:54:18 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:54:18 --> Model "M_solusi" initialized
ERROR - 2023-05-28 18:54:18 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
INFO - 2023-05-28 18:54:18 --> Final output sent to browser
INFO - 2023-05-28 18:55:14 --> Config Class Initialized
INFO - 2023-05-28 18:55:14 --> Hooks Class Initialized
INFO - 2023-05-28 18:55:14 --> Utf8 Class Initialized
INFO - 2023-05-28 18:55:14 --> URI Class Initialized
INFO - 2023-05-28 18:55:14 --> Router Class Initialized
INFO - 2023-05-28 18:55:14 --> Output Class Initialized
INFO - 2023-05-28 18:55:14 --> Security Class Initialized
INFO - 2023-05-28 18:55:14 --> Input Class Initialized
INFO - 2023-05-28 18:55:14 --> Language Class Initialized
INFO - 2023-05-28 18:55:14 --> Loader Class Initialized
INFO - 2023-05-28 18:55:14 --> Helper loaded: url_helper
INFO - 2023-05-28 18:55:14 --> Helper loaded: form_helper
INFO - 2023-05-28 18:55:14 --> Database Driver Class Initialized
INFO - 2023-05-28 18:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:55:14 --> Form Validation Class Initialized
INFO - 2023-05-28 18:55:14 --> Controller Class Initialized
INFO - 2023-05-28 18:55:14 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:55:14 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:55:14 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:55:14 --> Model "M_solusi" initialized
ERROR - 2023-05-28 18:55:14 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
INFO - 2023-05-28 18:55:14 --> Final output sent to browser
INFO - 2023-05-28 18:55:17 --> Config Class Initialized
INFO - 2023-05-28 18:55:17 --> Hooks Class Initialized
INFO - 2023-05-28 18:55:17 --> Utf8 Class Initialized
INFO - 2023-05-28 18:55:17 --> URI Class Initialized
INFO - 2023-05-28 18:55:17 --> Router Class Initialized
INFO - 2023-05-28 18:55:17 --> Output Class Initialized
INFO - 2023-05-28 18:55:17 --> Security Class Initialized
INFO - 2023-05-28 18:55:17 --> Input Class Initialized
INFO - 2023-05-28 18:55:17 --> Language Class Initialized
INFO - 2023-05-28 18:55:17 --> Loader Class Initialized
INFO - 2023-05-28 18:55:17 --> Helper loaded: url_helper
INFO - 2023-05-28 18:55:17 --> Helper loaded: form_helper
INFO - 2023-05-28 18:55:17 --> Database Driver Class Initialized
INFO - 2023-05-28 18:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:55:17 --> Form Validation Class Initialized
INFO - 2023-05-28 18:55:17 --> Controller Class Initialized
INFO - 2023-05-28 18:55:17 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:55:17 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:55:17 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:55:17 --> Model "M_solusi" initialized
ERROR - 2023-05-28 18:55:17 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 822
INFO - 2023-05-28 18:55:17 --> Final output sent to browser
INFO - 2023-05-28 18:55:29 --> Config Class Initialized
INFO - 2023-05-28 18:55:29 --> Hooks Class Initialized
INFO - 2023-05-28 18:55:29 --> Utf8 Class Initialized
INFO - 2023-05-28 18:55:29 --> URI Class Initialized
INFO - 2023-05-28 18:55:29 --> Router Class Initialized
INFO - 2023-05-28 18:55:29 --> Output Class Initialized
INFO - 2023-05-28 18:55:29 --> Security Class Initialized
INFO - 2023-05-28 18:55:29 --> Input Class Initialized
INFO - 2023-05-28 18:55:29 --> Language Class Initialized
INFO - 2023-05-28 18:55:29 --> Loader Class Initialized
INFO - 2023-05-28 18:55:29 --> Helper loaded: url_helper
INFO - 2023-05-28 18:55:29 --> Helper loaded: form_helper
INFO - 2023-05-28 18:55:29 --> Database Driver Class Initialized
INFO - 2023-05-28 18:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:55:30 --> Form Validation Class Initialized
INFO - 2023-05-28 18:55:30 --> Controller Class Initialized
INFO - 2023-05-28 18:55:30 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:55:30 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:55:30 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:55:30 --> Model "M_solusi" initialized
INFO - 2023-05-28 18:55:30 --> Final output sent to browser
INFO - 2023-05-28 18:56:28 --> Config Class Initialized
INFO - 2023-05-28 18:56:28 --> Hooks Class Initialized
INFO - 2023-05-28 18:56:28 --> Utf8 Class Initialized
INFO - 2023-05-28 18:56:28 --> URI Class Initialized
INFO - 2023-05-28 18:56:28 --> Router Class Initialized
INFO - 2023-05-28 18:56:28 --> Output Class Initialized
INFO - 2023-05-28 18:56:28 --> Security Class Initialized
INFO - 2023-05-28 18:56:28 --> Input Class Initialized
INFO - 2023-05-28 18:56:28 --> Language Class Initialized
INFO - 2023-05-28 18:56:28 --> Loader Class Initialized
INFO - 2023-05-28 18:56:28 --> Helper loaded: url_helper
INFO - 2023-05-28 18:56:28 --> Helper loaded: form_helper
INFO - 2023-05-28 18:56:28 --> Database Driver Class Initialized
INFO - 2023-05-28 18:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:56:28 --> Form Validation Class Initialized
INFO - 2023-05-28 18:56:28 --> Controller Class Initialized
INFO - 2023-05-28 18:56:28 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:56:28 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:56:28 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:56:28 --> Model "M_solusi" initialized
INFO - 2023-05-28 18:56:28 --> Final output sent to browser
INFO - 2023-05-28 18:56:49 --> Config Class Initialized
INFO - 2023-05-28 18:56:49 --> Hooks Class Initialized
INFO - 2023-05-28 18:56:49 --> Utf8 Class Initialized
INFO - 2023-05-28 18:56:49 --> URI Class Initialized
INFO - 2023-05-28 18:56:49 --> Router Class Initialized
INFO - 2023-05-28 18:56:49 --> Output Class Initialized
INFO - 2023-05-28 18:56:49 --> Security Class Initialized
INFO - 2023-05-28 18:56:49 --> Input Class Initialized
INFO - 2023-05-28 18:56:49 --> Language Class Initialized
INFO - 2023-05-28 18:56:49 --> Loader Class Initialized
INFO - 2023-05-28 18:56:49 --> Helper loaded: url_helper
INFO - 2023-05-28 18:56:49 --> Helper loaded: form_helper
INFO - 2023-05-28 18:56:49 --> Database Driver Class Initialized
INFO - 2023-05-28 18:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:56:49 --> Form Validation Class Initialized
INFO - 2023-05-28 18:56:49 --> Controller Class Initialized
INFO - 2023-05-28 18:56:49 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:56:49 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:56:49 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:56:49 --> Model "M_solusi" initialized
INFO - 2023-05-28 18:56:49 --> Final output sent to browser
INFO - 2023-05-28 18:57:17 --> Config Class Initialized
INFO - 2023-05-28 18:57:17 --> Hooks Class Initialized
INFO - 2023-05-28 18:57:17 --> Utf8 Class Initialized
INFO - 2023-05-28 18:57:17 --> URI Class Initialized
INFO - 2023-05-28 18:57:17 --> Router Class Initialized
INFO - 2023-05-28 18:57:17 --> Output Class Initialized
INFO - 2023-05-28 18:57:17 --> Security Class Initialized
INFO - 2023-05-28 18:57:17 --> Input Class Initialized
INFO - 2023-05-28 18:57:17 --> Language Class Initialized
INFO - 2023-05-28 18:57:17 --> Loader Class Initialized
INFO - 2023-05-28 18:57:17 --> Helper loaded: url_helper
INFO - 2023-05-28 18:57:17 --> Helper loaded: form_helper
INFO - 2023-05-28 18:57:17 --> Database Driver Class Initialized
INFO - 2023-05-28 18:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 18:57:17 --> Form Validation Class Initialized
INFO - 2023-05-28 18:57:17 --> Controller Class Initialized
INFO - 2023-05-28 18:57:17 --> Model "m_datatrain" initialized
INFO - 2023-05-28 18:57:17 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 18:57:17 --> Model "m_datatest" initialized
INFO - 2023-05-28 18:57:17 --> Model "M_solusi" initialized
INFO - 2023-05-28 18:57:17 --> Final output sent to browser
INFO - 2023-05-28 19:02:13 --> Config Class Initialized
INFO - 2023-05-28 19:02:13 --> Hooks Class Initialized
INFO - 2023-05-28 19:02:13 --> Utf8 Class Initialized
INFO - 2023-05-28 19:02:13 --> URI Class Initialized
INFO - 2023-05-28 19:02:13 --> Router Class Initialized
INFO - 2023-05-28 19:02:13 --> Output Class Initialized
INFO - 2023-05-28 19:02:13 --> Security Class Initialized
INFO - 2023-05-28 19:02:13 --> Input Class Initialized
INFO - 2023-05-28 19:02:13 --> Language Class Initialized
INFO - 2023-05-28 19:02:13 --> Loader Class Initialized
INFO - 2023-05-28 19:02:13 --> Helper loaded: url_helper
INFO - 2023-05-28 19:02:13 --> Helper loaded: form_helper
INFO - 2023-05-28 19:02:13 --> Database Driver Class Initialized
INFO - 2023-05-28 19:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 19:02:13 --> Form Validation Class Initialized
INFO - 2023-05-28 19:02:13 --> Controller Class Initialized
INFO - 2023-05-28 19:02:13 --> Model "m_datatrain" initialized
INFO - 2023-05-28 19:02:13 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 19:02:13 --> Model "m_datatest" initialized
INFO - 2023-05-28 19:02:13 --> Model "M_solusi" initialized
INFO - 2023-05-28 19:02:13 --> Final output sent to browser
INFO - 2023-05-28 19:58:55 --> Config Class Initialized
INFO - 2023-05-28 19:58:55 --> Hooks Class Initialized
INFO - 2023-05-28 19:58:55 --> Utf8 Class Initialized
INFO - 2023-05-28 19:58:55 --> URI Class Initialized
INFO - 2023-05-28 19:58:55 --> Router Class Initialized
INFO - 2023-05-28 19:58:55 --> Output Class Initialized
INFO - 2023-05-28 19:58:55 --> Security Class Initialized
INFO - 2023-05-28 19:58:55 --> Input Class Initialized
INFO - 2023-05-28 19:58:55 --> Language Class Initialized
INFO - 2023-05-28 19:58:56 --> Loader Class Initialized
INFO - 2023-05-28 19:58:56 --> Helper loaded: url_helper
INFO - 2023-05-28 19:58:56 --> Helper loaded: form_helper
INFO - 2023-05-28 19:58:56 --> Database Driver Class Initialized
INFO - 2023-05-28 19:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 19:58:56 --> Form Validation Class Initialized
INFO - 2023-05-28 19:58:56 --> Controller Class Initialized
INFO - 2023-05-28 19:58:56 --> Model "m_datatrain" initialized
INFO - 2023-05-28 19:58:56 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 19:58:56 --> Model "m_datatest" initialized
INFO - 2023-05-28 19:58:56 --> Model "M_solusi" initialized
INFO - 2023-05-28 19:58:56 --> Final output sent to browser
INFO - 2023-05-28 20:01:46 --> Config Class Initialized
INFO - 2023-05-28 20:01:46 --> Hooks Class Initialized
INFO - 2023-05-28 20:01:46 --> Utf8 Class Initialized
INFO - 2023-05-28 20:01:46 --> URI Class Initialized
INFO - 2023-05-28 20:01:46 --> Router Class Initialized
INFO - 2023-05-28 20:01:46 --> Output Class Initialized
INFO - 2023-05-28 20:01:46 --> Security Class Initialized
INFO - 2023-05-28 20:01:46 --> Input Class Initialized
INFO - 2023-05-28 20:01:46 --> Language Class Initialized
INFO - 2023-05-28 20:01:46 --> Loader Class Initialized
INFO - 2023-05-28 20:01:46 --> Helper loaded: url_helper
INFO - 2023-05-28 20:01:46 --> Helper loaded: form_helper
INFO - 2023-05-28 20:01:46 --> Database Driver Class Initialized
INFO - 2023-05-28 20:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 20:01:46 --> Form Validation Class Initialized
INFO - 2023-05-28 20:01:46 --> Controller Class Initialized
INFO - 2023-05-28 20:01:46 --> Model "m_datatrain" initialized
INFO - 2023-05-28 20:01:46 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 20:01:46 --> Model "m_datatest" initialized
INFO - 2023-05-28 20:01:46 --> Model "M_solusi" initialized
INFO - 2023-05-28 20:01:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 20:01:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-28 20:01:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-28 20:01:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-28 20:01:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-28 20:01:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-28 20:01:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-28 20:01:46 --> Final output sent to browser
INFO - 2023-05-28 20:04:22 --> Config Class Initialized
INFO - 2023-05-28 20:04:22 --> Hooks Class Initialized
INFO - 2023-05-28 20:04:22 --> Utf8 Class Initialized
INFO - 2023-05-28 20:04:22 --> URI Class Initialized
INFO - 2023-05-28 20:04:22 --> Router Class Initialized
INFO - 2023-05-28 20:04:22 --> Output Class Initialized
INFO - 2023-05-28 20:04:22 --> Security Class Initialized
INFO - 2023-05-28 20:04:22 --> Input Class Initialized
INFO - 2023-05-28 20:04:22 --> Language Class Initialized
INFO - 2023-05-28 20:04:22 --> Loader Class Initialized
INFO - 2023-05-28 20:04:22 --> Helper loaded: url_helper
INFO - 2023-05-28 20:04:22 --> Helper loaded: form_helper
INFO - 2023-05-28 20:04:22 --> Database Driver Class Initialized
INFO - 2023-05-28 20:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 20:04:22 --> Form Validation Class Initialized
INFO - 2023-05-28 20:04:22 --> Controller Class Initialized
INFO - 2023-05-28 20:04:22 --> Model "m_datatrain" initialized
INFO - 2023-05-28 20:04:22 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 20:04:22 --> Model "m_datatest" initialized
INFO - 2023-05-28 20:04:22 --> Model "M_solusi" initialized
INFO - 2023-05-28 20:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 20:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-28 20:04:22 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 66
INFO - 2023-05-28 20:04:40 --> Config Class Initialized
INFO - 2023-05-28 20:04:40 --> Hooks Class Initialized
INFO - 2023-05-28 20:04:40 --> Utf8 Class Initialized
INFO - 2023-05-28 20:04:40 --> URI Class Initialized
INFO - 2023-05-28 20:04:40 --> Router Class Initialized
INFO - 2023-05-28 20:04:40 --> Output Class Initialized
INFO - 2023-05-28 20:04:40 --> Security Class Initialized
INFO - 2023-05-28 20:04:40 --> Input Class Initialized
INFO - 2023-05-28 20:04:40 --> Language Class Initialized
INFO - 2023-05-28 20:04:40 --> Loader Class Initialized
INFO - 2023-05-28 20:04:40 --> Helper loaded: url_helper
INFO - 2023-05-28 20:04:40 --> Helper loaded: form_helper
INFO - 2023-05-28 20:04:40 --> Database Driver Class Initialized
INFO - 2023-05-28 20:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 20:04:40 --> Form Validation Class Initialized
INFO - 2023-05-28 20:04:40 --> Controller Class Initialized
INFO - 2023-05-28 20:04:40 --> Model "m_datatrain" initialized
INFO - 2023-05-28 20:04:40 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 20:04:40 --> Model "m_datatest" initialized
INFO - 2023-05-28 20:04:40 --> Model "M_solusi" initialized
INFO - 2023-05-28 20:04:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 20:04:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 40
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 43
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 46
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 49
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 52
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 55
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 58
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 61
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 64
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 43
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 46
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 49
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 52
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 55
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 58
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 61
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 43
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 46
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 49
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 52
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 55
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 58
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 61
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 43
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 46
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 49
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 52
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 55
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 58
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 61
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 43
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 46
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 49
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 52
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 55
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 58
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 61
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 43
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 46
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 49
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 52
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 55
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 58
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 61
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 43
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 46
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 49
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 52
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 55
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 58
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 61
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 43
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 46
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 49
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 52
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 55
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 58
ERROR - 2023-05-28 20:04:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 61
INFO - 2023-05-28 20:04:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-28 20:04:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-28 20:04:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-28 20:04:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-28 20:04:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-28 20:04:40 --> Final output sent to browser
INFO - 2023-05-28 20:05:12 --> Config Class Initialized
INFO - 2023-05-28 20:05:12 --> Hooks Class Initialized
INFO - 2023-05-28 20:05:12 --> Utf8 Class Initialized
INFO - 2023-05-28 20:05:12 --> URI Class Initialized
INFO - 2023-05-28 20:05:12 --> Router Class Initialized
INFO - 2023-05-28 20:05:12 --> Output Class Initialized
INFO - 2023-05-28 20:05:12 --> Security Class Initialized
INFO - 2023-05-28 20:05:12 --> Input Class Initialized
INFO - 2023-05-28 20:05:12 --> Language Class Initialized
INFO - 2023-05-28 20:05:12 --> Loader Class Initialized
INFO - 2023-05-28 20:05:12 --> Helper loaded: url_helper
INFO - 2023-05-28 20:05:12 --> Helper loaded: form_helper
INFO - 2023-05-28 20:05:12 --> Database Driver Class Initialized
INFO - 2023-05-28 20:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 20:05:12 --> Form Validation Class Initialized
INFO - 2023-05-28 20:05:12 --> Controller Class Initialized
INFO - 2023-05-28 20:05:12 --> Model "m_datatrain" initialized
INFO - 2023-05-28 20:05:12 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 20:05:12 --> Model "m_datatest" initialized
INFO - 2023-05-28 20:05:12 --> Model "M_solusi" initialized
INFO - 2023-05-28 20:05:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-28 20:05:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 44
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 47
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 50
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 53
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 59
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 62
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 44
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 47
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 50
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 53
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 59
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 62
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 44
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 47
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 50
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 53
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 59
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 62
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 44
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 47
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 50
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 53
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 59
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 62
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 44
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 47
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 50
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 53
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 59
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 62
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 44
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 47
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 50
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 53
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 59
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 62
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 44
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 47
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 50
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 53
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 59
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 62
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 44
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 47
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 50
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 53
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 59
ERROR - 2023-05-28 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 62
INFO - 2023-05-28 20:05:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-28 20:05:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-28 20:05:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-28 20:05:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-28 20:05:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-28 20:05:12 --> Final output sent to browser
INFO - 2023-05-28 20:07:18 --> Config Class Initialized
INFO - 2023-05-28 20:07:18 --> Hooks Class Initialized
INFO - 2023-05-28 20:07:18 --> Utf8 Class Initialized
INFO - 2023-05-28 20:07:19 --> URI Class Initialized
INFO - 2023-05-28 20:07:19 --> Router Class Initialized
INFO - 2023-05-28 20:07:19 --> Output Class Initialized
INFO - 2023-05-28 20:07:19 --> Security Class Initialized
INFO - 2023-05-28 20:07:19 --> Input Class Initialized
INFO - 2023-05-28 20:07:19 --> Language Class Initialized
INFO - 2023-05-28 20:07:19 --> Loader Class Initialized
INFO - 2023-05-28 20:07:19 --> Helper loaded: url_helper
INFO - 2023-05-28 20:07:19 --> Helper loaded: form_helper
INFO - 2023-05-28 20:07:19 --> Database Driver Class Initialized
INFO - 2023-05-28 20:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 20:07:19 --> Form Validation Class Initialized
INFO - 2023-05-28 20:07:19 --> Controller Class Initialized
INFO - 2023-05-28 20:07:19 --> Model "m_datatrain" initialized
INFO - 2023-05-28 20:07:19 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 20:07:19 --> Model "m_datatest" initialized
INFO - 2023-05-28 20:07:19 --> Model "M_solusi" initialized
INFO - 2023-05-28 20:07:19 --> Final output sent to browser
INFO - 2023-05-28 20:07:55 --> Config Class Initialized
INFO - 2023-05-28 20:07:55 --> Hooks Class Initialized
INFO - 2023-05-28 20:07:55 --> Utf8 Class Initialized
INFO - 2023-05-28 20:07:55 --> URI Class Initialized
INFO - 2023-05-28 20:07:55 --> Router Class Initialized
INFO - 2023-05-28 20:07:55 --> Output Class Initialized
INFO - 2023-05-28 20:07:55 --> Security Class Initialized
INFO - 2023-05-28 20:07:55 --> Input Class Initialized
INFO - 2023-05-28 20:07:55 --> Language Class Initialized
INFO - 2023-05-28 20:07:55 --> Loader Class Initialized
INFO - 2023-05-28 20:07:55 --> Helper loaded: url_helper
INFO - 2023-05-28 20:07:55 --> Helper loaded: form_helper
INFO - 2023-05-28 20:07:55 --> Database Driver Class Initialized
INFO - 2023-05-28 20:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 20:07:55 --> Form Validation Class Initialized
INFO - 2023-05-28 20:07:55 --> Controller Class Initialized
INFO - 2023-05-28 20:07:55 --> Model "m_datatrain" initialized
INFO - 2023-05-28 20:07:55 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 20:07:55 --> Model "m_datatest" initialized
INFO - 2023-05-28 20:07:55 --> Model "M_solusi" initialized
INFO - 2023-05-28 20:07:55 --> Final output sent to browser
INFO - 2023-05-28 20:08:46 --> Config Class Initialized
INFO - 2023-05-28 20:08:46 --> Hooks Class Initialized
INFO - 2023-05-28 20:08:46 --> Utf8 Class Initialized
INFO - 2023-05-28 20:08:46 --> URI Class Initialized
INFO - 2023-05-28 20:08:46 --> Router Class Initialized
INFO - 2023-05-28 20:08:46 --> Output Class Initialized
INFO - 2023-05-28 20:08:46 --> Security Class Initialized
INFO - 2023-05-28 20:08:46 --> Input Class Initialized
INFO - 2023-05-28 20:08:46 --> Language Class Initialized
INFO - 2023-05-28 20:08:46 --> Loader Class Initialized
INFO - 2023-05-28 20:08:46 --> Helper loaded: url_helper
INFO - 2023-05-28 20:08:46 --> Helper loaded: form_helper
INFO - 2023-05-28 20:08:46 --> Database Driver Class Initialized
INFO - 2023-05-28 20:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 20:08:46 --> Form Validation Class Initialized
INFO - 2023-05-28 20:08:46 --> Controller Class Initialized
INFO - 2023-05-28 20:08:46 --> Model "m_datatrain" initialized
INFO - 2023-05-28 20:08:46 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 20:08:46 --> Model "m_datatest" initialized
INFO - 2023-05-28 20:08:46 --> Model "M_solusi" initialized
INFO - 2023-05-28 20:08:46 --> Final output sent to browser
INFO - 2023-05-28 20:08:51 --> Config Class Initialized
INFO - 2023-05-28 20:08:51 --> Hooks Class Initialized
INFO - 2023-05-28 20:08:51 --> Utf8 Class Initialized
INFO - 2023-05-28 20:08:51 --> URI Class Initialized
INFO - 2023-05-28 20:08:51 --> Router Class Initialized
INFO - 2023-05-28 20:08:51 --> Output Class Initialized
INFO - 2023-05-28 20:08:51 --> Security Class Initialized
INFO - 2023-05-28 20:08:51 --> Input Class Initialized
INFO - 2023-05-28 20:08:51 --> Language Class Initialized
INFO - 2023-05-28 20:08:51 --> Loader Class Initialized
INFO - 2023-05-28 20:08:51 --> Helper loaded: url_helper
INFO - 2023-05-28 20:08:51 --> Helper loaded: form_helper
INFO - 2023-05-28 20:08:51 --> Database Driver Class Initialized
INFO - 2023-05-28 20:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-28 20:08:51 --> Form Validation Class Initialized
INFO - 2023-05-28 20:08:51 --> Controller Class Initialized
INFO - 2023-05-28 20:08:51 --> Model "m_datatrain" initialized
INFO - 2023-05-28 20:08:51 --> Model "m_penghitungan" initialized
INFO - 2023-05-28 20:08:51 --> Model "m_datatest" initialized
INFO - 2023-05-28 20:08:51 --> Model "M_solusi" initialized
INFO - 2023-05-28 20:08:51 --> Final output sent to browser
