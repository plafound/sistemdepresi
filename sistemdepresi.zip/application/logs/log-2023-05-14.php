<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-14 13:32:32 --> Config Class Initialized
INFO - 2023-05-14 13:32:32 --> Hooks Class Initialized
INFO - 2023-05-14 13:32:32 --> Utf8 Class Initialized
INFO - 2023-05-14 13:32:32 --> URI Class Initialized
INFO - 2023-05-14 13:32:33 --> Router Class Initialized
INFO - 2023-05-14 13:32:33 --> Output Class Initialized
INFO - 2023-05-14 13:32:33 --> Security Class Initialized
INFO - 2023-05-14 13:32:33 --> Input Class Initialized
INFO - 2023-05-14 13:32:33 --> Language Class Initialized
INFO - 2023-05-14 13:32:33 --> Loader Class Initialized
INFO - 2023-05-14 13:32:33 --> Helper loaded: url_helper
INFO - 2023-05-14 13:32:33 --> Helper loaded: form_helper
INFO - 2023-05-14 13:32:33 --> Database Driver Class Initialized
INFO - 2023-05-14 13:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:32:33 --> Form Validation Class Initialized
INFO - 2023-05-14 13:32:33 --> Controller Class Initialized
INFO - 2023-05-14 13:32:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-14 13:32:33 --> Final output sent to browser
INFO - 2023-05-14 13:33:31 --> Config Class Initialized
INFO - 2023-05-14 13:33:31 --> Hooks Class Initialized
INFO - 2023-05-14 13:33:31 --> Utf8 Class Initialized
INFO - 2023-05-14 13:33:31 --> URI Class Initialized
INFO - 2023-05-14 13:33:31 --> Router Class Initialized
INFO - 2023-05-14 13:33:31 --> Output Class Initialized
INFO - 2023-05-14 13:33:31 --> Security Class Initialized
INFO - 2023-05-14 13:33:31 --> Input Class Initialized
INFO - 2023-05-14 13:33:31 --> Language Class Initialized
INFO - 2023-05-14 13:33:31 --> Loader Class Initialized
INFO - 2023-05-14 13:33:31 --> Helper loaded: url_helper
INFO - 2023-05-14 13:33:31 --> Helper loaded: form_helper
INFO - 2023-05-14 13:33:31 --> Database Driver Class Initialized
INFO - 2023-05-14 13:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:33:31 --> Form Validation Class Initialized
INFO - 2023-05-14 13:33:31 --> Controller Class Initialized
INFO - 2023-05-14 13:33:31 --> Model "m_user" initialized
INFO - 2023-05-14 13:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 13:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 13:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-14 13:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 13:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 13:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-14 13:33:31 --> Final output sent to browser
INFO - 2023-05-14 13:34:10 --> Config Class Initialized
INFO - 2023-05-14 13:34:10 --> Hooks Class Initialized
INFO - 2023-05-14 13:34:10 --> Utf8 Class Initialized
INFO - 2023-05-14 13:34:10 --> URI Class Initialized
INFO - 2023-05-14 13:34:10 --> Router Class Initialized
INFO - 2023-05-14 13:34:10 --> Output Class Initialized
INFO - 2023-05-14 13:34:10 --> Security Class Initialized
INFO - 2023-05-14 13:34:10 --> Input Class Initialized
INFO - 2023-05-14 13:34:10 --> Language Class Initialized
INFO - 2023-05-14 13:34:10 --> Loader Class Initialized
INFO - 2023-05-14 13:34:10 --> Helper loaded: url_helper
INFO - 2023-05-14 13:34:10 --> Helper loaded: form_helper
INFO - 2023-05-14 13:34:10 --> Database Driver Class Initialized
INFO - 2023-05-14 13:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:34:10 --> Form Validation Class Initialized
INFO - 2023-05-14 13:34:10 --> Controller Class Initialized
INFO - 2023-05-14 13:34:10 --> Model "m_user" initialized
INFO - 2023-05-14 13:34:10 --> Config Class Initialized
INFO - 2023-05-14 13:34:10 --> Hooks Class Initialized
INFO - 2023-05-14 13:34:10 --> Utf8 Class Initialized
INFO - 2023-05-14 13:34:10 --> URI Class Initialized
INFO - 2023-05-14 13:34:10 --> Router Class Initialized
INFO - 2023-05-14 13:34:10 --> Output Class Initialized
INFO - 2023-05-14 13:34:10 --> Security Class Initialized
INFO - 2023-05-14 13:34:10 --> Input Class Initialized
INFO - 2023-05-14 13:34:10 --> Language Class Initialized
INFO - 2023-05-14 13:34:10 --> Loader Class Initialized
INFO - 2023-05-14 13:34:10 --> Helper loaded: url_helper
INFO - 2023-05-14 13:34:10 --> Helper loaded: form_helper
INFO - 2023-05-14 13:34:10 --> Database Driver Class Initialized
INFO - 2023-05-14 13:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:34:10 --> Form Validation Class Initialized
INFO - 2023-05-14 13:34:10 --> Controller Class Initialized
INFO - 2023-05-14 13:34:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-14 13:34:10 --> Final output sent to browser
INFO - 2023-05-14 13:34:12 --> Config Class Initialized
INFO - 2023-05-14 13:34:12 --> Hooks Class Initialized
INFO - 2023-05-14 13:34:12 --> Utf8 Class Initialized
INFO - 2023-05-14 13:34:12 --> URI Class Initialized
INFO - 2023-05-14 13:34:12 --> Router Class Initialized
INFO - 2023-05-14 13:34:12 --> Output Class Initialized
INFO - 2023-05-14 13:34:12 --> Security Class Initialized
INFO - 2023-05-14 13:34:12 --> Input Class Initialized
INFO - 2023-05-14 13:34:12 --> Language Class Initialized
INFO - 2023-05-14 13:34:12 --> Loader Class Initialized
INFO - 2023-05-14 13:34:12 --> Helper loaded: url_helper
INFO - 2023-05-14 13:34:12 --> Helper loaded: form_helper
INFO - 2023-05-14 13:34:12 --> Database Driver Class Initialized
INFO - 2023-05-14 13:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:34:12 --> Form Validation Class Initialized
INFO - 2023-05-14 13:34:12 --> Controller Class Initialized
INFO - 2023-05-14 13:34:12 --> Model "m_user" initialized
INFO - 2023-05-14 13:34:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-14 13:34:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-14 13:34:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-14 13:34:12 --> Final output sent to browser
INFO - 2023-05-14 13:34:17 --> Config Class Initialized
INFO - 2023-05-14 13:34:17 --> Hooks Class Initialized
INFO - 2023-05-14 13:34:17 --> Utf8 Class Initialized
INFO - 2023-05-14 13:34:17 --> URI Class Initialized
INFO - 2023-05-14 13:34:17 --> Router Class Initialized
INFO - 2023-05-14 13:34:17 --> Output Class Initialized
INFO - 2023-05-14 13:34:17 --> Security Class Initialized
INFO - 2023-05-14 13:34:17 --> Input Class Initialized
INFO - 2023-05-14 13:34:17 --> Language Class Initialized
INFO - 2023-05-14 13:34:17 --> Loader Class Initialized
INFO - 2023-05-14 13:34:17 --> Helper loaded: url_helper
INFO - 2023-05-14 13:34:17 --> Helper loaded: form_helper
INFO - 2023-05-14 13:34:17 --> Database Driver Class Initialized
INFO - 2023-05-14 13:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:34:17 --> Form Validation Class Initialized
INFO - 2023-05-14 13:34:17 --> Controller Class Initialized
INFO - 2023-05-14 13:34:17 --> Model "m_user" initialized
INFO - 2023-05-14 13:34:17 --> Config Class Initialized
INFO - 2023-05-14 13:34:17 --> Hooks Class Initialized
INFO - 2023-05-14 13:34:17 --> Utf8 Class Initialized
INFO - 2023-05-14 13:34:17 --> URI Class Initialized
INFO - 2023-05-14 13:34:17 --> Router Class Initialized
INFO - 2023-05-14 13:34:17 --> Output Class Initialized
INFO - 2023-05-14 13:34:17 --> Security Class Initialized
INFO - 2023-05-14 13:34:17 --> Input Class Initialized
INFO - 2023-05-14 13:34:17 --> Language Class Initialized
INFO - 2023-05-14 13:34:17 --> Loader Class Initialized
INFO - 2023-05-14 13:34:17 --> Helper loaded: url_helper
INFO - 2023-05-14 13:34:17 --> Helper loaded: form_helper
INFO - 2023-05-14 13:34:17 --> Database Driver Class Initialized
INFO - 2023-05-14 13:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:34:17 --> Form Validation Class Initialized
INFO - 2023-05-14 13:34:17 --> Controller Class Initialized
INFO - 2023-05-14 13:34:17 --> Model "m_user" initialized
INFO - 2023-05-14 13:34:17 --> Model "m_datatrain" initialized
INFO - 2023-05-14 13:34:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 13:34:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 13:34:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-14 13:34:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 13:34:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 13:34:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-14 13:34:17 --> Final output sent to browser
INFO - 2023-05-14 13:34:29 --> Config Class Initialized
INFO - 2023-05-14 13:34:29 --> Hooks Class Initialized
INFO - 2023-05-14 13:34:29 --> Utf8 Class Initialized
INFO - 2023-05-14 13:34:29 --> URI Class Initialized
INFO - 2023-05-14 13:34:29 --> Router Class Initialized
INFO - 2023-05-14 13:34:29 --> Output Class Initialized
INFO - 2023-05-14 13:34:29 --> Security Class Initialized
INFO - 2023-05-14 13:34:29 --> Input Class Initialized
INFO - 2023-05-14 13:34:29 --> Language Class Initialized
INFO - 2023-05-14 13:34:29 --> Loader Class Initialized
INFO - 2023-05-14 13:34:29 --> Helper loaded: url_helper
INFO - 2023-05-14 13:34:29 --> Helper loaded: form_helper
INFO - 2023-05-14 13:34:29 --> Database Driver Class Initialized
INFO - 2023-05-14 13:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:34:29 --> Form Validation Class Initialized
INFO - 2023-05-14 13:34:29 --> Controller Class Initialized
INFO - 2023-05-14 13:34:29 --> Model "m_user" initialized
INFO - 2023-05-14 13:34:29 --> Config Class Initialized
INFO - 2023-05-14 13:34:29 --> Hooks Class Initialized
INFO - 2023-05-14 13:34:29 --> Utf8 Class Initialized
INFO - 2023-05-14 13:34:29 --> URI Class Initialized
INFO - 2023-05-14 13:34:29 --> Router Class Initialized
INFO - 2023-05-14 13:34:29 --> Output Class Initialized
INFO - 2023-05-14 13:34:29 --> Security Class Initialized
INFO - 2023-05-14 13:34:29 --> Input Class Initialized
INFO - 2023-05-14 13:34:29 --> Language Class Initialized
INFO - 2023-05-14 13:34:29 --> Loader Class Initialized
INFO - 2023-05-14 13:34:29 --> Helper loaded: url_helper
INFO - 2023-05-14 13:34:29 --> Helper loaded: form_helper
INFO - 2023-05-14 13:34:29 --> Database Driver Class Initialized
INFO - 2023-05-14 13:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:34:29 --> Form Validation Class Initialized
INFO - 2023-05-14 13:34:29 --> Controller Class Initialized
INFO - 2023-05-14 13:34:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-14 13:34:29 --> Final output sent to browser
INFO - 2023-05-14 13:34:30 --> Config Class Initialized
INFO - 2023-05-14 13:34:30 --> Hooks Class Initialized
INFO - 2023-05-14 13:34:30 --> Utf8 Class Initialized
INFO - 2023-05-14 13:34:30 --> URI Class Initialized
INFO - 2023-05-14 13:34:30 --> Router Class Initialized
INFO - 2023-05-14 13:34:30 --> Output Class Initialized
INFO - 2023-05-14 13:34:30 --> Security Class Initialized
INFO - 2023-05-14 13:34:30 --> Input Class Initialized
INFO - 2023-05-14 13:34:30 --> Language Class Initialized
INFO - 2023-05-14 13:34:30 --> Loader Class Initialized
INFO - 2023-05-14 13:34:30 --> Helper loaded: url_helper
INFO - 2023-05-14 13:34:30 --> Helper loaded: form_helper
INFO - 2023-05-14 13:34:30 --> Database Driver Class Initialized
INFO - 2023-05-14 13:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:34:30 --> Form Validation Class Initialized
INFO - 2023-05-14 13:34:30 --> Controller Class Initialized
INFO - 2023-05-14 13:34:30 --> Model "m_user" initialized
INFO - 2023-05-14 13:34:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 13:34:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 13:34:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-14 13:34:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 13:34:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 13:34:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-14 13:34:30 --> Final output sent to browser
INFO - 2023-05-14 13:45:37 --> Config Class Initialized
INFO - 2023-05-14 13:45:37 --> Hooks Class Initialized
INFO - 2023-05-14 13:45:37 --> Utf8 Class Initialized
INFO - 2023-05-14 13:45:37 --> URI Class Initialized
INFO - 2023-05-14 13:45:37 --> Router Class Initialized
INFO - 2023-05-14 13:45:37 --> Output Class Initialized
INFO - 2023-05-14 13:45:37 --> Security Class Initialized
INFO - 2023-05-14 13:45:37 --> Input Class Initialized
INFO - 2023-05-14 13:45:37 --> Language Class Initialized
INFO - 2023-05-14 13:45:37 --> Loader Class Initialized
INFO - 2023-05-14 13:45:37 --> Helper loaded: url_helper
INFO - 2023-05-14 13:45:37 --> Helper loaded: form_helper
INFO - 2023-05-14 13:45:37 --> Database Driver Class Initialized
INFO - 2023-05-14 13:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:45:37 --> Form Validation Class Initialized
INFO - 2023-05-14 13:45:37 --> Controller Class Initialized
INFO - 2023-05-14 13:45:37 --> Model "m_user" initialized
INFO - 2023-05-14 13:45:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 13:45:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 13:45:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-14 13:45:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 13:45:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 13:45:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-14 13:45:37 --> Final output sent to browser
INFO - 2023-05-14 13:45:40 --> Config Class Initialized
INFO - 2023-05-14 13:45:40 --> Hooks Class Initialized
INFO - 2023-05-14 13:45:40 --> Utf8 Class Initialized
INFO - 2023-05-14 13:45:40 --> URI Class Initialized
INFO - 2023-05-14 13:45:40 --> Router Class Initialized
INFO - 2023-05-14 13:45:40 --> Output Class Initialized
INFO - 2023-05-14 13:45:40 --> Security Class Initialized
INFO - 2023-05-14 13:45:40 --> Input Class Initialized
INFO - 2023-05-14 13:45:40 --> Language Class Initialized
INFO - 2023-05-14 13:45:40 --> Loader Class Initialized
INFO - 2023-05-14 13:45:40 --> Helper loaded: url_helper
INFO - 2023-05-14 13:45:40 --> Helper loaded: form_helper
INFO - 2023-05-14 13:45:40 --> Database Driver Class Initialized
INFO - 2023-05-14 13:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:45:40 --> Form Validation Class Initialized
INFO - 2023-05-14 13:45:40 --> Controller Class Initialized
INFO - 2023-05-14 13:45:40 --> Model "m_datatrain" initialized
INFO - 2023-05-14 13:45:40 --> Model "m_datatest" initialized
INFO - 2023-05-14 13:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 13:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 13:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-14 13:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-14 13:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 13:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 13:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-14 13:45:40 --> Final output sent to browser
INFO - 2023-05-14 13:46:25 --> Config Class Initialized
INFO - 2023-05-14 13:46:25 --> Hooks Class Initialized
INFO - 2023-05-14 13:46:25 --> Utf8 Class Initialized
INFO - 2023-05-14 13:46:25 --> URI Class Initialized
INFO - 2023-05-14 13:46:25 --> Router Class Initialized
INFO - 2023-05-14 13:46:25 --> Output Class Initialized
INFO - 2023-05-14 13:46:25 --> Security Class Initialized
INFO - 2023-05-14 13:46:25 --> Input Class Initialized
INFO - 2023-05-14 13:46:25 --> Language Class Initialized
INFO - 2023-05-14 13:46:25 --> Loader Class Initialized
INFO - 2023-05-14 13:46:25 --> Helper loaded: url_helper
INFO - 2023-05-14 13:46:25 --> Helper loaded: form_helper
INFO - 2023-05-14 13:46:25 --> Database Driver Class Initialized
INFO - 2023-05-14 13:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:46:25 --> Form Validation Class Initialized
INFO - 2023-05-14 13:46:25 --> Controller Class Initialized
INFO - 2023-05-14 13:46:25 --> Model "m_datatrain" initialized
INFO - 2023-05-14 13:46:25 --> Model "m_datatest" initialized
INFO - 2023-05-14 13:46:25 --> Final output sent to browser
INFO - 2023-05-14 13:46:51 --> Config Class Initialized
INFO - 2023-05-14 13:46:51 --> Hooks Class Initialized
INFO - 2023-05-14 13:46:51 --> Utf8 Class Initialized
INFO - 2023-05-14 13:46:51 --> URI Class Initialized
INFO - 2023-05-14 13:46:51 --> Router Class Initialized
INFO - 2023-05-14 13:46:51 --> Output Class Initialized
INFO - 2023-05-14 13:46:51 --> Security Class Initialized
INFO - 2023-05-14 13:46:51 --> Input Class Initialized
INFO - 2023-05-14 13:46:51 --> Language Class Initialized
INFO - 2023-05-14 13:46:51 --> Loader Class Initialized
INFO - 2023-05-14 13:46:51 --> Helper loaded: url_helper
INFO - 2023-05-14 13:46:51 --> Helper loaded: form_helper
INFO - 2023-05-14 13:46:51 --> Database Driver Class Initialized
INFO - 2023-05-14 13:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 13:46:51 --> Form Validation Class Initialized
INFO - 2023-05-14 13:46:51 --> Controller Class Initialized
INFO - 2023-05-14 13:46:51 --> Model "m_datatrain" initialized
INFO - 2023-05-14 13:46:51 --> Model "m_datatest" initialized
INFO - 2023-05-14 13:46:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 13:46:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 13:46:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-14 13:46:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-14 13:46:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 13:46:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 13:46:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-14 13:46:51 --> Final output sent to browser
INFO - 2023-05-14 14:04:12 --> Config Class Initialized
INFO - 2023-05-14 14:04:12 --> Hooks Class Initialized
INFO - 2023-05-14 14:04:12 --> Utf8 Class Initialized
INFO - 2023-05-14 14:04:12 --> URI Class Initialized
INFO - 2023-05-14 14:04:12 --> Router Class Initialized
INFO - 2023-05-14 14:04:12 --> Output Class Initialized
INFO - 2023-05-14 14:04:12 --> Security Class Initialized
INFO - 2023-05-14 14:04:12 --> Input Class Initialized
INFO - 2023-05-14 14:04:12 --> Language Class Initialized
INFO - 2023-05-14 14:04:12 --> Loader Class Initialized
INFO - 2023-05-14 14:04:12 --> Helper loaded: url_helper
INFO - 2023-05-14 14:04:12 --> Helper loaded: form_helper
INFO - 2023-05-14 14:04:12 --> Database Driver Class Initialized
INFO - 2023-05-14 14:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 14:04:12 --> Form Validation Class Initialized
INFO - 2023-05-14 14:04:12 --> Controller Class Initialized
INFO - 2023-05-14 14:04:12 --> Model "m_datatrain" initialized
INFO - 2023-05-14 14:04:12 --> Model "m_datatest" initialized
INFO - 2023-05-14 14:04:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 14:04:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 14:04:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-14 14:04:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-14 14:04:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 14:04:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 14:04:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-14 14:04:12 --> Final output sent to browser
INFO - 2023-05-14 14:05:32 --> Config Class Initialized
INFO - 2023-05-14 14:05:32 --> Hooks Class Initialized
INFO - 2023-05-14 14:05:32 --> Utf8 Class Initialized
INFO - 2023-05-14 14:05:32 --> URI Class Initialized
INFO - 2023-05-14 14:05:32 --> Router Class Initialized
INFO - 2023-05-14 14:05:32 --> Output Class Initialized
INFO - 2023-05-14 14:05:32 --> Security Class Initialized
INFO - 2023-05-14 14:05:32 --> Input Class Initialized
INFO - 2023-05-14 14:05:32 --> Language Class Initialized
ERROR - 2023-05-14 14:05:32 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 63
INFO - 2023-05-14 14:05:55 --> Config Class Initialized
INFO - 2023-05-14 14:05:55 --> Hooks Class Initialized
INFO - 2023-05-14 14:05:55 --> Utf8 Class Initialized
INFO - 2023-05-14 14:05:55 --> URI Class Initialized
INFO - 2023-05-14 14:05:55 --> Router Class Initialized
INFO - 2023-05-14 14:05:55 --> Output Class Initialized
INFO - 2023-05-14 14:05:55 --> Security Class Initialized
INFO - 2023-05-14 14:05:55 --> Input Class Initialized
INFO - 2023-05-14 14:05:55 --> Language Class Initialized
INFO - 2023-05-14 14:05:55 --> Loader Class Initialized
INFO - 2023-05-14 14:05:55 --> Helper loaded: url_helper
INFO - 2023-05-14 14:05:55 --> Helper loaded: form_helper
INFO - 2023-05-14 14:05:55 --> Database Driver Class Initialized
INFO - 2023-05-14 14:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 14:05:55 --> Form Validation Class Initialized
INFO - 2023-05-14 14:05:55 --> Controller Class Initialized
INFO - 2023-05-14 14:05:55 --> Model "m_datatrain" initialized
INFO - 2023-05-14 14:05:55 --> Model "m_datatest" initialized
INFO - 2023-05-14 14:05:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 14:05:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 14:05:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-14 14:05:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-14 14:05:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 14:05:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 14:05:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-14 14:05:55 --> Final output sent to browser
INFO - 2023-05-14 14:06:40 --> Config Class Initialized
INFO - 2023-05-14 14:06:40 --> Hooks Class Initialized
INFO - 2023-05-14 14:06:40 --> Utf8 Class Initialized
INFO - 2023-05-14 14:06:40 --> URI Class Initialized
INFO - 2023-05-14 14:06:40 --> Router Class Initialized
INFO - 2023-05-14 14:06:40 --> Output Class Initialized
INFO - 2023-05-14 14:06:40 --> Security Class Initialized
INFO - 2023-05-14 14:06:40 --> Input Class Initialized
INFO - 2023-05-14 14:06:40 --> Language Class Initialized
INFO - 2023-05-14 14:06:40 --> Loader Class Initialized
INFO - 2023-05-14 14:06:40 --> Helper loaded: url_helper
INFO - 2023-05-14 14:06:40 --> Helper loaded: form_helper
INFO - 2023-05-14 14:06:40 --> Database Driver Class Initialized
INFO - 2023-05-14 14:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 14:06:40 --> Form Validation Class Initialized
INFO - 2023-05-14 14:06:40 --> Controller Class Initialized
INFO - 2023-05-14 14:06:40 --> Model "m_datatrain" initialized
INFO - 2023-05-14 14:06:40 --> Model "m_datatest" initialized
INFO - 2023-05-14 14:06:40 --> Final output sent to browser
INFO - 2023-05-14 19:26:09 --> Config Class Initialized
INFO - 2023-05-14 19:26:09 --> Hooks Class Initialized
INFO - 2023-05-14 19:26:09 --> Utf8 Class Initialized
INFO - 2023-05-14 19:26:09 --> URI Class Initialized
INFO - 2023-05-14 19:26:09 --> Router Class Initialized
INFO - 2023-05-14 19:26:09 --> Output Class Initialized
INFO - 2023-05-14 19:26:09 --> Security Class Initialized
INFO - 2023-05-14 19:26:09 --> Input Class Initialized
INFO - 2023-05-14 19:26:09 --> Language Class Initialized
INFO - 2023-05-14 19:26:09 --> Loader Class Initialized
INFO - 2023-05-14 19:26:09 --> Helper loaded: url_helper
INFO - 2023-05-14 19:26:09 --> Helper loaded: form_helper
INFO - 2023-05-14 19:26:09 --> Database Driver Class Initialized
INFO - 2023-05-14 19:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:26:09 --> Form Validation Class Initialized
INFO - 2023-05-14 19:26:10 --> Controller Class Initialized
INFO - 2023-05-14 19:26:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-14 19:26:10 --> Final output sent to browser
INFO - 2023-05-14 19:26:11 --> Config Class Initialized
INFO - 2023-05-14 19:26:11 --> Hooks Class Initialized
INFO - 2023-05-14 19:26:11 --> Utf8 Class Initialized
INFO - 2023-05-14 19:26:11 --> URI Class Initialized
INFO - 2023-05-14 19:26:11 --> Router Class Initialized
INFO - 2023-05-14 19:26:11 --> Output Class Initialized
INFO - 2023-05-14 19:26:11 --> Security Class Initialized
INFO - 2023-05-14 19:26:11 --> Input Class Initialized
INFO - 2023-05-14 19:26:11 --> Language Class Initialized
INFO - 2023-05-14 19:26:11 --> Loader Class Initialized
INFO - 2023-05-14 19:26:11 --> Helper loaded: url_helper
INFO - 2023-05-14 19:26:11 --> Helper loaded: form_helper
INFO - 2023-05-14 19:26:11 --> Database Driver Class Initialized
INFO - 2023-05-14 19:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:26:11 --> Form Validation Class Initialized
INFO - 2023-05-14 19:26:11 --> Controller Class Initialized
INFO - 2023-05-14 19:26:11 --> Model "m_user" initialized
INFO - 2023-05-14 19:26:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 19:26:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 19:26:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-14 19:26:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 19:26:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 19:26:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-14 19:26:12 --> Final output sent to browser
INFO - 2023-05-14 19:26:14 --> Config Class Initialized
INFO - 2023-05-14 19:26:14 --> Hooks Class Initialized
INFO - 2023-05-14 19:26:14 --> Utf8 Class Initialized
INFO - 2023-05-14 19:26:14 --> URI Class Initialized
INFO - 2023-05-14 19:26:14 --> Router Class Initialized
INFO - 2023-05-14 19:26:14 --> Output Class Initialized
INFO - 2023-05-14 19:26:14 --> Security Class Initialized
INFO - 2023-05-14 19:26:14 --> Input Class Initialized
INFO - 2023-05-14 19:26:14 --> Language Class Initialized
INFO - 2023-05-14 19:26:14 --> Loader Class Initialized
INFO - 2023-05-14 19:26:14 --> Helper loaded: url_helper
INFO - 2023-05-14 19:26:14 --> Helper loaded: form_helper
INFO - 2023-05-14 19:26:14 --> Database Driver Class Initialized
INFO - 2023-05-14 19:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:26:14 --> Form Validation Class Initialized
INFO - 2023-05-14 19:26:14 --> Controller Class Initialized
INFO - 2023-05-14 19:26:14 --> Model "m_datatrain" initialized
INFO - 2023-05-14 19:26:14 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:26:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 19:26:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 19:26:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-14 19:26:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-14 19:26:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 19:26:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 19:26:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-14 19:26:14 --> Final output sent to browser
INFO - 2023-05-14 19:27:06 --> Config Class Initialized
INFO - 2023-05-14 19:27:06 --> Hooks Class Initialized
INFO - 2023-05-14 19:27:06 --> Utf8 Class Initialized
INFO - 2023-05-14 19:27:06 --> URI Class Initialized
INFO - 2023-05-14 19:27:06 --> Router Class Initialized
INFO - 2023-05-14 19:27:06 --> Output Class Initialized
INFO - 2023-05-14 19:27:06 --> Security Class Initialized
INFO - 2023-05-14 19:27:06 --> Input Class Initialized
INFO - 2023-05-14 19:27:06 --> Language Class Initialized
INFO - 2023-05-14 19:27:06 --> Loader Class Initialized
INFO - 2023-05-14 19:27:06 --> Helper loaded: url_helper
INFO - 2023-05-14 19:27:06 --> Helper loaded: form_helper
INFO - 2023-05-14 19:27:06 --> Database Driver Class Initialized
INFO - 2023-05-14 19:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:27:06 --> Form Validation Class Initialized
INFO - 2023-05-14 19:27:06 --> Controller Class Initialized
INFO - 2023-05-14 19:27:06 --> Model "m_datatrain" initialized
INFO - 2023-05-14 19:27:06 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:27:06 --> Final output sent to browser
INFO - 2023-05-14 19:32:49 --> Config Class Initialized
INFO - 2023-05-14 19:32:49 --> Hooks Class Initialized
INFO - 2023-05-14 19:32:49 --> Utf8 Class Initialized
INFO - 2023-05-14 19:32:49 --> URI Class Initialized
INFO - 2023-05-14 19:32:49 --> Router Class Initialized
INFO - 2023-05-14 19:32:49 --> Output Class Initialized
INFO - 2023-05-14 19:32:49 --> Security Class Initialized
INFO - 2023-05-14 19:32:49 --> Input Class Initialized
INFO - 2023-05-14 19:32:49 --> Language Class Initialized
INFO - 2023-05-14 19:32:49 --> Loader Class Initialized
INFO - 2023-05-14 19:32:49 --> Helper loaded: url_helper
INFO - 2023-05-14 19:32:49 --> Helper loaded: form_helper
INFO - 2023-05-14 19:32:49 --> Database Driver Class Initialized
INFO - 2023-05-14 19:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:32:49 --> Form Validation Class Initialized
INFO - 2023-05-14 19:32:49 --> Controller Class Initialized
INFO - 2023-05-14 19:32:49 --> Model "m_datatrain" initialized
INFO - 2023-05-14 19:32:49 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:32:49 --> Final output sent to browser
INFO - 2023-05-14 19:40:10 --> Config Class Initialized
INFO - 2023-05-14 19:40:10 --> Hooks Class Initialized
INFO - 2023-05-14 19:40:10 --> Utf8 Class Initialized
INFO - 2023-05-14 19:40:10 --> URI Class Initialized
INFO - 2023-05-14 19:40:10 --> Router Class Initialized
INFO - 2023-05-14 19:40:10 --> Output Class Initialized
INFO - 2023-05-14 19:40:10 --> Security Class Initialized
INFO - 2023-05-14 19:40:10 --> Input Class Initialized
INFO - 2023-05-14 19:40:10 --> Language Class Initialized
INFO - 2023-05-14 19:40:10 --> Loader Class Initialized
INFO - 2023-05-14 19:40:10 --> Helper loaded: url_helper
INFO - 2023-05-14 19:40:10 --> Helper loaded: form_helper
INFO - 2023-05-14 19:40:10 --> Database Driver Class Initialized
INFO - 2023-05-14 19:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:40:10 --> Form Validation Class Initialized
INFO - 2023-05-14 19:40:10 --> Controller Class Initialized
INFO - 2023-05-14 19:40:10 --> Model "m_datatrain" initialized
INFO - 2023-05-14 19:40:10 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:40:10 --> Final output sent to browser
INFO - 2023-05-14 19:41:24 --> Config Class Initialized
INFO - 2023-05-14 19:41:24 --> Hooks Class Initialized
INFO - 2023-05-14 19:41:24 --> Utf8 Class Initialized
INFO - 2023-05-14 19:41:24 --> URI Class Initialized
INFO - 2023-05-14 19:41:24 --> Router Class Initialized
INFO - 2023-05-14 19:41:24 --> Output Class Initialized
INFO - 2023-05-14 19:41:24 --> Security Class Initialized
INFO - 2023-05-14 19:41:24 --> Input Class Initialized
INFO - 2023-05-14 19:41:24 --> Language Class Initialized
INFO - 2023-05-14 19:41:24 --> Loader Class Initialized
INFO - 2023-05-14 19:41:24 --> Helper loaded: url_helper
INFO - 2023-05-14 19:41:24 --> Helper loaded: form_helper
INFO - 2023-05-14 19:41:24 --> Database Driver Class Initialized
INFO - 2023-05-14 19:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:41:24 --> Form Validation Class Initialized
INFO - 2023-05-14 19:41:24 --> Controller Class Initialized
INFO - 2023-05-14 19:41:24 --> Model "m_datatrain" initialized
INFO - 2023-05-14 19:41:24 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 19:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 19:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-14 19:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-14 19:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 19:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 19:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-14 19:41:24 --> Final output sent to browser
INFO - 2023-05-14 19:42:30 --> Config Class Initialized
INFO - 2023-05-14 19:42:30 --> Hooks Class Initialized
INFO - 2023-05-14 19:42:30 --> Utf8 Class Initialized
INFO - 2023-05-14 19:42:30 --> URI Class Initialized
INFO - 2023-05-14 19:42:30 --> Router Class Initialized
INFO - 2023-05-14 19:42:30 --> Output Class Initialized
INFO - 2023-05-14 19:42:30 --> Security Class Initialized
INFO - 2023-05-14 19:42:30 --> Input Class Initialized
INFO - 2023-05-14 19:42:30 --> Language Class Initialized
INFO - 2023-05-14 19:42:30 --> Loader Class Initialized
INFO - 2023-05-14 19:42:30 --> Helper loaded: url_helper
INFO - 2023-05-14 19:42:30 --> Helper loaded: form_helper
INFO - 2023-05-14 19:42:30 --> Database Driver Class Initialized
INFO - 2023-05-14 19:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:42:30 --> Form Validation Class Initialized
INFO - 2023-05-14 19:42:30 --> Controller Class Initialized
INFO - 2023-05-14 19:42:30 --> Model "m_datatrain" initialized
INFO - 2023-05-14 19:42:30 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:42:30 --> Config Class Initialized
INFO - 2023-05-14 19:42:30 --> Hooks Class Initialized
INFO - 2023-05-14 19:42:30 --> Utf8 Class Initialized
INFO - 2023-05-14 19:42:30 --> URI Class Initialized
INFO - 2023-05-14 19:42:30 --> Router Class Initialized
INFO - 2023-05-14 19:42:30 --> Output Class Initialized
INFO - 2023-05-14 19:42:30 --> Security Class Initialized
INFO - 2023-05-14 19:42:30 --> Input Class Initialized
INFO - 2023-05-14 19:42:30 --> Language Class Initialized
INFO - 2023-05-14 19:42:30 --> Loader Class Initialized
INFO - 2023-05-14 19:42:30 --> Helper loaded: url_helper
INFO - 2023-05-14 19:42:30 --> Helper loaded: form_helper
INFO - 2023-05-14 19:42:30 --> Database Driver Class Initialized
INFO - 2023-05-14 19:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:42:30 --> Form Validation Class Initialized
INFO - 2023-05-14 19:42:30 --> Controller Class Initialized
INFO - 2023-05-14 19:42:30 --> Model "m_datatrain" initialized
INFO - 2023-05-14 19:42:30 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:42:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 19:42:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 19:42:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-14 19:42:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-14 19:42:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 19:42:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 19:42:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-14 19:42:30 --> Final output sent to browser
INFO - 2023-05-14 19:53:09 --> Config Class Initialized
INFO - 2023-05-14 19:53:09 --> Hooks Class Initialized
INFO - 2023-05-14 19:53:09 --> Utf8 Class Initialized
INFO - 2023-05-14 19:53:09 --> URI Class Initialized
INFO - 2023-05-14 19:53:09 --> Router Class Initialized
INFO - 2023-05-14 19:53:09 --> Output Class Initialized
INFO - 2023-05-14 19:53:09 --> Security Class Initialized
INFO - 2023-05-14 19:53:09 --> Input Class Initialized
INFO - 2023-05-14 19:53:09 --> Language Class Initialized
INFO - 2023-05-14 19:53:09 --> Loader Class Initialized
INFO - 2023-05-14 19:53:09 --> Helper loaded: url_helper
INFO - 2023-05-14 19:53:09 --> Helper loaded: form_helper
INFO - 2023-05-14 19:53:09 --> Database Driver Class Initialized
INFO - 2023-05-14 19:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:53:09 --> Form Validation Class Initialized
INFO - 2023-05-14 19:53:09 --> Controller Class Initialized
INFO - 2023-05-14 19:53:09 --> Model "m_user" initialized
INFO - 2023-05-14 19:53:09 --> Config Class Initialized
INFO - 2023-05-14 19:53:09 --> Hooks Class Initialized
INFO - 2023-05-14 19:53:09 --> Utf8 Class Initialized
INFO - 2023-05-14 19:53:09 --> URI Class Initialized
INFO - 2023-05-14 19:53:09 --> Router Class Initialized
INFO - 2023-05-14 19:53:09 --> Output Class Initialized
INFO - 2023-05-14 19:53:09 --> Security Class Initialized
INFO - 2023-05-14 19:53:09 --> Input Class Initialized
INFO - 2023-05-14 19:53:09 --> Language Class Initialized
INFO - 2023-05-14 19:53:09 --> Loader Class Initialized
INFO - 2023-05-14 19:53:09 --> Helper loaded: url_helper
INFO - 2023-05-14 19:53:09 --> Helper loaded: form_helper
INFO - 2023-05-14 19:53:09 --> Database Driver Class Initialized
INFO - 2023-05-14 19:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:53:10 --> Form Validation Class Initialized
INFO - 2023-05-14 19:53:10 --> Controller Class Initialized
INFO - 2023-05-14 19:53:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-14 19:53:10 --> Final output sent to browser
INFO - 2023-05-14 19:53:11 --> Config Class Initialized
INFO - 2023-05-14 19:53:11 --> Hooks Class Initialized
INFO - 2023-05-14 19:53:11 --> Utf8 Class Initialized
INFO - 2023-05-14 19:53:11 --> URI Class Initialized
INFO - 2023-05-14 19:53:11 --> Router Class Initialized
INFO - 2023-05-14 19:53:11 --> Output Class Initialized
INFO - 2023-05-14 19:53:11 --> Security Class Initialized
INFO - 2023-05-14 19:53:11 --> Input Class Initialized
INFO - 2023-05-14 19:53:11 --> Language Class Initialized
INFO - 2023-05-14 19:53:11 --> Loader Class Initialized
INFO - 2023-05-14 19:53:11 --> Helper loaded: url_helper
INFO - 2023-05-14 19:53:11 --> Helper loaded: form_helper
INFO - 2023-05-14 19:53:11 --> Database Driver Class Initialized
INFO - 2023-05-14 19:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:53:11 --> Form Validation Class Initialized
INFO - 2023-05-14 19:53:11 --> Controller Class Initialized
INFO - 2023-05-14 19:53:11 --> Model "m_user" initialized
INFO - 2023-05-14 19:53:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-14 19:53:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-14 19:53:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-14 19:53:11 --> Final output sent to browser
INFO - 2023-05-14 19:53:15 --> Config Class Initialized
INFO - 2023-05-14 19:53:15 --> Hooks Class Initialized
INFO - 2023-05-14 19:53:15 --> Utf8 Class Initialized
INFO - 2023-05-14 19:53:15 --> URI Class Initialized
INFO - 2023-05-14 19:53:15 --> Router Class Initialized
INFO - 2023-05-14 19:53:15 --> Output Class Initialized
INFO - 2023-05-14 19:53:15 --> Security Class Initialized
INFO - 2023-05-14 19:53:15 --> Input Class Initialized
INFO - 2023-05-14 19:53:15 --> Language Class Initialized
INFO - 2023-05-14 19:53:15 --> Loader Class Initialized
INFO - 2023-05-14 19:53:15 --> Helper loaded: url_helper
INFO - 2023-05-14 19:53:15 --> Helper loaded: form_helper
INFO - 2023-05-14 19:53:15 --> Database Driver Class Initialized
INFO - 2023-05-14 19:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:53:15 --> Form Validation Class Initialized
INFO - 2023-05-14 19:53:15 --> Controller Class Initialized
INFO - 2023-05-14 19:53:15 --> Model "m_user" initialized
INFO - 2023-05-14 19:53:15 --> Config Class Initialized
INFO - 2023-05-14 19:53:15 --> Hooks Class Initialized
INFO - 2023-05-14 19:53:15 --> Utf8 Class Initialized
INFO - 2023-05-14 19:53:15 --> URI Class Initialized
INFO - 2023-05-14 19:53:15 --> Router Class Initialized
INFO - 2023-05-14 19:53:15 --> Output Class Initialized
INFO - 2023-05-14 19:53:15 --> Security Class Initialized
INFO - 2023-05-14 19:53:15 --> Input Class Initialized
INFO - 2023-05-14 19:53:15 --> Language Class Initialized
INFO - 2023-05-14 19:53:15 --> Loader Class Initialized
INFO - 2023-05-14 19:53:15 --> Helper loaded: url_helper
INFO - 2023-05-14 19:53:15 --> Helper loaded: form_helper
INFO - 2023-05-14 19:53:15 --> Database Driver Class Initialized
INFO - 2023-05-14 19:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:53:15 --> Form Validation Class Initialized
INFO - 2023-05-14 19:53:15 --> Controller Class Initialized
INFO - 2023-05-14 19:53:15 --> Model "m_user" initialized
INFO - 2023-05-14 19:53:15 --> Model "m_datatrain" initialized
INFO - 2023-05-14 19:53:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 19:53:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 19:53:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-14 19:53:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 19:53:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 19:53:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-14 19:53:15 --> Final output sent to browser
INFO - 2023-05-14 19:53:18 --> Config Class Initialized
INFO - 2023-05-14 19:53:18 --> Hooks Class Initialized
INFO - 2023-05-14 19:53:18 --> Utf8 Class Initialized
INFO - 2023-05-14 19:53:18 --> URI Class Initialized
INFO - 2023-05-14 19:53:18 --> Router Class Initialized
INFO - 2023-05-14 19:53:18 --> Output Class Initialized
INFO - 2023-05-14 19:53:18 --> Security Class Initialized
INFO - 2023-05-14 19:53:18 --> Input Class Initialized
INFO - 2023-05-14 19:53:18 --> Language Class Initialized
INFO - 2023-05-14 19:53:18 --> Loader Class Initialized
INFO - 2023-05-14 19:53:18 --> Helper loaded: url_helper
INFO - 2023-05-14 19:53:18 --> Helper loaded: form_helper
INFO - 2023-05-14 19:53:18 --> Database Driver Class Initialized
INFO - 2023-05-14 19:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:53:18 --> Form Validation Class Initialized
INFO - 2023-05-14 19:53:18 --> Controller Class Initialized
INFO - 2023-05-14 19:53:18 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:53:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 19:53:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 19:53:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-14 19:53:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-14 19:53:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 19:53:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 19:53:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-14 19:53:18 --> Final output sent to browser
INFO - 2023-05-14 19:53:35 --> Config Class Initialized
INFO - 2023-05-14 19:53:35 --> Hooks Class Initialized
INFO - 2023-05-14 19:53:35 --> Utf8 Class Initialized
INFO - 2023-05-14 19:53:35 --> URI Class Initialized
INFO - 2023-05-14 19:53:35 --> Router Class Initialized
INFO - 2023-05-14 19:53:35 --> Output Class Initialized
INFO - 2023-05-14 19:53:35 --> Security Class Initialized
INFO - 2023-05-14 19:53:35 --> Input Class Initialized
INFO - 2023-05-14 19:53:35 --> Language Class Initialized
INFO - 2023-05-14 19:53:35 --> Loader Class Initialized
INFO - 2023-05-14 19:53:35 --> Helper loaded: url_helper
INFO - 2023-05-14 19:53:35 --> Helper loaded: form_helper
INFO - 2023-05-14 19:53:35 --> Database Driver Class Initialized
INFO - 2023-05-14 19:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:53:35 --> Form Validation Class Initialized
INFO - 2023-05-14 19:53:35 --> Controller Class Initialized
INFO - 2023-05-14 19:53:35 --> Model "m_user" initialized
INFO - 2023-05-14 19:53:35 --> Model "m_datatrain" initialized
INFO - 2023-05-14 19:53:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 19:53:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 19:53:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-14 19:53:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 19:53:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 19:53:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-14 19:53:35 --> Final output sent to browser
INFO - 2023-05-14 19:55:04 --> Config Class Initialized
INFO - 2023-05-14 19:55:04 --> Hooks Class Initialized
INFO - 2023-05-14 19:55:04 --> Utf8 Class Initialized
INFO - 2023-05-14 19:55:04 --> URI Class Initialized
INFO - 2023-05-14 19:55:04 --> Router Class Initialized
INFO - 2023-05-14 19:55:04 --> Output Class Initialized
INFO - 2023-05-14 19:55:04 --> Security Class Initialized
INFO - 2023-05-14 19:55:04 --> Input Class Initialized
INFO - 2023-05-14 19:55:04 --> Language Class Initialized
INFO - 2023-05-14 19:55:04 --> Loader Class Initialized
INFO - 2023-05-14 19:55:04 --> Helper loaded: url_helper
INFO - 2023-05-14 19:55:04 --> Helper loaded: form_helper
INFO - 2023-05-14 19:55:04 --> Database Driver Class Initialized
INFO - 2023-05-14 19:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:55:04 --> Form Validation Class Initialized
INFO - 2023-05-14 19:55:04 --> Controller Class Initialized
INFO - 2023-05-14 19:55:04 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:55:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 19:55:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 19:55:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-14 19:55:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-14 19:55:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 19:55:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 19:55:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-14 19:55:04 --> Final output sent to browser
INFO - 2023-05-14 19:55:37 --> Config Class Initialized
INFO - 2023-05-14 19:55:37 --> Hooks Class Initialized
INFO - 2023-05-14 19:55:37 --> Utf8 Class Initialized
INFO - 2023-05-14 19:55:37 --> URI Class Initialized
INFO - 2023-05-14 19:55:37 --> Router Class Initialized
INFO - 2023-05-14 19:55:37 --> Output Class Initialized
INFO - 2023-05-14 19:55:37 --> Security Class Initialized
INFO - 2023-05-14 19:55:37 --> Input Class Initialized
INFO - 2023-05-14 19:55:37 --> Language Class Initialized
INFO - 2023-05-14 19:55:38 --> Loader Class Initialized
INFO - 2023-05-14 19:55:38 --> Helper loaded: url_helper
INFO - 2023-05-14 19:55:38 --> Helper loaded: form_helper
INFO - 2023-05-14 19:55:38 --> Database Driver Class Initialized
INFO - 2023-05-14 19:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:55:38 --> Form Validation Class Initialized
INFO - 2023-05-14 19:55:38 --> Controller Class Initialized
INFO - 2023-05-14 19:55:38 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 19:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 19:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-14 19:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-14 19:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 19:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 19:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-14 19:55:38 --> Final output sent to browser
INFO - 2023-05-14 19:55:53 --> Config Class Initialized
INFO - 2023-05-14 19:55:53 --> Hooks Class Initialized
INFO - 2023-05-14 19:55:53 --> Utf8 Class Initialized
INFO - 2023-05-14 19:55:53 --> URI Class Initialized
INFO - 2023-05-14 19:55:53 --> Router Class Initialized
INFO - 2023-05-14 19:55:53 --> Output Class Initialized
INFO - 2023-05-14 19:55:53 --> Security Class Initialized
INFO - 2023-05-14 19:55:53 --> Input Class Initialized
INFO - 2023-05-14 19:55:53 --> Language Class Initialized
INFO - 2023-05-14 19:55:53 --> Loader Class Initialized
INFO - 2023-05-14 19:55:53 --> Helper loaded: url_helper
INFO - 2023-05-14 19:55:53 --> Helper loaded: form_helper
INFO - 2023-05-14 19:55:53 --> Database Driver Class Initialized
INFO - 2023-05-14 19:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:55:53 --> Form Validation Class Initialized
INFO - 2023-05-14 19:55:53 --> Controller Class Initialized
INFO - 2023-05-14 19:55:53 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 19:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 19:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-14 19:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-14 19:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 19:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 19:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-14 19:55:53 --> Final output sent to browser
INFO - 2023-05-14 19:56:20 --> Config Class Initialized
INFO - 2023-05-14 19:56:20 --> Hooks Class Initialized
INFO - 2023-05-14 19:56:20 --> Utf8 Class Initialized
INFO - 2023-05-14 19:56:20 --> URI Class Initialized
INFO - 2023-05-14 19:56:20 --> Router Class Initialized
INFO - 2023-05-14 19:56:20 --> Output Class Initialized
INFO - 2023-05-14 19:56:20 --> Security Class Initialized
INFO - 2023-05-14 19:56:20 --> Input Class Initialized
INFO - 2023-05-14 19:56:20 --> Language Class Initialized
INFO - 2023-05-14 19:56:20 --> Loader Class Initialized
INFO - 2023-05-14 19:56:20 --> Helper loaded: url_helper
INFO - 2023-05-14 19:56:20 --> Helper loaded: form_helper
INFO - 2023-05-14 19:56:20 --> Database Driver Class Initialized
INFO - 2023-05-14 19:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:56:20 --> Form Validation Class Initialized
INFO - 2023-05-14 19:56:20 --> Controller Class Initialized
INFO - 2023-05-14 19:56:20 --> Model "m_datatest" initialized
INFO - 2023-05-14 19:56:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-14 19:56:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-14 19:56:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-14 19:56:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-14 19:56:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-14 19:56:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-14 19:56:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-14 19:56:21 --> Final output sent to browser
INFO - 2023-05-14 19:56:45 --> Config Class Initialized
INFO - 2023-05-14 19:56:45 --> Hooks Class Initialized
INFO - 2023-05-14 19:56:45 --> Utf8 Class Initialized
INFO - 2023-05-14 19:56:45 --> URI Class Initialized
INFO - 2023-05-14 19:56:45 --> Router Class Initialized
INFO - 2023-05-14 19:56:45 --> Output Class Initialized
INFO - 2023-05-14 19:56:45 --> Security Class Initialized
INFO - 2023-05-14 19:56:45 --> Input Class Initialized
INFO - 2023-05-14 19:56:45 --> Language Class Initialized
INFO - 2023-05-14 19:56:45 --> Loader Class Initialized
INFO - 2023-05-14 19:56:45 --> Helper loaded: url_helper
INFO - 2023-05-14 19:56:45 --> Helper loaded: form_helper
INFO - 2023-05-14 19:56:45 --> Database Driver Class Initialized
INFO - 2023-05-14 19:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:56:45 --> Form Validation Class Initialized
INFO - 2023-05-14 19:56:45 --> Controller Class Initialized
INFO - 2023-05-14 19:56:45 --> Model "m_user" initialized
INFO - 2023-05-14 19:56:45 --> Config Class Initialized
INFO - 2023-05-14 19:56:45 --> Hooks Class Initialized
INFO - 2023-05-14 19:56:45 --> Utf8 Class Initialized
INFO - 2023-05-14 19:56:45 --> URI Class Initialized
INFO - 2023-05-14 19:56:45 --> Router Class Initialized
INFO - 2023-05-14 19:56:45 --> Output Class Initialized
INFO - 2023-05-14 19:56:45 --> Security Class Initialized
INFO - 2023-05-14 19:56:45 --> Input Class Initialized
INFO - 2023-05-14 19:56:45 --> Language Class Initialized
INFO - 2023-05-14 19:56:45 --> Loader Class Initialized
INFO - 2023-05-14 19:56:45 --> Helper loaded: url_helper
INFO - 2023-05-14 19:56:45 --> Helper loaded: form_helper
INFO - 2023-05-14 19:56:45 --> Database Driver Class Initialized
INFO - 2023-05-14 19:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 19:56:45 --> Form Validation Class Initialized
INFO - 2023-05-14 19:56:45 --> Controller Class Initialized
INFO - 2023-05-14 19:56:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-14 19:56:45 --> Final output sent to browser
