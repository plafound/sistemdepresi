<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-11 08:10:03 --> Config Class Initialized
INFO - 2023-06-11 08:10:03 --> Hooks Class Initialized
INFO - 2023-06-11 08:10:03 --> Utf8 Class Initialized
INFO - 2023-06-11 08:10:03 --> URI Class Initialized
INFO - 2023-06-11 08:10:03 --> Router Class Initialized
INFO - 2023-06-11 08:10:03 --> Output Class Initialized
INFO - 2023-06-11 08:10:03 --> Security Class Initialized
INFO - 2023-06-11 08:10:03 --> Input Class Initialized
INFO - 2023-06-11 08:10:03 --> Language Class Initialized
INFO - 2023-06-11 08:10:03 --> Loader Class Initialized
INFO - 2023-06-11 08:10:03 --> Helper loaded: url_helper
INFO - 2023-06-11 08:10:03 --> Helper loaded: form_helper
INFO - 2023-06-11 08:10:03 --> Database Driver Class Initialized
INFO - 2023-06-11 08:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:10:03 --> Form Validation Class Initialized
INFO - 2023-06-11 08:10:03 --> Controller Class Initialized
INFO - 2023-06-11 08:10:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 08:10:03 --> Final output sent to browser
INFO - 2023-06-11 08:10:07 --> Config Class Initialized
INFO - 2023-06-11 08:10:07 --> Hooks Class Initialized
INFO - 2023-06-11 08:10:07 --> Utf8 Class Initialized
INFO - 2023-06-11 08:10:07 --> URI Class Initialized
INFO - 2023-06-11 08:10:07 --> Router Class Initialized
INFO - 2023-06-11 08:10:07 --> Output Class Initialized
INFO - 2023-06-11 08:10:07 --> Security Class Initialized
INFO - 2023-06-11 08:10:07 --> Input Class Initialized
INFO - 2023-06-11 08:10:07 --> Language Class Initialized
INFO - 2023-06-11 08:10:07 --> Loader Class Initialized
INFO - 2023-06-11 08:10:07 --> Helper loaded: url_helper
INFO - 2023-06-11 08:10:07 --> Helper loaded: form_helper
INFO - 2023-06-11 08:10:07 --> Database Driver Class Initialized
INFO - 2023-06-11 08:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:10:07 --> Form Validation Class Initialized
INFO - 2023-06-11 08:10:07 --> Controller Class Initialized
INFO - 2023-06-11 08:10:07 --> Model "m_user" initialized
INFO - 2023-06-11 08:10:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-11 08:10:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-11 08:10:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-11 08:10:07 --> Final output sent to browser
INFO - 2023-06-11 08:10:12 --> Config Class Initialized
INFO - 2023-06-11 08:10:12 --> Hooks Class Initialized
INFO - 2023-06-11 08:10:12 --> Utf8 Class Initialized
INFO - 2023-06-11 08:10:12 --> URI Class Initialized
INFO - 2023-06-11 08:10:12 --> Router Class Initialized
INFO - 2023-06-11 08:10:12 --> Output Class Initialized
INFO - 2023-06-11 08:10:12 --> Security Class Initialized
INFO - 2023-06-11 08:10:12 --> Input Class Initialized
INFO - 2023-06-11 08:10:12 --> Language Class Initialized
INFO - 2023-06-11 08:10:12 --> Loader Class Initialized
INFO - 2023-06-11 08:10:12 --> Helper loaded: url_helper
INFO - 2023-06-11 08:10:12 --> Helper loaded: form_helper
INFO - 2023-06-11 08:10:12 --> Database Driver Class Initialized
INFO - 2023-06-11 08:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:10:12 --> Form Validation Class Initialized
INFO - 2023-06-11 08:10:12 --> Controller Class Initialized
INFO - 2023-06-11 08:10:12 --> Model "m_user" initialized
INFO - 2023-06-11 08:10:12 --> Config Class Initialized
INFO - 2023-06-11 08:10:12 --> Hooks Class Initialized
INFO - 2023-06-11 08:10:12 --> Utf8 Class Initialized
INFO - 2023-06-11 08:10:12 --> URI Class Initialized
INFO - 2023-06-11 08:10:12 --> Router Class Initialized
INFO - 2023-06-11 08:10:12 --> Output Class Initialized
INFO - 2023-06-11 08:10:12 --> Security Class Initialized
INFO - 2023-06-11 08:10:12 --> Input Class Initialized
INFO - 2023-06-11 08:10:12 --> Language Class Initialized
INFO - 2023-06-11 08:10:12 --> Loader Class Initialized
INFO - 2023-06-11 08:10:12 --> Helper loaded: url_helper
INFO - 2023-06-11 08:10:12 --> Helper loaded: form_helper
INFO - 2023-06-11 08:10:12 --> Database Driver Class Initialized
INFO - 2023-06-11 08:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:10:12 --> Form Validation Class Initialized
INFO - 2023-06-11 08:10:12 --> Controller Class Initialized
INFO - 2023-06-11 08:10:12 --> Model "m_user" initialized
INFO - 2023-06-11 08:10:12 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 08:10:12 --> Final output sent to browser
INFO - 2023-06-11 08:10:34 --> Config Class Initialized
INFO - 2023-06-11 08:10:34 --> Hooks Class Initialized
INFO - 2023-06-11 08:10:34 --> Utf8 Class Initialized
INFO - 2023-06-11 08:10:34 --> URI Class Initialized
INFO - 2023-06-11 08:10:34 --> Router Class Initialized
INFO - 2023-06-11 08:10:34 --> Output Class Initialized
INFO - 2023-06-11 08:10:34 --> Security Class Initialized
INFO - 2023-06-11 08:10:34 --> Input Class Initialized
INFO - 2023-06-11 08:10:34 --> Language Class Initialized
INFO - 2023-06-11 08:10:34 --> Loader Class Initialized
INFO - 2023-06-11 08:10:34 --> Helper loaded: url_helper
INFO - 2023-06-11 08:10:34 --> Helper loaded: form_helper
INFO - 2023-06-11 08:10:35 --> Database Driver Class Initialized
INFO - 2023-06-11 08:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:10:35 --> Form Validation Class Initialized
INFO - 2023-06-11 08:10:35 --> Controller Class Initialized
INFO - 2023-06-11 08:10:35 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:10:35 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 08:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 08:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:10:35 --> Final output sent to browser
INFO - 2023-06-11 08:11:52 --> Config Class Initialized
INFO - 2023-06-11 08:11:52 --> Hooks Class Initialized
INFO - 2023-06-11 08:11:52 --> Utf8 Class Initialized
INFO - 2023-06-11 08:11:52 --> URI Class Initialized
INFO - 2023-06-11 08:11:52 --> Router Class Initialized
INFO - 2023-06-11 08:11:52 --> Output Class Initialized
INFO - 2023-06-11 08:11:52 --> Security Class Initialized
INFO - 2023-06-11 08:11:52 --> Input Class Initialized
INFO - 2023-06-11 08:11:52 --> Language Class Initialized
INFO - 2023-06-11 08:11:52 --> Loader Class Initialized
INFO - 2023-06-11 08:11:52 --> Helper loaded: url_helper
INFO - 2023-06-11 08:11:52 --> Helper loaded: form_helper
INFO - 2023-06-11 08:11:52 --> Database Driver Class Initialized
INFO - 2023-06-11 08:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:11:52 --> Form Validation Class Initialized
INFO - 2023-06-11 08:11:52 --> Controller Class Initialized
INFO - 2023-06-11 08:11:52 --> Model "m_datatest" initialized
ERROR - 2023-06-11 08:11:52 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
ERROR - 2023-06-11 08:11:52 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 84
ERROR - 2023-06-11 08:11:52 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 85
ERROR - 2023-06-11 08:11:52 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 90
ERROR - 2023-06-11 08:11:52 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 91
ERROR - 2023-06-11 08:11:52 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 93
INFO - 2023-06-11 08:11:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:11:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:11:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 08:11:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 08:11:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:11:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:11:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-11 08:11:52 --> Final output sent to browser
INFO - 2023-06-11 08:20:03 --> Config Class Initialized
INFO - 2023-06-11 08:20:03 --> Hooks Class Initialized
INFO - 2023-06-11 08:20:03 --> Utf8 Class Initialized
INFO - 2023-06-11 08:20:03 --> URI Class Initialized
INFO - 2023-06-11 08:20:03 --> Router Class Initialized
INFO - 2023-06-11 08:20:03 --> Output Class Initialized
INFO - 2023-06-11 08:20:03 --> Security Class Initialized
INFO - 2023-06-11 08:20:03 --> Input Class Initialized
INFO - 2023-06-11 08:20:03 --> Language Class Initialized
INFO - 2023-06-11 08:20:03 --> Loader Class Initialized
INFO - 2023-06-11 08:20:03 --> Helper loaded: url_helper
INFO - 2023-06-11 08:20:03 --> Helper loaded: form_helper
INFO - 2023-06-11 08:20:03 --> Database Driver Class Initialized
INFO - 2023-06-11 08:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:20:03 --> Form Validation Class Initialized
INFO - 2023-06-11 08:20:03 --> Controller Class Initialized
INFO - 2023-06-11 08:20:03 --> Model "m_datatest" initialized
ERROR - 2023-06-11 08:20:03 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 111
ERROR - 2023-06-11 08:20:03 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 112
ERROR - 2023-06-11 08:20:03 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 114
INFO - 2023-06-11 08:20:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:20:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:20:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 08:20:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 08:20:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:20:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:20:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-11 08:20:03 --> Final output sent to browser
INFO - 2023-06-11 08:24:26 --> Config Class Initialized
INFO - 2023-06-11 08:24:26 --> Hooks Class Initialized
INFO - 2023-06-11 08:24:26 --> Utf8 Class Initialized
INFO - 2023-06-11 08:24:26 --> URI Class Initialized
INFO - 2023-06-11 08:24:26 --> Router Class Initialized
INFO - 2023-06-11 08:24:26 --> Output Class Initialized
INFO - 2023-06-11 08:24:26 --> Security Class Initialized
INFO - 2023-06-11 08:24:26 --> Input Class Initialized
INFO - 2023-06-11 08:24:26 --> Language Class Initialized
INFO - 2023-06-11 08:24:26 --> Loader Class Initialized
INFO - 2023-06-11 08:24:26 --> Helper loaded: url_helper
INFO - 2023-06-11 08:24:26 --> Helper loaded: form_helper
INFO - 2023-06-11 08:24:26 --> Database Driver Class Initialized
INFO - 2023-06-11 08:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:24:26 --> Form Validation Class Initialized
INFO - 2023-06-11 08:24:26 --> Controller Class Initialized
INFO - 2023-06-11 08:24:26 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:24:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:24:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:24:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 08:24:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 08:24:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:24:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:24:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-11 08:24:26 --> Final output sent to browser
INFO - 2023-06-11 08:26:28 --> Config Class Initialized
INFO - 2023-06-11 08:26:28 --> Hooks Class Initialized
INFO - 2023-06-11 08:26:28 --> Utf8 Class Initialized
INFO - 2023-06-11 08:26:28 --> URI Class Initialized
INFO - 2023-06-11 08:26:28 --> Router Class Initialized
INFO - 2023-06-11 08:26:28 --> Output Class Initialized
INFO - 2023-06-11 08:26:28 --> Security Class Initialized
INFO - 2023-06-11 08:26:28 --> Input Class Initialized
INFO - 2023-06-11 08:26:28 --> Language Class Initialized
INFO - 2023-06-11 08:26:28 --> Loader Class Initialized
INFO - 2023-06-11 08:26:28 --> Helper loaded: url_helper
INFO - 2023-06-11 08:26:28 --> Helper loaded: form_helper
INFO - 2023-06-11 08:26:28 --> Database Driver Class Initialized
INFO - 2023-06-11 08:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:26:28 --> Form Validation Class Initialized
INFO - 2023-06-11 08:26:28 --> Controller Class Initialized
INFO - 2023-06-11 08:26:28 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 08:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 08:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-11 08:26:28 --> Final output sent to browser
INFO - 2023-06-11 08:26:30 --> Config Class Initialized
INFO - 2023-06-11 08:26:30 --> Hooks Class Initialized
INFO - 2023-06-11 08:26:30 --> Utf8 Class Initialized
INFO - 2023-06-11 08:26:30 --> URI Class Initialized
INFO - 2023-06-11 08:26:30 --> Router Class Initialized
INFO - 2023-06-11 08:26:30 --> Output Class Initialized
INFO - 2023-06-11 08:26:30 --> Security Class Initialized
INFO - 2023-06-11 08:26:30 --> Input Class Initialized
INFO - 2023-06-11 08:26:30 --> Language Class Initialized
INFO - 2023-06-11 08:26:30 --> Loader Class Initialized
INFO - 2023-06-11 08:26:30 --> Helper loaded: url_helper
INFO - 2023-06-11 08:26:30 --> Helper loaded: form_helper
INFO - 2023-06-11 08:26:30 --> Database Driver Class Initialized
INFO - 2023-06-11 08:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:26:30 --> Form Validation Class Initialized
INFO - 2023-06-11 08:26:30 --> Controller Class Initialized
INFO - 2023-06-11 08:26:30 --> Model "m_user" initialized
INFO - 2023-06-11 08:26:30 --> Config Class Initialized
INFO - 2023-06-11 08:26:30 --> Hooks Class Initialized
INFO - 2023-06-11 08:26:30 --> Utf8 Class Initialized
INFO - 2023-06-11 08:26:30 --> URI Class Initialized
INFO - 2023-06-11 08:26:30 --> Router Class Initialized
INFO - 2023-06-11 08:26:30 --> Output Class Initialized
INFO - 2023-06-11 08:26:30 --> Security Class Initialized
INFO - 2023-06-11 08:26:30 --> Input Class Initialized
INFO - 2023-06-11 08:26:30 --> Language Class Initialized
INFO - 2023-06-11 08:26:30 --> Loader Class Initialized
INFO - 2023-06-11 08:26:30 --> Helper loaded: url_helper
INFO - 2023-06-11 08:26:30 --> Helper loaded: form_helper
INFO - 2023-06-11 08:26:30 --> Database Driver Class Initialized
INFO - 2023-06-11 08:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:26:30 --> Form Validation Class Initialized
INFO - 2023-06-11 08:26:30 --> Controller Class Initialized
INFO - 2023-06-11 08:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 08:26:30 --> Final output sent to browser
INFO - 2023-06-11 08:26:35 --> Config Class Initialized
INFO - 2023-06-11 08:26:35 --> Hooks Class Initialized
INFO - 2023-06-11 08:26:35 --> Utf8 Class Initialized
INFO - 2023-06-11 08:26:35 --> URI Class Initialized
INFO - 2023-06-11 08:26:35 --> Router Class Initialized
INFO - 2023-06-11 08:26:35 --> Output Class Initialized
INFO - 2023-06-11 08:26:35 --> Security Class Initialized
INFO - 2023-06-11 08:26:35 --> Input Class Initialized
INFO - 2023-06-11 08:26:35 --> Language Class Initialized
INFO - 2023-06-11 08:26:35 --> Loader Class Initialized
INFO - 2023-06-11 08:26:35 --> Helper loaded: url_helper
INFO - 2023-06-11 08:26:35 --> Helper loaded: form_helper
INFO - 2023-06-11 08:26:35 --> Database Driver Class Initialized
INFO - 2023-06-11 08:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:26:35 --> Form Validation Class Initialized
INFO - 2023-06-11 08:26:35 --> Controller Class Initialized
INFO - 2023-06-11 08:26:35 --> Model "m_datatest" initialized
ERROR - 2023-06-11 08:26:35 --> 404 Page Not Found: 
INFO - 2023-06-11 08:27:08 --> Config Class Initialized
INFO - 2023-06-11 08:27:08 --> Hooks Class Initialized
INFO - 2023-06-11 08:27:08 --> Utf8 Class Initialized
INFO - 2023-06-11 08:27:08 --> URI Class Initialized
INFO - 2023-06-11 08:27:08 --> Router Class Initialized
INFO - 2023-06-11 08:27:08 --> Output Class Initialized
INFO - 2023-06-11 08:27:08 --> Security Class Initialized
INFO - 2023-06-11 08:27:08 --> Input Class Initialized
INFO - 2023-06-11 08:27:08 --> Language Class Initialized
INFO - 2023-06-11 08:27:08 --> Loader Class Initialized
INFO - 2023-06-11 08:27:08 --> Helper loaded: url_helper
INFO - 2023-06-11 08:27:08 --> Helper loaded: form_helper
INFO - 2023-06-11 08:27:08 --> Database Driver Class Initialized
INFO - 2023-06-11 08:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:27:08 --> Form Validation Class Initialized
INFO - 2023-06-11 08:27:08 --> Controller Class Initialized
INFO - 2023-06-11 08:27:08 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:27:08 --> Config Class Initialized
INFO - 2023-06-11 08:27:08 --> Hooks Class Initialized
INFO - 2023-06-11 08:27:08 --> Utf8 Class Initialized
INFO - 2023-06-11 08:27:08 --> URI Class Initialized
INFO - 2023-06-11 08:27:08 --> Router Class Initialized
INFO - 2023-06-11 08:27:08 --> Output Class Initialized
INFO - 2023-06-11 08:27:08 --> Security Class Initialized
INFO - 2023-06-11 08:27:08 --> Input Class Initialized
INFO - 2023-06-11 08:27:08 --> Language Class Initialized
INFO - 2023-06-11 08:27:08 --> Loader Class Initialized
INFO - 2023-06-11 08:27:08 --> Helper loaded: url_helper
INFO - 2023-06-11 08:27:08 --> Helper loaded: form_helper
INFO - 2023-06-11 08:27:08 --> Database Driver Class Initialized
INFO - 2023-06-11 08:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:27:08 --> Form Validation Class Initialized
INFO - 2023-06-11 08:27:08 --> Controller Class Initialized
INFO - 2023-06-11 08:27:08 --> Model "m_user" initialized
INFO - 2023-06-11 08:27:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-11 08:27:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-11 08:27:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-11 08:27:08 --> Final output sent to browser
INFO - 2023-06-11 08:27:15 --> Config Class Initialized
INFO - 2023-06-11 08:27:15 --> Hooks Class Initialized
INFO - 2023-06-11 08:27:15 --> Utf8 Class Initialized
INFO - 2023-06-11 08:27:15 --> URI Class Initialized
INFO - 2023-06-11 08:27:15 --> Router Class Initialized
INFO - 2023-06-11 08:27:15 --> Output Class Initialized
INFO - 2023-06-11 08:27:15 --> Security Class Initialized
INFO - 2023-06-11 08:27:15 --> Input Class Initialized
INFO - 2023-06-11 08:27:15 --> Language Class Initialized
INFO - 2023-06-11 08:27:15 --> Loader Class Initialized
INFO - 2023-06-11 08:27:15 --> Helper loaded: url_helper
INFO - 2023-06-11 08:27:15 --> Helper loaded: form_helper
INFO - 2023-06-11 08:27:15 --> Database Driver Class Initialized
INFO - 2023-06-11 08:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:27:15 --> Form Validation Class Initialized
INFO - 2023-06-11 08:27:15 --> Controller Class Initialized
INFO - 2023-06-11 08:27:15 --> Model "m_user" initialized
INFO - 2023-06-11 08:27:15 --> Config Class Initialized
INFO - 2023-06-11 08:27:15 --> Hooks Class Initialized
INFO - 2023-06-11 08:27:15 --> Utf8 Class Initialized
INFO - 2023-06-11 08:27:15 --> URI Class Initialized
INFO - 2023-06-11 08:27:15 --> Router Class Initialized
INFO - 2023-06-11 08:27:15 --> Output Class Initialized
INFO - 2023-06-11 08:27:15 --> Security Class Initialized
INFO - 2023-06-11 08:27:15 --> Input Class Initialized
INFO - 2023-06-11 08:27:15 --> Language Class Initialized
INFO - 2023-06-11 08:27:15 --> Loader Class Initialized
INFO - 2023-06-11 08:27:15 --> Helper loaded: url_helper
INFO - 2023-06-11 08:27:15 --> Helper loaded: form_helper
INFO - 2023-06-11 08:27:15 --> Database Driver Class Initialized
INFO - 2023-06-11 08:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:27:15 --> Form Validation Class Initialized
INFO - 2023-06-11 08:27:15 --> Controller Class Initialized
INFO - 2023-06-11 08:27:15 --> Model "m_user" initialized
INFO - 2023-06-11 08:27:15 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:27:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:27:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:27:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:27:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:27:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:27:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 08:27:15 --> Final output sent to browser
INFO - 2023-06-11 08:27:53 --> Config Class Initialized
INFO - 2023-06-11 08:27:53 --> Hooks Class Initialized
INFO - 2023-06-11 08:27:53 --> Utf8 Class Initialized
INFO - 2023-06-11 08:27:53 --> URI Class Initialized
INFO - 2023-06-11 08:27:53 --> Router Class Initialized
INFO - 2023-06-11 08:27:53 --> Output Class Initialized
INFO - 2023-06-11 08:27:53 --> Security Class Initialized
INFO - 2023-06-11 08:27:53 --> Input Class Initialized
INFO - 2023-06-11 08:27:53 --> Language Class Initialized
INFO - 2023-06-11 08:27:53 --> Loader Class Initialized
INFO - 2023-06-11 08:27:53 --> Helper loaded: url_helper
INFO - 2023-06-11 08:27:53 --> Helper loaded: form_helper
INFO - 2023-06-11 08:27:53 --> Database Driver Class Initialized
INFO - 2023-06-11 08:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:27:53 --> Form Validation Class Initialized
INFO - 2023-06-11 08:27:53 --> Controller Class Initialized
INFO - 2023-06-11 08:27:53 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:27:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:27:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:27:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 08:27:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:27:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:27:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:27:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:27:53 --> Final output sent to browser
INFO - 2023-06-11 08:29:36 --> Config Class Initialized
INFO - 2023-06-11 08:29:36 --> Hooks Class Initialized
INFO - 2023-06-11 08:29:36 --> Utf8 Class Initialized
INFO - 2023-06-11 08:29:36 --> URI Class Initialized
INFO - 2023-06-11 08:29:36 --> Router Class Initialized
INFO - 2023-06-11 08:29:36 --> Output Class Initialized
INFO - 2023-06-11 08:29:36 --> Security Class Initialized
INFO - 2023-06-11 08:29:36 --> Input Class Initialized
INFO - 2023-06-11 08:29:36 --> Language Class Initialized
INFO - 2023-06-11 08:29:36 --> Loader Class Initialized
INFO - 2023-06-11 08:29:36 --> Helper loaded: url_helper
INFO - 2023-06-11 08:29:36 --> Helper loaded: form_helper
INFO - 2023-06-11 08:29:36 --> Database Driver Class Initialized
INFO - 2023-06-11 08:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:29:36 --> Form Validation Class Initialized
INFO - 2023-06-11 08:29:36 --> Controller Class Initialized
INFO - 2023-06-11 08:29:36 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:29:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 08:29:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:29:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:29:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 08:29:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:29:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:29:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:29:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:29:36 --> Final output sent to browser
INFO - 2023-06-11 08:29:37 --> Config Class Initialized
INFO - 2023-06-11 08:29:37 --> Hooks Class Initialized
INFO - 2023-06-11 08:29:37 --> Utf8 Class Initialized
INFO - 2023-06-11 08:29:37 --> URI Class Initialized
INFO - 2023-06-11 08:29:37 --> Router Class Initialized
INFO - 2023-06-11 08:29:37 --> Output Class Initialized
INFO - 2023-06-11 08:29:37 --> Security Class Initialized
INFO - 2023-06-11 08:29:37 --> Input Class Initialized
INFO - 2023-06-11 08:29:37 --> Language Class Initialized
INFO - 2023-06-11 08:29:37 --> Loader Class Initialized
INFO - 2023-06-11 08:29:37 --> Helper loaded: url_helper
INFO - 2023-06-11 08:29:37 --> Helper loaded: form_helper
INFO - 2023-06-11 08:29:37 --> Database Driver Class Initialized
INFO - 2023-06-11 08:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:29:37 --> Form Validation Class Initialized
INFO - 2023-06-11 08:29:37 --> Controller Class Initialized
INFO - 2023-06-11 08:29:37 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:29:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:29:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:29:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 08:29:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:29:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:29:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:29:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:29:37 --> Final output sent to browser
INFO - 2023-06-11 08:29:39 --> Config Class Initialized
INFO - 2023-06-11 08:29:39 --> Hooks Class Initialized
INFO - 2023-06-11 08:29:39 --> Utf8 Class Initialized
INFO - 2023-06-11 08:29:39 --> URI Class Initialized
INFO - 2023-06-11 08:29:39 --> Router Class Initialized
INFO - 2023-06-11 08:29:39 --> Output Class Initialized
INFO - 2023-06-11 08:29:39 --> Security Class Initialized
INFO - 2023-06-11 08:29:39 --> Input Class Initialized
INFO - 2023-06-11 08:29:39 --> Language Class Initialized
INFO - 2023-06-11 08:29:39 --> Loader Class Initialized
INFO - 2023-06-11 08:29:39 --> Helper loaded: url_helper
INFO - 2023-06-11 08:29:39 --> Helper loaded: form_helper
INFO - 2023-06-11 08:29:39 --> Database Driver Class Initialized
INFO - 2023-06-11 08:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:29:39 --> Form Validation Class Initialized
INFO - 2023-06-11 08:29:39 --> Controller Class Initialized
INFO - 2023-06-11 08:29:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:29:39 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 08:29:39 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-06-11 08:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:29:39 --> Final output sent to browser
INFO - 2023-06-11 08:29:59 --> Config Class Initialized
INFO - 2023-06-11 08:29:59 --> Hooks Class Initialized
INFO - 2023-06-11 08:29:59 --> Utf8 Class Initialized
INFO - 2023-06-11 08:29:59 --> URI Class Initialized
INFO - 2023-06-11 08:29:59 --> Router Class Initialized
INFO - 2023-06-11 08:29:59 --> Output Class Initialized
INFO - 2023-06-11 08:29:59 --> Security Class Initialized
INFO - 2023-06-11 08:29:59 --> Input Class Initialized
INFO - 2023-06-11 08:29:59 --> Language Class Initialized
INFO - 2023-06-11 08:29:59 --> Loader Class Initialized
INFO - 2023-06-11 08:29:59 --> Helper loaded: url_helper
INFO - 2023-06-11 08:29:59 --> Helper loaded: form_helper
INFO - 2023-06-11 08:29:59 --> Database Driver Class Initialized
INFO - 2023-06-11 08:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:29:59 --> Form Validation Class Initialized
INFO - 2023-06-11 08:29:59 --> Controller Class Initialized
INFO - 2023-06-11 08:29:59 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:29:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 08:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 08:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:29:59 --> Final output sent to browser
INFO - 2023-06-11 08:30:08 --> Config Class Initialized
INFO - 2023-06-11 08:30:08 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:08 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:08 --> URI Class Initialized
INFO - 2023-06-11 08:30:08 --> Router Class Initialized
INFO - 2023-06-11 08:30:08 --> Output Class Initialized
INFO - 2023-06-11 08:30:08 --> Security Class Initialized
INFO - 2023-06-11 08:30:08 --> Input Class Initialized
INFO - 2023-06-11 08:30:08 --> Language Class Initialized
INFO - 2023-06-11 08:30:08 --> Loader Class Initialized
INFO - 2023-06-11 08:30:08 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:08 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:08 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:08 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:08 --> Controller Class Initialized
INFO - 2023-06-11 08:30:08 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:30:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:30:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:30:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 08:30:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:30:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:30:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:30:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:30:08 --> Final output sent to browser
INFO - 2023-06-11 08:30:12 --> Config Class Initialized
INFO - 2023-06-11 08:30:12 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:12 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:12 --> URI Class Initialized
INFO - 2023-06-11 08:30:12 --> Router Class Initialized
INFO - 2023-06-11 08:30:12 --> Output Class Initialized
INFO - 2023-06-11 08:30:12 --> Security Class Initialized
INFO - 2023-06-11 08:30:12 --> Input Class Initialized
INFO - 2023-06-11 08:30:12 --> Language Class Initialized
INFO - 2023-06-11 08:30:12 --> Loader Class Initialized
INFO - 2023-06-11 08:30:12 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:12 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:12 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:12 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:12 --> Controller Class Initialized
INFO - 2023-06-11 08:30:12 --> Model "m_user" initialized
INFO - 2023-06-11 08:30:12 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:30:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:30:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:30:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:30:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:30:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:30:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 08:30:12 --> Final output sent to browser
INFO - 2023-06-11 08:30:13 --> Config Class Initialized
INFO - 2023-06-11 08:30:13 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:13 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:13 --> URI Class Initialized
INFO - 2023-06-11 08:30:13 --> Router Class Initialized
INFO - 2023-06-11 08:30:13 --> Output Class Initialized
INFO - 2023-06-11 08:30:13 --> Security Class Initialized
INFO - 2023-06-11 08:30:13 --> Input Class Initialized
INFO - 2023-06-11 08:30:13 --> Language Class Initialized
ERROR - 2023-06-11 08:30:14 --> 404 Page Not Found: C_todo_list/index
INFO - 2023-06-11 08:30:15 --> Config Class Initialized
INFO - 2023-06-11 08:30:15 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:15 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:15 --> URI Class Initialized
INFO - 2023-06-11 08:30:15 --> Router Class Initialized
INFO - 2023-06-11 08:30:15 --> Output Class Initialized
INFO - 2023-06-11 08:30:15 --> Security Class Initialized
INFO - 2023-06-11 08:30:15 --> Input Class Initialized
INFO - 2023-06-11 08:30:15 --> Language Class Initialized
INFO - 2023-06-11 08:30:15 --> Loader Class Initialized
INFO - 2023-06-11 08:30:15 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:15 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:15 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:15 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:15 --> Controller Class Initialized
INFO - 2023-06-11 08:30:15 --> Model "m_user" initialized
INFO - 2023-06-11 08:30:15 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:30:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:30:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:30:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:30:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:30:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:30:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 08:30:15 --> Final output sent to browser
INFO - 2023-06-11 08:30:20 --> Config Class Initialized
INFO - 2023-06-11 08:30:20 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:20 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:20 --> URI Class Initialized
INFO - 2023-06-11 08:30:20 --> Router Class Initialized
INFO - 2023-06-11 08:30:20 --> Output Class Initialized
INFO - 2023-06-11 08:30:20 --> Security Class Initialized
INFO - 2023-06-11 08:30:20 --> Input Class Initialized
INFO - 2023-06-11 08:30:20 --> Language Class Initialized
INFO - 2023-06-11 08:30:20 --> Loader Class Initialized
INFO - 2023-06-11 08:30:20 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:20 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:20 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:20 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:20 --> Controller Class Initialized
INFO - 2023-06-11 08:30:20 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:30:20 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 08:30:20 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:30:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:30:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:30:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-06-11 08:30:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:30:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:30:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:30:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:30:21 --> Final output sent to browser
INFO - 2023-06-11 08:30:42 --> Config Class Initialized
INFO - 2023-06-11 08:30:42 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:42 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:42 --> URI Class Initialized
INFO - 2023-06-11 08:30:42 --> Router Class Initialized
INFO - 2023-06-11 08:30:42 --> Output Class Initialized
INFO - 2023-06-11 08:30:42 --> Security Class Initialized
INFO - 2023-06-11 08:30:42 --> Input Class Initialized
INFO - 2023-06-11 08:30:42 --> Language Class Initialized
INFO - 2023-06-11 08:30:42 --> Loader Class Initialized
INFO - 2023-06-11 08:30:42 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:42 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:42 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:42 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:42 --> Controller Class Initialized
INFO - 2023-06-11 08:30:42 --> Model "m_user" initialized
INFO - 2023-06-11 08:30:42 --> Config Class Initialized
INFO - 2023-06-11 08:30:42 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:42 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:42 --> URI Class Initialized
INFO - 2023-06-11 08:30:42 --> Router Class Initialized
INFO - 2023-06-11 08:30:42 --> Output Class Initialized
INFO - 2023-06-11 08:30:42 --> Security Class Initialized
INFO - 2023-06-11 08:30:42 --> Input Class Initialized
INFO - 2023-06-11 08:30:42 --> Language Class Initialized
INFO - 2023-06-11 08:30:42 --> Loader Class Initialized
INFO - 2023-06-11 08:30:42 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:42 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:42 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:42 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:42 --> Controller Class Initialized
INFO - 2023-06-11 08:30:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 08:30:42 --> Final output sent to browser
INFO - 2023-06-11 08:30:44 --> Config Class Initialized
INFO - 2023-06-11 08:30:44 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:44 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:44 --> URI Class Initialized
INFO - 2023-06-11 08:30:44 --> Router Class Initialized
INFO - 2023-06-11 08:30:44 --> Output Class Initialized
INFO - 2023-06-11 08:30:44 --> Security Class Initialized
INFO - 2023-06-11 08:30:44 --> Input Class Initialized
INFO - 2023-06-11 08:30:44 --> Language Class Initialized
INFO - 2023-06-11 08:30:44 --> Loader Class Initialized
INFO - 2023-06-11 08:30:44 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:44 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:44 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:30:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:30:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 08:30:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:30:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:30:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-11 08:30:44 --> Final output sent to browser
INFO - 2023-06-11 08:30:46 --> Config Class Initialized
INFO - 2023-06-11 08:30:46 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:46 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:46 --> URI Class Initialized
INFO - 2023-06-11 08:30:46 --> Router Class Initialized
INFO - 2023-06-11 08:30:46 --> Output Class Initialized
INFO - 2023-06-11 08:30:46 --> Security Class Initialized
INFO - 2023-06-11 08:30:46 --> Input Class Initialized
INFO - 2023-06-11 08:30:46 --> Language Class Initialized
INFO - 2023-06-11 08:30:46 --> Loader Class Initialized
INFO - 2023-06-11 08:30:46 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:46 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:46 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:46 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:46 --> Controller Class Initialized
INFO - 2023-06-11 08:30:46 --> Model "m_user" initialized
INFO - 2023-06-11 08:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 08:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-11 08:30:46 --> Final output sent to browser
INFO - 2023-06-11 08:30:47 --> Config Class Initialized
INFO - 2023-06-11 08:30:47 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:47 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:47 --> URI Class Initialized
INFO - 2023-06-11 08:30:47 --> Router Class Initialized
INFO - 2023-06-11 08:30:47 --> Output Class Initialized
INFO - 2023-06-11 08:30:47 --> Security Class Initialized
INFO - 2023-06-11 08:30:47 --> Input Class Initialized
INFO - 2023-06-11 08:30:47 --> Language Class Initialized
INFO - 2023-06-11 08:30:47 --> Loader Class Initialized
INFO - 2023-06-11 08:30:47 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:47 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:47 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:47 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:47 --> Controller Class Initialized
INFO - 2023-06-11 08:30:47 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:30:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 08:30:47 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:30:47 --> Model "M_solusi" initialized
INFO - 2023-06-11 08:30:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:30:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:30:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-11 08:30:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 08:30:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:30:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:30:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-11 08:30:47 --> Final output sent to browser
INFO - 2023-06-11 08:30:49 --> Config Class Initialized
INFO - 2023-06-11 08:30:49 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:49 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:49 --> URI Class Initialized
INFO - 2023-06-11 08:30:49 --> Router Class Initialized
INFO - 2023-06-11 08:30:49 --> Output Class Initialized
INFO - 2023-06-11 08:30:49 --> Security Class Initialized
INFO - 2023-06-11 08:30:49 --> Input Class Initialized
INFO - 2023-06-11 08:30:49 --> Language Class Initialized
INFO - 2023-06-11 08:30:49 --> Loader Class Initialized
INFO - 2023-06-11 08:30:49 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:49 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:49 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:49 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:49 --> Controller Class Initialized
INFO - 2023-06-11 08:30:49 --> Model "m_user" initialized
INFO - 2023-06-11 08:30:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:30:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:30:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 08:30:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:30:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:30:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-11 08:30:49 --> Final output sent to browser
INFO - 2023-06-11 08:30:50 --> Config Class Initialized
INFO - 2023-06-11 08:30:50 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:50 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:50 --> URI Class Initialized
INFO - 2023-06-11 08:30:50 --> Router Class Initialized
INFO - 2023-06-11 08:30:50 --> Output Class Initialized
INFO - 2023-06-11 08:30:50 --> Security Class Initialized
INFO - 2023-06-11 08:30:50 --> Input Class Initialized
INFO - 2023-06-11 08:30:50 --> Language Class Initialized
INFO - 2023-06-11 08:30:50 --> Loader Class Initialized
INFO - 2023-06-11 08:30:50 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:50 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:50 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:50 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:50 --> Controller Class Initialized
INFO - 2023-06-11 08:30:50 --> Model "m_user" initialized
INFO - 2023-06-11 08:30:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:30:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:30:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 08:30:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:30:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:30:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-11 08:30:50 --> Final output sent to browser
INFO - 2023-06-11 08:30:52 --> Config Class Initialized
INFO - 2023-06-11 08:30:52 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:52 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:52 --> URI Class Initialized
INFO - 2023-06-11 08:30:52 --> Router Class Initialized
INFO - 2023-06-11 08:30:52 --> Output Class Initialized
INFO - 2023-06-11 08:30:52 --> Security Class Initialized
INFO - 2023-06-11 08:30:52 --> Input Class Initialized
INFO - 2023-06-11 08:30:52 --> Language Class Initialized
INFO - 2023-06-11 08:30:53 --> Loader Class Initialized
INFO - 2023-06-11 08:30:53 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:53 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:53 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:53 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:53 --> Controller Class Initialized
INFO - 2023-06-11 08:30:53 --> Model "m_user" initialized
INFO - 2023-06-11 08:30:53 --> Config Class Initialized
INFO - 2023-06-11 08:30:53 --> Hooks Class Initialized
INFO - 2023-06-11 08:30:53 --> Utf8 Class Initialized
INFO - 2023-06-11 08:30:53 --> URI Class Initialized
INFO - 2023-06-11 08:30:53 --> Router Class Initialized
INFO - 2023-06-11 08:30:53 --> Output Class Initialized
INFO - 2023-06-11 08:30:53 --> Security Class Initialized
INFO - 2023-06-11 08:30:53 --> Input Class Initialized
INFO - 2023-06-11 08:30:53 --> Language Class Initialized
INFO - 2023-06-11 08:30:53 --> Loader Class Initialized
INFO - 2023-06-11 08:30:53 --> Helper loaded: url_helper
INFO - 2023-06-11 08:30:53 --> Helper loaded: form_helper
INFO - 2023-06-11 08:30:53 --> Database Driver Class Initialized
INFO - 2023-06-11 08:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:30:53 --> Form Validation Class Initialized
INFO - 2023-06-11 08:30:53 --> Controller Class Initialized
INFO - 2023-06-11 08:30:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 08:30:53 --> Final output sent to browser
INFO - 2023-06-11 08:33:13 --> Config Class Initialized
INFO - 2023-06-11 08:33:13 --> Hooks Class Initialized
INFO - 2023-06-11 08:33:13 --> Utf8 Class Initialized
INFO - 2023-06-11 08:33:13 --> URI Class Initialized
INFO - 2023-06-11 08:33:13 --> Router Class Initialized
INFO - 2023-06-11 08:33:13 --> Output Class Initialized
INFO - 2023-06-11 08:33:13 --> Security Class Initialized
INFO - 2023-06-11 08:33:13 --> Input Class Initialized
INFO - 2023-06-11 08:33:13 --> Language Class Initialized
INFO - 2023-06-11 08:33:13 --> Loader Class Initialized
INFO - 2023-06-11 08:33:13 --> Helper loaded: url_helper
INFO - 2023-06-11 08:33:13 --> Helper loaded: form_helper
INFO - 2023-06-11 08:33:13 --> Database Driver Class Initialized
INFO - 2023-06-11 08:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:33:13 --> Form Validation Class Initialized
INFO - 2023-06-11 08:33:13 --> Controller Class Initialized
INFO - 2023-06-11 08:33:13 --> Model "m_user" initialized
INFO - 2023-06-11 08:33:13 --> Final output sent to browser
INFO - 2023-06-11 08:34:13 --> Config Class Initialized
INFO - 2023-06-11 08:34:13 --> Hooks Class Initialized
INFO - 2023-06-11 08:34:13 --> Utf8 Class Initialized
INFO - 2023-06-11 08:34:13 --> URI Class Initialized
INFO - 2023-06-11 08:34:13 --> Router Class Initialized
INFO - 2023-06-11 08:34:13 --> Output Class Initialized
INFO - 2023-06-11 08:34:13 --> Security Class Initialized
INFO - 2023-06-11 08:34:13 --> Input Class Initialized
INFO - 2023-06-11 08:34:13 --> Language Class Initialized
INFO - 2023-06-11 08:34:13 --> Loader Class Initialized
INFO - 2023-06-11 08:34:13 --> Helper loaded: url_helper
INFO - 2023-06-11 08:34:13 --> Helper loaded: form_helper
INFO - 2023-06-11 08:34:13 --> Database Driver Class Initialized
INFO - 2023-06-11 08:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:34:13 --> Form Validation Class Initialized
INFO - 2023-06-11 08:34:13 --> Controller Class Initialized
INFO - 2023-06-11 08:34:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 08:34:13 --> Final output sent to browser
INFO - 2023-06-11 08:34:21 --> Config Class Initialized
INFO - 2023-06-11 08:34:21 --> Hooks Class Initialized
INFO - 2023-06-11 08:34:21 --> Utf8 Class Initialized
INFO - 2023-06-11 08:34:21 --> URI Class Initialized
INFO - 2023-06-11 08:34:21 --> Router Class Initialized
INFO - 2023-06-11 08:34:21 --> Output Class Initialized
INFO - 2023-06-11 08:34:21 --> Security Class Initialized
INFO - 2023-06-11 08:34:21 --> Input Class Initialized
INFO - 2023-06-11 08:34:21 --> Language Class Initialized
INFO - 2023-06-11 08:34:21 --> Loader Class Initialized
INFO - 2023-06-11 08:34:21 --> Helper loaded: url_helper
INFO - 2023-06-11 08:34:21 --> Helper loaded: form_helper
INFO - 2023-06-11 08:34:21 --> Database Driver Class Initialized
INFO - 2023-06-11 08:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:34:21 --> Form Validation Class Initialized
INFO - 2023-06-11 08:34:21 --> Controller Class Initialized
INFO - 2023-06-11 08:34:21 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:34:21 --> Config Class Initialized
INFO - 2023-06-11 08:34:21 --> Hooks Class Initialized
INFO - 2023-06-11 08:34:21 --> Utf8 Class Initialized
INFO - 2023-06-11 08:34:21 --> URI Class Initialized
INFO - 2023-06-11 08:34:21 --> Router Class Initialized
INFO - 2023-06-11 08:34:21 --> Output Class Initialized
INFO - 2023-06-11 08:34:21 --> Security Class Initialized
INFO - 2023-06-11 08:34:21 --> Input Class Initialized
INFO - 2023-06-11 08:34:21 --> Language Class Initialized
INFO - 2023-06-11 08:34:21 --> Loader Class Initialized
INFO - 2023-06-11 08:34:21 --> Helper loaded: url_helper
INFO - 2023-06-11 08:34:21 --> Helper loaded: form_helper
INFO - 2023-06-11 08:34:21 --> Database Driver Class Initialized
INFO - 2023-06-11 08:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:34:21 --> Form Validation Class Initialized
INFO - 2023-06-11 08:34:21 --> Controller Class Initialized
INFO - 2023-06-11 08:34:21 --> Model "m_user" initialized
INFO - 2023-06-11 08:34:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-11 08:34:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-11 08:34:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-11 08:34:21 --> Final output sent to browser
INFO - 2023-06-11 08:34:25 --> Config Class Initialized
INFO - 2023-06-11 08:34:25 --> Hooks Class Initialized
INFO - 2023-06-11 08:34:25 --> Utf8 Class Initialized
INFO - 2023-06-11 08:34:25 --> URI Class Initialized
INFO - 2023-06-11 08:34:25 --> Router Class Initialized
INFO - 2023-06-11 08:34:25 --> Output Class Initialized
INFO - 2023-06-11 08:34:25 --> Security Class Initialized
INFO - 2023-06-11 08:34:25 --> Input Class Initialized
INFO - 2023-06-11 08:34:25 --> Language Class Initialized
INFO - 2023-06-11 08:34:25 --> Loader Class Initialized
INFO - 2023-06-11 08:34:25 --> Helper loaded: url_helper
INFO - 2023-06-11 08:34:25 --> Helper loaded: form_helper
INFO - 2023-06-11 08:34:25 --> Database Driver Class Initialized
INFO - 2023-06-11 08:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:34:25 --> Form Validation Class Initialized
INFO - 2023-06-11 08:34:25 --> Controller Class Initialized
INFO - 2023-06-11 08:34:25 --> Model "m_user" initialized
INFO - 2023-06-11 08:34:25 --> Config Class Initialized
INFO - 2023-06-11 08:34:25 --> Hooks Class Initialized
INFO - 2023-06-11 08:34:25 --> Utf8 Class Initialized
INFO - 2023-06-11 08:34:25 --> URI Class Initialized
INFO - 2023-06-11 08:34:25 --> Router Class Initialized
INFO - 2023-06-11 08:34:25 --> Output Class Initialized
INFO - 2023-06-11 08:34:25 --> Security Class Initialized
INFO - 2023-06-11 08:34:25 --> Input Class Initialized
INFO - 2023-06-11 08:34:25 --> Language Class Initialized
INFO - 2023-06-11 08:34:25 --> Loader Class Initialized
INFO - 2023-06-11 08:34:25 --> Helper loaded: url_helper
INFO - 2023-06-11 08:34:25 --> Helper loaded: form_helper
INFO - 2023-06-11 08:34:25 --> Database Driver Class Initialized
INFO - 2023-06-11 08:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:34:25 --> Form Validation Class Initialized
INFO - 2023-06-11 08:34:25 --> Controller Class Initialized
INFO - 2023-06-11 08:34:25 --> Model "m_user" initialized
INFO - 2023-06-11 08:34:25 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:34:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:34:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:34:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:34:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:34:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:34:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 08:34:25 --> Final output sent to browser
INFO - 2023-06-11 08:34:27 --> Config Class Initialized
INFO - 2023-06-11 08:34:27 --> Hooks Class Initialized
INFO - 2023-06-11 08:34:27 --> Utf8 Class Initialized
INFO - 2023-06-11 08:34:27 --> URI Class Initialized
INFO - 2023-06-11 08:34:27 --> Router Class Initialized
INFO - 2023-06-11 08:34:27 --> Output Class Initialized
INFO - 2023-06-11 08:34:27 --> Security Class Initialized
INFO - 2023-06-11 08:34:27 --> Input Class Initialized
INFO - 2023-06-11 08:34:27 --> Language Class Initialized
INFO - 2023-06-11 08:34:27 --> Loader Class Initialized
INFO - 2023-06-11 08:34:27 --> Helper loaded: url_helper
INFO - 2023-06-11 08:34:27 --> Helper loaded: form_helper
INFO - 2023-06-11 08:34:27 --> Database Driver Class Initialized
INFO - 2023-06-11 08:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:34:27 --> Form Validation Class Initialized
INFO - 2023-06-11 08:34:27 --> Controller Class Initialized
INFO - 2023-06-11 08:34:27 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:34:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:34:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:35:18 --> Config Class Initialized
INFO - 2023-06-11 08:35:18 --> Hooks Class Initialized
INFO - 2023-06-11 08:35:18 --> Utf8 Class Initialized
INFO - 2023-06-11 08:35:18 --> URI Class Initialized
INFO - 2023-06-11 08:35:18 --> Router Class Initialized
INFO - 2023-06-11 08:35:18 --> Output Class Initialized
INFO - 2023-06-11 08:35:18 --> Security Class Initialized
INFO - 2023-06-11 08:35:18 --> Input Class Initialized
INFO - 2023-06-11 08:35:18 --> Language Class Initialized
INFO - 2023-06-11 08:35:18 --> Loader Class Initialized
INFO - 2023-06-11 08:35:18 --> Helper loaded: url_helper
INFO - 2023-06-11 08:35:18 --> Helper loaded: form_helper
INFO - 2023-06-11 08:35:18 --> Database Driver Class Initialized
INFO - 2023-06-11 08:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:35:18 --> Form Validation Class Initialized
INFO - 2023-06-11 08:35:18 --> Controller Class Initialized
INFO - 2023-06-11 08:35:18 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:35:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:35:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:35:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 08:35:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:35:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:35:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:35:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:35:18 --> Final output sent to browser
INFO - 2023-06-11 08:35:19 --> Config Class Initialized
INFO - 2023-06-11 08:35:19 --> Hooks Class Initialized
INFO - 2023-06-11 08:35:19 --> Utf8 Class Initialized
INFO - 2023-06-11 08:35:19 --> URI Class Initialized
INFO - 2023-06-11 08:35:19 --> Router Class Initialized
INFO - 2023-06-11 08:35:19 --> Output Class Initialized
INFO - 2023-06-11 08:35:19 --> Security Class Initialized
INFO - 2023-06-11 08:35:19 --> Input Class Initialized
INFO - 2023-06-11 08:35:19 --> Language Class Initialized
INFO - 2023-06-11 08:35:19 --> Loader Class Initialized
INFO - 2023-06-11 08:35:19 --> Helper loaded: url_helper
INFO - 2023-06-11 08:35:19 --> Helper loaded: form_helper
INFO - 2023-06-11 08:35:19 --> Database Driver Class Initialized
INFO - 2023-06-11 08:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:35:19 --> Form Validation Class Initialized
INFO - 2023-06-11 08:35:19 --> Controller Class Initialized
INFO - 2023-06-11 08:35:19 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:35:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 08:35:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:35:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:35:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 08:35:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:35:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:35:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:35:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:35:19 --> Final output sent to browser
INFO - 2023-06-11 08:35:22 --> Config Class Initialized
INFO - 2023-06-11 08:35:22 --> Hooks Class Initialized
INFO - 2023-06-11 08:35:22 --> Utf8 Class Initialized
INFO - 2023-06-11 08:35:22 --> URI Class Initialized
INFO - 2023-06-11 08:35:22 --> Router Class Initialized
INFO - 2023-06-11 08:35:22 --> Output Class Initialized
INFO - 2023-06-11 08:35:22 --> Security Class Initialized
INFO - 2023-06-11 08:35:22 --> Input Class Initialized
INFO - 2023-06-11 08:35:22 --> Language Class Initialized
INFO - 2023-06-11 08:35:22 --> Loader Class Initialized
INFO - 2023-06-11 08:35:22 --> Helper loaded: url_helper
INFO - 2023-06-11 08:35:22 --> Helper loaded: form_helper
INFO - 2023-06-11 08:35:22 --> Database Driver Class Initialized
INFO - 2023-06-11 08:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:35:22 --> Form Validation Class Initialized
INFO - 2023-06-11 08:35:22 --> Controller Class Initialized
INFO - 2023-06-11 08:35:22 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:35:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 08:35:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:35:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:35:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-11 08:35:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:35:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:35:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:35:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:35:23 --> Final output sent to browser
INFO - 2023-06-11 08:35:26 --> Config Class Initialized
INFO - 2023-06-11 08:35:26 --> Hooks Class Initialized
INFO - 2023-06-11 08:35:26 --> Utf8 Class Initialized
INFO - 2023-06-11 08:35:26 --> URI Class Initialized
INFO - 2023-06-11 08:35:26 --> Router Class Initialized
INFO - 2023-06-11 08:35:26 --> Output Class Initialized
INFO - 2023-06-11 08:35:26 --> Security Class Initialized
INFO - 2023-06-11 08:35:26 --> Input Class Initialized
INFO - 2023-06-11 08:35:26 --> Language Class Initialized
INFO - 2023-06-11 08:35:26 --> Loader Class Initialized
INFO - 2023-06-11 08:35:26 --> Helper loaded: url_helper
INFO - 2023-06-11 08:35:26 --> Helper loaded: form_helper
INFO - 2023-06-11 08:35:26 --> Database Driver Class Initialized
INFO - 2023-06-11 08:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:35:26 --> Form Validation Class Initialized
INFO - 2023-06-11 08:35:26 --> Controller Class Initialized
INFO - 2023-06-11 08:35:26 --> Model "m_datatest" initialized
INFO - 2023-06-11 08:35:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:35:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:35:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 08:35:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:35:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:35:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:35:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:35:26 --> Final output sent to browser
INFO - 2023-06-11 08:35:37 --> Config Class Initialized
INFO - 2023-06-11 08:35:37 --> Hooks Class Initialized
INFO - 2023-06-11 08:35:37 --> Utf8 Class Initialized
INFO - 2023-06-11 08:35:37 --> URI Class Initialized
INFO - 2023-06-11 08:35:37 --> Router Class Initialized
INFO - 2023-06-11 08:35:37 --> Output Class Initialized
INFO - 2023-06-11 08:35:37 --> Security Class Initialized
INFO - 2023-06-11 08:35:37 --> Input Class Initialized
INFO - 2023-06-11 08:35:37 --> Language Class Initialized
INFO - 2023-06-11 08:35:37 --> Loader Class Initialized
INFO - 2023-06-11 08:35:37 --> Helper loaded: url_helper
INFO - 2023-06-11 08:35:37 --> Helper loaded: form_helper
INFO - 2023-06-11 08:35:37 --> Database Driver Class Initialized
INFO - 2023-06-11 08:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:35:37 --> Form Validation Class Initialized
INFO - 2023-06-11 08:35:37 --> Controller Class Initialized
INFO - 2023-06-11 08:35:37 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 08:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:35:37 --> Final output sent to browser
INFO - 2023-06-11 08:40:55 --> Config Class Initialized
INFO - 2023-06-11 08:40:55 --> Hooks Class Initialized
INFO - 2023-06-11 08:40:55 --> Utf8 Class Initialized
INFO - 2023-06-11 08:40:55 --> URI Class Initialized
INFO - 2023-06-11 08:40:55 --> Router Class Initialized
INFO - 2023-06-11 08:40:55 --> Output Class Initialized
INFO - 2023-06-11 08:40:55 --> Security Class Initialized
INFO - 2023-06-11 08:40:55 --> Input Class Initialized
INFO - 2023-06-11 08:40:55 --> Language Class Initialized
INFO - 2023-06-11 08:40:55 --> Loader Class Initialized
INFO - 2023-06-11 08:40:55 --> Helper loaded: url_helper
INFO - 2023-06-11 08:40:55 --> Helper loaded: form_helper
INFO - 2023-06-11 08:40:55 --> Database Driver Class Initialized
INFO - 2023-06-11 08:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:40:55 --> Form Validation Class Initialized
INFO - 2023-06-11 08:40:55 --> Controller Class Initialized
INFO - 2023-06-11 08:40:55 --> Model "m_user" initialized
INFO - 2023-06-11 08:40:56 --> Config Class Initialized
INFO - 2023-06-11 08:40:56 --> Hooks Class Initialized
INFO - 2023-06-11 08:40:56 --> Utf8 Class Initialized
INFO - 2023-06-11 08:40:56 --> URI Class Initialized
INFO - 2023-06-11 08:40:56 --> Router Class Initialized
INFO - 2023-06-11 08:40:56 --> Output Class Initialized
INFO - 2023-06-11 08:40:56 --> Security Class Initialized
INFO - 2023-06-11 08:40:56 --> Input Class Initialized
INFO - 2023-06-11 08:40:56 --> Language Class Initialized
INFO - 2023-06-11 08:40:56 --> Loader Class Initialized
INFO - 2023-06-11 08:40:56 --> Helper loaded: url_helper
INFO - 2023-06-11 08:40:56 --> Helper loaded: form_helper
INFO - 2023-06-11 08:40:56 --> Database Driver Class Initialized
INFO - 2023-06-11 08:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:40:56 --> Form Validation Class Initialized
INFO - 2023-06-11 08:40:56 --> Controller Class Initialized
INFO - 2023-06-11 08:40:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 08:40:56 --> Final output sent to browser
INFO - 2023-06-11 08:40:57 --> Config Class Initialized
INFO - 2023-06-11 08:40:57 --> Hooks Class Initialized
INFO - 2023-06-11 08:40:57 --> Utf8 Class Initialized
INFO - 2023-06-11 08:40:57 --> URI Class Initialized
INFO - 2023-06-11 08:40:57 --> Router Class Initialized
INFO - 2023-06-11 08:40:57 --> Output Class Initialized
INFO - 2023-06-11 08:40:57 --> Security Class Initialized
INFO - 2023-06-11 08:40:57 --> Input Class Initialized
INFO - 2023-06-11 08:40:57 --> Language Class Initialized
INFO - 2023-06-11 08:40:57 --> Loader Class Initialized
INFO - 2023-06-11 08:40:57 --> Helper loaded: url_helper
INFO - 2023-06-11 08:40:57 --> Helper loaded: form_helper
INFO - 2023-06-11 08:40:57 --> Database Driver Class Initialized
INFO - 2023-06-11 08:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:40:57 --> Form Validation Class Initialized
INFO - 2023-06-11 08:40:57 --> Controller Class Initialized
INFO - 2023-06-11 08:40:57 --> Model "m_user" initialized
INFO - 2023-06-11 08:40:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:40:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:40:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 08:40:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:40:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:40:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-11 08:40:57 --> Final output sent to browser
INFO - 2023-06-11 08:45:49 --> Config Class Initialized
INFO - 2023-06-11 08:45:49 --> Hooks Class Initialized
INFO - 2023-06-11 08:45:49 --> Utf8 Class Initialized
INFO - 2023-06-11 08:45:49 --> URI Class Initialized
INFO - 2023-06-11 08:45:49 --> Router Class Initialized
INFO - 2023-06-11 08:45:49 --> Output Class Initialized
INFO - 2023-06-11 08:45:49 --> Security Class Initialized
INFO - 2023-06-11 08:45:49 --> Input Class Initialized
INFO - 2023-06-11 08:45:49 --> Language Class Initialized
INFO - 2023-06-11 08:45:49 --> Loader Class Initialized
INFO - 2023-06-11 08:45:49 --> Helper loaded: url_helper
INFO - 2023-06-11 08:45:49 --> Helper loaded: form_helper
INFO - 2023-06-11 08:45:49 --> Database Driver Class Initialized
INFO - 2023-06-11 08:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:45:49 --> Form Validation Class Initialized
INFO - 2023-06-11 08:45:49 --> Controller Class Initialized
INFO - 2023-06-11 08:45:49 --> Model "m_user" initialized
INFO - 2023-06-11 08:45:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:45:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:45:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 08:45:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:45:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:45:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-11 08:45:49 --> Final output sent to browser
INFO - 2023-06-11 08:45:59 --> Config Class Initialized
INFO - 2023-06-11 08:45:59 --> Hooks Class Initialized
INFO - 2023-06-11 08:45:59 --> Utf8 Class Initialized
INFO - 2023-06-11 08:45:59 --> URI Class Initialized
INFO - 2023-06-11 08:45:59 --> Router Class Initialized
INFO - 2023-06-11 08:45:59 --> Output Class Initialized
INFO - 2023-06-11 08:45:59 --> Security Class Initialized
INFO - 2023-06-11 08:45:59 --> Input Class Initialized
INFO - 2023-06-11 08:45:59 --> Language Class Initialized
INFO - 2023-06-11 08:45:59 --> Loader Class Initialized
INFO - 2023-06-11 08:45:59 --> Helper loaded: url_helper
INFO - 2023-06-11 08:45:59 --> Helper loaded: form_helper
INFO - 2023-06-11 08:45:59 --> Database Driver Class Initialized
INFO - 2023-06-11 08:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:45:59 --> Form Validation Class Initialized
INFO - 2023-06-11 08:45:59 --> Controller Class Initialized
INFO - 2023-06-11 08:45:59 --> Model "m_user" initialized
INFO - 2023-06-11 08:45:59 --> Config Class Initialized
INFO - 2023-06-11 08:45:59 --> Hooks Class Initialized
INFO - 2023-06-11 08:45:59 --> Utf8 Class Initialized
INFO - 2023-06-11 08:45:59 --> URI Class Initialized
INFO - 2023-06-11 08:45:59 --> Router Class Initialized
INFO - 2023-06-11 08:45:59 --> Output Class Initialized
INFO - 2023-06-11 08:45:59 --> Security Class Initialized
INFO - 2023-06-11 08:45:59 --> Input Class Initialized
INFO - 2023-06-11 08:45:59 --> Language Class Initialized
INFO - 2023-06-11 08:45:59 --> Loader Class Initialized
INFO - 2023-06-11 08:45:59 --> Helper loaded: url_helper
INFO - 2023-06-11 08:45:59 --> Helper loaded: form_helper
INFO - 2023-06-11 08:45:59 --> Database Driver Class Initialized
INFO - 2023-06-11 08:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:45:59 --> Form Validation Class Initialized
INFO - 2023-06-11 08:45:59 --> Controller Class Initialized
INFO - 2023-06-11 08:45:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 08:45:59 --> Final output sent to browser
INFO - 2023-06-11 08:46:00 --> Config Class Initialized
INFO - 2023-06-11 08:46:00 --> Hooks Class Initialized
INFO - 2023-06-11 08:46:00 --> Utf8 Class Initialized
INFO - 2023-06-11 08:46:00 --> URI Class Initialized
INFO - 2023-06-11 08:46:00 --> Router Class Initialized
INFO - 2023-06-11 08:46:00 --> Output Class Initialized
INFO - 2023-06-11 08:46:00 --> Security Class Initialized
INFO - 2023-06-11 08:46:00 --> Input Class Initialized
INFO - 2023-06-11 08:46:00 --> Language Class Initialized
INFO - 2023-06-11 08:46:00 --> Loader Class Initialized
INFO - 2023-06-11 08:46:00 --> Helper loaded: url_helper
INFO - 2023-06-11 08:46:00 --> Helper loaded: form_helper
INFO - 2023-06-11 08:46:00 --> Database Driver Class Initialized
INFO - 2023-06-11 08:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:46:00 --> Form Validation Class Initialized
INFO - 2023-06-11 08:46:00 --> Controller Class Initialized
INFO - 2023-06-11 08:46:00 --> Model "m_user" initialized
INFO - 2023-06-11 08:46:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-11 08:46:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-11 08:46:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-11 08:46:00 --> Final output sent to browser
INFO - 2023-06-11 08:46:03 --> Config Class Initialized
INFO - 2023-06-11 08:46:03 --> Hooks Class Initialized
INFO - 2023-06-11 08:46:03 --> Utf8 Class Initialized
INFO - 2023-06-11 08:46:03 --> URI Class Initialized
INFO - 2023-06-11 08:46:03 --> Router Class Initialized
INFO - 2023-06-11 08:46:03 --> Output Class Initialized
INFO - 2023-06-11 08:46:03 --> Security Class Initialized
INFO - 2023-06-11 08:46:03 --> Input Class Initialized
INFO - 2023-06-11 08:46:03 --> Language Class Initialized
INFO - 2023-06-11 08:46:03 --> Loader Class Initialized
INFO - 2023-06-11 08:46:03 --> Helper loaded: url_helper
INFO - 2023-06-11 08:46:03 --> Helper loaded: form_helper
INFO - 2023-06-11 08:46:03 --> Database Driver Class Initialized
INFO - 2023-06-11 08:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:46:03 --> Form Validation Class Initialized
INFO - 2023-06-11 08:46:03 --> Controller Class Initialized
INFO - 2023-06-11 08:46:03 --> Model "m_user" initialized
INFO - 2023-06-11 08:46:03 --> Config Class Initialized
INFO - 2023-06-11 08:46:03 --> Hooks Class Initialized
INFO - 2023-06-11 08:46:03 --> Utf8 Class Initialized
INFO - 2023-06-11 08:46:03 --> URI Class Initialized
INFO - 2023-06-11 08:46:03 --> Router Class Initialized
INFO - 2023-06-11 08:46:03 --> Output Class Initialized
INFO - 2023-06-11 08:46:03 --> Security Class Initialized
INFO - 2023-06-11 08:46:03 --> Input Class Initialized
INFO - 2023-06-11 08:46:03 --> Language Class Initialized
INFO - 2023-06-11 08:46:03 --> Loader Class Initialized
INFO - 2023-06-11 08:46:03 --> Helper loaded: url_helper
INFO - 2023-06-11 08:46:03 --> Helper loaded: form_helper
INFO - 2023-06-11 08:46:03 --> Database Driver Class Initialized
INFO - 2023-06-11 08:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:46:03 --> Form Validation Class Initialized
INFO - 2023-06-11 08:46:03 --> Controller Class Initialized
INFO - 2023-06-11 08:46:03 --> Model "m_user" initialized
INFO - 2023-06-11 08:46:03 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:46:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:46:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:46:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:46:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:46:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:46:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 08:46:03 --> Final output sent to browser
INFO - 2023-06-11 08:51:49 --> Config Class Initialized
INFO - 2023-06-11 08:51:49 --> Hooks Class Initialized
INFO - 2023-06-11 08:51:49 --> Utf8 Class Initialized
INFO - 2023-06-11 08:51:49 --> URI Class Initialized
INFO - 2023-06-11 08:51:49 --> Router Class Initialized
INFO - 2023-06-11 08:51:49 --> Output Class Initialized
INFO - 2023-06-11 08:51:49 --> Security Class Initialized
INFO - 2023-06-11 08:51:49 --> Input Class Initialized
INFO - 2023-06-11 08:51:49 --> Language Class Initialized
INFO - 2023-06-11 08:51:49 --> Loader Class Initialized
INFO - 2023-06-11 08:51:49 --> Helper loaded: url_helper
INFO - 2023-06-11 08:51:49 --> Helper loaded: form_helper
INFO - 2023-06-11 08:51:49 --> Database Driver Class Initialized
INFO - 2023-06-11 08:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:51:49 --> Form Validation Class Initialized
INFO - 2023-06-11 08:51:49 --> Controller Class Initialized
INFO - 2023-06-11 08:51:49 --> Model "m_user" initialized
INFO - 2023-06-11 08:51:49 --> Model "m_datatrain" initialized
INFO - 2023-06-11 08:51:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:51:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:51:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:51:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:51:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:51:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 08:51:49 --> Final output sent to browser
INFO - 2023-06-11 08:51:52 --> Config Class Initialized
INFO - 2023-06-11 08:51:52 --> Hooks Class Initialized
INFO - 2023-06-11 08:51:52 --> Utf8 Class Initialized
INFO - 2023-06-11 08:51:52 --> URI Class Initialized
INFO - 2023-06-11 08:51:52 --> Router Class Initialized
INFO - 2023-06-11 08:51:52 --> Output Class Initialized
INFO - 2023-06-11 08:51:52 --> Security Class Initialized
INFO - 2023-06-11 08:51:52 --> Input Class Initialized
INFO - 2023-06-11 08:51:52 --> Language Class Initialized
INFO - 2023-06-11 08:51:52 --> Loader Class Initialized
INFO - 2023-06-11 08:51:52 --> Helper loaded: url_helper
INFO - 2023-06-11 08:51:52 --> Helper loaded: form_helper
INFO - 2023-06-11 08:51:52 --> Database Driver Class Initialized
INFO - 2023-06-11 08:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:51:52 --> Form Validation Class Initialized
INFO - 2023-06-11 08:51:52 --> Controller Class Initialized
INFO - 2023-06-11 08:51:52 --> Model "m_user" initialized
INFO - 2023-06-11 08:51:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:51:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:51:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 08:51:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:51:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:51:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:51:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:51:52 --> Final output sent to browser
INFO - 2023-06-11 08:52:01 --> Config Class Initialized
INFO - 2023-06-11 08:52:01 --> Hooks Class Initialized
INFO - 2023-06-11 08:52:01 --> Utf8 Class Initialized
INFO - 2023-06-11 08:52:01 --> URI Class Initialized
INFO - 2023-06-11 08:52:01 --> Router Class Initialized
INFO - 2023-06-11 08:52:01 --> Output Class Initialized
INFO - 2023-06-11 08:52:01 --> Security Class Initialized
INFO - 2023-06-11 08:52:01 --> Input Class Initialized
INFO - 2023-06-11 08:52:01 --> Language Class Initialized
ERROR - 2023-06-11 08:52:01 --> 404 Page Not Found: C_admin/hapus
INFO - 2023-06-11 08:52:03 --> Config Class Initialized
INFO - 2023-06-11 08:52:03 --> Hooks Class Initialized
INFO - 2023-06-11 08:52:03 --> Utf8 Class Initialized
INFO - 2023-06-11 08:52:03 --> URI Class Initialized
INFO - 2023-06-11 08:52:03 --> Router Class Initialized
INFO - 2023-06-11 08:52:03 --> Output Class Initialized
INFO - 2023-06-11 08:52:03 --> Security Class Initialized
INFO - 2023-06-11 08:52:03 --> Input Class Initialized
INFO - 2023-06-11 08:52:03 --> Language Class Initialized
INFO - 2023-06-11 08:52:03 --> Loader Class Initialized
INFO - 2023-06-11 08:52:03 --> Helper loaded: url_helper
INFO - 2023-06-11 08:52:03 --> Helper loaded: form_helper
INFO - 2023-06-11 08:52:03 --> Database Driver Class Initialized
INFO - 2023-06-11 08:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:52:03 --> Form Validation Class Initialized
INFO - 2023-06-11 08:52:03 --> Controller Class Initialized
INFO - 2023-06-11 08:52:03 --> Model "m_user" initialized
INFO - 2023-06-11 08:52:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:52:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:52:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 08:52:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:52:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:52:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:52:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:52:03 --> Final output sent to browser
INFO - 2023-06-11 08:53:28 --> Config Class Initialized
INFO - 2023-06-11 08:53:28 --> Hooks Class Initialized
INFO - 2023-06-11 08:53:28 --> Utf8 Class Initialized
INFO - 2023-06-11 08:53:28 --> URI Class Initialized
INFO - 2023-06-11 08:53:28 --> Router Class Initialized
INFO - 2023-06-11 08:53:28 --> Output Class Initialized
INFO - 2023-06-11 08:53:28 --> Security Class Initialized
INFO - 2023-06-11 08:53:28 --> Input Class Initialized
INFO - 2023-06-11 08:53:28 --> Language Class Initialized
INFO - 2023-06-11 08:53:28 --> Loader Class Initialized
INFO - 2023-06-11 08:53:28 --> Helper loaded: url_helper
INFO - 2023-06-11 08:53:28 --> Helper loaded: form_helper
INFO - 2023-06-11 08:53:28 --> Database Driver Class Initialized
INFO - 2023-06-11 08:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:53:28 --> Form Validation Class Initialized
INFO - 2023-06-11 08:53:28 --> Controller Class Initialized
INFO - 2023-06-11 08:53:28 --> Model "m_user" initialized
INFO - 2023-06-11 08:53:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:53:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:53:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 08:53:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:53:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:53:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:53:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:53:28 --> Final output sent to browser
INFO - 2023-06-11 08:53:30 --> Config Class Initialized
INFO - 2023-06-11 08:53:30 --> Hooks Class Initialized
INFO - 2023-06-11 08:53:30 --> Utf8 Class Initialized
INFO - 2023-06-11 08:53:30 --> URI Class Initialized
INFO - 2023-06-11 08:53:30 --> Router Class Initialized
INFO - 2023-06-11 08:53:30 --> Output Class Initialized
INFO - 2023-06-11 08:53:30 --> Security Class Initialized
INFO - 2023-06-11 08:53:30 --> Input Class Initialized
INFO - 2023-06-11 08:53:30 --> Language Class Initialized
INFO - 2023-06-11 08:53:30 --> Loader Class Initialized
INFO - 2023-06-11 08:53:30 --> Helper loaded: url_helper
INFO - 2023-06-11 08:53:30 --> Helper loaded: form_helper
INFO - 2023-06-11 08:53:30 --> Database Driver Class Initialized
INFO - 2023-06-11 08:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:53:30 --> Form Validation Class Initialized
INFO - 2023-06-11 08:53:30 --> Controller Class Initialized
INFO - 2023-06-11 08:53:30 --> Model "m_user" initialized
INFO - 2023-06-11 08:53:30 --> Config Class Initialized
INFO - 2023-06-11 08:53:30 --> Hooks Class Initialized
INFO - 2023-06-11 08:53:30 --> Utf8 Class Initialized
INFO - 2023-06-11 08:53:30 --> URI Class Initialized
INFO - 2023-06-11 08:53:30 --> Router Class Initialized
INFO - 2023-06-11 08:53:30 --> Output Class Initialized
INFO - 2023-06-11 08:53:30 --> Security Class Initialized
INFO - 2023-06-11 08:53:30 --> Input Class Initialized
INFO - 2023-06-11 08:53:30 --> Language Class Initialized
INFO - 2023-06-11 08:53:30 --> Loader Class Initialized
INFO - 2023-06-11 08:53:30 --> Helper loaded: url_helper
INFO - 2023-06-11 08:53:30 --> Helper loaded: form_helper
INFO - 2023-06-11 08:53:30 --> Database Driver Class Initialized
INFO - 2023-06-11 08:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 08:53:30 --> Form Validation Class Initialized
INFO - 2023-06-11 08:53:30 --> Controller Class Initialized
INFO - 2023-06-11 08:53:30 --> Model "m_user" initialized
INFO - 2023-06-11 08:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 08:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 08:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 08:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 08:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 08:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 08:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 08:53:30 --> Final output sent to browser
INFO - 2023-06-11 09:02:08 --> Config Class Initialized
INFO - 2023-06-11 09:02:08 --> Hooks Class Initialized
INFO - 2023-06-11 09:02:08 --> Utf8 Class Initialized
INFO - 2023-06-11 09:02:08 --> URI Class Initialized
INFO - 2023-06-11 09:02:08 --> Router Class Initialized
INFO - 2023-06-11 09:02:08 --> Output Class Initialized
INFO - 2023-06-11 09:02:08 --> Security Class Initialized
INFO - 2023-06-11 09:02:08 --> Input Class Initialized
INFO - 2023-06-11 09:02:08 --> Language Class Initialized
INFO - 2023-06-11 09:02:08 --> Loader Class Initialized
INFO - 2023-06-11 09:02:08 --> Helper loaded: url_helper
INFO - 2023-06-11 09:02:09 --> Helper loaded: form_helper
INFO - 2023-06-11 09:02:09 --> Database Driver Class Initialized
INFO - 2023-06-11 09:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:02:09 --> Form Validation Class Initialized
INFO - 2023-06-11 09:02:09 --> Controller Class Initialized
INFO - 2023-06-11 09:02:09 --> Model "m_user" initialized
INFO - 2023-06-11 09:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 09:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:02:09 --> Final output sent to browser
INFO - 2023-06-11 09:02:10 --> Config Class Initialized
INFO - 2023-06-11 09:02:10 --> Hooks Class Initialized
INFO - 2023-06-11 09:02:10 --> Utf8 Class Initialized
INFO - 2023-06-11 09:02:10 --> URI Class Initialized
INFO - 2023-06-11 09:02:10 --> Router Class Initialized
INFO - 2023-06-11 09:02:10 --> Output Class Initialized
INFO - 2023-06-11 09:02:10 --> Security Class Initialized
INFO - 2023-06-11 09:02:10 --> Input Class Initialized
INFO - 2023-06-11 09:02:10 --> Language Class Initialized
INFO - 2023-06-11 09:02:10 --> Loader Class Initialized
INFO - 2023-06-11 09:02:10 --> Helper loaded: url_helper
INFO - 2023-06-11 09:02:10 --> Helper loaded: form_helper
INFO - 2023-06-11 09:02:10 --> Database Driver Class Initialized
INFO - 2023-06-11 09:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:02:10 --> Form Validation Class Initialized
INFO - 2023-06-11 09:02:10 --> Controller Class Initialized
INFO - 2023-06-11 09:02:10 --> Model "m_user" initialized
INFO - 2023-06-11 09:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:02:10 --> Final output sent to browser
INFO - 2023-06-11 09:02:25 --> Config Class Initialized
INFO - 2023-06-11 09:02:25 --> Hooks Class Initialized
INFO - 2023-06-11 09:02:25 --> Utf8 Class Initialized
INFO - 2023-06-11 09:02:25 --> URI Class Initialized
INFO - 2023-06-11 09:02:25 --> Router Class Initialized
INFO - 2023-06-11 09:02:25 --> Output Class Initialized
INFO - 2023-06-11 09:02:25 --> Security Class Initialized
INFO - 2023-06-11 09:02:25 --> Input Class Initialized
INFO - 2023-06-11 09:02:25 --> Language Class Initialized
INFO - 2023-06-11 09:02:25 --> Loader Class Initialized
INFO - 2023-06-11 09:02:25 --> Helper loaded: url_helper
INFO - 2023-06-11 09:02:25 --> Helper loaded: form_helper
INFO - 2023-06-11 09:02:25 --> Database Driver Class Initialized
INFO - 2023-06-11 09:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:02:25 --> Form Validation Class Initialized
INFO - 2023-06-11 09:02:25 --> Controller Class Initialized
INFO - 2023-06-11 09:02:25 --> Model "m_user" initialized
ERROR - 2023-06-11 09:02:25 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 30
INFO - 2023-06-11 09:02:25 --> Config Class Initialized
INFO - 2023-06-11 09:02:25 --> Hooks Class Initialized
INFO - 2023-06-11 09:02:25 --> Utf8 Class Initialized
INFO - 2023-06-11 09:02:25 --> URI Class Initialized
INFO - 2023-06-11 09:02:25 --> Router Class Initialized
INFO - 2023-06-11 09:02:25 --> Output Class Initialized
INFO - 2023-06-11 09:02:25 --> Security Class Initialized
INFO - 2023-06-11 09:02:25 --> Input Class Initialized
INFO - 2023-06-11 09:02:25 --> Language Class Initialized
INFO - 2023-06-11 09:02:25 --> Loader Class Initialized
INFO - 2023-06-11 09:02:25 --> Helper loaded: url_helper
INFO - 2023-06-11 09:02:25 --> Helper loaded: form_helper
INFO - 2023-06-11 09:02:25 --> Database Driver Class Initialized
INFO - 2023-06-11 09:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:02:25 --> Form Validation Class Initialized
INFO - 2023-06-11 09:02:25 --> Controller Class Initialized
INFO - 2023-06-11 09:02:25 --> Model "m_user" initialized
INFO - 2023-06-11 09:02:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:02:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:02:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:02:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:02:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:02:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:02:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:02:25 --> Final output sent to browser
INFO - 2023-06-11 09:02:32 --> Config Class Initialized
INFO - 2023-06-11 09:02:32 --> Hooks Class Initialized
INFO - 2023-06-11 09:02:32 --> Utf8 Class Initialized
INFO - 2023-06-11 09:02:32 --> URI Class Initialized
INFO - 2023-06-11 09:02:32 --> Router Class Initialized
INFO - 2023-06-11 09:02:32 --> Output Class Initialized
INFO - 2023-06-11 09:02:32 --> Security Class Initialized
INFO - 2023-06-11 09:02:32 --> Input Class Initialized
INFO - 2023-06-11 09:02:32 --> Language Class Initialized
INFO - 2023-06-11 09:02:32 --> Loader Class Initialized
INFO - 2023-06-11 09:02:32 --> Helper loaded: url_helper
INFO - 2023-06-11 09:02:32 --> Helper loaded: form_helper
INFO - 2023-06-11 09:02:32 --> Database Driver Class Initialized
INFO - 2023-06-11 09:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:02:32 --> Form Validation Class Initialized
INFO - 2023-06-11 09:02:32 --> Controller Class Initialized
INFO - 2023-06-11 09:02:32 --> Model "m_user" initialized
INFO - 2023-06-11 09:02:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:02:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:02:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 09:02:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:02:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:02:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:02:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:02:32 --> Final output sent to browser
INFO - 2023-06-11 09:03:46 --> Config Class Initialized
INFO - 2023-06-11 09:03:46 --> Hooks Class Initialized
INFO - 2023-06-11 09:03:46 --> Utf8 Class Initialized
INFO - 2023-06-11 09:03:46 --> URI Class Initialized
INFO - 2023-06-11 09:03:46 --> Router Class Initialized
INFO - 2023-06-11 09:03:46 --> Output Class Initialized
INFO - 2023-06-11 09:03:46 --> Security Class Initialized
INFO - 2023-06-11 09:03:46 --> Input Class Initialized
INFO - 2023-06-11 09:03:46 --> Language Class Initialized
INFO - 2023-06-11 09:03:46 --> Loader Class Initialized
INFO - 2023-06-11 09:03:46 --> Helper loaded: url_helper
INFO - 2023-06-11 09:03:46 --> Helper loaded: form_helper
INFO - 2023-06-11 09:03:46 --> Database Driver Class Initialized
INFO - 2023-06-11 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:03:46 --> Form Validation Class Initialized
INFO - 2023-06-11 09:03:46 --> Controller Class Initialized
INFO - 2023-06-11 09:03:46 --> Model "m_user" initialized
INFO - 2023-06-11 09:03:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:03:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:03:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:03:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:03:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:03:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:03:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:03:46 --> Final output sent to browser
INFO - 2023-06-11 09:03:54 --> Config Class Initialized
INFO - 2023-06-11 09:03:54 --> Hooks Class Initialized
INFO - 2023-06-11 09:03:54 --> Utf8 Class Initialized
INFO - 2023-06-11 09:03:54 --> URI Class Initialized
INFO - 2023-06-11 09:03:54 --> Router Class Initialized
INFO - 2023-06-11 09:03:54 --> Output Class Initialized
INFO - 2023-06-11 09:03:54 --> Security Class Initialized
INFO - 2023-06-11 09:03:54 --> Input Class Initialized
INFO - 2023-06-11 09:03:54 --> Language Class Initialized
INFO - 2023-06-11 09:03:54 --> Loader Class Initialized
INFO - 2023-06-11 09:03:54 --> Helper loaded: url_helper
INFO - 2023-06-11 09:03:54 --> Helper loaded: form_helper
INFO - 2023-06-11 09:03:54 --> Database Driver Class Initialized
INFO - 2023-06-11 09:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:03:54 --> Form Validation Class Initialized
INFO - 2023-06-11 09:03:54 --> Controller Class Initialized
INFO - 2023-06-11 09:03:54 --> Model "m_user" initialized
ERROR - 2023-06-11 09:03:54 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 30
INFO - 2023-06-11 09:03:54 --> Config Class Initialized
INFO - 2023-06-11 09:03:54 --> Hooks Class Initialized
INFO - 2023-06-11 09:03:54 --> Utf8 Class Initialized
INFO - 2023-06-11 09:03:54 --> URI Class Initialized
INFO - 2023-06-11 09:03:54 --> Router Class Initialized
INFO - 2023-06-11 09:03:54 --> Output Class Initialized
INFO - 2023-06-11 09:03:54 --> Security Class Initialized
INFO - 2023-06-11 09:03:54 --> Input Class Initialized
INFO - 2023-06-11 09:03:54 --> Language Class Initialized
INFO - 2023-06-11 09:03:54 --> Loader Class Initialized
INFO - 2023-06-11 09:03:54 --> Helper loaded: url_helper
INFO - 2023-06-11 09:03:54 --> Helper loaded: form_helper
INFO - 2023-06-11 09:03:54 --> Database Driver Class Initialized
INFO - 2023-06-11 09:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:03:54 --> Form Validation Class Initialized
INFO - 2023-06-11 09:03:54 --> Controller Class Initialized
INFO - 2023-06-11 09:03:54 --> Model "m_user" initialized
INFO - 2023-06-11 09:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:03:54 --> Final output sent to browser
INFO - 2023-06-11 09:06:34 --> Config Class Initialized
INFO - 2023-06-11 09:06:34 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:34 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:34 --> URI Class Initialized
INFO - 2023-06-11 09:06:34 --> Router Class Initialized
INFO - 2023-06-11 09:06:34 --> Output Class Initialized
INFO - 2023-06-11 09:06:34 --> Security Class Initialized
INFO - 2023-06-11 09:06:34 --> Input Class Initialized
INFO - 2023-06-11 09:06:34 --> Language Class Initialized
INFO - 2023-06-11 09:06:34 --> Loader Class Initialized
INFO - 2023-06-11 09:06:34 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:34 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:34 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:34 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:34 --> Controller Class Initialized
INFO - 2023-06-11 09:06:34 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:34 --> Config Class Initialized
INFO - 2023-06-11 09:06:34 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:34 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:34 --> URI Class Initialized
INFO - 2023-06-11 09:06:34 --> Router Class Initialized
INFO - 2023-06-11 09:06:34 --> Output Class Initialized
INFO - 2023-06-11 09:06:34 --> Security Class Initialized
INFO - 2023-06-11 09:06:34 --> Input Class Initialized
INFO - 2023-06-11 09:06:34 --> Language Class Initialized
INFO - 2023-06-11 09:06:34 --> Loader Class Initialized
INFO - 2023-06-11 09:06:34 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:34 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:34 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:34 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:34 --> Controller Class Initialized
INFO - 2023-06-11 09:06:34 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:34 --> Config Class Initialized
INFO - 2023-06-11 09:06:34 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:34 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:34 --> URI Class Initialized
INFO - 2023-06-11 09:06:34 --> Router Class Initialized
INFO - 2023-06-11 09:06:34 --> Output Class Initialized
INFO - 2023-06-11 09:06:34 --> Security Class Initialized
INFO - 2023-06-11 09:06:34 --> Input Class Initialized
INFO - 2023-06-11 09:06:34 --> Language Class Initialized
INFO - 2023-06-11 09:06:34 --> Loader Class Initialized
INFO - 2023-06-11 09:06:34 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:34 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:34 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:34 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:34 --> Controller Class Initialized
INFO - 2023-06-11 09:06:34 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:34 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:34 --> Config Class Initialized
INFO - 2023-06-11 09:06:34 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:34 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:34 --> URI Class Initialized
INFO - 2023-06-11 09:06:34 --> Router Class Initialized
INFO - 2023-06-11 09:06:34 --> Output Class Initialized
INFO - 2023-06-11 09:06:34 --> Security Class Initialized
INFO - 2023-06-11 09:06:34 --> Input Class Initialized
INFO - 2023-06-11 09:06:34 --> Language Class Initialized
INFO - 2023-06-11 09:06:34 --> Loader Class Initialized
INFO - 2023-06-11 09:06:34 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:34 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:34 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:34 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:34 --> Controller Class Initialized
INFO - 2023-06-11 09:06:34 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:34 --> Config Class Initialized
INFO - 2023-06-11 09:06:34 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:34 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:34 --> URI Class Initialized
INFO - 2023-06-11 09:06:34 --> Router Class Initialized
INFO - 2023-06-11 09:06:34 --> Output Class Initialized
INFO - 2023-06-11 09:06:34 --> Security Class Initialized
INFO - 2023-06-11 09:06:34 --> Input Class Initialized
INFO - 2023-06-11 09:06:34 --> Language Class Initialized
INFO - 2023-06-11 09:06:34 --> Loader Class Initialized
INFO - 2023-06-11 09:06:34 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:34 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:34 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:34 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:34 --> Controller Class Initialized
INFO - 2023-06-11 09:06:34 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:34 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:34 --> Config Class Initialized
INFO - 2023-06-11 09:06:34 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:34 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:34 --> URI Class Initialized
INFO - 2023-06-11 09:06:34 --> Router Class Initialized
INFO - 2023-06-11 09:06:34 --> Output Class Initialized
INFO - 2023-06-11 09:06:34 --> Security Class Initialized
INFO - 2023-06-11 09:06:34 --> Input Class Initialized
INFO - 2023-06-11 09:06:34 --> Language Class Initialized
INFO - 2023-06-11 09:06:34 --> Loader Class Initialized
INFO - 2023-06-11 09:06:34 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:34 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:34 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:34 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:34 --> Controller Class Initialized
INFO - 2023-06-11 09:06:34 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:34 --> Config Class Initialized
INFO - 2023-06-11 09:06:34 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:34 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:34 --> URI Class Initialized
INFO - 2023-06-11 09:06:34 --> Router Class Initialized
INFO - 2023-06-11 09:06:34 --> Output Class Initialized
INFO - 2023-06-11 09:06:34 --> Security Class Initialized
INFO - 2023-06-11 09:06:34 --> Input Class Initialized
INFO - 2023-06-11 09:06:34 --> Language Class Initialized
INFO - 2023-06-11 09:06:34 --> Loader Class Initialized
INFO - 2023-06-11 09:06:34 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:34 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:34 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:35 --> Controller Class Initialized
INFO - 2023-06-11 09:06:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:35 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:35 --> Config Class Initialized
INFO - 2023-06-11 09:06:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:35 --> URI Class Initialized
INFO - 2023-06-11 09:06:35 --> Router Class Initialized
INFO - 2023-06-11 09:06:35 --> Output Class Initialized
INFO - 2023-06-11 09:06:35 --> Security Class Initialized
INFO - 2023-06-11 09:06:35 --> Input Class Initialized
INFO - 2023-06-11 09:06:35 --> Language Class Initialized
INFO - 2023-06-11 09:06:35 --> Loader Class Initialized
INFO - 2023-06-11 09:06:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:35 --> Controller Class Initialized
INFO - 2023-06-11 09:06:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:35 --> Config Class Initialized
INFO - 2023-06-11 09:06:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:35 --> URI Class Initialized
INFO - 2023-06-11 09:06:35 --> Router Class Initialized
INFO - 2023-06-11 09:06:35 --> Output Class Initialized
INFO - 2023-06-11 09:06:35 --> Security Class Initialized
INFO - 2023-06-11 09:06:35 --> Input Class Initialized
INFO - 2023-06-11 09:06:35 --> Language Class Initialized
INFO - 2023-06-11 09:06:35 --> Loader Class Initialized
INFO - 2023-06-11 09:06:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:35 --> Controller Class Initialized
INFO - 2023-06-11 09:06:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:35 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:35 --> Config Class Initialized
INFO - 2023-06-11 09:06:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:35 --> URI Class Initialized
INFO - 2023-06-11 09:06:35 --> Router Class Initialized
INFO - 2023-06-11 09:06:35 --> Output Class Initialized
INFO - 2023-06-11 09:06:35 --> Security Class Initialized
INFO - 2023-06-11 09:06:35 --> Input Class Initialized
INFO - 2023-06-11 09:06:35 --> Language Class Initialized
INFO - 2023-06-11 09:06:35 --> Loader Class Initialized
INFO - 2023-06-11 09:06:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:35 --> Controller Class Initialized
INFO - 2023-06-11 09:06:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:35 --> Config Class Initialized
INFO - 2023-06-11 09:06:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:35 --> URI Class Initialized
INFO - 2023-06-11 09:06:35 --> Router Class Initialized
INFO - 2023-06-11 09:06:35 --> Output Class Initialized
INFO - 2023-06-11 09:06:35 --> Security Class Initialized
INFO - 2023-06-11 09:06:35 --> Input Class Initialized
INFO - 2023-06-11 09:06:35 --> Language Class Initialized
INFO - 2023-06-11 09:06:35 --> Loader Class Initialized
INFO - 2023-06-11 09:06:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:35 --> Controller Class Initialized
INFO - 2023-06-11 09:06:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:35 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:35 --> Config Class Initialized
INFO - 2023-06-11 09:06:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:35 --> URI Class Initialized
INFO - 2023-06-11 09:06:35 --> Router Class Initialized
INFO - 2023-06-11 09:06:35 --> Output Class Initialized
INFO - 2023-06-11 09:06:35 --> Security Class Initialized
INFO - 2023-06-11 09:06:35 --> Input Class Initialized
INFO - 2023-06-11 09:06:35 --> Language Class Initialized
INFO - 2023-06-11 09:06:35 --> Loader Class Initialized
INFO - 2023-06-11 09:06:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:35 --> Controller Class Initialized
INFO - 2023-06-11 09:06:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:35 --> Config Class Initialized
INFO - 2023-06-11 09:06:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:35 --> URI Class Initialized
INFO - 2023-06-11 09:06:35 --> Router Class Initialized
INFO - 2023-06-11 09:06:35 --> Output Class Initialized
INFO - 2023-06-11 09:06:35 --> Security Class Initialized
INFO - 2023-06-11 09:06:35 --> Input Class Initialized
INFO - 2023-06-11 09:06:35 --> Language Class Initialized
INFO - 2023-06-11 09:06:35 --> Loader Class Initialized
INFO - 2023-06-11 09:06:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:35 --> Controller Class Initialized
INFO - 2023-06-11 09:06:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:35 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:35 --> Config Class Initialized
INFO - 2023-06-11 09:06:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:35 --> URI Class Initialized
INFO - 2023-06-11 09:06:35 --> Router Class Initialized
INFO - 2023-06-11 09:06:35 --> Output Class Initialized
INFO - 2023-06-11 09:06:35 --> Security Class Initialized
INFO - 2023-06-11 09:06:35 --> Input Class Initialized
INFO - 2023-06-11 09:06:35 --> Language Class Initialized
INFO - 2023-06-11 09:06:35 --> Loader Class Initialized
INFO - 2023-06-11 09:06:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:35 --> Controller Class Initialized
INFO - 2023-06-11 09:06:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:35 --> Config Class Initialized
INFO - 2023-06-11 09:06:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:35 --> URI Class Initialized
INFO - 2023-06-11 09:06:35 --> Router Class Initialized
INFO - 2023-06-11 09:06:35 --> Output Class Initialized
INFO - 2023-06-11 09:06:35 --> Security Class Initialized
INFO - 2023-06-11 09:06:35 --> Input Class Initialized
INFO - 2023-06-11 09:06:35 --> Language Class Initialized
INFO - 2023-06-11 09:06:35 --> Loader Class Initialized
INFO - 2023-06-11 09:06:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:35 --> Controller Class Initialized
INFO - 2023-06-11 09:06:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:35 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:35 --> Config Class Initialized
INFO - 2023-06-11 09:06:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:35 --> URI Class Initialized
INFO - 2023-06-11 09:06:35 --> Router Class Initialized
INFO - 2023-06-11 09:06:35 --> Output Class Initialized
INFO - 2023-06-11 09:06:35 --> Security Class Initialized
INFO - 2023-06-11 09:06:35 --> Input Class Initialized
INFO - 2023-06-11 09:06:35 --> Language Class Initialized
INFO - 2023-06-11 09:06:35 --> Loader Class Initialized
INFO - 2023-06-11 09:06:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:35 --> Controller Class Initialized
INFO - 2023-06-11 09:06:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:36 --> Config Class Initialized
INFO - 2023-06-11 09:06:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:36 --> URI Class Initialized
INFO - 2023-06-11 09:06:36 --> Router Class Initialized
INFO - 2023-06-11 09:06:36 --> Output Class Initialized
INFO - 2023-06-11 09:06:36 --> Security Class Initialized
INFO - 2023-06-11 09:06:36 --> Input Class Initialized
INFO - 2023-06-11 09:06:36 --> Language Class Initialized
INFO - 2023-06-11 09:06:36 --> Loader Class Initialized
INFO - 2023-06-11 09:06:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:36 --> Controller Class Initialized
INFO - 2023-06-11 09:06:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:36 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:36 --> Config Class Initialized
INFO - 2023-06-11 09:06:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:36 --> URI Class Initialized
INFO - 2023-06-11 09:06:36 --> Router Class Initialized
INFO - 2023-06-11 09:06:36 --> Output Class Initialized
INFO - 2023-06-11 09:06:36 --> Security Class Initialized
INFO - 2023-06-11 09:06:36 --> Input Class Initialized
INFO - 2023-06-11 09:06:36 --> Language Class Initialized
INFO - 2023-06-11 09:06:36 --> Loader Class Initialized
INFO - 2023-06-11 09:06:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:36 --> Controller Class Initialized
INFO - 2023-06-11 09:06:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:36 --> Config Class Initialized
INFO - 2023-06-11 09:06:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:36 --> URI Class Initialized
INFO - 2023-06-11 09:06:36 --> Router Class Initialized
INFO - 2023-06-11 09:06:36 --> Output Class Initialized
INFO - 2023-06-11 09:06:36 --> Security Class Initialized
INFO - 2023-06-11 09:06:36 --> Input Class Initialized
INFO - 2023-06-11 09:06:36 --> Language Class Initialized
INFO - 2023-06-11 09:06:36 --> Loader Class Initialized
INFO - 2023-06-11 09:06:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:36 --> Controller Class Initialized
INFO - 2023-06-11 09:06:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:36 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:36 --> Config Class Initialized
INFO - 2023-06-11 09:06:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:36 --> URI Class Initialized
INFO - 2023-06-11 09:06:36 --> Router Class Initialized
INFO - 2023-06-11 09:06:36 --> Output Class Initialized
INFO - 2023-06-11 09:06:36 --> Security Class Initialized
INFO - 2023-06-11 09:06:36 --> Input Class Initialized
INFO - 2023-06-11 09:06:36 --> Language Class Initialized
INFO - 2023-06-11 09:06:36 --> Loader Class Initialized
INFO - 2023-06-11 09:06:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:36 --> Controller Class Initialized
INFO - 2023-06-11 09:06:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:37 --> Config Class Initialized
INFO - 2023-06-11 09:06:37 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:37 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:37 --> URI Class Initialized
INFO - 2023-06-11 09:06:37 --> Router Class Initialized
INFO - 2023-06-11 09:06:37 --> Output Class Initialized
INFO - 2023-06-11 09:06:37 --> Security Class Initialized
INFO - 2023-06-11 09:06:37 --> Input Class Initialized
INFO - 2023-06-11 09:06:37 --> Language Class Initialized
INFO - 2023-06-11 09:06:37 --> Loader Class Initialized
INFO - 2023-06-11 09:06:37 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:37 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:37 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:37 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:37 --> Controller Class Initialized
INFO - 2023-06-11 09:06:37 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:37 --> Config Class Initialized
INFO - 2023-06-11 09:06:37 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:37 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:37 --> URI Class Initialized
INFO - 2023-06-11 09:06:37 --> Router Class Initialized
INFO - 2023-06-11 09:06:37 --> Output Class Initialized
INFO - 2023-06-11 09:06:37 --> Security Class Initialized
INFO - 2023-06-11 09:06:37 --> Input Class Initialized
INFO - 2023-06-11 09:06:37 --> Language Class Initialized
INFO - 2023-06-11 09:06:37 --> Loader Class Initialized
INFO - 2023-06-11 09:06:37 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:37 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:37 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:37 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:37 --> Controller Class Initialized
INFO - 2023-06-11 09:06:37 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:37 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:37 --> Config Class Initialized
INFO - 2023-06-11 09:06:37 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:37 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:37 --> URI Class Initialized
INFO - 2023-06-11 09:06:37 --> Router Class Initialized
INFO - 2023-06-11 09:06:37 --> Output Class Initialized
INFO - 2023-06-11 09:06:37 --> Security Class Initialized
INFO - 2023-06-11 09:06:37 --> Input Class Initialized
INFO - 2023-06-11 09:06:37 --> Language Class Initialized
INFO - 2023-06-11 09:06:37 --> Loader Class Initialized
INFO - 2023-06-11 09:06:37 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:37 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:37 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:37 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:37 --> Controller Class Initialized
INFO - 2023-06-11 09:06:37 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:37 --> Config Class Initialized
INFO - 2023-06-11 09:06:37 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:37 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:37 --> URI Class Initialized
INFO - 2023-06-11 09:06:37 --> Router Class Initialized
INFO - 2023-06-11 09:06:37 --> Output Class Initialized
INFO - 2023-06-11 09:06:37 --> Security Class Initialized
INFO - 2023-06-11 09:06:37 --> Input Class Initialized
INFO - 2023-06-11 09:06:37 --> Language Class Initialized
INFO - 2023-06-11 09:06:37 --> Loader Class Initialized
INFO - 2023-06-11 09:06:37 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:37 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:37 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:37 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:37 --> Controller Class Initialized
INFO - 2023-06-11 09:06:37 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:37 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:37 --> Config Class Initialized
INFO - 2023-06-11 09:06:37 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:37 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:37 --> URI Class Initialized
INFO - 2023-06-11 09:06:37 --> Router Class Initialized
INFO - 2023-06-11 09:06:38 --> Output Class Initialized
INFO - 2023-06-11 09:06:38 --> Security Class Initialized
INFO - 2023-06-11 09:06:38 --> Input Class Initialized
INFO - 2023-06-11 09:06:38 --> Language Class Initialized
INFO - 2023-06-11 09:06:38 --> Loader Class Initialized
INFO - 2023-06-11 09:06:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:38 --> Controller Class Initialized
INFO - 2023-06-11 09:06:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:38 --> Config Class Initialized
INFO - 2023-06-11 09:06:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:38 --> URI Class Initialized
INFO - 2023-06-11 09:06:38 --> Router Class Initialized
INFO - 2023-06-11 09:06:38 --> Output Class Initialized
INFO - 2023-06-11 09:06:38 --> Security Class Initialized
INFO - 2023-06-11 09:06:38 --> Input Class Initialized
INFO - 2023-06-11 09:06:38 --> Language Class Initialized
INFO - 2023-06-11 09:06:38 --> Loader Class Initialized
INFO - 2023-06-11 09:06:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:38 --> Controller Class Initialized
INFO - 2023-06-11 09:06:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:38 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:38 --> Config Class Initialized
INFO - 2023-06-11 09:06:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:38 --> URI Class Initialized
INFO - 2023-06-11 09:06:38 --> Router Class Initialized
INFO - 2023-06-11 09:06:38 --> Output Class Initialized
INFO - 2023-06-11 09:06:38 --> Security Class Initialized
INFO - 2023-06-11 09:06:38 --> Input Class Initialized
INFO - 2023-06-11 09:06:38 --> Language Class Initialized
INFO - 2023-06-11 09:06:38 --> Loader Class Initialized
INFO - 2023-06-11 09:06:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:38 --> Controller Class Initialized
INFO - 2023-06-11 09:06:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:38 --> Config Class Initialized
INFO - 2023-06-11 09:06:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:38 --> URI Class Initialized
INFO - 2023-06-11 09:06:38 --> Router Class Initialized
INFO - 2023-06-11 09:06:38 --> Output Class Initialized
INFO - 2023-06-11 09:06:38 --> Security Class Initialized
INFO - 2023-06-11 09:06:38 --> Input Class Initialized
INFO - 2023-06-11 09:06:38 --> Language Class Initialized
INFO - 2023-06-11 09:06:38 --> Loader Class Initialized
INFO - 2023-06-11 09:06:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:38 --> Controller Class Initialized
INFO - 2023-06-11 09:06:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:38 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:38 --> Config Class Initialized
INFO - 2023-06-11 09:06:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:38 --> URI Class Initialized
INFO - 2023-06-11 09:06:38 --> Router Class Initialized
INFO - 2023-06-11 09:06:38 --> Output Class Initialized
INFO - 2023-06-11 09:06:38 --> Security Class Initialized
INFO - 2023-06-11 09:06:38 --> Input Class Initialized
INFO - 2023-06-11 09:06:38 --> Language Class Initialized
INFO - 2023-06-11 09:06:38 --> Loader Class Initialized
INFO - 2023-06-11 09:06:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:38 --> Controller Class Initialized
INFO - 2023-06-11 09:06:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:38 --> Config Class Initialized
INFO - 2023-06-11 09:06:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:38 --> URI Class Initialized
INFO - 2023-06-11 09:06:38 --> Router Class Initialized
INFO - 2023-06-11 09:06:38 --> Output Class Initialized
INFO - 2023-06-11 09:06:38 --> Security Class Initialized
INFO - 2023-06-11 09:06:38 --> Input Class Initialized
INFO - 2023-06-11 09:06:38 --> Language Class Initialized
INFO - 2023-06-11 09:06:38 --> Loader Class Initialized
INFO - 2023-06-11 09:06:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:38 --> Controller Class Initialized
INFO - 2023-06-11 09:06:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:38 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:38 --> Config Class Initialized
INFO - 2023-06-11 09:06:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:38 --> URI Class Initialized
INFO - 2023-06-11 09:06:38 --> Router Class Initialized
INFO - 2023-06-11 09:06:38 --> Output Class Initialized
INFO - 2023-06-11 09:06:38 --> Security Class Initialized
INFO - 2023-06-11 09:06:38 --> Input Class Initialized
INFO - 2023-06-11 09:06:38 --> Language Class Initialized
INFO - 2023-06-11 09:06:38 --> Loader Class Initialized
INFO - 2023-06-11 09:06:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:38 --> Controller Class Initialized
INFO - 2023-06-11 09:06:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:38 --> Config Class Initialized
INFO - 2023-06-11 09:06:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:38 --> URI Class Initialized
INFO - 2023-06-11 09:06:38 --> Router Class Initialized
INFO - 2023-06-11 09:06:38 --> Output Class Initialized
INFO - 2023-06-11 09:06:38 --> Security Class Initialized
INFO - 2023-06-11 09:06:38 --> Input Class Initialized
INFO - 2023-06-11 09:06:38 --> Language Class Initialized
INFO - 2023-06-11 09:06:38 --> Loader Class Initialized
INFO - 2023-06-11 09:06:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:38 --> Config Class Initialized
INFO - 2023-06-11 09:06:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:38 --> Controller Class Initialized
INFO - 2023-06-11 09:06:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:38 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:38 --> URI Class Initialized
INFO - 2023-06-11 09:06:38 --> Router Class Initialized
INFO - 2023-06-11 09:06:38 --> Output Class Initialized
INFO - 2023-06-11 09:06:38 --> Security Class Initialized
INFO - 2023-06-11 09:06:38 --> Input Class Initialized
INFO - 2023-06-11 09:06:38 --> Language Class Initialized
INFO - 2023-06-11 09:06:38 --> Loader Class Initialized
INFO - 2023-06-11 09:06:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:38 --> Controller Class Initialized
INFO - 2023-06-11 09:06:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:39 --> Config Class Initialized
INFO - 2023-06-11 09:06:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:39 --> URI Class Initialized
INFO - 2023-06-11 09:06:39 --> Router Class Initialized
INFO - 2023-06-11 09:06:39 --> Output Class Initialized
INFO - 2023-06-11 09:06:39 --> Security Class Initialized
INFO - 2023-06-11 09:06:39 --> Input Class Initialized
INFO - 2023-06-11 09:06:39 --> Language Class Initialized
INFO - 2023-06-11 09:06:39 --> Loader Class Initialized
INFO - 2023-06-11 09:06:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:39 --> Controller Class Initialized
INFO - 2023-06-11 09:06:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:39 --> Config Class Initialized
INFO - 2023-06-11 09:06:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:39 --> URI Class Initialized
INFO - 2023-06-11 09:06:39 --> Router Class Initialized
INFO - 2023-06-11 09:06:39 --> Output Class Initialized
INFO - 2023-06-11 09:06:39 --> Security Class Initialized
INFO - 2023-06-11 09:06:39 --> Input Class Initialized
INFO - 2023-06-11 09:06:39 --> Language Class Initialized
INFO - 2023-06-11 09:06:39 --> Loader Class Initialized
INFO - 2023-06-11 09:06:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:39 --> Controller Class Initialized
INFO - 2023-06-11 09:06:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:39 --> Config Class Initialized
INFO - 2023-06-11 09:06:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:39 --> URI Class Initialized
INFO - 2023-06-11 09:06:39 --> Router Class Initialized
INFO - 2023-06-11 09:06:39 --> Output Class Initialized
INFO - 2023-06-11 09:06:39 --> Security Class Initialized
INFO - 2023-06-11 09:06:39 --> Input Class Initialized
INFO - 2023-06-11 09:06:39 --> Language Class Initialized
INFO - 2023-06-11 09:06:39 --> Loader Class Initialized
INFO - 2023-06-11 09:06:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:39 --> Controller Class Initialized
INFO - 2023-06-11 09:06:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:39 --> Config Class Initialized
INFO - 2023-06-11 09:06:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:39 --> URI Class Initialized
INFO - 2023-06-11 09:06:39 --> Router Class Initialized
INFO - 2023-06-11 09:06:39 --> Output Class Initialized
INFO - 2023-06-11 09:06:39 --> Security Class Initialized
INFO - 2023-06-11 09:06:39 --> Input Class Initialized
INFO - 2023-06-11 09:06:39 --> Language Class Initialized
INFO - 2023-06-11 09:06:39 --> Loader Class Initialized
INFO - 2023-06-11 09:06:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:39 --> Controller Class Initialized
INFO - 2023-06-11 09:06:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:39 --> Config Class Initialized
INFO - 2023-06-11 09:06:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:39 --> URI Class Initialized
INFO - 2023-06-11 09:06:39 --> Router Class Initialized
INFO - 2023-06-11 09:06:39 --> Output Class Initialized
INFO - 2023-06-11 09:06:39 --> Security Class Initialized
INFO - 2023-06-11 09:06:39 --> Input Class Initialized
INFO - 2023-06-11 09:06:39 --> Language Class Initialized
INFO - 2023-06-11 09:06:39 --> Loader Class Initialized
INFO - 2023-06-11 09:06:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:39 --> Controller Class Initialized
INFO - 2023-06-11 09:06:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:39 --> Config Class Initialized
INFO - 2023-06-11 09:06:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:39 --> URI Class Initialized
INFO - 2023-06-11 09:06:39 --> Router Class Initialized
INFO - 2023-06-11 09:06:39 --> Output Class Initialized
INFO - 2023-06-11 09:06:39 --> Security Class Initialized
INFO - 2023-06-11 09:06:39 --> Input Class Initialized
INFO - 2023-06-11 09:06:39 --> Language Class Initialized
INFO - 2023-06-11 09:06:39 --> Loader Class Initialized
INFO - 2023-06-11 09:06:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:39 --> Controller Class Initialized
INFO - 2023-06-11 09:06:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:39 --> Config Class Initialized
INFO - 2023-06-11 09:06:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:39 --> URI Class Initialized
INFO - 2023-06-11 09:06:39 --> Router Class Initialized
INFO - 2023-06-11 09:06:39 --> Output Class Initialized
INFO - 2023-06-11 09:06:39 --> Security Class Initialized
INFO - 2023-06-11 09:06:39 --> Input Class Initialized
INFO - 2023-06-11 09:06:39 --> Language Class Initialized
INFO - 2023-06-11 09:06:39 --> Loader Class Initialized
INFO - 2023-06-11 09:06:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:39 --> Controller Class Initialized
INFO - 2023-06-11 09:06:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:39 --> Config Class Initialized
INFO - 2023-06-11 09:06:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:39 --> URI Class Initialized
INFO - 2023-06-11 09:06:39 --> Router Class Initialized
INFO - 2023-06-11 09:06:39 --> Output Class Initialized
INFO - 2023-06-11 09:06:39 --> Security Class Initialized
INFO - 2023-06-11 09:06:39 --> Input Class Initialized
INFO - 2023-06-11 09:06:39 --> Language Class Initialized
INFO - 2023-06-11 09:06:39 --> Loader Class Initialized
INFO - 2023-06-11 09:06:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:39 --> Controller Class Initialized
INFO - 2023-06-11 09:06:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:39 --> Config Class Initialized
INFO - 2023-06-11 09:06:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:39 --> URI Class Initialized
INFO - 2023-06-11 09:06:39 --> Router Class Initialized
INFO - 2023-06-11 09:06:39 --> Output Class Initialized
INFO - 2023-06-11 09:06:39 --> Security Class Initialized
INFO - 2023-06-11 09:06:39 --> Input Class Initialized
INFO - 2023-06-11 09:06:39 --> Language Class Initialized
INFO - 2023-06-11 09:06:39 --> Loader Class Initialized
INFO - 2023-06-11 09:06:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:39 --> Controller Class Initialized
INFO - 2023-06-11 09:06:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:39 --> Config Class Initialized
INFO - 2023-06-11 09:06:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:39 --> URI Class Initialized
INFO - 2023-06-11 09:06:40 --> Router Class Initialized
INFO - 2023-06-11 09:06:40 --> Output Class Initialized
INFO - 2023-06-11 09:06:40 --> Security Class Initialized
INFO - 2023-06-11 09:06:40 --> Input Class Initialized
INFO - 2023-06-11 09:06:40 --> Language Class Initialized
INFO - 2023-06-11 09:06:40 --> Loader Class Initialized
INFO - 2023-06-11 09:06:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:40 --> Controller Class Initialized
INFO - 2023-06-11 09:06:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:40 --> Config Class Initialized
INFO - 2023-06-11 09:06:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:40 --> URI Class Initialized
INFO - 2023-06-11 09:06:40 --> Router Class Initialized
INFO - 2023-06-11 09:06:40 --> Output Class Initialized
INFO - 2023-06-11 09:06:40 --> Security Class Initialized
INFO - 2023-06-11 09:06:40 --> Input Class Initialized
INFO - 2023-06-11 09:06:40 --> Language Class Initialized
INFO - 2023-06-11 09:06:40 --> Loader Class Initialized
INFO - 2023-06-11 09:06:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:40 --> Controller Class Initialized
INFO - 2023-06-11 09:06:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:40 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:40 --> Config Class Initialized
INFO - 2023-06-11 09:06:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:40 --> URI Class Initialized
INFO - 2023-06-11 09:06:40 --> Router Class Initialized
INFO - 2023-06-11 09:06:40 --> Output Class Initialized
INFO - 2023-06-11 09:06:40 --> Security Class Initialized
INFO - 2023-06-11 09:06:40 --> Input Class Initialized
INFO - 2023-06-11 09:06:40 --> Language Class Initialized
INFO - 2023-06-11 09:06:40 --> Loader Class Initialized
INFO - 2023-06-11 09:06:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:40 --> Controller Class Initialized
INFO - 2023-06-11 09:06:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:40 --> Config Class Initialized
INFO - 2023-06-11 09:06:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:40 --> URI Class Initialized
INFO - 2023-06-11 09:06:40 --> Router Class Initialized
INFO - 2023-06-11 09:06:40 --> Output Class Initialized
INFO - 2023-06-11 09:06:40 --> Security Class Initialized
INFO - 2023-06-11 09:06:40 --> Input Class Initialized
INFO - 2023-06-11 09:06:40 --> Language Class Initialized
INFO - 2023-06-11 09:06:40 --> Loader Class Initialized
INFO - 2023-06-11 09:06:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:40 --> Controller Class Initialized
INFO - 2023-06-11 09:06:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:40 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:40 --> Config Class Initialized
INFO - 2023-06-11 09:06:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:40 --> URI Class Initialized
INFO - 2023-06-11 09:06:40 --> Router Class Initialized
INFO - 2023-06-11 09:06:40 --> Output Class Initialized
INFO - 2023-06-11 09:06:40 --> Security Class Initialized
INFO - 2023-06-11 09:06:40 --> Input Class Initialized
INFO - 2023-06-11 09:06:40 --> Language Class Initialized
INFO - 2023-06-11 09:06:40 --> Loader Class Initialized
INFO - 2023-06-11 09:06:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:40 --> Controller Class Initialized
INFO - 2023-06-11 09:06:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:40 --> Config Class Initialized
INFO - 2023-06-11 09:06:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:40 --> URI Class Initialized
INFO - 2023-06-11 09:06:40 --> Router Class Initialized
INFO - 2023-06-11 09:06:40 --> Output Class Initialized
INFO - 2023-06-11 09:06:40 --> Security Class Initialized
INFO - 2023-06-11 09:06:40 --> Input Class Initialized
INFO - 2023-06-11 09:06:40 --> Language Class Initialized
INFO - 2023-06-11 09:06:40 --> Loader Class Initialized
INFO - 2023-06-11 09:06:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:40 --> Controller Class Initialized
INFO - 2023-06-11 09:06:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:40 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:40 --> Config Class Initialized
INFO - 2023-06-11 09:06:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:40 --> URI Class Initialized
INFO - 2023-06-11 09:06:40 --> Router Class Initialized
INFO - 2023-06-11 09:06:40 --> Output Class Initialized
INFO - 2023-06-11 09:06:40 --> Security Class Initialized
INFO - 2023-06-11 09:06:40 --> Input Class Initialized
INFO - 2023-06-11 09:06:40 --> Language Class Initialized
INFO - 2023-06-11 09:06:40 --> Loader Class Initialized
INFO - 2023-06-11 09:06:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:40 --> Controller Class Initialized
INFO - 2023-06-11 09:06:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:40 --> Config Class Initialized
INFO - 2023-06-11 09:06:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:40 --> URI Class Initialized
INFO - 2023-06-11 09:06:40 --> Router Class Initialized
INFO - 2023-06-11 09:06:40 --> Output Class Initialized
INFO - 2023-06-11 09:06:40 --> Security Class Initialized
INFO - 2023-06-11 09:06:40 --> Input Class Initialized
INFO - 2023-06-11 09:06:40 --> Language Class Initialized
INFO - 2023-06-11 09:06:40 --> Loader Class Initialized
INFO - 2023-06-11 09:06:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:40 --> Controller Class Initialized
INFO - 2023-06-11 09:06:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:40 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:40 --> Config Class Initialized
INFO - 2023-06-11 09:06:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:40 --> URI Class Initialized
INFO - 2023-06-11 09:06:40 --> Router Class Initialized
INFO - 2023-06-11 09:06:40 --> Output Class Initialized
INFO - 2023-06-11 09:06:40 --> Security Class Initialized
INFO - 2023-06-11 09:06:40 --> Input Class Initialized
INFO - 2023-06-11 09:06:40 --> Language Class Initialized
INFO - 2023-06-11 09:06:40 --> Loader Class Initialized
INFO - 2023-06-11 09:06:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:40 --> Controller Class Initialized
INFO - 2023-06-11 09:06:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:41 --> Config Class Initialized
INFO - 2023-06-11 09:06:41 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:41 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:41 --> URI Class Initialized
INFO - 2023-06-11 09:06:41 --> Router Class Initialized
INFO - 2023-06-11 09:06:41 --> Output Class Initialized
INFO - 2023-06-11 09:06:41 --> Security Class Initialized
INFO - 2023-06-11 09:06:41 --> Input Class Initialized
INFO - 2023-06-11 09:06:41 --> Language Class Initialized
INFO - 2023-06-11 09:06:41 --> Loader Class Initialized
INFO - 2023-06-11 09:06:41 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:41 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:41 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:41 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:41 --> Controller Class Initialized
INFO - 2023-06-11 09:06:41 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:41 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:46 --> Config Class Initialized
INFO - 2023-06-11 09:06:46 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:46 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:46 --> URI Class Initialized
INFO - 2023-06-11 09:06:46 --> Router Class Initialized
INFO - 2023-06-11 09:06:46 --> Output Class Initialized
INFO - 2023-06-11 09:06:46 --> Security Class Initialized
INFO - 2023-06-11 09:06:46 --> Input Class Initialized
INFO - 2023-06-11 09:06:46 --> Language Class Initialized
INFO - 2023-06-11 09:06:46 --> Loader Class Initialized
INFO - 2023-06-11 09:06:46 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:46 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:46 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:46 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:46 --> Controller Class Initialized
INFO - 2023-06-11 09:06:46 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:46 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:46 --> Config Class Initialized
INFO - 2023-06-11 09:06:46 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:46 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:46 --> URI Class Initialized
INFO - 2023-06-11 09:06:46 --> Router Class Initialized
INFO - 2023-06-11 09:06:46 --> Output Class Initialized
INFO - 2023-06-11 09:06:46 --> Security Class Initialized
INFO - 2023-06-11 09:06:46 --> Input Class Initialized
INFO - 2023-06-11 09:06:46 --> Language Class Initialized
INFO - 2023-06-11 09:06:46 --> Loader Class Initialized
INFO - 2023-06-11 09:06:46 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:46 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:46 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:46 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:46 --> Controller Class Initialized
INFO - 2023-06-11 09:06:46 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:46 --> Config Class Initialized
INFO - 2023-06-11 09:06:46 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:46 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:46 --> URI Class Initialized
INFO - 2023-06-11 09:06:46 --> Router Class Initialized
INFO - 2023-06-11 09:06:46 --> Output Class Initialized
INFO - 2023-06-11 09:06:46 --> Security Class Initialized
INFO - 2023-06-11 09:06:46 --> Input Class Initialized
INFO - 2023-06-11 09:06:46 --> Language Class Initialized
INFO - 2023-06-11 09:06:46 --> Loader Class Initialized
INFO - 2023-06-11 09:06:46 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:46 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:46 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:46 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:46 --> Controller Class Initialized
INFO - 2023-06-11 09:06:46 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:46 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:46 --> Config Class Initialized
INFO - 2023-06-11 09:06:46 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:46 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:46 --> URI Class Initialized
INFO - 2023-06-11 09:06:46 --> Router Class Initialized
INFO - 2023-06-11 09:06:46 --> Output Class Initialized
INFO - 2023-06-11 09:06:46 --> Security Class Initialized
INFO - 2023-06-11 09:06:46 --> Input Class Initialized
INFO - 2023-06-11 09:06:46 --> Language Class Initialized
INFO - 2023-06-11 09:06:46 --> Loader Class Initialized
INFO - 2023-06-11 09:06:46 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:46 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:46 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:46 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:46 --> Controller Class Initialized
INFO - 2023-06-11 09:06:46 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:46 --> Config Class Initialized
INFO - 2023-06-11 09:06:46 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:46 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:46 --> URI Class Initialized
INFO - 2023-06-11 09:06:46 --> Router Class Initialized
INFO - 2023-06-11 09:06:46 --> Output Class Initialized
INFO - 2023-06-11 09:06:46 --> Security Class Initialized
INFO - 2023-06-11 09:06:46 --> Input Class Initialized
INFO - 2023-06-11 09:06:46 --> Language Class Initialized
INFO - 2023-06-11 09:06:46 --> Loader Class Initialized
INFO - 2023-06-11 09:06:46 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:46 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:46 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:46 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:46 --> Controller Class Initialized
INFO - 2023-06-11 09:06:46 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:46 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:46 --> Config Class Initialized
INFO - 2023-06-11 09:06:46 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:46 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:46 --> URI Class Initialized
INFO - 2023-06-11 09:06:46 --> Router Class Initialized
INFO - 2023-06-11 09:06:46 --> Output Class Initialized
INFO - 2023-06-11 09:06:46 --> Security Class Initialized
INFO - 2023-06-11 09:06:46 --> Input Class Initialized
INFO - 2023-06-11 09:06:46 --> Language Class Initialized
INFO - 2023-06-11 09:06:46 --> Loader Class Initialized
INFO - 2023-06-11 09:06:46 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:46 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:46 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:46 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:46 --> Controller Class Initialized
INFO - 2023-06-11 09:06:46 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:46 --> Config Class Initialized
INFO - 2023-06-11 09:06:46 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:46 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:46 --> URI Class Initialized
INFO - 2023-06-11 09:06:46 --> Router Class Initialized
INFO - 2023-06-11 09:06:46 --> Output Class Initialized
INFO - 2023-06-11 09:06:46 --> Security Class Initialized
INFO - 2023-06-11 09:06:46 --> Input Class Initialized
INFO - 2023-06-11 09:06:46 --> Language Class Initialized
INFO - 2023-06-11 09:06:46 --> Loader Class Initialized
INFO - 2023-06-11 09:06:46 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:46 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:46 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:46 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:46 --> Controller Class Initialized
INFO - 2023-06-11 09:06:46 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:46 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:47 --> Config Class Initialized
INFO - 2023-06-11 09:06:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:47 --> URI Class Initialized
INFO - 2023-06-11 09:06:47 --> Router Class Initialized
INFO - 2023-06-11 09:06:47 --> Output Class Initialized
INFO - 2023-06-11 09:06:47 --> Security Class Initialized
INFO - 2023-06-11 09:06:47 --> Input Class Initialized
INFO - 2023-06-11 09:06:47 --> Language Class Initialized
INFO - 2023-06-11 09:06:47 --> Loader Class Initialized
INFO - 2023-06-11 09:06:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:47 --> Controller Class Initialized
INFO - 2023-06-11 09:06:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:47 --> Config Class Initialized
INFO - 2023-06-11 09:06:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:47 --> URI Class Initialized
INFO - 2023-06-11 09:06:47 --> Router Class Initialized
INFO - 2023-06-11 09:06:47 --> Output Class Initialized
INFO - 2023-06-11 09:06:47 --> Security Class Initialized
INFO - 2023-06-11 09:06:47 --> Input Class Initialized
INFO - 2023-06-11 09:06:47 --> Language Class Initialized
INFO - 2023-06-11 09:06:47 --> Loader Class Initialized
INFO - 2023-06-11 09:06:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:47 --> Controller Class Initialized
INFO - 2023-06-11 09:06:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:47 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:47 --> Config Class Initialized
INFO - 2023-06-11 09:06:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:47 --> URI Class Initialized
INFO - 2023-06-11 09:06:47 --> Router Class Initialized
INFO - 2023-06-11 09:06:47 --> Output Class Initialized
INFO - 2023-06-11 09:06:47 --> Security Class Initialized
INFO - 2023-06-11 09:06:47 --> Input Class Initialized
INFO - 2023-06-11 09:06:47 --> Language Class Initialized
INFO - 2023-06-11 09:06:47 --> Loader Class Initialized
INFO - 2023-06-11 09:06:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:47 --> Controller Class Initialized
INFO - 2023-06-11 09:06:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:47 --> Config Class Initialized
INFO - 2023-06-11 09:06:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:47 --> URI Class Initialized
INFO - 2023-06-11 09:06:47 --> Router Class Initialized
INFO - 2023-06-11 09:06:47 --> Output Class Initialized
INFO - 2023-06-11 09:06:47 --> Security Class Initialized
INFO - 2023-06-11 09:06:47 --> Input Class Initialized
INFO - 2023-06-11 09:06:47 --> Language Class Initialized
INFO - 2023-06-11 09:06:47 --> Loader Class Initialized
INFO - 2023-06-11 09:06:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:47 --> Controller Class Initialized
INFO - 2023-06-11 09:06:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:47 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:47 --> Config Class Initialized
INFO - 2023-06-11 09:06:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:47 --> URI Class Initialized
INFO - 2023-06-11 09:06:47 --> Router Class Initialized
INFO - 2023-06-11 09:06:47 --> Output Class Initialized
INFO - 2023-06-11 09:06:47 --> Security Class Initialized
INFO - 2023-06-11 09:06:47 --> Input Class Initialized
INFO - 2023-06-11 09:06:47 --> Language Class Initialized
INFO - 2023-06-11 09:06:47 --> Loader Class Initialized
INFO - 2023-06-11 09:06:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:47 --> Controller Class Initialized
INFO - 2023-06-11 09:06:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:47 --> Config Class Initialized
INFO - 2023-06-11 09:06:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:47 --> URI Class Initialized
INFO - 2023-06-11 09:06:47 --> Router Class Initialized
INFO - 2023-06-11 09:06:47 --> Output Class Initialized
INFO - 2023-06-11 09:06:47 --> Security Class Initialized
INFO - 2023-06-11 09:06:47 --> Input Class Initialized
INFO - 2023-06-11 09:06:47 --> Language Class Initialized
INFO - 2023-06-11 09:06:47 --> Loader Class Initialized
INFO - 2023-06-11 09:06:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:47 --> Controller Class Initialized
INFO - 2023-06-11 09:06:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:47 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:47 --> Config Class Initialized
INFO - 2023-06-11 09:06:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:47 --> URI Class Initialized
INFO - 2023-06-11 09:06:47 --> Router Class Initialized
INFO - 2023-06-11 09:06:47 --> Output Class Initialized
INFO - 2023-06-11 09:06:47 --> Security Class Initialized
INFO - 2023-06-11 09:06:47 --> Input Class Initialized
INFO - 2023-06-11 09:06:47 --> Language Class Initialized
INFO - 2023-06-11 09:06:47 --> Loader Class Initialized
INFO - 2023-06-11 09:06:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:47 --> Controller Class Initialized
INFO - 2023-06-11 09:06:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:47 --> Config Class Initialized
INFO - 2023-06-11 09:06:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:47 --> URI Class Initialized
INFO - 2023-06-11 09:06:47 --> Router Class Initialized
INFO - 2023-06-11 09:06:47 --> Output Class Initialized
INFO - 2023-06-11 09:06:47 --> Security Class Initialized
INFO - 2023-06-11 09:06:47 --> Input Class Initialized
INFO - 2023-06-11 09:06:47 --> Language Class Initialized
INFO - 2023-06-11 09:06:47 --> Loader Class Initialized
INFO - 2023-06-11 09:06:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:47 --> Controller Class Initialized
INFO - 2023-06-11 09:06:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:47 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:47 --> Config Class Initialized
INFO - 2023-06-11 09:06:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:47 --> URI Class Initialized
INFO - 2023-06-11 09:06:47 --> Router Class Initialized
INFO - 2023-06-11 09:06:47 --> Output Class Initialized
INFO - 2023-06-11 09:06:47 --> Security Class Initialized
INFO - 2023-06-11 09:06:47 --> Input Class Initialized
INFO - 2023-06-11 09:06:47 --> Language Class Initialized
INFO - 2023-06-11 09:06:47 --> Loader Class Initialized
INFO - 2023-06-11 09:06:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:47 --> Controller Class Initialized
INFO - 2023-06-11 09:06:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:48 --> Config Class Initialized
INFO - 2023-06-11 09:06:48 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:48 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:48 --> URI Class Initialized
INFO - 2023-06-11 09:06:48 --> Router Class Initialized
INFO - 2023-06-11 09:06:48 --> Output Class Initialized
INFO - 2023-06-11 09:06:48 --> Security Class Initialized
INFO - 2023-06-11 09:06:48 --> Input Class Initialized
INFO - 2023-06-11 09:06:48 --> Language Class Initialized
INFO - 2023-06-11 09:06:48 --> Loader Class Initialized
INFO - 2023-06-11 09:06:48 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:48 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:48 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:48 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:48 --> Controller Class Initialized
INFO - 2023-06-11 09:06:48 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:48 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:48 --> Config Class Initialized
INFO - 2023-06-11 09:06:48 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:48 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:48 --> URI Class Initialized
INFO - 2023-06-11 09:06:48 --> Router Class Initialized
INFO - 2023-06-11 09:06:48 --> Output Class Initialized
INFO - 2023-06-11 09:06:48 --> Security Class Initialized
INFO - 2023-06-11 09:06:48 --> Input Class Initialized
INFO - 2023-06-11 09:06:48 --> Language Class Initialized
INFO - 2023-06-11 09:06:48 --> Loader Class Initialized
INFO - 2023-06-11 09:06:48 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:48 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:48 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:48 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:48 --> Controller Class Initialized
INFO - 2023-06-11 09:06:48 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:48 --> Config Class Initialized
INFO - 2023-06-11 09:06:48 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:48 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:48 --> URI Class Initialized
INFO - 2023-06-11 09:06:48 --> Router Class Initialized
INFO - 2023-06-11 09:06:48 --> Output Class Initialized
INFO - 2023-06-11 09:06:48 --> Security Class Initialized
INFO - 2023-06-11 09:06:48 --> Input Class Initialized
INFO - 2023-06-11 09:06:48 --> Language Class Initialized
INFO - 2023-06-11 09:06:48 --> Loader Class Initialized
INFO - 2023-06-11 09:06:48 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:48 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:48 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:48 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:48 --> Controller Class Initialized
INFO - 2023-06-11 09:06:48 --> Model "m_user" initialized
INFO - 2023-06-11 09:06:48 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:06:48 --> Config Class Initialized
INFO - 2023-06-11 09:06:48 --> Hooks Class Initialized
INFO - 2023-06-11 09:06:48 --> Utf8 Class Initialized
INFO - 2023-06-11 09:06:48 --> URI Class Initialized
INFO - 2023-06-11 09:06:48 --> Router Class Initialized
INFO - 2023-06-11 09:06:48 --> Output Class Initialized
INFO - 2023-06-11 09:06:48 --> Security Class Initialized
INFO - 2023-06-11 09:06:48 --> Input Class Initialized
INFO - 2023-06-11 09:06:48 --> Language Class Initialized
INFO - 2023-06-11 09:06:48 --> Loader Class Initialized
INFO - 2023-06-11 09:06:48 --> Helper loaded: url_helper
INFO - 2023-06-11 09:06:48 --> Helper loaded: form_helper
INFO - 2023-06-11 09:06:48 --> Database Driver Class Initialized
INFO - 2023-06-11 09:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:06:48 --> Form Validation Class Initialized
INFO - 2023-06-11 09:06:48 --> Controller Class Initialized
INFO - 2023-06-11 09:06:48 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:18 --> Config Class Initialized
INFO - 2023-06-11 09:07:18 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:18 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:18 --> URI Class Initialized
INFO - 2023-06-11 09:07:18 --> Router Class Initialized
INFO - 2023-06-11 09:07:18 --> Output Class Initialized
INFO - 2023-06-11 09:07:18 --> Security Class Initialized
INFO - 2023-06-11 09:07:18 --> Input Class Initialized
INFO - 2023-06-11 09:07:18 --> Language Class Initialized
INFO - 2023-06-11 09:07:18 --> Loader Class Initialized
INFO - 2023-06-11 09:07:18 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:18 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:18 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:18 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:18 --> Controller Class Initialized
INFO - 2023-06-11 09:07:18 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:18 --> Config Class Initialized
INFO - 2023-06-11 09:07:18 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:18 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:18 --> URI Class Initialized
INFO - 2023-06-11 09:07:18 --> Router Class Initialized
INFO - 2023-06-11 09:07:18 --> Output Class Initialized
INFO - 2023-06-11 09:07:18 --> Security Class Initialized
INFO - 2023-06-11 09:07:18 --> Input Class Initialized
INFO - 2023-06-11 09:07:18 --> Language Class Initialized
INFO - 2023-06-11 09:07:18 --> Loader Class Initialized
INFO - 2023-06-11 09:07:18 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:18 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:18 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:18 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:18 --> Controller Class Initialized
INFO - 2023-06-11 09:07:18 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:18 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:18 --> Config Class Initialized
INFO - 2023-06-11 09:07:18 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:18 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:18 --> URI Class Initialized
INFO - 2023-06-11 09:07:18 --> Router Class Initialized
INFO - 2023-06-11 09:07:18 --> Output Class Initialized
INFO - 2023-06-11 09:07:18 --> Security Class Initialized
INFO - 2023-06-11 09:07:18 --> Input Class Initialized
INFO - 2023-06-11 09:07:18 --> Language Class Initialized
INFO - 2023-06-11 09:07:18 --> Loader Class Initialized
INFO - 2023-06-11 09:07:19 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:19 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:19 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:19 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:19 --> Controller Class Initialized
INFO - 2023-06-11 09:07:19 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:19 --> Config Class Initialized
INFO - 2023-06-11 09:07:19 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:19 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:19 --> URI Class Initialized
INFO - 2023-06-11 09:07:19 --> Router Class Initialized
INFO - 2023-06-11 09:07:19 --> Output Class Initialized
INFO - 2023-06-11 09:07:19 --> Security Class Initialized
INFO - 2023-06-11 09:07:19 --> Input Class Initialized
INFO - 2023-06-11 09:07:19 --> Language Class Initialized
INFO - 2023-06-11 09:07:19 --> Loader Class Initialized
INFO - 2023-06-11 09:07:19 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:19 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:19 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:19 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:19 --> Controller Class Initialized
INFO - 2023-06-11 09:07:19 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:19 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:19 --> Config Class Initialized
INFO - 2023-06-11 09:07:19 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:19 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:19 --> URI Class Initialized
INFO - 2023-06-11 09:07:19 --> Router Class Initialized
INFO - 2023-06-11 09:07:19 --> Output Class Initialized
INFO - 2023-06-11 09:07:19 --> Security Class Initialized
INFO - 2023-06-11 09:07:19 --> Input Class Initialized
INFO - 2023-06-11 09:07:19 --> Language Class Initialized
INFO - 2023-06-11 09:07:19 --> Loader Class Initialized
INFO - 2023-06-11 09:07:19 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:19 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:19 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:19 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:19 --> Controller Class Initialized
INFO - 2023-06-11 09:07:19 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:19 --> Config Class Initialized
INFO - 2023-06-11 09:07:19 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:19 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:19 --> URI Class Initialized
INFO - 2023-06-11 09:07:19 --> Router Class Initialized
INFO - 2023-06-11 09:07:19 --> Output Class Initialized
INFO - 2023-06-11 09:07:19 --> Security Class Initialized
INFO - 2023-06-11 09:07:19 --> Input Class Initialized
INFO - 2023-06-11 09:07:19 --> Language Class Initialized
INFO - 2023-06-11 09:07:19 --> Loader Class Initialized
INFO - 2023-06-11 09:07:19 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:19 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:19 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:19 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:19 --> Controller Class Initialized
INFO - 2023-06-11 09:07:19 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:19 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:19 --> Config Class Initialized
INFO - 2023-06-11 09:07:19 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:19 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:19 --> URI Class Initialized
INFO - 2023-06-11 09:07:19 --> Router Class Initialized
INFO - 2023-06-11 09:07:19 --> Output Class Initialized
INFO - 2023-06-11 09:07:19 --> Security Class Initialized
INFO - 2023-06-11 09:07:19 --> Input Class Initialized
INFO - 2023-06-11 09:07:19 --> Language Class Initialized
INFO - 2023-06-11 09:07:19 --> Loader Class Initialized
INFO - 2023-06-11 09:07:19 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:19 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:19 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:19 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:19 --> Controller Class Initialized
INFO - 2023-06-11 09:07:19 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:19 --> Config Class Initialized
INFO - 2023-06-11 09:07:19 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:19 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:19 --> URI Class Initialized
INFO - 2023-06-11 09:07:19 --> Router Class Initialized
INFO - 2023-06-11 09:07:19 --> Output Class Initialized
INFO - 2023-06-11 09:07:19 --> Security Class Initialized
INFO - 2023-06-11 09:07:19 --> Input Class Initialized
INFO - 2023-06-11 09:07:19 --> Language Class Initialized
INFO - 2023-06-11 09:07:19 --> Loader Class Initialized
INFO - 2023-06-11 09:07:19 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:19 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:19 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:19 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:19 --> Controller Class Initialized
INFO - 2023-06-11 09:07:19 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:19 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:19 --> Config Class Initialized
INFO - 2023-06-11 09:07:19 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:19 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:19 --> URI Class Initialized
INFO - 2023-06-11 09:07:19 --> Router Class Initialized
INFO - 2023-06-11 09:07:19 --> Output Class Initialized
INFO - 2023-06-11 09:07:19 --> Security Class Initialized
INFO - 2023-06-11 09:07:19 --> Input Class Initialized
INFO - 2023-06-11 09:07:19 --> Language Class Initialized
INFO - 2023-06-11 09:07:19 --> Loader Class Initialized
INFO - 2023-06-11 09:07:19 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:19 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:19 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:19 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:19 --> Controller Class Initialized
INFO - 2023-06-11 09:07:19 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:19 --> Config Class Initialized
INFO - 2023-06-11 09:07:19 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:19 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:19 --> URI Class Initialized
INFO - 2023-06-11 09:07:19 --> Router Class Initialized
INFO - 2023-06-11 09:07:19 --> Output Class Initialized
INFO - 2023-06-11 09:07:19 --> Security Class Initialized
INFO - 2023-06-11 09:07:19 --> Input Class Initialized
INFO - 2023-06-11 09:07:19 --> Language Class Initialized
INFO - 2023-06-11 09:07:19 --> Loader Class Initialized
INFO - 2023-06-11 09:07:19 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:19 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:19 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:19 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:19 --> Controller Class Initialized
INFO - 2023-06-11 09:07:19 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:19 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:19 --> Config Class Initialized
INFO - 2023-06-11 09:07:19 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:19 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:19 --> URI Class Initialized
INFO - 2023-06-11 09:07:19 --> Router Class Initialized
INFO - 2023-06-11 09:07:19 --> Output Class Initialized
INFO - 2023-06-11 09:07:19 --> Security Class Initialized
INFO - 2023-06-11 09:07:19 --> Input Class Initialized
INFO - 2023-06-11 09:07:19 --> Language Class Initialized
INFO - 2023-06-11 09:07:19 --> Loader Class Initialized
INFO - 2023-06-11 09:07:19 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:19 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:19 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:19 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:19 --> Controller Class Initialized
INFO - 2023-06-11 09:07:19 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:20 --> Config Class Initialized
INFO - 2023-06-11 09:07:20 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:20 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:20 --> URI Class Initialized
INFO - 2023-06-11 09:07:20 --> Router Class Initialized
INFO - 2023-06-11 09:07:20 --> Output Class Initialized
INFO - 2023-06-11 09:07:20 --> Security Class Initialized
INFO - 2023-06-11 09:07:20 --> Input Class Initialized
INFO - 2023-06-11 09:07:20 --> Language Class Initialized
INFO - 2023-06-11 09:07:20 --> Loader Class Initialized
INFO - 2023-06-11 09:07:20 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:20 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:20 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:20 --> Config Class Initialized
INFO - 2023-06-11 09:07:20 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:20 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:20 --> Controller Class Initialized
INFO - 2023-06-11 09:07:20 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:20 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:20 --> URI Class Initialized
INFO - 2023-06-11 09:07:20 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:20 --> Router Class Initialized
INFO - 2023-06-11 09:07:20 --> Output Class Initialized
INFO - 2023-06-11 09:07:20 --> Security Class Initialized
INFO - 2023-06-11 09:07:20 --> Input Class Initialized
INFO - 2023-06-11 09:07:20 --> Language Class Initialized
INFO - 2023-06-11 09:07:20 --> Loader Class Initialized
INFO - 2023-06-11 09:07:20 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:20 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:20 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:20 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:20 --> Controller Class Initialized
INFO - 2023-06-11 09:07:20 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:20 --> Config Class Initialized
INFO - 2023-06-11 09:07:20 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:20 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:20 --> URI Class Initialized
INFO - 2023-06-11 09:07:20 --> Router Class Initialized
INFO - 2023-06-11 09:07:20 --> Output Class Initialized
INFO - 2023-06-11 09:07:20 --> Security Class Initialized
INFO - 2023-06-11 09:07:20 --> Input Class Initialized
INFO - 2023-06-11 09:07:20 --> Language Class Initialized
INFO - 2023-06-11 09:07:20 --> Loader Class Initialized
INFO - 2023-06-11 09:07:20 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:20 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:20 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:20 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:20 --> Controller Class Initialized
INFO - 2023-06-11 09:07:20 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:20 --> Config Class Initialized
INFO - 2023-06-11 09:07:20 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:20 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:20 --> URI Class Initialized
INFO - 2023-06-11 09:07:20 --> Router Class Initialized
INFO - 2023-06-11 09:07:20 --> Output Class Initialized
INFO - 2023-06-11 09:07:20 --> Security Class Initialized
INFO - 2023-06-11 09:07:20 --> Input Class Initialized
INFO - 2023-06-11 09:07:20 --> Language Class Initialized
INFO - 2023-06-11 09:07:20 --> Loader Class Initialized
INFO - 2023-06-11 09:07:20 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:20 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:20 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:20 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:20 --> Controller Class Initialized
INFO - 2023-06-11 09:07:20 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:20 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:20 --> Config Class Initialized
INFO - 2023-06-11 09:07:20 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:20 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:20 --> URI Class Initialized
INFO - 2023-06-11 09:07:20 --> Router Class Initialized
INFO - 2023-06-11 09:07:20 --> Output Class Initialized
INFO - 2023-06-11 09:07:20 --> Security Class Initialized
INFO - 2023-06-11 09:07:20 --> Input Class Initialized
INFO - 2023-06-11 09:07:20 --> Language Class Initialized
INFO - 2023-06-11 09:07:20 --> Loader Class Initialized
INFO - 2023-06-11 09:07:20 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:20 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:20 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:20 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:20 --> Controller Class Initialized
INFO - 2023-06-11 09:07:20 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:20 --> Config Class Initialized
INFO - 2023-06-11 09:07:20 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:20 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:20 --> URI Class Initialized
INFO - 2023-06-11 09:07:20 --> Router Class Initialized
INFO - 2023-06-11 09:07:20 --> Output Class Initialized
INFO - 2023-06-11 09:07:20 --> Security Class Initialized
INFO - 2023-06-11 09:07:20 --> Input Class Initialized
INFO - 2023-06-11 09:07:20 --> Language Class Initialized
INFO - 2023-06-11 09:07:20 --> Loader Class Initialized
INFO - 2023-06-11 09:07:20 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:20 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:20 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:20 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:20 --> Controller Class Initialized
INFO - 2023-06-11 09:07:20 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:20 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:20 --> Config Class Initialized
INFO - 2023-06-11 09:07:20 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:20 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:20 --> URI Class Initialized
INFO - 2023-06-11 09:07:20 --> Router Class Initialized
INFO - 2023-06-11 09:07:20 --> Output Class Initialized
INFO - 2023-06-11 09:07:20 --> Security Class Initialized
INFO - 2023-06-11 09:07:20 --> Input Class Initialized
INFO - 2023-06-11 09:07:20 --> Language Class Initialized
INFO - 2023-06-11 09:07:20 --> Loader Class Initialized
INFO - 2023-06-11 09:07:20 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:20 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:20 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:20 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:20 --> Controller Class Initialized
INFO - 2023-06-11 09:07:20 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:20 --> Config Class Initialized
INFO - 2023-06-11 09:07:20 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:20 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:20 --> URI Class Initialized
INFO - 2023-06-11 09:07:20 --> Router Class Initialized
INFO - 2023-06-11 09:07:20 --> Output Class Initialized
INFO - 2023-06-11 09:07:20 --> Security Class Initialized
INFO - 2023-06-11 09:07:20 --> Input Class Initialized
INFO - 2023-06-11 09:07:20 --> Language Class Initialized
INFO - 2023-06-11 09:07:20 --> Loader Class Initialized
INFO - 2023-06-11 09:07:20 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:20 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:20 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:20 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:20 --> Controller Class Initialized
INFO - 2023-06-11 09:07:20 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:20 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:20 --> Config Class Initialized
INFO - 2023-06-11 09:07:20 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:20 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:20 --> URI Class Initialized
INFO - 2023-06-11 09:07:20 --> Router Class Initialized
INFO - 2023-06-11 09:07:20 --> Output Class Initialized
INFO - 2023-06-11 09:07:20 --> Security Class Initialized
INFO - 2023-06-11 09:07:20 --> Input Class Initialized
INFO - 2023-06-11 09:07:20 --> Language Class Initialized
INFO - 2023-06-11 09:07:20 --> Loader Class Initialized
INFO - 2023-06-11 09:07:20 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:20 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:20 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:20 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:20 --> Controller Class Initialized
INFO - 2023-06-11 09:07:20 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:20 --> Config Class Initialized
INFO - 2023-06-11 09:07:20 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:20 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:20 --> URI Class Initialized
INFO - 2023-06-11 09:07:20 --> Router Class Initialized
INFO - 2023-06-11 09:07:20 --> Output Class Initialized
INFO - 2023-06-11 09:07:20 --> Security Class Initialized
INFO - 2023-06-11 09:07:20 --> Input Class Initialized
INFO - 2023-06-11 09:07:20 --> Language Class Initialized
INFO - 2023-06-11 09:07:20 --> Loader Class Initialized
INFO - 2023-06-11 09:07:20 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:20 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:20 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:20 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:20 --> Controller Class Initialized
INFO - 2023-06-11 09:07:20 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:20 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:21 --> Config Class Initialized
INFO - 2023-06-11 09:07:21 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:21 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:21 --> URI Class Initialized
INFO - 2023-06-11 09:07:21 --> Router Class Initialized
INFO - 2023-06-11 09:07:21 --> Output Class Initialized
INFO - 2023-06-11 09:07:21 --> Security Class Initialized
INFO - 2023-06-11 09:07:21 --> Input Class Initialized
INFO - 2023-06-11 09:07:21 --> Language Class Initialized
INFO - 2023-06-11 09:07:21 --> Loader Class Initialized
INFO - 2023-06-11 09:07:21 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:21 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:21 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:21 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:21 --> Controller Class Initialized
INFO - 2023-06-11 09:07:21 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:21 --> Config Class Initialized
INFO - 2023-06-11 09:07:21 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:21 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:21 --> URI Class Initialized
INFO - 2023-06-11 09:07:21 --> Router Class Initialized
INFO - 2023-06-11 09:07:21 --> Output Class Initialized
INFO - 2023-06-11 09:07:21 --> Security Class Initialized
INFO - 2023-06-11 09:07:21 --> Input Class Initialized
INFO - 2023-06-11 09:07:21 --> Language Class Initialized
INFO - 2023-06-11 09:07:21 --> Loader Class Initialized
INFO - 2023-06-11 09:07:21 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:21 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:21 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:21 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:21 --> Controller Class Initialized
INFO - 2023-06-11 09:07:21 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:21 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:21 --> Config Class Initialized
INFO - 2023-06-11 09:07:21 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:21 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:21 --> URI Class Initialized
INFO - 2023-06-11 09:07:21 --> Router Class Initialized
INFO - 2023-06-11 09:07:21 --> Output Class Initialized
INFO - 2023-06-11 09:07:21 --> Security Class Initialized
INFO - 2023-06-11 09:07:21 --> Input Class Initialized
INFO - 2023-06-11 09:07:21 --> Language Class Initialized
INFO - 2023-06-11 09:07:21 --> Loader Class Initialized
INFO - 2023-06-11 09:07:21 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:21 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:21 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:21 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:21 --> Controller Class Initialized
INFO - 2023-06-11 09:07:21 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:21 --> Config Class Initialized
INFO - 2023-06-11 09:07:21 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:21 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:21 --> URI Class Initialized
INFO - 2023-06-11 09:07:21 --> Router Class Initialized
INFO - 2023-06-11 09:07:21 --> Output Class Initialized
INFO - 2023-06-11 09:07:21 --> Security Class Initialized
INFO - 2023-06-11 09:07:21 --> Input Class Initialized
INFO - 2023-06-11 09:07:21 --> Language Class Initialized
INFO - 2023-06-11 09:07:21 --> Loader Class Initialized
INFO - 2023-06-11 09:07:21 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:21 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:21 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:21 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:21 --> Controller Class Initialized
INFO - 2023-06-11 09:07:21 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:21 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:21 --> Config Class Initialized
INFO - 2023-06-11 09:07:21 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:21 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:21 --> URI Class Initialized
INFO - 2023-06-11 09:07:21 --> Router Class Initialized
INFO - 2023-06-11 09:07:21 --> Output Class Initialized
INFO - 2023-06-11 09:07:21 --> Security Class Initialized
INFO - 2023-06-11 09:07:21 --> Input Class Initialized
INFO - 2023-06-11 09:07:21 --> Language Class Initialized
INFO - 2023-06-11 09:07:21 --> Loader Class Initialized
INFO - 2023-06-11 09:07:21 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:21 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:21 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:21 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:21 --> Controller Class Initialized
INFO - 2023-06-11 09:07:21 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:21 --> Config Class Initialized
INFO - 2023-06-11 09:07:21 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:21 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:21 --> URI Class Initialized
INFO - 2023-06-11 09:07:21 --> Router Class Initialized
INFO - 2023-06-11 09:07:21 --> Output Class Initialized
INFO - 2023-06-11 09:07:21 --> Security Class Initialized
INFO - 2023-06-11 09:07:21 --> Input Class Initialized
INFO - 2023-06-11 09:07:21 --> Language Class Initialized
INFO - 2023-06-11 09:07:21 --> Loader Class Initialized
INFO - 2023-06-11 09:07:21 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:21 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:21 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:21 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:21 --> Controller Class Initialized
INFO - 2023-06-11 09:07:21 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:21 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:21 --> Config Class Initialized
INFO - 2023-06-11 09:07:21 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:21 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:21 --> URI Class Initialized
INFO - 2023-06-11 09:07:21 --> Router Class Initialized
INFO - 2023-06-11 09:07:21 --> Output Class Initialized
INFO - 2023-06-11 09:07:21 --> Security Class Initialized
INFO - 2023-06-11 09:07:21 --> Input Class Initialized
INFO - 2023-06-11 09:07:21 --> Language Class Initialized
INFO - 2023-06-11 09:07:21 --> Loader Class Initialized
INFO - 2023-06-11 09:07:21 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:21 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:21 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:21 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:21 --> Controller Class Initialized
INFO - 2023-06-11 09:07:21 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:21 --> Config Class Initialized
INFO - 2023-06-11 09:07:21 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:21 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:21 --> URI Class Initialized
INFO - 2023-06-11 09:07:21 --> Router Class Initialized
INFO - 2023-06-11 09:07:21 --> Output Class Initialized
INFO - 2023-06-11 09:07:21 --> Security Class Initialized
INFO - 2023-06-11 09:07:21 --> Input Class Initialized
INFO - 2023-06-11 09:07:21 --> Language Class Initialized
INFO - 2023-06-11 09:07:21 --> Loader Class Initialized
INFO - 2023-06-11 09:07:21 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:21 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:21 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:21 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:21 --> Controller Class Initialized
INFO - 2023-06-11 09:07:21 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:21 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:21 --> Config Class Initialized
INFO - 2023-06-11 09:07:21 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:21 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:21 --> URI Class Initialized
INFO - 2023-06-11 09:07:21 --> Router Class Initialized
INFO - 2023-06-11 09:07:21 --> Output Class Initialized
INFO - 2023-06-11 09:07:21 --> Security Class Initialized
INFO - 2023-06-11 09:07:21 --> Input Class Initialized
INFO - 2023-06-11 09:07:21 --> Language Class Initialized
INFO - 2023-06-11 09:07:21 --> Loader Class Initialized
INFO - 2023-06-11 09:07:21 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:21 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:22 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:22 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:22 --> Controller Class Initialized
INFO - 2023-06-11 09:07:22 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:22 --> Config Class Initialized
INFO - 2023-06-11 09:07:22 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:22 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:22 --> URI Class Initialized
INFO - 2023-06-11 09:07:22 --> Router Class Initialized
INFO - 2023-06-11 09:07:22 --> Output Class Initialized
INFO - 2023-06-11 09:07:22 --> Security Class Initialized
INFO - 2023-06-11 09:07:22 --> Input Class Initialized
INFO - 2023-06-11 09:07:22 --> Language Class Initialized
INFO - 2023-06-11 09:07:22 --> Loader Class Initialized
INFO - 2023-06-11 09:07:22 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:22 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:22 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:22 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:22 --> Controller Class Initialized
INFO - 2023-06-11 09:07:22 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:22 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:22 --> Config Class Initialized
INFO - 2023-06-11 09:07:22 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:22 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:22 --> URI Class Initialized
INFO - 2023-06-11 09:07:22 --> Router Class Initialized
INFO - 2023-06-11 09:07:22 --> Output Class Initialized
INFO - 2023-06-11 09:07:22 --> Security Class Initialized
INFO - 2023-06-11 09:07:22 --> Input Class Initialized
INFO - 2023-06-11 09:07:22 --> Language Class Initialized
INFO - 2023-06-11 09:07:22 --> Loader Class Initialized
INFO - 2023-06-11 09:07:22 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:22 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:22 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:22 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:22 --> Controller Class Initialized
INFO - 2023-06-11 09:07:22 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:22 --> Config Class Initialized
INFO - 2023-06-11 09:07:22 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:22 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:22 --> URI Class Initialized
INFO - 2023-06-11 09:07:22 --> Router Class Initialized
INFO - 2023-06-11 09:07:22 --> Output Class Initialized
INFO - 2023-06-11 09:07:22 --> Security Class Initialized
INFO - 2023-06-11 09:07:22 --> Input Class Initialized
INFO - 2023-06-11 09:07:22 --> Language Class Initialized
INFO - 2023-06-11 09:07:22 --> Loader Class Initialized
INFO - 2023-06-11 09:07:22 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:22 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:22 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:22 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:22 --> Controller Class Initialized
INFO - 2023-06-11 09:07:22 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:22 --> Config Class Initialized
INFO - 2023-06-11 09:07:22 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:22 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:23 --> URI Class Initialized
INFO - 2023-06-11 09:07:23 --> Router Class Initialized
INFO - 2023-06-11 09:07:23 --> Output Class Initialized
INFO - 2023-06-11 09:07:23 --> Security Class Initialized
INFO - 2023-06-11 09:07:23 --> Input Class Initialized
INFO - 2023-06-11 09:07:23 --> Language Class Initialized
INFO - 2023-06-11 09:07:23 --> Loader Class Initialized
INFO - 2023-06-11 09:07:23 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:23 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:23 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:23 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:23 --> Controller Class Initialized
INFO - 2023-06-11 09:07:23 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:23 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:23 --> Config Class Initialized
INFO - 2023-06-11 09:07:23 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:23 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:23 --> URI Class Initialized
INFO - 2023-06-11 09:07:23 --> Router Class Initialized
INFO - 2023-06-11 09:07:23 --> Output Class Initialized
INFO - 2023-06-11 09:07:23 --> Security Class Initialized
INFO - 2023-06-11 09:07:23 --> Input Class Initialized
INFO - 2023-06-11 09:07:23 --> Language Class Initialized
INFO - 2023-06-11 09:07:23 --> Loader Class Initialized
INFO - 2023-06-11 09:07:23 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:23 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:23 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:23 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:23 --> Controller Class Initialized
INFO - 2023-06-11 09:07:23 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:23 --> Config Class Initialized
INFO - 2023-06-11 09:07:23 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:23 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:23 --> URI Class Initialized
INFO - 2023-06-11 09:07:23 --> Router Class Initialized
INFO - 2023-06-11 09:07:23 --> Output Class Initialized
INFO - 2023-06-11 09:07:23 --> Security Class Initialized
INFO - 2023-06-11 09:07:23 --> Input Class Initialized
INFO - 2023-06-11 09:07:23 --> Language Class Initialized
INFO - 2023-06-11 09:07:23 --> Loader Class Initialized
INFO - 2023-06-11 09:07:23 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:23 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:23 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:23 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:23 --> Controller Class Initialized
INFO - 2023-06-11 09:07:23 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:23 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:23 --> Config Class Initialized
INFO - 2023-06-11 09:07:23 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:23 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:23 --> URI Class Initialized
INFO - 2023-06-11 09:07:23 --> Router Class Initialized
INFO - 2023-06-11 09:07:23 --> Output Class Initialized
INFO - 2023-06-11 09:07:23 --> Security Class Initialized
INFO - 2023-06-11 09:07:23 --> Input Class Initialized
INFO - 2023-06-11 09:07:23 --> Language Class Initialized
INFO - 2023-06-11 09:07:23 --> Loader Class Initialized
INFO - 2023-06-11 09:07:23 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:23 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:23 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:23 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:23 --> Controller Class Initialized
INFO - 2023-06-11 09:07:23 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:23 --> Config Class Initialized
INFO - 2023-06-11 09:07:23 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:23 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:23 --> URI Class Initialized
INFO - 2023-06-11 09:07:23 --> Router Class Initialized
INFO - 2023-06-11 09:07:23 --> Output Class Initialized
INFO - 2023-06-11 09:07:23 --> Security Class Initialized
INFO - 2023-06-11 09:07:23 --> Input Class Initialized
INFO - 2023-06-11 09:07:23 --> Language Class Initialized
INFO - 2023-06-11 09:07:23 --> Loader Class Initialized
INFO - 2023-06-11 09:07:23 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:23 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:23 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:23 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:23 --> Controller Class Initialized
INFO - 2023-06-11 09:07:23 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:23 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:23 --> Config Class Initialized
INFO - 2023-06-11 09:07:23 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:23 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:23 --> URI Class Initialized
INFO - 2023-06-11 09:07:23 --> Router Class Initialized
INFO - 2023-06-11 09:07:23 --> Output Class Initialized
INFO - 2023-06-11 09:07:23 --> Security Class Initialized
INFO - 2023-06-11 09:07:23 --> Input Class Initialized
INFO - 2023-06-11 09:07:23 --> Language Class Initialized
INFO - 2023-06-11 09:07:23 --> Loader Class Initialized
INFO - 2023-06-11 09:07:23 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:23 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:23 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:23 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:23 --> Controller Class Initialized
INFO - 2023-06-11 09:07:23 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:23 --> Config Class Initialized
INFO - 2023-06-11 09:07:23 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:23 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:23 --> URI Class Initialized
INFO - 2023-06-11 09:07:23 --> Router Class Initialized
INFO - 2023-06-11 09:07:23 --> Output Class Initialized
INFO - 2023-06-11 09:07:23 --> Security Class Initialized
INFO - 2023-06-11 09:07:23 --> Input Class Initialized
INFO - 2023-06-11 09:07:23 --> Language Class Initialized
INFO - 2023-06-11 09:07:23 --> Loader Class Initialized
INFO - 2023-06-11 09:07:23 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:23 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:23 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:23 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:23 --> Controller Class Initialized
INFO - 2023-06-11 09:07:23 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:23 --> Config Class Initialized
INFO - 2023-06-11 09:07:23 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:23 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:23 --> URI Class Initialized
INFO - 2023-06-11 09:07:23 --> Router Class Initialized
INFO - 2023-06-11 09:07:23 --> Output Class Initialized
INFO - 2023-06-11 09:07:23 --> Security Class Initialized
INFO - 2023-06-11 09:07:23 --> Input Class Initialized
INFO - 2023-06-11 09:07:23 --> Language Class Initialized
INFO - 2023-06-11 09:07:23 --> Loader Class Initialized
INFO - 2023-06-11 09:07:23 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:23 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:23 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:23 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:23 --> Controller Class Initialized
INFO - 2023-06-11 09:07:23 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:23 --> Config Class Initialized
INFO - 2023-06-11 09:07:23 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:23 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:23 --> URI Class Initialized
INFO - 2023-06-11 09:07:23 --> Router Class Initialized
INFO - 2023-06-11 09:07:23 --> Output Class Initialized
INFO - 2023-06-11 09:07:23 --> Security Class Initialized
INFO - 2023-06-11 09:07:23 --> Input Class Initialized
INFO - 2023-06-11 09:07:23 --> Language Class Initialized
INFO - 2023-06-11 09:07:23 --> Loader Class Initialized
INFO - 2023-06-11 09:07:23 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:23 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:23 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:23 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:23 --> Controller Class Initialized
INFO - 2023-06-11 09:07:23 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:23 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:23 --> Config Class Initialized
INFO - 2023-06-11 09:07:23 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:23 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:23 --> URI Class Initialized
INFO - 2023-06-11 09:07:23 --> Router Class Initialized
INFO - 2023-06-11 09:07:23 --> Output Class Initialized
INFO - 2023-06-11 09:07:23 --> Security Class Initialized
INFO - 2023-06-11 09:07:23 --> Input Class Initialized
INFO - 2023-06-11 09:07:23 --> Language Class Initialized
INFO - 2023-06-11 09:07:23 --> Loader Class Initialized
INFO - 2023-06-11 09:07:23 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:23 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:24 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:24 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:24 --> Controller Class Initialized
INFO - 2023-06-11 09:07:24 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:24 --> Config Class Initialized
INFO - 2023-06-11 09:07:24 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:24 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:24 --> URI Class Initialized
INFO - 2023-06-11 09:07:24 --> Router Class Initialized
INFO - 2023-06-11 09:07:24 --> Output Class Initialized
INFO - 2023-06-11 09:07:24 --> Security Class Initialized
INFO - 2023-06-11 09:07:24 --> Input Class Initialized
INFO - 2023-06-11 09:07:24 --> Language Class Initialized
INFO - 2023-06-11 09:07:24 --> Loader Class Initialized
INFO - 2023-06-11 09:07:24 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:24 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:24 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:24 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:24 --> Controller Class Initialized
INFO - 2023-06-11 09:07:24 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:24 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:24 --> Config Class Initialized
INFO - 2023-06-11 09:07:24 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:24 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:24 --> URI Class Initialized
INFO - 2023-06-11 09:07:24 --> Router Class Initialized
INFO - 2023-06-11 09:07:24 --> Output Class Initialized
INFO - 2023-06-11 09:07:24 --> Security Class Initialized
INFO - 2023-06-11 09:07:24 --> Input Class Initialized
INFO - 2023-06-11 09:07:24 --> Language Class Initialized
INFO - 2023-06-11 09:07:24 --> Loader Class Initialized
INFO - 2023-06-11 09:07:24 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:24 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:24 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:24 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:24 --> Controller Class Initialized
INFO - 2023-06-11 09:07:24 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:24 --> Config Class Initialized
INFO - 2023-06-11 09:07:24 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:24 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:24 --> URI Class Initialized
INFO - 2023-06-11 09:07:24 --> Router Class Initialized
INFO - 2023-06-11 09:07:24 --> Output Class Initialized
INFO - 2023-06-11 09:07:24 --> Security Class Initialized
INFO - 2023-06-11 09:07:24 --> Input Class Initialized
INFO - 2023-06-11 09:07:24 --> Language Class Initialized
INFO - 2023-06-11 09:07:24 --> Loader Class Initialized
INFO - 2023-06-11 09:07:24 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:24 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:24 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:24 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:24 --> Controller Class Initialized
INFO - 2023-06-11 09:07:24 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:24 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:24 --> Config Class Initialized
INFO - 2023-06-11 09:07:24 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:24 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:24 --> URI Class Initialized
INFO - 2023-06-11 09:07:24 --> Router Class Initialized
INFO - 2023-06-11 09:07:24 --> Output Class Initialized
INFO - 2023-06-11 09:07:24 --> Security Class Initialized
INFO - 2023-06-11 09:07:24 --> Input Class Initialized
INFO - 2023-06-11 09:07:24 --> Language Class Initialized
INFO - 2023-06-11 09:07:24 --> Loader Class Initialized
INFO - 2023-06-11 09:07:24 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:24 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:24 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:24 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:24 --> Controller Class Initialized
INFO - 2023-06-11 09:07:24 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:24 --> Config Class Initialized
INFO - 2023-06-11 09:07:24 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:24 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:24 --> URI Class Initialized
INFO - 2023-06-11 09:07:24 --> Router Class Initialized
INFO - 2023-06-11 09:07:24 --> Output Class Initialized
INFO - 2023-06-11 09:07:24 --> Security Class Initialized
INFO - 2023-06-11 09:07:24 --> Input Class Initialized
INFO - 2023-06-11 09:07:24 --> Language Class Initialized
INFO - 2023-06-11 09:07:24 --> Loader Class Initialized
INFO - 2023-06-11 09:07:24 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:24 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:24 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:24 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:24 --> Controller Class Initialized
INFO - 2023-06-11 09:07:24 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:24 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:24 --> Config Class Initialized
INFO - 2023-06-11 09:07:24 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:24 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:24 --> URI Class Initialized
INFO - 2023-06-11 09:07:24 --> Router Class Initialized
INFO - 2023-06-11 09:07:24 --> Output Class Initialized
INFO - 2023-06-11 09:07:24 --> Security Class Initialized
INFO - 2023-06-11 09:07:24 --> Input Class Initialized
INFO - 2023-06-11 09:07:24 --> Language Class Initialized
INFO - 2023-06-11 09:07:24 --> Loader Class Initialized
INFO - 2023-06-11 09:07:24 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:24 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:24 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:24 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:24 --> Controller Class Initialized
INFO - 2023-06-11 09:07:24 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:24 --> Config Class Initialized
INFO - 2023-06-11 09:07:24 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:24 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:24 --> URI Class Initialized
INFO - 2023-06-11 09:07:24 --> Router Class Initialized
INFO - 2023-06-11 09:07:24 --> Output Class Initialized
INFO - 2023-06-11 09:07:24 --> Security Class Initialized
INFO - 2023-06-11 09:07:24 --> Input Class Initialized
INFO - 2023-06-11 09:07:24 --> Language Class Initialized
INFO - 2023-06-11 09:07:24 --> Loader Class Initialized
INFO - 2023-06-11 09:07:24 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:24 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:24 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:24 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:24 --> Controller Class Initialized
INFO - 2023-06-11 09:07:24 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:24 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:24 --> Config Class Initialized
INFO - 2023-06-11 09:07:24 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:24 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:24 --> URI Class Initialized
INFO - 2023-06-11 09:07:24 --> Router Class Initialized
INFO - 2023-06-11 09:07:24 --> Output Class Initialized
INFO - 2023-06-11 09:07:24 --> Security Class Initialized
INFO - 2023-06-11 09:07:24 --> Input Class Initialized
INFO - 2023-06-11 09:07:24 --> Language Class Initialized
INFO - 2023-06-11 09:07:24 --> Loader Class Initialized
INFO - 2023-06-11 09:07:24 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:24 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:24 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:24 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:24 --> Controller Class Initialized
INFO - 2023-06-11 09:07:24 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:24 --> Config Class Initialized
INFO - 2023-06-11 09:07:24 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:24 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:24 --> URI Class Initialized
INFO - 2023-06-11 09:07:24 --> Router Class Initialized
INFO - 2023-06-11 09:07:24 --> Output Class Initialized
INFO - 2023-06-11 09:07:24 --> Security Class Initialized
INFO - 2023-06-11 09:07:24 --> Input Class Initialized
INFO - 2023-06-11 09:07:24 --> Language Class Initialized
INFO - 2023-06-11 09:07:24 --> Loader Class Initialized
INFO - 2023-06-11 09:07:24 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:24 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:24 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:24 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:24 --> Controller Class Initialized
INFO - 2023-06-11 09:07:24 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:24 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:24 --> Config Class Initialized
INFO - 2023-06-11 09:07:24 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:24 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:24 --> URI Class Initialized
INFO - 2023-06-11 09:07:24 --> Router Class Initialized
INFO - 2023-06-11 09:07:24 --> Output Class Initialized
INFO - 2023-06-11 09:07:24 --> Security Class Initialized
INFO - 2023-06-11 09:07:24 --> Input Class Initialized
INFO - 2023-06-11 09:07:24 --> Language Class Initialized
INFO - 2023-06-11 09:07:24 --> Loader Class Initialized
INFO - 2023-06-11 09:07:24 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:25 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:25 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:25 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:25 --> Controller Class Initialized
INFO - 2023-06-11 09:07:25 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:25 --> Config Class Initialized
INFO - 2023-06-11 09:07:25 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:25 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:25 --> URI Class Initialized
INFO - 2023-06-11 09:07:25 --> Router Class Initialized
INFO - 2023-06-11 09:07:25 --> Output Class Initialized
INFO - 2023-06-11 09:07:25 --> Security Class Initialized
INFO - 2023-06-11 09:07:25 --> Input Class Initialized
INFO - 2023-06-11 09:07:25 --> Language Class Initialized
INFO - 2023-06-11 09:07:25 --> Loader Class Initialized
INFO - 2023-06-11 09:07:25 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:25 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:25 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:25 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:25 --> Controller Class Initialized
INFO - 2023-06-11 09:07:25 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:25 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:25 --> Config Class Initialized
INFO - 2023-06-11 09:07:25 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:25 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:25 --> URI Class Initialized
INFO - 2023-06-11 09:07:25 --> Router Class Initialized
INFO - 2023-06-11 09:07:25 --> Output Class Initialized
INFO - 2023-06-11 09:07:25 --> Security Class Initialized
INFO - 2023-06-11 09:07:25 --> Input Class Initialized
INFO - 2023-06-11 09:07:25 --> Language Class Initialized
INFO - 2023-06-11 09:07:25 --> Loader Class Initialized
INFO - 2023-06-11 09:07:25 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:25 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:25 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:25 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:25 --> Controller Class Initialized
INFO - 2023-06-11 09:07:25 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:25 --> Config Class Initialized
INFO - 2023-06-11 09:07:25 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:25 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:25 --> URI Class Initialized
INFO - 2023-06-11 09:07:25 --> Router Class Initialized
INFO - 2023-06-11 09:07:25 --> Output Class Initialized
INFO - 2023-06-11 09:07:25 --> Security Class Initialized
INFO - 2023-06-11 09:07:25 --> Input Class Initialized
INFO - 2023-06-11 09:07:25 --> Language Class Initialized
INFO - 2023-06-11 09:07:25 --> Loader Class Initialized
INFO - 2023-06-11 09:07:25 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:25 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:25 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:25 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:25 --> Controller Class Initialized
INFO - 2023-06-11 09:07:25 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:25 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:25 --> Config Class Initialized
INFO - 2023-06-11 09:07:25 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:25 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:25 --> URI Class Initialized
INFO - 2023-06-11 09:07:25 --> Router Class Initialized
INFO - 2023-06-11 09:07:25 --> Output Class Initialized
INFO - 2023-06-11 09:07:25 --> Security Class Initialized
INFO - 2023-06-11 09:07:25 --> Input Class Initialized
INFO - 2023-06-11 09:07:25 --> Language Class Initialized
INFO - 2023-06-11 09:07:25 --> Loader Class Initialized
INFO - 2023-06-11 09:07:25 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:25 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:25 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:25 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:25 --> Controller Class Initialized
INFO - 2023-06-11 09:07:25 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:25 --> Config Class Initialized
INFO - 2023-06-11 09:07:25 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:25 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:25 --> URI Class Initialized
INFO - 2023-06-11 09:07:25 --> Router Class Initialized
INFO - 2023-06-11 09:07:25 --> Output Class Initialized
INFO - 2023-06-11 09:07:25 --> Security Class Initialized
INFO - 2023-06-11 09:07:25 --> Input Class Initialized
INFO - 2023-06-11 09:07:25 --> Language Class Initialized
INFO - 2023-06-11 09:07:25 --> Loader Class Initialized
INFO - 2023-06-11 09:07:25 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:25 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:25 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:25 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:25 --> Controller Class Initialized
INFO - 2023-06-11 09:07:25 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:25 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:25 --> Config Class Initialized
INFO - 2023-06-11 09:07:25 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:25 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:25 --> URI Class Initialized
INFO - 2023-06-11 09:07:25 --> Router Class Initialized
INFO - 2023-06-11 09:07:25 --> Output Class Initialized
INFO - 2023-06-11 09:07:25 --> Security Class Initialized
INFO - 2023-06-11 09:07:25 --> Input Class Initialized
INFO - 2023-06-11 09:07:25 --> Language Class Initialized
INFO - 2023-06-11 09:07:25 --> Loader Class Initialized
INFO - 2023-06-11 09:07:25 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:25 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:25 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:25 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:25 --> Controller Class Initialized
INFO - 2023-06-11 09:07:25 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:29 --> Config Class Initialized
INFO - 2023-06-11 09:07:29 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:29 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:29 --> URI Class Initialized
INFO - 2023-06-11 09:07:29 --> Router Class Initialized
INFO - 2023-06-11 09:07:29 --> Output Class Initialized
INFO - 2023-06-11 09:07:29 --> Security Class Initialized
INFO - 2023-06-11 09:07:29 --> Input Class Initialized
INFO - 2023-06-11 09:07:29 --> Language Class Initialized
INFO - 2023-06-11 09:07:29 --> Loader Class Initialized
INFO - 2023-06-11 09:07:29 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:29 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:29 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:29 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:29 --> Controller Class Initialized
INFO - 2023-06-11 09:07:29 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:29 --> Config Class Initialized
INFO - 2023-06-11 09:07:29 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:29 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:29 --> URI Class Initialized
INFO - 2023-06-11 09:07:29 --> Router Class Initialized
INFO - 2023-06-11 09:07:29 --> Output Class Initialized
INFO - 2023-06-11 09:07:29 --> Security Class Initialized
INFO - 2023-06-11 09:07:29 --> Input Class Initialized
INFO - 2023-06-11 09:07:29 --> Language Class Initialized
INFO - 2023-06-11 09:07:29 --> Loader Class Initialized
INFO - 2023-06-11 09:07:29 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:29 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:29 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:29 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:29 --> Controller Class Initialized
INFO - 2023-06-11 09:07:29 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:29 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:29 --> Config Class Initialized
INFO - 2023-06-11 09:07:29 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:29 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:29 --> URI Class Initialized
INFO - 2023-06-11 09:07:29 --> Router Class Initialized
INFO - 2023-06-11 09:07:29 --> Output Class Initialized
INFO - 2023-06-11 09:07:29 --> Security Class Initialized
INFO - 2023-06-11 09:07:29 --> Input Class Initialized
INFO - 2023-06-11 09:07:29 --> Language Class Initialized
INFO - 2023-06-11 09:07:29 --> Loader Class Initialized
INFO - 2023-06-11 09:07:29 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:29 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:29 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:30 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:30 --> Controller Class Initialized
INFO - 2023-06-11 09:07:30 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:30 --> Config Class Initialized
INFO - 2023-06-11 09:07:30 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:30 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:30 --> URI Class Initialized
INFO - 2023-06-11 09:07:30 --> Router Class Initialized
INFO - 2023-06-11 09:07:30 --> Output Class Initialized
INFO - 2023-06-11 09:07:30 --> Security Class Initialized
INFO - 2023-06-11 09:07:30 --> Input Class Initialized
INFO - 2023-06-11 09:07:30 --> Language Class Initialized
INFO - 2023-06-11 09:07:30 --> Loader Class Initialized
INFO - 2023-06-11 09:07:30 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:30 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:30 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:30 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:30 --> Controller Class Initialized
INFO - 2023-06-11 09:07:30 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:30 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:30 --> Config Class Initialized
INFO - 2023-06-11 09:07:30 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:30 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:30 --> URI Class Initialized
INFO - 2023-06-11 09:07:30 --> Router Class Initialized
INFO - 2023-06-11 09:07:30 --> Output Class Initialized
INFO - 2023-06-11 09:07:30 --> Security Class Initialized
INFO - 2023-06-11 09:07:30 --> Input Class Initialized
INFO - 2023-06-11 09:07:30 --> Language Class Initialized
INFO - 2023-06-11 09:07:30 --> Loader Class Initialized
INFO - 2023-06-11 09:07:30 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:30 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:30 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:30 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:30 --> Controller Class Initialized
INFO - 2023-06-11 09:07:30 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:30 --> Config Class Initialized
INFO - 2023-06-11 09:07:30 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:30 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:30 --> URI Class Initialized
INFO - 2023-06-11 09:07:30 --> Router Class Initialized
INFO - 2023-06-11 09:07:30 --> Output Class Initialized
INFO - 2023-06-11 09:07:30 --> Security Class Initialized
INFO - 2023-06-11 09:07:30 --> Input Class Initialized
INFO - 2023-06-11 09:07:30 --> Language Class Initialized
INFO - 2023-06-11 09:07:30 --> Loader Class Initialized
INFO - 2023-06-11 09:07:30 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:30 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:30 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:30 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:30 --> Controller Class Initialized
INFO - 2023-06-11 09:07:30 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:30 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:30 --> Config Class Initialized
INFO - 2023-06-11 09:07:30 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:30 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:30 --> URI Class Initialized
INFO - 2023-06-11 09:07:30 --> Router Class Initialized
INFO - 2023-06-11 09:07:30 --> Output Class Initialized
INFO - 2023-06-11 09:07:30 --> Security Class Initialized
INFO - 2023-06-11 09:07:30 --> Input Class Initialized
INFO - 2023-06-11 09:07:30 --> Language Class Initialized
INFO - 2023-06-11 09:07:30 --> Loader Class Initialized
INFO - 2023-06-11 09:07:30 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:30 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:30 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:30 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:30 --> Controller Class Initialized
INFO - 2023-06-11 09:07:30 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:30 --> Config Class Initialized
INFO - 2023-06-11 09:07:30 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:30 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:30 --> URI Class Initialized
INFO - 2023-06-11 09:07:30 --> Router Class Initialized
INFO - 2023-06-11 09:07:30 --> Output Class Initialized
INFO - 2023-06-11 09:07:30 --> Security Class Initialized
INFO - 2023-06-11 09:07:30 --> Input Class Initialized
INFO - 2023-06-11 09:07:30 --> Language Class Initialized
INFO - 2023-06-11 09:07:30 --> Loader Class Initialized
INFO - 2023-06-11 09:07:30 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:30 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:30 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:30 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:30 --> Controller Class Initialized
INFO - 2023-06-11 09:07:30 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:30 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:30 --> Config Class Initialized
INFO - 2023-06-11 09:07:30 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:30 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:30 --> URI Class Initialized
INFO - 2023-06-11 09:07:30 --> Router Class Initialized
INFO - 2023-06-11 09:07:30 --> Output Class Initialized
INFO - 2023-06-11 09:07:30 --> Security Class Initialized
INFO - 2023-06-11 09:07:30 --> Input Class Initialized
INFO - 2023-06-11 09:07:30 --> Language Class Initialized
INFO - 2023-06-11 09:07:30 --> Loader Class Initialized
INFO - 2023-06-11 09:07:30 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:30 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:30 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:30 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:30 --> Controller Class Initialized
INFO - 2023-06-11 09:07:30 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:30 --> Config Class Initialized
INFO - 2023-06-11 09:07:30 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:30 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:30 --> URI Class Initialized
INFO - 2023-06-11 09:07:30 --> Router Class Initialized
INFO - 2023-06-11 09:07:30 --> Output Class Initialized
INFO - 2023-06-11 09:07:30 --> Security Class Initialized
INFO - 2023-06-11 09:07:30 --> Input Class Initialized
INFO - 2023-06-11 09:07:30 --> Language Class Initialized
INFO - 2023-06-11 09:07:30 --> Loader Class Initialized
INFO - 2023-06-11 09:07:30 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:30 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:30 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:30 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:30 --> Controller Class Initialized
INFO - 2023-06-11 09:07:30 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:30 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:30 --> Config Class Initialized
INFO - 2023-06-11 09:07:30 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:30 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:30 --> URI Class Initialized
INFO - 2023-06-11 09:07:30 --> Router Class Initialized
INFO - 2023-06-11 09:07:30 --> Output Class Initialized
INFO - 2023-06-11 09:07:30 --> Security Class Initialized
INFO - 2023-06-11 09:07:30 --> Input Class Initialized
INFO - 2023-06-11 09:07:30 --> Language Class Initialized
INFO - 2023-06-11 09:07:30 --> Loader Class Initialized
INFO - 2023-06-11 09:07:30 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:30 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:30 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:30 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:30 --> Controller Class Initialized
INFO - 2023-06-11 09:07:30 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:30 --> Config Class Initialized
INFO - 2023-06-11 09:07:30 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:30 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:30 --> URI Class Initialized
INFO - 2023-06-11 09:07:30 --> Router Class Initialized
INFO - 2023-06-11 09:07:30 --> Output Class Initialized
INFO - 2023-06-11 09:07:30 --> Security Class Initialized
INFO - 2023-06-11 09:07:30 --> Input Class Initialized
INFO - 2023-06-11 09:07:30 --> Language Class Initialized
INFO - 2023-06-11 09:07:30 --> Loader Class Initialized
INFO - 2023-06-11 09:07:30 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:30 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:30 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:30 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:30 --> Controller Class Initialized
INFO - 2023-06-11 09:07:30 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:30 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:30 --> Config Class Initialized
INFO - 2023-06-11 09:07:30 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:30 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:30 --> URI Class Initialized
INFO - 2023-06-11 09:07:30 --> Router Class Initialized
INFO - 2023-06-11 09:07:30 --> Output Class Initialized
INFO - 2023-06-11 09:07:31 --> Security Class Initialized
INFO - 2023-06-11 09:07:31 --> Input Class Initialized
INFO - 2023-06-11 09:07:31 --> Language Class Initialized
INFO - 2023-06-11 09:07:31 --> Loader Class Initialized
INFO - 2023-06-11 09:07:31 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:31 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:31 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:31 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:31 --> Controller Class Initialized
INFO - 2023-06-11 09:07:31 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:31 --> Config Class Initialized
INFO - 2023-06-11 09:07:31 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:31 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:31 --> URI Class Initialized
INFO - 2023-06-11 09:07:31 --> Router Class Initialized
INFO - 2023-06-11 09:07:31 --> Output Class Initialized
INFO - 2023-06-11 09:07:31 --> Security Class Initialized
INFO - 2023-06-11 09:07:31 --> Input Class Initialized
INFO - 2023-06-11 09:07:31 --> Language Class Initialized
INFO - 2023-06-11 09:07:31 --> Loader Class Initialized
INFO - 2023-06-11 09:07:31 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:31 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:31 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:31 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:31 --> Controller Class Initialized
INFO - 2023-06-11 09:07:31 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:31 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:31 --> Config Class Initialized
INFO - 2023-06-11 09:07:31 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:31 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:31 --> URI Class Initialized
INFO - 2023-06-11 09:07:31 --> Router Class Initialized
INFO - 2023-06-11 09:07:31 --> Output Class Initialized
INFO - 2023-06-11 09:07:31 --> Security Class Initialized
INFO - 2023-06-11 09:07:31 --> Input Class Initialized
INFO - 2023-06-11 09:07:31 --> Language Class Initialized
INFO - 2023-06-11 09:07:31 --> Loader Class Initialized
INFO - 2023-06-11 09:07:31 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:31 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:31 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:31 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:31 --> Controller Class Initialized
INFO - 2023-06-11 09:07:31 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:31 --> Config Class Initialized
INFO - 2023-06-11 09:07:31 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:31 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:31 --> URI Class Initialized
INFO - 2023-06-11 09:07:31 --> Router Class Initialized
INFO - 2023-06-11 09:07:31 --> Output Class Initialized
INFO - 2023-06-11 09:07:31 --> Security Class Initialized
INFO - 2023-06-11 09:07:31 --> Input Class Initialized
INFO - 2023-06-11 09:07:31 --> Language Class Initialized
INFO - 2023-06-11 09:07:31 --> Loader Class Initialized
INFO - 2023-06-11 09:07:31 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:31 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:31 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:31 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:31 --> Controller Class Initialized
INFO - 2023-06-11 09:07:31 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:31 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:31 --> Config Class Initialized
INFO - 2023-06-11 09:07:31 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:31 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:31 --> URI Class Initialized
INFO - 2023-06-11 09:07:31 --> Router Class Initialized
INFO - 2023-06-11 09:07:31 --> Output Class Initialized
INFO - 2023-06-11 09:07:31 --> Security Class Initialized
INFO - 2023-06-11 09:07:31 --> Input Class Initialized
INFO - 2023-06-11 09:07:31 --> Language Class Initialized
INFO - 2023-06-11 09:07:31 --> Loader Class Initialized
INFO - 2023-06-11 09:07:31 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:31 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:31 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:31 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:31 --> Controller Class Initialized
INFO - 2023-06-11 09:07:31 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:31 --> Config Class Initialized
INFO - 2023-06-11 09:07:31 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:31 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:31 --> URI Class Initialized
INFO - 2023-06-11 09:07:31 --> Router Class Initialized
INFO - 2023-06-11 09:07:31 --> Output Class Initialized
INFO - 2023-06-11 09:07:31 --> Security Class Initialized
INFO - 2023-06-11 09:07:31 --> Input Class Initialized
INFO - 2023-06-11 09:07:31 --> Language Class Initialized
INFO - 2023-06-11 09:07:31 --> Loader Class Initialized
INFO - 2023-06-11 09:07:31 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:31 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:31 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:31 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:31 --> Controller Class Initialized
INFO - 2023-06-11 09:07:31 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:31 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:31 --> Config Class Initialized
INFO - 2023-06-11 09:07:31 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:31 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:31 --> URI Class Initialized
INFO - 2023-06-11 09:07:31 --> Router Class Initialized
INFO - 2023-06-11 09:07:31 --> Output Class Initialized
INFO - 2023-06-11 09:07:31 --> Security Class Initialized
INFO - 2023-06-11 09:07:31 --> Input Class Initialized
INFO - 2023-06-11 09:07:31 --> Language Class Initialized
INFO - 2023-06-11 09:07:31 --> Loader Class Initialized
INFO - 2023-06-11 09:07:31 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:31 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:31 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:31 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:31 --> Controller Class Initialized
INFO - 2023-06-11 09:07:31 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:31 --> Config Class Initialized
INFO - 2023-06-11 09:07:31 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:31 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:31 --> URI Class Initialized
INFO - 2023-06-11 09:07:31 --> Router Class Initialized
INFO - 2023-06-11 09:07:31 --> Output Class Initialized
INFO - 2023-06-11 09:07:31 --> Security Class Initialized
INFO - 2023-06-11 09:07:31 --> Input Class Initialized
INFO - 2023-06-11 09:07:31 --> Language Class Initialized
INFO - 2023-06-11 09:07:31 --> Loader Class Initialized
INFO - 2023-06-11 09:07:31 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:31 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:31 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:31 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:31 --> Controller Class Initialized
INFO - 2023-06-11 09:07:31 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:31 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:33 --> Config Class Initialized
INFO - 2023-06-11 09:07:33 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:33 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:33 --> URI Class Initialized
INFO - 2023-06-11 09:07:33 --> Router Class Initialized
INFO - 2023-06-11 09:07:33 --> Output Class Initialized
INFO - 2023-06-11 09:07:33 --> Security Class Initialized
INFO - 2023-06-11 09:07:33 --> Input Class Initialized
INFO - 2023-06-11 09:07:33 --> Language Class Initialized
INFO - 2023-06-11 09:07:33 --> Loader Class Initialized
INFO - 2023-06-11 09:07:33 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:33 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:33 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:33 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:33 --> Controller Class Initialized
INFO - 2023-06-11 09:07:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 09:07:33 --> Final output sent to browser
INFO - 2023-06-11 09:07:35 --> Config Class Initialized
INFO - 2023-06-11 09:07:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:35 --> URI Class Initialized
INFO - 2023-06-11 09:07:35 --> Router Class Initialized
INFO - 2023-06-11 09:07:35 --> Output Class Initialized
INFO - 2023-06-11 09:07:35 --> Security Class Initialized
INFO - 2023-06-11 09:07:35 --> Input Class Initialized
INFO - 2023-06-11 09:07:35 --> Language Class Initialized
INFO - 2023-06-11 09:07:35 --> Loader Class Initialized
INFO - 2023-06-11 09:07:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:35 --> Controller Class Initialized
INFO - 2023-06-11 09:07:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:35 --> Config Class Initialized
INFO - 2023-06-11 09:07:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:35 --> URI Class Initialized
INFO - 2023-06-11 09:07:35 --> Router Class Initialized
INFO - 2023-06-11 09:07:35 --> Output Class Initialized
INFO - 2023-06-11 09:07:35 --> Security Class Initialized
INFO - 2023-06-11 09:07:35 --> Input Class Initialized
INFO - 2023-06-11 09:07:35 --> Language Class Initialized
INFO - 2023-06-11 09:07:35 --> Loader Class Initialized
INFO - 2023-06-11 09:07:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:35 --> Controller Class Initialized
INFO - 2023-06-11 09:07:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:35 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:35 --> Config Class Initialized
INFO - 2023-06-11 09:07:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:35 --> URI Class Initialized
INFO - 2023-06-11 09:07:35 --> Router Class Initialized
INFO - 2023-06-11 09:07:35 --> Output Class Initialized
INFO - 2023-06-11 09:07:35 --> Security Class Initialized
INFO - 2023-06-11 09:07:35 --> Input Class Initialized
INFO - 2023-06-11 09:07:35 --> Language Class Initialized
INFO - 2023-06-11 09:07:35 --> Loader Class Initialized
INFO - 2023-06-11 09:07:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:35 --> Controller Class Initialized
INFO - 2023-06-11 09:07:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:35 --> Config Class Initialized
INFO - 2023-06-11 09:07:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:35 --> URI Class Initialized
INFO - 2023-06-11 09:07:35 --> Router Class Initialized
INFO - 2023-06-11 09:07:35 --> Output Class Initialized
INFO - 2023-06-11 09:07:35 --> Security Class Initialized
INFO - 2023-06-11 09:07:35 --> Input Class Initialized
INFO - 2023-06-11 09:07:35 --> Language Class Initialized
INFO - 2023-06-11 09:07:35 --> Loader Class Initialized
INFO - 2023-06-11 09:07:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:35 --> Controller Class Initialized
INFO - 2023-06-11 09:07:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:35 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:35 --> Config Class Initialized
INFO - 2023-06-11 09:07:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:35 --> URI Class Initialized
INFO - 2023-06-11 09:07:35 --> Router Class Initialized
INFO - 2023-06-11 09:07:35 --> Output Class Initialized
INFO - 2023-06-11 09:07:35 --> Security Class Initialized
INFO - 2023-06-11 09:07:35 --> Input Class Initialized
INFO - 2023-06-11 09:07:35 --> Language Class Initialized
INFO - 2023-06-11 09:07:35 --> Loader Class Initialized
INFO - 2023-06-11 09:07:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:35 --> Controller Class Initialized
INFO - 2023-06-11 09:07:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:35 --> Config Class Initialized
INFO - 2023-06-11 09:07:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:35 --> URI Class Initialized
INFO - 2023-06-11 09:07:35 --> Router Class Initialized
INFO - 2023-06-11 09:07:35 --> Output Class Initialized
INFO - 2023-06-11 09:07:35 --> Security Class Initialized
INFO - 2023-06-11 09:07:35 --> Input Class Initialized
INFO - 2023-06-11 09:07:35 --> Language Class Initialized
INFO - 2023-06-11 09:07:35 --> Loader Class Initialized
INFO - 2023-06-11 09:07:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:35 --> Controller Class Initialized
INFO - 2023-06-11 09:07:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:35 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:35 --> Config Class Initialized
INFO - 2023-06-11 09:07:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:35 --> URI Class Initialized
INFO - 2023-06-11 09:07:35 --> Router Class Initialized
INFO - 2023-06-11 09:07:35 --> Output Class Initialized
INFO - 2023-06-11 09:07:35 --> Security Class Initialized
INFO - 2023-06-11 09:07:35 --> Input Class Initialized
INFO - 2023-06-11 09:07:35 --> Language Class Initialized
INFO - 2023-06-11 09:07:35 --> Loader Class Initialized
INFO - 2023-06-11 09:07:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:35 --> Controller Class Initialized
INFO - 2023-06-11 09:07:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:35 --> Config Class Initialized
INFO - 2023-06-11 09:07:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:35 --> URI Class Initialized
INFO - 2023-06-11 09:07:35 --> Router Class Initialized
INFO - 2023-06-11 09:07:35 --> Output Class Initialized
INFO - 2023-06-11 09:07:35 --> Security Class Initialized
INFO - 2023-06-11 09:07:35 --> Input Class Initialized
INFO - 2023-06-11 09:07:35 --> Language Class Initialized
INFO - 2023-06-11 09:07:36 --> Loader Class Initialized
INFO - 2023-06-11 09:07:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:36 --> Controller Class Initialized
INFO - 2023-06-11 09:07:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:36 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:36 --> Config Class Initialized
INFO - 2023-06-11 09:07:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:36 --> URI Class Initialized
INFO - 2023-06-11 09:07:36 --> Router Class Initialized
INFO - 2023-06-11 09:07:36 --> Output Class Initialized
INFO - 2023-06-11 09:07:36 --> Security Class Initialized
INFO - 2023-06-11 09:07:36 --> Input Class Initialized
INFO - 2023-06-11 09:07:36 --> Language Class Initialized
INFO - 2023-06-11 09:07:36 --> Loader Class Initialized
INFO - 2023-06-11 09:07:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:36 --> Controller Class Initialized
INFO - 2023-06-11 09:07:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:36 --> Config Class Initialized
INFO - 2023-06-11 09:07:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:36 --> URI Class Initialized
INFO - 2023-06-11 09:07:36 --> Router Class Initialized
INFO - 2023-06-11 09:07:36 --> Output Class Initialized
INFO - 2023-06-11 09:07:36 --> Security Class Initialized
INFO - 2023-06-11 09:07:36 --> Input Class Initialized
INFO - 2023-06-11 09:07:36 --> Language Class Initialized
INFO - 2023-06-11 09:07:36 --> Loader Class Initialized
INFO - 2023-06-11 09:07:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:36 --> Controller Class Initialized
INFO - 2023-06-11 09:07:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:36 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:36 --> Config Class Initialized
INFO - 2023-06-11 09:07:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:36 --> URI Class Initialized
INFO - 2023-06-11 09:07:36 --> Router Class Initialized
INFO - 2023-06-11 09:07:36 --> Output Class Initialized
INFO - 2023-06-11 09:07:36 --> Security Class Initialized
INFO - 2023-06-11 09:07:36 --> Input Class Initialized
INFO - 2023-06-11 09:07:36 --> Language Class Initialized
INFO - 2023-06-11 09:07:36 --> Loader Class Initialized
INFO - 2023-06-11 09:07:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:36 --> Controller Class Initialized
INFO - 2023-06-11 09:07:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:36 --> Config Class Initialized
INFO - 2023-06-11 09:07:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:36 --> URI Class Initialized
INFO - 2023-06-11 09:07:36 --> Router Class Initialized
INFO - 2023-06-11 09:07:36 --> Output Class Initialized
INFO - 2023-06-11 09:07:36 --> Security Class Initialized
INFO - 2023-06-11 09:07:36 --> Input Class Initialized
INFO - 2023-06-11 09:07:36 --> Language Class Initialized
INFO - 2023-06-11 09:07:36 --> Loader Class Initialized
INFO - 2023-06-11 09:07:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:36 --> Controller Class Initialized
INFO - 2023-06-11 09:07:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:36 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:36 --> Config Class Initialized
INFO - 2023-06-11 09:07:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:36 --> URI Class Initialized
INFO - 2023-06-11 09:07:36 --> Router Class Initialized
INFO - 2023-06-11 09:07:36 --> Output Class Initialized
INFO - 2023-06-11 09:07:36 --> Security Class Initialized
INFO - 2023-06-11 09:07:36 --> Input Class Initialized
INFO - 2023-06-11 09:07:36 --> Language Class Initialized
INFO - 2023-06-11 09:07:36 --> Loader Class Initialized
INFO - 2023-06-11 09:07:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:36 --> Controller Class Initialized
INFO - 2023-06-11 09:07:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:36 --> Config Class Initialized
INFO - 2023-06-11 09:07:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:36 --> URI Class Initialized
INFO - 2023-06-11 09:07:36 --> Router Class Initialized
INFO - 2023-06-11 09:07:36 --> Output Class Initialized
INFO - 2023-06-11 09:07:36 --> Security Class Initialized
INFO - 2023-06-11 09:07:36 --> Input Class Initialized
INFO - 2023-06-11 09:07:36 --> Language Class Initialized
INFO - 2023-06-11 09:07:36 --> Loader Class Initialized
INFO - 2023-06-11 09:07:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:36 --> Controller Class Initialized
INFO - 2023-06-11 09:07:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:36 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:36 --> Config Class Initialized
INFO - 2023-06-11 09:07:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:36 --> URI Class Initialized
INFO - 2023-06-11 09:07:36 --> Router Class Initialized
INFO - 2023-06-11 09:07:36 --> Output Class Initialized
INFO - 2023-06-11 09:07:36 --> Security Class Initialized
INFO - 2023-06-11 09:07:36 --> Input Class Initialized
INFO - 2023-06-11 09:07:36 --> Language Class Initialized
INFO - 2023-06-11 09:07:36 --> Loader Class Initialized
INFO - 2023-06-11 09:07:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:36 --> Controller Class Initialized
INFO - 2023-06-11 09:07:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:36 --> Config Class Initialized
INFO - 2023-06-11 09:07:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:36 --> URI Class Initialized
INFO - 2023-06-11 09:07:36 --> Router Class Initialized
INFO - 2023-06-11 09:07:36 --> Output Class Initialized
INFO - 2023-06-11 09:07:36 --> Security Class Initialized
INFO - 2023-06-11 09:07:36 --> Input Class Initialized
INFO - 2023-06-11 09:07:36 --> Language Class Initialized
INFO - 2023-06-11 09:07:36 --> Loader Class Initialized
INFO - 2023-06-11 09:07:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:36 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:36 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:36 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:36 --> Controller Class Initialized
INFO - 2023-06-11 09:07:36 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:36 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:36 --> Config Class Initialized
INFO - 2023-06-11 09:07:36 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:36 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:36 --> URI Class Initialized
INFO - 2023-06-11 09:07:36 --> Router Class Initialized
INFO - 2023-06-11 09:07:36 --> Output Class Initialized
INFO - 2023-06-11 09:07:36 --> Security Class Initialized
INFO - 2023-06-11 09:07:36 --> Input Class Initialized
INFO - 2023-06-11 09:07:36 --> Language Class Initialized
INFO - 2023-06-11 09:07:36 --> Loader Class Initialized
INFO - 2023-06-11 09:07:36 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:37 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:37 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:37 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:37 --> Controller Class Initialized
INFO - 2023-06-11 09:07:37 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:37 --> Config Class Initialized
INFO - 2023-06-11 09:07:37 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:37 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:37 --> URI Class Initialized
INFO - 2023-06-11 09:07:37 --> Router Class Initialized
INFO - 2023-06-11 09:07:37 --> Output Class Initialized
INFO - 2023-06-11 09:07:37 --> Security Class Initialized
INFO - 2023-06-11 09:07:37 --> Input Class Initialized
INFO - 2023-06-11 09:07:37 --> Language Class Initialized
INFO - 2023-06-11 09:07:37 --> Loader Class Initialized
INFO - 2023-06-11 09:07:37 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:37 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:37 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:37 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:37 --> Controller Class Initialized
INFO - 2023-06-11 09:07:37 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:37 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:37 --> Config Class Initialized
INFO - 2023-06-11 09:07:37 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:37 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:37 --> URI Class Initialized
INFO - 2023-06-11 09:07:37 --> Router Class Initialized
INFO - 2023-06-11 09:07:37 --> Output Class Initialized
INFO - 2023-06-11 09:07:37 --> Security Class Initialized
INFO - 2023-06-11 09:07:37 --> Input Class Initialized
INFO - 2023-06-11 09:07:37 --> Language Class Initialized
INFO - 2023-06-11 09:07:37 --> Loader Class Initialized
INFO - 2023-06-11 09:07:37 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:37 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:37 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:37 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:37 --> Controller Class Initialized
INFO - 2023-06-11 09:07:37 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:37 --> Config Class Initialized
INFO - 2023-06-11 09:07:37 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:37 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:37 --> URI Class Initialized
INFO - 2023-06-11 09:07:37 --> Router Class Initialized
INFO - 2023-06-11 09:07:37 --> Output Class Initialized
INFO - 2023-06-11 09:07:37 --> Security Class Initialized
INFO - 2023-06-11 09:07:37 --> Input Class Initialized
INFO - 2023-06-11 09:07:37 --> Language Class Initialized
INFO - 2023-06-11 09:07:37 --> Loader Class Initialized
INFO - 2023-06-11 09:07:37 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:37 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:37 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:37 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:37 --> Controller Class Initialized
INFO - 2023-06-11 09:07:37 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:37 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:38 --> Config Class Initialized
INFO - 2023-06-11 09:07:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:38 --> URI Class Initialized
INFO - 2023-06-11 09:07:38 --> Router Class Initialized
INFO - 2023-06-11 09:07:38 --> Output Class Initialized
INFO - 2023-06-11 09:07:38 --> Security Class Initialized
INFO - 2023-06-11 09:07:38 --> Input Class Initialized
INFO - 2023-06-11 09:07:38 --> Language Class Initialized
INFO - 2023-06-11 09:07:38 --> Loader Class Initialized
INFO - 2023-06-11 09:07:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:38 --> Controller Class Initialized
INFO - 2023-06-11 09:07:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:38 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:38 --> Config Class Initialized
INFO - 2023-06-11 09:07:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:38 --> URI Class Initialized
INFO - 2023-06-11 09:07:38 --> Router Class Initialized
INFO - 2023-06-11 09:07:38 --> Output Class Initialized
INFO - 2023-06-11 09:07:38 --> Security Class Initialized
INFO - 2023-06-11 09:07:38 --> Input Class Initialized
INFO - 2023-06-11 09:07:38 --> Language Class Initialized
INFO - 2023-06-11 09:07:38 --> Loader Class Initialized
INFO - 2023-06-11 09:07:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:38 --> Controller Class Initialized
INFO - 2023-06-11 09:07:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:38 --> Config Class Initialized
INFO - 2023-06-11 09:07:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:38 --> URI Class Initialized
INFO - 2023-06-11 09:07:38 --> Router Class Initialized
INFO - 2023-06-11 09:07:38 --> Output Class Initialized
INFO - 2023-06-11 09:07:38 --> Security Class Initialized
INFO - 2023-06-11 09:07:38 --> Input Class Initialized
INFO - 2023-06-11 09:07:38 --> Language Class Initialized
INFO - 2023-06-11 09:07:38 --> Loader Class Initialized
INFO - 2023-06-11 09:07:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:38 --> Controller Class Initialized
INFO - 2023-06-11 09:07:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:38 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:38 --> Config Class Initialized
INFO - 2023-06-11 09:07:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:38 --> URI Class Initialized
INFO - 2023-06-11 09:07:38 --> Router Class Initialized
INFO - 2023-06-11 09:07:38 --> Output Class Initialized
INFO - 2023-06-11 09:07:38 --> Security Class Initialized
INFO - 2023-06-11 09:07:38 --> Input Class Initialized
INFO - 2023-06-11 09:07:38 --> Language Class Initialized
INFO - 2023-06-11 09:07:38 --> Loader Class Initialized
INFO - 2023-06-11 09:07:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:38 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:38 --> Controller Class Initialized
INFO - 2023-06-11 09:07:38 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:38 --> Config Class Initialized
INFO - 2023-06-11 09:07:38 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:38 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:38 --> URI Class Initialized
INFO - 2023-06-11 09:07:38 --> Router Class Initialized
INFO - 2023-06-11 09:07:38 --> Output Class Initialized
INFO - 2023-06-11 09:07:38 --> Security Class Initialized
INFO - 2023-06-11 09:07:38 --> Input Class Initialized
INFO - 2023-06-11 09:07:38 --> Language Class Initialized
INFO - 2023-06-11 09:07:38 --> Loader Class Initialized
INFO - 2023-06-11 09:07:38 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:38 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:38 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:39 --> Controller Class Initialized
INFO - 2023-06-11 09:07:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:39 --> Config Class Initialized
INFO - 2023-06-11 09:07:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:39 --> URI Class Initialized
INFO - 2023-06-11 09:07:39 --> Router Class Initialized
INFO - 2023-06-11 09:07:39 --> Output Class Initialized
INFO - 2023-06-11 09:07:39 --> Security Class Initialized
INFO - 2023-06-11 09:07:39 --> Input Class Initialized
INFO - 2023-06-11 09:07:39 --> Language Class Initialized
INFO - 2023-06-11 09:07:39 --> Loader Class Initialized
INFO - 2023-06-11 09:07:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:39 --> Controller Class Initialized
INFO - 2023-06-11 09:07:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:39 --> Config Class Initialized
INFO - 2023-06-11 09:07:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:39 --> URI Class Initialized
INFO - 2023-06-11 09:07:39 --> Router Class Initialized
INFO - 2023-06-11 09:07:39 --> Output Class Initialized
INFO - 2023-06-11 09:07:39 --> Security Class Initialized
INFO - 2023-06-11 09:07:39 --> Input Class Initialized
INFO - 2023-06-11 09:07:39 --> Language Class Initialized
INFO - 2023-06-11 09:07:39 --> Loader Class Initialized
INFO - 2023-06-11 09:07:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:39 --> Controller Class Initialized
INFO - 2023-06-11 09:07:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:39 --> Config Class Initialized
INFO - 2023-06-11 09:07:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:39 --> URI Class Initialized
INFO - 2023-06-11 09:07:39 --> Router Class Initialized
INFO - 2023-06-11 09:07:39 --> Output Class Initialized
INFO - 2023-06-11 09:07:39 --> Security Class Initialized
INFO - 2023-06-11 09:07:39 --> Input Class Initialized
INFO - 2023-06-11 09:07:39 --> Language Class Initialized
INFO - 2023-06-11 09:07:39 --> Loader Class Initialized
INFO - 2023-06-11 09:07:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:39 --> Controller Class Initialized
INFO - 2023-06-11 09:07:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:39 --> Config Class Initialized
INFO - 2023-06-11 09:07:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:39 --> URI Class Initialized
INFO - 2023-06-11 09:07:39 --> Router Class Initialized
INFO - 2023-06-11 09:07:39 --> Output Class Initialized
INFO - 2023-06-11 09:07:39 --> Security Class Initialized
INFO - 2023-06-11 09:07:39 --> Input Class Initialized
INFO - 2023-06-11 09:07:39 --> Language Class Initialized
INFO - 2023-06-11 09:07:39 --> Loader Class Initialized
INFO - 2023-06-11 09:07:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:39 --> Controller Class Initialized
INFO - 2023-06-11 09:07:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:39 --> Config Class Initialized
INFO - 2023-06-11 09:07:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:39 --> URI Class Initialized
INFO - 2023-06-11 09:07:39 --> Router Class Initialized
INFO - 2023-06-11 09:07:39 --> Output Class Initialized
INFO - 2023-06-11 09:07:39 --> Security Class Initialized
INFO - 2023-06-11 09:07:39 --> Input Class Initialized
INFO - 2023-06-11 09:07:39 --> Language Class Initialized
INFO - 2023-06-11 09:07:39 --> Loader Class Initialized
INFO - 2023-06-11 09:07:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:39 --> Controller Class Initialized
INFO - 2023-06-11 09:07:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:39 --> Config Class Initialized
INFO - 2023-06-11 09:07:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:39 --> URI Class Initialized
INFO - 2023-06-11 09:07:39 --> Router Class Initialized
INFO - 2023-06-11 09:07:39 --> Output Class Initialized
INFO - 2023-06-11 09:07:39 --> Security Class Initialized
INFO - 2023-06-11 09:07:39 --> Input Class Initialized
INFO - 2023-06-11 09:07:39 --> Language Class Initialized
INFO - 2023-06-11 09:07:39 --> Loader Class Initialized
INFO - 2023-06-11 09:07:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:39 --> Controller Class Initialized
INFO - 2023-06-11 09:07:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:39 --> Config Class Initialized
INFO - 2023-06-11 09:07:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:39 --> URI Class Initialized
INFO - 2023-06-11 09:07:39 --> Router Class Initialized
INFO - 2023-06-11 09:07:39 --> Output Class Initialized
INFO - 2023-06-11 09:07:39 --> Security Class Initialized
INFO - 2023-06-11 09:07:39 --> Input Class Initialized
INFO - 2023-06-11 09:07:39 --> Language Class Initialized
INFO - 2023-06-11 09:07:39 --> Loader Class Initialized
INFO - 2023-06-11 09:07:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:39 --> Controller Class Initialized
INFO - 2023-06-11 09:07:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:39 --> Config Class Initialized
INFO - 2023-06-11 09:07:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:39 --> URI Class Initialized
INFO - 2023-06-11 09:07:39 --> Router Class Initialized
INFO - 2023-06-11 09:07:39 --> Output Class Initialized
INFO - 2023-06-11 09:07:39 --> Security Class Initialized
INFO - 2023-06-11 09:07:39 --> Input Class Initialized
INFO - 2023-06-11 09:07:39 --> Language Class Initialized
INFO - 2023-06-11 09:07:39 --> Loader Class Initialized
INFO - 2023-06-11 09:07:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:39 --> Controller Class Initialized
INFO - 2023-06-11 09:07:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:39 --> Config Class Initialized
INFO - 2023-06-11 09:07:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:39 --> URI Class Initialized
INFO - 2023-06-11 09:07:39 --> Router Class Initialized
INFO - 2023-06-11 09:07:39 --> Output Class Initialized
INFO - 2023-06-11 09:07:39 --> Security Class Initialized
INFO - 2023-06-11 09:07:39 --> Input Class Initialized
INFO - 2023-06-11 09:07:39 --> Language Class Initialized
INFO - 2023-06-11 09:07:39 --> Loader Class Initialized
INFO - 2023-06-11 09:07:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:39 --> Controller Class Initialized
INFO - 2023-06-11 09:07:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:40 --> Config Class Initialized
INFO - 2023-06-11 09:07:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:40 --> URI Class Initialized
INFO - 2023-06-11 09:07:40 --> Router Class Initialized
INFO - 2023-06-11 09:07:40 --> Output Class Initialized
INFO - 2023-06-11 09:07:40 --> Security Class Initialized
INFO - 2023-06-11 09:07:40 --> Input Class Initialized
INFO - 2023-06-11 09:07:40 --> Language Class Initialized
INFO - 2023-06-11 09:07:40 --> Loader Class Initialized
INFO - 2023-06-11 09:07:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:40 --> Controller Class Initialized
INFO - 2023-06-11 09:07:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:40 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:40 --> Config Class Initialized
INFO - 2023-06-11 09:07:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:40 --> URI Class Initialized
INFO - 2023-06-11 09:07:40 --> Router Class Initialized
INFO - 2023-06-11 09:07:40 --> Output Class Initialized
INFO - 2023-06-11 09:07:40 --> Security Class Initialized
INFO - 2023-06-11 09:07:40 --> Input Class Initialized
INFO - 2023-06-11 09:07:40 --> Language Class Initialized
INFO - 2023-06-11 09:07:40 --> Loader Class Initialized
INFO - 2023-06-11 09:07:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:40 --> Controller Class Initialized
INFO - 2023-06-11 09:07:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:40 --> Config Class Initialized
INFO - 2023-06-11 09:07:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:40 --> URI Class Initialized
INFO - 2023-06-11 09:07:40 --> Router Class Initialized
INFO - 2023-06-11 09:07:40 --> Output Class Initialized
INFO - 2023-06-11 09:07:40 --> Security Class Initialized
INFO - 2023-06-11 09:07:40 --> Input Class Initialized
INFO - 2023-06-11 09:07:40 --> Language Class Initialized
INFO - 2023-06-11 09:07:40 --> Loader Class Initialized
INFO - 2023-06-11 09:07:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:40 --> Controller Class Initialized
INFO - 2023-06-11 09:07:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:40 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:40 --> Config Class Initialized
INFO - 2023-06-11 09:07:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:40 --> URI Class Initialized
INFO - 2023-06-11 09:07:40 --> Router Class Initialized
INFO - 2023-06-11 09:07:40 --> Output Class Initialized
INFO - 2023-06-11 09:07:40 --> Security Class Initialized
INFO - 2023-06-11 09:07:40 --> Input Class Initialized
INFO - 2023-06-11 09:07:40 --> Language Class Initialized
INFO - 2023-06-11 09:07:40 --> Loader Class Initialized
INFO - 2023-06-11 09:07:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:40 --> Controller Class Initialized
INFO - 2023-06-11 09:07:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:40 --> Config Class Initialized
INFO - 2023-06-11 09:07:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:40 --> URI Class Initialized
INFO - 2023-06-11 09:07:40 --> Router Class Initialized
INFO - 2023-06-11 09:07:40 --> Output Class Initialized
INFO - 2023-06-11 09:07:40 --> Security Class Initialized
INFO - 2023-06-11 09:07:40 --> Input Class Initialized
INFO - 2023-06-11 09:07:40 --> Language Class Initialized
INFO - 2023-06-11 09:07:40 --> Loader Class Initialized
INFO - 2023-06-11 09:07:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:40 --> Controller Class Initialized
INFO - 2023-06-11 09:07:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:40 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:40 --> Config Class Initialized
INFO - 2023-06-11 09:07:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:40 --> URI Class Initialized
INFO - 2023-06-11 09:07:40 --> Router Class Initialized
INFO - 2023-06-11 09:07:40 --> Output Class Initialized
INFO - 2023-06-11 09:07:40 --> Security Class Initialized
INFO - 2023-06-11 09:07:40 --> Input Class Initialized
INFO - 2023-06-11 09:07:40 --> Language Class Initialized
INFO - 2023-06-11 09:07:40 --> Loader Class Initialized
INFO - 2023-06-11 09:07:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:40 --> Controller Class Initialized
INFO - 2023-06-11 09:07:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:44 --> Config Class Initialized
INFO - 2023-06-11 09:07:44 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:44 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:44 --> URI Class Initialized
INFO - 2023-06-11 09:07:44 --> Router Class Initialized
INFO - 2023-06-11 09:07:44 --> Output Class Initialized
INFO - 2023-06-11 09:07:44 --> Security Class Initialized
INFO - 2023-06-11 09:07:44 --> Input Class Initialized
INFO - 2023-06-11 09:07:44 --> Language Class Initialized
INFO - 2023-06-11 09:07:44 --> Loader Class Initialized
INFO - 2023-06-11 09:07:44 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:44 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:44 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:44 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:44 --> Controller Class Initialized
INFO - 2023-06-11 09:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 09:07:44 --> Final output sent to browser
INFO - 2023-06-11 09:07:47 --> Config Class Initialized
INFO - 2023-06-11 09:07:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:47 --> URI Class Initialized
INFO - 2023-06-11 09:07:47 --> Router Class Initialized
INFO - 2023-06-11 09:07:47 --> Output Class Initialized
INFO - 2023-06-11 09:07:47 --> Security Class Initialized
INFO - 2023-06-11 09:07:47 --> Input Class Initialized
INFO - 2023-06-11 09:07:47 --> Language Class Initialized
INFO - 2023-06-11 09:07:47 --> Loader Class Initialized
INFO - 2023-06-11 09:07:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:47 --> Controller Class Initialized
INFO - 2023-06-11 09:07:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 09:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-11 09:07:47 --> Final output sent to browser
INFO - 2023-06-11 09:07:49 --> Config Class Initialized
INFO - 2023-06-11 09:07:49 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:49 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:49 --> URI Class Initialized
INFO - 2023-06-11 09:07:49 --> Router Class Initialized
INFO - 2023-06-11 09:07:49 --> Output Class Initialized
INFO - 2023-06-11 09:07:49 --> Security Class Initialized
INFO - 2023-06-11 09:07:49 --> Input Class Initialized
INFO - 2023-06-11 09:07:49 --> Language Class Initialized
INFO - 2023-06-11 09:07:49 --> Loader Class Initialized
INFO - 2023-06-11 09:07:49 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:49 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:49 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:49 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:49 --> Controller Class Initialized
INFO - 2023-06-11 09:07:49 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:49 --> Config Class Initialized
INFO - 2023-06-11 09:07:49 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:49 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:49 --> URI Class Initialized
INFO - 2023-06-11 09:07:49 --> Router Class Initialized
INFO - 2023-06-11 09:07:49 --> Output Class Initialized
INFO - 2023-06-11 09:07:49 --> Security Class Initialized
INFO - 2023-06-11 09:07:49 --> Input Class Initialized
INFO - 2023-06-11 09:07:49 --> Language Class Initialized
INFO - 2023-06-11 09:07:49 --> Loader Class Initialized
INFO - 2023-06-11 09:07:49 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:49 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:49 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:49 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:49 --> Controller Class Initialized
INFO - 2023-06-11 09:07:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 09:07:49 --> Final output sent to browser
INFO - 2023-06-11 09:07:50 --> Config Class Initialized
INFO - 2023-06-11 09:07:50 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:50 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:50 --> URI Class Initialized
INFO - 2023-06-11 09:07:50 --> Router Class Initialized
INFO - 2023-06-11 09:07:50 --> Output Class Initialized
INFO - 2023-06-11 09:07:50 --> Security Class Initialized
INFO - 2023-06-11 09:07:50 --> Input Class Initialized
INFO - 2023-06-11 09:07:50 --> Language Class Initialized
INFO - 2023-06-11 09:07:50 --> Loader Class Initialized
INFO - 2023-06-11 09:07:50 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:50 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:50 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:50 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:50 --> Controller Class Initialized
INFO - 2023-06-11 09:07:50 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-11 09:07:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-11 09:07:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-11 09:07:50 --> Final output sent to browser
INFO - 2023-06-11 09:07:54 --> Config Class Initialized
INFO - 2023-06-11 09:07:54 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:54 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:54 --> URI Class Initialized
INFO - 2023-06-11 09:07:54 --> Router Class Initialized
INFO - 2023-06-11 09:07:54 --> Output Class Initialized
INFO - 2023-06-11 09:07:54 --> Security Class Initialized
INFO - 2023-06-11 09:07:54 --> Input Class Initialized
INFO - 2023-06-11 09:07:54 --> Language Class Initialized
INFO - 2023-06-11 09:07:54 --> Loader Class Initialized
INFO - 2023-06-11 09:07:54 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:54 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:54 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:54 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:54 --> Controller Class Initialized
INFO - 2023-06-11 09:07:54 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:54 --> Config Class Initialized
INFO - 2023-06-11 09:07:54 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:54 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:54 --> URI Class Initialized
INFO - 2023-06-11 09:07:54 --> Router Class Initialized
INFO - 2023-06-11 09:07:54 --> Output Class Initialized
INFO - 2023-06-11 09:07:54 --> Security Class Initialized
INFO - 2023-06-11 09:07:54 --> Input Class Initialized
INFO - 2023-06-11 09:07:54 --> Language Class Initialized
INFO - 2023-06-11 09:07:54 --> Loader Class Initialized
INFO - 2023-06-11 09:07:54 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:54 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:54 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:54 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:54 --> Controller Class Initialized
INFO - 2023-06-11 09:07:54 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:54 --> Model "m_datatrain" initialized
INFO - 2023-06-11 09:07:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:07:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:07:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:07:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:07:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:07:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 09:07:54 --> Final output sent to browser
INFO - 2023-06-11 09:07:56 --> Config Class Initialized
INFO - 2023-06-11 09:07:56 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:56 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:56 --> URI Class Initialized
INFO - 2023-06-11 09:07:56 --> Router Class Initialized
INFO - 2023-06-11 09:07:56 --> Output Class Initialized
INFO - 2023-06-11 09:07:56 --> Security Class Initialized
INFO - 2023-06-11 09:07:56 --> Input Class Initialized
INFO - 2023-06-11 09:07:56 --> Language Class Initialized
INFO - 2023-06-11 09:07:56 --> Loader Class Initialized
INFO - 2023-06-11 09:07:56 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:56 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:56 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:56 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:56 --> Controller Class Initialized
INFO - 2023-06-11 09:07:56 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:07:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:07:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 09:07:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:07:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:07:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:07:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:07:57 --> Final output sent to browser
INFO - 2023-06-11 09:07:58 --> Config Class Initialized
INFO - 2023-06-11 09:07:58 --> Hooks Class Initialized
INFO - 2023-06-11 09:07:58 --> Utf8 Class Initialized
INFO - 2023-06-11 09:07:58 --> URI Class Initialized
INFO - 2023-06-11 09:07:58 --> Router Class Initialized
INFO - 2023-06-11 09:07:58 --> Output Class Initialized
INFO - 2023-06-11 09:07:58 --> Security Class Initialized
INFO - 2023-06-11 09:07:58 --> Input Class Initialized
INFO - 2023-06-11 09:07:58 --> Language Class Initialized
INFO - 2023-06-11 09:07:58 --> Loader Class Initialized
INFO - 2023-06-11 09:07:58 --> Helper loaded: url_helper
INFO - 2023-06-11 09:07:58 --> Helper loaded: form_helper
INFO - 2023-06-11 09:07:58 --> Database Driver Class Initialized
INFO - 2023-06-11 09:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:07:58 --> Form Validation Class Initialized
INFO - 2023-06-11 09:07:58 --> Controller Class Initialized
INFO - 2023-06-11 09:07:58 --> Model "m_user" initialized
INFO - 2023-06-11 09:07:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:07:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:07:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:07:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:07:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:07:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:07:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:07:58 --> Final output sent to browser
INFO - 2023-06-11 09:08:07 --> Config Class Initialized
INFO - 2023-06-11 09:08:07 --> Hooks Class Initialized
INFO - 2023-06-11 09:08:07 --> Utf8 Class Initialized
INFO - 2023-06-11 09:08:07 --> URI Class Initialized
INFO - 2023-06-11 09:08:07 --> Router Class Initialized
INFO - 2023-06-11 09:08:07 --> Output Class Initialized
INFO - 2023-06-11 09:08:07 --> Security Class Initialized
INFO - 2023-06-11 09:08:07 --> Input Class Initialized
INFO - 2023-06-11 09:08:07 --> Language Class Initialized
INFO - 2023-06-11 09:08:07 --> Loader Class Initialized
INFO - 2023-06-11 09:08:07 --> Helper loaded: url_helper
INFO - 2023-06-11 09:08:07 --> Helper loaded: form_helper
INFO - 2023-06-11 09:08:07 --> Database Driver Class Initialized
INFO - 2023-06-11 09:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:08:07 --> Form Validation Class Initialized
INFO - 2023-06-11 09:08:07 --> Controller Class Initialized
INFO - 2023-06-11 09:08:07 --> Model "m_user" initialized
ERROR - 2023-06-11 09:08:07 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 30
INFO - 2023-06-11 09:08:07 --> Config Class Initialized
INFO - 2023-06-11 09:08:07 --> Hooks Class Initialized
INFO - 2023-06-11 09:08:07 --> Utf8 Class Initialized
INFO - 2023-06-11 09:08:07 --> URI Class Initialized
INFO - 2023-06-11 09:08:07 --> Router Class Initialized
INFO - 2023-06-11 09:08:07 --> Output Class Initialized
INFO - 2023-06-11 09:08:07 --> Security Class Initialized
INFO - 2023-06-11 09:08:07 --> Input Class Initialized
INFO - 2023-06-11 09:08:07 --> Language Class Initialized
INFO - 2023-06-11 09:08:07 --> Loader Class Initialized
INFO - 2023-06-11 09:08:07 --> Helper loaded: url_helper
INFO - 2023-06-11 09:08:07 --> Helper loaded: form_helper
INFO - 2023-06-11 09:08:07 --> Database Driver Class Initialized
INFO - 2023-06-11 09:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:08:07 --> Form Validation Class Initialized
INFO - 2023-06-11 09:08:07 --> Controller Class Initialized
INFO - 2023-06-11 09:08:07 --> Model "m_user" initialized
INFO - 2023-06-11 09:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:08:07 --> Final output sent to browser
INFO - 2023-06-11 09:13:00 --> Config Class Initialized
INFO - 2023-06-11 09:13:00 --> Hooks Class Initialized
INFO - 2023-06-11 09:13:00 --> Utf8 Class Initialized
INFO - 2023-06-11 09:13:00 --> URI Class Initialized
INFO - 2023-06-11 09:13:00 --> Router Class Initialized
INFO - 2023-06-11 09:13:00 --> Output Class Initialized
INFO - 2023-06-11 09:13:00 --> Security Class Initialized
INFO - 2023-06-11 09:13:00 --> Input Class Initialized
INFO - 2023-06-11 09:13:00 --> Language Class Initialized
INFO - 2023-06-11 09:13:00 --> Loader Class Initialized
INFO - 2023-06-11 09:13:00 --> Helper loaded: url_helper
INFO - 2023-06-11 09:13:00 --> Helper loaded: form_helper
INFO - 2023-06-11 09:13:00 --> Database Driver Class Initialized
INFO - 2023-06-11 09:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:13:00 --> Form Validation Class Initialized
INFO - 2023-06-11 09:13:00 --> Controller Class Initialized
INFO - 2023-06-11 09:13:00 --> Model "m_user" initialized
INFO - 2023-06-11 09:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:13:00 --> Final output sent to browser
INFO - 2023-06-11 09:14:04 --> Config Class Initialized
INFO - 2023-06-11 09:14:04 --> Hooks Class Initialized
INFO - 2023-06-11 09:14:04 --> Utf8 Class Initialized
INFO - 2023-06-11 09:14:04 --> URI Class Initialized
INFO - 2023-06-11 09:14:04 --> Router Class Initialized
INFO - 2023-06-11 09:14:04 --> Output Class Initialized
INFO - 2023-06-11 09:14:04 --> Security Class Initialized
INFO - 2023-06-11 09:14:04 --> Input Class Initialized
INFO - 2023-06-11 09:14:04 --> Language Class Initialized
INFO - 2023-06-11 09:14:04 --> Loader Class Initialized
INFO - 2023-06-11 09:14:04 --> Helper loaded: url_helper
INFO - 2023-06-11 09:14:04 --> Helper loaded: form_helper
INFO - 2023-06-11 09:14:04 --> Database Driver Class Initialized
INFO - 2023-06-11 09:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:14:04 --> Form Validation Class Initialized
INFO - 2023-06-11 09:14:04 --> Controller Class Initialized
INFO - 2023-06-11 09:14:04 --> Model "m_user" initialized
INFO - 2023-06-11 09:14:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:14:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:14:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:14:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:14:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:14:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:14:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:14:04 --> Final output sent to browser
INFO - 2023-06-11 09:14:18 --> Config Class Initialized
INFO - 2023-06-11 09:14:18 --> Hooks Class Initialized
INFO - 2023-06-11 09:14:18 --> Utf8 Class Initialized
INFO - 2023-06-11 09:14:18 --> URI Class Initialized
INFO - 2023-06-11 09:14:18 --> Router Class Initialized
INFO - 2023-06-11 09:14:18 --> Output Class Initialized
INFO - 2023-06-11 09:14:18 --> Security Class Initialized
INFO - 2023-06-11 09:14:18 --> Input Class Initialized
INFO - 2023-06-11 09:14:18 --> Language Class Initialized
INFO - 2023-06-11 09:14:18 --> Loader Class Initialized
INFO - 2023-06-11 09:14:18 --> Helper loaded: url_helper
INFO - 2023-06-11 09:14:18 --> Helper loaded: form_helper
INFO - 2023-06-11 09:14:18 --> Database Driver Class Initialized
INFO - 2023-06-11 09:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:14:18 --> Form Validation Class Initialized
INFO - 2023-06-11 09:14:18 --> Controller Class Initialized
INFO - 2023-06-11 09:14:18 --> Model "m_user" initialized
ERROR - 2023-06-11 09:14:18 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 30
INFO - 2023-06-11 09:14:18 --> Config Class Initialized
INFO - 2023-06-11 09:14:18 --> Hooks Class Initialized
INFO - 2023-06-11 09:14:18 --> Utf8 Class Initialized
INFO - 2023-06-11 09:14:18 --> URI Class Initialized
INFO - 2023-06-11 09:14:18 --> Router Class Initialized
INFO - 2023-06-11 09:14:18 --> Output Class Initialized
INFO - 2023-06-11 09:14:18 --> Security Class Initialized
INFO - 2023-06-11 09:14:18 --> Input Class Initialized
INFO - 2023-06-11 09:14:18 --> Language Class Initialized
INFO - 2023-06-11 09:14:18 --> Loader Class Initialized
INFO - 2023-06-11 09:14:18 --> Helper loaded: url_helper
INFO - 2023-06-11 09:14:18 --> Helper loaded: form_helper
INFO - 2023-06-11 09:14:18 --> Database Driver Class Initialized
INFO - 2023-06-11 09:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:14:18 --> Form Validation Class Initialized
INFO - 2023-06-11 09:14:18 --> Controller Class Initialized
INFO - 2023-06-11 09:14:18 --> Model "m_user" initialized
INFO - 2023-06-11 09:14:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:14:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:14:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:14:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:14:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:14:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:14:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:14:18 --> Final output sent to browser
INFO - 2023-06-11 09:14:39 --> Config Class Initialized
INFO - 2023-06-11 09:14:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:14:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:14:39 --> URI Class Initialized
INFO - 2023-06-11 09:14:39 --> Router Class Initialized
INFO - 2023-06-11 09:14:39 --> Output Class Initialized
INFO - 2023-06-11 09:14:39 --> Security Class Initialized
INFO - 2023-06-11 09:14:39 --> Input Class Initialized
INFO - 2023-06-11 09:14:39 --> Language Class Initialized
INFO - 2023-06-11 09:14:39 --> Loader Class Initialized
INFO - 2023-06-11 09:14:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:14:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:14:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:14:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:14:39 --> Controller Class Initialized
INFO - 2023-06-11 09:14:39 --> Model "m_user" initialized
ERROR - 2023-06-11 09:14:39 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 30
INFO - 2023-06-11 09:14:39 --> Config Class Initialized
INFO - 2023-06-11 09:14:39 --> Hooks Class Initialized
INFO - 2023-06-11 09:14:39 --> Utf8 Class Initialized
INFO - 2023-06-11 09:14:39 --> URI Class Initialized
INFO - 2023-06-11 09:14:39 --> Router Class Initialized
INFO - 2023-06-11 09:14:39 --> Output Class Initialized
INFO - 2023-06-11 09:14:39 --> Security Class Initialized
INFO - 2023-06-11 09:14:39 --> Input Class Initialized
INFO - 2023-06-11 09:14:39 --> Language Class Initialized
INFO - 2023-06-11 09:14:39 --> Loader Class Initialized
INFO - 2023-06-11 09:14:39 --> Helper loaded: url_helper
INFO - 2023-06-11 09:14:39 --> Helper loaded: form_helper
INFO - 2023-06-11 09:14:39 --> Database Driver Class Initialized
INFO - 2023-06-11 09:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:14:39 --> Form Validation Class Initialized
INFO - 2023-06-11 09:14:39 --> Controller Class Initialized
INFO - 2023-06-11 09:14:39 --> Model "m_user" initialized
INFO - 2023-06-11 09:14:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:14:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:14:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:14:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:14:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:14:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:14:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:14:39 --> Final output sent to browser
INFO - 2023-06-11 09:15:08 --> Config Class Initialized
INFO - 2023-06-11 09:15:08 --> Hooks Class Initialized
INFO - 2023-06-11 09:15:08 --> Utf8 Class Initialized
INFO - 2023-06-11 09:15:08 --> URI Class Initialized
INFO - 2023-06-11 09:15:08 --> Router Class Initialized
INFO - 2023-06-11 09:15:08 --> Output Class Initialized
INFO - 2023-06-11 09:15:08 --> Security Class Initialized
INFO - 2023-06-11 09:15:08 --> Input Class Initialized
INFO - 2023-06-11 09:15:08 --> Language Class Initialized
INFO - 2023-06-11 09:15:08 --> Loader Class Initialized
INFO - 2023-06-11 09:15:08 --> Helper loaded: url_helper
INFO - 2023-06-11 09:15:08 --> Helper loaded: form_helper
INFO - 2023-06-11 09:15:08 --> Database Driver Class Initialized
INFO - 2023-06-11 09:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:15:08 --> Form Validation Class Initialized
INFO - 2023-06-11 09:15:08 --> Controller Class Initialized
INFO - 2023-06-11 09:15:08 --> Model "m_user" initialized
ERROR - 2023-06-11 09:15:08 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 30
INFO - 2023-06-11 09:15:08 --> Config Class Initialized
INFO - 2023-06-11 09:15:08 --> Hooks Class Initialized
INFO - 2023-06-11 09:15:09 --> Utf8 Class Initialized
INFO - 2023-06-11 09:15:09 --> URI Class Initialized
INFO - 2023-06-11 09:15:09 --> Router Class Initialized
INFO - 2023-06-11 09:15:09 --> Output Class Initialized
INFO - 2023-06-11 09:15:09 --> Security Class Initialized
INFO - 2023-06-11 09:15:09 --> Input Class Initialized
INFO - 2023-06-11 09:15:09 --> Language Class Initialized
INFO - 2023-06-11 09:15:09 --> Loader Class Initialized
INFO - 2023-06-11 09:15:09 --> Helper loaded: url_helper
INFO - 2023-06-11 09:15:09 --> Helper loaded: form_helper
INFO - 2023-06-11 09:15:09 --> Database Driver Class Initialized
INFO - 2023-06-11 09:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:15:09 --> Form Validation Class Initialized
INFO - 2023-06-11 09:15:09 --> Controller Class Initialized
INFO - 2023-06-11 09:15:09 --> Model "m_user" initialized
INFO - 2023-06-11 09:15:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:15:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:15:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:15:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:15:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:15:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:15:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:15:09 --> Final output sent to browser
INFO - 2023-06-11 09:15:50 --> Config Class Initialized
INFO - 2023-06-11 09:15:50 --> Hooks Class Initialized
INFO - 2023-06-11 09:15:50 --> Utf8 Class Initialized
INFO - 2023-06-11 09:15:50 --> URI Class Initialized
INFO - 2023-06-11 09:15:50 --> Router Class Initialized
INFO - 2023-06-11 09:15:50 --> Output Class Initialized
INFO - 2023-06-11 09:15:50 --> Security Class Initialized
INFO - 2023-06-11 09:15:50 --> Input Class Initialized
INFO - 2023-06-11 09:15:50 --> Language Class Initialized
INFO - 2023-06-11 09:15:50 --> Loader Class Initialized
INFO - 2023-06-11 09:15:50 --> Helper loaded: url_helper
INFO - 2023-06-11 09:15:50 --> Helper loaded: form_helper
INFO - 2023-06-11 09:15:50 --> Database Driver Class Initialized
INFO - 2023-06-11 09:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:15:50 --> Form Validation Class Initialized
INFO - 2023-06-11 09:15:50 --> Controller Class Initialized
INFO - 2023-06-11 09:15:50 --> Model "m_user" initialized
ERROR - 2023-06-11 09:15:50 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 30
INFO - 2023-06-11 09:15:50 --> Config Class Initialized
INFO - 2023-06-11 09:15:50 --> Hooks Class Initialized
INFO - 2023-06-11 09:15:50 --> Utf8 Class Initialized
INFO - 2023-06-11 09:15:50 --> URI Class Initialized
INFO - 2023-06-11 09:15:50 --> Router Class Initialized
INFO - 2023-06-11 09:15:50 --> Output Class Initialized
INFO - 2023-06-11 09:15:50 --> Security Class Initialized
INFO - 2023-06-11 09:15:50 --> Input Class Initialized
INFO - 2023-06-11 09:15:50 --> Language Class Initialized
INFO - 2023-06-11 09:15:50 --> Loader Class Initialized
INFO - 2023-06-11 09:15:50 --> Helper loaded: url_helper
INFO - 2023-06-11 09:15:50 --> Helper loaded: form_helper
INFO - 2023-06-11 09:15:50 --> Database Driver Class Initialized
INFO - 2023-06-11 09:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:15:50 --> Form Validation Class Initialized
INFO - 2023-06-11 09:15:50 --> Controller Class Initialized
INFO - 2023-06-11 09:15:50 --> Model "m_user" initialized
INFO - 2023-06-11 09:15:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:15:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:15:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:15:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:15:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:15:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:15:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:15:50 --> Final output sent to browser
INFO - 2023-06-11 09:15:52 --> Config Class Initialized
INFO - 2023-06-11 09:15:52 --> Hooks Class Initialized
INFO - 2023-06-11 09:15:52 --> Utf8 Class Initialized
INFO - 2023-06-11 09:15:52 --> URI Class Initialized
INFO - 2023-06-11 09:15:52 --> Router Class Initialized
INFO - 2023-06-11 09:15:52 --> Output Class Initialized
INFO - 2023-06-11 09:15:52 --> Security Class Initialized
INFO - 2023-06-11 09:15:52 --> Input Class Initialized
INFO - 2023-06-11 09:15:52 --> Language Class Initialized
INFO - 2023-06-11 09:15:52 --> Loader Class Initialized
INFO - 2023-06-11 09:15:52 --> Helper loaded: url_helper
INFO - 2023-06-11 09:15:52 --> Helper loaded: form_helper
INFO - 2023-06-11 09:15:52 --> Database Driver Class Initialized
INFO - 2023-06-11 09:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:15:53 --> Form Validation Class Initialized
INFO - 2023-06-11 09:15:53 --> Controller Class Initialized
INFO - 2023-06-11 09:15:53 --> Model "m_user" initialized
INFO - 2023-06-11 09:15:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:15:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:15:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 09:15:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:15:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:15:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:15:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:15:53 --> Final output sent to browser
INFO - 2023-06-11 09:17:18 --> Config Class Initialized
INFO - 2023-06-11 09:17:18 --> Hooks Class Initialized
INFO - 2023-06-11 09:17:18 --> Utf8 Class Initialized
INFO - 2023-06-11 09:17:18 --> URI Class Initialized
INFO - 2023-06-11 09:17:18 --> Router Class Initialized
INFO - 2023-06-11 09:17:18 --> Output Class Initialized
INFO - 2023-06-11 09:17:18 --> Security Class Initialized
INFO - 2023-06-11 09:17:18 --> Input Class Initialized
INFO - 2023-06-11 09:17:18 --> Language Class Initialized
INFO - 2023-06-11 09:17:18 --> Loader Class Initialized
INFO - 2023-06-11 09:17:18 --> Helper loaded: url_helper
INFO - 2023-06-11 09:17:18 --> Helper loaded: form_helper
INFO - 2023-06-11 09:17:18 --> Database Driver Class Initialized
INFO - 2023-06-11 09:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:17:18 --> Form Validation Class Initialized
INFO - 2023-06-11 09:17:18 --> Controller Class Initialized
INFO - 2023-06-11 09:17:18 --> Model "m_user" initialized
INFO - 2023-06-11 09:17:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:17:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:17:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:17:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:17:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:17:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:17:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:17:18 --> Final output sent to browser
INFO - 2023-06-11 09:17:31 --> Config Class Initialized
INFO - 2023-06-11 09:17:31 --> Hooks Class Initialized
INFO - 2023-06-11 09:17:31 --> Utf8 Class Initialized
INFO - 2023-06-11 09:17:31 --> URI Class Initialized
INFO - 2023-06-11 09:17:31 --> Router Class Initialized
INFO - 2023-06-11 09:17:31 --> Output Class Initialized
INFO - 2023-06-11 09:17:31 --> Security Class Initialized
INFO - 2023-06-11 09:17:31 --> Input Class Initialized
INFO - 2023-06-11 09:17:31 --> Language Class Initialized
INFO - 2023-06-11 09:17:31 --> Loader Class Initialized
INFO - 2023-06-11 09:17:31 --> Helper loaded: url_helper
INFO - 2023-06-11 09:17:31 --> Helper loaded: form_helper
INFO - 2023-06-11 09:17:31 --> Database Driver Class Initialized
INFO - 2023-06-11 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:17:31 --> Form Validation Class Initialized
INFO - 2023-06-11 09:17:31 --> Controller Class Initialized
INFO - 2023-06-11 09:17:31 --> Model "m_user" initialized
ERROR - 2023-06-11 09:17:31 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 30
INFO - 2023-06-11 09:17:31 --> Config Class Initialized
INFO - 2023-06-11 09:17:31 --> Hooks Class Initialized
INFO - 2023-06-11 09:17:31 --> Utf8 Class Initialized
INFO - 2023-06-11 09:17:31 --> URI Class Initialized
INFO - 2023-06-11 09:17:31 --> Router Class Initialized
INFO - 2023-06-11 09:17:31 --> Output Class Initialized
INFO - 2023-06-11 09:17:31 --> Security Class Initialized
INFO - 2023-06-11 09:17:31 --> Input Class Initialized
INFO - 2023-06-11 09:17:31 --> Language Class Initialized
INFO - 2023-06-11 09:17:31 --> Loader Class Initialized
INFO - 2023-06-11 09:17:31 --> Helper loaded: url_helper
INFO - 2023-06-11 09:17:31 --> Helper loaded: form_helper
INFO - 2023-06-11 09:17:31 --> Database Driver Class Initialized
INFO - 2023-06-11 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:17:31 --> Form Validation Class Initialized
INFO - 2023-06-11 09:17:31 --> Controller Class Initialized
INFO - 2023-06-11 09:17:31 --> Model "m_user" initialized
INFO - 2023-06-11 09:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:17:31 --> Final output sent to browser
INFO - 2023-06-11 09:17:35 --> Config Class Initialized
INFO - 2023-06-11 09:17:35 --> Hooks Class Initialized
INFO - 2023-06-11 09:17:35 --> Utf8 Class Initialized
INFO - 2023-06-11 09:17:35 --> URI Class Initialized
INFO - 2023-06-11 09:17:35 --> Router Class Initialized
INFO - 2023-06-11 09:17:35 --> Output Class Initialized
INFO - 2023-06-11 09:17:35 --> Security Class Initialized
INFO - 2023-06-11 09:17:35 --> Input Class Initialized
INFO - 2023-06-11 09:17:35 --> Language Class Initialized
INFO - 2023-06-11 09:17:35 --> Loader Class Initialized
INFO - 2023-06-11 09:17:35 --> Helper loaded: url_helper
INFO - 2023-06-11 09:17:35 --> Helper loaded: form_helper
INFO - 2023-06-11 09:17:35 --> Database Driver Class Initialized
INFO - 2023-06-11 09:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:17:35 --> Form Validation Class Initialized
INFO - 2023-06-11 09:17:35 --> Controller Class Initialized
INFO - 2023-06-11 09:17:35 --> Model "m_user" initialized
INFO - 2023-06-11 09:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 09:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:17:35 --> Final output sent to browser
INFO - 2023-06-11 09:20:08 --> Config Class Initialized
INFO - 2023-06-11 09:20:08 --> Hooks Class Initialized
INFO - 2023-06-11 09:20:08 --> Utf8 Class Initialized
INFO - 2023-06-11 09:20:08 --> URI Class Initialized
INFO - 2023-06-11 09:20:08 --> Router Class Initialized
INFO - 2023-06-11 09:20:08 --> Output Class Initialized
INFO - 2023-06-11 09:20:08 --> Security Class Initialized
INFO - 2023-06-11 09:20:08 --> Input Class Initialized
INFO - 2023-06-11 09:20:08 --> Language Class Initialized
INFO - 2023-06-11 09:20:08 --> Loader Class Initialized
INFO - 2023-06-11 09:20:08 --> Helper loaded: url_helper
INFO - 2023-06-11 09:20:08 --> Helper loaded: form_helper
INFO - 2023-06-11 09:20:08 --> Database Driver Class Initialized
INFO - 2023-06-11 09:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:20:08 --> Form Validation Class Initialized
INFO - 2023-06-11 09:20:08 --> Controller Class Initialized
INFO - 2023-06-11 09:20:08 --> Model "m_user" initialized
INFO - 2023-06-11 09:20:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:20:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:20:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 09:20:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:20:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:20:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:20:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:20:08 --> Final output sent to browser
INFO - 2023-06-11 09:20:09 --> Config Class Initialized
INFO - 2023-06-11 09:20:09 --> Hooks Class Initialized
INFO - 2023-06-11 09:20:09 --> Utf8 Class Initialized
INFO - 2023-06-11 09:20:09 --> URI Class Initialized
INFO - 2023-06-11 09:20:09 --> Router Class Initialized
INFO - 2023-06-11 09:20:09 --> Output Class Initialized
INFO - 2023-06-11 09:20:09 --> Security Class Initialized
INFO - 2023-06-11 09:20:09 --> Input Class Initialized
INFO - 2023-06-11 09:20:09 --> Language Class Initialized
INFO - 2023-06-11 09:20:09 --> Loader Class Initialized
INFO - 2023-06-11 09:20:09 --> Helper loaded: url_helper
INFO - 2023-06-11 09:20:09 --> Helper loaded: form_helper
INFO - 2023-06-11 09:20:09 --> Database Driver Class Initialized
INFO - 2023-06-11 09:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:20:09 --> Form Validation Class Initialized
INFO - 2023-06-11 09:20:09 --> Controller Class Initialized
INFO - 2023-06-11 09:20:09 --> Model "m_user" initialized
INFO - 2023-06-11 09:20:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:20:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:20:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:20:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:20:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:20:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:20:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:20:09 --> Final output sent to browser
INFO - 2023-06-11 09:20:26 --> Config Class Initialized
INFO - 2023-06-11 09:20:26 --> Hooks Class Initialized
INFO - 2023-06-11 09:20:26 --> Utf8 Class Initialized
INFO - 2023-06-11 09:20:26 --> URI Class Initialized
INFO - 2023-06-11 09:20:26 --> Router Class Initialized
INFO - 2023-06-11 09:20:26 --> Output Class Initialized
INFO - 2023-06-11 09:20:26 --> Security Class Initialized
INFO - 2023-06-11 09:20:26 --> Input Class Initialized
INFO - 2023-06-11 09:20:26 --> Language Class Initialized
INFO - 2023-06-11 09:20:26 --> Loader Class Initialized
INFO - 2023-06-11 09:20:26 --> Helper loaded: url_helper
INFO - 2023-06-11 09:20:26 --> Helper loaded: form_helper
INFO - 2023-06-11 09:20:26 --> Database Driver Class Initialized
INFO - 2023-06-11 09:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:20:26 --> Form Validation Class Initialized
INFO - 2023-06-11 09:20:26 --> Controller Class Initialized
INFO - 2023-06-11 09:20:26 --> Model "m_user" initialized
ERROR - 2023-06-11 09:20:26 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 30
INFO - 2023-06-11 09:20:26 --> Config Class Initialized
INFO - 2023-06-11 09:20:26 --> Hooks Class Initialized
INFO - 2023-06-11 09:20:26 --> Utf8 Class Initialized
INFO - 2023-06-11 09:20:26 --> URI Class Initialized
INFO - 2023-06-11 09:20:26 --> Router Class Initialized
INFO - 2023-06-11 09:20:26 --> Output Class Initialized
INFO - 2023-06-11 09:20:26 --> Security Class Initialized
INFO - 2023-06-11 09:20:26 --> Input Class Initialized
INFO - 2023-06-11 09:20:27 --> Language Class Initialized
INFO - 2023-06-11 09:20:27 --> Loader Class Initialized
INFO - 2023-06-11 09:20:27 --> Helper loaded: url_helper
INFO - 2023-06-11 09:20:27 --> Helper loaded: form_helper
INFO - 2023-06-11 09:20:27 --> Database Driver Class Initialized
INFO - 2023-06-11 09:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:20:27 --> Form Validation Class Initialized
INFO - 2023-06-11 09:20:27 --> Controller Class Initialized
INFO - 2023-06-11 09:20:27 --> Model "m_user" initialized
INFO - 2023-06-11 09:20:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:20:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:20:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:20:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:20:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:20:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:20:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:20:27 --> Final output sent to browser
INFO - 2023-06-11 09:21:55 --> Config Class Initialized
INFO - 2023-06-11 09:21:55 --> Hooks Class Initialized
INFO - 2023-06-11 09:21:55 --> Utf8 Class Initialized
INFO - 2023-06-11 09:21:55 --> URI Class Initialized
INFO - 2023-06-11 09:21:55 --> Router Class Initialized
INFO - 2023-06-11 09:21:55 --> Output Class Initialized
INFO - 2023-06-11 09:21:55 --> Security Class Initialized
INFO - 2023-06-11 09:21:55 --> Input Class Initialized
INFO - 2023-06-11 09:21:55 --> Language Class Initialized
INFO - 2023-06-11 09:21:55 --> Loader Class Initialized
INFO - 2023-06-11 09:21:55 --> Helper loaded: url_helper
INFO - 2023-06-11 09:21:55 --> Helper loaded: form_helper
INFO - 2023-06-11 09:21:55 --> Database Driver Class Initialized
INFO - 2023-06-11 09:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:21:55 --> Form Validation Class Initialized
INFO - 2023-06-11 09:21:55 --> Controller Class Initialized
INFO - 2023-06-11 09:21:55 --> Model "m_user" initialized
INFO - 2023-06-11 09:21:55 --> Final output sent to browser
INFO - 2023-06-11 09:22:11 --> Config Class Initialized
INFO - 2023-06-11 09:22:11 --> Hooks Class Initialized
INFO - 2023-06-11 09:22:11 --> Utf8 Class Initialized
INFO - 2023-06-11 09:22:11 --> URI Class Initialized
INFO - 2023-06-11 09:22:11 --> Router Class Initialized
INFO - 2023-06-11 09:22:11 --> Output Class Initialized
INFO - 2023-06-11 09:22:11 --> Security Class Initialized
INFO - 2023-06-11 09:22:11 --> Input Class Initialized
INFO - 2023-06-11 09:22:11 --> Language Class Initialized
INFO - 2023-06-11 09:22:11 --> Loader Class Initialized
INFO - 2023-06-11 09:22:11 --> Helper loaded: url_helper
INFO - 2023-06-11 09:22:11 --> Helper loaded: form_helper
INFO - 2023-06-11 09:22:11 --> Database Driver Class Initialized
INFO - 2023-06-11 09:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:22:11 --> Form Validation Class Initialized
INFO - 2023-06-11 09:22:11 --> Controller Class Initialized
INFO - 2023-06-11 09:22:11 --> Model "m_user" initialized
INFO - 2023-06-11 09:22:11 --> Final output sent to browser
INFO - 2023-06-11 09:22:42 --> Config Class Initialized
INFO - 2023-06-11 09:22:42 --> Hooks Class Initialized
INFO - 2023-06-11 09:22:42 --> Utf8 Class Initialized
INFO - 2023-06-11 09:22:42 --> URI Class Initialized
INFO - 2023-06-11 09:22:42 --> Router Class Initialized
INFO - 2023-06-11 09:22:42 --> Output Class Initialized
INFO - 2023-06-11 09:22:42 --> Security Class Initialized
INFO - 2023-06-11 09:22:42 --> Input Class Initialized
INFO - 2023-06-11 09:22:42 --> Language Class Initialized
INFO - 2023-06-11 09:22:42 --> Loader Class Initialized
INFO - 2023-06-11 09:22:42 --> Helper loaded: url_helper
INFO - 2023-06-11 09:22:42 --> Helper loaded: form_helper
INFO - 2023-06-11 09:22:42 --> Database Driver Class Initialized
INFO - 2023-06-11 09:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:22:42 --> Form Validation Class Initialized
INFO - 2023-06-11 09:22:42 --> Controller Class Initialized
INFO - 2023-06-11 09:22:42 --> Model "m_user" initialized
INFO - 2023-06-11 09:22:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:22:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:22:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:22:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:22:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:22:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:22:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:22:42 --> Final output sent to browser
INFO - 2023-06-11 09:24:51 --> Config Class Initialized
INFO - 2023-06-11 09:24:51 --> Hooks Class Initialized
INFO - 2023-06-11 09:24:51 --> Utf8 Class Initialized
INFO - 2023-06-11 09:24:51 --> URI Class Initialized
INFO - 2023-06-11 09:24:51 --> Router Class Initialized
INFO - 2023-06-11 09:24:51 --> Output Class Initialized
INFO - 2023-06-11 09:24:51 --> Security Class Initialized
INFO - 2023-06-11 09:24:51 --> Input Class Initialized
INFO - 2023-06-11 09:24:51 --> Language Class Initialized
INFO - 2023-06-11 09:24:51 --> Loader Class Initialized
INFO - 2023-06-11 09:24:51 --> Helper loaded: url_helper
INFO - 2023-06-11 09:24:51 --> Helper loaded: form_helper
INFO - 2023-06-11 09:24:51 --> Database Driver Class Initialized
INFO - 2023-06-11 09:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:24:51 --> Form Validation Class Initialized
INFO - 2023-06-11 09:24:51 --> Controller Class Initialized
INFO - 2023-06-11 09:24:51 --> Model "m_user" initialized
ERROR - 2023-06-11 09:24:51 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 30
ERROR - 2023-06-11 09:24:51 --> Severity: Warning --> var_dump() expects at least 1 parameter, 0 given C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 47
INFO - 2023-06-11 09:24:51 --> Final output sent to browser
INFO - 2023-06-11 09:55:47 --> Config Class Initialized
INFO - 2023-06-11 09:55:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:55:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:55:47 --> URI Class Initialized
INFO - 2023-06-11 09:55:47 --> Router Class Initialized
INFO - 2023-06-11 09:55:47 --> Output Class Initialized
INFO - 2023-06-11 09:55:47 --> Security Class Initialized
INFO - 2023-06-11 09:55:47 --> Input Class Initialized
INFO - 2023-06-11 09:55:47 --> Language Class Initialized
INFO - 2023-06-11 09:55:47 --> Loader Class Initialized
INFO - 2023-06-11 09:55:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:55:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:55:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:55:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:55:47 --> Controller Class Initialized
INFO - 2023-06-11 09:55:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:55:47 --> Config Class Initialized
INFO - 2023-06-11 09:55:47 --> Hooks Class Initialized
INFO - 2023-06-11 09:55:47 --> Utf8 Class Initialized
INFO - 2023-06-11 09:55:47 --> URI Class Initialized
INFO - 2023-06-11 09:55:47 --> Router Class Initialized
INFO - 2023-06-11 09:55:47 --> Output Class Initialized
INFO - 2023-06-11 09:55:47 --> Security Class Initialized
INFO - 2023-06-11 09:55:47 --> Input Class Initialized
INFO - 2023-06-11 09:55:47 --> Language Class Initialized
INFO - 2023-06-11 09:55:47 --> Loader Class Initialized
INFO - 2023-06-11 09:55:47 --> Helper loaded: url_helper
INFO - 2023-06-11 09:55:47 --> Helper loaded: form_helper
INFO - 2023-06-11 09:55:47 --> Database Driver Class Initialized
INFO - 2023-06-11 09:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:55:47 --> Form Validation Class Initialized
INFO - 2023-06-11 09:55:47 --> Controller Class Initialized
INFO - 2023-06-11 09:55:47 --> Model "m_user" initialized
INFO - 2023-06-11 09:55:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:55:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:55:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 09:55:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:55:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:55:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:55:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:55:47 --> Final output sent to browser
INFO - 2023-06-11 09:55:52 --> Config Class Initialized
INFO - 2023-06-11 09:55:52 --> Hooks Class Initialized
INFO - 2023-06-11 09:55:52 --> Utf8 Class Initialized
INFO - 2023-06-11 09:55:52 --> URI Class Initialized
INFO - 2023-06-11 09:55:52 --> Router Class Initialized
INFO - 2023-06-11 09:55:52 --> Output Class Initialized
INFO - 2023-06-11 09:55:52 --> Security Class Initialized
INFO - 2023-06-11 09:55:52 --> Input Class Initialized
INFO - 2023-06-11 09:55:52 --> Language Class Initialized
INFO - 2023-06-11 09:55:52 --> Loader Class Initialized
INFO - 2023-06-11 09:55:52 --> Helper loaded: url_helper
INFO - 2023-06-11 09:55:52 --> Helper loaded: form_helper
INFO - 2023-06-11 09:55:52 --> Database Driver Class Initialized
INFO - 2023-06-11 09:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:55:52 --> Form Validation Class Initialized
INFO - 2023-06-11 09:55:52 --> Controller Class Initialized
INFO - 2023-06-11 09:55:52 --> Model "m_user" initialized
INFO - 2023-06-11 09:55:52 --> Config Class Initialized
INFO - 2023-06-11 09:55:52 --> Hooks Class Initialized
INFO - 2023-06-11 09:55:52 --> Utf8 Class Initialized
INFO - 2023-06-11 09:55:52 --> URI Class Initialized
INFO - 2023-06-11 09:55:52 --> Router Class Initialized
INFO - 2023-06-11 09:55:52 --> Output Class Initialized
INFO - 2023-06-11 09:55:52 --> Security Class Initialized
INFO - 2023-06-11 09:55:52 --> Input Class Initialized
INFO - 2023-06-11 09:55:52 --> Language Class Initialized
INFO - 2023-06-11 09:55:52 --> Loader Class Initialized
INFO - 2023-06-11 09:55:52 --> Helper loaded: url_helper
INFO - 2023-06-11 09:55:52 --> Helper loaded: form_helper
INFO - 2023-06-11 09:55:52 --> Database Driver Class Initialized
INFO - 2023-06-11 09:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:55:52 --> Form Validation Class Initialized
INFO - 2023-06-11 09:55:52 --> Controller Class Initialized
INFO - 2023-06-11 09:55:52 --> Model "m_user" initialized
INFO - 2023-06-11 09:55:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:55:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:55:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 09:55:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:55:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:55:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:55:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:55:52 --> Final output sent to browser
INFO - 2023-06-11 09:57:28 --> Config Class Initialized
INFO - 2023-06-11 09:57:28 --> Hooks Class Initialized
INFO - 2023-06-11 09:57:28 --> Utf8 Class Initialized
INFO - 2023-06-11 09:57:28 --> URI Class Initialized
INFO - 2023-06-11 09:57:28 --> Router Class Initialized
INFO - 2023-06-11 09:57:28 --> Output Class Initialized
INFO - 2023-06-11 09:57:28 --> Security Class Initialized
INFO - 2023-06-11 09:57:28 --> Input Class Initialized
INFO - 2023-06-11 09:57:28 --> Language Class Initialized
INFO - 2023-06-11 09:57:28 --> Loader Class Initialized
INFO - 2023-06-11 09:57:28 --> Helper loaded: url_helper
INFO - 2023-06-11 09:57:28 --> Helper loaded: form_helper
INFO - 2023-06-11 09:57:28 --> Database Driver Class Initialized
INFO - 2023-06-11 09:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:57:28 --> Form Validation Class Initialized
INFO - 2023-06-11 09:57:28 --> Controller Class Initialized
INFO - 2023-06-11 09:57:28 --> Model "m_user" initialized
INFO - 2023-06-11 09:57:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:57:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:57:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:57:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:57:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:57:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:57:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:57:28 --> Final output sent to browser
INFO - 2023-06-11 09:57:40 --> Config Class Initialized
INFO - 2023-06-11 09:57:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:57:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:57:40 --> URI Class Initialized
INFO - 2023-06-11 09:57:40 --> Router Class Initialized
INFO - 2023-06-11 09:57:40 --> Output Class Initialized
INFO - 2023-06-11 09:57:40 --> Security Class Initialized
INFO - 2023-06-11 09:57:40 --> Input Class Initialized
INFO - 2023-06-11 09:57:40 --> Language Class Initialized
INFO - 2023-06-11 09:57:40 --> Loader Class Initialized
INFO - 2023-06-11 09:57:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:57:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:57:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:57:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:57:40 --> Controller Class Initialized
INFO - 2023-06-11 09:57:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:57:40 --> Config Class Initialized
INFO - 2023-06-11 09:57:40 --> Hooks Class Initialized
INFO - 2023-06-11 09:57:40 --> Utf8 Class Initialized
INFO - 2023-06-11 09:57:40 --> URI Class Initialized
INFO - 2023-06-11 09:57:40 --> Router Class Initialized
INFO - 2023-06-11 09:57:40 --> Output Class Initialized
INFO - 2023-06-11 09:57:40 --> Security Class Initialized
INFO - 2023-06-11 09:57:40 --> Input Class Initialized
INFO - 2023-06-11 09:57:40 --> Language Class Initialized
INFO - 2023-06-11 09:57:40 --> Loader Class Initialized
INFO - 2023-06-11 09:57:40 --> Helper loaded: url_helper
INFO - 2023-06-11 09:57:40 --> Helper loaded: form_helper
INFO - 2023-06-11 09:57:40 --> Database Driver Class Initialized
INFO - 2023-06-11 09:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:57:40 --> Form Validation Class Initialized
INFO - 2023-06-11 09:57:40 --> Controller Class Initialized
INFO - 2023-06-11 09:57:40 --> Model "m_user" initialized
INFO - 2023-06-11 09:57:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:57:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:57:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:57:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:57:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:57:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:57:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:57:40 --> Final output sent to browser
INFO - 2023-06-11 09:58:08 --> Config Class Initialized
INFO - 2023-06-11 09:58:08 --> Hooks Class Initialized
INFO - 2023-06-11 09:58:08 --> Utf8 Class Initialized
INFO - 2023-06-11 09:58:08 --> URI Class Initialized
INFO - 2023-06-11 09:58:08 --> Router Class Initialized
INFO - 2023-06-11 09:58:08 --> Output Class Initialized
INFO - 2023-06-11 09:58:08 --> Security Class Initialized
INFO - 2023-06-11 09:58:08 --> Input Class Initialized
INFO - 2023-06-11 09:58:08 --> Language Class Initialized
INFO - 2023-06-11 09:58:08 --> Loader Class Initialized
INFO - 2023-06-11 09:58:08 --> Helper loaded: url_helper
INFO - 2023-06-11 09:58:08 --> Helper loaded: form_helper
INFO - 2023-06-11 09:58:08 --> Database Driver Class Initialized
INFO - 2023-06-11 09:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:58:08 --> Form Validation Class Initialized
INFO - 2023-06-11 09:58:08 --> Controller Class Initialized
INFO - 2023-06-11 09:58:08 --> Model "m_user" initialized
INFO - 2023-06-11 09:58:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 09:58:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 09:58:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 09:58:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 09:58:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 09:58:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 09:58:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 09:58:08 --> Final output sent to browser
INFO - 2023-06-11 09:58:19 --> Config Class Initialized
INFO - 2023-06-11 09:58:19 --> Hooks Class Initialized
INFO - 2023-06-11 09:58:19 --> Utf8 Class Initialized
INFO - 2023-06-11 09:58:19 --> URI Class Initialized
INFO - 2023-06-11 09:58:19 --> Router Class Initialized
INFO - 2023-06-11 09:58:19 --> Output Class Initialized
INFO - 2023-06-11 09:58:19 --> Security Class Initialized
INFO - 2023-06-11 09:58:19 --> Input Class Initialized
INFO - 2023-06-11 09:58:19 --> Language Class Initialized
INFO - 2023-06-11 09:58:19 --> Loader Class Initialized
INFO - 2023-06-11 09:58:19 --> Helper loaded: url_helper
INFO - 2023-06-11 09:58:19 --> Helper loaded: form_helper
INFO - 2023-06-11 09:58:19 --> Database Driver Class Initialized
INFO - 2023-06-11 09:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 09:58:19 --> Form Validation Class Initialized
INFO - 2023-06-11 09:58:19 --> Controller Class Initialized
INFO - 2023-06-11 09:58:19 --> Model "m_user" initialized
INFO - 2023-06-11 09:58:19 --> Final output sent to browser
INFO - 2023-06-11 10:00:50 --> Config Class Initialized
INFO - 2023-06-11 10:00:50 --> Hooks Class Initialized
INFO - 2023-06-11 10:00:50 --> Utf8 Class Initialized
INFO - 2023-06-11 10:00:50 --> URI Class Initialized
INFO - 2023-06-11 10:00:50 --> Router Class Initialized
INFO - 2023-06-11 10:00:50 --> Output Class Initialized
INFO - 2023-06-11 10:00:50 --> Security Class Initialized
INFO - 2023-06-11 10:00:50 --> Input Class Initialized
INFO - 2023-06-11 10:00:50 --> Language Class Initialized
INFO - 2023-06-11 10:00:50 --> Loader Class Initialized
INFO - 2023-06-11 10:00:50 --> Helper loaded: url_helper
INFO - 2023-06-11 10:00:50 --> Helper loaded: form_helper
INFO - 2023-06-11 10:00:50 --> Database Driver Class Initialized
INFO - 2023-06-11 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:00:50 --> Form Validation Class Initialized
INFO - 2023-06-11 10:00:50 --> Controller Class Initialized
INFO - 2023-06-11 10:00:50 --> Model "m_user" initialized
INFO - 2023-06-11 10:00:50 --> Final output sent to browser
INFO - 2023-06-11 10:00:54 --> Config Class Initialized
INFO - 2023-06-11 10:00:54 --> Hooks Class Initialized
INFO - 2023-06-11 10:00:54 --> Utf8 Class Initialized
INFO - 2023-06-11 10:00:54 --> URI Class Initialized
INFO - 2023-06-11 10:00:54 --> Router Class Initialized
INFO - 2023-06-11 10:00:54 --> Output Class Initialized
INFO - 2023-06-11 10:00:54 --> Security Class Initialized
INFO - 2023-06-11 10:00:54 --> Input Class Initialized
INFO - 2023-06-11 10:00:54 --> Language Class Initialized
INFO - 2023-06-11 10:00:54 --> Loader Class Initialized
INFO - 2023-06-11 10:00:54 --> Helper loaded: url_helper
INFO - 2023-06-11 10:00:54 --> Helper loaded: form_helper
INFO - 2023-06-11 10:00:54 --> Database Driver Class Initialized
INFO - 2023-06-11 10:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:00:54 --> Form Validation Class Initialized
INFO - 2023-06-11 10:00:54 --> Controller Class Initialized
INFO - 2023-06-11 10:00:54 --> Model "m_user" initialized
INFO - 2023-06-11 10:00:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:00:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:00:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 10:00:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:00:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:00:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:00:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:00:54 --> Final output sent to browser
INFO - 2023-06-11 10:01:02 --> Config Class Initialized
INFO - 2023-06-11 10:01:02 --> Hooks Class Initialized
INFO - 2023-06-11 10:01:02 --> Utf8 Class Initialized
INFO - 2023-06-11 10:01:02 --> URI Class Initialized
INFO - 2023-06-11 10:01:02 --> Router Class Initialized
INFO - 2023-06-11 10:01:02 --> Output Class Initialized
INFO - 2023-06-11 10:01:02 --> Security Class Initialized
INFO - 2023-06-11 10:01:02 --> Input Class Initialized
INFO - 2023-06-11 10:01:02 --> Language Class Initialized
INFO - 2023-06-11 10:01:02 --> Loader Class Initialized
INFO - 2023-06-11 10:01:02 --> Helper loaded: url_helper
INFO - 2023-06-11 10:01:02 --> Helper loaded: form_helper
INFO - 2023-06-11 10:01:02 --> Database Driver Class Initialized
INFO - 2023-06-11 10:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:01:02 --> Form Validation Class Initialized
INFO - 2023-06-11 10:01:02 --> Controller Class Initialized
INFO - 2023-06-11 10:01:02 --> Model "m_user" initialized
INFO - 2023-06-11 10:01:02 --> Final output sent to browser
INFO - 2023-06-11 10:02:10 --> Config Class Initialized
INFO - 2023-06-11 10:02:10 --> Hooks Class Initialized
INFO - 2023-06-11 10:02:10 --> Utf8 Class Initialized
INFO - 2023-06-11 10:02:10 --> URI Class Initialized
INFO - 2023-06-11 10:02:10 --> Router Class Initialized
INFO - 2023-06-11 10:02:10 --> Output Class Initialized
INFO - 2023-06-11 10:02:10 --> Security Class Initialized
INFO - 2023-06-11 10:02:10 --> Input Class Initialized
INFO - 2023-06-11 10:02:10 --> Language Class Initialized
INFO - 2023-06-11 10:02:10 --> Loader Class Initialized
INFO - 2023-06-11 10:02:10 --> Helper loaded: url_helper
INFO - 2023-06-11 10:02:10 --> Helper loaded: form_helper
INFO - 2023-06-11 10:02:10 --> Database Driver Class Initialized
INFO - 2023-06-11 10:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:02:10 --> Form Validation Class Initialized
INFO - 2023-06-11 10:02:10 --> Controller Class Initialized
INFO - 2023-06-11 10:02:10 --> Model "m_user" initialized
INFO - 2023-06-11 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:02:10 --> Final output sent to browser
INFO - 2023-06-11 10:02:37 --> Config Class Initialized
INFO - 2023-06-11 10:02:37 --> Hooks Class Initialized
INFO - 2023-06-11 10:02:37 --> Utf8 Class Initialized
INFO - 2023-06-11 10:02:37 --> URI Class Initialized
INFO - 2023-06-11 10:02:37 --> Router Class Initialized
INFO - 2023-06-11 10:02:37 --> Output Class Initialized
INFO - 2023-06-11 10:02:37 --> Security Class Initialized
INFO - 2023-06-11 10:02:37 --> Input Class Initialized
INFO - 2023-06-11 10:02:37 --> Language Class Initialized
INFO - 2023-06-11 10:02:37 --> Loader Class Initialized
INFO - 2023-06-11 10:02:37 --> Helper loaded: url_helper
INFO - 2023-06-11 10:02:37 --> Helper loaded: form_helper
INFO - 2023-06-11 10:02:37 --> Database Driver Class Initialized
INFO - 2023-06-11 10:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:02:37 --> Form Validation Class Initialized
INFO - 2023-06-11 10:02:37 --> Controller Class Initialized
INFO - 2023-06-11 10:02:37 --> Model "m_user" initialized
INFO - 2023-06-11 10:02:37 --> Config Class Initialized
INFO - 2023-06-11 10:02:37 --> Hooks Class Initialized
INFO - 2023-06-11 10:02:37 --> Utf8 Class Initialized
INFO - 2023-06-11 10:02:37 --> URI Class Initialized
INFO - 2023-06-11 10:02:37 --> Router Class Initialized
INFO - 2023-06-11 10:02:37 --> Output Class Initialized
INFO - 2023-06-11 10:02:37 --> Security Class Initialized
INFO - 2023-06-11 10:02:37 --> Input Class Initialized
INFO - 2023-06-11 10:02:37 --> Language Class Initialized
INFO - 2023-06-11 10:02:37 --> Loader Class Initialized
INFO - 2023-06-11 10:02:37 --> Helper loaded: url_helper
INFO - 2023-06-11 10:02:37 --> Helper loaded: form_helper
INFO - 2023-06-11 10:02:37 --> Database Driver Class Initialized
INFO - 2023-06-11 10:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:02:37 --> Form Validation Class Initialized
INFO - 2023-06-11 10:02:37 --> Controller Class Initialized
INFO - 2023-06-11 10:02:37 --> Model "m_user" initialized
INFO - 2023-06-11 10:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 10:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:02:37 --> Final output sent to browser
INFO - 2023-06-11 10:02:51 --> Config Class Initialized
INFO - 2023-06-11 10:02:51 --> Hooks Class Initialized
INFO - 2023-06-11 10:02:51 --> Utf8 Class Initialized
INFO - 2023-06-11 10:02:51 --> URI Class Initialized
INFO - 2023-06-11 10:02:51 --> Router Class Initialized
INFO - 2023-06-11 10:02:51 --> Output Class Initialized
INFO - 2023-06-11 10:02:51 --> Security Class Initialized
INFO - 2023-06-11 10:02:51 --> Input Class Initialized
INFO - 2023-06-11 10:02:51 --> Language Class Initialized
INFO - 2023-06-11 10:02:51 --> Loader Class Initialized
INFO - 2023-06-11 10:02:51 --> Helper loaded: url_helper
INFO - 2023-06-11 10:02:51 --> Helper loaded: form_helper
INFO - 2023-06-11 10:02:51 --> Database Driver Class Initialized
INFO - 2023-06-11 10:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:02:51 --> Form Validation Class Initialized
INFO - 2023-06-11 10:02:51 --> Controller Class Initialized
INFO - 2023-06-11 10:02:51 --> Model "m_user" initialized
INFO - 2023-06-11 10:02:51 --> Config Class Initialized
INFO - 2023-06-11 10:02:51 --> Hooks Class Initialized
INFO - 2023-06-11 10:02:51 --> Utf8 Class Initialized
INFO - 2023-06-11 10:02:51 --> URI Class Initialized
INFO - 2023-06-11 10:02:51 --> Router Class Initialized
INFO - 2023-06-11 10:02:51 --> Output Class Initialized
INFO - 2023-06-11 10:02:51 --> Security Class Initialized
INFO - 2023-06-11 10:02:51 --> Input Class Initialized
INFO - 2023-06-11 10:02:51 --> Language Class Initialized
INFO - 2023-06-11 10:02:51 --> Loader Class Initialized
INFO - 2023-06-11 10:02:51 --> Helper loaded: url_helper
INFO - 2023-06-11 10:02:51 --> Helper loaded: form_helper
INFO - 2023-06-11 10:02:51 --> Database Driver Class Initialized
INFO - 2023-06-11 10:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:02:51 --> Form Validation Class Initialized
INFO - 2023-06-11 10:02:51 --> Controller Class Initialized
INFO - 2023-06-11 10:02:51 --> Model "m_user" initialized
INFO - 2023-06-11 10:02:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:02:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:02:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:02:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:02:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:02:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:02:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:02:51 --> Final output sent to browser
INFO - 2023-06-11 10:02:53 --> Config Class Initialized
INFO - 2023-06-11 10:02:53 --> Hooks Class Initialized
INFO - 2023-06-11 10:02:53 --> Utf8 Class Initialized
INFO - 2023-06-11 10:02:53 --> URI Class Initialized
INFO - 2023-06-11 10:02:53 --> Router Class Initialized
INFO - 2023-06-11 10:02:53 --> Output Class Initialized
INFO - 2023-06-11 10:02:53 --> Security Class Initialized
INFO - 2023-06-11 10:02:53 --> Input Class Initialized
INFO - 2023-06-11 10:02:53 --> Language Class Initialized
INFO - 2023-06-11 10:02:53 --> Loader Class Initialized
INFO - 2023-06-11 10:02:53 --> Helper loaded: url_helper
INFO - 2023-06-11 10:02:53 --> Helper loaded: form_helper
INFO - 2023-06-11 10:02:53 --> Database Driver Class Initialized
INFO - 2023-06-11 10:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:02:53 --> Form Validation Class Initialized
INFO - 2023-06-11 10:02:53 --> Controller Class Initialized
INFO - 2023-06-11 10:02:53 --> Model "m_user" initialized
INFO - 2023-06-11 10:02:53 --> Config Class Initialized
INFO - 2023-06-11 10:02:53 --> Hooks Class Initialized
INFO - 2023-06-11 10:02:53 --> Utf8 Class Initialized
INFO - 2023-06-11 10:02:53 --> URI Class Initialized
INFO - 2023-06-11 10:02:53 --> Router Class Initialized
INFO - 2023-06-11 10:02:53 --> Output Class Initialized
INFO - 2023-06-11 10:02:53 --> Security Class Initialized
INFO - 2023-06-11 10:02:53 --> Input Class Initialized
INFO - 2023-06-11 10:02:53 --> Language Class Initialized
INFO - 2023-06-11 10:02:53 --> Loader Class Initialized
INFO - 2023-06-11 10:02:53 --> Helper loaded: url_helper
INFO - 2023-06-11 10:02:53 --> Helper loaded: form_helper
INFO - 2023-06-11 10:02:53 --> Database Driver Class Initialized
INFO - 2023-06-11 10:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:02:53 --> Form Validation Class Initialized
INFO - 2023-06-11 10:02:53 --> Controller Class Initialized
INFO - 2023-06-11 10:02:53 --> Model "m_user" initialized
INFO - 2023-06-11 10:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:02:53 --> Final output sent to browser
INFO - 2023-06-11 10:02:55 --> Config Class Initialized
INFO - 2023-06-11 10:02:55 --> Hooks Class Initialized
INFO - 2023-06-11 10:02:55 --> Utf8 Class Initialized
INFO - 2023-06-11 10:02:55 --> URI Class Initialized
INFO - 2023-06-11 10:02:55 --> Router Class Initialized
INFO - 2023-06-11 10:02:55 --> Output Class Initialized
INFO - 2023-06-11 10:02:55 --> Security Class Initialized
INFO - 2023-06-11 10:02:55 --> Input Class Initialized
INFO - 2023-06-11 10:02:55 --> Language Class Initialized
INFO - 2023-06-11 10:02:55 --> Loader Class Initialized
INFO - 2023-06-11 10:02:55 --> Helper loaded: url_helper
INFO - 2023-06-11 10:02:55 --> Helper loaded: form_helper
INFO - 2023-06-11 10:02:55 --> Database Driver Class Initialized
INFO - 2023-06-11 10:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:02:55 --> Form Validation Class Initialized
INFO - 2023-06-11 10:02:55 --> Controller Class Initialized
INFO - 2023-06-11 10:02:55 --> Model "m_user" initialized
INFO - 2023-06-11 10:02:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:02:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:02:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 10:02:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:02:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:02:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:02:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:02:55 --> Final output sent to browser
INFO - 2023-06-11 10:03:05 --> Config Class Initialized
INFO - 2023-06-11 10:03:05 --> Hooks Class Initialized
INFO - 2023-06-11 10:03:05 --> Utf8 Class Initialized
INFO - 2023-06-11 10:03:05 --> URI Class Initialized
INFO - 2023-06-11 10:03:05 --> Router Class Initialized
INFO - 2023-06-11 10:03:05 --> Output Class Initialized
INFO - 2023-06-11 10:03:05 --> Security Class Initialized
INFO - 2023-06-11 10:03:05 --> Input Class Initialized
INFO - 2023-06-11 10:03:05 --> Language Class Initialized
INFO - 2023-06-11 10:03:05 --> Loader Class Initialized
INFO - 2023-06-11 10:03:05 --> Helper loaded: url_helper
INFO - 2023-06-11 10:03:05 --> Helper loaded: form_helper
INFO - 2023-06-11 10:03:05 --> Database Driver Class Initialized
INFO - 2023-06-11 10:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:03:05 --> Form Validation Class Initialized
INFO - 2023-06-11 10:03:05 --> Controller Class Initialized
INFO - 2023-06-11 10:03:05 --> Model "m_user" initialized
INFO - 2023-06-11 10:03:05 --> Config Class Initialized
INFO - 2023-06-11 10:03:05 --> Hooks Class Initialized
INFO - 2023-06-11 10:03:05 --> Utf8 Class Initialized
INFO - 2023-06-11 10:03:05 --> URI Class Initialized
INFO - 2023-06-11 10:03:05 --> Router Class Initialized
INFO - 2023-06-11 10:03:05 --> Output Class Initialized
INFO - 2023-06-11 10:03:05 --> Security Class Initialized
INFO - 2023-06-11 10:03:05 --> Input Class Initialized
INFO - 2023-06-11 10:03:05 --> Language Class Initialized
INFO - 2023-06-11 10:03:05 --> Loader Class Initialized
INFO - 2023-06-11 10:03:05 --> Helper loaded: url_helper
INFO - 2023-06-11 10:03:05 --> Helper loaded: form_helper
INFO - 2023-06-11 10:03:05 --> Database Driver Class Initialized
INFO - 2023-06-11 10:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:03:05 --> Form Validation Class Initialized
INFO - 2023-06-11 10:03:05 --> Controller Class Initialized
INFO - 2023-06-11 10:03:05 --> Model "m_user" initialized
INFO - 2023-06-11 10:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 10:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:03:05 --> Final output sent to browser
INFO - 2023-06-11 10:07:43 --> Config Class Initialized
INFO - 2023-06-11 10:07:43 --> Hooks Class Initialized
INFO - 2023-06-11 10:07:43 --> Utf8 Class Initialized
INFO - 2023-06-11 10:07:44 --> URI Class Initialized
INFO - 2023-06-11 10:07:44 --> Router Class Initialized
INFO - 2023-06-11 10:07:44 --> Output Class Initialized
INFO - 2023-06-11 10:07:44 --> Security Class Initialized
INFO - 2023-06-11 10:07:44 --> Input Class Initialized
INFO - 2023-06-11 10:07:44 --> Language Class Initialized
INFO - 2023-06-11 10:07:44 --> Loader Class Initialized
INFO - 2023-06-11 10:07:44 --> Helper loaded: url_helper
INFO - 2023-06-11 10:07:44 --> Helper loaded: form_helper
INFO - 2023-06-11 10:07:44 --> Database Driver Class Initialized
INFO - 2023-06-11 10:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:07:44 --> Form Validation Class Initialized
INFO - 2023-06-11 10:07:44 --> Controller Class Initialized
INFO - 2023-06-11 10:07:44 --> Model "m_user" initialized
INFO - 2023-06-11 10:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:07:44 --> Final output sent to browser
INFO - 2023-06-11 10:07:46 --> Config Class Initialized
INFO - 2023-06-11 10:07:46 --> Hooks Class Initialized
INFO - 2023-06-11 10:07:46 --> Utf8 Class Initialized
INFO - 2023-06-11 10:07:46 --> URI Class Initialized
INFO - 2023-06-11 10:07:46 --> Router Class Initialized
INFO - 2023-06-11 10:07:46 --> Output Class Initialized
INFO - 2023-06-11 10:07:46 --> Security Class Initialized
INFO - 2023-06-11 10:07:46 --> Input Class Initialized
INFO - 2023-06-11 10:07:46 --> Language Class Initialized
INFO - 2023-06-11 10:07:46 --> Loader Class Initialized
INFO - 2023-06-11 10:07:46 --> Helper loaded: url_helper
INFO - 2023-06-11 10:07:46 --> Helper loaded: form_helper
INFO - 2023-06-11 10:07:46 --> Database Driver Class Initialized
INFO - 2023-06-11 10:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:07:46 --> Form Validation Class Initialized
INFO - 2023-06-11 10:07:46 --> Controller Class Initialized
INFO - 2023-06-11 10:07:46 --> Model "m_user" initialized
INFO - 2023-06-11 10:07:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:07:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:07:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_ubah.php
INFO - 2023-06-11 10:07:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:07:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:07:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:07:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:07:46 --> Final output sent to browser
INFO - 2023-06-11 10:08:15 --> Config Class Initialized
INFO - 2023-06-11 10:08:15 --> Hooks Class Initialized
INFO - 2023-06-11 10:08:15 --> Utf8 Class Initialized
INFO - 2023-06-11 10:08:15 --> URI Class Initialized
INFO - 2023-06-11 10:08:15 --> Router Class Initialized
INFO - 2023-06-11 10:08:15 --> Output Class Initialized
INFO - 2023-06-11 10:08:15 --> Security Class Initialized
INFO - 2023-06-11 10:08:15 --> Input Class Initialized
INFO - 2023-06-11 10:08:15 --> Language Class Initialized
INFO - 2023-06-11 10:08:15 --> Loader Class Initialized
INFO - 2023-06-11 10:08:15 --> Helper loaded: url_helper
INFO - 2023-06-11 10:08:15 --> Helper loaded: form_helper
INFO - 2023-06-11 10:08:15 --> Database Driver Class Initialized
INFO - 2023-06-11 10:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:08:15 --> Form Validation Class Initialized
INFO - 2023-06-11 10:08:15 --> Controller Class Initialized
INFO - 2023-06-11 10:08:15 --> Model "m_user" initialized
INFO - 2023-06-11 10:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:08:15 --> Final output sent to browser
INFO - 2023-06-11 10:08:19 --> Config Class Initialized
INFO - 2023-06-11 10:08:19 --> Hooks Class Initialized
INFO - 2023-06-11 10:08:19 --> Utf8 Class Initialized
INFO - 2023-06-11 10:08:19 --> URI Class Initialized
INFO - 2023-06-11 10:08:19 --> Router Class Initialized
INFO - 2023-06-11 10:08:19 --> Output Class Initialized
INFO - 2023-06-11 10:08:19 --> Security Class Initialized
INFO - 2023-06-11 10:08:19 --> Input Class Initialized
INFO - 2023-06-11 10:08:19 --> Language Class Initialized
INFO - 2023-06-11 10:08:19 --> Loader Class Initialized
INFO - 2023-06-11 10:08:19 --> Helper loaded: url_helper
INFO - 2023-06-11 10:08:19 --> Helper loaded: form_helper
INFO - 2023-06-11 10:08:19 --> Database Driver Class Initialized
INFO - 2023-06-11 10:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:08:19 --> Form Validation Class Initialized
INFO - 2023-06-11 10:08:19 --> Controller Class Initialized
INFO - 2023-06-11 10:08:19 --> Model "m_user" initialized
INFO - 2023-06-11 10:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_tambah.php
INFO - 2023-06-11 10:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:08:19 --> Final output sent to browser
INFO - 2023-06-11 10:08:28 --> Config Class Initialized
INFO - 2023-06-11 10:08:28 --> Hooks Class Initialized
INFO - 2023-06-11 10:08:28 --> Utf8 Class Initialized
INFO - 2023-06-11 10:08:28 --> URI Class Initialized
INFO - 2023-06-11 10:08:28 --> Router Class Initialized
INFO - 2023-06-11 10:08:28 --> Output Class Initialized
INFO - 2023-06-11 10:08:28 --> Security Class Initialized
INFO - 2023-06-11 10:08:28 --> Input Class Initialized
INFO - 2023-06-11 10:08:28 --> Language Class Initialized
INFO - 2023-06-11 10:08:28 --> Loader Class Initialized
INFO - 2023-06-11 10:08:28 --> Helper loaded: url_helper
INFO - 2023-06-11 10:08:28 --> Helper loaded: form_helper
INFO - 2023-06-11 10:08:28 --> Database Driver Class Initialized
INFO - 2023-06-11 10:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:08:28 --> Form Validation Class Initialized
INFO - 2023-06-11 10:08:28 --> Controller Class Initialized
INFO - 2023-06-11 10:08:28 --> Model "m_user" initialized
INFO - 2023-06-11 10:08:28 --> Config Class Initialized
INFO - 2023-06-11 10:08:28 --> Hooks Class Initialized
INFO - 2023-06-11 10:08:28 --> Utf8 Class Initialized
INFO - 2023-06-11 10:08:28 --> URI Class Initialized
INFO - 2023-06-11 10:08:28 --> Router Class Initialized
INFO - 2023-06-11 10:08:28 --> Output Class Initialized
INFO - 2023-06-11 10:08:28 --> Security Class Initialized
INFO - 2023-06-11 10:08:28 --> Input Class Initialized
INFO - 2023-06-11 10:08:28 --> Language Class Initialized
INFO - 2023-06-11 10:08:28 --> Loader Class Initialized
INFO - 2023-06-11 10:08:28 --> Helper loaded: url_helper
INFO - 2023-06-11 10:08:28 --> Helper loaded: form_helper
INFO - 2023-06-11 10:08:28 --> Database Driver Class Initialized
INFO - 2023-06-11 10:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:08:28 --> Form Validation Class Initialized
INFO - 2023-06-11 10:08:28 --> Controller Class Initialized
INFO - 2023-06-11 10:08:28 --> Model "m_user" initialized
INFO - 2023-06-11 10:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:08:28 --> Final output sent to browser
INFO - 2023-06-11 10:08:30 --> Config Class Initialized
INFO - 2023-06-11 10:08:30 --> Hooks Class Initialized
INFO - 2023-06-11 10:08:30 --> Utf8 Class Initialized
INFO - 2023-06-11 10:08:30 --> URI Class Initialized
INFO - 2023-06-11 10:08:30 --> Router Class Initialized
INFO - 2023-06-11 10:08:30 --> Output Class Initialized
INFO - 2023-06-11 10:08:30 --> Security Class Initialized
INFO - 2023-06-11 10:08:30 --> Input Class Initialized
INFO - 2023-06-11 10:08:30 --> Language Class Initialized
INFO - 2023-06-11 10:08:30 --> Loader Class Initialized
INFO - 2023-06-11 10:08:30 --> Helper loaded: url_helper
INFO - 2023-06-11 10:08:30 --> Helper loaded: form_helper
INFO - 2023-06-11 10:08:30 --> Database Driver Class Initialized
INFO - 2023-06-11 10:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:08:30 --> Form Validation Class Initialized
INFO - 2023-06-11 10:08:30 --> Controller Class Initialized
INFO - 2023-06-11 10:08:30 --> Model "m_user" initialized
INFO - 2023-06-11 10:08:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:08:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:08:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_ubah.php
INFO - 2023-06-11 10:08:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:08:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:08:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:08:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:08:30 --> Final output sent to browser
INFO - 2023-06-11 10:08:43 --> Config Class Initialized
INFO - 2023-06-11 10:08:43 --> Hooks Class Initialized
INFO - 2023-06-11 10:08:43 --> Utf8 Class Initialized
INFO - 2023-06-11 10:08:43 --> URI Class Initialized
INFO - 2023-06-11 10:08:43 --> Router Class Initialized
INFO - 2023-06-11 10:08:43 --> Output Class Initialized
INFO - 2023-06-11 10:08:43 --> Security Class Initialized
INFO - 2023-06-11 10:08:43 --> Input Class Initialized
INFO - 2023-06-11 10:08:43 --> Language Class Initialized
INFO - 2023-06-11 10:08:43 --> Loader Class Initialized
INFO - 2023-06-11 10:08:43 --> Helper loaded: url_helper
INFO - 2023-06-11 10:08:43 --> Helper loaded: form_helper
INFO - 2023-06-11 10:08:43 --> Database Driver Class Initialized
INFO - 2023-06-11 10:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:08:43 --> Form Validation Class Initialized
INFO - 2023-06-11 10:08:43 --> Controller Class Initialized
INFO - 2023-06-11 10:08:43 --> Model "m_user" initialized
ERROR - 2023-06-11 10:08:43 --> Severity: Notice --> Undefined property: C_admin::$m_tutor C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 56
ERROR - 2023-06-11 10:08:43 --> Severity: Error --> Call to a member function ubah() on null C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 56
INFO - 2023-06-11 10:08:53 --> Config Class Initialized
INFO - 2023-06-11 10:08:53 --> Hooks Class Initialized
INFO - 2023-06-11 10:08:53 --> Utf8 Class Initialized
INFO - 2023-06-11 10:08:53 --> URI Class Initialized
INFO - 2023-06-11 10:08:53 --> Router Class Initialized
INFO - 2023-06-11 10:08:53 --> Output Class Initialized
INFO - 2023-06-11 10:08:53 --> Security Class Initialized
INFO - 2023-06-11 10:08:53 --> Input Class Initialized
INFO - 2023-06-11 10:08:53 --> Language Class Initialized
INFO - 2023-06-11 10:08:53 --> Loader Class Initialized
INFO - 2023-06-11 10:08:53 --> Helper loaded: url_helper
INFO - 2023-06-11 10:08:53 --> Helper loaded: form_helper
INFO - 2023-06-11 10:08:53 --> Database Driver Class Initialized
INFO - 2023-06-11 10:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:08:54 --> Form Validation Class Initialized
INFO - 2023-06-11 10:08:54 --> Controller Class Initialized
INFO - 2023-06-11 10:08:54 --> Model "m_user" initialized
INFO - 2023-06-11 10:08:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:08:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:08:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_ubah.php
INFO - 2023-06-11 10:08:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:08:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:08:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:08:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:08:54 --> Final output sent to browser
INFO - 2023-06-11 10:09:02 --> Config Class Initialized
INFO - 2023-06-11 10:09:02 --> Hooks Class Initialized
INFO - 2023-06-11 10:09:02 --> Utf8 Class Initialized
INFO - 2023-06-11 10:09:02 --> URI Class Initialized
INFO - 2023-06-11 10:09:02 --> Router Class Initialized
INFO - 2023-06-11 10:09:02 --> Output Class Initialized
INFO - 2023-06-11 10:09:02 --> Security Class Initialized
INFO - 2023-06-11 10:09:02 --> Input Class Initialized
INFO - 2023-06-11 10:09:02 --> Language Class Initialized
INFO - 2023-06-11 10:09:02 --> Loader Class Initialized
INFO - 2023-06-11 10:09:02 --> Helper loaded: url_helper
INFO - 2023-06-11 10:09:02 --> Helper loaded: form_helper
INFO - 2023-06-11 10:09:02 --> Database Driver Class Initialized
INFO - 2023-06-11 10:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:09:03 --> Form Validation Class Initialized
INFO - 2023-06-11 10:09:03 --> Controller Class Initialized
INFO - 2023-06-11 10:09:03 --> Model "m_user" initialized
ERROR - 2023-06-11 10:09:03 --> Severity: Notice --> Undefined property: C_admin::$m_tutor C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 56
ERROR - 2023-06-11 10:09:03 --> Severity: Error --> Call to a member function ubah() on null C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_admin.php 56
INFO - 2023-06-11 10:09:37 --> Config Class Initialized
INFO - 2023-06-11 10:09:37 --> Hooks Class Initialized
INFO - 2023-06-11 10:09:37 --> Utf8 Class Initialized
INFO - 2023-06-11 10:09:37 --> URI Class Initialized
INFO - 2023-06-11 10:09:37 --> Router Class Initialized
INFO - 2023-06-11 10:09:37 --> Output Class Initialized
INFO - 2023-06-11 10:09:37 --> Security Class Initialized
INFO - 2023-06-11 10:09:37 --> Input Class Initialized
INFO - 2023-06-11 10:09:37 --> Language Class Initialized
INFO - 2023-06-11 10:09:37 --> Loader Class Initialized
INFO - 2023-06-11 10:09:37 --> Helper loaded: url_helper
INFO - 2023-06-11 10:09:37 --> Helper loaded: form_helper
INFO - 2023-06-11 10:09:37 --> Database Driver Class Initialized
INFO - 2023-06-11 10:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:09:37 --> Form Validation Class Initialized
INFO - 2023-06-11 10:09:37 --> Controller Class Initialized
INFO - 2023-06-11 10:09:37 --> Model "m_user" initialized
INFO - 2023-06-11 10:09:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:09:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:09:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_ubah.php
INFO - 2023-06-11 10:09:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:09:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:09:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:09:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:09:37 --> Final output sent to browser
INFO - 2023-06-11 10:09:46 --> Config Class Initialized
INFO - 2023-06-11 10:09:46 --> Hooks Class Initialized
INFO - 2023-06-11 10:09:46 --> Utf8 Class Initialized
INFO - 2023-06-11 10:09:46 --> URI Class Initialized
INFO - 2023-06-11 10:09:46 --> Router Class Initialized
INFO - 2023-06-11 10:09:46 --> Output Class Initialized
INFO - 2023-06-11 10:09:46 --> Security Class Initialized
INFO - 2023-06-11 10:09:46 --> Input Class Initialized
INFO - 2023-06-11 10:09:46 --> Language Class Initialized
INFO - 2023-06-11 10:09:46 --> Loader Class Initialized
INFO - 2023-06-11 10:09:46 --> Helper loaded: url_helper
INFO - 2023-06-11 10:09:46 --> Helper loaded: form_helper
INFO - 2023-06-11 10:09:46 --> Database Driver Class Initialized
INFO - 2023-06-11 10:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:09:46 --> Form Validation Class Initialized
INFO - 2023-06-11 10:09:46 --> Controller Class Initialized
INFO - 2023-06-11 10:09:46 --> Model "m_user" initialized
INFO - 2023-06-11 10:09:46 --> Config Class Initialized
INFO - 2023-06-11 10:09:46 --> Hooks Class Initialized
INFO - 2023-06-11 10:09:46 --> Utf8 Class Initialized
INFO - 2023-06-11 10:09:46 --> URI Class Initialized
INFO - 2023-06-11 10:09:46 --> Router Class Initialized
INFO - 2023-06-11 10:09:46 --> Output Class Initialized
INFO - 2023-06-11 10:09:46 --> Security Class Initialized
INFO - 2023-06-11 10:09:46 --> Input Class Initialized
INFO - 2023-06-11 10:09:46 --> Language Class Initialized
INFO - 2023-06-11 10:09:46 --> Loader Class Initialized
INFO - 2023-06-11 10:09:46 --> Helper loaded: url_helper
INFO - 2023-06-11 10:09:46 --> Helper loaded: form_helper
INFO - 2023-06-11 10:09:46 --> Database Driver Class Initialized
INFO - 2023-06-11 10:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:09:46 --> Form Validation Class Initialized
INFO - 2023-06-11 10:09:46 --> Controller Class Initialized
INFO - 2023-06-11 10:09:46 --> Model "m_user" initialized
INFO - 2023-06-11 10:09:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:09:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:09:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:09:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:09:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:09:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:09:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:09:46 --> Final output sent to browser
INFO - 2023-06-11 10:09:48 --> Config Class Initialized
INFO - 2023-06-11 10:09:48 --> Hooks Class Initialized
INFO - 2023-06-11 10:09:48 --> Database Driver Class Initialized
INFO - 2023-06-11 10:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:09:48 --> Form Validation Class Initialized
INFO - 2023-06-11 10:09:48 --> Controller Class Initialized
INFO - 2023-06-11 10:09:48 --> Model "m_user" initialized
INFO - 2023-06-11 10:09:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:09:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:09:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_ubah.php
INFO - 2023-06-11 10:09:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:09:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:09:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:09:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:09:48 --> Final output sent to browser
INFO - 2023-06-11 10:09:58 --> Config Class Initialized
INFO - 2023-06-11 10:09:58 --> Hooks Class Initialized
INFO - 2023-06-11 10:09:58 --> Utf8 Class Initialized
INFO - 2023-06-11 10:09:58 --> URI Class Initialized
INFO - 2023-06-11 10:09:58 --> Router Class Initialized
INFO - 2023-06-11 10:09:58 --> Output Class Initialized
INFO - 2023-06-11 10:09:58 --> Security Class Initialized
INFO - 2023-06-11 10:09:58 --> Input Class Initialized
INFO - 2023-06-11 10:09:58 --> Language Class Initialized
INFO - 2023-06-11 10:09:58 --> Loader Class Initialized
INFO - 2023-06-11 10:09:58 --> Helper loaded: url_helper
INFO - 2023-06-11 10:09:58 --> Helper loaded: form_helper
INFO - 2023-06-11 10:09:58 --> Database Driver Class Initialized
INFO - 2023-06-11 10:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:09:58 --> Form Validation Class Initialized
INFO - 2023-06-11 10:09:58 --> Controller Class Initialized
INFO - 2023-06-11 10:09:58 --> Model "m_user" initialized
INFO - 2023-06-11 10:09:58 --> Config Class Initialized
INFO - 2023-06-11 10:09:58 --> Hooks Class Initialized
INFO - 2023-06-11 10:09:58 --> Utf8 Class Initialized
INFO - 2023-06-11 10:09:58 --> URI Class Initialized
INFO - 2023-06-11 10:09:58 --> Router Class Initialized
INFO - 2023-06-11 10:09:58 --> Output Class Initialized
INFO - 2023-06-11 10:09:58 --> Security Class Initialized
INFO - 2023-06-11 10:09:58 --> Input Class Initialized
INFO - 2023-06-11 10:09:58 --> Language Class Initialized
INFO - 2023-06-11 10:09:58 --> Loader Class Initialized
INFO - 2023-06-11 10:09:58 --> Helper loaded: url_helper
INFO - 2023-06-11 10:09:58 --> Helper loaded: form_helper
INFO - 2023-06-11 10:09:58 --> Database Driver Class Initialized
INFO - 2023-06-11 10:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:09:58 --> Form Validation Class Initialized
INFO - 2023-06-11 10:09:58 --> Controller Class Initialized
INFO - 2023-06-11 10:09:58 --> Model "m_user" initialized
INFO - 2023-06-11 10:09:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:09:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:09:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:09:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:09:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:09:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:09:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:09:58 --> Final output sent to browser
INFO - 2023-06-11 10:10:03 --> Config Class Initialized
INFO - 2023-06-11 10:10:03 --> Hooks Class Initialized
INFO - 2023-06-11 10:10:03 --> Utf8 Class Initialized
INFO - 2023-06-11 10:10:03 --> URI Class Initialized
INFO - 2023-06-11 10:10:03 --> Router Class Initialized
INFO - 2023-06-11 10:10:03 --> Output Class Initialized
INFO - 2023-06-11 10:10:03 --> Security Class Initialized
INFO - 2023-06-11 10:10:03 --> Input Class Initialized
INFO - 2023-06-11 10:10:03 --> Language Class Initialized
INFO - 2023-06-11 10:10:03 --> Loader Class Initialized
INFO - 2023-06-11 10:10:03 --> Helper loaded: url_helper
INFO - 2023-06-11 10:10:03 --> Helper loaded: form_helper
INFO - 2023-06-11 10:10:03 --> Database Driver Class Initialized
INFO - 2023-06-11 10:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:10:03 --> Form Validation Class Initialized
INFO - 2023-06-11 10:10:03 --> Controller Class Initialized
INFO - 2023-06-11 10:10:03 --> Model "m_user" initialized
INFO - 2023-06-11 10:10:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:10:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:10:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_ubah.php
INFO - 2023-06-11 10:10:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:10:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:10:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:10:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:10:03 --> Final output sent to browser
INFO - 2023-06-11 10:10:33 --> Config Class Initialized
INFO - 2023-06-11 10:10:33 --> Hooks Class Initialized
INFO - 2023-06-11 10:10:33 --> Utf8 Class Initialized
INFO - 2023-06-11 10:10:33 --> URI Class Initialized
INFO - 2023-06-11 10:10:33 --> Router Class Initialized
INFO - 2023-06-11 10:10:33 --> Output Class Initialized
INFO - 2023-06-11 10:10:33 --> Security Class Initialized
INFO - 2023-06-11 10:10:33 --> Input Class Initialized
INFO - 2023-06-11 10:10:33 --> Language Class Initialized
INFO - 2023-06-11 10:10:33 --> Loader Class Initialized
INFO - 2023-06-11 10:10:33 --> Helper loaded: url_helper
INFO - 2023-06-11 10:10:33 --> Helper loaded: form_helper
INFO - 2023-06-11 10:10:33 --> Database Driver Class Initialized
INFO - 2023-06-11 10:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:10:33 --> Form Validation Class Initialized
INFO - 2023-06-11 10:10:33 --> Controller Class Initialized
INFO - 2023-06-11 10:10:33 --> Model "m_user" initialized
INFO - 2023-06-11 10:10:34 --> Config Class Initialized
INFO - 2023-06-11 10:10:34 --> Hooks Class Initialized
INFO - 2023-06-11 10:10:34 --> Utf8 Class Initialized
INFO - 2023-06-11 10:10:34 --> URI Class Initialized
INFO - 2023-06-11 10:10:34 --> Router Class Initialized
INFO - 2023-06-11 10:10:34 --> Output Class Initialized
INFO - 2023-06-11 10:10:34 --> Security Class Initialized
INFO - 2023-06-11 10:10:34 --> Input Class Initialized
INFO - 2023-06-11 10:10:34 --> Language Class Initialized
INFO - 2023-06-11 10:10:34 --> Loader Class Initialized
INFO - 2023-06-11 10:10:34 --> Helper loaded: url_helper
INFO - 2023-06-11 10:10:34 --> Helper loaded: form_helper
INFO - 2023-06-11 10:10:34 --> Database Driver Class Initialized
INFO - 2023-06-11 10:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:10:34 --> Form Validation Class Initialized
INFO - 2023-06-11 10:10:34 --> Controller Class Initialized
INFO - 2023-06-11 10:10:34 --> Model "m_user" initialized
INFO - 2023-06-11 10:10:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:10:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:10:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:10:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:10:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:10:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:10:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:10:34 --> Final output sent to browser
INFO - 2023-06-11 10:10:35 --> Config Class Initialized
INFO - 2023-06-11 10:10:35 --> Hooks Class Initialized
INFO - 2023-06-11 10:10:35 --> Utf8 Class Initialized
INFO - 2023-06-11 10:10:35 --> URI Class Initialized
INFO - 2023-06-11 10:10:35 --> Router Class Initialized
INFO - 2023-06-11 10:10:35 --> Output Class Initialized
INFO - 2023-06-11 10:10:35 --> Security Class Initialized
INFO - 2023-06-11 10:10:35 --> Input Class Initialized
INFO - 2023-06-11 10:10:35 --> Language Class Initialized
INFO - 2023-06-11 10:10:35 --> Loader Class Initialized
INFO - 2023-06-11 10:10:35 --> Helper loaded: url_helper
INFO - 2023-06-11 10:10:35 --> Helper loaded: form_helper
INFO - 2023-06-11 10:10:35 --> Database Driver Class Initialized
INFO - 2023-06-11 10:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:10:35 --> Form Validation Class Initialized
INFO - 2023-06-11 10:10:35 --> Controller Class Initialized
INFO - 2023-06-11 10:10:35 --> Model "m_user" initialized
INFO - 2023-06-11 10:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_ubah.php
INFO - 2023-06-11 10:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:10:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:10:35 --> Final output sent to browser
INFO - 2023-06-11 10:10:43 --> Config Class Initialized
INFO - 2023-06-11 10:10:43 --> Hooks Class Initialized
INFO - 2023-06-11 10:10:43 --> Utf8 Class Initialized
INFO - 2023-06-11 10:10:43 --> URI Class Initialized
INFO - 2023-06-11 10:10:43 --> Router Class Initialized
INFO - 2023-06-11 10:10:43 --> Output Class Initialized
INFO - 2023-06-11 10:10:43 --> Security Class Initialized
INFO - 2023-06-11 10:10:43 --> Input Class Initialized
INFO - 2023-06-11 10:10:43 --> Language Class Initialized
INFO - 2023-06-11 10:10:43 --> Loader Class Initialized
INFO - 2023-06-11 10:10:43 --> Helper loaded: url_helper
INFO - 2023-06-11 10:10:43 --> Helper loaded: form_helper
INFO - 2023-06-11 10:10:43 --> Database Driver Class Initialized
INFO - 2023-06-11 10:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:10:43 --> Form Validation Class Initialized
INFO - 2023-06-11 10:10:43 --> Controller Class Initialized
INFO - 2023-06-11 10:10:43 --> Model "m_user" initialized
INFO - 2023-06-11 10:10:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:10:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:10:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:10:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:10:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:10:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:10:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:10:43 --> Final output sent to browser
INFO - 2023-06-11 10:12:30 --> Config Class Initialized
INFO - 2023-06-11 10:12:30 --> Hooks Class Initialized
INFO - 2023-06-11 10:12:30 --> Utf8 Class Initialized
INFO - 2023-06-11 10:12:30 --> URI Class Initialized
INFO - 2023-06-11 10:12:30 --> Router Class Initialized
INFO - 2023-06-11 10:12:30 --> Output Class Initialized
INFO - 2023-06-11 10:12:30 --> Security Class Initialized
INFO - 2023-06-11 10:12:30 --> Input Class Initialized
INFO - 2023-06-11 10:12:30 --> Language Class Initialized
INFO - 2023-06-11 10:12:30 --> Loader Class Initialized
INFO - 2023-06-11 10:12:30 --> Helper loaded: url_helper
INFO - 2023-06-11 10:12:31 --> Helper loaded: form_helper
INFO - 2023-06-11 10:12:31 --> Database Driver Class Initialized
INFO - 2023-06-11 10:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:12:31 --> Form Validation Class Initialized
INFO - 2023-06-11 10:12:31 --> Controller Class Initialized
INFO - 2023-06-11 10:12:31 --> Model "m_user" initialized
INFO - 2023-06-11 10:12:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:12:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:12:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_ubah.php
INFO - 2023-06-11 10:12:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:12:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:12:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:12:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:12:31 --> Final output sent to browser
INFO - 2023-06-11 10:12:39 --> Config Class Initialized
INFO - 2023-06-11 10:12:39 --> Hooks Class Initialized
INFO - 2023-06-11 10:12:39 --> Utf8 Class Initialized
INFO - 2023-06-11 10:12:39 --> URI Class Initialized
INFO - 2023-06-11 10:12:39 --> Router Class Initialized
INFO - 2023-06-11 10:12:39 --> Output Class Initialized
INFO - 2023-06-11 10:12:39 --> Security Class Initialized
INFO - 2023-06-11 10:12:39 --> Input Class Initialized
INFO - 2023-06-11 10:12:39 --> Language Class Initialized
INFO - 2023-06-11 10:12:39 --> Loader Class Initialized
INFO - 2023-06-11 10:12:39 --> Helper loaded: url_helper
INFO - 2023-06-11 10:12:39 --> Helper loaded: form_helper
INFO - 2023-06-11 10:12:39 --> Database Driver Class Initialized
INFO - 2023-06-11 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:12:39 --> Form Validation Class Initialized
INFO - 2023-06-11 10:12:39 --> Controller Class Initialized
INFO - 2023-06-11 10:12:39 --> Model "m_user" initialized
INFO - 2023-06-11 10:12:39 --> Config Class Initialized
INFO - 2023-06-11 10:12:39 --> Hooks Class Initialized
INFO - 2023-06-11 10:12:39 --> Utf8 Class Initialized
INFO - 2023-06-11 10:12:39 --> URI Class Initialized
INFO - 2023-06-11 10:12:39 --> Router Class Initialized
INFO - 2023-06-11 10:12:39 --> Output Class Initialized
INFO - 2023-06-11 10:12:39 --> Security Class Initialized
INFO - 2023-06-11 10:12:39 --> Input Class Initialized
INFO - 2023-06-11 10:12:39 --> Language Class Initialized
INFO - 2023-06-11 10:12:39 --> Loader Class Initialized
INFO - 2023-06-11 10:12:39 --> Helper loaded: url_helper
INFO - 2023-06-11 10:12:39 --> Helper loaded: form_helper
INFO - 2023-06-11 10:12:39 --> Database Driver Class Initialized
INFO - 2023-06-11 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:12:39 --> Form Validation Class Initialized
INFO - 2023-06-11 10:12:39 --> Controller Class Initialized
INFO - 2023-06-11 10:12:39 --> Model "m_user" initialized
INFO - 2023-06-11 10:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:12:39 --> Final output sent to browser
INFO - 2023-06-11 10:12:42 --> Config Class Initialized
INFO - 2023-06-11 10:12:42 --> Hooks Class Initialized
INFO - 2023-06-11 10:12:42 --> Utf8 Class Initialized
INFO - 2023-06-11 10:12:42 --> URI Class Initialized
INFO - 2023-06-11 10:12:42 --> Router Class Initialized
INFO - 2023-06-11 10:12:42 --> Output Class Initialized
INFO - 2023-06-11 10:12:42 --> Security Class Initialized
INFO - 2023-06-11 10:12:42 --> Input Class Initialized
INFO - 2023-06-11 10:12:42 --> Language Class Initialized
INFO - 2023-06-11 10:12:42 --> Loader Class Initialized
INFO - 2023-06-11 10:12:42 --> Helper loaded: url_helper
INFO - 2023-06-11 10:12:42 --> Helper loaded: form_helper
INFO - 2023-06-11 10:12:42 --> Database Driver Class Initialized
INFO - 2023-06-11 10:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:12:42 --> Form Validation Class Initialized
INFO - 2023-06-11 10:12:42 --> Controller Class Initialized
INFO - 2023-06-11 10:12:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 10:12:42 --> Final output sent to browser
INFO - 2023-06-11 10:12:44 --> Config Class Initialized
INFO - 2023-06-11 10:12:44 --> Hooks Class Initialized
INFO - 2023-06-11 10:12:44 --> Utf8 Class Initialized
INFO - 2023-06-11 10:12:44 --> URI Class Initialized
INFO - 2023-06-11 10:12:44 --> Router Class Initialized
INFO - 2023-06-11 10:12:44 --> Output Class Initialized
INFO - 2023-06-11 10:12:44 --> Security Class Initialized
INFO - 2023-06-11 10:12:44 --> Input Class Initialized
INFO - 2023-06-11 10:12:44 --> Language Class Initialized
INFO - 2023-06-11 10:12:44 --> Loader Class Initialized
INFO - 2023-06-11 10:12:44 --> Helper loaded: url_helper
INFO - 2023-06-11 10:12:44 --> Helper loaded: form_helper
INFO - 2023-06-11 10:12:44 --> Database Driver Class Initialized
INFO - 2023-06-11 10:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:12:44 --> Form Validation Class Initialized
INFO - 2023-06-11 10:12:44 --> Controller Class Initialized
INFO - 2023-06-11 10:12:44 --> Model "m_user" initialized
INFO - 2023-06-11 10:12:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-11 10:12:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-11 10:12:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-11 10:12:44 --> Final output sent to browser
INFO - 2023-06-11 10:12:50 --> Config Class Initialized
INFO - 2023-06-11 10:12:50 --> Hooks Class Initialized
INFO - 2023-06-11 10:12:50 --> Utf8 Class Initialized
INFO - 2023-06-11 10:12:50 --> URI Class Initialized
INFO - 2023-06-11 10:12:50 --> Router Class Initialized
INFO - 2023-06-11 10:12:50 --> Output Class Initialized
INFO - 2023-06-11 10:12:50 --> Security Class Initialized
INFO - 2023-06-11 10:12:50 --> Input Class Initialized
INFO - 2023-06-11 10:12:50 --> Language Class Initialized
INFO - 2023-06-11 10:12:50 --> Loader Class Initialized
INFO - 2023-06-11 10:12:50 --> Helper loaded: url_helper
INFO - 2023-06-11 10:12:50 --> Helper loaded: form_helper
INFO - 2023-06-11 10:12:50 --> Database Driver Class Initialized
INFO - 2023-06-11 10:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:12:50 --> Form Validation Class Initialized
INFO - 2023-06-11 10:12:50 --> Controller Class Initialized
INFO - 2023-06-11 10:12:50 --> Model "m_user" initialized
INFO - 2023-06-11 10:12:50 --> Config Class Initialized
INFO - 2023-06-11 10:12:50 --> Hooks Class Initialized
INFO - 2023-06-11 10:12:50 --> Utf8 Class Initialized
INFO - 2023-06-11 10:12:50 --> URI Class Initialized
INFO - 2023-06-11 10:12:50 --> Router Class Initialized
INFO - 2023-06-11 10:12:50 --> Output Class Initialized
INFO - 2023-06-11 10:12:50 --> Security Class Initialized
INFO - 2023-06-11 10:12:50 --> Input Class Initialized
INFO - 2023-06-11 10:12:50 --> Language Class Initialized
INFO - 2023-06-11 10:12:50 --> Loader Class Initialized
INFO - 2023-06-11 10:12:50 --> Helper loaded: url_helper
INFO - 2023-06-11 10:12:50 --> Helper loaded: form_helper
INFO - 2023-06-11 10:12:50 --> Database Driver Class Initialized
INFO - 2023-06-11 10:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:12:50 --> Form Validation Class Initialized
INFO - 2023-06-11 10:12:50 --> Controller Class Initialized
INFO - 2023-06-11 10:12:50 --> Model "m_user" initialized
INFO - 2023-06-11 10:12:50 --> Model "m_datatrain" initialized
INFO - 2023-06-11 10:12:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:12:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:12:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:12:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:12:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:12:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 10:12:50 --> Final output sent to browser
INFO - 2023-06-11 10:12:53 --> Config Class Initialized
INFO - 2023-06-11 10:12:53 --> Hooks Class Initialized
INFO - 2023-06-11 10:12:53 --> Utf8 Class Initialized
INFO - 2023-06-11 10:12:53 --> URI Class Initialized
INFO - 2023-06-11 10:12:53 --> Router Class Initialized
INFO - 2023-06-11 10:12:53 --> Output Class Initialized
INFO - 2023-06-11 10:12:53 --> Security Class Initialized
INFO - 2023-06-11 10:12:53 --> Input Class Initialized
INFO - 2023-06-11 10:12:53 --> Language Class Initialized
INFO - 2023-06-11 10:12:53 --> Loader Class Initialized
INFO - 2023-06-11 10:12:53 --> Helper loaded: url_helper
INFO - 2023-06-11 10:12:53 --> Helper loaded: form_helper
INFO - 2023-06-11 10:12:53 --> Database Driver Class Initialized
INFO - 2023-06-11 10:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:12:53 --> Form Validation Class Initialized
INFO - 2023-06-11 10:12:53 --> Controller Class Initialized
INFO - 2023-06-11 10:12:53 --> Model "m_user" initialized
INFO - 2023-06-11 10:12:53 --> Config Class Initialized
INFO - 2023-06-11 10:12:53 --> Hooks Class Initialized
INFO - 2023-06-11 10:12:53 --> Utf8 Class Initialized
INFO - 2023-06-11 10:12:53 --> URI Class Initialized
INFO - 2023-06-11 10:12:53 --> Router Class Initialized
INFO - 2023-06-11 10:12:53 --> Output Class Initialized
INFO - 2023-06-11 10:12:53 --> Security Class Initialized
INFO - 2023-06-11 10:12:53 --> Input Class Initialized
INFO - 2023-06-11 10:12:53 --> Language Class Initialized
INFO - 2023-06-11 10:12:53 --> Loader Class Initialized
INFO - 2023-06-11 10:12:53 --> Helper loaded: url_helper
INFO - 2023-06-11 10:12:53 --> Helper loaded: form_helper
INFO - 2023-06-11 10:12:53 --> Database Driver Class Initialized
INFO - 2023-06-11 10:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:12:53 --> Form Validation Class Initialized
INFO - 2023-06-11 10:12:53 --> Controller Class Initialized
INFO - 2023-06-11 10:12:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 10:12:53 --> Final output sent to browser
INFO - 2023-06-11 10:15:20 --> Config Class Initialized
INFO - 2023-06-11 10:15:20 --> Hooks Class Initialized
INFO - 2023-06-11 10:15:20 --> Utf8 Class Initialized
INFO - 2023-06-11 10:15:20 --> URI Class Initialized
INFO - 2023-06-11 10:15:21 --> Router Class Initialized
INFO - 2023-06-11 10:15:21 --> Output Class Initialized
INFO - 2023-06-11 10:15:21 --> Security Class Initialized
INFO - 2023-06-11 10:15:21 --> Input Class Initialized
INFO - 2023-06-11 10:15:21 --> Language Class Initialized
INFO - 2023-06-11 10:15:21 --> Loader Class Initialized
INFO - 2023-06-11 10:15:21 --> Helper loaded: url_helper
INFO - 2023-06-11 10:15:21 --> Helper loaded: form_helper
INFO - 2023-06-11 10:15:21 --> Database Driver Class Initialized
INFO - 2023-06-11 10:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:15:21 --> Form Validation Class Initialized
INFO - 2023-06-11 10:15:21 --> Controller Class Initialized
INFO - 2023-06-11 10:15:21 --> Model "m_user" initialized
INFO - 2023-06-11 10:15:21 --> Config Class Initialized
INFO - 2023-06-11 10:15:21 --> Hooks Class Initialized
INFO - 2023-06-11 10:15:21 --> Utf8 Class Initialized
INFO - 2023-06-11 10:15:21 --> URI Class Initialized
INFO - 2023-06-11 10:15:21 --> Router Class Initialized
INFO - 2023-06-11 10:15:21 --> Output Class Initialized
INFO - 2023-06-11 10:15:21 --> Security Class Initialized
INFO - 2023-06-11 10:15:21 --> Input Class Initialized
INFO - 2023-06-11 10:15:21 --> Language Class Initialized
INFO - 2023-06-11 10:15:21 --> Loader Class Initialized
INFO - 2023-06-11 10:15:21 --> Helper loaded: url_helper
INFO - 2023-06-11 10:15:21 --> Helper loaded: form_helper
INFO - 2023-06-11 10:15:21 --> Database Driver Class Initialized
INFO - 2023-06-11 10:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:15:21 --> Form Validation Class Initialized
INFO - 2023-06-11 10:15:21 --> Controller Class Initialized
INFO - 2023-06-11 10:15:21 --> Model "m_user" initialized
INFO - 2023-06-11 10:15:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-11 10:15:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-11 10:15:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-11 10:15:21 --> Final output sent to browser
INFO - 2023-06-11 10:15:25 --> Config Class Initialized
INFO - 2023-06-11 10:15:25 --> Hooks Class Initialized
INFO - 2023-06-11 10:15:25 --> Utf8 Class Initialized
INFO - 2023-06-11 10:15:25 --> URI Class Initialized
INFO - 2023-06-11 10:15:25 --> Router Class Initialized
INFO - 2023-06-11 10:15:25 --> Output Class Initialized
INFO - 2023-06-11 10:15:25 --> Security Class Initialized
INFO - 2023-06-11 10:15:25 --> Input Class Initialized
INFO - 2023-06-11 10:15:25 --> Language Class Initialized
INFO - 2023-06-11 10:15:25 --> Loader Class Initialized
INFO - 2023-06-11 10:15:25 --> Helper loaded: url_helper
INFO - 2023-06-11 10:15:25 --> Helper loaded: form_helper
INFO - 2023-06-11 10:15:25 --> Database Driver Class Initialized
INFO - 2023-06-11 10:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:15:25 --> Form Validation Class Initialized
INFO - 2023-06-11 10:15:25 --> Controller Class Initialized
INFO - 2023-06-11 10:15:25 --> Model "m_user" initialized
INFO - 2023-06-11 10:15:25 --> Config Class Initialized
INFO - 2023-06-11 10:15:25 --> Hooks Class Initialized
INFO - 2023-06-11 10:15:25 --> Utf8 Class Initialized
INFO - 2023-06-11 10:15:25 --> URI Class Initialized
INFO - 2023-06-11 10:15:25 --> Router Class Initialized
INFO - 2023-06-11 10:15:25 --> Output Class Initialized
INFO - 2023-06-11 10:15:25 --> Security Class Initialized
INFO - 2023-06-11 10:15:25 --> Input Class Initialized
INFO - 2023-06-11 10:15:25 --> Language Class Initialized
INFO - 2023-06-11 10:15:25 --> Loader Class Initialized
INFO - 2023-06-11 10:15:25 --> Helper loaded: url_helper
INFO - 2023-06-11 10:15:25 --> Helper loaded: form_helper
INFO - 2023-06-11 10:15:25 --> Database Driver Class Initialized
INFO - 2023-06-11 10:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:15:25 --> Form Validation Class Initialized
INFO - 2023-06-11 10:15:25 --> Controller Class Initialized
INFO - 2023-06-11 10:15:25 --> Model "m_user" initialized
INFO - 2023-06-11 10:15:25 --> Model "m_datatrain" initialized
INFO - 2023-06-11 10:15:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:15:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:15:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:15:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:15:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:15:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 10:15:25 --> Final output sent to browser
INFO - 2023-06-11 10:15:29 --> Config Class Initialized
INFO - 2023-06-11 10:15:29 --> Hooks Class Initialized
INFO - 2023-06-11 10:15:29 --> Utf8 Class Initialized
INFO - 2023-06-11 10:15:29 --> URI Class Initialized
INFO - 2023-06-11 10:15:29 --> Router Class Initialized
INFO - 2023-06-11 10:15:29 --> Output Class Initialized
INFO - 2023-06-11 10:15:29 --> Security Class Initialized
INFO - 2023-06-11 10:15:29 --> Input Class Initialized
INFO - 2023-06-11 10:15:29 --> Language Class Initialized
INFO - 2023-06-11 10:15:29 --> Loader Class Initialized
INFO - 2023-06-11 10:15:29 --> Helper loaded: url_helper
INFO - 2023-06-11 10:15:29 --> Helper loaded: form_helper
INFO - 2023-06-11 10:15:29 --> Database Driver Class Initialized
INFO - 2023-06-11 10:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:15:29 --> Form Validation Class Initialized
INFO - 2023-06-11 10:15:29 --> Controller Class Initialized
INFO - 2023-06-11 10:15:29 --> Model "m_user" initialized
INFO - 2023-06-11 10:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:15:29 --> Final output sent to browser
INFO - 2023-06-11 10:15:31 --> Config Class Initialized
INFO - 2023-06-11 10:15:31 --> Hooks Class Initialized
INFO - 2023-06-11 10:15:31 --> Utf8 Class Initialized
INFO - 2023-06-11 10:15:31 --> URI Class Initialized
INFO - 2023-06-11 10:15:31 --> Router Class Initialized
INFO - 2023-06-11 10:15:31 --> Output Class Initialized
INFO - 2023-06-11 10:15:31 --> Security Class Initialized
INFO - 2023-06-11 10:15:31 --> Input Class Initialized
INFO - 2023-06-11 10:15:31 --> Language Class Initialized
INFO - 2023-06-11 10:15:31 --> Loader Class Initialized
INFO - 2023-06-11 10:15:31 --> Helper loaded: url_helper
INFO - 2023-06-11 10:15:31 --> Helper loaded: form_helper
INFO - 2023-06-11 10:15:31 --> Database Driver Class Initialized
INFO - 2023-06-11 10:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:15:31 --> Form Validation Class Initialized
INFO - 2023-06-11 10:15:31 --> Controller Class Initialized
INFO - 2023-06-11 10:15:31 --> Model "m_user" initialized
INFO - 2023-06-11 10:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_ubah.php
INFO - 2023-06-11 10:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:15:31 --> Final output sent to browser
INFO - 2023-06-11 10:15:36 --> Config Class Initialized
INFO - 2023-06-11 10:15:36 --> Hooks Class Initialized
INFO - 2023-06-11 10:15:36 --> Utf8 Class Initialized
INFO - 2023-06-11 10:15:36 --> URI Class Initialized
INFO - 2023-06-11 10:15:36 --> Router Class Initialized
INFO - 2023-06-11 10:15:36 --> Output Class Initialized
INFO - 2023-06-11 10:15:36 --> Security Class Initialized
INFO - 2023-06-11 10:15:36 --> Input Class Initialized
INFO - 2023-06-11 10:15:36 --> Language Class Initialized
INFO - 2023-06-11 10:15:36 --> Loader Class Initialized
INFO - 2023-06-11 10:15:36 --> Helper loaded: url_helper
INFO - 2023-06-11 10:15:36 --> Helper loaded: form_helper
INFO - 2023-06-11 10:15:36 --> Database Driver Class Initialized
INFO - 2023-06-11 10:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:15:36 --> Form Validation Class Initialized
INFO - 2023-06-11 10:15:36 --> Controller Class Initialized
INFO - 2023-06-11 10:15:36 --> Model "m_user" initialized
INFO - 2023-06-11 10:15:36 --> Config Class Initialized
INFO - 2023-06-11 10:15:36 --> Hooks Class Initialized
INFO - 2023-06-11 10:15:36 --> Utf8 Class Initialized
INFO - 2023-06-11 10:15:36 --> URI Class Initialized
INFO - 2023-06-11 10:15:36 --> Router Class Initialized
INFO - 2023-06-11 10:15:36 --> Output Class Initialized
INFO - 2023-06-11 10:15:36 --> Security Class Initialized
INFO - 2023-06-11 10:15:36 --> Input Class Initialized
INFO - 2023-06-11 10:15:36 --> Language Class Initialized
INFO - 2023-06-11 10:15:36 --> Loader Class Initialized
INFO - 2023-06-11 10:15:36 --> Helper loaded: url_helper
INFO - 2023-06-11 10:15:36 --> Helper loaded: form_helper
INFO - 2023-06-11 10:15:36 --> Database Driver Class Initialized
INFO - 2023-06-11 10:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:15:37 --> Form Validation Class Initialized
INFO - 2023-06-11 10:15:37 --> Controller Class Initialized
INFO - 2023-06-11 10:15:37 --> Model "m_user" initialized
INFO - 2023-06-11 10:15:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:15:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:15:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_ubah.php
INFO - 2023-06-11 10:15:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:15:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:15:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:15:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:15:37 --> Final output sent to browser
INFO - 2023-06-11 10:15:49 --> Config Class Initialized
INFO - 2023-06-11 10:15:49 --> Hooks Class Initialized
INFO - 2023-06-11 10:15:49 --> Utf8 Class Initialized
INFO - 2023-06-11 10:15:49 --> URI Class Initialized
INFO - 2023-06-11 10:15:49 --> Router Class Initialized
INFO - 2023-06-11 10:15:49 --> Output Class Initialized
INFO - 2023-06-11 10:15:49 --> Security Class Initialized
INFO - 2023-06-11 10:15:49 --> Input Class Initialized
INFO - 2023-06-11 10:15:49 --> Language Class Initialized
INFO - 2023-06-11 10:15:49 --> Loader Class Initialized
INFO - 2023-06-11 10:15:49 --> Helper loaded: url_helper
INFO - 2023-06-11 10:15:49 --> Helper loaded: form_helper
INFO - 2023-06-11 10:15:49 --> Database Driver Class Initialized
INFO - 2023-06-11 10:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:15:49 --> Form Validation Class Initialized
INFO - 2023-06-11 10:15:49 --> Controller Class Initialized
INFO - 2023-06-11 10:15:49 --> Model "m_user" initialized
INFO - 2023-06-11 10:15:49 --> Config Class Initialized
INFO - 2023-06-11 10:15:49 --> Hooks Class Initialized
INFO - 2023-06-11 10:15:49 --> Utf8 Class Initialized
INFO - 2023-06-11 10:15:49 --> URI Class Initialized
INFO - 2023-06-11 10:15:49 --> Router Class Initialized
INFO - 2023-06-11 10:15:49 --> Output Class Initialized
INFO - 2023-06-11 10:15:49 --> Security Class Initialized
INFO - 2023-06-11 10:15:49 --> Input Class Initialized
INFO - 2023-06-11 10:15:49 --> Language Class Initialized
INFO - 2023-06-11 10:15:49 --> Loader Class Initialized
INFO - 2023-06-11 10:15:49 --> Helper loaded: url_helper
INFO - 2023-06-11 10:15:49 --> Helper loaded: form_helper
INFO - 2023-06-11 10:15:49 --> Database Driver Class Initialized
INFO - 2023-06-11 10:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:15:49 --> Form Validation Class Initialized
INFO - 2023-06-11 10:15:49 --> Controller Class Initialized
INFO - 2023-06-11 10:15:49 --> Model "m_user" initialized
INFO - 2023-06-11 10:15:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:15:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:15:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_ubah.php
INFO - 2023-06-11 10:15:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:15:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:15:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:15:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:15:49 --> Final output sent to browser
INFO - 2023-06-11 10:16:00 --> Config Class Initialized
INFO - 2023-06-11 10:16:00 --> Hooks Class Initialized
INFO - 2023-06-11 10:16:00 --> Utf8 Class Initialized
INFO - 2023-06-11 10:16:00 --> URI Class Initialized
INFO - 2023-06-11 10:16:00 --> Router Class Initialized
INFO - 2023-06-11 10:16:00 --> Output Class Initialized
INFO - 2023-06-11 10:16:00 --> Security Class Initialized
INFO - 2023-06-11 10:16:00 --> Input Class Initialized
INFO - 2023-06-11 10:16:00 --> Language Class Initialized
INFO - 2023-06-11 10:16:00 --> Loader Class Initialized
INFO - 2023-06-11 10:16:00 --> Helper loaded: url_helper
INFO - 2023-06-11 10:16:00 --> Helper loaded: form_helper
INFO - 2023-06-11 10:16:00 --> Database Driver Class Initialized
INFO - 2023-06-11 10:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:16:00 --> Form Validation Class Initialized
INFO - 2023-06-11 10:16:00 --> Controller Class Initialized
INFO - 2023-06-11 10:16:00 --> Model "m_user" initialized
INFO - 2023-06-11 10:16:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:16:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:16:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:16:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:16:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:16:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:16:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:16:00 --> Final output sent to browser
INFO - 2023-06-11 10:16:01 --> Config Class Initialized
INFO - 2023-06-11 10:16:01 --> Hooks Class Initialized
INFO - 2023-06-11 10:16:01 --> Utf8 Class Initialized
INFO - 2023-06-11 10:16:01 --> URI Class Initialized
INFO - 2023-06-11 10:16:01 --> Router Class Initialized
INFO - 2023-06-11 10:16:01 --> Output Class Initialized
INFO - 2023-06-11 10:16:01 --> Security Class Initialized
INFO - 2023-06-11 10:16:01 --> Input Class Initialized
INFO - 2023-06-11 10:16:01 --> Language Class Initialized
INFO - 2023-06-11 10:16:01 --> Loader Class Initialized
INFO - 2023-06-11 10:16:01 --> Helper loaded: url_helper
INFO - 2023-06-11 10:16:01 --> Helper loaded: form_helper
INFO - 2023-06-11 10:16:01 --> Database Driver Class Initialized
INFO - 2023-06-11 10:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:16:01 --> Form Validation Class Initialized
INFO - 2023-06-11 10:16:01 --> Controller Class Initialized
INFO - 2023-06-11 10:16:01 --> Model "m_user" initialized
INFO - 2023-06-11 10:16:01 --> Config Class Initialized
INFO - 2023-06-11 10:16:01 --> Hooks Class Initialized
INFO - 2023-06-11 10:16:01 --> Utf8 Class Initialized
INFO - 2023-06-11 10:16:01 --> URI Class Initialized
INFO - 2023-06-11 10:16:01 --> Router Class Initialized
INFO - 2023-06-11 10:16:01 --> Output Class Initialized
INFO - 2023-06-11 10:16:01 --> Security Class Initialized
INFO - 2023-06-11 10:16:01 --> Input Class Initialized
INFO - 2023-06-11 10:16:01 --> Language Class Initialized
INFO - 2023-06-11 10:16:01 --> Loader Class Initialized
INFO - 2023-06-11 10:16:01 --> Helper loaded: url_helper
INFO - 2023-06-11 10:16:01 --> Helper loaded: form_helper
INFO - 2023-06-11 10:16:01 --> Database Driver Class Initialized
INFO - 2023-06-11 10:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:16:01 --> Form Validation Class Initialized
INFO - 2023-06-11 10:16:01 --> Controller Class Initialized
INFO - 2023-06-11 10:16:01 --> Model "m_user" initialized
INFO - 2023-06-11 10:16:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:16:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:16:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:16:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:16:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:16:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:16:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:16:01 --> Final output sent to browser
INFO - 2023-06-11 10:17:55 --> Config Class Initialized
INFO - 2023-06-11 10:17:55 --> Hooks Class Initialized
INFO - 2023-06-11 10:17:55 --> Utf8 Class Initialized
INFO - 2023-06-11 10:17:55 --> URI Class Initialized
INFO - 2023-06-11 10:17:55 --> Router Class Initialized
INFO - 2023-06-11 10:17:55 --> Output Class Initialized
INFO - 2023-06-11 10:17:55 --> Security Class Initialized
INFO - 2023-06-11 10:17:55 --> Input Class Initialized
INFO - 2023-06-11 10:17:55 --> Language Class Initialized
INFO - 2023-06-11 10:17:55 --> Loader Class Initialized
INFO - 2023-06-11 10:17:55 --> Helper loaded: url_helper
INFO - 2023-06-11 10:17:55 --> Helper loaded: form_helper
INFO - 2023-06-11 10:17:55 --> Database Driver Class Initialized
INFO - 2023-06-11 10:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:17:55 --> Form Validation Class Initialized
INFO - 2023-06-11 10:17:55 --> Controller Class Initialized
INFO - 2023-06-11 10:17:55 --> Model "m_datatrain" initialized
INFO - 2023-06-11 10:17:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:17:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:17:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 10:17:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:17:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:17:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:17:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:17:55 --> Final output sent to browser
INFO - 2023-06-11 10:17:56 --> Config Class Initialized
INFO - 2023-06-11 10:17:56 --> Hooks Class Initialized
INFO - 2023-06-11 10:17:56 --> Utf8 Class Initialized
INFO - 2023-06-11 10:17:56 --> URI Class Initialized
INFO - 2023-06-11 10:17:56 --> Router Class Initialized
INFO - 2023-06-11 10:17:56 --> Output Class Initialized
INFO - 2023-06-11 10:17:56 --> Security Class Initialized
INFO - 2023-06-11 10:17:56 --> Input Class Initialized
INFO - 2023-06-11 10:17:56 --> Language Class Initialized
INFO - 2023-06-11 10:17:56 --> Loader Class Initialized
INFO - 2023-06-11 10:17:56 --> Helper loaded: url_helper
INFO - 2023-06-11 10:17:56 --> Helper loaded: form_helper
INFO - 2023-06-11 10:17:56 --> Database Driver Class Initialized
INFO - 2023-06-11 10:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:17:56 --> Form Validation Class Initialized
INFO - 2023-06-11 10:17:56 --> Controller Class Initialized
INFO - 2023-06-11 10:17:56 --> Model "m_datatrain" initialized
INFO - 2023-06-11 10:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-06-11 10:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:17:56 --> Final output sent to browser
INFO - 2023-06-11 10:18:00 --> Config Class Initialized
INFO - 2023-06-11 10:18:00 --> Hooks Class Initialized
INFO - 2023-06-11 10:18:00 --> Utf8 Class Initialized
INFO - 2023-06-11 10:18:00 --> URI Class Initialized
INFO - 2023-06-11 10:18:00 --> Router Class Initialized
INFO - 2023-06-11 10:18:00 --> Output Class Initialized
INFO - 2023-06-11 10:18:00 --> Security Class Initialized
INFO - 2023-06-11 10:18:00 --> Input Class Initialized
INFO - 2023-06-11 10:18:00 --> Language Class Initialized
INFO - 2023-06-11 10:18:00 --> Loader Class Initialized
INFO - 2023-06-11 10:18:00 --> Helper loaded: url_helper
INFO - 2023-06-11 10:18:00 --> Helper loaded: form_helper
INFO - 2023-06-11 10:18:00 --> Database Driver Class Initialized
INFO - 2023-06-11 10:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:18:00 --> Form Validation Class Initialized
INFO - 2023-06-11 10:18:00 --> Controller Class Initialized
INFO - 2023-06-11 10:18:00 --> Model "m_datatest" initialized
INFO - 2023-06-11 10:18:00 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 10:18:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:18:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 10:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:18:01 --> Final output sent to browser
INFO - 2023-06-11 10:19:51 --> Config Class Initialized
INFO - 2023-06-11 10:19:51 --> Hooks Class Initialized
INFO - 2023-06-11 10:19:51 --> Utf8 Class Initialized
INFO - 2023-06-11 10:19:51 --> URI Class Initialized
INFO - 2023-06-11 10:19:51 --> Router Class Initialized
INFO - 2023-06-11 10:19:51 --> Output Class Initialized
INFO - 2023-06-11 10:19:51 --> Security Class Initialized
INFO - 2023-06-11 10:19:51 --> Input Class Initialized
INFO - 2023-06-11 10:19:51 --> Language Class Initialized
INFO - 2023-06-11 10:19:51 --> Loader Class Initialized
INFO - 2023-06-11 10:19:51 --> Helper loaded: url_helper
INFO - 2023-06-11 10:19:51 --> Helper loaded: form_helper
INFO - 2023-06-11 10:19:51 --> Database Driver Class Initialized
INFO - 2023-06-11 10:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:19:51 --> Form Validation Class Initialized
INFO - 2023-06-11 10:19:51 --> Controller Class Initialized
INFO - 2023-06-11 10:19:51 --> Model "m_datatest" initialized
INFO - 2023-06-11 10:19:51 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 10:19:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:19:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:19:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 10:19:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:19:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:19:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:19:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:19:51 --> Final output sent to browser
INFO - 2023-06-11 10:19:52 --> Config Class Initialized
INFO - 2023-06-11 10:19:52 --> Hooks Class Initialized
INFO - 2023-06-11 10:19:52 --> Utf8 Class Initialized
INFO - 2023-06-11 10:19:52 --> URI Class Initialized
INFO - 2023-06-11 10:19:52 --> Router Class Initialized
INFO - 2023-06-11 10:19:52 --> Output Class Initialized
INFO - 2023-06-11 10:19:52 --> Security Class Initialized
INFO - 2023-06-11 10:19:52 --> Input Class Initialized
INFO - 2023-06-11 10:19:52 --> Language Class Initialized
INFO - 2023-06-11 10:19:52 --> Loader Class Initialized
INFO - 2023-06-11 10:19:52 --> Helper loaded: url_helper
INFO - 2023-06-11 10:19:52 --> Helper loaded: form_helper
INFO - 2023-06-11 10:19:52 --> Database Driver Class Initialized
INFO - 2023-06-11 10:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:19:52 --> Form Validation Class Initialized
INFO - 2023-06-11 10:19:52 --> Controller Class Initialized
INFO - 2023-06-11 10:19:52 --> Model "m_datatest" initialized
INFO - 2023-06-11 10:19:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:19:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:19:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 10:19:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:19:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:19:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:19:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:19:52 --> Final output sent to browser
INFO - 2023-06-11 10:19:55 --> Config Class Initialized
INFO - 2023-06-11 10:19:55 --> Hooks Class Initialized
INFO - 2023-06-11 10:19:55 --> Utf8 Class Initialized
INFO - 2023-06-11 10:19:55 --> URI Class Initialized
INFO - 2023-06-11 10:19:55 --> Router Class Initialized
INFO - 2023-06-11 10:19:55 --> Output Class Initialized
INFO - 2023-06-11 10:19:55 --> Security Class Initialized
INFO - 2023-06-11 10:19:55 --> Input Class Initialized
INFO - 2023-06-11 10:19:55 --> Language Class Initialized
INFO - 2023-06-11 10:19:55 --> Loader Class Initialized
INFO - 2023-06-11 10:19:55 --> Helper loaded: url_helper
INFO - 2023-06-11 10:19:55 --> Helper loaded: form_helper
INFO - 2023-06-11 10:19:55 --> Database Driver Class Initialized
INFO - 2023-06-11 10:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:19:55 --> Form Validation Class Initialized
INFO - 2023-06-11 10:19:55 --> Controller Class Initialized
INFO - 2023-06-11 10:19:55 --> Model "m_user" initialized
INFO - 2023-06-11 10:19:55 --> Model "m_datatrain" initialized
INFO - 2023-06-11 10:19:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:19:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:19:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:19:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:19:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:19:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 10:19:55 --> Final output sent to browser
INFO - 2023-06-11 10:19:56 --> Config Class Initialized
INFO - 2023-06-11 10:19:56 --> Hooks Class Initialized
INFO - 2023-06-11 10:19:56 --> Utf8 Class Initialized
INFO - 2023-06-11 10:19:56 --> URI Class Initialized
INFO - 2023-06-11 10:19:56 --> Router Class Initialized
INFO - 2023-06-11 10:19:56 --> Output Class Initialized
INFO - 2023-06-11 10:19:56 --> Security Class Initialized
INFO - 2023-06-11 10:19:57 --> Input Class Initialized
INFO - 2023-06-11 10:19:57 --> Language Class Initialized
ERROR - 2023-06-11 10:19:57 --> 404 Page Not Found: C_todo_list/index
INFO - 2023-06-11 10:19:58 --> Config Class Initialized
INFO - 2023-06-11 10:19:58 --> Hooks Class Initialized
INFO - 2023-06-11 10:19:58 --> Utf8 Class Initialized
INFO - 2023-06-11 10:19:58 --> URI Class Initialized
INFO - 2023-06-11 10:19:58 --> Router Class Initialized
INFO - 2023-06-11 10:19:58 --> Output Class Initialized
INFO - 2023-06-11 10:19:58 --> Security Class Initialized
INFO - 2023-06-11 10:19:58 --> Input Class Initialized
INFO - 2023-06-11 10:19:58 --> Language Class Initialized
INFO - 2023-06-11 10:19:58 --> Loader Class Initialized
INFO - 2023-06-11 10:19:58 --> Helper loaded: url_helper
INFO - 2023-06-11 10:19:58 --> Helper loaded: form_helper
INFO - 2023-06-11 10:19:58 --> Database Driver Class Initialized
INFO - 2023-06-11 10:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:19:58 --> Form Validation Class Initialized
INFO - 2023-06-11 10:19:58 --> Controller Class Initialized
INFO - 2023-06-11 10:19:58 --> Model "m_user" initialized
INFO - 2023-06-11 10:19:58 --> Model "m_datatrain" initialized
INFO - 2023-06-11 10:19:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:19:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:19:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:19:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:19:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:19:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 10:19:58 --> Final output sent to browser
INFO - 2023-06-11 10:19:59 --> Config Class Initialized
INFO - 2023-06-11 10:19:59 --> Hooks Class Initialized
INFO - 2023-06-11 10:19:59 --> Utf8 Class Initialized
INFO - 2023-06-11 10:19:59 --> URI Class Initialized
INFO - 2023-06-11 10:19:59 --> Router Class Initialized
INFO - 2023-06-11 10:19:59 --> Output Class Initialized
INFO - 2023-06-11 10:19:59 --> Security Class Initialized
INFO - 2023-06-11 10:19:59 --> Input Class Initialized
INFO - 2023-06-11 10:19:59 --> Language Class Initialized
INFO - 2023-06-11 10:19:59 --> Loader Class Initialized
INFO - 2023-06-11 10:19:59 --> Helper loaded: url_helper
INFO - 2023-06-11 10:19:59 --> Helper loaded: form_helper
INFO - 2023-06-11 10:19:59 --> Database Driver Class Initialized
INFO - 2023-06-11 10:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:19:59 --> Form Validation Class Initialized
INFO - 2023-06-11 10:19:59 --> Controller Class Initialized
INFO - 2023-06-11 10:19:59 --> Model "m_user" initialized
INFO - 2023-06-11 10:20:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:20:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:20:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:20:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:20:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:20:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:20:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:20:00 --> Final output sent to browser
INFO - 2023-06-11 10:21:36 --> Config Class Initialized
INFO - 2023-06-11 10:21:36 --> Hooks Class Initialized
INFO - 2023-06-11 10:21:36 --> Utf8 Class Initialized
INFO - 2023-06-11 10:21:36 --> URI Class Initialized
INFO - 2023-06-11 10:21:36 --> Router Class Initialized
INFO - 2023-06-11 10:21:36 --> Output Class Initialized
INFO - 2023-06-11 10:21:36 --> Security Class Initialized
INFO - 2023-06-11 10:21:36 --> Input Class Initialized
INFO - 2023-06-11 10:21:36 --> Language Class Initialized
INFO - 2023-06-11 10:21:36 --> Loader Class Initialized
INFO - 2023-06-11 10:21:36 --> Helper loaded: url_helper
INFO - 2023-06-11 10:21:36 --> Helper loaded: form_helper
INFO - 2023-06-11 10:21:36 --> Database Driver Class Initialized
INFO - 2023-06-11 10:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:21:36 --> Form Validation Class Initialized
INFO - 2023-06-11 10:21:36 --> Controller Class Initialized
INFO - 2023-06-11 10:21:36 --> Model "m_user" initialized
INFO - 2023-06-11 10:21:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:21:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:21:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:21:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:21:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:21:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:21:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:21:36 --> Final output sent to browser
INFO - 2023-06-11 10:21:48 --> Config Class Initialized
INFO - 2023-06-11 10:21:48 --> Hooks Class Initialized
INFO - 2023-06-11 10:21:48 --> Utf8 Class Initialized
INFO - 2023-06-11 10:21:48 --> URI Class Initialized
INFO - 2023-06-11 10:21:48 --> Router Class Initialized
INFO - 2023-06-11 10:21:48 --> Output Class Initialized
INFO - 2023-06-11 10:21:48 --> Security Class Initialized
INFO - 2023-06-11 10:21:48 --> Input Class Initialized
INFO - 2023-06-11 10:21:48 --> Language Class Initialized
ERROR - 2023-06-11 10:21:48 --> 404 Page Not Found: C_todo_list/index
INFO - 2023-06-11 10:21:49 --> Config Class Initialized
INFO - 2023-06-11 10:21:49 --> Hooks Class Initialized
INFO - 2023-06-11 10:21:50 --> Utf8 Class Initialized
INFO - 2023-06-11 10:21:50 --> URI Class Initialized
INFO - 2023-06-11 10:21:50 --> Router Class Initialized
INFO - 2023-06-11 10:21:50 --> Output Class Initialized
INFO - 2023-06-11 10:21:50 --> Security Class Initialized
INFO - 2023-06-11 10:21:50 --> Input Class Initialized
INFO - 2023-06-11 10:21:50 --> Language Class Initialized
INFO - 2023-06-11 10:21:50 --> Loader Class Initialized
INFO - 2023-06-11 10:21:50 --> Helper loaded: url_helper
INFO - 2023-06-11 10:21:50 --> Helper loaded: form_helper
INFO - 2023-06-11 10:21:50 --> Database Driver Class Initialized
INFO - 2023-06-11 10:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:21:50 --> Form Validation Class Initialized
INFO - 2023-06-11 10:21:50 --> Controller Class Initialized
INFO - 2023-06-11 10:21:50 --> Model "m_user" initialized
INFO - 2023-06-11 10:21:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:21:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:21:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 10:21:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:21:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:21:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:21:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:21:50 --> Final output sent to browser
INFO - 2023-06-11 10:21:52 --> Config Class Initialized
INFO - 2023-06-11 10:21:52 --> Hooks Class Initialized
INFO - 2023-06-11 10:21:52 --> Utf8 Class Initialized
INFO - 2023-06-11 10:21:52 --> URI Class Initialized
INFO - 2023-06-11 10:21:52 --> Router Class Initialized
INFO - 2023-06-11 10:21:52 --> Output Class Initialized
INFO - 2023-06-11 10:21:52 --> Security Class Initialized
INFO - 2023-06-11 10:21:52 --> Input Class Initialized
INFO - 2023-06-11 10:21:52 --> Language Class Initialized
INFO - 2023-06-11 10:21:52 --> Loader Class Initialized
INFO - 2023-06-11 10:21:52 --> Helper loaded: url_helper
INFO - 2023-06-11 10:21:52 --> Helper loaded: form_helper
INFO - 2023-06-11 10:21:52 --> Database Driver Class Initialized
INFO - 2023-06-11 10:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:21:52 --> Form Validation Class Initialized
INFO - 2023-06-11 10:21:52 --> Controller Class Initialized
INFO - 2023-06-11 10:21:52 --> Model "m_datatest" initialized
INFO - 2023-06-11 10:21:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:21:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:21:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 10:21:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:21:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:21:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:21:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:21:52 --> Final output sent to browser
INFO - 2023-06-11 10:21:59 --> Config Class Initialized
INFO - 2023-06-11 10:21:59 --> Hooks Class Initialized
INFO - 2023-06-11 10:21:59 --> Utf8 Class Initialized
INFO - 2023-06-11 10:21:59 --> URI Class Initialized
INFO - 2023-06-11 10:21:59 --> Router Class Initialized
INFO - 2023-06-11 10:21:59 --> Output Class Initialized
INFO - 2023-06-11 10:21:59 --> Security Class Initialized
INFO - 2023-06-11 10:21:59 --> Input Class Initialized
INFO - 2023-06-11 10:21:59 --> Language Class Initialized
INFO - 2023-06-11 10:21:59 --> Loader Class Initialized
INFO - 2023-06-11 10:21:59 --> Helper loaded: url_helper
INFO - 2023-06-11 10:21:59 --> Helper loaded: form_helper
INFO - 2023-06-11 10:21:59 --> Database Driver Class Initialized
INFO - 2023-06-11 10:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:21:59 --> Form Validation Class Initialized
INFO - 2023-06-11 10:21:59 --> Controller Class Initialized
INFO - 2023-06-11 10:21:59 --> Model "m_user" initialized
INFO - 2023-06-11 10:21:59 --> Config Class Initialized
INFO - 2023-06-11 10:21:59 --> Hooks Class Initialized
INFO - 2023-06-11 10:21:59 --> Utf8 Class Initialized
INFO - 2023-06-11 10:21:59 --> URI Class Initialized
INFO - 2023-06-11 10:21:59 --> Router Class Initialized
INFO - 2023-06-11 10:21:59 --> Output Class Initialized
INFO - 2023-06-11 10:21:59 --> Security Class Initialized
INFO - 2023-06-11 10:21:59 --> Input Class Initialized
INFO - 2023-06-11 10:21:59 --> Language Class Initialized
INFO - 2023-06-11 10:21:59 --> Loader Class Initialized
INFO - 2023-06-11 10:21:59 --> Helper loaded: url_helper
INFO - 2023-06-11 10:21:59 --> Helper loaded: form_helper
INFO - 2023-06-11 10:21:59 --> Database Driver Class Initialized
INFO - 2023-06-11 10:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:21:59 --> Form Validation Class Initialized
INFO - 2023-06-11 10:21:59 --> Controller Class Initialized
INFO - 2023-06-11 10:21:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 10:21:59 --> Final output sent to browser
INFO - 2023-06-11 10:22:02 --> Config Class Initialized
INFO - 2023-06-11 10:22:02 --> Hooks Class Initialized
INFO - 2023-06-11 10:22:02 --> Utf8 Class Initialized
INFO - 2023-06-11 10:22:02 --> URI Class Initialized
INFO - 2023-06-11 10:22:02 --> Router Class Initialized
INFO - 2023-06-11 10:22:02 --> Output Class Initialized
INFO - 2023-06-11 10:22:02 --> Security Class Initialized
INFO - 2023-06-11 10:22:02 --> Input Class Initialized
INFO - 2023-06-11 10:22:02 --> Language Class Initialized
INFO - 2023-06-11 10:22:02 --> Loader Class Initialized
INFO - 2023-06-11 10:22:02 --> Helper loaded: url_helper
INFO - 2023-06-11 10:22:02 --> Helper loaded: form_helper
INFO - 2023-06-11 10:22:02 --> Database Driver Class Initialized
INFO - 2023-06-11 10:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:22:02 --> Form Validation Class Initialized
INFO - 2023-06-11 10:22:02 --> Controller Class Initialized
INFO - 2023-06-11 10:22:02 --> Model "m_user" initialized
INFO - 2023-06-11 10:22:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-11 10:22:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-11 10:22:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-11 10:22:02 --> Final output sent to browser
INFO - 2023-06-11 10:22:05 --> Config Class Initialized
INFO - 2023-06-11 10:22:05 --> Hooks Class Initialized
INFO - 2023-06-11 10:22:05 --> Utf8 Class Initialized
INFO - 2023-06-11 10:22:05 --> URI Class Initialized
INFO - 2023-06-11 10:22:05 --> Router Class Initialized
INFO - 2023-06-11 10:22:05 --> Output Class Initialized
INFO - 2023-06-11 10:22:05 --> Security Class Initialized
INFO - 2023-06-11 10:22:05 --> Input Class Initialized
INFO - 2023-06-11 10:22:05 --> Language Class Initialized
INFO - 2023-06-11 10:22:05 --> Loader Class Initialized
INFO - 2023-06-11 10:22:05 --> Helper loaded: url_helper
INFO - 2023-06-11 10:22:05 --> Helper loaded: form_helper
INFO - 2023-06-11 10:22:05 --> Database Driver Class Initialized
INFO - 2023-06-11 10:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:22:05 --> Form Validation Class Initialized
INFO - 2023-06-11 10:22:05 --> Controller Class Initialized
INFO - 2023-06-11 10:22:05 --> Model "m_user" initialized
INFO - 2023-06-11 10:22:05 --> Config Class Initialized
INFO - 2023-06-11 10:22:05 --> Hooks Class Initialized
INFO - 2023-06-11 10:22:05 --> Utf8 Class Initialized
INFO - 2023-06-11 10:22:05 --> URI Class Initialized
INFO - 2023-06-11 10:22:05 --> Router Class Initialized
INFO - 2023-06-11 10:22:05 --> Output Class Initialized
INFO - 2023-06-11 10:22:05 --> Security Class Initialized
INFO - 2023-06-11 10:22:05 --> Input Class Initialized
INFO - 2023-06-11 10:22:05 --> Language Class Initialized
INFO - 2023-06-11 10:22:05 --> Loader Class Initialized
INFO - 2023-06-11 10:22:05 --> Helper loaded: url_helper
INFO - 2023-06-11 10:22:05 --> Helper loaded: form_helper
INFO - 2023-06-11 10:22:05 --> Database Driver Class Initialized
INFO - 2023-06-11 10:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:22:05 --> Form Validation Class Initialized
INFO - 2023-06-11 10:22:05 --> Controller Class Initialized
INFO - 2023-06-11 10:22:05 --> Model "m_user" initialized
INFO - 2023-06-11 10:22:05 --> Model "m_datatrain" initialized
INFO - 2023-06-11 10:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 10:22:05 --> Final output sent to browser
INFO - 2023-06-11 10:22:25 --> Config Class Initialized
INFO - 2023-06-11 10:22:25 --> Hooks Class Initialized
INFO - 2023-06-11 10:22:25 --> Utf8 Class Initialized
INFO - 2023-06-11 10:22:25 --> URI Class Initialized
INFO - 2023-06-11 10:22:25 --> Router Class Initialized
INFO - 2023-06-11 10:22:25 --> Output Class Initialized
INFO - 2023-06-11 10:22:25 --> Security Class Initialized
INFO - 2023-06-11 10:22:25 --> Input Class Initialized
INFO - 2023-06-11 10:22:25 --> Language Class Initialized
INFO - 2023-06-11 10:22:25 --> Loader Class Initialized
INFO - 2023-06-11 10:22:25 --> Helper loaded: url_helper
INFO - 2023-06-11 10:22:25 --> Helper loaded: form_helper
INFO - 2023-06-11 10:22:25 --> Database Driver Class Initialized
INFO - 2023-06-11 10:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:22:25 --> Form Validation Class Initialized
INFO - 2023-06-11 10:22:25 --> Controller Class Initialized
INFO - 2023-06-11 10:22:25 --> Model "m_user" initialized
INFO - 2023-06-11 10:22:25 --> Model "m_datatrain" initialized
INFO - 2023-06-11 10:22:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:22:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:22:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:22:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:22:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:22:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 10:22:25 --> Final output sent to browser
INFO - 2023-06-11 10:22:41 --> Config Class Initialized
INFO - 2023-06-11 10:22:41 --> Hooks Class Initialized
INFO - 2023-06-11 10:22:41 --> Utf8 Class Initialized
INFO - 2023-06-11 10:22:41 --> URI Class Initialized
INFO - 2023-06-11 10:22:41 --> Router Class Initialized
INFO - 2023-06-11 10:22:41 --> Output Class Initialized
INFO - 2023-06-11 10:22:41 --> Security Class Initialized
INFO - 2023-06-11 10:22:41 --> Input Class Initialized
INFO - 2023-06-11 10:22:41 --> Language Class Initialized
INFO - 2023-06-11 10:22:41 --> Loader Class Initialized
INFO - 2023-06-11 10:22:41 --> Helper loaded: url_helper
INFO - 2023-06-11 10:22:41 --> Helper loaded: form_helper
INFO - 2023-06-11 10:22:41 --> Database Driver Class Initialized
INFO - 2023-06-11 10:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:22:41 --> Form Validation Class Initialized
INFO - 2023-06-11 10:22:41 --> Controller Class Initialized
INFO - 2023-06-11 10:22:41 --> Model "m_datatrain" initialized
INFO - 2023-06-11 10:22:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:22:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:22:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 10:22:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:22:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:22:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:22:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:22:41 --> Final output sent to browser
INFO - 2023-06-11 10:34:31 --> Config Class Initialized
INFO - 2023-06-11 10:34:31 --> Hooks Class Initialized
INFO - 2023-06-11 10:34:31 --> Utf8 Class Initialized
INFO - 2023-06-11 10:34:31 --> URI Class Initialized
INFO - 2023-06-11 10:34:31 --> Router Class Initialized
INFO - 2023-06-11 10:34:31 --> Output Class Initialized
INFO - 2023-06-11 10:34:31 --> Security Class Initialized
INFO - 2023-06-11 10:34:31 --> Input Class Initialized
INFO - 2023-06-11 10:34:31 --> Language Class Initialized
INFO - 2023-06-11 10:34:31 --> Loader Class Initialized
INFO - 2023-06-11 10:34:31 --> Helper loaded: url_helper
INFO - 2023-06-11 10:34:31 --> Helper loaded: form_helper
INFO - 2023-06-11 10:34:31 --> Database Driver Class Initialized
INFO - 2023-06-11 10:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:34:31 --> Form Validation Class Initialized
INFO - 2023-06-11 10:34:31 --> Controller Class Initialized
INFO - 2023-06-11 10:34:31 --> Model "m_datatrain" initialized
INFO - 2023-06-11 10:34:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:34:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:34:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 10:34:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:34:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:34:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:34:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:34:31 --> Final output sent to browser
INFO - 2023-06-11 10:34:32 --> Config Class Initialized
INFO - 2023-06-11 10:34:32 --> Hooks Class Initialized
INFO - 2023-06-11 10:34:32 --> Utf8 Class Initialized
INFO - 2023-06-11 10:34:32 --> URI Class Initialized
INFO - 2023-06-11 10:34:32 --> Router Class Initialized
INFO - 2023-06-11 10:34:32 --> Output Class Initialized
INFO - 2023-06-11 10:34:32 --> Security Class Initialized
INFO - 2023-06-11 10:34:32 --> Input Class Initialized
INFO - 2023-06-11 10:34:32 --> Language Class Initialized
INFO - 2023-06-11 10:34:33 --> Loader Class Initialized
INFO - 2023-06-11 10:34:33 --> Helper loaded: url_helper
INFO - 2023-06-11 10:34:33 --> Helper loaded: form_helper
INFO - 2023-06-11 10:34:33 --> Database Driver Class Initialized
INFO - 2023-06-11 10:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:34:33 --> Form Validation Class Initialized
INFO - 2023-06-11 10:34:33 --> Controller Class Initialized
INFO - 2023-06-11 10:34:33 --> Model "m_datatest" initialized
INFO - 2023-06-11 10:34:33 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 10:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 10:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:34:33 --> Final output sent to browser
INFO - 2023-06-11 10:35:35 --> Config Class Initialized
INFO - 2023-06-11 10:35:35 --> Hooks Class Initialized
INFO - 2023-06-11 10:35:35 --> Utf8 Class Initialized
INFO - 2023-06-11 10:35:35 --> URI Class Initialized
INFO - 2023-06-11 10:35:35 --> Router Class Initialized
INFO - 2023-06-11 10:35:35 --> Output Class Initialized
INFO - 2023-06-11 10:35:35 --> Security Class Initialized
INFO - 2023-06-11 10:35:35 --> Input Class Initialized
INFO - 2023-06-11 10:35:35 --> Language Class Initialized
INFO - 2023-06-11 10:35:35 --> Loader Class Initialized
INFO - 2023-06-11 10:35:35 --> Helper loaded: url_helper
INFO - 2023-06-11 10:35:35 --> Helper loaded: form_helper
INFO - 2023-06-11 10:35:35 --> Database Driver Class Initialized
INFO - 2023-06-11 10:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:35:35 --> Form Validation Class Initialized
INFO - 2023-06-11 10:35:35 --> Controller Class Initialized
INFO - 2023-06-11 10:35:35 --> Model "m_datatest" initialized
INFO - 2023-06-11 10:35:35 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 10:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 10:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:35:35 --> Final output sent to browser
INFO - 2023-06-11 10:42:08 --> Config Class Initialized
INFO - 2023-06-11 10:42:08 --> Hooks Class Initialized
INFO - 2023-06-11 10:42:08 --> Utf8 Class Initialized
INFO - 2023-06-11 10:42:08 --> URI Class Initialized
INFO - 2023-06-11 10:42:08 --> Router Class Initialized
INFO - 2023-06-11 10:42:08 --> Output Class Initialized
INFO - 2023-06-11 10:42:08 --> Security Class Initialized
INFO - 2023-06-11 10:42:08 --> Input Class Initialized
INFO - 2023-06-11 10:42:08 --> Language Class Initialized
INFO - 2023-06-11 10:42:08 --> Loader Class Initialized
INFO - 2023-06-11 10:42:08 --> Helper loaded: url_helper
INFO - 2023-06-11 10:42:08 --> Helper loaded: form_helper
INFO - 2023-06-11 10:42:08 --> Database Driver Class Initialized
INFO - 2023-06-11 10:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 10:42:08 --> Form Validation Class Initialized
INFO - 2023-06-11 10:42:08 --> Controller Class Initialized
INFO - 2023-06-11 10:42:08 --> Model "m_datatest" initialized
INFO - 2023-06-11 10:42:08 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 10:42:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 10:42:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 10:42:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 10:42:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 10:42:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 10:42:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 10:42:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 10:42:08 --> Final output sent to browser
INFO - 2023-06-11 11:12:55 --> Config Class Initialized
INFO - 2023-06-11 11:12:55 --> Hooks Class Initialized
INFO - 2023-06-11 11:12:55 --> Utf8 Class Initialized
INFO - 2023-06-11 11:12:55 --> URI Class Initialized
INFO - 2023-06-11 11:12:55 --> Router Class Initialized
INFO - 2023-06-11 11:12:55 --> Output Class Initialized
INFO - 2023-06-11 11:12:55 --> Security Class Initialized
INFO - 2023-06-11 11:12:55 --> Input Class Initialized
INFO - 2023-06-11 11:12:55 --> Language Class Initialized
INFO - 2023-06-11 11:12:55 --> Loader Class Initialized
INFO - 2023-06-11 11:12:55 --> Helper loaded: url_helper
INFO - 2023-06-11 11:12:55 --> Helper loaded: form_helper
INFO - 2023-06-11 11:12:55 --> Database Driver Class Initialized
INFO - 2023-06-11 11:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:12:55 --> Form Validation Class Initialized
INFO - 2023-06-11 11:12:55 --> Controller Class Initialized
INFO - 2023-06-11 11:12:55 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:12:56 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-06-11 11:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:12:56 --> Final output sent to browser
INFO - 2023-06-11 11:12:58 --> Config Class Initialized
INFO - 2023-06-11 11:12:58 --> Hooks Class Initialized
INFO - 2023-06-11 11:12:58 --> Utf8 Class Initialized
INFO - 2023-06-11 11:12:58 --> URI Class Initialized
INFO - 2023-06-11 11:12:58 --> Router Class Initialized
INFO - 2023-06-11 11:12:58 --> Output Class Initialized
INFO - 2023-06-11 11:12:58 --> Security Class Initialized
INFO - 2023-06-11 11:12:58 --> Input Class Initialized
INFO - 2023-06-11 11:12:58 --> Language Class Initialized
INFO - 2023-06-11 11:12:58 --> Loader Class Initialized
INFO - 2023-06-11 11:12:59 --> Helper loaded: url_helper
INFO - 2023-06-11 11:12:59 --> Helper loaded: form_helper
INFO - 2023-06-11 11:12:59 --> Database Driver Class Initialized
INFO - 2023-06-11 11:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:12:59 --> Form Validation Class Initialized
INFO - 2023-06-11 11:12:59 --> Controller Class Initialized
INFO - 2023-06-11 11:12:59 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:12:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 11:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:12:59 --> Final output sent to browser
INFO - 2023-06-11 11:13:00 --> Config Class Initialized
INFO - 2023-06-11 11:13:00 --> Hooks Class Initialized
INFO - 2023-06-11 11:13:00 --> Utf8 Class Initialized
INFO - 2023-06-11 11:13:00 --> URI Class Initialized
INFO - 2023-06-11 11:13:00 --> Router Class Initialized
INFO - 2023-06-11 11:13:00 --> Output Class Initialized
INFO - 2023-06-11 11:13:00 --> Security Class Initialized
INFO - 2023-06-11 11:13:00 --> Input Class Initialized
INFO - 2023-06-11 11:13:00 --> Language Class Initialized
INFO - 2023-06-11 11:13:00 --> Loader Class Initialized
INFO - 2023-06-11 11:13:00 --> Helper loaded: url_helper
INFO - 2023-06-11 11:13:00 --> Helper loaded: form_helper
INFO - 2023-06-11 11:13:00 --> Database Driver Class Initialized
INFO - 2023-06-11 11:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:13:00 --> Form Validation Class Initialized
INFO - 2023-06-11 11:13:00 --> Controller Class Initialized
INFO - 2023-06-11 11:13:00 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:13:00 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 11:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:13:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:13:00 --> Final output sent to browser
INFO - 2023-06-11 11:13:02 --> Config Class Initialized
INFO - 2023-06-11 11:13:02 --> Hooks Class Initialized
INFO - 2023-06-11 11:13:02 --> Utf8 Class Initialized
INFO - 2023-06-11 11:13:02 --> URI Class Initialized
INFO - 2023-06-11 11:13:02 --> Router Class Initialized
INFO - 2023-06-11 11:13:02 --> Output Class Initialized
INFO - 2023-06-11 11:13:02 --> Security Class Initialized
INFO - 2023-06-11 11:13:02 --> Input Class Initialized
INFO - 2023-06-11 11:13:02 --> Language Class Initialized
INFO - 2023-06-11 11:13:02 --> Loader Class Initialized
INFO - 2023-06-11 11:13:02 --> Helper loaded: url_helper
INFO - 2023-06-11 11:13:02 --> Helper loaded: form_helper
INFO - 2023-06-11 11:13:02 --> Database Driver Class Initialized
INFO - 2023-06-11 11:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:13:02 --> Form Validation Class Initialized
INFO - 2023-06-11 11:13:02 --> Controller Class Initialized
INFO - 2023-06-11 11:13:02 --> Model "m_datatrain" initialized
INFO - 2023-06-11 11:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 11:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:13:02 --> Final output sent to browser
INFO - 2023-06-11 11:13:03 --> Config Class Initialized
INFO - 2023-06-11 11:13:03 --> Hooks Class Initialized
INFO - 2023-06-11 11:13:03 --> Utf8 Class Initialized
INFO - 2023-06-11 11:13:03 --> URI Class Initialized
INFO - 2023-06-11 11:13:03 --> Router Class Initialized
INFO - 2023-06-11 11:13:03 --> Output Class Initialized
INFO - 2023-06-11 11:13:03 --> Security Class Initialized
INFO - 2023-06-11 11:13:03 --> Input Class Initialized
INFO - 2023-06-11 11:13:03 --> Language Class Initialized
INFO - 2023-06-11 11:13:03 --> Loader Class Initialized
INFO - 2023-06-11 11:13:03 --> Helper loaded: url_helper
INFO - 2023-06-11 11:13:03 --> Helper loaded: form_helper
INFO - 2023-06-11 11:13:03 --> Database Driver Class Initialized
INFO - 2023-06-11 11:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:13:03 --> Form Validation Class Initialized
INFO - 2023-06-11 11:13:03 --> Controller Class Initialized
INFO - 2023-06-11 11:13:03 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:13:03 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 11:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:13:03 --> Final output sent to browser
INFO - 2023-06-11 11:13:04 --> Config Class Initialized
INFO - 2023-06-11 11:13:04 --> Hooks Class Initialized
INFO - 2023-06-11 11:13:04 --> Utf8 Class Initialized
INFO - 2023-06-11 11:13:04 --> URI Class Initialized
INFO - 2023-06-11 11:13:04 --> Router Class Initialized
INFO - 2023-06-11 11:13:04 --> Output Class Initialized
INFO - 2023-06-11 11:13:04 --> Security Class Initialized
INFO - 2023-06-11 11:13:04 --> Input Class Initialized
INFO - 2023-06-11 11:13:04 --> Language Class Initialized
INFO - 2023-06-11 11:13:04 --> Loader Class Initialized
INFO - 2023-06-11 11:13:04 --> Helper loaded: url_helper
INFO - 2023-06-11 11:13:04 --> Helper loaded: form_helper
INFO - 2023-06-11 11:13:04 --> Database Driver Class Initialized
INFO - 2023-06-11 11:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:13:04 --> Form Validation Class Initialized
INFO - 2023-06-11 11:13:04 --> Controller Class Initialized
INFO - 2023-06-11 11:13:04 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:13:04 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:13:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:13:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:13:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-06-11 11:13:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:13:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:13:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:13:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:13:04 --> Final output sent to browser
INFO - 2023-06-11 11:13:47 --> Config Class Initialized
INFO - 2023-06-11 11:13:47 --> Hooks Class Initialized
INFO - 2023-06-11 11:13:47 --> Utf8 Class Initialized
INFO - 2023-06-11 11:13:47 --> URI Class Initialized
INFO - 2023-06-11 11:13:47 --> Router Class Initialized
INFO - 2023-06-11 11:13:47 --> Output Class Initialized
INFO - 2023-06-11 11:13:47 --> Security Class Initialized
INFO - 2023-06-11 11:13:47 --> Input Class Initialized
INFO - 2023-06-11 11:13:47 --> Language Class Initialized
INFO - 2023-06-11 11:13:47 --> Loader Class Initialized
INFO - 2023-06-11 11:13:47 --> Helper loaded: url_helper
INFO - 2023-06-11 11:13:47 --> Helper loaded: form_helper
INFO - 2023-06-11 11:13:47 --> Database Driver Class Initialized
INFO - 2023-06-11 11:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:13:47 --> Form Validation Class Initialized
INFO - 2023-06-11 11:13:47 --> Controller Class Initialized
INFO - 2023-06-11 11:13:47 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:13:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 11:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:13:47 --> Final output sent to browser
INFO - 2023-06-11 11:13:48 --> Config Class Initialized
INFO - 2023-06-11 11:13:48 --> Hooks Class Initialized
INFO - 2023-06-11 11:13:48 --> Utf8 Class Initialized
INFO - 2023-06-11 11:13:48 --> URI Class Initialized
INFO - 2023-06-11 11:13:48 --> Router Class Initialized
INFO - 2023-06-11 11:13:48 --> Output Class Initialized
INFO - 2023-06-11 11:13:48 --> Security Class Initialized
INFO - 2023-06-11 11:13:48 --> Input Class Initialized
INFO - 2023-06-11 11:13:48 --> Language Class Initialized
INFO - 2023-06-11 11:13:48 --> Loader Class Initialized
INFO - 2023-06-11 11:13:48 --> Helper loaded: url_helper
INFO - 2023-06-11 11:13:48 --> Helper loaded: form_helper
INFO - 2023-06-11 11:13:48 --> Database Driver Class Initialized
INFO - 2023-06-11 11:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:13:48 --> Form Validation Class Initialized
INFO - 2023-06-11 11:13:48 --> Controller Class Initialized
INFO - 2023-06-11 11:13:48 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:13:48 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 11:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:13:48 --> Final output sent to browser
INFO - 2023-06-11 11:14:54 --> Config Class Initialized
INFO - 2023-06-11 11:14:54 --> Hooks Class Initialized
INFO - 2023-06-11 11:14:54 --> Utf8 Class Initialized
INFO - 2023-06-11 11:14:54 --> URI Class Initialized
INFO - 2023-06-11 11:14:54 --> Router Class Initialized
INFO - 2023-06-11 11:14:54 --> Output Class Initialized
INFO - 2023-06-11 11:14:54 --> Security Class Initialized
INFO - 2023-06-11 11:14:54 --> Input Class Initialized
INFO - 2023-06-11 11:14:54 --> Language Class Initialized
INFO - 2023-06-11 11:14:54 --> Loader Class Initialized
INFO - 2023-06-11 11:14:54 --> Helper loaded: url_helper
INFO - 2023-06-11 11:14:54 --> Helper loaded: form_helper
INFO - 2023-06-11 11:14:55 --> Database Driver Class Initialized
INFO - 2023-06-11 11:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:14:55 --> Form Validation Class Initialized
INFO - 2023-06-11 11:14:55 --> Controller Class Initialized
INFO - 2023-06-11 11:14:55 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:14:55 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:14:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:14:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:14:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 11:14:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:14:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:14:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:14:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:14:55 --> Final output sent to browser
INFO - 2023-06-11 11:15:02 --> Config Class Initialized
INFO - 2023-06-11 11:15:02 --> Hooks Class Initialized
INFO - 2023-06-11 11:15:02 --> Utf8 Class Initialized
INFO - 2023-06-11 11:15:02 --> URI Class Initialized
INFO - 2023-06-11 11:15:02 --> Router Class Initialized
INFO - 2023-06-11 11:15:02 --> Output Class Initialized
INFO - 2023-06-11 11:15:02 --> Security Class Initialized
INFO - 2023-06-11 11:15:02 --> Input Class Initialized
INFO - 2023-06-11 11:15:02 --> Language Class Initialized
INFO - 2023-06-11 11:15:02 --> Loader Class Initialized
INFO - 2023-06-11 11:15:02 --> Helper loaded: url_helper
INFO - 2023-06-11 11:15:02 --> Helper loaded: form_helper
INFO - 2023-06-11 11:15:02 --> Database Driver Class Initialized
INFO - 2023-06-11 11:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:15:02 --> Form Validation Class Initialized
INFO - 2023-06-11 11:15:02 --> Controller Class Initialized
INFO - 2023-06-11 11:15:02 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:15:02 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:15:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:15:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:15:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 11:15:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:15:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:15:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:15:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:15:02 --> Final output sent to browser
INFO - 2023-06-11 11:15:03 --> Config Class Initialized
INFO - 2023-06-11 11:15:03 --> Hooks Class Initialized
INFO - 2023-06-11 11:15:03 --> Utf8 Class Initialized
INFO - 2023-06-11 11:15:03 --> URI Class Initialized
INFO - 2023-06-11 11:15:03 --> Router Class Initialized
INFO - 2023-06-11 11:15:03 --> Output Class Initialized
INFO - 2023-06-11 11:15:03 --> Security Class Initialized
INFO - 2023-06-11 11:15:03 --> Input Class Initialized
INFO - 2023-06-11 11:15:03 --> Language Class Initialized
INFO - 2023-06-11 11:15:03 --> Loader Class Initialized
INFO - 2023-06-11 11:15:03 --> Helper loaded: url_helper
INFO - 2023-06-11 11:15:03 --> Helper loaded: form_helper
INFO - 2023-06-11 11:15:03 --> Database Driver Class Initialized
INFO - 2023-06-11 11:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:15:03 --> Form Validation Class Initialized
INFO - 2023-06-11 11:15:03 --> Controller Class Initialized
INFO - 2023-06-11 11:15:03 --> Model "m_datatrain" initialized
INFO - 2023-06-11 11:15:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:15:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:15:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 11:15:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:15:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:15:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:15:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:15:03 --> Final output sent to browser
INFO - 2023-06-11 11:15:04 --> Config Class Initialized
INFO - 2023-06-11 11:15:04 --> Hooks Class Initialized
INFO - 2023-06-11 11:15:04 --> Utf8 Class Initialized
INFO - 2023-06-11 11:15:04 --> URI Class Initialized
INFO - 2023-06-11 11:15:04 --> Router Class Initialized
INFO - 2023-06-11 11:15:04 --> Output Class Initialized
INFO - 2023-06-11 11:15:04 --> Security Class Initialized
INFO - 2023-06-11 11:15:04 --> Input Class Initialized
INFO - 2023-06-11 11:15:04 --> Language Class Initialized
INFO - 2023-06-11 11:15:04 --> Loader Class Initialized
INFO - 2023-06-11 11:15:04 --> Helper loaded: url_helper
INFO - 2023-06-11 11:15:04 --> Helper loaded: form_helper
INFO - 2023-06-11 11:15:04 --> Database Driver Class Initialized
INFO - 2023-06-11 11:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:15:04 --> Form Validation Class Initialized
INFO - 2023-06-11 11:15:04 --> Controller Class Initialized
INFO - 2023-06-11 11:15:04 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:15:04 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:15:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:15:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:15:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 11:15:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:15:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:15:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:15:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:15:04 --> Final output sent to browser
INFO - 2023-06-11 11:15:06 --> Config Class Initialized
INFO - 2023-06-11 11:15:06 --> Hooks Class Initialized
INFO - 2023-06-11 11:15:06 --> Utf8 Class Initialized
INFO - 2023-06-11 11:15:06 --> URI Class Initialized
INFO - 2023-06-11 11:15:06 --> Router Class Initialized
INFO - 2023-06-11 11:15:06 --> Output Class Initialized
INFO - 2023-06-11 11:15:06 --> Security Class Initialized
INFO - 2023-06-11 11:15:06 --> Input Class Initialized
INFO - 2023-06-11 11:15:06 --> Language Class Initialized
INFO - 2023-06-11 11:15:06 --> Loader Class Initialized
INFO - 2023-06-11 11:15:06 --> Helper loaded: url_helper
INFO - 2023-06-11 11:15:06 --> Helper loaded: form_helper
INFO - 2023-06-11 11:15:06 --> Database Driver Class Initialized
INFO - 2023-06-11 11:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:15:06 --> Form Validation Class Initialized
INFO - 2023-06-11 11:15:06 --> Controller Class Initialized
INFO - 2023-06-11 11:15:06 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:15:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 11:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:15:06 --> Final output sent to browser
INFO - 2023-06-11 11:15:34 --> Config Class Initialized
INFO - 2023-06-11 11:15:34 --> Hooks Class Initialized
INFO - 2023-06-11 11:15:34 --> Utf8 Class Initialized
INFO - 2023-06-11 11:15:34 --> URI Class Initialized
INFO - 2023-06-11 11:15:35 --> Router Class Initialized
INFO - 2023-06-11 11:15:35 --> Output Class Initialized
INFO - 2023-06-11 11:15:35 --> Security Class Initialized
INFO - 2023-06-11 11:15:35 --> Input Class Initialized
INFO - 2023-06-11 11:15:35 --> Language Class Initialized
INFO - 2023-06-11 11:15:35 --> Loader Class Initialized
INFO - 2023-06-11 11:15:35 --> Helper loaded: url_helper
INFO - 2023-06-11 11:15:35 --> Helper loaded: form_helper
INFO - 2023-06-11 11:15:35 --> Database Driver Class Initialized
INFO - 2023-06-11 11:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:15:35 --> Form Validation Class Initialized
INFO - 2023-06-11 11:15:35 --> Controller Class Initialized
INFO - 2023-06-11 11:15:35 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:15:35 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:15:35 --> Final output sent to browser
INFO - 2023-06-11 11:15:35 --> Config Class Initialized
INFO - 2023-06-11 11:15:35 --> Hooks Class Initialized
INFO - 2023-06-11 11:15:35 --> Utf8 Class Initialized
INFO - 2023-06-11 11:15:35 --> URI Class Initialized
INFO - 2023-06-11 11:15:35 --> Router Class Initialized
INFO - 2023-06-11 11:15:35 --> Output Class Initialized
INFO - 2023-06-11 11:15:35 --> Security Class Initialized
INFO - 2023-06-11 11:15:35 --> Input Class Initialized
INFO - 2023-06-11 11:15:35 --> Language Class Initialized
INFO - 2023-06-11 11:15:35 --> Loader Class Initialized
INFO - 2023-06-11 11:15:35 --> Helper loaded: url_helper
INFO - 2023-06-11 11:15:35 --> Helper loaded: form_helper
INFO - 2023-06-11 11:15:35 --> Database Driver Class Initialized
INFO - 2023-06-11 11:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:15:35 --> Form Validation Class Initialized
INFO - 2023-06-11 11:15:35 --> Controller Class Initialized
INFO - 2023-06-11 11:15:35 --> Model "m_datatrain" initialized
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:15:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:15:35 --> Final output sent to browser
INFO - 2023-06-11 11:15:36 --> Config Class Initialized
INFO - 2023-06-11 11:15:36 --> Hooks Class Initialized
INFO - 2023-06-11 11:15:36 --> Utf8 Class Initialized
INFO - 2023-06-11 11:15:36 --> URI Class Initialized
INFO - 2023-06-11 11:15:36 --> Router Class Initialized
INFO - 2023-06-11 11:15:36 --> Output Class Initialized
INFO - 2023-06-11 11:15:36 --> Security Class Initialized
INFO - 2023-06-11 11:15:36 --> Input Class Initialized
INFO - 2023-06-11 11:15:36 --> Language Class Initialized
INFO - 2023-06-11 11:15:36 --> Loader Class Initialized
INFO - 2023-06-11 11:15:36 --> Helper loaded: url_helper
INFO - 2023-06-11 11:15:36 --> Helper loaded: form_helper
INFO - 2023-06-11 11:15:36 --> Database Driver Class Initialized
INFO - 2023-06-11 11:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:15:36 --> Form Validation Class Initialized
INFO - 2023-06-11 11:15:36 --> Controller Class Initialized
INFO - 2023-06-11 11:15:36 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:15:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 11:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:15:36 --> Final output sent to browser
INFO - 2023-06-11 11:16:27 --> Config Class Initialized
INFO - 2023-06-11 11:16:27 --> Hooks Class Initialized
INFO - 2023-06-11 11:16:27 --> Utf8 Class Initialized
INFO - 2023-06-11 11:16:27 --> URI Class Initialized
INFO - 2023-06-11 11:16:27 --> Router Class Initialized
INFO - 2023-06-11 11:16:27 --> Output Class Initialized
INFO - 2023-06-11 11:16:27 --> Security Class Initialized
INFO - 2023-06-11 11:16:27 --> Input Class Initialized
INFO - 2023-06-11 11:16:27 --> Language Class Initialized
INFO - 2023-06-11 11:16:27 --> Loader Class Initialized
INFO - 2023-06-11 11:16:27 --> Helper loaded: url_helper
INFO - 2023-06-11 11:16:27 --> Helper loaded: form_helper
INFO - 2023-06-11 11:16:27 --> Database Driver Class Initialized
INFO - 2023-06-11 11:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:16:27 --> Form Validation Class Initialized
INFO - 2023-06-11 11:16:27 --> Controller Class Initialized
INFO - 2023-06-11 11:16:27 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:16:27 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 11:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:16:27 --> Final output sent to browser
INFO - 2023-06-11 11:16:36 --> Config Class Initialized
INFO - 2023-06-11 11:16:36 --> Hooks Class Initialized
INFO - 2023-06-11 11:16:36 --> Utf8 Class Initialized
INFO - 2023-06-11 11:16:36 --> URI Class Initialized
INFO - 2023-06-11 11:16:36 --> Router Class Initialized
INFO - 2023-06-11 11:16:36 --> Output Class Initialized
INFO - 2023-06-11 11:16:36 --> Security Class Initialized
INFO - 2023-06-11 11:16:36 --> Input Class Initialized
INFO - 2023-06-11 11:16:36 --> Language Class Initialized
INFO - 2023-06-11 11:16:36 --> Loader Class Initialized
INFO - 2023-06-11 11:16:36 --> Helper loaded: url_helper
INFO - 2023-06-11 11:16:36 --> Helper loaded: form_helper
INFO - 2023-06-11 11:16:36 --> Database Driver Class Initialized
INFO - 2023-06-11 11:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:16:36 --> Form Validation Class Initialized
INFO - 2023-06-11 11:16:36 --> Controller Class Initialized
INFO - 2023-06-11 11:16:36 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:16:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:16:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:16:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:16:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 11:16:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:16:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:16:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:16:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:16:36 --> Final output sent to browser
INFO - 2023-06-11 11:16:37 --> Config Class Initialized
INFO - 2023-06-11 11:16:37 --> Hooks Class Initialized
INFO - 2023-06-11 11:16:37 --> Utf8 Class Initialized
INFO - 2023-06-11 11:16:37 --> URI Class Initialized
INFO - 2023-06-11 11:16:37 --> Router Class Initialized
INFO - 2023-06-11 11:16:37 --> Output Class Initialized
INFO - 2023-06-11 11:16:37 --> Security Class Initialized
INFO - 2023-06-11 11:16:37 --> Input Class Initialized
INFO - 2023-06-11 11:16:37 --> Language Class Initialized
INFO - 2023-06-11 11:16:37 --> Loader Class Initialized
INFO - 2023-06-11 11:16:37 --> Helper loaded: url_helper
INFO - 2023-06-11 11:16:37 --> Helper loaded: form_helper
INFO - 2023-06-11 11:16:37 --> Database Driver Class Initialized
INFO - 2023-06-11 11:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:16:37 --> Form Validation Class Initialized
INFO - 2023-06-11 11:16:37 --> Controller Class Initialized
INFO - 2023-06-11 11:16:37 --> Model "m_datatrain" initialized
INFO - 2023-06-11 11:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 11:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:16:37 --> Final output sent to browser
INFO - 2023-06-11 11:16:38 --> Config Class Initialized
INFO - 2023-06-11 11:16:38 --> Hooks Class Initialized
INFO - 2023-06-11 11:16:38 --> Utf8 Class Initialized
INFO - 2023-06-11 11:16:38 --> URI Class Initialized
INFO - 2023-06-11 11:16:38 --> Router Class Initialized
INFO - 2023-06-11 11:16:38 --> Output Class Initialized
INFO - 2023-06-11 11:16:38 --> Security Class Initialized
INFO - 2023-06-11 11:16:38 --> Input Class Initialized
INFO - 2023-06-11 11:16:38 --> Language Class Initialized
INFO - 2023-06-11 11:16:38 --> Loader Class Initialized
INFO - 2023-06-11 11:16:38 --> Helper loaded: url_helper
INFO - 2023-06-11 11:16:38 --> Helper loaded: form_helper
INFO - 2023-06-11 11:16:38 --> Database Driver Class Initialized
INFO - 2023-06-11 11:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:16:38 --> Form Validation Class Initialized
INFO - 2023-06-11 11:16:38 --> Controller Class Initialized
INFO - 2023-06-11 11:16:38 --> Model "m_user" initialized
INFO - 2023-06-11 11:16:38 --> Model "m_datatrain" initialized
INFO - 2023-06-11 11:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 11:16:38 --> Final output sent to browser
INFO - 2023-06-11 11:16:39 --> Config Class Initialized
INFO - 2023-06-11 11:16:39 --> Hooks Class Initialized
INFO - 2023-06-11 11:16:39 --> Utf8 Class Initialized
INFO - 2023-06-11 11:16:39 --> URI Class Initialized
INFO - 2023-06-11 11:16:39 --> Router Class Initialized
INFO - 2023-06-11 11:16:39 --> Output Class Initialized
INFO - 2023-06-11 11:16:39 --> Security Class Initialized
INFO - 2023-06-11 11:16:39 --> Input Class Initialized
INFO - 2023-06-11 11:16:39 --> Language Class Initialized
INFO - 2023-06-11 11:16:39 --> Loader Class Initialized
INFO - 2023-06-11 11:16:39 --> Helper loaded: url_helper
INFO - 2023-06-11 11:16:39 --> Helper loaded: form_helper
INFO - 2023-06-11 11:16:39 --> Database Driver Class Initialized
INFO - 2023-06-11 11:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:16:39 --> Form Validation Class Initialized
INFO - 2023-06-11 11:16:39 --> Controller Class Initialized
INFO - 2023-06-11 11:16:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 11:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 11:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:16:39 --> Final output sent to browser
INFO - 2023-06-11 11:17:05 --> Config Class Initialized
INFO - 2023-06-11 11:17:05 --> Hooks Class Initialized
INFO - 2023-06-11 11:17:05 --> Utf8 Class Initialized
INFO - 2023-06-11 11:17:05 --> URI Class Initialized
INFO - 2023-06-11 11:17:05 --> Router Class Initialized
INFO - 2023-06-11 11:17:05 --> Output Class Initialized
INFO - 2023-06-11 11:17:05 --> Security Class Initialized
INFO - 2023-06-11 11:17:05 --> Input Class Initialized
INFO - 2023-06-11 11:17:05 --> Language Class Initialized
INFO - 2023-06-11 11:17:05 --> Loader Class Initialized
INFO - 2023-06-11 11:17:05 --> Helper loaded: url_helper
INFO - 2023-06-11 11:17:05 --> Helper loaded: form_helper
INFO - 2023-06-11 11:17:05 --> Database Driver Class Initialized
INFO - 2023-06-11 11:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:17:05 --> Form Validation Class Initialized
INFO - 2023-06-11 11:17:05 --> Controller Class Initialized
INFO - 2023-06-11 11:17:05 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:17:05 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:17:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:17:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:17:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 11:17:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:17:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:17:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:17:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:17:05 --> Final output sent to browser
INFO - 2023-06-11 11:17:06 --> Config Class Initialized
INFO - 2023-06-11 11:17:06 --> Hooks Class Initialized
INFO - 2023-06-11 11:17:06 --> Utf8 Class Initialized
INFO - 2023-06-11 11:17:06 --> URI Class Initialized
INFO - 2023-06-11 11:17:06 --> Router Class Initialized
INFO - 2023-06-11 11:17:06 --> Output Class Initialized
INFO - 2023-06-11 11:17:06 --> Security Class Initialized
INFO - 2023-06-11 11:17:06 --> Input Class Initialized
INFO - 2023-06-11 11:17:06 --> Language Class Initialized
INFO - 2023-06-11 11:17:06 --> Loader Class Initialized
INFO - 2023-06-11 11:17:06 --> Helper loaded: url_helper
INFO - 2023-06-11 11:17:06 --> Helper loaded: form_helper
INFO - 2023-06-11 11:17:06 --> Database Driver Class Initialized
INFO - 2023-06-11 11:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:17:06 --> Form Validation Class Initialized
INFO - 2023-06-11 11:17:06 --> Controller Class Initialized
INFO - 2023-06-11 11:17:06 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:17:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:17:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:17:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:17:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 11:17:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:17:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:17:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:17:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:17:06 --> Final output sent to browser
INFO - 2023-06-11 11:18:20 --> Config Class Initialized
INFO - 2023-06-11 11:18:20 --> Hooks Class Initialized
INFO - 2023-06-11 11:18:20 --> Utf8 Class Initialized
INFO - 2023-06-11 11:18:20 --> URI Class Initialized
INFO - 2023-06-11 11:18:20 --> Router Class Initialized
INFO - 2023-06-11 11:18:20 --> Output Class Initialized
INFO - 2023-06-11 11:18:20 --> Security Class Initialized
INFO - 2023-06-11 11:18:20 --> Input Class Initialized
INFO - 2023-06-11 11:18:20 --> Language Class Initialized
INFO - 2023-06-11 11:18:20 --> Loader Class Initialized
INFO - 2023-06-11 11:18:20 --> Helper loaded: url_helper
INFO - 2023-06-11 11:18:20 --> Helper loaded: form_helper
INFO - 2023-06-11 11:18:20 --> Database Driver Class Initialized
INFO - 2023-06-11 11:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:18:20 --> Form Validation Class Initialized
INFO - 2023-06-11 11:18:20 --> Controller Class Initialized
INFO - 2023-06-11 11:18:20 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:18:20 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:18:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:18:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:18:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 11:18:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:18:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:18:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:18:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:18:20 --> Final output sent to browser
INFO - 2023-06-11 11:28:41 --> Config Class Initialized
INFO - 2023-06-11 11:28:41 --> Hooks Class Initialized
INFO - 2023-06-11 11:28:41 --> Utf8 Class Initialized
INFO - 2023-06-11 11:28:41 --> URI Class Initialized
INFO - 2023-06-11 11:28:41 --> Router Class Initialized
INFO - 2023-06-11 11:28:41 --> Output Class Initialized
INFO - 2023-06-11 11:28:41 --> Security Class Initialized
INFO - 2023-06-11 11:28:41 --> Input Class Initialized
INFO - 2023-06-11 11:28:41 --> Language Class Initialized
INFO - 2023-06-11 11:28:41 --> Loader Class Initialized
INFO - 2023-06-11 11:28:41 --> Helper loaded: url_helper
INFO - 2023-06-11 11:28:41 --> Helper loaded: form_helper
INFO - 2023-06-11 11:28:41 --> Database Driver Class Initialized
INFO - 2023-06-11 11:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:28:41 --> Form Validation Class Initialized
INFO - 2023-06-11 11:28:41 --> Controller Class Initialized
INFO - 2023-06-11 11:28:41 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:28:41 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:28:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:28:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:28:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 11:28:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:28:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:28:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:28:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:28:41 --> Final output sent to browser
INFO - 2023-06-11 11:28:44 --> Config Class Initialized
INFO - 2023-06-11 11:28:44 --> Hooks Class Initialized
INFO - 2023-06-11 11:28:44 --> Utf8 Class Initialized
INFO - 2023-06-11 11:28:44 --> URI Class Initialized
INFO - 2023-06-11 11:28:44 --> Router Class Initialized
INFO - 2023-06-11 11:28:44 --> Output Class Initialized
INFO - 2023-06-11 11:28:44 --> Security Class Initialized
INFO - 2023-06-11 11:28:44 --> Input Class Initialized
INFO - 2023-06-11 11:28:44 --> Language Class Initialized
INFO - 2023-06-11 11:28:44 --> Loader Class Initialized
INFO - 2023-06-11 11:28:44 --> Helper loaded: url_helper
INFO - 2023-06-11 11:28:44 --> Helper loaded: form_helper
INFO - 2023-06-11 11:28:44 --> Database Driver Class Initialized
INFO - 2023-06-11 11:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:28:44 --> Form Validation Class Initialized
INFO - 2023-06-11 11:28:44 --> Controller Class Initialized
INFO - 2023-06-11 11:28:44 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:28:44 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:28:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:28:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:28:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 11:28:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:28:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:28:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:28:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:28:44 --> Final output sent to browser
INFO - 2023-06-11 11:29:58 --> Config Class Initialized
INFO - 2023-06-11 11:29:58 --> Hooks Class Initialized
INFO - 2023-06-11 11:29:58 --> Utf8 Class Initialized
INFO - 2023-06-11 11:29:58 --> URI Class Initialized
INFO - 2023-06-11 11:29:58 --> Router Class Initialized
INFO - 2023-06-11 11:29:58 --> Output Class Initialized
INFO - 2023-06-11 11:29:58 --> Security Class Initialized
INFO - 2023-06-11 11:29:58 --> Input Class Initialized
INFO - 2023-06-11 11:29:58 --> Language Class Initialized
INFO - 2023-06-11 11:29:58 --> Loader Class Initialized
INFO - 2023-06-11 11:29:58 --> Helper loaded: url_helper
INFO - 2023-06-11 11:29:58 --> Helper loaded: form_helper
INFO - 2023-06-11 11:29:58 --> Database Driver Class Initialized
INFO - 2023-06-11 11:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:29:58 --> Form Validation Class Initialized
INFO - 2023-06-11 11:29:58 --> Controller Class Initialized
INFO - 2023-06-11 11:29:58 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:29:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:29:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:29:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-11 11:29:58 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_addData.php 47
INFO - 2023-06-11 11:30:16 --> Config Class Initialized
INFO - 2023-06-11 11:30:16 --> Hooks Class Initialized
INFO - 2023-06-11 11:30:16 --> Utf8 Class Initialized
INFO - 2023-06-11 11:30:16 --> URI Class Initialized
INFO - 2023-06-11 11:30:16 --> Router Class Initialized
INFO - 2023-06-11 11:30:16 --> Output Class Initialized
INFO - 2023-06-11 11:30:16 --> Security Class Initialized
INFO - 2023-06-11 11:30:16 --> Input Class Initialized
INFO - 2023-06-11 11:30:16 --> Language Class Initialized
INFO - 2023-06-11 11:30:16 --> Loader Class Initialized
INFO - 2023-06-11 11:30:16 --> Helper loaded: url_helper
INFO - 2023-06-11 11:30:16 --> Helper loaded: form_helper
INFO - 2023-06-11 11:30:16 --> Database Driver Class Initialized
INFO - 2023-06-11 11:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:30:16 --> Form Validation Class Initialized
INFO - 2023-06-11 11:30:16 --> Controller Class Initialized
INFO - 2023-06-11 11:30:16 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:30:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:30:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:30:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:30:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 11:30:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:30:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:30:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:30:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:30:16 --> Final output sent to browser
INFO - 2023-06-11 11:45:50 --> Config Class Initialized
INFO - 2023-06-11 11:45:50 --> Hooks Class Initialized
INFO - 2023-06-11 11:45:50 --> Utf8 Class Initialized
INFO - 2023-06-11 11:45:50 --> URI Class Initialized
INFO - 2023-06-11 11:45:50 --> Router Class Initialized
INFO - 2023-06-11 11:45:50 --> Output Class Initialized
INFO - 2023-06-11 11:45:50 --> Security Class Initialized
INFO - 2023-06-11 11:45:50 --> Input Class Initialized
INFO - 2023-06-11 11:45:50 --> Language Class Initialized
ERROR - 2023-06-11 11:45:50 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ';' or '{' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 619
INFO - 2023-06-11 11:46:14 --> Config Class Initialized
INFO - 2023-06-11 11:46:14 --> Hooks Class Initialized
INFO - 2023-06-11 11:46:14 --> Utf8 Class Initialized
INFO - 2023-06-11 11:46:14 --> URI Class Initialized
INFO - 2023-06-11 11:46:14 --> Router Class Initialized
INFO - 2023-06-11 11:46:14 --> Output Class Initialized
INFO - 2023-06-11 11:46:14 --> Security Class Initialized
INFO - 2023-06-11 11:46:14 --> Input Class Initialized
INFO - 2023-06-11 11:46:14 --> Language Class Initialized
INFO - 2023-06-11 11:46:14 --> Loader Class Initialized
INFO - 2023-06-11 11:46:14 --> Helper loaded: url_helper
INFO - 2023-06-11 11:46:14 --> Helper loaded: form_helper
INFO - 2023-06-11 11:46:14 --> Database Driver Class Initialized
INFO - 2023-06-11 11:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:46:14 --> Form Validation Class Initialized
INFO - 2023-06-11 11:46:14 --> Controller Class Initialized
INFO - 2023-06-11 11:46:14 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:46:14 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:46:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:46:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:46:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 11:46:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:46:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:46:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:46:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:46:14 --> Final output sent to browser
INFO - 2023-06-11 11:46:45 --> Config Class Initialized
INFO - 2023-06-11 11:46:45 --> Hooks Class Initialized
INFO - 2023-06-11 11:46:45 --> Utf8 Class Initialized
INFO - 2023-06-11 11:46:45 --> URI Class Initialized
INFO - 2023-06-11 11:46:45 --> Router Class Initialized
INFO - 2023-06-11 11:46:45 --> Output Class Initialized
INFO - 2023-06-11 11:46:45 --> Security Class Initialized
INFO - 2023-06-11 11:46:45 --> Input Class Initialized
INFO - 2023-06-11 11:46:45 --> Language Class Initialized
INFO - 2023-06-11 11:46:45 --> Loader Class Initialized
INFO - 2023-06-11 11:46:45 --> Helper loaded: url_helper
INFO - 2023-06-11 11:46:45 --> Helper loaded: form_helper
INFO - 2023-06-11 11:46:45 --> Database Driver Class Initialized
INFO - 2023-06-11 11:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:46:45 --> Form Validation Class Initialized
INFO - 2023-06-11 11:46:45 --> Controller Class Initialized
INFO - 2023-06-11 11:46:45 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:46:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:46:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:46:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:46:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 11:46:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:46:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:46:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:46:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:46:45 --> Final output sent to browser
INFO - 2023-06-11 11:57:50 --> Config Class Initialized
INFO - 2023-06-11 11:57:50 --> Hooks Class Initialized
INFO - 2023-06-11 11:57:50 --> Utf8 Class Initialized
INFO - 2023-06-11 11:57:50 --> URI Class Initialized
INFO - 2023-06-11 11:57:50 --> Router Class Initialized
INFO - 2023-06-11 11:57:50 --> Output Class Initialized
INFO - 2023-06-11 11:57:50 --> Security Class Initialized
INFO - 2023-06-11 11:57:50 --> Input Class Initialized
INFO - 2023-06-11 11:57:50 --> Language Class Initialized
INFO - 2023-06-11 11:57:50 --> Loader Class Initialized
INFO - 2023-06-11 11:57:50 --> Helper loaded: url_helper
INFO - 2023-06-11 11:57:50 --> Helper loaded: form_helper
INFO - 2023-06-11 11:57:50 --> Database Driver Class Initialized
INFO - 2023-06-11 11:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 11:57:50 --> Form Validation Class Initialized
INFO - 2023-06-11 11:57:50 --> Controller Class Initialized
INFO - 2023-06-11 11:57:50 --> Model "m_datatest" initialized
INFO - 2023-06-11 11:57:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 11:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 11:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 11:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 11:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 11:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 11:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 11:57:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 11:57:50 --> Final output sent to browser
INFO - 2023-06-11 12:09:43 --> Config Class Initialized
INFO - 2023-06-11 12:09:43 --> Hooks Class Initialized
INFO - 2023-06-11 12:09:43 --> Utf8 Class Initialized
INFO - 2023-06-11 12:09:43 --> URI Class Initialized
INFO - 2023-06-11 12:09:43 --> Router Class Initialized
INFO - 2023-06-11 12:09:43 --> Output Class Initialized
INFO - 2023-06-11 12:09:43 --> Security Class Initialized
INFO - 2023-06-11 12:09:43 --> Input Class Initialized
INFO - 2023-06-11 12:09:43 --> Language Class Initialized
INFO - 2023-06-11 12:09:43 --> Loader Class Initialized
INFO - 2023-06-11 12:09:43 --> Helper loaded: url_helper
INFO - 2023-06-11 12:09:43 --> Helper loaded: form_helper
INFO - 2023-06-11 12:09:43 --> Database Driver Class Initialized
INFO - 2023-06-11 12:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 12:09:43 --> Form Validation Class Initialized
INFO - 2023-06-11 12:09:43 --> Controller Class Initialized
INFO - 2023-06-11 12:09:43 --> Model "m_datatest" initialized
INFO - 2023-06-11 12:09:43 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 12:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 12:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 12:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 12:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 12:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 12:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 12:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 12:09:43 --> Final output sent to browser
INFO - 2023-06-11 12:09:56 --> Config Class Initialized
INFO - 2023-06-11 12:09:56 --> Hooks Class Initialized
INFO - 2023-06-11 12:09:56 --> Utf8 Class Initialized
INFO - 2023-06-11 12:09:56 --> URI Class Initialized
INFO - 2023-06-11 12:09:56 --> Router Class Initialized
INFO - 2023-06-11 12:09:56 --> Output Class Initialized
INFO - 2023-06-11 12:09:56 --> Security Class Initialized
INFO - 2023-06-11 12:09:56 --> Input Class Initialized
INFO - 2023-06-11 12:09:56 --> Language Class Initialized
INFO - 2023-06-11 12:09:56 --> Loader Class Initialized
INFO - 2023-06-11 12:09:56 --> Helper loaded: url_helper
INFO - 2023-06-11 12:09:56 --> Helper loaded: form_helper
INFO - 2023-06-11 12:09:56 --> Database Driver Class Initialized
INFO - 2023-06-11 12:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 12:09:56 --> Form Validation Class Initialized
INFO - 2023-06-11 12:09:56 --> Controller Class Initialized
INFO - 2023-06-11 12:09:56 --> Model "m_datatest" initialized
INFO - 2023-06-11 12:09:56 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 12:09:56 --> Final output sent to browser
INFO - 2023-06-11 12:10:05 --> Config Class Initialized
INFO - 2023-06-11 12:10:05 --> Hooks Class Initialized
INFO - 2023-06-11 12:10:05 --> Utf8 Class Initialized
INFO - 2023-06-11 12:10:05 --> URI Class Initialized
INFO - 2023-06-11 12:10:05 --> Router Class Initialized
INFO - 2023-06-11 12:10:05 --> Output Class Initialized
INFO - 2023-06-11 12:10:05 --> Security Class Initialized
INFO - 2023-06-11 12:10:05 --> Input Class Initialized
INFO - 2023-06-11 12:10:05 --> Language Class Initialized
INFO - 2023-06-11 12:10:05 --> Loader Class Initialized
INFO - 2023-06-11 12:10:05 --> Helper loaded: url_helper
INFO - 2023-06-11 12:10:05 --> Helper loaded: form_helper
INFO - 2023-06-11 12:10:05 --> Database Driver Class Initialized
INFO - 2023-06-11 12:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 12:10:05 --> Form Validation Class Initialized
INFO - 2023-06-11 12:10:05 --> Controller Class Initialized
INFO - 2023-06-11 12:10:05 --> Model "m_datatest" initialized
INFO - 2023-06-11 12:10:05 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 12:10:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 12:10:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 12:10:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 12:10:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 12:10:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 12:10:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 12:10:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 12:10:05 --> Final output sent to browser
INFO - 2023-06-11 12:43:28 --> Config Class Initialized
INFO - 2023-06-11 12:43:28 --> Hooks Class Initialized
INFO - 2023-06-11 12:43:28 --> Utf8 Class Initialized
INFO - 2023-06-11 12:43:28 --> URI Class Initialized
INFO - 2023-06-11 12:43:28 --> Router Class Initialized
INFO - 2023-06-11 12:43:28 --> Output Class Initialized
INFO - 2023-06-11 12:43:28 --> Security Class Initialized
INFO - 2023-06-11 12:43:28 --> Input Class Initialized
INFO - 2023-06-11 12:43:28 --> Language Class Initialized
ERROR - 2023-06-11 12:43:28 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 626
INFO - 2023-06-11 12:43:44 --> Config Class Initialized
INFO - 2023-06-11 12:43:44 --> Hooks Class Initialized
INFO - 2023-06-11 12:43:44 --> Utf8 Class Initialized
INFO - 2023-06-11 12:43:44 --> URI Class Initialized
INFO - 2023-06-11 12:43:44 --> Router Class Initialized
INFO - 2023-06-11 12:43:44 --> Output Class Initialized
INFO - 2023-06-11 12:43:44 --> Security Class Initialized
INFO - 2023-06-11 12:43:44 --> Input Class Initialized
INFO - 2023-06-11 12:43:44 --> Language Class Initialized
INFO - 2023-06-11 12:43:44 --> Loader Class Initialized
INFO - 2023-06-11 12:43:44 --> Helper loaded: url_helper
INFO - 2023-06-11 12:43:44 --> Helper loaded: form_helper
INFO - 2023-06-11 12:43:44 --> Database Driver Class Initialized
INFO - 2023-06-11 12:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 12:43:44 --> Form Validation Class Initialized
INFO - 2023-06-11 12:43:44 --> Controller Class Initialized
INFO - 2023-06-11 12:43:44 --> Model "m_datatest" initialized
INFO - 2023-06-11 12:43:44 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 12:43:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 12:43:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 12:43:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 12:43:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 12:43:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 12:43:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 12:43:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 12:43:44 --> Final output sent to browser
INFO - 2023-06-11 12:43:49 --> Config Class Initialized
INFO - 2023-06-11 12:43:49 --> Hooks Class Initialized
INFO - 2023-06-11 12:43:49 --> Utf8 Class Initialized
INFO - 2023-06-11 12:43:49 --> URI Class Initialized
INFO - 2023-06-11 12:43:49 --> Router Class Initialized
INFO - 2023-06-11 12:43:49 --> Output Class Initialized
INFO - 2023-06-11 12:43:49 --> Security Class Initialized
INFO - 2023-06-11 12:43:49 --> Input Class Initialized
INFO - 2023-06-11 12:43:49 --> Language Class Initialized
INFO - 2023-06-11 12:43:49 --> Loader Class Initialized
INFO - 2023-06-11 12:43:49 --> Helper loaded: url_helper
INFO - 2023-06-11 12:43:49 --> Helper loaded: form_helper
INFO - 2023-06-11 12:43:49 --> Database Driver Class Initialized
INFO - 2023-06-11 12:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 12:43:49 --> Form Validation Class Initialized
INFO - 2023-06-11 12:43:49 --> Controller Class Initialized
INFO - 2023-06-11 12:43:49 --> Model "m_datatest" initialized
INFO - 2023-06-11 12:43:49 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 12:43:49 --> Final output sent to browser
INFO - 2023-06-11 12:43:54 --> Config Class Initialized
INFO - 2023-06-11 12:43:54 --> Hooks Class Initialized
INFO - 2023-06-11 12:43:54 --> Utf8 Class Initialized
INFO - 2023-06-11 12:43:54 --> URI Class Initialized
INFO - 2023-06-11 12:43:54 --> Router Class Initialized
INFO - 2023-06-11 12:43:54 --> Output Class Initialized
INFO - 2023-06-11 12:43:54 --> Security Class Initialized
INFO - 2023-06-11 12:43:54 --> Input Class Initialized
INFO - 2023-06-11 12:43:54 --> Language Class Initialized
INFO - 2023-06-11 12:43:54 --> Loader Class Initialized
INFO - 2023-06-11 12:43:54 --> Helper loaded: url_helper
INFO - 2023-06-11 12:43:54 --> Helper loaded: form_helper
INFO - 2023-06-11 12:43:54 --> Database Driver Class Initialized
INFO - 2023-06-11 12:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 12:43:54 --> Form Validation Class Initialized
INFO - 2023-06-11 12:43:54 --> Controller Class Initialized
INFO - 2023-06-11 12:43:54 --> Model "m_datatest" initialized
INFO - 2023-06-11 12:43:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 12:43:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 12:43:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 12:43:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 12:43:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 12:43:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 12:43:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 12:43:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 12:43:54 --> Final output sent to browser
INFO - 2023-06-11 13:08:16 --> Config Class Initialized
INFO - 2023-06-11 13:08:16 --> Hooks Class Initialized
INFO - 2023-06-11 13:08:16 --> Utf8 Class Initialized
INFO - 2023-06-11 13:08:16 --> URI Class Initialized
INFO - 2023-06-11 13:08:16 --> Router Class Initialized
INFO - 2023-06-11 13:08:16 --> Output Class Initialized
INFO - 2023-06-11 13:08:16 --> Security Class Initialized
INFO - 2023-06-11 13:08:16 --> Input Class Initialized
INFO - 2023-06-11 13:08:16 --> Language Class Initialized
INFO - 2023-06-11 13:08:16 --> Loader Class Initialized
INFO - 2023-06-11 13:08:16 --> Helper loaded: url_helper
INFO - 2023-06-11 13:08:16 --> Helper loaded: form_helper
INFO - 2023-06-11 13:08:16 --> Database Driver Class Initialized
INFO - 2023-06-11 13:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:08:16 --> Form Validation Class Initialized
INFO - 2023-06-11 13:08:16 --> Controller Class Initialized
INFO - 2023-06-11 13:08:16 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:08:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:08:16 --> Final output sent to browser
INFO - 2023-06-11 13:09:45 --> Config Class Initialized
INFO - 2023-06-11 13:09:45 --> Hooks Class Initialized
INFO - 2023-06-11 13:09:45 --> Utf8 Class Initialized
INFO - 2023-06-11 13:09:45 --> URI Class Initialized
INFO - 2023-06-11 13:09:45 --> Router Class Initialized
INFO - 2023-06-11 13:09:45 --> Output Class Initialized
INFO - 2023-06-11 13:09:45 --> Security Class Initialized
INFO - 2023-06-11 13:09:45 --> Input Class Initialized
INFO - 2023-06-11 13:09:45 --> Language Class Initialized
INFO - 2023-06-11 13:09:45 --> Loader Class Initialized
INFO - 2023-06-11 13:09:45 --> Helper loaded: url_helper
INFO - 2023-06-11 13:09:45 --> Helper loaded: form_helper
INFO - 2023-06-11 13:09:45 --> Database Driver Class Initialized
INFO - 2023-06-11 13:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:09:45 --> Form Validation Class Initialized
INFO - 2023-06-11 13:09:45 --> Controller Class Initialized
INFO - 2023-06-11 13:09:45 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:09:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:09:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 13:09:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 13:09:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 13:09:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 13:09:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 13:09:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 13:09:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 13:09:45 --> Final output sent to browser
INFO - 2023-06-11 13:09:50 --> Config Class Initialized
INFO - 2023-06-11 13:09:50 --> Hooks Class Initialized
INFO - 2023-06-11 13:09:50 --> Utf8 Class Initialized
INFO - 2023-06-11 13:09:50 --> URI Class Initialized
INFO - 2023-06-11 13:09:50 --> Router Class Initialized
INFO - 2023-06-11 13:09:50 --> Output Class Initialized
INFO - 2023-06-11 13:09:50 --> Security Class Initialized
INFO - 2023-06-11 13:09:50 --> Input Class Initialized
INFO - 2023-06-11 13:09:50 --> Language Class Initialized
INFO - 2023-06-11 13:09:50 --> Loader Class Initialized
INFO - 2023-06-11 13:09:50 --> Helper loaded: url_helper
INFO - 2023-06-11 13:09:50 --> Helper loaded: form_helper
INFO - 2023-06-11 13:09:50 --> Database Driver Class Initialized
INFO - 2023-06-11 13:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:09:50 --> Form Validation Class Initialized
INFO - 2023-06-11 13:09:50 --> Controller Class Initialized
INFO - 2023-06-11 13:09:50 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:09:50 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 13:09:50 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 627
ERROR - 2023-06-11 13:09:50 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 627
ERROR - 2023-06-11 13:09:50 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 627
INFO - 2023-06-11 13:09:50 --> Final output sent to browser
INFO - 2023-06-11 13:09:52 --> Config Class Initialized
INFO - 2023-06-11 13:09:52 --> Hooks Class Initialized
INFO - 2023-06-11 13:09:52 --> Utf8 Class Initialized
INFO - 2023-06-11 13:09:52 --> URI Class Initialized
INFO - 2023-06-11 13:09:52 --> Router Class Initialized
INFO - 2023-06-11 13:09:52 --> Output Class Initialized
INFO - 2023-06-11 13:09:52 --> Security Class Initialized
INFO - 2023-06-11 13:09:52 --> Input Class Initialized
INFO - 2023-06-11 13:09:52 --> Language Class Initialized
INFO - 2023-06-11 13:09:52 --> Loader Class Initialized
INFO - 2023-06-11 13:09:52 --> Helper loaded: url_helper
INFO - 2023-06-11 13:09:52 --> Helper loaded: form_helper
INFO - 2023-06-11 13:09:52 --> Database Driver Class Initialized
INFO - 2023-06-11 13:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:09:52 --> Form Validation Class Initialized
INFO - 2023-06-11 13:09:52 --> Controller Class Initialized
INFO - 2023-06-11 13:09:52 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:09:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:09:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 13:09:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 13:09:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 13:09:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 13:09:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 13:09:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 13:09:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 13:09:52 --> Final output sent to browser
INFO - 2023-06-11 13:10:13 --> Config Class Initialized
INFO - 2023-06-11 13:10:13 --> Hooks Class Initialized
INFO - 2023-06-11 13:10:13 --> Utf8 Class Initialized
INFO - 2023-06-11 13:10:13 --> URI Class Initialized
INFO - 2023-06-11 13:10:13 --> Router Class Initialized
INFO - 2023-06-11 13:10:13 --> Output Class Initialized
INFO - 2023-06-11 13:10:13 --> Security Class Initialized
INFO - 2023-06-11 13:10:13 --> Input Class Initialized
INFO - 2023-06-11 13:10:13 --> Language Class Initialized
INFO - 2023-06-11 13:10:13 --> Loader Class Initialized
INFO - 2023-06-11 13:10:13 --> Helper loaded: url_helper
INFO - 2023-06-11 13:10:13 --> Helper loaded: form_helper
INFO - 2023-06-11 13:10:13 --> Database Driver Class Initialized
INFO - 2023-06-11 13:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:10:13 --> Form Validation Class Initialized
INFO - 2023-06-11 13:10:13 --> Controller Class Initialized
INFO - 2023-06-11 13:10:13 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:10:13 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 13:10:13 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\system\database\DB_query_builder.php 2442
ERROR - 2023-06-11 13:10:13 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: DELETE FROM `datatest`
WHERE `id` = Array
INFO - 2023-06-11 13:10:13 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-11 13:10:17 --> Config Class Initialized
INFO - 2023-06-11 13:10:17 --> Hooks Class Initialized
INFO - 2023-06-11 13:10:17 --> Utf8 Class Initialized
INFO - 2023-06-11 13:10:17 --> URI Class Initialized
INFO - 2023-06-11 13:10:17 --> Router Class Initialized
INFO - 2023-06-11 13:10:17 --> Output Class Initialized
INFO - 2023-06-11 13:10:17 --> Security Class Initialized
INFO - 2023-06-11 13:10:17 --> Input Class Initialized
INFO - 2023-06-11 13:10:17 --> Language Class Initialized
INFO - 2023-06-11 13:10:17 --> Loader Class Initialized
INFO - 2023-06-11 13:10:17 --> Helper loaded: url_helper
INFO - 2023-06-11 13:10:17 --> Helper loaded: form_helper
INFO - 2023-06-11 13:10:17 --> Database Driver Class Initialized
INFO - 2023-06-11 13:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:10:17 --> Form Validation Class Initialized
INFO - 2023-06-11 13:10:17 --> Controller Class Initialized
INFO - 2023-06-11 13:10:17 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:10:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 13:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 13:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 13:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 13:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 13:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 13:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 13:10:17 --> Final output sent to browser
INFO - 2023-06-11 13:11:26 --> Config Class Initialized
INFO - 2023-06-11 13:11:26 --> Hooks Class Initialized
INFO - 2023-06-11 13:11:26 --> Utf8 Class Initialized
INFO - 2023-06-11 13:11:26 --> URI Class Initialized
INFO - 2023-06-11 13:11:26 --> Router Class Initialized
INFO - 2023-06-11 13:11:26 --> Output Class Initialized
INFO - 2023-06-11 13:11:26 --> Security Class Initialized
INFO - 2023-06-11 13:11:26 --> Input Class Initialized
INFO - 2023-06-11 13:11:26 --> Language Class Initialized
INFO - 2023-06-11 13:11:26 --> Loader Class Initialized
INFO - 2023-06-11 13:11:26 --> Helper loaded: url_helper
INFO - 2023-06-11 13:11:26 --> Helper loaded: form_helper
INFO - 2023-06-11 13:11:26 --> Database Driver Class Initialized
INFO - 2023-06-11 13:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:11:26 --> Form Validation Class Initialized
INFO - 2023-06-11 13:11:26 --> Controller Class Initialized
INFO - 2023-06-11 13:11:26 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:11:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:11:26 --> Final output sent to browser
INFO - 2023-06-11 13:11:30 --> Config Class Initialized
INFO - 2023-06-11 13:11:30 --> Hooks Class Initialized
INFO - 2023-06-11 13:11:30 --> Utf8 Class Initialized
INFO - 2023-06-11 13:11:30 --> URI Class Initialized
INFO - 2023-06-11 13:11:30 --> Router Class Initialized
INFO - 2023-06-11 13:11:30 --> Output Class Initialized
INFO - 2023-06-11 13:11:30 --> Security Class Initialized
INFO - 2023-06-11 13:11:30 --> Input Class Initialized
INFO - 2023-06-11 13:11:30 --> Language Class Initialized
INFO - 2023-06-11 13:11:30 --> Loader Class Initialized
INFO - 2023-06-11 13:11:30 --> Helper loaded: url_helper
INFO - 2023-06-11 13:11:30 --> Helper loaded: form_helper
INFO - 2023-06-11 13:11:30 --> Database Driver Class Initialized
INFO - 2023-06-11 13:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:11:30 --> Form Validation Class Initialized
INFO - 2023-06-11 13:11:30 --> Controller Class Initialized
INFO - 2023-06-11 13:11:30 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:11:30 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 13:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 13:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 13:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 13:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 13:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 13:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 13:11:30 --> Final output sent to browser
INFO - 2023-06-11 13:16:32 --> Config Class Initialized
INFO - 2023-06-11 13:16:32 --> Hooks Class Initialized
INFO - 2023-06-11 13:16:32 --> Utf8 Class Initialized
INFO - 2023-06-11 13:16:32 --> URI Class Initialized
INFO - 2023-06-11 13:16:32 --> Router Class Initialized
INFO - 2023-06-11 13:16:32 --> Output Class Initialized
INFO - 2023-06-11 13:16:32 --> Security Class Initialized
INFO - 2023-06-11 13:16:32 --> Input Class Initialized
INFO - 2023-06-11 13:16:32 --> Language Class Initialized
INFO - 2023-06-11 13:16:32 --> Loader Class Initialized
INFO - 2023-06-11 13:16:32 --> Helper loaded: url_helper
INFO - 2023-06-11 13:16:32 --> Helper loaded: form_helper
INFO - 2023-06-11 13:16:32 --> Database Driver Class Initialized
INFO - 2023-06-11 13:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:16:32 --> Form Validation Class Initialized
INFO - 2023-06-11 13:16:32 --> Controller Class Initialized
INFO - 2023-06-11 13:16:32 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:16:32 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 13:16:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 627
INFO - 2023-06-11 13:16:32 --> Final output sent to browser
INFO - 2023-06-11 13:16:39 --> Config Class Initialized
INFO - 2023-06-11 13:16:39 --> Hooks Class Initialized
INFO - 2023-06-11 13:16:39 --> Utf8 Class Initialized
INFO - 2023-06-11 13:16:39 --> URI Class Initialized
INFO - 2023-06-11 13:16:39 --> Router Class Initialized
INFO - 2023-06-11 13:16:39 --> Output Class Initialized
INFO - 2023-06-11 13:16:39 --> Security Class Initialized
INFO - 2023-06-11 13:16:39 --> Input Class Initialized
INFO - 2023-06-11 13:16:39 --> Language Class Initialized
INFO - 2023-06-11 13:16:39 --> Loader Class Initialized
INFO - 2023-06-11 13:16:39 --> Helper loaded: url_helper
INFO - 2023-06-11 13:16:39 --> Helper loaded: form_helper
INFO - 2023-06-11 13:16:39 --> Database Driver Class Initialized
INFO - 2023-06-11 13:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:16:39 --> Form Validation Class Initialized
INFO - 2023-06-11 13:16:39 --> Controller Class Initialized
INFO - 2023-06-11 13:16:39 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:16:39 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 13:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 13:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 13:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 13:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 13:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 13:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 13:16:39 --> Final output sent to browser
INFO - 2023-06-11 13:17:20 --> Config Class Initialized
INFO - 2023-06-11 13:17:20 --> Hooks Class Initialized
INFO - 2023-06-11 13:17:20 --> Utf8 Class Initialized
INFO - 2023-06-11 13:17:20 --> URI Class Initialized
INFO - 2023-06-11 13:17:20 --> Router Class Initialized
INFO - 2023-06-11 13:17:20 --> Output Class Initialized
INFO - 2023-06-11 13:17:20 --> Security Class Initialized
INFO - 2023-06-11 13:17:20 --> Input Class Initialized
INFO - 2023-06-11 13:17:20 --> Language Class Initialized
INFO - 2023-06-11 13:17:20 --> Loader Class Initialized
INFO - 2023-06-11 13:17:20 --> Helper loaded: url_helper
INFO - 2023-06-11 13:17:20 --> Helper loaded: form_helper
INFO - 2023-06-11 13:17:20 --> Database Driver Class Initialized
INFO - 2023-06-11 13:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:17:20 --> Form Validation Class Initialized
INFO - 2023-06-11 13:17:20 --> Controller Class Initialized
INFO - 2023-06-11 13:17:20 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:17:20 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:17:20 --> Config Class Initialized
INFO - 2023-06-11 13:17:20 --> Hooks Class Initialized
INFO - 2023-06-11 13:17:20 --> Utf8 Class Initialized
INFO - 2023-06-11 13:17:20 --> URI Class Initialized
INFO - 2023-06-11 13:17:20 --> Router Class Initialized
INFO - 2023-06-11 13:17:20 --> Output Class Initialized
INFO - 2023-06-11 13:17:20 --> Security Class Initialized
INFO - 2023-06-11 13:17:20 --> Input Class Initialized
INFO - 2023-06-11 13:17:20 --> Language Class Initialized
INFO - 2023-06-11 13:17:20 --> Loader Class Initialized
INFO - 2023-06-11 13:17:20 --> Helper loaded: url_helper
INFO - 2023-06-11 13:17:20 --> Helper loaded: form_helper
INFO - 2023-06-11 13:17:20 --> Database Driver Class Initialized
INFO - 2023-06-11 13:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:17:20 --> Form Validation Class Initialized
INFO - 2023-06-11 13:17:20 --> Controller Class Initialized
INFO - 2023-06-11 13:17:20 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:17:20 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:17:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 13:17:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 13:17:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 13:17:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 13:17:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 13:17:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 13:17:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 13:17:20 --> Final output sent to browser
INFO - 2023-06-11 13:20:39 --> Config Class Initialized
INFO - 2023-06-11 13:20:39 --> Hooks Class Initialized
INFO - 2023-06-11 13:20:39 --> Utf8 Class Initialized
INFO - 2023-06-11 13:20:39 --> URI Class Initialized
INFO - 2023-06-11 13:20:39 --> Router Class Initialized
INFO - 2023-06-11 13:20:39 --> Output Class Initialized
INFO - 2023-06-11 13:20:39 --> Security Class Initialized
INFO - 2023-06-11 13:20:39 --> Input Class Initialized
INFO - 2023-06-11 13:20:39 --> Language Class Initialized
INFO - 2023-06-11 13:20:39 --> Loader Class Initialized
INFO - 2023-06-11 13:20:39 --> Helper loaded: url_helper
INFO - 2023-06-11 13:20:39 --> Helper loaded: form_helper
INFO - 2023-06-11 13:20:39 --> Database Driver Class Initialized
INFO - 2023-06-11 13:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:20:39 --> Form Validation Class Initialized
INFO - 2023-06-11 13:20:39 --> Controller Class Initialized
INFO - 2023-06-11 13:20:39 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:20:39 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:20:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 13:20:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 13:20:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 13:20:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 13:20:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 13:20:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 13:20:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 13:20:39 --> Final output sent to browser
INFO - 2023-06-11 13:20:40 --> Config Class Initialized
INFO - 2023-06-11 13:20:40 --> Hooks Class Initialized
INFO - 2023-06-11 13:20:40 --> Utf8 Class Initialized
INFO - 2023-06-11 13:20:40 --> URI Class Initialized
INFO - 2023-06-11 13:20:40 --> Router Class Initialized
INFO - 2023-06-11 13:20:40 --> Output Class Initialized
INFO - 2023-06-11 13:20:40 --> Security Class Initialized
INFO - 2023-06-11 13:20:40 --> Input Class Initialized
INFO - 2023-06-11 13:20:40 --> Language Class Initialized
INFO - 2023-06-11 13:20:40 --> Loader Class Initialized
INFO - 2023-06-11 13:20:40 --> Helper loaded: url_helper
INFO - 2023-06-11 13:20:40 --> Helper loaded: form_helper
INFO - 2023-06-11 13:20:40 --> Database Driver Class Initialized
INFO - 2023-06-11 13:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:20:40 --> Form Validation Class Initialized
INFO - 2023-06-11 13:20:40 --> Controller Class Initialized
INFO - 2023-06-11 13:20:40 --> Model "m_datatrain" initialized
INFO - 2023-06-11 13:20:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 13:20:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 13:20:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 13:20:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 13:20:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 13:20:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 13:20:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 13:20:40 --> Final output sent to browser
INFO - 2023-06-11 13:20:43 --> Config Class Initialized
INFO - 2023-06-11 13:20:43 --> Hooks Class Initialized
INFO - 2023-06-11 13:20:43 --> Utf8 Class Initialized
INFO - 2023-06-11 13:20:43 --> URI Class Initialized
INFO - 2023-06-11 13:20:43 --> Router Class Initialized
INFO - 2023-06-11 13:20:43 --> Output Class Initialized
INFO - 2023-06-11 13:20:43 --> Security Class Initialized
INFO - 2023-06-11 13:20:43 --> Input Class Initialized
INFO - 2023-06-11 13:20:43 --> Language Class Initialized
INFO - 2023-06-11 13:20:43 --> Loader Class Initialized
INFO - 2023-06-11 13:20:43 --> Helper loaded: url_helper
INFO - 2023-06-11 13:20:43 --> Helper loaded: form_helper
INFO - 2023-06-11 13:20:43 --> Database Driver Class Initialized
INFO - 2023-06-11 13:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:20:43 --> Form Validation Class Initialized
INFO - 2023-06-11 13:20:43 --> Controller Class Initialized
INFO - 2023-06-11 13:20:43 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:20:43 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:20:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 13:20:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 13:20:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 13:20:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 13:20:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 13:20:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 13:20:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 13:20:43 --> Final output sent to browser
INFO - 2023-06-11 13:57:29 --> Config Class Initialized
INFO - 2023-06-11 13:57:29 --> Hooks Class Initialized
INFO - 2023-06-11 13:57:29 --> Utf8 Class Initialized
INFO - 2023-06-11 13:57:29 --> URI Class Initialized
INFO - 2023-06-11 13:57:29 --> Router Class Initialized
INFO - 2023-06-11 13:57:29 --> Output Class Initialized
INFO - 2023-06-11 13:57:29 --> Security Class Initialized
INFO - 2023-06-11 13:57:29 --> Input Class Initialized
INFO - 2023-06-11 13:57:29 --> Language Class Initialized
INFO - 2023-06-11 13:57:29 --> Loader Class Initialized
INFO - 2023-06-11 13:57:29 --> Helper loaded: url_helper
INFO - 2023-06-11 13:57:29 --> Helper loaded: form_helper
INFO - 2023-06-11 13:57:29 --> Database Driver Class Initialized
INFO - 2023-06-11 13:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 13:57:29 --> Form Validation Class Initialized
INFO - 2023-06-11 13:57:29 --> Controller Class Initialized
INFO - 2023-06-11 13:57:29 --> Model "m_datatest" initialized
INFO - 2023-06-11 13:57:29 --> Model "m_datatrain" initialized
INFO - 2023-06-11 13:57:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 13:57:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 13:57:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 13:57:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 13:57:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 13:57:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 13:57:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 13:57:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 13:57:29 --> Final output sent to browser
INFO - 2023-06-11 14:12:01 --> Config Class Initialized
INFO - 2023-06-11 14:12:01 --> Hooks Class Initialized
INFO - 2023-06-11 14:12:01 --> Utf8 Class Initialized
INFO - 2023-06-11 14:12:01 --> URI Class Initialized
INFO - 2023-06-11 14:12:01 --> Router Class Initialized
INFO - 2023-06-11 14:12:01 --> Output Class Initialized
INFO - 2023-06-11 14:12:01 --> Security Class Initialized
INFO - 2023-06-11 14:12:01 --> Input Class Initialized
INFO - 2023-06-11 14:12:01 --> Language Class Initialized
INFO - 2023-06-11 14:12:01 --> Loader Class Initialized
INFO - 2023-06-11 14:12:01 --> Helper loaded: url_helper
INFO - 2023-06-11 14:12:01 --> Helper loaded: form_helper
INFO - 2023-06-11 14:12:01 --> Database Driver Class Initialized
INFO - 2023-06-11 14:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 14:12:01 --> Form Validation Class Initialized
INFO - 2023-06-11 14:12:01 --> Controller Class Initialized
INFO - 2023-06-11 14:12:01 --> Model "m_datatest" initialized
INFO - 2023-06-11 14:12:01 --> Model "m_datatrain" initialized
INFO - 2023-06-11 14:12:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 14:12:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 14:12:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 14:12:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 14:12:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 14:12:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 14:12:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 14:12:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 14:12:01 --> Final output sent to browser
INFO - 2023-06-11 14:12:58 --> Config Class Initialized
INFO - 2023-06-11 14:12:58 --> Hooks Class Initialized
INFO - 2023-06-11 14:12:58 --> Utf8 Class Initialized
INFO - 2023-06-11 14:12:58 --> URI Class Initialized
INFO - 2023-06-11 14:12:58 --> Router Class Initialized
INFO - 2023-06-11 14:12:58 --> Output Class Initialized
INFO - 2023-06-11 14:12:58 --> Security Class Initialized
INFO - 2023-06-11 14:12:58 --> Input Class Initialized
INFO - 2023-06-11 14:12:58 --> Language Class Initialized
INFO - 2023-06-11 14:12:58 --> Loader Class Initialized
INFO - 2023-06-11 14:12:58 --> Helper loaded: url_helper
INFO - 2023-06-11 14:12:58 --> Helper loaded: form_helper
INFO - 2023-06-11 14:12:58 --> Database Driver Class Initialized
INFO - 2023-06-11 14:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 14:12:58 --> Form Validation Class Initialized
INFO - 2023-06-11 14:12:58 --> Controller Class Initialized
INFO - 2023-06-11 14:12:58 --> Model "m_datatest" initialized
INFO - 2023-06-11 14:12:58 --> Model "m_datatrain" initialized
INFO - 2023-06-11 14:12:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 14:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 14:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 14:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 14:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 14:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 14:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 14:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 14:12:58 --> Final output sent to browser
INFO - 2023-06-11 14:12:59 --> Config Class Initialized
INFO - 2023-06-11 14:12:59 --> Hooks Class Initialized
INFO - 2023-06-11 14:12:59 --> Utf8 Class Initialized
INFO - 2023-06-11 14:12:59 --> URI Class Initialized
INFO - 2023-06-11 14:12:59 --> Router Class Initialized
INFO - 2023-06-11 14:12:59 --> Output Class Initialized
INFO - 2023-06-11 14:12:59 --> Security Class Initialized
INFO - 2023-06-11 14:12:59 --> Input Class Initialized
INFO - 2023-06-11 14:12:59 --> Language Class Initialized
INFO - 2023-06-11 14:12:59 --> Loader Class Initialized
INFO - 2023-06-11 14:12:59 --> Helper loaded: url_helper
INFO - 2023-06-11 14:12:59 --> Helper loaded: form_helper
INFO - 2023-06-11 14:12:59 --> Database Driver Class Initialized
INFO - 2023-06-11 14:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 14:12:59 --> Form Validation Class Initialized
INFO - 2023-06-11 14:12:59 --> Controller Class Initialized
INFO - 2023-06-11 14:12:59 --> Model "m_datatest" initialized
INFO - 2023-06-11 14:12:59 --> Model "m_datatrain" initialized
INFO - 2023-06-11 14:12:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 14:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 14:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 14:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 14:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 14:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 14:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 14:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 14:12:59 --> Final output sent to browser
INFO - 2023-06-11 14:57:46 --> Config Class Initialized
INFO - 2023-06-11 14:57:46 --> Hooks Class Initialized
INFO - 2023-06-11 14:57:46 --> Utf8 Class Initialized
INFO - 2023-06-11 14:57:46 --> URI Class Initialized
INFO - 2023-06-11 14:57:46 --> Router Class Initialized
INFO - 2023-06-11 14:57:46 --> Output Class Initialized
INFO - 2023-06-11 14:57:47 --> Security Class Initialized
INFO - 2023-06-11 14:57:47 --> Input Class Initialized
INFO - 2023-06-11 14:57:47 --> Language Class Initialized
INFO - 2023-06-11 14:57:47 --> Loader Class Initialized
INFO - 2023-06-11 14:57:47 --> Helper loaded: url_helper
INFO - 2023-06-11 14:57:47 --> Helper loaded: form_helper
INFO - 2023-06-11 14:57:47 --> Database Driver Class Initialized
INFO - 2023-06-11 14:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 14:57:47 --> Form Validation Class Initialized
INFO - 2023-06-11 14:57:47 --> Controller Class Initialized
INFO - 2023-06-11 14:57:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 14:57:47 --> Final output sent to browser
INFO - 2023-06-11 14:57:49 --> Config Class Initialized
INFO - 2023-06-11 14:57:49 --> Hooks Class Initialized
INFO - 2023-06-11 14:57:49 --> Utf8 Class Initialized
INFO - 2023-06-11 14:57:49 --> URI Class Initialized
INFO - 2023-06-11 14:57:49 --> Router Class Initialized
INFO - 2023-06-11 14:57:49 --> Output Class Initialized
INFO - 2023-06-11 14:57:49 --> Security Class Initialized
INFO - 2023-06-11 14:57:49 --> Input Class Initialized
INFO - 2023-06-11 14:57:49 --> Language Class Initialized
INFO - 2023-06-11 14:57:49 --> Loader Class Initialized
INFO - 2023-06-11 14:57:49 --> Helper loaded: url_helper
INFO - 2023-06-11 14:57:49 --> Helper loaded: form_helper
INFO - 2023-06-11 14:57:49 --> Database Driver Class Initialized
INFO - 2023-06-11 14:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 14:57:49 --> Form Validation Class Initialized
INFO - 2023-06-11 14:57:49 --> Controller Class Initialized
INFO - 2023-06-11 14:57:49 --> Model "m_user" initialized
INFO - 2023-06-11 14:57:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-11 14:57:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-11 14:57:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-11 14:57:49 --> Final output sent to browser
INFO - 2023-06-11 14:57:57 --> Config Class Initialized
INFO - 2023-06-11 14:57:57 --> Hooks Class Initialized
INFO - 2023-06-11 14:57:57 --> Utf8 Class Initialized
INFO - 2023-06-11 14:57:57 --> URI Class Initialized
INFO - 2023-06-11 14:57:57 --> Router Class Initialized
INFO - 2023-06-11 14:57:57 --> Output Class Initialized
INFO - 2023-06-11 14:57:57 --> Security Class Initialized
INFO - 2023-06-11 14:57:57 --> Input Class Initialized
INFO - 2023-06-11 14:57:57 --> Language Class Initialized
INFO - 2023-06-11 14:57:57 --> Loader Class Initialized
INFO - 2023-06-11 14:57:57 --> Helper loaded: url_helper
INFO - 2023-06-11 14:57:57 --> Helper loaded: form_helper
INFO - 2023-06-11 14:57:57 --> Database Driver Class Initialized
INFO - 2023-06-11 14:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 14:57:57 --> Form Validation Class Initialized
INFO - 2023-06-11 14:57:57 --> Controller Class Initialized
INFO - 2023-06-11 14:57:57 --> Model "m_user" initialized
INFO - 2023-06-11 14:57:57 --> Config Class Initialized
INFO - 2023-06-11 14:57:57 --> Hooks Class Initialized
INFO - 2023-06-11 14:57:57 --> Utf8 Class Initialized
INFO - 2023-06-11 14:57:57 --> URI Class Initialized
INFO - 2023-06-11 14:57:57 --> Router Class Initialized
INFO - 2023-06-11 14:57:57 --> Output Class Initialized
INFO - 2023-06-11 14:57:57 --> Security Class Initialized
INFO - 2023-06-11 14:57:57 --> Input Class Initialized
INFO - 2023-06-11 14:57:57 --> Language Class Initialized
INFO - 2023-06-11 14:57:57 --> Loader Class Initialized
INFO - 2023-06-11 14:57:57 --> Helper loaded: url_helper
INFO - 2023-06-11 14:57:57 --> Helper loaded: form_helper
INFO - 2023-06-11 14:57:57 --> Database Driver Class Initialized
INFO - 2023-06-11 14:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 14:57:57 --> Form Validation Class Initialized
INFO - 2023-06-11 14:57:57 --> Controller Class Initialized
INFO - 2023-06-11 14:57:57 --> Model "m_user" initialized
INFO - 2023-06-11 14:57:57 --> Model "m_datatrain" initialized
INFO - 2023-06-11 14:57:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 14:57:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 14:57:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 14:57:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 14:57:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 14:57:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 14:57:57 --> Final output sent to browser
INFO - 2023-06-11 14:58:00 --> Config Class Initialized
INFO - 2023-06-11 14:58:00 --> Hooks Class Initialized
INFO - 2023-06-11 14:58:00 --> Utf8 Class Initialized
INFO - 2023-06-11 14:58:00 --> URI Class Initialized
INFO - 2023-06-11 14:58:00 --> Router Class Initialized
INFO - 2023-06-11 14:58:00 --> Output Class Initialized
INFO - 2023-06-11 14:58:00 --> Security Class Initialized
INFO - 2023-06-11 14:58:00 --> Input Class Initialized
INFO - 2023-06-11 14:58:00 --> Language Class Initialized
INFO - 2023-06-11 14:58:00 --> Loader Class Initialized
INFO - 2023-06-11 14:58:00 --> Helper loaded: url_helper
INFO - 2023-06-11 14:58:00 --> Helper loaded: form_helper
INFO - 2023-06-11 14:58:00 --> Database Driver Class Initialized
INFO - 2023-06-11 14:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 14:58:00 --> Form Validation Class Initialized
INFO - 2023-06-11 14:58:00 --> Controller Class Initialized
INFO - 2023-06-11 14:58:00 --> Model "m_datatest" initialized
INFO - 2023-06-11 14:58:00 --> Model "m_datatrain" initialized
INFO - 2023-06-11 14:58:00 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 14:58:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 14:58:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 14:58:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 14:58:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 14:58:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 14:58:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 14:58:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 14:58:00 --> Final output sent to browser
INFO - 2023-06-11 14:58:01 --> Config Class Initialized
INFO - 2023-06-11 14:58:01 --> Hooks Class Initialized
INFO - 2023-06-11 14:58:01 --> Utf8 Class Initialized
INFO - 2023-06-11 14:58:01 --> URI Class Initialized
INFO - 2023-06-11 14:58:01 --> Router Class Initialized
INFO - 2023-06-11 14:58:01 --> Output Class Initialized
INFO - 2023-06-11 14:58:01 --> Security Class Initialized
INFO - 2023-06-11 14:58:01 --> Input Class Initialized
INFO - 2023-06-11 14:58:01 --> Language Class Initialized
INFO - 2023-06-11 14:58:01 --> Loader Class Initialized
INFO - 2023-06-11 14:58:01 --> Helper loaded: url_helper
INFO - 2023-06-11 14:58:01 --> Helper loaded: form_helper
INFO - 2023-06-11 14:58:01 --> Database Driver Class Initialized
INFO - 2023-06-11 14:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 14:58:01 --> Form Validation Class Initialized
INFO - 2023-06-11 14:58:01 --> Controller Class Initialized
INFO - 2023-06-11 14:58:01 --> Model "m_datatest" initialized
INFO - 2023-06-11 14:58:01 --> Model "m_datatrain" initialized
INFO - 2023-06-11 14:58:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 14:58:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 14:58:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 14:58:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 14:58:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 14:58:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 14:58:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 14:58:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 14:58:01 --> Final output sent to browser
INFO - 2023-06-11 15:07:24 --> Config Class Initialized
INFO - 2023-06-11 15:07:24 --> Hooks Class Initialized
INFO - 2023-06-11 15:07:24 --> Utf8 Class Initialized
INFO - 2023-06-11 15:07:24 --> URI Class Initialized
INFO - 2023-06-11 15:07:24 --> Router Class Initialized
INFO - 2023-06-11 15:07:24 --> Output Class Initialized
INFO - 2023-06-11 15:07:24 --> Security Class Initialized
INFO - 2023-06-11 15:07:24 --> Input Class Initialized
INFO - 2023-06-11 15:07:24 --> Language Class Initialized
INFO - 2023-06-11 15:07:24 --> Loader Class Initialized
INFO - 2023-06-11 15:07:24 --> Helper loaded: url_helper
INFO - 2023-06-11 15:07:24 --> Helper loaded: form_helper
INFO - 2023-06-11 15:07:24 --> Database Driver Class Initialized
INFO - 2023-06-11 15:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:07:24 --> Form Validation Class Initialized
INFO - 2023-06-11 15:07:24 --> Controller Class Initialized
INFO - 2023-06-11 15:07:24 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:07:24 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:07:24 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:07:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:07:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:07:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:07:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:07:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:07:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:07:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:07:24 --> Final output sent to browser
INFO - 2023-06-11 15:08:06 --> Config Class Initialized
INFO - 2023-06-11 15:08:06 --> Hooks Class Initialized
INFO - 2023-06-11 15:08:06 --> Utf8 Class Initialized
INFO - 2023-06-11 15:08:06 --> URI Class Initialized
INFO - 2023-06-11 15:08:06 --> Router Class Initialized
INFO - 2023-06-11 15:08:06 --> Output Class Initialized
INFO - 2023-06-11 15:08:06 --> Security Class Initialized
INFO - 2023-06-11 15:08:06 --> Input Class Initialized
INFO - 2023-06-11 15:08:06 --> Language Class Initialized
INFO - 2023-06-11 15:08:06 --> Loader Class Initialized
INFO - 2023-06-11 15:08:06 --> Helper loaded: url_helper
INFO - 2023-06-11 15:08:06 --> Helper loaded: form_helper
INFO - 2023-06-11 15:08:06 --> Database Driver Class Initialized
INFO - 2023-06-11 15:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:08:06 --> Form Validation Class Initialized
INFO - 2023-06-11 15:08:06 --> Controller Class Initialized
INFO - 2023-06-11 15:08:06 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:08:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:08:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:08:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 15:08:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:08:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:08:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:08:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:08:06 --> Final output sent to browser
INFO - 2023-06-11 15:08:14 --> Config Class Initialized
INFO - 2023-06-11 15:08:14 --> Hooks Class Initialized
INFO - 2023-06-11 15:08:14 --> Utf8 Class Initialized
INFO - 2023-06-11 15:08:14 --> URI Class Initialized
INFO - 2023-06-11 15:08:14 --> Router Class Initialized
INFO - 2023-06-11 15:08:14 --> Output Class Initialized
INFO - 2023-06-11 15:08:14 --> Security Class Initialized
INFO - 2023-06-11 15:08:14 --> Input Class Initialized
INFO - 2023-06-11 15:08:14 --> Language Class Initialized
INFO - 2023-06-11 15:08:14 --> Loader Class Initialized
INFO - 2023-06-11 15:08:14 --> Helper loaded: url_helper
INFO - 2023-06-11 15:08:14 --> Helper loaded: form_helper
INFO - 2023-06-11 15:08:14 --> Database Driver Class Initialized
INFO - 2023-06-11 15:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:08:14 --> Form Validation Class Initialized
INFO - 2023-06-11 15:08:14 --> Controller Class Initialized
INFO - 2023-06-11 15:08:14 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:08:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:08:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:08:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 15:08:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:08:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:08:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:08:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:08:14 --> Final output sent to browser
INFO - 2023-06-11 15:08:15 --> Config Class Initialized
INFO - 2023-06-11 15:08:15 --> Hooks Class Initialized
INFO - 2023-06-11 15:08:15 --> Utf8 Class Initialized
INFO - 2023-06-11 15:08:15 --> URI Class Initialized
INFO - 2023-06-11 15:08:15 --> Router Class Initialized
INFO - 2023-06-11 15:08:15 --> Output Class Initialized
INFO - 2023-06-11 15:08:15 --> Security Class Initialized
INFO - 2023-06-11 15:08:15 --> Input Class Initialized
INFO - 2023-06-11 15:08:15 --> Language Class Initialized
INFO - 2023-06-11 15:08:15 --> Loader Class Initialized
INFO - 2023-06-11 15:08:15 --> Helper loaded: url_helper
INFO - 2023-06-11 15:08:15 --> Helper loaded: form_helper
INFO - 2023-06-11 15:08:16 --> Database Driver Class Initialized
INFO - 2023-06-11 15:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:08:16 --> Form Validation Class Initialized
INFO - 2023-06-11 15:08:16 --> Controller Class Initialized
INFO - 2023-06-11 15:08:16 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:08:16 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:08:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:08:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:08:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:08:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:08:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:08:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:08:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:08:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:08:16 --> Final output sent to browser
INFO - 2023-06-11 15:08:17 --> Config Class Initialized
INFO - 2023-06-11 15:08:17 --> Hooks Class Initialized
INFO - 2023-06-11 15:08:17 --> Utf8 Class Initialized
INFO - 2023-06-11 15:08:17 --> URI Class Initialized
INFO - 2023-06-11 15:08:17 --> Router Class Initialized
INFO - 2023-06-11 15:08:17 --> Output Class Initialized
INFO - 2023-06-11 15:08:17 --> Security Class Initialized
INFO - 2023-06-11 15:08:17 --> Input Class Initialized
INFO - 2023-06-11 15:08:17 --> Language Class Initialized
INFO - 2023-06-11 15:08:17 --> Loader Class Initialized
INFO - 2023-06-11 15:08:17 --> Helper loaded: url_helper
INFO - 2023-06-11 15:08:17 --> Helper loaded: form_helper
INFO - 2023-06-11 15:08:17 --> Database Driver Class Initialized
INFO - 2023-06-11 15:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:08:17 --> Form Validation Class Initialized
INFO - 2023-06-11 15:08:17 --> Controller Class Initialized
INFO - 2023-06-11 15:08:17 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:08:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:08:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:08:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 15:08:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:08:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:08:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:08:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:08:17 --> Final output sent to browser
INFO - 2023-06-11 15:08:18 --> Config Class Initialized
INFO - 2023-06-11 15:08:18 --> Hooks Class Initialized
INFO - 2023-06-11 15:08:18 --> Utf8 Class Initialized
INFO - 2023-06-11 15:08:18 --> URI Class Initialized
INFO - 2023-06-11 15:08:18 --> Router Class Initialized
INFO - 2023-06-11 15:08:18 --> Output Class Initialized
INFO - 2023-06-11 15:08:18 --> Security Class Initialized
INFO - 2023-06-11 15:08:18 --> Input Class Initialized
INFO - 2023-06-11 15:08:18 --> Language Class Initialized
INFO - 2023-06-11 15:08:18 --> Loader Class Initialized
INFO - 2023-06-11 15:08:18 --> Helper loaded: url_helper
INFO - 2023-06-11 15:08:18 --> Helper loaded: form_helper
INFO - 2023-06-11 15:08:18 --> Database Driver Class Initialized
INFO - 2023-06-11 15:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:08:18 --> Form Validation Class Initialized
INFO - 2023-06-11 15:08:18 --> Controller Class Initialized
INFO - 2023-06-11 15:08:18 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:08:18 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:08:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:08:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:08:19 --> Final output sent to browser
INFO - 2023-06-11 15:12:07 --> Config Class Initialized
INFO - 2023-06-11 15:12:07 --> Hooks Class Initialized
INFO - 2023-06-11 15:12:07 --> Utf8 Class Initialized
INFO - 2023-06-11 15:12:07 --> URI Class Initialized
INFO - 2023-06-11 15:12:07 --> Router Class Initialized
INFO - 2023-06-11 15:12:07 --> Output Class Initialized
INFO - 2023-06-11 15:12:07 --> Security Class Initialized
INFO - 2023-06-11 15:12:07 --> Input Class Initialized
INFO - 2023-06-11 15:12:07 --> Language Class Initialized
INFO - 2023-06-11 15:12:07 --> Loader Class Initialized
INFO - 2023-06-11 15:12:07 --> Helper loaded: url_helper
INFO - 2023-06-11 15:12:07 --> Helper loaded: form_helper
INFO - 2023-06-11 15:12:07 --> Database Driver Class Initialized
INFO - 2023-06-11 15:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:12:07 --> Form Validation Class Initialized
INFO - 2023-06-11 15:12:07 --> Controller Class Initialized
INFO - 2023-06-11 15:12:07 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:12:07 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:12:07 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:12:07 --> Final output sent to browser
INFO - 2023-06-11 15:12:09 --> Config Class Initialized
INFO - 2023-06-11 15:12:09 --> Hooks Class Initialized
INFO - 2023-06-11 15:12:09 --> Utf8 Class Initialized
INFO - 2023-06-11 15:12:09 --> URI Class Initialized
INFO - 2023-06-11 15:12:09 --> Router Class Initialized
INFO - 2023-06-11 15:12:09 --> Output Class Initialized
INFO - 2023-06-11 15:12:09 --> Security Class Initialized
INFO - 2023-06-11 15:12:09 --> Input Class Initialized
INFO - 2023-06-11 15:12:09 --> Language Class Initialized
INFO - 2023-06-11 15:12:09 --> Loader Class Initialized
INFO - 2023-06-11 15:12:09 --> Helper loaded: url_helper
INFO - 2023-06-11 15:12:09 --> Helper loaded: form_helper
INFO - 2023-06-11 15:12:09 --> Database Driver Class Initialized
INFO - 2023-06-11 15:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:12:09 --> Form Validation Class Initialized
INFO - 2023-06-11 15:12:09 --> Controller Class Initialized
INFO - 2023-06-11 15:12:09 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:12:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:12:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:12:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 15:12:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:12:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:12:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:12:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:12:09 --> Final output sent to browser
INFO - 2023-06-11 15:12:26 --> Config Class Initialized
INFO - 2023-06-11 15:12:26 --> Hooks Class Initialized
INFO - 2023-06-11 15:12:26 --> Utf8 Class Initialized
INFO - 2023-06-11 15:12:26 --> URI Class Initialized
INFO - 2023-06-11 15:12:26 --> Router Class Initialized
INFO - 2023-06-11 15:12:26 --> Output Class Initialized
INFO - 2023-06-11 15:12:26 --> Security Class Initialized
INFO - 2023-06-11 15:12:26 --> Input Class Initialized
INFO - 2023-06-11 15:12:26 --> Language Class Initialized
INFO - 2023-06-11 15:12:26 --> Loader Class Initialized
INFO - 2023-06-11 15:12:26 --> Helper loaded: url_helper
INFO - 2023-06-11 15:12:26 --> Helper loaded: form_helper
INFO - 2023-06-11 15:12:26 --> Database Driver Class Initialized
INFO - 2023-06-11 15:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:12:26 --> Form Validation Class Initialized
INFO - 2023-06-11 15:12:26 --> Controller Class Initialized
INFO - 2023-06-11 15:12:26 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:12:26 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:12:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:12:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:12:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:12:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:12:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:12:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:12:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:12:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:12:26 --> Final output sent to browser
INFO - 2023-06-11 15:12:29 --> Config Class Initialized
INFO - 2023-06-11 15:12:29 --> Hooks Class Initialized
INFO - 2023-06-11 15:12:29 --> Utf8 Class Initialized
INFO - 2023-06-11 15:12:29 --> URI Class Initialized
INFO - 2023-06-11 15:12:29 --> Router Class Initialized
INFO - 2023-06-11 15:12:29 --> Output Class Initialized
INFO - 2023-06-11 15:12:29 --> Security Class Initialized
INFO - 2023-06-11 15:12:29 --> Input Class Initialized
INFO - 2023-06-11 15:12:29 --> Language Class Initialized
INFO - 2023-06-11 15:12:29 --> Loader Class Initialized
INFO - 2023-06-11 15:12:29 --> Helper loaded: url_helper
INFO - 2023-06-11 15:12:29 --> Helper loaded: form_helper
INFO - 2023-06-11 15:12:29 --> Database Driver Class Initialized
INFO - 2023-06-11 15:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:12:29 --> Form Validation Class Initialized
INFO - 2023-06-11 15:12:29 --> Controller Class Initialized
INFO - 2023-06-11 15:12:29 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:12:29 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:12:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:12:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:12:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:12:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:12:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:12:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:12:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:12:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:12:29 --> Final output sent to browser
INFO - 2023-06-11 15:12:33 --> Config Class Initialized
INFO - 2023-06-11 15:12:33 --> Hooks Class Initialized
INFO - 2023-06-11 15:12:33 --> Utf8 Class Initialized
INFO - 2023-06-11 15:12:33 --> URI Class Initialized
INFO - 2023-06-11 15:12:33 --> Router Class Initialized
INFO - 2023-06-11 15:12:33 --> Output Class Initialized
INFO - 2023-06-11 15:12:33 --> Security Class Initialized
INFO - 2023-06-11 15:12:33 --> Input Class Initialized
INFO - 2023-06-11 15:12:33 --> Language Class Initialized
INFO - 2023-06-11 15:12:33 --> Loader Class Initialized
INFO - 2023-06-11 15:12:33 --> Helper loaded: url_helper
INFO - 2023-06-11 15:12:33 --> Helper loaded: form_helper
INFO - 2023-06-11 15:12:33 --> Database Driver Class Initialized
INFO - 2023-06-11 15:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:12:33 --> Form Validation Class Initialized
INFO - 2023-06-11 15:12:33 --> Controller Class Initialized
INFO - 2023-06-11 15:12:33 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:12:33 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:12:33 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:12:33 --> Config Class Initialized
INFO - 2023-06-11 15:12:33 --> Hooks Class Initialized
INFO - 2023-06-11 15:12:33 --> Utf8 Class Initialized
INFO - 2023-06-11 15:12:33 --> URI Class Initialized
INFO - 2023-06-11 15:12:33 --> Router Class Initialized
INFO - 2023-06-11 15:12:33 --> Output Class Initialized
INFO - 2023-06-11 15:12:33 --> Security Class Initialized
INFO - 2023-06-11 15:12:33 --> Input Class Initialized
INFO - 2023-06-11 15:12:33 --> Language Class Initialized
INFO - 2023-06-11 15:12:33 --> Loader Class Initialized
INFO - 2023-06-11 15:12:33 --> Helper loaded: url_helper
INFO - 2023-06-11 15:12:33 --> Helper loaded: form_helper
INFO - 2023-06-11 15:12:33 --> Database Driver Class Initialized
INFO - 2023-06-11 15:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:12:33 --> Form Validation Class Initialized
INFO - 2023-06-11 15:12:33 --> Controller Class Initialized
INFO - 2023-06-11 15:12:33 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:12:33 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:12:33 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:12:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:12:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:12:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:12:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:12:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:12:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:12:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:12:33 --> Final output sent to browser
INFO - 2023-06-11 15:12:39 --> Config Class Initialized
INFO - 2023-06-11 15:12:39 --> Hooks Class Initialized
INFO - 2023-06-11 15:12:39 --> Utf8 Class Initialized
INFO - 2023-06-11 15:12:39 --> URI Class Initialized
INFO - 2023-06-11 15:12:39 --> Router Class Initialized
INFO - 2023-06-11 15:12:39 --> Output Class Initialized
INFO - 2023-06-11 15:12:39 --> Security Class Initialized
INFO - 2023-06-11 15:12:39 --> Input Class Initialized
INFO - 2023-06-11 15:12:39 --> Language Class Initialized
INFO - 2023-06-11 15:12:39 --> Loader Class Initialized
INFO - 2023-06-11 15:12:39 --> Helper loaded: url_helper
INFO - 2023-06-11 15:12:39 --> Helper loaded: form_helper
INFO - 2023-06-11 15:12:39 --> Database Driver Class Initialized
INFO - 2023-06-11 15:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:12:39 --> Form Validation Class Initialized
INFO - 2023-06-11 15:12:39 --> Controller Class Initialized
INFO - 2023-06-11 15:12:39 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:12:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:12:39 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:12:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:12:39 --> Final output sent to browser
INFO - 2023-06-11 15:13:26 --> Config Class Initialized
INFO - 2023-06-11 15:13:26 --> Hooks Class Initialized
INFO - 2023-06-11 15:13:27 --> Utf8 Class Initialized
INFO - 2023-06-11 15:13:27 --> URI Class Initialized
INFO - 2023-06-11 15:13:27 --> Router Class Initialized
INFO - 2023-06-11 15:13:27 --> Output Class Initialized
INFO - 2023-06-11 15:13:27 --> Security Class Initialized
INFO - 2023-06-11 15:13:27 --> Input Class Initialized
INFO - 2023-06-11 15:13:27 --> Language Class Initialized
INFO - 2023-06-11 15:13:27 --> Loader Class Initialized
INFO - 2023-06-11 15:13:27 --> Helper loaded: url_helper
INFO - 2023-06-11 15:13:28 --> Helper loaded: form_helper
INFO - 2023-06-11 15:13:28 --> Database Driver Class Initialized
INFO - 2023-06-11 15:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:13:28 --> Form Validation Class Initialized
INFO - 2023-06-11 15:13:28 --> Controller Class Initialized
INFO - 2023-06-11 15:13:28 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:13:28 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:13:28 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:13:28 --> Config Class Initialized
INFO - 2023-06-11 15:13:28 --> Hooks Class Initialized
INFO - 2023-06-11 15:13:28 --> Utf8 Class Initialized
INFO - 2023-06-11 15:13:28 --> URI Class Initialized
INFO - 2023-06-11 15:13:28 --> Router Class Initialized
INFO - 2023-06-11 15:13:28 --> Output Class Initialized
INFO - 2023-06-11 15:13:28 --> Security Class Initialized
INFO - 2023-06-11 15:13:28 --> Input Class Initialized
INFO - 2023-06-11 15:13:28 --> Language Class Initialized
INFO - 2023-06-11 15:13:28 --> Loader Class Initialized
INFO - 2023-06-11 15:13:28 --> Helper loaded: url_helper
INFO - 2023-06-11 15:13:28 --> Helper loaded: form_helper
INFO - 2023-06-11 15:13:28 --> Database Driver Class Initialized
INFO - 2023-06-11 15:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:13:28 --> Form Validation Class Initialized
INFO - 2023-06-11 15:13:28 --> Controller Class Initialized
INFO - 2023-06-11 15:13:28 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:13:28 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:13:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:13:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:13:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:13:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:13:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:13:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:13:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:13:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:13:29 --> Final output sent to browser
INFO - 2023-06-11 15:14:02 --> Config Class Initialized
INFO - 2023-06-11 15:14:02 --> Hooks Class Initialized
INFO - 2023-06-11 15:14:02 --> Utf8 Class Initialized
INFO - 2023-06-11 15:14:02 --> URI Class Initialized
INFO - 2023-06-11 15:14:02 --> Router Class Initialized
INFO - 2023-06-11 15:14:02 --> Output Class Initialized
INFO - 2023-06-11 15:14:02 --> Security Class Initialized
INFO - 2023-06-11 15:14:02 --> Input Class Initialized
INFO - 2023-06-11 15:14:02 --> Language Class Initialized
INFO - 2023-06-11 15:14:02 --> Loader Class Initialized
INFO - 2023-06-11 15:14:02 --> Helper loaded: url_helper
INFO - 2023-06-11 15:14:02 --> Helper loaded: form_helper
INFO - 2023-06-11 15:14:02 --> Database Driver Class Initialized
INFO - 2023-06-11 15:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:14:02 --> Form Validation Class Initialized
INFO - 2023-06-11 15:14:02 --> Controller Class Initialized
INFO - 2023-06-11 15:14:02 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:14:02 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:14:02 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:14:02 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 628
INFO - 2023-06-11 15:14:02 --> Final output sent to browser
INFO - 2023-06-11 15:14:23 --> Config Class Initialized
INFO - 2023-06-11 15:14:23 --> Hooks Class Initialized
INFO - 2023-06-11 15:14:23 --> Utf8 Class Initialized
INFO - 2023-06-11 15:14:23 --> URI Class Initialized
INFO - 2023-06-11 15:14:23 --> Router Class Initialized
INFO - 2023-06-11 15:14:23 --> Output Class Initialized
INFO - 2023-06-11 15:14:23 --> Security Class Initialized
INFO - 2023-06-11 15:14:23 --> Input Class Initialized
INFO - 2023-06-11 15:14:23 --> Language Class Initialized
INFO - 2023-06-11 15:14:23 --> Loader Class Initialized
INFO - 2023-06-11 15:14:23 --> Helper loaded: url_helper
INFO - 2023-06-11 15:14:23 --> Helper loaded: form_helper
INFO - 2023-06-11 15:14:23 --> Database Driver Class Initialized
INFO - 2023-06-11 15:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:14:23 --> Form Validation Class Initialized
INFO - 2023-06-11 15:14:23 --> Controller Class Initialized
INFO - 2023-06-11 15:14:23 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:14:23 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:14:23 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:14:23 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 628
INFO - 2023-06-11 15:14:23 --> Final output sent to browser
INFO - 2023-06-11 15:15:34 --> Config Class Initialized
INFO - 2023-06-11 15:15:34 --> Hooks Class Initialized
INFO - 2023-06-11 15:15:34 --> Utf8 Class Initialized
INFO - 2023-06-11 15:15:34 --> URI Class Initialized
INFO - 2023-06-11 15:15:34 --> Router Class Initialized
INFO - 2023-06-11 15:15:34 --> Output Class Initialized
INFO - 2023-06-11 15:15:34 --> Security Class Initialized
INFO - 2023-06-11 15:15:34 --> Input Class Initialized
INFO - 2023-06-11 15:15:34 --> Language Class Initialized
ERROR - 2023-06-11 15:15:34 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 630
INFO - 2023-06-11 15:15:51 --> Config Class Initialized
INFO - 2023-06-11 15:15:51 --> Hooks Class Initialized
INFO - 2023-06-11 15:15:51 --> Utf8 Class Initialized
INFO - 2023-06-11 15:15:51 --> URI Class Initialized
INFO - 2023-06-11 15:15:51 --> Router Class Initialized
INFO - 2023-06-11 15:15:51 --> Output Class Initialized
INFO - 2023-06-11 15:15:51 --> Security Class Initialized
INFO - 2023-06-11 15:15:51 --> Input Class Initialized
INFO - 2023-06-11 15:15:51 --> Language Class Initialized
INFO - 2023-06-11 15:15:51 --> Loader Class Initialized
INFO - 2023-06-11 15:15:51 --> Helper loaded: url_helper
INFO - 2023-06-11 15:15:51 --> Helper loaded: form_helper
INFO - 2023-06-11 15:15:51 --> Database Driver Class Initialized
INFO - 2023-06-11 15:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:15:52 --> Form Validation Class Initialized
INFO - 2023-06-11 15:15:52 --> Controller Class Initialized
INFO - 2023-06-11 15:15:52 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:15:52 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:15:52 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:15:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 630
ERROR - 2023-06-11 15:15:52 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 628
INFO - 2023-06-11 15:15:52 --> Final output sent to browser
INFO - 2023-06-11 15:15:57 --> Config Class Initialized
INFO - 2023-06-11 15:15:57 --> Hooks Class Initialized
INFO - 2023-06-11 15:15:57 --> Utf8 Class Initialized
INFO - 2023-06-11 15:15:57 --> URI Class Initialized
INFO - 2023-06-11 15:15:57 --> Router Class Initialized
INFO - 2023-06-11 15:15:57 --> Output Class Initialized
INFO - 2023-06-11 15:15:57 --> Security Class Initialized
INFO - 2023-06-11 15:15:57 --> Input Class Initialized
INFO - 2023-06-11 15:15:57 --> Language Class Initialized
INFO - 2023-06-11 15:15:57 --> Loader Class Initialized
INFO - 2023-06-11 15:15:57 --> Helper loaded: url_helper
INFO - 2023-06-11 15:15:57 --> Helper loaded: form_helper
INFO - 2023-06-11 15:15:57 --> Database Driver Class Initialized
INFO - 2023-06-11 15:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:15:57 --> Form Validation Class Initialized
INFO - 2023-06-11 15:15:57 --> Controller Class Initialized
INFO - 2023-06-11 15:15:57 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:15:57 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:15:57 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:15:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 630
ERROR - 2023-06-11 15:15:57 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 628
INFO - 2023-06-11 15:15:57 --> Final output sent to browser
INFO - 2023-06-11 15:16:35 --> Config Class Initialized
INFO - 2023-06-11 15:16:35 --> Hooks Class Initialized
INFO - 2023-06-11 15:16:35 --> Utf8 Class Initialized
INFO - 2023-06-11 15:16:35 --> URI Class Initialized
INFO - 2023-06-11 15:16:35 --> Router Class Initialized
INFO - 2023-06-11 15:16:35 --> Output Class Initialized
INFO - 2023-06-11 15:16:35 --> Security Class Initialized
INFO - 2023-06-11 15:16:35 --> Input Class Initialized
INFO - 2023-06-11 15:16:35 --> Language Class Initialized
INFO - 2023-06-11 15:16:35 --> Loader Class Initialized
INFO - 2023-06-11 15:16:35 --> Helper loaded: url_helper
INFO - 2023-06-11 15:16:35 --> Helper loaded: form_helper
INFO - 2023-06-11 15:16:35 --> Database Driver Class Initialized
INFO - 2023-06-11 15:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:16:35 --> Form Validation Class Initialized
INFO - 2023-06-11 15:16:35 --> Controller Class Initialized
INFO - 2023-06-11 15:16:35 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:16:35 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:16:35 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:16:35 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 628
INFO - 2023-06-11 15:16:35 --> Final output sent to browser
INFO - 2023-06-11 15:16:48 --> Config Class Initialized
INFO - 2023-06-11 15:16:48 --> Hooks Class Initialized
INFO - 2023-06-11 15:16:48 --> Utf8 Class Initialized
INFO - 2023-06-11 15:16:48 --> URI Class Initialized
INFO - 2023-06-11 15:16:48 --> Router Class Initialized
INFO - 2023-06-11 15:16:48 --> Output Class Initialized
INFO - 2023-06-11 15:16:48 --> Security Class Initialized
INFO - 2023-06-11 15:16:48 --> Input Class Initialized
INFO - 2023-06-11 15:16:48 --> Language Class Initialized
INFO - 2023-06-11 15:16:48 --> Loader Class Initialized
INFO - 2023-06-11 15:16:48 --> Helper loaded: url_helper
INFO - 2023-06-11 15:16:48 --> Helper loaded: form_helper
INFO - 2023-06-11 15:16:48 --> Database Driver Class Initialized
INFO - 2023-06-11 15:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:16:48 --> Form Validation Class Initialized
INFO - 2023-06-11 15:16:48 --> Controller Class Initialized
INFO - 2023-06-11 15:16:48 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:16:48 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:16:48 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:16:48 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 628
INFO - 2023-06-11 15:16:48 --> Final output sent to browser
INFO - 2023-06-11 15:16:55 --> Config Class Initialized
INFO - 2023-06-11 15:16:55 --> Hooks Class Initialized
INFO - 2023-06-11 15:16:55 --> Utf8 Class Initialized
INFO - 2023-06-11 15:16:55 --> URI Class Initialized
INFO - 2023-06-11 15:16:55 --> Router Class Initialized
INFO - 2023-06-11 15:16:55 --> Output Class Initialized
INFO - 2023-06-11 15:16:55 --> Security Class Initialized
INFO - 2023-06-11 15:16:55 --> Input Class Initialized
INFO - 2023-06-11 15:16:55 --> Language Class Initialized
INFO - 2023-06-11 15:16:55 --> Loader Class Initialized
INFO - 2023-06-11 15:16:55 --> Helper loaded: url_helper
INFO - 2023-06-11 15:16:55 --> Helper loaded: form_helper
INFO - 2023-06-11 15:16:55 --> Database Driver Class Initialized
INFO - 2023-06-11 15:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:16:55 --> Form Validation Class Initialized
INFO - 2023-06-11 15:16:55 --> Controller Class Initialized
INFO - 2023-06-11 15:16:55 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:16:55 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:16:55 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:16:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:16:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:16:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:16:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:16:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:16:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:16:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:16:55 --> Final output sent to browser
INFO - 2023-06-11 15:16:57 --> Config Class Initialized
INFO - 2023-06-11 15:16:57 --> Hooks Class Initialized
INFO - 2023-06-11 15:16:57 --> Utf8 Class Initialized
INFO - 2023-06-11 15:16:57 --> URI Class Initialized
INFO - 2023-06-11 15:16:57 --> Router Class Initialized
INFO - 2023-06-11 15:16:57 --> Output Class Initialized
INFO - 2023-06-11 15:16:57 --> Security Class Initialized
INFO - 2023-06-11 15:16:57 --> Input Class Initialized
INFO - 2023-06-11 15:16:57 --> Language Class Initialized
INFO - 2023-06-11 15:16:57 --> Loader Class Initialized
INFO - 2023-06-11 15:16:57 --> Helper loaded: url_helper
INFO - 2023-06-11 15:16:57 --> Helper loaded: form_helper
INFO - 2023-06-11 15:16:57 --> Database Driver Class Initialized
INFO - 2023-06-11 15:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:16:57 --> Form Validation Class Initialized
INFO - 2023-06-11 15:16:57 --> Controller Class Initialized
INFO - 2023-06-11 15:16:57 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:16:57 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:16:57 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:16:57 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 628
INFO - 2023-06-11 15:16:57 --> Final output sent to browser
INFO - 2023-06-11 15:17:29 --> Config Class Initialized
INFO - 2023-06-11 15:17:29 --> Hooks Class Initialized
INFO - 2023-06-11 15:17:29 --> Utf8 Class Initialized
INFO - 2023-06-11 15:17:29 --> URI Class Initialized
INFO - 2023-06-11 15:17:29 --> Router Class Initialized
INFO - 2023-06-11 15:17:29 --> Output Class Initialized
INFO - 2023-06-11 15:17:29 --> Security Class Initialized
INFO - 2023-06-11 15:17:29 --> Input Class Initialized
INFO - 2023-06-11 15:17:29 --> Language Class Initialized
INFO - 2023-06-11 15:17:29 --> Loader Class Initialized
INFO - 2023-06-11 15:17:29 --> Helper loaded: url_helper
INFO - 2023-06-11 15:17:29 --> Helper loaded: form_helper
INFO - 2023-06-11 15:17:29 --> Database Driver Class Initialized
INFO - 2023-06-11 15:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:17:29 --> Form Validation Class Initialized
INFO - 2023-06-11 15:17:29 --> Controller Class Initialized
INFO - 2023-06-11 15:17:29 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:17:29 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:17:29 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:17:29 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 628
INFO - 2023-06-11 15:17:29 --> Final output sent to browser
INFO - 2023-06-11 15:18:14 --> Config Class Initialized
INFO - 2023-06-11 15:18:14 --> Hooks Class Initialized
INFO - 2023-06-11 15:18:14 --> Utf8 Class Initialized
INFO - 2023-06-11 15:18:14 --> URI Class Initialized
INFO - 2023-06-11 15:18:14 --> Router Class Initialized
INFO - 2023-06-11 15:18:14 --> Output Class Initialized
INFO - 2023-06-11 15:18:14 --> Security Class Initialized
INFO - 2023-06-11 15:18:14 --> Input Class Initialized
INFO - 2023-06-11 15:18:14 --> Language Class Initialized
INFO - 2023-06-11 15:18:14 --> Loader Class Initialized
INFO - 2023-06-11 15:18:14 --> Helper loaded: url_helper
INFO - 2023-06-11 15:18:14 --> Helper loaded: form_helper
INFO - 2023-06-11 15:18:14 --> Database Driver Class Initialized
INFO - 2023-06-11 15:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:18:14 --> Form Validation Class Initialized
INFO - 2023-06-11 15:18:14 --> Controller Class Initialized
INFO - 2023-06-11 15:18:14 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:18:14 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:18:14 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:18:14 --> Final output sent to browser
INFO - 2023-06-11 15:18:39 --> Config Class Initialized
INFO - 2023-06-11 15:18:39 --> Hooks Class Initialized
INFO - 2023-06-11 15:18:39 --> Utf8 Class Initialized
INFO - 2023-06-11 15:18:39 --> URI Class Initialized
INFO - 2023-06-11 15:18:39 --> Router Class Initialized
INFO - 2023-06-11 15:18:39 --> Output Class Initialized
INFO - 2023-06-11 15:18:39 --> Security Class Initialized
INFO - 2023-06-11 15:18:39 --> Input Class Initialized
INFO - 2023-06-11 15:18:39 --> Language Class Initialized
INFO - 2023-06-11 15:18:39 --> Loader Class Initialized
INFO - 2023-06-11 15:18:39 --> Helper loaded: url_helper
INFO - 2023-06-11 15:18:39 --> Helper loaded: form_helper
INFO - 2023-06-11 15:18:39 --> Database Driver Class Initialized
INFO - 2023-06-11 15:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:18:39 --> Form Validation Class Initialized
INFO - 2023-06-11 15:18:39 --> Controller Class Initialized
INFO - 2023-06-11 15:18:39 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:18:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:18:39 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:18:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:18:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:18:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:18:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:18:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:18:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:18:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:18:39 --> Final output sent to browser
INFO - 2023-06-11 15:18:46 --> Config Class Initialized
INFO - 2023-06-11 15:18:46 --> Hooks Class Initialized
INFO - 2023-06-11 15:18:46 --> Utf8 Class Initialized
INFO - 2023-06-11 15:18:46 --> URI Class Initialized
INFO - 2023-06-11 15:18:46 --> Router Class Initialized
INFO - 2023-06-11 15:18:46 --> Output Class Initialized
INFO - 2023-06-11 15:18:46 --> Security Class Initialized
INFO - 2023-06-11 15:18:46 --> Input Class Initialized
INFO - 2023-06-11 15:18:46 --> Language Class Initialized
INFO - 2023-06-11 15:18:46 --> Loader Class Initialized
INFO - 2023-06-11 15:18:46 --> Helper loaded: url_helper
INFO - 2023-06-11 15:18:46 --> Helper loaded: form_helper
INFO - 2023-06-11 15:18:46 --> Database Driver Class Initialized
INFO - 2023-06-11 15:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:18:46 --> Form Validation Class Initialized
INFO - 2023-06-11 15:18:46 --> Controller Class Initialized
INFO - 2023-06-11 15:18:46 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:18:46 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:18:46 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:18:46 --> Config Class Initialized
INFO - 2023-06-11 15:18:46 --> Hooks Class Initialized
INFO - 2023-06-11 15:18:46 --> Utf8 Class Initialized
INFO - 2023-06-11 15:18:46 --> URI Class Initialized
INFO - 2023-06-11 15:18:46 --> Router Class Initialized
INFO - 2023-06-11 15:18:46 --> Output Class Initialized
INFO - 2023-06-11 15:18:46 --> Security Class Initialized
INFO - 2023-06-11 15:18:46 --> Input Class Initialized
INFO - 2023-06-11 15:18:46 --> Language Class Initialized
INFO - 2023-06-11 15:18:46 --> Loader Class Initialized
INFO - 2023-06-11 15:18:46 --> Helper loaded: url_helper
INFO - 2023-06-11 15:18:46 --> Helper loaded: form_helper
INFO - 2023-06-11 15:18:46 --> Database Driver Class Initialized
INFO - 2023-06-11 15:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:18:46 --> Form Validation Class Initialized
INFO - 2023-06-11 15:18:46 --> Controller Class Initialized
INFO - 2023-06-11 15:18:46 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:18:46 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:18:46 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:18:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:18:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:18:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:18:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:18:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:18:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:18:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:18:46 --> Final output sent to browser
INFO - 2023-06-11 15:18:54 --> Config Class Initialized
INFO - 2023-06-11 15:18:54 --> Hooks Class Initialized
INFO - 2023-06-11 15:18:54 --> Utf8 Class Initialized
INFO - 2023-06-11 15:18:54 --> URI Class Initialized
INFO - 2023-06-11 15:18:54 --> Router Class Initialized
INFO - 2023-06-11 15:18:54 --> Output Class Initialized
INFO - 2023-06-11 15:18:54 --> Security Class Initialized
INFO - 2023-06-11 15:18:54 --> Input Class Initialized
INFO - 2023-06-11 15:18:54 --> Language Class Initialized
INFO - 2023-06-11 15:18:54 --> Loader Class Initialized
INFO - 2023-06-11 15:18:54 --> Helper loaded: url_helper
INFO - 2023-06-11 15:18:54 --> Helper loaded: form_helper
INFO - 2023-06-11 15:18:54 --> Database Driver Class Initialized
INFO - 2023-06-11 15:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:18:54 --> Form Validation Class Initialized
INFO - 2023-06-11 15:18:54 --> Controller Class Initialized
INFO - 2023-06-11 15:18:54 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:18:54 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:18:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:18:54 --> Config Class Initialized
INFO - 2023-06-11 15:18:54 --> Hooks Class Initialized
INFO - 2023-06-11 15:18:54 --> Utf8 Class Initialized
INFO - 2023-06-11 15:18:54 --> URI Class Initialized
INFO - 2023-06-11 15:18:54 --> Router Class Initialized
INFO - 2023-06-11 15:18:54 --> Output Class Initialized
INFO - 2023-06-11 15:18:54 --> Security Class Initialized
INFO - 2023-06-11 15:18:54 --> Input Class Initialized
INFO - 2023-06-11 15:18:54 --> Language Class Initialized
INFO - 2023-06-11 15:18:54 --> Loader Class Initialized
INFO - 2023-06-11 15:18:54 --> Helper loaded: url_helper
INFO - 2023-06-11 15:18:54 --> Helper loaded: form_helper
INFO - 2023-06-11 15:18:54 --> Database Driver Class Initialized
INFO - 2023-06-11 15:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:18:54 --> Form Validation Class Initialized
INFO - 2023-06-11 15:18:54 --> Controller Class Initialized
INFO - 2023-06-11 15:18:54 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:18:54 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:18:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:18:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:18:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:18:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:18:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:18:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:18:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:18:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:18:54 --> Final output sent to browser
INFO - 2023-06-11 15:19:45 --> Config Class Initialized
INFO - 2023-06-11 15:19:45 --> Hooks Class Initialized
INFO - 2023-06-11 15:19:45 --> Utf8 Class Initialized
INFO - 2023-06-11 15:19:45 --> URI Class Initialized
INFO - 2023-06-11 15:19:45 --> Router Class Initialized
INFO - 2023-06-11 15:19:45 --> Output Class Initialized
INFO - 2023-06-11 15:19:45 --> Security Class Initialized
INFO - 2023-06-11 15:19:45 --> Input Class Initialized
INFO - 2023-06-11 15:19:45 --> Language Class Initialized
INFO - 2023-06-11 15:19:45 --> Loader Class Initialized
INFO - 2023-06-11 15:19:45 --> Helper loaded: url_helper
INFO - 2023-06-11 15:19:45 --> Helper loaded: form_helper
INFO - 2023-06-11 15:19:45 --> Database Driver Class Initialized
INFO - 2023-06-11 15:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:19:45 --> Form Validation Class Initialized
INFO - 2023-06-11 15:19:45 --> Controller Class Initialized
INFO - 2023-06-11 15:19:45 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:19:45 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:19:45 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:19:45 --> Severity: Warning --> var_dump() expects at least 1 parameter, 0 given C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 638
ERROR - 2023-06-11 15:19:45 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 637
ERROR - 2023-06-11 15:19:45 --> Severity: Warning --> var_dump() expects at least 1 parameter, 0 given C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 638
INFO - 2023-06-11 15:19:45 --> Final output sent to browser
INFO - 2023-06-11 15:20:14 --> Config Class Initialized
INFO - 2023-06-11 15:20:14 --> Hooks Class Initialized
INFO - 2023-06-11 15:20:14 --> Utf8 Class Initialized
INFO - 2023-06-11 15:20:14 --> URI Class Initialized
INFO - 2023-06-11 15:20:14 --> Router Class Initialized
INFO - 2023-06-11 15:20:14 --> Output Class Initialized
INFO - 2023-06-11 15:20:14 --> Security Class Initialized
INFO - 2023-06-11 15:20:14 --> Input Class Initialized
INFO - 2023-06-11 15:20:14 --> Language Class Initialized
INFO - 2023-06-11 15:20:14 --> Loader Class Initialized
INFO - 2023-06-11 15:20:14 --> Helper loaded: url_helper
INFO - 2023-06-11 15:20:14 --> Helper loaded: form_helper
INFO - 2023-06-11 15:20:14 --> Database Driver Class Initialized
INFO - 2023-06-11 15:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:20:14 --> Form Validation Class Initialized
INFO - 2023-06-11 15:20:14 --> Controller Class Initialized
INFO - 2023-06-11 15:20:14 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:20:14 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:20:14 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:20:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:20:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:20:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:20:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:20:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:20:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:20:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:20:14 --> Final output sent to browser
INFO - 2023-06-11 15:20:31 --> Config Class Initialized
INFO - 2023-06-11 15:20:31 --> Hooks Class Initialized
INFO - 2023-06-11 15:20:31 --> Utf8 Class Initialized
INFO - 2023-06-11 15:20:31 --> URI Class Initialized
INFO - 2023-06-11 15:20:31 --> Router Class Initialized
INFO - 2023-06-11 15:20:31 --> Output Class Initialized
INFO - 2023-06-11 15:20:31 --> Security Class Initialized
INFO - 2023-06-11 15:20:31 --> Input Class Initialized
INFO - 2023-06-11 15:20:31 --> Language Class Initialized
INFO - 2023-06-11 15:20:31 --> Loader Class Initialized
INFO - 2023-06-11 15:20:31 --> Helper loaded: url_helper
INFO - 2023-06-11 15:20:31 --> Helper loaded: form_helper
INFO - 2023-06-11 15:20:31 --> Database Driver Class Initialized
INFO - 2023-06-11 15:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:20:31 --> Form Validation Class Initialized
INFO - 2023-06-11 15:20:31 --> Controller Class Initialized
INFO - 2023-06-11 15:20:31 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:20:31 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:20:31 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:20:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 624
INFO - 2023-06-11 15:20:31 --> Final output sent to browser
INFO - 2023-06-11 15:20:34 --> Config Class Initialized
INFO - 2023-06-11 15:20:34 --> Hooks Class Initialized
INFO - 2023-06-11 15:20:34 --> Utf8 Class Initialized
INFO - 2023-06-11 15:20:34 --> URI Class Initialized
INFO - 2023-06-11 15:20:34 --> Router Class Initialized
INFO - 2023-06-11 15:20:34 --> Output Class Initialized
INFO - 2023-06-11 15:20:34 --> Security Class Initialized
INFO - 2023-06-11 15:20:34 --> Input Class Initialized
INFO - 2023-06-11 15:20:34 --> Language Class Initialized
INFO - 2023-06-11 15:20:34 --> Loader Class Initialized
INFO - 2023-06-11 15:20:34 --> Helper loaded: url_helper
INFO - 2023-06-11 15:20:34 --> Helper loaded: form_helper
INFO - 2023-06-11 15:20:34 --> Database Driver Class Initialized
INFO - 2023-06-11 15:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:20:34 --> Form Validation Class Initialized
INFO - 2023-06-11 15:20:34 --> Controller Class Initialized
INFO - 2023-06-11 15:20:34 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:20:34 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:20:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:20:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:20:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:20:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:20:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:20:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:20:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:20:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:20:34 --> Final output sent to browser
INFO - 2023-06-11 15:20:59 --> Config Class Initialized
INFO - 2023-06-11 15:20:59 --> Hooks Class Initialized
INFO - 2023-06-11 15:20:59 --> Utf8 Class Initialized
INFO - 2023-06-11 15:20:59 --> URI Class Initialized
INFO - 2023-06-11 15:20:59 --> Router Class Initialized
INFO - 2023-06-11 15:20:59 --> Output Class Initialized
INFO - 2023-06-11 15:20:59 --> Security Class Initialized
INFO - 2023-06-11 15:20:59 --> Input Class Initialized
INFO - 2023-06-11 15:20:59 --> Language Class Initialized
INFO - 2023-06-11 15:20:59 --> Loader Class Initialized
INFO - 2023-06-11 15:20:59 --> Helper loaded: url_helper
INFO - 2023-06-11 15:20:59 --> Helper loaded: form_helper
INFO - 2023-06-11 15:20:59 --> Database Driver Class Initialized
INFO - 2023-06-11 15:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:20:59 --> Form Validation Class Initialized
INFO - 2023-06-11 15:20:59 --> Controller Class Initialized
INFO - 2023-06-11 15:20:59 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:20:59 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:20:59 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:20:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 627
INFO - 2023-06-11 15:20:59 --> Final output sent to browser
INFO - 2023-06-11 15:21:04 --> Config Class Initialized
INFO - 2023-06-11 15:21:04 --> Hooks Class Initialized
INFO - 2023-06-11 15:21:04 --> Utf8 Class Initialized
INFO - 2023-06-11 15:21:04 --> URI Class Initialized
INFO - 2023-06-11 15:21:04 --> Router Class Initialized
INFO - 2023-06-11 15:21:04 --> Output Class Initialized
INFO - 2023-06-11 15:21:04 --> Security Class Initialized
INFO - 2023-06-11 15:21:04 --> Input Class Initialized
INFO - 2023-06-11 15:21:04 --> Language Class Initialized
INFO - 2023-06-11 15:21:04 --> Loader Class Initialized
INFO - 2023-06-11 15:21:04 --> Helper loaded: url_helper
INFO - 2023-06-11 15:21:04 --> Helper loaded: form_helper
INFO - 2023-06-11 15:21:04 --> Database Driver Class Initialized
INFO - 2023-06-11 15:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:21:04 --> Form Validation Class Initialized
INFO - 2023-06-11 15:21:04 --> Controller Class Initialized
INFO - 2023-06-11 15:21:04 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:21:04 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:21:04 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:21:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:21:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:21:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:21:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:21:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:21:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:21:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:21:04 --> Final output sent to browser
INFO - 2023-06-11 15:21:58 --> Config Class Initialized
INFO - 2023-06-11 15:21:58 --> Hooks Class Initialized
INFO - 2023-06-11 15:21:58 --> Utf8 Class Initialized
INFO - 2023-06-11 15:21:58 --> URI Class Initialized
INFO - 2023-06-11 15:21:58 --> Router Class Initialized
INFO - 2023-06-11 15:21:58 --> Output Class Initialized
INFO - 2023-06-11 15:21:58 --> Security Class Initialized
INFO - 2023-06-11 15:21:58 --> Input Class Initialized
INFO - 2023-06-11 15:21:58 --> Language Class Initialized
INFO - 2023-06-11 15:21:58 --> Loader Class Initialized
INFO - 2023-06-11 15:21:58 --> Helper loaded: url_helper
INFO - 2023-06-11 15:21:58 --> Helper loaded: form_helper
INFO - 2023-06-11 15:21:58 --> Database Driver Class Initialized
INFO - 2023-06-11 15:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:21:58 --> Form Validation Class Initialized
INFO - 2023-06-11 15:21:58 --> Controller Class Initialized
INFO - 2023-06-11 15:21:58 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:21:58 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:21:58 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:21:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 627
INFO - 2023-06-11 15:21:58 --> Final output sent to browser
INFO - 2023-06-11 15:22:17 --> Config Class Initialized
INFO - 2023-06-11 15:22:17 --> Hooks Class Initialized
INFO - 2023-06-11 15:22:17 --> Utf8 Class Initialized
INFO - 2023-06-11 15:22:17 --> URI Class Initialized
INFO - 2023-06-11 15:22:17 --> Router Class Initialized
INFO - 2023-06-11 15:22:17 --> Output Class Initialized
INFO - 2023-06-11 15:22:17 --> Security Class Initialized
INFO - 2023-06-11 15:22:17 --> Input Class Initialized
INFO - 2023-06-11 15:22:17 --> Language Class Initialized
INFO - 2023-06-11 15:22:17 --> Loader Class Initialized
INFO - 2023-06-11 15:22:17 --> Helper loaded: url_helper
INFO - 2023-06-11 15:22:17 --> Helper loaded: form_helper
INFO - 2023-06-11 15:22:17 --> Database Driver Class Initialized
INFO - 2023-06-11 15:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:22:17 --> Form Validation Class Initialized
INFO - 2023-06-11 15:22:17 --> Controller Class Initialized
INFO - 2023-06-11 15:22:17 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:22:17 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:22:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:22:17 --> Final output sent to browser
INFO - 2023-06-11 15:22:22 --> Config Class Initialized
INFO - 2023-06-11 15:22:22 --> Hooks Class Initialized
INFO - 2023-06-11 15:22:22 --> Utf8 Class Initialized
INFO - 2023-06-11 15:22:22 --> URI Class Initialized
INFO - 2023-06-11 15:22:22 --> Router Class Initialized
INFO - 2023-06-11 15:22:22 --> Output Class Initialized
INFO - 2023-06-11 15:22:22 --> Security Class Initialized
INFO - 2023-06-11 15:22:22 --> Input Class Initialized
INFO - 2023-06-11 15:22:22 --> Language Class Initialized
INFO - 2023-06-11 15:22:22 --> Loader Class Initialized
INFO - 2023-06-11 15:22:22 --> Helper loaded: url_helper
INFO - 2023-06-11 15:22:22 --> Helper loaded: form_helper
INFO - 2023-06-11 15:22:22 --> Database Driver Class Initialized
INFO - 2023-06-11 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:22:22 --> Form Validation Class Initialized
INFO - 2023-06-11 15:22:22 --> Controller Class Initialized
INFO - 2023-06-11 15:22:22 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:22:22 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:22:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:22:22 --> Final output sent to browser
INFO - 2023-06-11 15:22:30 --> Config Class Initialized
INFO - 2023-06-11 15:22:30 --> Hooks Class Initialized
INFO - 2023-06-11 15:22:30 --> Utf8 Class Initialized
INFO - 2023-06-11 15:22:30 --> URI Class Initialized
INFO - 2023-06-11 15:22:30 --> Router Class Initialized
INFO - 2023-06-11 15:22:30 --> Output Class Initialized
INFO - 2023-06-11 15:22:30 --> Security Class Initialized
INFO - 2023-06-11 15:22:30 --> Input Class Initialized
INFO - 2023-06-11 15:22:30 --> Language Class Initialized
INFO - 2023-06-11 15:22:30 --> Loader Class Initialized
INFO - 2023-06-11 15:22:30 --> Helper loaded: url_helper
INFO - 2023-06-11 15:22:30 --> Helper loaded: form_helper
INFO - 2023-06-11 15:22:30 --> Database Driver Class Initialized
INFO - 2023-06-11 15:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:22:30 --> Form Validation Class Initialized
INFO - 2023-06-11 15:22:30 --> Controller Class Initialized
INFO - 2023-06-11 15:22:31 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:22:31 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:22:31 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:22:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:22:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:22:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:22:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:22:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:22:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:22:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:22:31 --> Final output sent to browser
INFO - 2023-06-11 15:22:33 --> Config Class Initialized
INFO - 2023-06-11 15:22:33 --> Hooks Class Initialized
INFO - 2023-06-11 15:22:33 --> Utf8 Class Initialized
INFO - 2023-06-11 15:22:33 --> URI Class Initialized
INFO - 2023-06-11 15:22:33 --> Router Class Initialized
INFO - 2023-06-11 15:22:33 --> Output Class Initialized
INFO - 2023-06-11 15:22:33 --> Security Class Initialized
INFO - 2023-06-11 15:22:34 --> Input Class Initialized
INFO - 2023-06-11 15:22:34 --> Language Class Initialized
INFO - 2023-06-11 15:22:34 --> Loader Class Initialized
INFO - 2023-06-11 15:22:34 --> Helper loaded: url_helper
INFO - 2023-06-11 15:22:34 --> Helper loaded: form_helper
INFO - 2023-06-11 15:22:34 --> Database Driver Class Initialized
INFO - 2023-06-11 15:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:22:34 --> Form Validation Class Initialized
INFO - 2023-06-11 15:22:34 --> Controller Class Initialized
INFO - 2023-06-11 15:22:34 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:22:34 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:22:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:22:34 --> Final output sent to browser
INFO - 2023-06-11 15:22:43 --> Config Class Initialized
INFO - 2023-06-11 15:22:43 --> Hooks Class Initialized
INFO - 2023-06-11 15:22:43 --> Utf8 Class Initialized
INFO - 2023-06-11 15:22:43 --> URI Class Initialized
INFO - 2023-06-11 15:22:43 --> Router Class Initialized
INFO - 2023-06-11 15:22:43 --> Output Class Initialized
INFO - 2023-06-11 15:22:43 --> Security Class Initialized
INFO - 2023-06-11 15:22:43 --> Input Class Initialized
INFO - 2023-06-11 15:22:43 --> Language Class Initialized
INFO - 2023-06-11 15:22:43 --> Loader Class Initialized
INFO - 2023-06-11 15:22:43 --> Helper loaded: url_helper
INFO - 2023-06-11 15:22:43 --> Helper loaded: form_helper
INFO - 2023-06-11 15:22:43 --> Database Driver Class Initialized
INFO - 2023-06-11 15:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:22:43 --> Form Validation Class Initialized
INFO - 2023-06-11 15:22:43 --> Controller Class Initialized
INFO - 2023-06-11 15:22:43 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:22:43 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:22:43 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:22:43 --> Final output sent to browser
INFO - 2023-06-11 15:23:06 --> Config Class Initialized
INFO - 2023-06-11 15:23:06 --> Hooks Class Initialized
INFO - 2023-06-11 15:23:06 --> Utf8 Class Initialized
INFO - 2023-06-11 15:23:06 --> URI Class Initialized
INFO - 2023-06-11 15:23:06 --> Router Class Initialized
INFO - 2023-06-11 15:23:06 --> Output Class Initialized
INFO - 2023-06-11 15:23:06 --> Security Class Initialized
INFO - 2023-06-11 15:23:06 --> Input Class Initialized
INFO - 2023-06-11 15:23:06 --> Language Class Initialized
INFO - 2023-06-11 15:23:06 --> Loader Class Initialized
INFO - 2023-06-11 15:23:06 --> Helper loaded: url_helper
INFO - 2023-06-11 15:23:06 --> Helper loaded: form_helper
INFO - 2023-06-11 15:23:06 --> Database Driver Class Initialized
INFO - 2023-06-11 15:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:23:06 --> Form Validation Class Initialized
INFO - 2023-06-11 15:23:06 --> Controller Class Initialized
INFO - 2023-06-11 15:23:06 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:23:06 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:23:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:23:06 --> Final output sent to browser
INFO - 2023-06-11 15:23:15 --> Config Class Initialized
INFO - 2023-06-11 15:23:15 --> Hooks Class Initialized
INFO - 2023-06-11 15:23:15 --> Utf8 Class Initialized
INFO - 2023-06-11 15:23:15 --> URI Class Initialized
INFO - 2023-06-11 15:23:15 --> Router Class Initialized
INFO - 2023-06-11 15:23:15 --> Output Class Initialized
INFO - 2023-06-11 15:23:15 --> Security Class Initialized
INFO - 2023-06-11 15:23:15 --> Input Class Initialized
INFO - 2023-06-11 15:23:15 --> Language Class Initialized
INFO - 2023-06-11 15:23:15 --> Loader Class Initialized
INFO - 2023-06-11 15:23:15 --> Helper loaded: url_helper
INFO - 2023-06-11 15:23:15 --> Helper loaded: form_helper
INFO - 2023-06-11 15:23:15 --> Database Driver Class Initialized
INFO - 2023-06-11 15:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:23:15 --> Form Validation Class Initialized
INFO - 2023-06-11 15:23:15 --> Controller Class Initialized
INFO - 2023-06-11 15:23:15 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:23:15 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:23:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:23:15 --> Final output sent to browser
INFO - 2023-06-11 15:23:21 --> Config Class Initialized
INFO - 2023-06-11 15:23:21 --> Hooks Class Initialized
INFO - 2023-06-11 15:23:21 --> Utf8 Class Initialized
INFO - 2023-06-11 15:23:21 --> URI Class Initialized
INFO - 2023-06-11 15:23:21 --> Router Class Initialized
INFO - 2023-06-11 15:23:21 --> Output Class Initialized
INFO - 2023-06-11 15:23:21 --> Security Class Initialized
INFO - 2023-06-11 15:23:21 --> Input Class Initialized
INFO - 2023-06-11 15:23:21 --> Language Class Initialized
INFO - 2023-06-11 15:23:21 --> Loader Class Initialized
INFO - 2023-06-11 15:23:21 --> Helper loaded: url_helper
INFO - 2023-06-11 15:23:21 --> Helper loaded: form_helper
INFO - 2023-06-11 15:23:21 --> Database Driver Class Initialized
INFO - 2023-06-11 15:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:23:21 --> Form Validation Class Initialized
INFO - 2023-06-11 15:23:21 --> Controller Class Initialized
INFO - 2023-06-11 15:23:21 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:23:21 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:23:21 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:23:21 --> Final output sent to browser
INFO - 2023-06-11 15:24:21 --> Config Class Initialized
INFO - 2023-06-11 15:24:21 --> Hooks Class Initialized
INFO - 2023-06-11 15:24:21 --> Utf8 Class Initialized
INFO - 2023-06-11 15:24:21 --> URI Class Initialized
INFO - 2023-06-11 15:24:21 --> Router Class Initialized
INFO - 2023-06-11 15:24:21 --> Output Class Initialized
INFO - 2023-06-11 15:24:21 --> Security Class Initialized
INFO - 2023-06-11 15:24:21 --> Input Class Initialized
INFO - 2023-06-11 15:24:21 --> Language Class Initialized
INFO - 2023-06-11 15:24:21 --> Loader Class Initialized
INFO - 2023-06-11 15:24:21 --> Helper loaded: url_helper
INFO - 2023-06-11 15:24:21 --> Helper loaded: form_helper
INFO - 2023-06-11 15:24:21 --> Database Driver Class Initialized
INFO - 2023-06-11 15:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:24:21 --> Form Validation Class Initialized
INFO - 2023-06-11 15:24:21 --> Controller Class Initialized
INFO - 2023-06-11 15:24:21 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:24:21 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:24:21 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:24:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:24:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:24:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:24:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:24:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:24:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:24:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:24:21 --> Final output sent to browser
INFO - 2023-06-11 15:24:24 --> Config Class Initialized
INFO - 2023-06-11 15:24:24 --> Hooks Class Initialized
INFO - 2023-06-11 15:24:24 --> Utf8 Class Initialized
INFO - 2023-06-11 15:24:24 --> URI Class Initialized
INFO - 2023-06-11 15:24:24 --> Router Class Initialized
INFO - 2023-06-11 15:24:24 --> Output Class Initialized
INFO - 2023-06-11 15:24:24 --> Security Class Initialized
INFO - 2023-06-11 15:24:24 --> Input Class Initialized
INFO - 2023-06-11 15:24:24 --> Language Class Initialized
INFO - 2023-06-11 15:24:24 --> Helper loaded: form_helper
INFO - 2023-06-11 15:24:24 --> Database Driver Class Initialized
INFO - 2023-06-11 15:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:24:24 --> Form Validation Class Initialized
INFO - 2023-06-11 15:24:24 --> Controller Class Initialized
INFO - 2023-06-11 15:24:24 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:24:24 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:24:24 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:24:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 637
INFO - 2023-06-11 15:24:24 --> Final output sent to browser
INFO - 2023-06-11 15:24:30 --> Config Class Initialized
INFO - 2023-06-11 15:24:30 --> Hooks Class Initialized
INFO - 2023-06-11 15:24:30 --> Utf8 Class Initialized
INFO - 2023-06-11 15:24:30 --> URI Class Initialized
INFO - 2023-06-11 15:24:30 --> Router Class Initialized
INFO - 2023-06-11 15:24:30 --> Output Class Initialized
INFO - 2023-06-11 15:24:30 --> Security Class Initialized
INFO - 2023-06-11 15:24:30 --> Input Class Initialized
INFO - 2023-06-11 15:24:30 --> Language Class Initialized
INFO - 2023-06-11 15:24:30 --> Loader Class Initialized
INFO - 2023-06-11 15:24:30 --> Helper loaded: url_helper
INFO - 2023-06-11 15:24:30 --> Helper loaded: form_helper
INFO - 2023-06-11 15:24:30 --> Database Driver Class Initialized
INFO - 2023-06-11 15:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:24:30 --> Form Validation Class Initialized
INFO - 2023-06-11 15:24:30 --> Controller Class Initialized
INFO - 2023-06-11 15:24:30 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:24:30 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:24:30 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:24:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:24:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:24:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:24:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:24:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:24:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:24:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:24:30 --> Final output sent to browser
INFO - 2023-06-11 15:26:30 --> Config Class Initialized
INFO - 2023-06-11 15:26:30 --> Hooks Class Initialized
INFO - 2023-06-11 15:26:30 --> Utf8 Class Initialized
INFO - 2023-06-11 15:26:30 --> URI Class Initialized
INFO - 2023-06-11 15:26:30 --> Router Class Initialized
INFO - 2023-06-11 15:26:30 --> Output Class Initialized
INFO - 2023-06-11 15:26:30 --> Security Class Initialized
INFO - 2023-06-11 15:26:30 --> Input Class Initialized
INFO - 2023-06-11 15:26:30 --> Language Class Initialized
INFO - 2023-06-11 15:26:30 --> Loader Class Initialized
INFO - 2023-06-11 15:26:30 --> Helper loaded: url_helper
INFO - 2023-06-11 15:26:30 --> Helper loaded: form_helper
INFO - 2023-06-11 15:26:30 --> Database Driver Class Initialized
INFO - 2023-06-11 15:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:26:30 --> Form Validation Class Initialized
INFO - 2023-06-11 15:26:30 --> Controller Class Initialized
INFO - 2023-06-11 15:26:30 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:26:30 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:26:30 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:26:30 --> Config Class Initialized
INFO - 2023-06-11 15:26:30 --> Hooks Class Initialized
INFO - 2023-06-11 15:26:30 --> Utf8 Class Initialized
INFO - 2023-06-11 15:26:30 --> URI Class Initialized
INFO - 2023-06-11 15:26:30 --> Router Class Initialized
INFO - 2023-06-11 15:26:30 --> Output Class Initialized
INFO - 2023-06-11 15:26:30 --> Security Class Initialized
INFO - 2023-06-11 15:26:30 --> Input Class Initialized
INFO - 2023-06-11 15:26:30 --> Language Class Initialized
INFO - 2023-06-11 15:26:30 --> Loader Class Initialized
INFO - 2023-06-11 15:26:30 --> Helper loaded: url_helper
INFO - 2023-06-11 15:26:30 --> Helper loaded: form_helper
INFO - 2023-06-11 15:26:30 --> Database Driver Class Initialized
INFO - 2023-06-11 15:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:26:30 --> Form Validation Class Initialized
INFO - 2023-06-11 15:26:30 --> Controller Class Initialized
INFO - 2023-06-11 15:26:30 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:26:30 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:26:30 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:26:30 --> Severity: Warning --> Missing argument 1 for C_datatest::hapus() C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 606
ERROR - 2023-06-11 15:26:30 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 608
INFO - 2023-06-11 15:26:30 --> Config Class Initialized
INFO - 2023-06-11 15:26:30 --> Hooks Class Initialized
INFO - 2023-06-11 15:26:30 --> Utf8 Class Initialized
INFO - 2023-06-11 15:26:30 --> URI Class Initialized
INFO - 2023-06-11 15:26:30 --> Router Class Initialized
INFO - 2023-06-11 15:26:30 --> Output Class Initialized
INFO - 2023-06-11 15:26:30 --> Security Class Initialized
INFO - 2023-06-11 15:26:30 --> Input Class Initialized
INFO - 2023-06-11 15:26:30 --> Language Class Initialized
INFO - 2023-06-11 15:26:30 --> Loader Class Initialized
INFO - 2023-06-11 15:26:30 --> Helper loaded: url_helper
INFO - 2023-06-11 15:26:30 --> Helper loaded: form_helper
INFO - 2023-06-11 15:26:30 --> Database Driver Class Initialized
INFO - 2023-06-11 15:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:26:30 --> Form Validation Class Initialized
INFO - 2023-06-11 15:26:30 --> Controller Class Initialized
INFO - 2023-06-11 15:26:30 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:26:30 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:26:30 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:26:30 --> Final output sent to browser
INFO - 2023-06-11 15:26:39 --> Config Class Initialized
INFO - 2023-06-11 15:26:39 --> Hooks Class Initialized
INFO - 2023-06-11 15:26:39 --> Utf8 Class Initialized
INFO - 2023-06-11 15:26:39 --> URI Class Initialized
INFO - 2023-06-11 15:26:39 --> Router Class Initialized
INFO - 2023-06-11 15:26:39 --> Output Class Initialized
INFO - 2023-06-11 15:26:39 --> Security Class Initialized
INFO - 2023-06-11 15:26:39 --> Input Class Initialized
INFO - 2023-06-11 15:26:39 --> Language Class Initialized
INFO - 2023-06-11 15:26:39 --> Loader Class Initialized
INFO - 2023-06-11 15:26:39 --> Helper loaded: url_helper
INFO - 2023-06-11 15:26:39 --> Helper loaded: form_helper
INFO - 2023-06-11 15:26:40 --> Database Driver Class Initialized
INFO - 2023-06-11 15:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:26:40 --> Form Validation Class Initialized
INFO - 2023-06-11 15:26:40 --> Controller Class Initialized
INFO - 2023-06-11 15:26:40 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:26:40 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:26:40 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:26:40 --> Final output sent to browser
INFO - 2023-06-11 15:26:45 --> Config Class Initialized
INFO - 2023-06-11 15:26:45 --> Hooks Class Initialized
INFO - 2023-06-11 15:26:45 --> Utf8 Class Initialized
INFO - 2023-06-11 15:26:45 --> URI Class Initialized
INFO - 2023-06-11 15:26:45 --> Router Class Initialized
INFO - 2023-06-11 15:26:45 --> Output Class Initialized
INFO - 2023-06-11 15:26:45 --> Security Class Initialized
INFO - 2023-06-11 15:26:45 --> Input Class Initialized
INFO - 2023-06-11 15:26:45 --> Language Class Initialized
INFO - 2023-06-11 15:26:45 --> Loader Class Initialized
INFO - 2023-06-11 15:26:45 --> Helper loaded: url_helper
INFO - 2023-06-11 15:26:45 --> Helper loaded: form_helper
INFO - 2023-06-11 15:26:45 --> Database Driver Class Initialized
INFO - 2023-06-11 15:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:26:45 --> Form Validation Class Initialized
INFO - 2023-06-11 15:26:45 --> Controller Class Initialized
INFO - 2023-06-11 15:26:45 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:26:45 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:26:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:26:45 --> Config Class Initialized
INFO - 2023-06-11 15:26:45 --> Hooks Class Initialized
INFO - 2023-06-11 15:26:45 --> Utf8 Class Initialized
INFO - 2023-06-11 15:26:45 --> URI Class Initialized
INFO - 2023-06-11 15:26:45 --> Router Class Initialized
INFO - 2023-06-11 15:26:45 --> Output Class Initialized
INFO - 2023-06-11 15:26:45 --> Security Class Initialized
INFO - 2023-06-11 15:26:45 --> Input Class Initialized
INFO - 2023-06-11 15:26:45 --> Language Class Initialized
INFO - 2023-06-11 15:26:45 --> Loader Class Initialized
INFO - 2023-06-11 15:26:45 --> Helper loaded: url_helper
INFO - 2023-06-11 15:26:45 --> Helper loaded: form_helper
INFO - 2023-06-11 15:26:45 --> Database Driver Class Initialized
INFO - 2023-06-11 15:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:26:45 --> Form Validation Class Initialized
INFO - 2023-06-11 15:26:45 --> Controller Class Initialized
INFO - 2023-06-11 15:26:45 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:26:45 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:26:45 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:26:45 --> Severity: Warning --> Missing argument 1 for C_datatest::hapus() C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 606
ERROR - 2023-06-11 15:26:45 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 608
INFO - 2023-06-11 15:26:45 --> Config Class Initialized
INFO - 2023-06-11 15:26:45 --> Hooks Class Initialized
INFO - 2023-06-11 15:26:45 --> Utf8 Class Initialized
INFO - 2023-06-11 15:26:45 --> URI Class Initialized
INFO - 2023-06-11 15:26:45 --> Router Class Initialized
INFO - 2023-06-11 15:26:45 --> Output Class Initialized
INFO - 2023-06-11 15:26:45 --> Security Class Initialized
INFO - 2023-06-11 15:26:45 --> Input Class Initialized
INFO - 2023-06-11 15:26:45 --> Language Class Initialized
INFO - 2023-06-11 15:26:45 --> Loader Class Initialized
INFO - 2023-06-11 15:26:45 --> Helper loaded: url_helper
INFO - 2023-06-11 15:26:45 --> Helper loaded: form_helper
INFO - 2023-06-11 15:26:45 --> Database Driver Class Initialized
INFO - 2023-06-11 15:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:26:45 --> Form Validation Class Initialized
INFO - 2023-06-11 15:26:45 --> Controller Class Initialized
INFO - 2023-06-11 15:26:45 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:26:45 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:26:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:26:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:26:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:26:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:26:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:26:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:26:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:26:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:26:45 --> Final output sent to browser
INFO - 2023-06-11 15:28:23 --> Config Class Initialized
INFO - 2023-06-11 15:28:23 --> Hooks Class Initialized
INFO - 2023-06-11 15:28:23 --> Utf8 Class Initialized
INFO - 2023-06-11 15:28:23 --> URI Class Initialized
INFO - 2023-06-11 15:28:23 --> Router Class Initialized
INFO - 2023-06-11 15:28:23 --> Output Class Initialized
INFO - 2023-06-11 15:28:23 --> Security Class Initialized
INFO - 2023-06-11 15:28:23 --> Input Class Initialized
INFO - 2023-06-11 15:28:23 --> Language Class Initialized
INFO - 2023-06-11 15:28:23 --> Loader Class Initialized
INFO - 2023-06-11 15:28:23 --> Helper loaded: url_helper
INFO - 2023-06-11 15:28:23 --> Helper loaded: form_helper
INFO - 2023-06-11 15:28:23 --> Database Driver Class Initialized
INFO - 2023-06-11 15:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:28:23 --> Form Validation Class Initialized
INFO - 2023-06-11 15:28:23 --> Controller Class Initialized
INFO - 2023-06-11 15:28:23 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:28:23 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:28:23 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:28:23 --> Final output sent to browser
INFO - 2023-06-11 15:28:28 --> Config Class Initialized
INFO - 2023-06-11 15:28:28 --> Hooks Class Initialized
INFO - 2023-06-11 15:28:28 --> Utf8 Class Initialized
INFO - 2023-06-11 15:28:28 --> URI Class Initialized
INFO - 2023-06-11 15:28:28 --> Router Class Initialized
INFO - 2023-06-11 15:28:28 --> Output Class Initialized
INFO - 2023-06-11 15:28:28 --> Security Class Initialized
INFO - 2023-06-11 15:28:28 --> Input Class Initialized
INFO - 2023-06-11 15:28:28 --> Language Class Initialized
INFO - 2023-06-11 15:28:28 --> Loader Class Initialized
INFO - 2023-06-11 15:28:28 --> Helper loaded: url_helper
INFO - 2023-06-11 15:28:28 --> Helper loaded: form_helper
INFO - 2023-06-11 15:28:28 --> Database Driver Class Initialized
INFO - 2023-06-11 15:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:28:28 --> Form Validation Class Initialized
INFO - 2023-06-11 15:28:28 --> Controller Class Initialized
INFO - 2023-06-11 15:28:28 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:28:28 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:28:28 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:28:28 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 638
INFO - 2023-06-11 15:28:28 --> Config Class Initialized
INFO - 2023-06-11 15:28:28 --> Hooks Class Initialized
INFO - 2023-06-11 15:28:28 --> Utf8 Class Initialized
INFO - 2023-06-11 15:28:28 --> URI Class Initialized
INFO - 2023-06-11 15:28:28 --> Router Class Initialized
INFO - 2023-06-11 15:28:28 --> Output Class Initialized
INFO - 2023-06-11 15:28:28 --> Security Class Initialized
INFO - 2023-06-11 15:28:28 --> Input Class Initialized
INFO - 2023-06-11 15:28:28 --> Language Class Initialized
INFO - 2023-06-11 15:28:28 --> Loader Class Initialized
INFO - 2023-06-11 15:28:28 --> Helper loaded: url_helper
INFO - 2023-06-11 15:28:28 --> Helper loaded: form_helper
INFO - 2023-06-11 15:28:28 --> Database Driver Class Initialized
INFO - 2023-06-11 15:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:28:28 --> Form Validation Class Initialized
INFO - 2023-06-11 15:28:28 --> Controller Class Initialized
INFO - 2023-06-11 15:28:28 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:28:28 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:28:28 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:28:28 --> Final output sent to browser
INFO - 2023-06-11 15:29:07 --> Config Class Initialized
INFO - 2023-06-11 15:29:07 --> Hooks Class Initialized
INFO - 2023-06-11 15:29:07 --> Utf8 Class Initialized
INFO - 2023-06-11 15:29:07 --> URI Class Initialized
INFO - 2023-06-11 15:29:07 --> Router Class Initialized
INFO - 2023-06-11 15:29:07 --> Output Class Initialized
INFO - 2023-06-11 15:29:07 --> Security Class Initialized
INFO - 2023-06-11 15:29:07 --> Input Class Initialized
INFO - 2023-06-11 15:29:07 --> Language Class Initialized
INFO - 2023-06-11 15:29:07 --> Loader Class Initialized
INFO - 2023-06-11 15:29:07 --> Helper loaded: url_helper
INFO - 2023-06-11 15:29:07 --> Helper loaded: form_helper
INFO - 2023-06-11 15:29:07 --> Database Driver Class Initialized
INFO - 2023-06-11 15:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:29:07 --> Form Validation Class Initialized
INFO - 2023-06-11 15:29:07 --> Controller Class Initialized
INFO - 2023-06-11 15:29:07 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:29:07 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:29:07 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:29:07 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 637
INFO - 2023-06-11 15:29:07 --> Final output sent to browser
INFO - 2023-06-11 15:29:19 --> Config Class Initialized
INFO - 2023-06-11 15:29:19 --> Hooks Class Initialized
INFO - 2023-06-11 15:29:19 --> Utf8 Class Initialized
INFO - 2023-06-11 15:29:19 --> URI Class Initialized
INFO - 2023-06-11 15:29:19 --> Router Class Initialized
INFO - 2023-06-11 15:29:19 --> Output Class Initialized
INFO - 2023-06-11 15:29:19 --> Security Class Initialized
INFO - 2023-06-11 15:29:19 --> Input Class Initialized
INFO - 2023-06-11 15:29:19 --> Language Class Initialized
INFO - 2023-06-11 15:29:19 --> Loader Class Initialized
INFO - 2023-06-11 15:29:19 --> Helper loaded: url_helper
INFO - 2023-06-11 15:29:19 --> Helper loaded: form_helper
INFO - 2023-06-11 15:29:19 --> Database Driver Class Initialized
INFO - 2023-06-11 15:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:29:19 --> Form Validation Class Initialized
INFO - 2023-06-11 15:29:19 --> Controller Class Initialized
INFO - 2023-06-11 15:29:19 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:29:19 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:29:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:29:19 --> Final output sent to browser
INFO - 2023-06-11 15:29:25 --> Config Class Initialized
INFO - 2023-06-11 15:29:25 --> Hooks Class Initialized
INFO - 2023-06-11 15:29:25 --> Utf8 Class Initialized
INFO - 2023-06-11 15:29:25 --> URI Class Initialized
INFO - 2023-06-11 15:29:26 --> Router Class Initialized
INFO - 2023-06-11 15:29:26 --> Output Class Initialized
INFO - 2023-06-11 15:29:26 --> Security Class Initialized
INFO - 2023-06-11 15:29:26 --> Input Class Initialized
INFO - 2023-06-11 15:29:26 --> Language Class Initialized
INFO - 2023-06-11 15:29:26 --> Loader Class Initialized
INFO - 2023-06-11 15:29:26 --> Helper loaded: url_helper
INFO - 2023-06-11 15:29:26 --> Helper loaded: form_helper
INFO - 2023-06-11 15:29:26 --> Database Driver Class Initialized
INFO - 2023-06-11 15:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:29:26 --> Form Validation Class Initialized
INFO - 2023-06-11 15:29:26 --> Controller Class Initialized
INFO - 2023-06-11 15:29:26 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:29:26 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:29:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:29:26 --> Final output sent to browser
INFO - 2023-06-11 15:29:48 --> Config Class Initialized
INFO - 2023-06-11 15:29:48 --> Hooks Class Initialized
INFO - 2023-06-11 15:29:48 --> Utf8 Class Initialized
INFO - 2023-06-11 15:29:48 --> URI Class Initialized
INFO - 2023-06-11 15:29:48 --> Router Class Initialized
INFO - 2023-06-11 15:29:48 --> Output Class Initialized
INFO - 2023-06-11 15:29:48 --> Security Class Initialized
INFO - 2023-06-11 15:29:48 --> Input Class Initialized
INFO - 2023-06-11 15:29:49 --> Language Class Initialized
INFO - 2023-06-11 15:29:49 --> Loader Class Initialized
INFO - 2023-06-11 15:29:49 --> Helper loaded: url_helper
INFO - 2023-06-11 15:29:49 --> Helper loaded: form_helper
INFO - 2023-06-11 15:29:49 --> Database Driver Class Initialized
INFO - 2023-06-11 15:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:29:49 --> Form Validation Class Initialized
INFO - 2023-06-11 15:29:49 --> Controller Class Initialized
INFO - 2023-06-11 15:29:49 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:29:49 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:29:49 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:29:49 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 639
INFO - 2023-06-11 15:29:49 --> Config Class Initialized
INFO - 2023-06-11 15:29:49 --> Hooks Class Initialized
INFO - 2023-06-11 15:29:49 --> Utf8 Class Initialized
INFO - 2023-06-11 15:29:49 --> URI Class Initialized
INFO - 2023-06-11 15:29:49 --> Router Class Initialized
INFO - 2023-06-11 15:29:49 --> Output Class Initialized
INFO - 2023-06-11 15:29:49 --> Security Class Initialized
INFO - 2023-06-11 15:29:49 --> Input Class Initialized
INFO - 2023-06-11 15:29:49 --> Language Class Initialized
INFO - 2023-06-11 15:29:49 --> Loader Class Initialized
INFO - 2023-06-11 15:29:49 --> Helper loaded: url_helper
INFO - 2023-06-11 15:29:49 --> Helper loaded: form_helper
INFO - 2023-06-11 15:29:49 --> Database Driver Class Initialized
INFO - 2023-06-11 15:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:29:49 --> Form Validation Class Initialized
INFO - 2023-06-11 15:29:49 --> Controller Class Initialized
INFO - 2023-06-11 15:29:49 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:29:49 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:29:49 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:29:49 --> Final output sent to browser
INFO - 2023-06-11 15:29:54 --> Config Class Initialized
INFO - 2023-06-11 15:29:54 --> Hooks Class Initialized
INFO - 2023-06-11 15:29:54 --> Utf8 Class Initialized
INFO - 2023-06-11 15:29:54 --> URI Class Initialized
INFO - 2023-06-11 15:29:54 --> Router Class Initialized
INFO - 2023-06-11 15:29:54 --> Output Class Initialized
INFO - 2023-06-11 15:29:54 --> Security Class Initialized
INFO - 2023-06-11 15:29:54 --> Input Class Initialized
INFO - 2023-06-11 15:29:54 --> Language Class Initialized
INFO - 2023-06-11 15:29:54 --> Loader Class Initialized
INFO - 2023-06-11 15:29:54 --> Helper loaded: url_helper
INFO - 2023-06-11 15:29:54 --> Helper loaded: form_helper
INFO - 2023-06-11 15:29:54 --> Database Driver Class Initialized
INFO - 2023-06-11 15:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:29:54 --> Form Validation Class Initialized
INFO - 2023-06-11 15:29:54 --> Controller Class Initialized
INFO - 2023-06-11 15:29:54 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:29:54 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:29:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:29:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:29:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:29:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:29:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:29:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:29:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:29:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:29:54 --> Final output sent to browser
INFO - 2023-06-11 15:29:55 --> Config Class Initialized
INFO - 2023-06-11 15:29:55 --> Hooks Class Initialized
INFO - 2023-06-11 15:29:55 --> Utf8 Class Initialized
INFO - 2023-06-11 15:29:56 --> URI Class Initialized
INFO - 2023-06-11 15:29:56 --> Router Class Initialized
INFO - 2023-06-11 15:29:56 --> Output Class Initialized
INFO - 2023-06-11 15:29:56 --> Security Class Initialized
INFO - 2023-06-11 15:29:56 --> Input Class Initialized
INFO - 2023-06-11 15:29:56 --> Language Class Initialized
INFO - 2023-06-11 15:29:56 --> Loader Class Initialized
INFO - 2023-06-11 15:29:56 --> Helper loaded: url_helper
INFO - 2023-06-11 15:29:56 --> Helper loaded: form_helper
INFO - 2023-06-11 15:29:56 --> Database Driver Class Initialized
INFO - 2023-06-11 15:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:29:56 --> Form Validation Class Initialized
INFO - 2023-06-11 15:29:56 --> Controller Class Initialized
INFO - 2023-06-11 15:29:56 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:29:56 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:29:56 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:29:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:29:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:29:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:29:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:29:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:29:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:29:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:29:56 --> Final output sent to browser
INFO - 2023-06-11 15:30:01 --> Config Class Initialized
INFO - 2023-06-11 15:30:01 --> Hooks Class Initialized
INFO - 2023-06-11 15:30:01 --> Utf8 Class Initialized
INFO - 2023-06-11 15:30:01 --> URI Class Initialized
INFO - 2023-06-11 15:30:01 --> Router Class Initialized
INFO - 2023-06-11 15:30:01 --> Output Class Initialized
INFO - 2023-06-11 15:30:01 --> Security Class Initialized
INFO - 2023-06-11 15:30:01 --> Input Class Initialized
INFO - 2023-06-11 15:30:01 --> Language Class Initialized
INFO - 2023-06-11 15:30:01 --> Loader Class Initialized
INFO - 2023-06-11 15:30:01 --> Helper loaded: url_helper
INFO - 2023-06-11 15:30:01 --> Helper loaded: form_helper
INFO - 2023-06-11 15:30:01 --> Database Driver Class Initialized
INFO - 2023-06-11 15:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:30:01 --> Form Validation Class Initialized
INFO - 2023-06-11 15:30:01 --> Controller Class Initialized
INFO - 2023-06-11 15:30:01 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:30:01 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:30:01 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:30:01 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 639
INFO - 2023-06-11 15:30:01 --> Config Class Initialized
INFO - 2023-06-11 15:30:01 --> Hooks Class Initialized
INFO - 2023-06-11 15:30:01 --> Utf8 Class Initialized
INFO - 2023-06-11 15:30:01 --> URI Class Initialized
INFO - 2023-06-11 15:30:01 --> Router Class Initialized
INFO - 2023-06-11 15:30:01 --> Output Class Initialized
INFO - 2023-06-11 15:30:01 --> Security Class Initialized
INFO - 2023-06-11 15:30:01 --> Input Class Initialized
INFO - 2023-06-11 15:30:01 --> Language Class Initialized
INFO - 2023-06-11 15:30:01 --> Loader Class Initialized
INFO - 2023-06-11 15:30:01 --> Helper loaded: url_helper
INFO - 2023-06-11 15:30:01 --> Helper loaded: form_helper
INFO - 2023-06-11 15:30:01 --> Database Driver Class Initialized
INFO - 2023-06-11 15:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:30:01 --> Form Validation Class Initialized
INFO - 2023-06-11 15:30:01 --> Controller Class Initialized
INFO - 2023-06-11 15:30:01 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:30:01 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:30:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:30:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:30:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:30:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:30:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:30:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:30:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:30:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:30:01 --> Final output sent to browser
INFO - 2023-06-11 15:30:45 --> Config Class Initialized
INFO - 2023-06-11 15:30:45 --> Hooks Class Initialized
INFO - 2023-06-11 15:30:45 --> Utf8 Class Initialized
INFO - 2023-06-11 15:30:45 --> URI Class Initialized
INFO - 2023-06-11 15:30:45 --> Router Class Initialized
INFO - 2023-06-11 15:30:45 --> Output Class Initialized
INFO - 2023-06-11 15:30:45 --> Security Class Initialized
INFO - 2023-06-11 15:30:45 --> Input Class Initialized
INFO - 2023-06-11 15:30:45 --> Language Class Initialized
INFO - 2023-06-11 15:30:45 --> Loader Class Initialized
INFO - 2023-06-11 15:30:45 --> Helper loaded: url_helper
INFO - 2023-06-11 15:30:45 --> Helper loaded: form_helper
INFO - 2023-06-11 15:30:46 --> Database Driver Class Initialized
INFO - 2023-06-11 15:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:30:46 --> Form Validation Class Initialized
INFO - 2023-06-11 15:30:46 --> Controller Class Initialized
INFO - 2023-06-11 15:30:46 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:30:46 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:30:46 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:30:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 639
INFO - 2023-06-11 15:30:46 --> Config Class Initialized
INFO - 2023-06-11 15:30:46 --> Hooks Class Initialized
INFO - 2023-06-11 15:30:46 --> Utf8 Class Initialized
INFO - 2023-06-11 15:30:46 --> URI Class Initialized
INFO - 2023-06-11 15:30:46 --> Router Class Initialized
INFO - 2023-06-11 15:30:46 --> Output Class Initialized
INFO - 2023-06-11 15:30:46 --> Security Class Initialized
INFO - 2023-06-11 15:30:46 --> Input Class Initialized
INFO - 2023-06-11 15:30:46 --> Language Class Initialized
INFO - 2023-06-11 15:30:46 --> Loader Class Initialized
INFO - 2023-06-11 15:30:46 --> Helper loaded: url_helper
INFO - 2023-06-11 15:30:46 --> Helper loaded: form_helper
INFO - 2023-06-11 15:30:46 --> Database Driver Class Initialized
INFO - 2023-06-11 15:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:30:46 --> Form Validation Class Initialized
INFO - 2023-06-11 15:30:46 --> Controller Class Initialized
INFO - 2023-06-11 15:30:46 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:30:46 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:30:46 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:30:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:30:46 --> Final output sent to browser
INFO - 2023-06-11 15:31:22 --> Config Class Initialized
INFO - 2023-06-11 15:31:22 --> Hooks Class Initialized
INFO - 2023-06-11 15:31:22 --> Utf8 Class Initialized
INFO - 2023-06-11 15:31:22 --> URI Class Initialized
INFO - 2023-06-11 15:31:22 --> Router Class Initialized
INFO - 2023-06-11 15:31:22 --> Output Class Initialized
INFO - 2023-06-11 15:31:22 --> Security Class Initialized
INFO - 2023-06-11 15:31:22 --> Input Class Initialized
INFO - 2023-06-11 15:31:22 --> Language Class Initialized
INFO - 2023-06-11 15:31:22 --> Loader Class Initialized
INFO - 2023-06-11 15:31:22 --> Helper loaded: url_helper
INFO - 2023-06-11 15:31:22 --> Helper loaded: form_helper
INFO - 2023-06-11 15:31:22 --> Database Driver Class Initialized
INFO - 2023-06-11 15:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:31:22 --> Form Validation Class Initialized
INFO - 2023-06-11 15:31:22 --> Controller Class Initialized
INFO - 2023-06-11 15:31:22 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:31:22 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:31:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:31:22 --> Final output sent to browser
INFO - 2023-06-11 15:31:28 --> Config Class Initialized
INFO - 2023-06-11 15:31:28 --> Hooks Class Initialized
INFO - 2023-06-11 15:31:28 --> Utf8 Class Initialized
INFO - 2023-06-11 15:31:28 --> URI Class Initialized
INFO - 2023-06-11 15:31:28 --> Router Class Initialized
INFO - 2023-06-11 15:31:28 --> Output Class Initialized
INFO - 2023-06-11 15:31:28 --> Security Class Initialized
INFO - 2023-06-11 15:31:28 --> Input Class Initialized
INFO - 2023-06-11 15:31:28 --> Language Class Initialized
INFO - 2023-06-11 15:31:28 --> Loader Class Initialized
INFO - 2023-06-11 15:31:28 --> Helper loaded: url_helper
INFO - 2023-06-11 15:31:28 --> Helper loaded: form_helper
INFO - 2023-06-11 15:31:28 --> Database Driver Class Initialized
INFO - 2023-06-11 15:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:31:28 --> Form Validation Class Initialized
INFO - 2023-06-11 15:31:28 --> Controller Class Initialized
INFO - 2023-06-11 15:31:28 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:31:28 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:31:28 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:31:28 --> Final output sent to browser
INFO - 2023-06-11 15:32:03 --> Config Class Initialized
INFO - 2023-06-11 15:32:03 --> Hooks Class Initialized
INFO - 2023-06-11 15:32:03 --> Utf8 Class Initialized
INFO - 2023-06-11 15:32:03 --> URI Class Initialized
INFO - 2023-06-11 15:32:03 --> Router Class Initialized
INFO - 2023-06-11 15:32:03 --> Output Class Initialized
INFO - 2023-06-11 15:32:03 --> Security Class Initialized
INFO - 2023-06-11 15:32:03 --> Input Class Initialized
INFO - 2023-06-11 15:32:03 --> Language Class Initialized
INFO - 2023-06-11 15:32:03 --> Loader Class Initialized
INFO - 2023-06-11 15:32:03 --> Helper loaded: url_helper
INFO - 2023-06-11 15:32:03 --> Helper loaded: form_helper
INFO - 2023-06-11 15:32:03 --> Database Driver Class Initialized
INFO - 2023-06-11 15:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:32:03 --> Form Validation Class Initialized
INFO - 2023-06-11 15:32:03 --> Controller Class Initialized
INFO - 2023-06-11 15:32:03 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:32:03 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:32:03 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:32:03 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 638
ERROR - 2023-06-11 15:32:03 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 638
ERROR - 2023-06-11 15:32:03 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 638
ERROR - 2023-06-11 15:32:03 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 638
INFO - 2023-06-11 15:32:03 --> Final output sent to browser
INFO - 2023-06-11 15:32:10 --> Config Class Initialized
INFO - 2023-06-11 15:32:10 --> Hooks Class Initialized
INFO - 2023-06-11 15:32:10 --> Utf8 Class Initialized
INFO - 2023-06-11 15:32:10 --> URI Class Initialized
INFO - 2023-06-11 15:32:10 --> Router Class Initialized
INFO - 2023-06-11 15:32:10 --> Output Class Initialized
INFO - 2023-06-11 15:32:10 --> Security Class Initialized
INFO - 2023-06-11 15:32:10 --> Input Class Initialized
INFO - 2023-06-11 15:32:10 --> Language Class Initialized
INFO - 2023-06-11 15:32:10 --> Loader Class Initialized
INFO - 2023-06-11 15:32:10 --> Helper loaded: url_helper
INFO - 2023-06-11 15:32:10 --> Helper loaded: form_helper
INFO - 2023-06-11 15:32:10 --> Database Driver Class Initialized
INFO - 2023-06-11 15:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:32:10 --> Form Validation Class Initialized
INFO - 2023-06-11 15:32:10 --> Controller Class Initialized
INFO - 2023-06-11 15:32:10 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:32:10 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:32:10 --> Model "m_penghitungan" initialized
ERROR - 2023-06-11 15:32:10 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 638
ERROR - 2023-06-11 15:32:10 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 638
ERROR - 2023-06-11 15:32:10 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 638
ERROR - 2023-06-11 15:32:10 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 638
INFO - 2023-06-11 15:32:10 --> Final output sent to browser
INFO - 2023-06-11 15:32:22 --> Config Class Initialized
INFO - 2023-06-11 15:32:22 --> Hooks Class Initialized
INFO - 2023-06-11 15:32:22 --> Utf8 Class Initialized
INFO - 2023-06-11 15:32:22 --> URI Class Initialized
INFO - 2023-06-11 15:32:22 --> Router Class Initialized
INFO - 2023-06-11 15:32:22 --> Output Class Initialized
INFO - 2023-06-11 15:32:22 --> Security Class Initialized
INFO - 2023-06-11 15:32:22 --> Input Class Initialized
INFO - 2023-06-11 15:32:22 --> Language Class Initialized
INFO - 2023-06-11 15:32:22 --> Loader Class Initialized
INFO - 2023-06-11 15:32:22 --> Helper loaded: url_helper
INFO - 2023-06-11 15:32:22 --> Helper loaded: form_helper
INFO - 2023-06-11 15:32:22 --> Database Driver Class Initialized
INFO - 2023-06-11 15:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:32:22 --> Form Validation Class Initialized
INFO - 2023-06-11 15:32:22 --> Controller Class Initialized
INFO - 2023-06-11 15:32:22 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:32:22 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:32:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:32:22 --> Final output sent to browser
INFO - 2023-06-11 15:32:54 --> Config Class Initialized
INFO - 2023-06-11 15:32:54 --> Hooks Class Initialized
INFO - 2023-06-11 15:32:54 --> Utf8 Class Initialized
INFO - 2023-06-11 15:32:54 --> URI Class Initialized
INFO - 2023-06-11 15:32:54 --> Router Class Initialized
INFO - 2023-06-11 15:32:54 --> Output Class Initialized
INFO - 2023-06-11 15:32:54 --> Security Class Initialized
INFO - 2023-06-11 15:32:54 --> Input Class Initialized
INFO - 2023-06-11 15:32:54 --> Language Class Initialized
INFO - 2023-06-11 15:32:55 --> Loader Class Initialized
INFO - 2023-06-11 15:32:55 --> Helper loaded: url_helper
INFO - 2023-06-11 15:32:55 --> Helper loaded: form_helper
INFO - 2023-06-11 15:32:55 --> Database Driver Class Initialized
INFO - 2023-06-11 15:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:32:55 --> Form Validation Class Initialized
INFO - 2023-06-11 15:32:55 --> Controller Class Initialized
INFO - 2023-06-11 15:32:55 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:32:55 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:32:55 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:32:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:32:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:32:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:32:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:32:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:32:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:32:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:32:55 --> Final output sent to browser
INFO - 2023-06-11 15:32:58 --> Config Class Initialized
INFO - 2023-06-11 15:32:58 --> Hooks Class Initialized
INFO - 2023-06-11 15:32:58 --> Utf8 Class Initialized
INFO - 2023-06-11 15:32:58 --> URI Class Initialized
INFO - 2023-06-11 15:32:58 --> Router Class Initialized
INFO - 2023-06-11 15:32:58 --> Output Class Initialized
INFO - 2023-06-11 15:32:58 --> Security Class Initialized
INFO - 2023-06-11 15:32:58 --> Input Class Initialized
INFO - 2023-06-11 15:32:58 --> Language Class Initialized
INFO - 2023-06-11 15:32:58 --> Loader Class Initialized
INFO - 2023-06-11 15:32:58 --> Helper loaded: url_helper
INFO - 2023-06-11 15:32:58 --> Helper loaded: form_helper
INFO - 2023-06-11 15:32:58 --> Database Driver Class Initialized
INFO - 2023-06-11 15:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:32:58 --> Form Validation Class Initialized
INFO - 2023-06-11 15:32:58 --> Controller Class Initialized
INFO - 2023-06-11 15:32:58 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:32:58 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:32:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:32:58 --> Config Class Initialized
INFO - 2023-06-11 15:32:58 --> Hooks Class Initialized
INFO - 2023-06-11 15:32:58 --> Utf8 Class Initialized
INFO - 2023-06-11 15:32:58 --> URI Class Initialized
INFO - 2023-06-11 15:32:58 --> Router Class Initialized
INFO - 2023-06-11 15:32:58 --> Output Class Initialized
INFO - 2023-06-11 15:32:58 --> Security Class Initialized
INFO - 2023-06-11 15:32:58 --> Input Class Initialized
INFO - 2023-06-11 15:32:58 --> Language Class Initialized
INFO - 2023-06-11 15:32:58 --> Loader Class Initialized
INFO - 2023-06-11 15:32:58 --> Helper loaded: url_helper
INFO - 2023-06-11 15:32:58 --> Helper loaded: form_helper
INFO - 2023-06-11 15:32:58 --> Database Driver Class Initialized
INFO - 2023-06-11 15:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:32:58 --> Form Validation Class Initialized
INFO - 2023-06-11 15:32:58 --> Controller Class Initialized
INFO - 2023-06-11 15:32:58 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:32:58 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:32:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:32:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:32:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:32:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:32:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:32:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:32:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:32:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:32:58 --> Final output sent to browser
INFO - 2023-06-11 15:33:31 --> Config Class Initialized
INFO - 2023-06-11 15:33:31 --> Hooks Class Initialized
INFO - 2023-06-11 15:33:31 --> Utf8 Class Initialized
INFO - 2023-06-11 15:33:31 --> URI Class Initialized
INFO - 2023-06-11 15:33:31 --> Router Class Initialized
INFO - 2023-06-11 15:33:31 --> Output Class Initialized
INFO - 2023-06-11 15:33:31 --> Security Class Initialized
INFO - 2023-06-11 15:33:31 --> Input Class Initialized
INFO - 2023-06-11 15:33:31 --> Language Class Initialized
INFO - 2023-06-11 15:33:31 --> Loader Class Initialized
INFO - 2023-06-11 15:33:31 --> Helper loaded: url_helper
INFO - 2023-06-11 15:33:31 --> Helper loaded: form_helper
INFO - 2023-06-11 15:33:31 --> Database Driver Class Initialized
INFO - 2023-06-11 15:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:33:31 --> Form Validation Class Initialized
INFO - 2023-06-11 15:33:31 --> Controller Class Initialized
INFO - 2023-06-11 15:33:31 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:33:31 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:33:31 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:33:31 --> Config Class Initialized
INFO - 2023-06-11 15:33:31 --> Hooks Class Initialized
INFO - 2023-06-11 15:33:31 --> Utf8 Class Initialized
INFO - 2023-06-11 15:33:31 --> URI Class Initialized
INFO - 2023-06-11 15:33:31 --> Router Class Initialized
INFO - 2023-06-11 15:33:31 --> Output Class Initialized
INFO - 2023-06-11 15:33:31 --> Security Class Initialized
INFO - 2023-06-11 15:33:31 --> Input Class Initialized
INFO - 2023-06-11 15:33:31 --> Language Class Initialized
INFO - 2023-06-11 15:33:31 --> Loader Class Initialized
INFO - 2023-06-11 15:33:31 --> Helper loaded: url_helper
INFO - 2023-06-11 15:33:31 --> Helper loaded: form_helper
INFO - 2023-06-11 15:33:31 --> Database Driver Class Initialized
INFO - 2023-06-11 15:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:33:31 --> Form Validation Class Initialized
INFO - 2023-06-11 15:33:31 --> Controller Class Initialized
INFO - 2023-06-11 15:33:31 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:33:31 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:33:31 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:33:31 --> Final output sent to browser
INFO - 2023-06-11 15:35:15 --> Config Class Initialized
INFO - 2023-06-11 15:35:15 --> Hooks Class Initialized
INFO - 2023-06-11 15:35:15 --> Utf8 Class Initialized
INFO - 2023-06-11 15:35:15 --> URI Class Initialized
INFO - 2023-06-11 15:35:15 --> Router Class Initialized
INFO - 2023-06-11 15:35:15 --> Output Class Initialized
INFO - 2023-06-11 15:35:15 --> Security Class Initialized
INFO - 2023-06-11 15:35:15 --> Input Class Initialized
INFO - 2023-06-11 15:35:15 --> Language Class Initialized
INFO - 2023-06-11 15:35:15 --> Loader Class Initialized
INFO - 2023-06-11 15:35:15 --> Helper loaded: url_helper
INFO - 2023-06-11 15:35:16 --> Helper loaded: form_helper
INFO - 2023-06-11 15:35:16 --> Database Driver Class Initialized
INFO - 2023-06-11 15:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:35:16 --> Form Validation Class Initialized
INFO - 2023-06-11 15:35:16 --> Controller Class Initialized
INFO - 2023-06-11 15:35:16 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:35:16 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:35:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:35:16 --> Config Class Initialized
INFO - 2023-06-11 15:35:16 --> Hooks Class Initialized
INFO - 2023-06-11 15:35:16 --> Utf8 Class Initialized
INFO - 2023-06-11 15:35:16 --> URI Class Initialized
INFO - 2023-06-11 15:35:16 --> Router Class Initialized
INFO - 2023-06-11 15:35:16 --> Output Class Initialized
INFO - 2023-06-11 15:35:16 --> Security Class Initialized
INFO - 2023-06-11 15:35:16 --> Input Class Initialized
INFO - 2023-06-11 15:35:16 --> Language Class Initialized
INFO - 2023-06-11 15:35:16 --> Loader Class Initialized
INFO - 2023-06-11 15:35:16 --> Helper loaded: url_helper
INFO - 2023-06-11 15:35:16 --> Helper loaded: form_helper
INFO - 2023-06-11 15:35:16 --> Database Driver Class Initialized
INFO - 2023-06-11 15:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:35:16 --> Form Validation Class Initialized
INFO - 2023-06-11 15:35:16 --> Controller Class Initialized
INFO - 2023-06-11 15:35:16 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:35:16 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:35:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:35:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:35:16 --> Final output sent to browser
INFO - 2023-06-11 15:35:29 --> Config Class Initialized
INFO - 2023-06-11 15:35:29 --> Hooks Class Initialized
INFO - 2023-06-11 15:35:29 --> Utf8 Class Initialized
INFO - 2023-06-11 15:35:29 --> URI Class Initialized
INFO - 2023-06-11 15:35:29 --> Router Class Initialized
INFO - 2023-06-11 15:35:29 --> Output Class Initialized
INFO - 2023-06-11 15:35:29 --> Security Class Initialized
INFO - 2023-06-11 15:35:29 --> Input Class Initialized
INFO - 2023-06-11 15:35:29 --> Language Class Initialized
INFO - 2023-06-11 15:35:29 --> Loader Class Initialized
INFO - 2023-06-11 15:35:29 --> Helper loaded: url_helper
INFO - 2023-06-11 15:35:29 --> Helper loaded: form_helper
INFO - 2023-06-11 15:35:29 --> Database Driver Class Initialized
INFO - 2023-06-11 15:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:35:29 --> Form Validation Class Initialized
INFO - 2023-06-11 15:35:29 --> Controller Class Initialized
INFO - 2023-06-11 15:35:29 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:35:29 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:35:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:35:29 --> Final output sent to browser
INFO - 2023-06-11 15:41:07 --> Config Class Initialized
INFO - 2023-06-11 15:41:07 --> Hooks Class Initialized
INFO - 2023-06-11 15:41:07 --> Utf8 Class Initialized
INFO - 2023-06-11 15:41:07 --> URI Class Initialized
INFO - 2023-06-11 15:41:07 --> Router Class Initialized
INFO - 2023-06-11 15:41:07 --> Output Class Initialized
INFO - 2023-06-11 15:41:07 --> Security Class Initialized
INFO - 2023-06-11 15:41:07 --> Input Class Initialized
INFO - 2023-06-11 15:41:07 --> Language Class Initialized
INFO - 2023-06-11 15:41:07 --> Loader Class Initialized
INFO - 2023-06-11 15:41:07 --> Helper loaded: url_helper
INFO - 2023-06-11 15:41:07 --> Helper loaded: form_helper
INFO - 2023-06-11 15:41:07 --> Database Driver Class Initialized
INFO - 2023-06-11 15:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:41:07 --> Form Validation Class Initialized
INFO - 2023-06-11 15:41:07 --> Controller Class Initialized
INFO - 2023-06-11 15:41:07 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:41:07 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:41:07 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:41:07 --> Final output sent to browser
INFO - 2023-06-11 15:41:11 --> Config Class Initialized
INFO - 2023-06-11 15:41:11 --> Hooks Class Initialized
INFO - 2023-06-11 15:41:11 --> Utf8 Class Initialized
INFO - 2023-06-11 15:41:11 --> URI Class Initialized
INFO - 2023-06-11 15:41:11 --> Router Class Initialized
INFO - 2023-06-11 15:41:11 --> Output Class Initialized
INFO - 2023-06-11 15:41:11 --> Security Class Initialized
INFO - 2023-06-11 15:41:11 --> Input Class Initialized
INFO - 2023-06-11 15:41:11 --> Language Class Initialized
INFO - 2023-06-11 15:41:11 --> Loader Class Initialized
INFO - 2023-06-11 15:41:11 --> Helper loaded: url_helper
INFO - 2023-06-11 15:41:11 --> Helper loaded: form_helper
INFO - 2023-06-11 15:41:11 --> Database Driver Class Initialized
INFO - 2023-06-11 15:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:41:11 --> Form Validation Class Initialized
INFO - 2023-06-11 15:41:11 --> Controller Class Initialized
INFO - 2023-06-11 15:41:11 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:41:11 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:41:11 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:41:11 --> Final output sent to browser
INFO - 2023-06-11 15:41:19 --> Config Class Initialized
INFO - 2023-06-11 15:41:19 --> Hooks Class Initialized
INFO - 2023-06-11 15:41:19 --> Utf8 Class Initialized
INFO - 2023-06-11 15:41:19 --> URI Class Initialized
INFO - 2023-06-11 15:41:19 --> Router Class Initialized
INFO - 2023-06-11 15:41:19 --> Output Class Initialized
INFO - 2023-06-11 15:41:19 --> Security Class Initialized
INFO - 2023-06-11 15:41:19 --> Input Class Initialized
INFO - 2023-06-11 15:41:19 --> Language Class Initialized
INFO - 2023-06-11 15:41:19 --> Loader Class Initialized
INFO - 2023-06-11 15:41:19 --> Helper loaded: url_helper
INFO - 2023-06-11 15:41:19 --> Helper loaded: form_helper
INFO - 2023-06-11 15:41:19 --> Database Driver Class Initialized
INFO - 2023-06-11 15:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:41:19 --> Form Validation Class Initialized
INFO - 2023-06-11 15:41:19 --> Controller Class Initialized
INFO - 2023-06-11 15:41:19 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:41:19 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:41:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:41:19 --> Final output sent to browser
INFO - 2023-06-11 15:41:36 --> Config Class Initialized
INFO - 2023-06-11 15:41:36 --> Hooks Class Initialized
INFO - 2023-06-11 15:41:36 --> Utf8 Class Initialized
INFO - 2023-06-11 15:41:36 --> URI Class Initialized
INFO - 2023-06-11 15:41:36 --> Router Class Initialized
INFO - 2023-06-11 15:41:36 --> Output Class Initialized
INFO - 2023-06-11 15:41:36 --> Security Class Initialized
INFO - 2023-06-11 15:41:36 --> Input Class Initialized
INFO - 2023-06-11 15:41:36 --> Language Class Initialized
INFO - 2023-06-11 15:41:36 --> Loader Class Initialized
INFO - 2023-06-11 15:41:36 --> Helper loaded: url_helper
INFO - 2023-06-11 15:41:36 --> Helper loaded: form_helper
INFO - 2023-06-11 15:41:36 --> Database Driver Class Initialized
INFO - 2023-06-11 15:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:41:36 --> Form Validation Class Initialized
INFO - 2023-06-11 15:41:36 --> Controller Class Initialized
INFO - 2023-06-11 15:41:36 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:41:36 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:41:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:41:36 --> Final output sent to browser
INFO - 2023-06-11 15:45:29 --> Config Class Initialized
INFO - 2023-06-11 15:45:29 --> Hooks Class Initialized
INFO - 2023-06-11 15:45:29 --> Utf8 Class Initialized
INFO - 2023-06-11 15:45:29 --> URI Class Initialized
INFO - 2023-06-11 15:45:29 --> Router Class Initialized
INFO - 2023-06-11 15:45:29 --> Output Class Initialized
INFO - 2023-06-11 15:45:29 --> Security Class Initialized
INFO - 2023-06-11 15:45:29 --> Input Class Initialized
INFO - 2023-06-11 15:45:29 --> Language Class Initialized
INFO - 2023-06-11 15:45:29 --> Loader Class Initialized
INFO - 2023-06-11 15:45:29 --> Helper loaded: url_helper
INFO - 2023-06-11 15:45:29 --> Helper loaded: form_helper
INFO - 2023-06-11 15:45:29 --> Database Driver Class Initialized
INFO - 2023-06-11 15:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:45:29 --> Form Validation Class Initialized
INFO - 2023-06-11 15:45:29 --> Controller Class Initialized
INFO - 2023-06-11 15:45:29 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:45:29 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:45:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:45:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:45:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:45:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:45:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:45:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:45:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:45:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:45:30 --> Final output sent to browser
INFO - 2023-06-11 15:45:44 --> Config Class Initialized
INFO - 2023-06-11 15:45:44 --> Hooks Class Initialized
INFO - 2023-06-11 15:45:44 --> Utf8 Class Initialized
INFO - 2023-06-11 15:45:44 --> URI Class Initialized
INFO - 2023-06-11 15:45:44 --> Router Class Initialized
INFO - 2023-06-11 15:45:44 --> Output Class Initialized
INFO - 2023-06-11 15:45:44 --> Security Class Initialized
INFO - 2023-06-11 15:45:44 --> Input Class Initialized
INFO - 2023-06-11 15:45:44 --> Language Class Initialized
INFO - 2023-06-11 15:45:44 --> Loader Class Initialized
INFO - 2023-06-11 15:45:44 --> Helper loaded: url_helper
INFO - 2023-06-11 15:45:44 --> Helper loaded: form_helper
INFO - 2023-06-11 15:45:44 --> Database Driver Class Initialized
INFO - 2023-06-11 15:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:45:44 --> Form Validation Class Initialized
INFO - 2023-06-11 15:45:44 --> Controller Class Initialized
INFO - 2023-06-11 15:45:44 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:45:44 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:45:44 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:45:44 --> Config Class Initialized
INFO - 2023-06-11 15:45:44 --> Hooks Class Initialized
INFO - 2023-06-11 15:45:44 --> Utf8 Class Initialized
INFO - 2023-06-11 15:45:44 --> URI Class Initialized
INFO - 2023-06-11 15:45:44 --> Router Class Initialized
INFO - 2023-06-11 15:45:44 --> Output Class Initialized
INFO - 2023-06-11 15:45:44 --> Security Class Initialized
INFO - 2023-06-11 15:45:44 --> Input Class Initialized
INFO - 2023-06-11 15:45:45 --> Language Class Initialized
INFO - 2023-06-11 15:45:45 --> Loader Class Initialized
INFO - 2023-06-11 15:45:45 --> Helper loaded: url_helper
INFO - 2023-06-11 15:45:45 --> Helper loaded: form_helper
INFO - 2023-06-11 15:45:45 --> Database Driver Class Initialized
INFO - 2023-06-11 15:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:45:45 --> Form Validation Class Initialized
INFO - 2023-06-11 15:45:45 --> Controller Class Initialized
INFO - 2023-06-11 15:45:45 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:45:45 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:45:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:45:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:45:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:45:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:45:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:45:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:45:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:45:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:45:45 --> Final output sent to browser
INFO - 2023-06-11 15:45:48 --> Config Class Initialized
INFO - 2023-06-11 15:45:48 --> Hooks Class Initialized
INFO - 2023-06-11 15:45:48 --> Utf8 Class Initialized
INFO - 2023-06-11 15:45:48 --> URI Class Initialized
INFO - 2023-06-11 15:45:48 --> Router Class Initialized
INFO - 2023-06-11 15:45:48 --> Output Class Initialized
INFO - 2023-06-11 15:45:48 --> Security Class Initialized
INFO - 2023-06-11 15:45:48 --> Input Class Initialized
INFO - 2023-06-11 15:45:48 --> Language Class Initialized
INFO - 2023-06-11 15:45:48 --> Loader Class Initialized
INFO - 2023-06-11 15:45:48 --> Helper loaded: url_helper
INFO - 2023-06-11 15:45:48 --> Helper loaded: form_helper
INFO - 2023-06-11 15:45:48 --> Database Driver Class Initialized
INFO - 2023-06-11 15:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:45:48 --> Form Validation Class Initialized
INFO - 2023-06-11 15:45:48 --> Controller Class Initialized
INFO - 2023-06-11 15:45:48 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 15:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:45:48 --> Final output sent to browser
INFO - 2023-06-11 15:52:38 --> Config Class Initialized
INFO - 2023-06-11 15:52:38 --> Hooks Class Initialized
INFO - 2023-06-11 15:52:38 --> Utf8 Class Initialized
INFO - 2023-06-11 15:52:38 --> URI Class Initialized
INFO - 2023-06-11 15:52:38 --> Router Class Initialized
INFO - 2023-06-11 15:52:38 --> Output Class Initialized
INFO - 2023-06-11 15:52:38 --> Security Class Initialized
INFO - 2023-06-11 15:52:39 --> Input Class Initialized
INFO - 2023-06-11 15:52:39 --> Language Class Initialized
INFO - 2023-06-11 15:52:39 --> Loader Class Initialized
INFO - 2023-06-11 15:52:39 --> Helper loaded: url_helper
INFO - 2023-06-11 15:52:39 --> Helper loaded: form_helper
INFO - 2023-06-11 15:52:39 --> Database Driver Class Initialized
INFO - 2023-06-11 15:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:52:39 --> Form Validation Class Initialized
INFO - 2023-06-11 15:52:39 --> Controller Class Initialized
INFO - 2023-06-11 15:52:39 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:52:39 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:52:39 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:52:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:52:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:52:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:52:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:52:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:52:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:52:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:52:39 --> Final output sent to browser
INFO - 2023-06-11 15:52:40 --> Config Class Initialized
INFO - 2023-06-11 15:52:40 --> Hooks Class Initialized
INFO - 2023-06-11 15:52:40 --> Utf8 Class Initialized
INFO - 2023-06-11 15:52:40 --> URI Class Initialized
INFO - 2023-06-11 15:52:40 --> Router Class Initialized
INFO - 2023-06-11 15:52:40 --> Output Class Initialized
INFO - 2023-06-11 15:52:40 --> Security Class Initialized
INFO - 2023-06-11 15:52:40 --> Input Class Initialized
INFO - 2023-06-11 15:52:40 --> Language Class Initialized
INFO - 2023-06-11 15:52:40 --> Loader Class Initialized
INFO - 2023-06-11 15:52:40 --> Helper loaded: url_helper
INFO - 2023-06-11 15:52:40 --> Helper loaded: form_helper
INFO - 2023-06-11 15:52:40 --> Database Driver Class Initialized
INFO - 2023-06-11 15:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:52:40 --> Form Validation Class Initialized
INFO - 2023-06-11 15:52:40 --> Controller Class Initialized
INFO - 2023-06-11 15:52:40 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:52:40 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:52:40 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:52:40 --> Final output sent to browser
INFO - 2023-06-11 15:52:47 --> Config Class Initialized
INFO - 2023-06-11 15:52:47 --> Hooks Class Initialized
INFO - 2023-06-11 15:52:47 --> Utf8 Class Initialized
INFO - 2023-06-11 15:52:47 --> URI Class Initialized
INFO - 2023-06-11 15:52:47 --> Router Class Initialized
INFO - 2023-06-11 15:52:47 --> Output Class Initialized
INFO - 2023-06-11 15:52:47 --> Security Class Initialized
INFO - 2023-06-11 15:52:47 --> Input Class Initialized
INFO - 2023-06-11 15:52:47 --> Language Class Initialized
INFO - 2023-06-11 15:52:47 --> Loader Class Initialized
INFO - 2023-06-11 15:52:47 --> Helper loaded: url_helper
INFO - 2023-06-11 15:52:47 --> Helper loaded: form_helper
INFO - 2023-06-11 15:52:47 --> Database Driver Class Initialized
INFO - 2023-06-11 15:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:52:47 --> Form Validation Class Initialized
INFO - 2023-06-11 15:52:47 --> Controller Class Initialized
INFO - 2023-06-11 15:52:47 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:52:47 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:52:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:52:47 --> Config Class Initialized
INFO - 2023-06-11 15:52:47 --> Hooks Class Initialized
INFO - 2023-06-11 15:52:47 --> Utf8 Class Initialized
INFO - 2023-06-11 15:52:47 --> URI Class Initialized
INFO - 2023-06-11 15:52:47 --> Router Class Initialized
INFO - 2023-06-11 15:52:47 --> Output Class Initialized
INFO - 2023-06-11 15:52:47 --> Security Class Initialized
INFO - 2023-06-11 15:52:47 --> Input Class Initialized
INFO - 2023-06-11 15:52:47 --> Language Class Initialized
INFO - 2023-06-11 15:52:47 --> Loader Class Initialized
INFO - 2023-06-11 15:52:47 --> Helper loaded: url_helper
INFO - 2023-06-11 15:52:47 --> Helper loaded: form_helper
INFO - 2023-06-11 15:52:47 --> Database Driver Class Initialized
INFO - 2023-06-11 15:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:52:47 --> Form Validation Class Initialized
INFO - 2023-06-11 15:52:47 --> Controller Class Initialized
INFO - 2023-06-11 15:52:47 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:52:47 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:52:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:52:47 --> Final output sent to browser
INFO - 2023-06-11 15:53:31 --> Config Class Initialized
INFO - 2023-06-11 15:53:31 --> Hooks Class Initialized
INFO - 2023-06-11 15:53:31 --> Utf8 Class Initialized
INFO - 2023-06-11 15:53:31 --> URI Class Initialized
INFO - 2023-06-11 15:53:31 --> Router Class Initialized
INFO - 2023-06-11 15:53:31 --> Output Class Initialized
INFO - 2023-06-11 15:53:31 --> Security Class Initialized
INFO - 2023-06-11 15:53:31 --> Input Class Initialized
INFO - 2023-06-11 15:53:31 --> Language Class Initialized
INFO - 2023-06-11 15:53:31 --> Loader Class Initialized
INFO - 2023-06-11 15:53:31 --> Helper loaded: url_helper
INFO - 2023-06-11 15:53:31 --> Helper loaded: form_helper
INFO - 2023-06-11 15:53:31 --> Database Driver Class Initialized
INFO - 2023-06-11 15:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:53:31 --> Form Validation Class Initialized
INFO - 2023-06-11 15:53:31 --> Controller Class Initialized
INFO - 2023-06-11 15:53:31 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:53:31 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:53:31 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:53:31 --> Config Class Initialized
INFO - 2023-06-11 15:53:31 --> Hooks Class Initialized
INFO - 2023-06-11 15:53:31 --> Utf8 Class Initialized
INFO - 2023-06-11 15:53:31 --> URI Class Initialized
INFO - 2023-06-11 15:53:31 --> Router Class Initialized
INFO - 2023-06-11 15:53:31 --> Output Class Initialized
INFO - 2023-06-11 15:53:31 --> Security Class Initialized
INFO - 2023-06-11 15:53:31 --> Input Class Initialized
INFO - 2023-06-11 15:53:31 --> Language Class Initialized
INFO - 2023-06-11 15:53:31 --> Loader Class Initialized
INFO - 2023-06-11 15:53:31 --> Helper loaded: url_helper
INFO - 2023-06-11 15:53:31 --> Helper loaded: form_helper
INFO - 2023-06-11 15:53:31 --> Database Driver Class Initialized
INFO - 2023-06-11 15:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:53:31 --> Form Validation Class Initialized
INFO - 2023-06-11 15:53:31 --> Controller Class Initialized
INFO - 2023-06-11 15:53:31 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:53:31 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:53:31 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:53:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:53:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:53:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:53:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:53:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:53:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:53:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:53:31 --> Final output sent to browser
INFO - 2023-06-11 15:53:49 --> Config Class Initialized
INFO - 2023-06-11 15:53:49 --> Hooks Class Initialized
INFO - 2023-06-11 15:53:49 --> Utf8 Class Initialized
INFO - 2023-06-11 15:53:49 --> URI Class Initialized
INFO - 2023-06-11 15:53:49 --> Router Class Initialized
INFO - 2023-06-11 15:53:49 --> Output Class Initialized
INFO - 2023-06-11 15:53:49 --> Security Class Initialized
INFO - 2023-06-11 15:53:49 --> Input Class Initialized
INFO - 2023-06-11 15:53:49 --> Language Class Initialized
INFO - 2023-06-11 15:53:49 --> Loader Class Initialized
INFO - 2023-06-11 15:53:49 --> Helper loaded: url_helper
INFO - 2023-06-11 15:53:50 --> Helper loaded: form_helper
INFO - 2023-06-11 15:53:50 --> Database Driver Class Initialized
INFO - 2023-06-11 15:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:53:50 --> Form Validation Class Initialized
INFO - 2023-06-11 15:53:50 --> Controller Class Initialized
INFO - 2023-06-11 15:53:50 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:53:50 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:53:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:53:50 --> Config Class Initialized
INFO - 2023-06-11 15:53:50 --> Hooks Class Initialized
INFO - 2023-06-11 15:53:50 --> Utf8 Class Initialized
INFO - 2023-06-11 15:53:50 --> URI Class Initialized
INFO - 2023-06-11 15:53:50 --> Router Class Initialized
INFO - 2023-06-11 15:53:50 --> Output Class Initialized
INFO - 2023-06-11 15:53:50 --> Security Class Initialized
INFO - 2023-06-11 15:53:50 --> Input Class Initialized
INFO - 2023-06-11 15:53:50 --> Language Class Initialized
INFO - 2023-06-11 15:53:50 --> Loader Class Initialized
INFO - 2023-06-11 15:53:50 --> Helper loaded: url_helper
INFO - 2023-06-11 15:53:50 --> Helper loaded: form_helper
INFO - 2023-06-11 15:53:50 --> Database Driver Class Initialized
INFO - 2023-06-11 15:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:53:50 --> Form Validation Class Initialized
INFO - 2023-06-11 15:53:50 --> Controller Class Initialized
INFO - 2023-06-11 15:53:50 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:53:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:53:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:53:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 15:53:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:53:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:53:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:53:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:53:50 --> Final output sent to browser
INFO - 2023-06-11 15:54:23 --> Config Class Initialized
INFO - 2023-06-11 15:54:23 --> Hooks Class Initialized
INFO - 2023-06-11 15:54:23 --> Utf8 Class Initialized
INFO - 2023-06-11 15:54:23 --> URI Class Initialized
INFO - 2023-06-11 15:54:23 --> Router Class Initialized
INFO - 2023-06-11 15:54:23 --> Output Class Initialized
INFO - 2023-06-11 15:54:23 --> Security Class Initialized
INFO - 2023-06-11 15:54:23 --> Input Class Initialized
INFO - 2023-06-11 15:54:23 --> Language Class Initialized
INFO - 2023-06-11 15:54:23 --> Loader Class Initialized
INFO - 2023-06-11 15:54:23 --> Helper loaded: url_helper
INFO - 2023-06-11 15:54:23 --> Helper loaded: form_helper
INFO - 2023-06-11 15:54:23 --> Database Driver Class Initialized
INFO - 2023-06-11 15:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:54:23 --> Form Validation Class Initialized
INFO - 2023-06-11 15:54:23 --> Controller Class Initialized
INFO - 2023-06-11 15:54:23 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 15:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:54:23 --> Final output sent to browser
INFO - 2023-06-11 15:54:25 --> Config Class Initialized
INFO - 2023-06-11 15:54:25 --> Hooks Class Initialized
INFO - 2023-06-11 15:54:25 --> Utf8 Class Initialized
INFO - 2023-06-11 15:54:25 --> URI Class Initialized
INFO - 2023-06-11 15:54:25 --> Router Class Initialized
INFO - 2023-06-11 15:54:25 --> Output Class Initialized
INFO - 2023-06-11 15:54:25 --> Security Class Initialized
INFO - 2023-06-11 15:54:25 --> Input Class Initialized
INFO - 2023-06-11 15:54:25 --> Language Class Initialized
INFO - 2023-06-11 15:54:25 --> Loader Class Initialized
INFO - 2023-06-11 15:54:25 --> Helper loaded: url_helper
INFO - 2023-06-11 15:54:25 --> Helper loaded: form_helper
INFO - 2023-06-11 15:54:25 --> Database Driver Class Initialized
INFO - 2023-06-11 15:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:54:25 --> Form Validation Class Initialized
INFO - 2023-06-11 15:54:25 --> Controller Class Initialized
INFO - 2023-06-11 15:54:25 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:54:25 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:54:25 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:54:25 --> Final output sent to browser
INFO - 2023-06-11 15:54:29 --> Config Class Initialized
INFO - 2023-06-11 15:54:29 --> Hooks Class Initialized
INFO - 2023-06-11 15:54:29 --> Utf8 Class Initialized
INFO - 2023-06-11 15:54:29 --> URI Class Initialized
INFO - 2023-06-11 15:54:29 --> Router Class Initialized
INFO - 2023-06-11 15:54:29 --> Output Class Initialized
INFO - 2023-06-11 15:54:29 --> Security Class Initialized
INFO - 2023-06-11 15:54:29 --> Input Class Initialized
INFO - 2023-06-11 15:54:29 --> Language Class Initialized
INFO - 2023-06-11 15:54:29 --> Loader Class Initialized
INFO - 2023-06-11 15:54:29 --> Helper loaded: url_helper
INFO - 2023-06-11 15:54:29 --> Helper loaded: form_helper
INFO - 2023-06-11 15:54:29 --> Database Driver Class Initialized
INFO - 2023-06-11 15:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:54:29 --> Form Validation Class Initialized
INFO - 2023-06-11 15:54:29 --> Controller Class Initialized
INFO - 2023-06-11 15:54:29 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:54:29 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:54:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:54:29 --> Final output sent to browser
INFO - 2023-06-11 15:54:37 --> Config Class Initialized
INFO - 2023-06-11 15:54:37 --> Hooks Class Initialized
INFO - 2023-06-11 15:54:37 --> Utf8 Class Initialized
INFO - 2023-06-11 15:54:37 --> URI Class Initialized
INFO - 2023-06-11 15:54:37 --> Router Class Initialized
INFO - 2023-06-11 15:54:37 --> Output Class Initialized
INFO - 2023-06-11 15:54:37 --> Security Class Initialized
INFO - 2023-06-11 15:54:37 --> Input Class Initialized
INFO - 2023-06-11 15:54:37 --> Language Class Initialized
INFO - 2023-06-11 15:54:37 --> Loader Class Initialized
INFO - 2023-06-11 15:54:37 --> Helper loaded: url_helper
INFO - 2023-06-11 15:54:37 --> Helper loaded: form_helper
INFO - 2023-06-11 15:54:37 --> Database Driver Class Initialized
INFO - 2023-06-11 15:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:54:37 --> Form Validation Class Initialized
INFO - 2023-06-11 15:54:37 --> Controller Class Initialized
INFO - 2023-06-11 15:54:37 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:54:37 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:54:37 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:54:37 --> Config Class Initialized
INFO - 2023-06-11 15:54:37 --> Hooks Class Initialized
INFO - 2023-06-11 15:54:37 --> Utf8 Class Initialized
INFO - 2023-06-11 15:54:37 --> URI Class Initialized
INFO - 2023-06-11 15:54:37 --> Router Class Initialized
INFO - 2023-06-11 15:54:37 --> Output Class Initialized
INFO - 2023-06-11 15:54:37 --> Security Class Initialized
INFO - 2023-06-11 15:54:37 --> Input Class Initialized
INFO - 2023-06-11 15:54:37 --> Language Class Initialized
INFO - 2023-06-11 15:54:37 --> Loader Class Initialized
INFO - 2023-06-11 15:54:37 --> Helper loaded: url_helper
INFO - 2023-06-11 15:54:37 --> Helper loaded: form_helper
INFO - 2023-06-11 15:54:37 --> Database Driver Class Initialized
INFO - 2023-06-11 15:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:54:37 --> Form Validation Class Initialized
INFO - 2023-06-11 15:54:37 --> Controller Class Initialized
INFO - 2023-06-11 15:54:37 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:54:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:54:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:54:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 15:54:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:54:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:54:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:54:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:54:38 --> Final output sent to browser
INFO - 2023-06-11 15:56:49 --> Config Class Initialized
INFO - 2023-06-11 15:56:49 --> Hooks Class Initialized
INFO - 2023-06-11 15:56:49 --> Utf8 Class Initialized
INFO - 2023-06-11 15:56:49 --> URI Class Initialized
INFO - 2023-06-11 15:56:49 --> Router Class Initialized
INFO - 2023-06-11 15:56:49 --> Output Class Initialized
INFO - 2023-06-11 15:56:49 --> Security Class Initialized
INFO - 2023-06-11 15:56:49 --> Input Class Initialized
INFO - 2023-06-11 15:56:49 --> Language Class Initialized
INFO - 2023-06-11 15:56:49 --> Loader Class Initialized
INFO - 2023-06-11 15:56:49 --> Helper loaded: url_helper
INFO - 2023-06-11 15:56:49 --> Helper loaded: form_helper
INFO - 2023-06-11 15:56:49 --> Database Driver Class Initialized
INFO - 2023-06-11 15:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:56:49 --> Form Validation Class Initialized
INFO - 2023-06-11 15:56:49 --> Controller Class Initialized
INFO - 2023-06-11 15:56:49 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:56:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:56:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:56:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 15:56:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:56:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:56:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:56:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:56:49 --> Final output sent to browser
INFO - 2023-06-11 15:56:54 --> Config Class Initialized
INFO - 2023-06-11 15:56:54 --> Hooks Class Initialized
INFO - 2023-06-11 15:56:54 --> Utf8 Class Initialized
INFO - 2023-06-11 15:56:54 --> URI Class Initialized
INFO - 2023-06-11 15:56:54 --> Router Class Initialized
INFO - 2023-06-11 15:56:54 --> Output Class Initialized
INFO - 2023-06-11 15:56:54 --> Security Class Initialized
INFO - 2023-06-11 15:56:54 --> Input Class Initialized
INFO - 2023-06-11 15:56:54 --> Language Class Initialized
INFO - 2023-06-11 15:56:54 --> Loader Class Initialized
INFO - 2023-06-11 15:56:54 --> Helper loaded: url_helper
INFO - 2023-06-11 15:56:54 --> Helper loaded: form_helper
INFO - 2023-06-11 15:56:54 --> Database Driver Class Initialized
INFO - 2023-06-11 15:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:56:54 --> Form Validation Class Initialized
INFO - 2023-06-11 15:56:54 --> Controller Class Initialized
INFO - 2023-06-11 15:56:54 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:56:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:56:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:56:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 15:56:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:56:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:56:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:56:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:56:54 --> Final output sent to browser
INFO - 2023-06-11 15:56:55 --> Config Class Initialized
INFO - 2023-06-11 15:56:55 --> Hooks Class Initialized
INFO - 2023-06-11 15:56:55 --> Utf8 Class Initialized
INFO - 2023-06-11 15:56:55 --> URI Class Initialized
INFO - 2023-06-11 15:56:55 --> Router Class Initialized
INFO - 2023-06-11 15:56:55 --> Output Class Initialized
INFO - 2023-06-11 15:56:55 --> Security Class Initialized
INFO - 2023-06-11 15:56:55 --> Input Class Initialized
INFO - 2023-06-11 15:56:55 --> Language Class Initialized
INFO - 2023-06-11 15:56:55 --> Loader Class Initialized
INFO - 2023-06-11 15:56:55 --> Helper loaded: url_helper
INFO - 2023-06-11 15:56:55 --> Helper loaded: form_helper
INFO - 2023-06-11 15:56:55 --> Database Driver Class Initialized
INFO - 2023-06-11 15:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:56:55 --> Form Validation Class Initialized
INFO - 2023-06-11 15:56:55 --> Controller Class Initialized
INFO - 2023-06-11 15:56:55 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:56:55 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:56:55 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:56:55 --> Final output sent to browser
INFO - 2023-06-11 15:57:36 --> Config Class Initialized
INFO - 2023-06-11 15:57:36 --> Hooks Class Initialized
INFO - 2023-06-11 15:57:36 --> Utf8 Class Initialized
INFO - 2023-06-11 15:57:36 --> URI Class Initialized
INFO - 2023-06-11 15:57:36 --> Router Class Initialized
INFO - 2023-06-11 15:57:36 --> Output Class Initialized
INFO - 2023-06-11 15:57:36 --> Security Class Initialized
INFO - 2023-06-11 15:57:36 --> Input Class Initialized
INFO - 2023-06-11 15:57:36 --> Language Class Initialized
INFO - 2023-06-11 15:57:36 --> Loader Class Initialized
INFO - 2023-06-11 15:57:36 --> Helper loaded: url_helper
INFO - 2023-06-11 15:57:36 --> Helper loaded: form_helper
INFO - 2023-06-11 15:57:36 --> Database Driver Class Initialized
INFO - 2023-06-11 15:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:57:36 --> Form Validation Class Initialized
INFO - 2023-06-11 15:57:36 --> Controller Class Initialized
INFO - 2023-06-11 15:57:36 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:57:36 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:57:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:57:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:57:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:57:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:57:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:57:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:57:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:57:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:57:37 --> Final output sent to browser
INFO - 2023-06-11 15:58:15 --> Config Class Initialized
INFO - 2023-06-11 15:58:15 --> Hooks Class Initialized
INFO - 2023-06-11 15:58:15 --> Utf8 Class Initialized
INFO - 2023-06-11 15:58:15 --> URI Class Initialized
INFO - 2023-06-11 15:58:15 --> Router Class Initialized
INFO - 2023-06-11 15:58:15 --> Output Class Initialized
INFO - 2023-06-11 15:58:15 --> Security Class Initialized
INFO - 2023-06-11 15:58:15 --> Input Class Initialized
INFO - 2023-06-11 15:58:15 --> Language Class Initialized
INFO - 2023-06-11 15:58:15 --> Loader Class Initialized
INFO - 2023-06-11 15:58:15 --> Helper loaded: url_helper
INFO - 2023-06-11 15:58:15 --> Helper loaded: form_helper
INFO - 2023-06-11 15:58:15 --> Database Driver Class Initialized
INFO - 2023-06-11 15:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:58:15 --> Form Validation Class Initialized
INFO - 2023-06-11 15:58:15 --> Controller Class Initialized
INFO - 2023-06-11 15:58:15 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:58:15 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:58:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:58:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:58:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:58:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:58:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:58:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:58:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:58:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:58:15 --> Final output sent to browser
INFO - 2023-06-11 15:58:51 --> Config Class Initialized
INFO - 2023-06-11 15:58:51 --> Hooks Class Initialized
INFO - 2023-06-11 15:58:51 --> Utf8 Class Initialized
INFO - 2023-06-11 15:58:51 --> URI Class Initialized
INFO - 2023-06-11 15:58:51 --> Router Class Initialized
INFO - 2023-06-11 15:58:51 --> Output Class Initialized
INFO - 2023-06-11 15:58:51 --> Security Class Initialized
INFO - 2023-06-11 15:58:51 --> Input Class Initialized
INFO - 2023-06-11 15:58:51 --> Language Class Initialized
INFO - 2023-06-11 15:58:51 --> Loader Class Initialized
INFO - 2023-06-11 15:58:51 --> Helper loaded: url_helper
INFO - 2023-06-11 15:58:51 --> Helper loaded: form_helper
INFO - 2023-06-11 15:58:51 --> Database Driver Class Initialized
INFO - 2023-06-11 15:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:58:51 --> Form Validation Class Initialized
INFO - 2023-06-11 15:58:51 --> Controller Class Initialized
INFO - 2023-06-11 15:58:51 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:58:51 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:58:51 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:58:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:58:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:58:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:58:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:58:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:58:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:58:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:58:51 --> Final output sent to browser
INFO - 2023-06-11 15:59:00 --> Config Class Initialized
INFO - 2023-06-11 15:59:00 --> Hooks Class Initialized
INFO - 2023-06-11 15:59:00 --> Utf8 Class Initialized
INFO - 2023-06-11 15:59:00 --> URI Class Initialized
INFO - 2023-06-11 15:59:00 --> Router Class Initialized
INFO - 2023-06-11 15:59:00 --> Output Class Initialized
INFO - 2023-06-11 15:59:00 --> Security Class Initialized
INFO - 2023-06-11 15:59:00 --> Input Class Initialized
INFO - 2023-06-11 15:59:00 --> Language Class Initialized
INFO - 2023-06-11 15:59:00 --> Loader Class Initialized
INFO - 2023-06-11 15:59:00 --> Helper loaded: url_helper
INFO - 2023-06-11 15:59:00 --> Helper loaded: form_helper
INFO - 2023-06-11 15:59:00 --> Database Driver Class Initialized
INFO - 2023-06-11 15:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:59:00 --> Form Validation Class Initialized
INFO - 2023-06-11 15:59:00 --> Controller Class Initialized
INFO - 2023-06-11 15:59:00 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:59:00 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:59:00 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:59:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:59:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:59:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-11 15:59:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:59:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:59:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:59:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:59:01 --> Final output sent to browser
INFO - 2023-06-11 15:59:11 --> Config Class Initialized
INFO - 2023-06-11 15:59:11 --> Hooks Class Initialized
INFO - 2023-06-11 15:59:11 --> Utf8 Class Initialized
INFO - 2023-06-11 15:59:11 --> URI Class Initialized
INFO - 2023-06-11 15:59:11 --> Router Class Initialized
INFO - 2023-06-11 15:59:11 --> Output Class Initialized
INFO - 2023-06-11 15:59:11 --> Security Class Initialized
INFO - 2023-06-11 15:59:11 --> Input Class Initialized
INFO - 2023-06-11 15:59:11 --> Language Class Initialized
INFO - 2023-06-11 15:59:11 --> Loader Class Initialized
INFO - 2023-06-11 15:59:11 --> Helper loaded: url_helper
INFO - 2023-06-11 15:59:11 --> Helper loaded: form_helper
INFO - 2023-06-11 15:59:11 --> Database Driver Class Initialized
INFO - 2023-06-11 15:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:59:11 --> Form Validation Class Initialized
INFO - 2023-06-11 15:59:11 --> Controller Class Initialized
INFO - 2023-06-11 15:59:11 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:59:11 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:59:11 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:59:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:59:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:59:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:59:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:59:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:59:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:59:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:59:11 --> Final output sent to browser
INFO - 2023-06-11 15:59:34 --> Config Class Initialized
INFO - 2023-06-11 15:59:34 --> Hooks Class Initialized
INFO - 2023-06-11 15:59:34 --> Utf8 Class Initialized
INFO - 2023-06-11 15:59:34 --> URI Class Initialized
INFO - 2023-06-11 15:59:34 --> Router Class Initialized
INFO - 2023-06-11 15:59:34 --> Output Class Initialized
INFO - 2023-06-11 15:59:34 --> Security Class Initialized
INFO - 2023-06-11 15:59:34 --> Input Class Initialized
INFO - 2023-06-11 15:59:34 --> Language Class Initialized
INFO - 2023-06-11 15:59:34 --> Loader Class Initialized
INFO - 2023-06-11 15:59:34 --> Helper loaded: url_helper
INFO - 2023-06-11 15:59:34 --> Helper loaded: form_helper
INFO - 2023-06-11 15:59:34 --> Database Driver Class Initialized
INFO - 2023-06-11 15:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:59:34 --> Form Validation Class Initialized
INFO - 2023-06-11 15:59:34 --> Controller Class Initialized
INFO - 2023-06-11 15:59:34 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:59:34 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:59:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:59:34 --> Final output sent to browser
INFO - 2023-06-11 15:59:43 --> Config Class Initialized
INFO - 2023-06-11 15:59:43 --> Hooks Class Initialized
INFO - 2023-06-11 15:59:43 --> Utf8 Class Initialized
INFO - 2023-06-11 15:59:43 --> URI Class Initialized
INFO - 2023-06-11 15:59:43 --> Router Class Initialized
INFO - 2023-06-11 15:59:43 --> Output Class Initialized
INFO - 2023-06-11 15:59:43 --> Security Class Initialized
INFO - 2023-06-11 15:59:43 --> Input Class Initialized
INFO - 2023-06-11 15:59:43 --> Language Class Initialized
INFO - 2023-06-11 15:59:43 --> Loader Class Initialized
INFO - 2023-06-11 15:59:43 --> Helper loaded: url_helper
INFO - 2023-06-11 15:59:43 --> Helper loaded: form_helper
INFO - 2023-06-11 15:59:43 --> Database Driver Class Initialized
INFO - 2023-06-11 15:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:59:43 --> Form Validation Class Initialized
INFO - 2023-06-11 15:59:43 --> Controller Class Initialized
INFO - 2023-06-11 15:59:43 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:59:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:59:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:59:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 15:59:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:59:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:59:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:59:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:59:43 --> Final output sent to browser
INFO - 2023-06-11 15:59:48 --> Config Class Initialized
INFO - 2023-06-11 15:59:48 --> Hooks Class Initialized
INFO - 2023-06-11 15:59:48 --> Utf8 Class Initialized
INFO - 2023-06-11 15:59:48 --> URI Class Initialized
INFO - 2023-06-11 15:59:48 --> Router Class Initialized
INFO - 2023-06-11 15:59:48 --> Output Class Initialized
INFO - 2023-06-11 15:59:48 --> Security Class Initialized
INFO - 2023-06-11 15:59:48 --> Input Class Initialized
INFO - 2023-06-11 15:59:48 --> Language Class Initialized
INFO - 2023-06-11 15:59:48 --> Loader Class Initialized
INFO - 2023-06-11 15:59:48 --> Helper loaded: url_helper
INFO - 2023-06-11 15:59:48 --> Helper loaded: form_helper
INFO - 2023-06-11 15:59:48 --> Database Driver Class Initialized
INFO - 2023-06-11 15:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:59:48 --> Form Validation Class Initialized
INFO - 2023-06-11 15:59:48 --> Controller Class Initialized
INFO - 2023-06-11 15:59:48 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:59:48 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:59:48 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:59:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:59:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:59:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:59:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:59:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:59:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:59:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:59:48 --> Final output sent to browser
INFO - 2023-06-11 15:59:49 --> Config Class Initialized
INFO - 2023-06-11 15:59:49 --> Hooks Class Initialized
INFO - 2023-06-11 15:59:49 --> Utf8 Class Initialized
INFO - 2023-06-11 15:59:49 --> URI Class Initialized
INFO - 2023-06-11 15:59:49 --> Router Class Initialized
INFO - 2023-06-11 15:59:49 --> Output Class Initialized
INFO - 2023-06-11 15:59:49 --> Security Class Initialized
INFO - 2023-06-11 15:59:49 --> Input Class Initialized
INFO - 2023-06-11 15:59:49 --> Language Class Initialized
INFO - 2023-06-11 15:59:49 --> Loader Class Initialized
INFO - 2023-06-11 15:59:49 --> Helper loaded: url_helper
INFO - 2023-06-11 15:59:49 --> Helper loaded: form_helper
INFO - 2023-06-11 15:59:49 --> Database Driver Class Initialized
INFO - 2023-06-11 15:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:59:49 --> Form Validation Class Initialized
INFO - 2023-06-11 15:59:49 --> Controller Class Initialized
INFO - 2023-06-11 15:59:49 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:59:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:59:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:59:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 15:59:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:59:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:59:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:59:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:59:50 --> Final output sent to browser
INFO - 2023-06-11 15:59:52 --> Config Class Initialized
INFO - 2023-06-11 15:59:52 --> Hooks Class Initialized
INFO - 2023-06-11 15:59:52 --> Utf8 Class Initialized
INFO - 2023-06-11 15:59:52 --> URI Class Initialized
INFO - 2023-06-11 15:59:52 --> Router Class Initialized
INFO - 2023-06-11 15:59:52 --> Output Class Initialized
INFO - 2023-06-11 15:59:52 --> Security Class Initialized
INFO - 2023-06-11 15:59:52 --> Input Class Initialized
INFO - 2023-06-11 15:59:52 --> Language Class Initialized
INFO - 2023-06-11 15:59:52 --> Loader Class Initialized
INFO - 2023-06-11 15:59:52 --> Helper loaded: url_helper
INFO - 2023-06-11 15:59:52 --> Helper loaded: form_helper
INFO - 2023-06-11 15:59:52 --> Database Driver Class Initialized
INFO - 2023-06-11 15:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:59:52 --> Form Validation Class Initialized
INFO - 2023-06-11 15:59:52 --> Controller Class Initialized
INFO - 2023-06-11 15:59:52 --> Model "m_datatest" initialized
INFO - 2023-06-11 15:59:52 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:59:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 15:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 15:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:59:52 --> Final output sent to browser
INFO - 2023-06-11 15:59:59 --> Config Class Initialized
INFO - 2023-06-11 15:59:59 --> Hooks Class Initialized
INFO - 2023-06-11 15:59:59 --> Utf8 Class Initialized
INFO - 2023-06-11 15:59:59 --> URI Class Initialized
INFO - 2023-06-11 15:59:59 --> Router Class Initialized
INFO - 2023-06-11 15:59:59 --> Output Class Initialized
INFO - 2023-06-11 15:59:59 --> Security Class Initialized
INFO - 2023-06-11 15:59:59 --> Input Class Initialized
INFO - 2023-06-11 15:59:59 --> Language Class Initialized
INFO - 2023-06-11 15:59:59 --> Loader Class Initialized
INFO - 2023-06-11 15:59:59 --> Helper loaded: url_helper
INFO - 2023-06-11 15:59:59 --> Helper loaded: form_helper
INFO - 2023-06-11 15:59:59 --> Database Driver Class Initialized
INFO - 2023-06-11 15:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 15:59:59 --> Form Validation Class Initialized
INFO - 2023-06-11 15:59:59 --> Controller Class Initialized
INFO - 2023-06-11 15:59:59 --> Model "m_datatrain" initialized
INFO - 2023-06-11 15:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 15:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 15:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 15:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 15:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 15:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 15:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 15:59:59 --> Final output sent to browser
INFO - 2023-06-11 16:00:04 --> Config Class Initialized
INFO - 2023-06-11 16:00:04 --> Hooks Class Initialized
INFO - 2023-06-11 16:00:04 --> Utf8 Class Initialized
INFO - 2023-06-11 16:00:04 --> URI Class Initialized
INFO - 2023-06-11 16:00:04 --> Router Class Initialized
INFO - 2023-06-11 16:00:04 --> Output Class Initialized
INFO - 2023-06-11 16:00:04 --> Security Class Initialized
INFO - 2023-06-11 16:00:04 --> Input Class Initialized
INFO - 2023-06-11 16:00:04 --> Language Class Initialized
INFO - 2023-06-11 16:00:04 --> Loader Class Initialized
INFO - 2023-06-11 16:00:04 --> Helper loaded: url_helper
INFO - 2023-06-11 16:00:04 --> Helper loaded: form_helper
INFO - 2023-06-11 16:00:04 --> Database Driver Class Initialized
INFO - 2023-06-11 16:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:00:04 --> Form Validation Class Initialized
INFO - 2023-06-11 16:00:04 --> Controller Class Initialized
INFO - 2023-06-11 16:00:04 --> Model "m_datatest" initialized
INFO - 2023-06-11 16:00:04 --> Model "m_datatrain" initialized
INFO - 2023-06-11 16:00:04 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 16:00:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:00:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:00:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 16:00:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:00:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:00:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:00:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:00:04 --> Final output sent to browser
INFO - 2023-06-11 16:01:23 --> Config Class Initialized
INFO - 2023-06-11 16:01:23 --> Hooks Class Initialized
INFO - 2023-06-11 16:01:23 --> Utf8 Class Initialized
INFO - 2023-06-11 16:01:23 --> URI Class Initialized
INFO - 2023-06-11 16:01:23 --> Router Class Initialized
INFO - 2023-06-11 16:01:23 --> Output Class Initialized
INFO - 2023-06-11 16:01:23 --> Security Class Initialized
INFO - 2023-06-11 16:01:23 --> Input Class Initialized
INFO - 2023-06-11 16:01:23 --> Language Class Initialized
INFO - 2023-06-11 16:01:23 --> Loader Class Initialized
INFO - 2023-06-11 16:01:23 --> Helper loaded: url_helper
INFO - 2023-06-11 16:01:23 --> Helper loaded: form_helper
INFO - 2023-06-11 16:01:23 --> Database Driver Class Initialized
INFO - 2023-06-11 16:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:01:23 --> Form Validation Class Initialized
INFO - 2023-06-11 16:01:23 --> Controller Class Initialized
INFO - 2023-06-11 16:01:23 --> Model "m_datatrain" initialized
INFO - 2023-06-11 16:01:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:01:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:01:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 16:01:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:01:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:01:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:01:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:01:23 --> Final output sent to browser
INFO - 2023-06-11 16:01:24 --> Config Class Initialized
INFO - 2023-06-11 16:01:24 --> Hooks Class Initialized
INFO - 2023-06-11 16:01:24 --> Utf8 Class Initialized
INFO - 2023-06-11 16:01:24 --> URI Class Initialized
INFO - 2023-06-11 16:01:24 --> Router Class Initialized
INFO - 2023-06-11 16:01:24 --> Output Class Initialized
INFO - 2023-06-11 16:01:24 --> Security Class Initialized
INFO - 2023-06-11 16:01:24 --> Input Class Initialized
INFO - 2023-06-11 16:01:24 --> Language Class Initialized
INFO - 2023-06-11 16:01:24 --> Loader Class Initialized
INFO - 2023-06-11 16:01:24 --> Helper loaded: url_helper
INFO - 2023-06-11 16:01:24 --> Helper loaded: form_helper
INFO - 2023-06-11 16:01:24 --> Database Driver Class Initialized
INFO - 2023-06-11 16:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:01:24 --> Form Validation Class Initialized
INFO - 2023-06-11 16:01:24 --> Controller Class Initialized
INFO - 2023-06-11 16:01:24 --> Model "m_datatest" initialized
INFO - 2023-06-11 16:01:24 --> Model "m_datatrain" initialized
INFO - 2023-06-11 16:01:24 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 16:01:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:01:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:01:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 16:01:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:01:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:01:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:01:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:01:25 --> Final output sent to browser
INFO - 2023-06-11 16:01:55 --> Config Class Initialized
INFO - 2023-06-11 16:01:55 --> Hooks Class Initialized
INFO - 2023-06-11 16:01:55 --> Utf8 Class Initialized
INFO - 2023-06-11 16:01:55 --> URI Class Initialized
INFO - 2023-06-11 16:01:55 --> Router Class Initialized
INFO - 2023-06-11 16:01:55 --> Output Class Initialized
INFO - 2023-06-11 16:01:55 --> Security Class Initialized
INFO - 2023-06-11 16:01:55 --> Input Class Initialized
INFO - 2023-06-11 16:01:55 --> Language Class Initialized
INFO - 2023-06-11 16:01:55 --> Loader Class Initialized
INFO - 2023-06-11 16:01:55 --> Helper loaded: url_helper
INFO - 2023-06-11 16:01:55 --> Helper loaded: form_helper
INFO - 2023-06-11 16:01:55 --> Database Driver Class Initialized
INFO - 2023-06-11 16:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:01:55 --> Form Validation Class Initialized
INFO - 2023-06-11 16:01:56 --> Controller Class Initialized
INFO - 2023-06-11 16:01:56 --> Model "m_datatrain" initialized
INFO - 2023-06-11 16:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 16:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:01:56 --> Final output sent to browser
INFO - 2023-06-11 16:01:56 --> Config Class Initialized
INFO - 2023-06-11 16:01:56 --> Hooks Class Initialized
INFO - 2023-06-11 16:01:56 --> Utf8 Class Initialized
INFO - 2023-06-11 16:01:56 --> URI Class Initialized
INFO - 2023-06-11 16:01:56 --> Router Class Initialized
INFO - 2023-06-11 16:01:56 --> Output Class Initialized
INFO - 2023-06-11 16:01:56 --> Security Class Initialized
INFO - 2023-06-11 16:01:56 --> Input Class Initialized
INFO - 2023-06-11 16:01:56 --> Language Class Initialized
INFO - 2023-06-11 16:01:56 --> Loader Class Initialized
INFO - 2023-06-11 16:01:56 --> Helper loaded: url_helper
INFO - 2023-06-11 16:01:56 --> Helper loaded: form_helper
INFO - 2023-06-11 16:01:56 --> Database Driver Class Initialized
INFO - 2023-06-11 16:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:01:56 --> Form Validation Class Initialized
INFO - 2023-06-11 16:01:56 --> Controller Class Initialized
INFO - 2023-06-11 16:01:57 --> Model "m_datatest" initialized
INFO - 2023-06-11 16:01:57 --> Model "m_datatrain" initialized
INFO - 2023-06-11 16:01:57 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 16:01:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:01:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:01:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-11 16:01:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:01:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:01:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:01:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:01:57 --> Final output sent to browser
INFO - 2023-06-11 16:01:58 --> Config Class Initialized
INFO - 2023-06-11 16:01:58 --> Hooks Class Initialized
INFO - 2023-06-11 16:01:58 --> Utf8 Class Initialized
INFO - 2023-06-11 16:01:58 --> URI Class Initialized
INFO - 2023-06-11 16:01:58 --> Router Class Initialized
INFO - 2023-06-11 16:01:58 --> Output Class Initialized
INFO - 2023-06-11 16:01:58 --> Security Class Initialized
INFO - 2023-06-11 16:01:58 --> Input Class Initialized
INFO - 2023-06-11 16:01:58 --> Language Class Initialized
INFO - 2023-06-11 16:01:58 --> Loader Class Initialized
INFO - 2023-06-11 16:01:58 --> Helper loaded: url_helper
INFO - 2023-06-11 16:01:58 --> Helper loaded: form_helper
INFO - 2023-06-11 16:01:58 --> Database Driver Class Initialized
INFO - 2023-06-11 16:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:01:58 --> Form Validation Class Initialized
INFO - 2023-06-11 16:01:58 --> Controller Class Initialized
INFO - 2023-06-11 16:01:58 --> Model "m_datatrain" initialized
INFO - 2023-06-11 16:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 16:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:01:58 --> Final output sent to browser
INFO - 2023-06-11 16:01:59 --> Config Class Initialized
INFO - 2023-06-11 16:01:59 --> Hooks Class Initialized
INFO - 2023-06-11 16:01:59 --> Utf8 Class Initialized
INFO - 2023-06-11 16:01:59 --> URI Class Initialized
INFO - 2023-06-11 16:01:59 --> Router Class Initialized
INFO - 2023-06-11 16:01:59 --> Output Class Initialized
INFO - 2023-06-11 16:01:59 --> Security Class Initialized
INFO - 2023-06-11 16:01:59 --> Input Class Initialized
INFO - 2023-06-11 16:01:59 --> Language Class Initialized
INFO - 2023-06-11 16:01:59 --> Loader Class Initialized
INFO - 2023-06-11 16:01:59 --> Helper loaded: url_helper
INFO - 2023-06-11 16:01:59 --> Helper loaded: form_helper
INFO - 2023-06-11 16:01:59 --> Database Driver Class Initialized
INFO - 2023-06-11 16:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:01:59 --> Form Validation Class Initialized
INFO - 2023-06-11 16:01:59 --> Controller Class Initialized
INFO - 2023-06-11 16:01:59 --> Model "m_datatest" initialized
INFO - 2023-06-11 16:01:59 --> Model "m_datatrain" initialized
INFO - 2023-06-11 16:01:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 16:01:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:01:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:01:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 16:01:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:01:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:01:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:01:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:01:59 --> Final output sent to browser
INFO - 2023-06-11 16:03:09 --> Config Class Initialized
INFO - 2023-06-11 16:03:09 --> Hooks Class Initialized
INFO - 2023-06-11 16:03:09 --> Utf8 Class Initialized
INFO - 2023-06-11 16:03:09 --> URI Class Initialized
INFO - 2023-06-11 16:03:09 --> Router Class Initialized
INFO - 2023-06-11 16:03:09 --> Output Class Initialized
INFO - 2023-06-11 16:03:09 --> Security Class Initialized
INFO - 2023-06-11 16:03:09 --> Input Class Initialized
INFO - 2023-06-11 16:03:09 --> Language Class Initialized
INFO - 2023-06-11 16:03:09 --> Loader Class Initialized
INFO - 2023-06-11 16:03:09 --> Helper loaded: url_helper
INFO - 2023-06-11 16:03:09 --> Helper loaded: form_helper
INFO - 2023-06-11 16:03:09 --> Database Driver Class Initialized
INFO - 2023-06-11 16:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:03:09 --> Form Validation Class Initialized
INFO - 2023-06-11 16:03:09 --> Controller Class Initialized
INFO - 2023-06-11 16:03:09 --> Model "m_datatrain" initialized
INFO - 2023-06-11 16:03:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:03:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:03:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 16:03:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:03:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:03:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:03:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:03:09 --> Final output sent to browser
INFO - 2023-06-11 16:03:17 --> Config Class Initialized
INFO - 2023-06-11 16:03:17 --> Hooks Class Initialized
INFO - 2023-06-11 16:03:17 --> Utf8 Class Initialized
INFO - 2023-06-11 16:03:17 --> URI Class Initialized
INFO - 2023-06-11 16:03:17 --> Router Class Initialized
INFO - 2023-06-11 16:03:17 --> Output Class Initialized
INFO - 2023-06-11 16:03:17 --> Security Class Initialized
INFO - 2023-06-11 16:03:17 --> Input Class Initialized
INFO - 2023-06-11 16:03:17 --> Language Class Initialized
INFO - 2023-06-11 16:03:17 --> Loader Class Initialized
INFO - 2023-06-11 16:03:17 --> Helper loaded: url_helper
INFO - 2023-06-11 16:03:17 --> Helper loaded: form_helper
INFO - 2023-06-11 16:03:17 --> Database Driver Class Initialized
INFO - 2023-06-11 16:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:03:17 --> Form Validation Class Initialized
INFO - 2023-06-11 16:03:17 --> Controller Class Initialized
INFO - 2023-06-11 16:03:17 --> Model "m_datatest" initialized
INFO - 2023-06-11 16:03:17 --> Model "m_datatrain" initialized
INFO - 2023-06-11 16:03:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-11 16:03:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:03:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:03:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-11 16:03:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:03:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:03:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:03:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:03:17 --> Final output sent to browser
INFO - 2023-06-11 16:03:21 --> Config Class Initialized
INFO - 2023-06-11 16:03:21 --> Hooks Class Initialized
INFO - 2023-06-11 16:03:21 --> Utf8 Class Initialized
INFO - 2023-06-11 16:03:21 --> URI Class Initialized
INFO - 2023-06-11 16:03:21 --> Router Class Initialized
INFO - 2023-06-11 16:03:21 --> Output Class Initialized
INFO - 2023-06-11 16:03:21 --> Security Class Initialized
INFO - 2023-06-11 16:03:21 --> Input Class Initialized
INFO - 2023-06-11 16:03:21 --> Language Class Initialized
INFO - 2023-06-11 16:03:21 --> Loader Class Initialized
INFO - 2023-06-11 16:03:21 --> Helper loaded: url_helper
INFO - 2023-06-11 16:03:21 --> Helper loaded: form_helper
INFO - 2023-06-11 16:03:21 --> Database Driver Class Initialized
INFO - 2023-06-11 16:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:03:21 --> Form Validation Class Initialized
INFO - 2023-06-11 16:03:21 --> Controller Class Initialized
INFO - 2023-06-11 16:03:21 --> Model "m_datatest" initialized
INFO - 2023-06-11 16:03:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:03:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:03:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 16:03:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:03:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:03:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:03:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:03:21 --> Final output sent to browser
INFO - 2023-06-11 16:03:54 --> Config Class Initialized
INFO - 2023-06-11 16:03:54 --> Hooks Class Initialized
INFO - 2023-06-11 16:03:54 --> Utf8 Class Initialized
INFO - 2023-06-11 16:03:54 --> URI Class Initialized
INFO - 2023-06-11 16:03:54 --> Router Class Initialized
INFO - 2023-06-11 16:03:54 --> Output Class Initialized
INFO - 2023-06-11 16:03:54 --> Security Class Initialized
INFO - 2023-06-11 16:03:54 --> Input Class Initialized
INFO - 2023-06-11 16:03:54 --> Language Class Initialized
INFO - 2023-06-11 16:03:54 --> Loader Class Initialized
INFO - 2023-06-11 16:03:54 --> Helper loaded: url_helper
INFO - 2023-06-11 16:03:54 --> Helper loaded: form_helper
INFO - 2023-06-11 16:03:54 --> Database Driver Class Initialized
INFO - 2023-06-11 16:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:03:54 --> Form Validation Class Initialized
INFO - 2023-06-11 16:03:54 --> Controller Class Initialized
INFO - 2023-06-11 16:03:54 --> Model "m_user" initialized
INFO - 2023-06-11 16:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 16:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:03:54 --> Final output sent to browser
INFO - 2023-06-11 16:04:01 --> Config Class Initialized
INFO - 2023-06-11 16:04:01 --> Hooks Class Initialized
INFO - 2023-06-11 16:04:01 --> Utf8 Class Initialized
INFO - 2023-06-11 16:04:01 --> URI Class Initialized
INFO - 2023-06-11 16:04:01 --> Router Class Initialized
INFO - 2023-06-11 16:04:01 --> Output Class Initialized
INFO - 2023-06-11 16:04:01 --> Security Class Initialized
INFO - 2023-06-11 16:04:01 --> Input Class Initialized
INFO - 2023-06-11 16:04:01 --> Language Class Initialized
INFO - 2023-06-11 16:04:01 --> Loader Class Initialized
INFO - 2023-06-11 16:04:01 --> Helper loaded: url_helper
INFO - 2023-06-11 16:04:01 --> Helper loaded: form_helper
INFO - 2023-06-11 16:04:01 --> Database Driver Class Initialized
INFO - 2023-06-11 16:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:04:01 --> Form Validation Class Initialized
INFO - 2023-06-11 16:04:01 --> Controller Class Initialized
INFO - 2023-06-11 16:04:01 --> Model "m_datatrain" initialized
INFO - 2023-06-11 16:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-11 16:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:04:01 --> Final output sent to browser
INFO - 2023-06-11 16:04:38 --> Config Class Initialized
INFO - 2023-06-11 16:04:38 --> Hooks Class Initialized
INFO - 2023-06-11 16:04:38 --> Utf8 Class Initialized
INFO - 2023-06-11 16:04:38 --> URI Class Initialized
INFO - 2023-06-11 16:04:38 --> Router Class Initialized
INFO - 2023-06-11 16:04:38 --> Output Class Initialized
INFO - 2023-06-11 16:04:38 --> Security Class Initialized
INFO - 2023-06-11 16:04:38 --> Input Class Initialized
INFO - 2023-06-11 16:04:38 --> Language Class Initialized
INFO - 2023-06-11 16:04:38 --> Loader Class Initialized
INFO - 2023-06-11 16:04:38 --> Helper loaded: url_helper
INFO - 2023-06-11 16:04:38 --> Helper loaded: form_helper
INFO - 2023-06-11 16:04:38 --> Database Driver Class Initialized
INFO - 2023-06-11 16:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:04:38 --> Form Validation Class Initialized
INFO - 2023-06-11 16:04:38 --> Controller Class Initialized
INFO - 2023-06-11 16:04:38 --> Model "m_datatest" initialized
INFO - 2023-06-11 16:04:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:04:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:04:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 16:04:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:04:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:04:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:04:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:04:38 --> Final output sent to browser
INFO - 2023-06-11 16:05:14 --> Config Class Initialized
INFO - 2023-06-11 16:05:14 --> Hooks Class Initialized
INFO - 2023-06-11 16:05:14 --> Utf8 Class Initialized
INFO - 2023-06-11 16:05:14 --> URI Class Initialized
INFO - 2023-06-11 16:05:14 --> Router Class Initialized
INFO - 2023-06-11 16:05:14 --> Output Class Initialized
INFO - 2023-06-11 16:05:14 --> Security Class Initialized
INFO - 2023-06-11 16:05:14 --> Input Class Initialized
INFO - 2023-06-11 16:05:14 --> Language Class Initialized
ERROR - 2023-06-11 16:05:14 --> 404 Page Not Found: C_todo_list/index
INFO - 2023-06-11 16:05:16 --> Config Class Initialized
INFO - 2023-06-11 16:05:16 --> Hooks Class Initialized
INFO - 2023-06-11 16:05:16 --> Utf8 Class Initialized
INFO - 2023-06-11 16:05:16 --> URI Class Initialized
INFO - 2023-06-11 16:05:16 --> Router Class Initialized
INFO - 2023-06-11 16:05:16 --> Output Class Initialized
INFO - 2023-06-11 16:05:16 --> Security Class Initialized
INFO - 2023-06-11 16:05:16 --> Input Class Initialized
INFO - 2023-06-11 16:05:16 --> Language Class Initialized
INFO - 2023-06-11 16:05:16 --> Loader Class Initialized
INFO - 2023-06-11 16:05:16 --> Helper loaded: url_helper
INFO - 2023-06-11 16:05:16 --> Helper loaded: form_helper
INFO - 2023-06-11 16:05:16 --> Database Driver Class Initialized
INFO - 2023-06-11 16:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:05:16 --> Form Validation Class Initialized
INFO - 2023-06-11 16:05:16 --> Controller Class Initialized
INFO - 2023-06-11 16:05:16 --> Model "m_datatest" initialized
INFO - 2023-06-11 16:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 16:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:05:16 --> Final output sent to browser
INFO - 2023-06-11 16:06:20 --> Config Class Initialized
INFO - 2023-06-11 16:06:20 --> Hooks Class Initialized
INFO - 2023-06-11 16:06:20 --> Utf8 Class Initialized
INFO - 2023-06-11 16:06:20 --> URI Class Initialized
INFO - 2023-06-11 16:06:20 --> Router Class Initialized
INFO - 2023-06-11 16:06:20 --> Output Class Initialized
INFO - 2023-06-11 16:06:20 --> Security Class Initialized
INFO - 2023-06-11 16:06:20 --> Input Class Initialized
INFO - 2023-06-11 16:06:20 --> Language Class Initialized
INFO - 2023-06-11 16:06:20 --> Loader Class Initialized
INFO - 2023-06-11 16:06:20 --> Helper loaded: url_helper
INFO - 2023-06-11 16:06:20 --> Helper loaded: form_helper
INFO - 2023-06-11 16:06:20 --> Database Driver Class Initialized
INFO - 2023-06-11 16:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:06:20 --> Form Validation Class Initialized
INFO - 2023-06-11 16:06:20 --> Controller Class Initialized
INFO - 2023-06-11 16:06:20 --> Model "m_user" initialized
INFO - 2023-06-11 16:06:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:06:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:06:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 16:06:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:06:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:06:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:06:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:06:20 --> Final output sent to browser
INFO - 2023-06-11 16:06:22 --> Config Class Initialized
INFO - 2023-06-11 16:06:22 --> Hooks Class Initialized
INFO - 2023-06-11 16:06:22 --> Utf8 Class Initialized
INFO - 2023-06-11 16:06:22 --> URI Class Initialized
INFO - 2023-06-11 16:06:22 --> Router Class Initialized
INFO - 2023-06-11 16:06:22 --> Output Class Initialized
INFO - 2023-06-11 16:06:22 --> Security Class Initialized
INFO - 2023-06-11 16:06:22 --> Input Class Initialized
INFO - 2023-06-11 16:06:22 --> Language Class Initialized
ERROR - 2023-06-11 16:06:22 --> 404 Page Not Found: C_todo_list/index
INFO - 2023-06-11 16:06:24 --> Config Class Initialized
INFO - 2023-06-11 16:06:24 --> Hooks Class Initialized
INFO - 2023-06-11 16:06:24 --> Utf8 Class Initialized
INFO - 2023-06-11 16:06:24 --> URI Class Initialized
INFO - 2023-06-11 16:06:24 --> Router Class Initialized
INFO - 2023-06-11 16:06:24 --> Output Class Initialized
INFO - 2023-06-11 16:06:24 --> Security Class Initialized
INFO - 2023-06-11 16:06:24 --> Input Class Initialized
INFO - 2023-06-11 16:06:24 --> Language Class Initialized
INFO - 2023-06-11 16:06:24 --> Loader Class Initialized
INFO - 2023-06-11 16:06:24 --> Helper loaded: url_helper
INFO - 2023-06-11 16:06:24 --> Helper loaded: form_helper
INFO - 2023-06-11 16:06:24 --> Database Driver Class Initialized
INFO - 2023-06-11 16:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:06:24 --> Form Validation Class Initialized
INFO - 2023-06-11 16:06:24 --> Controller Class Initialized
INFO - 2023-06-11 16:06:24 --> Model "m_user" initialized
INFO - 2023-06-11 16:06:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:06:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:06:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-11 16:06:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:06:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:06:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:06:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 16:06:24 --> Final output sent to browser
INFO - 2023-06-11 16:06:32 --> Config Class Initialized
INFO - 2023-06-11 16:06:32 --> Hooks Class Initialized
INFO - 2023-06-11 16:06:32 --> Utf8 Class Initialized
INFO - 2023-06-11 16:06:32 --> URI Class Initialized
INFO - 2023-06-11 16:06:32 --> Router Class Initialized
INFO - 2023-06-11 16:06:32 --> Output Class Initialized
INFO - 2023-06-11 16:06:32 --> Security Class Initialized
INFO - 2023-06-11 16:06:32 --> Input Class Initialized
INFO - 2023-06-11 16:06:32 --> Language Class Initialized
INFO - 2023-06-11 16:06:32 --> Loader Class Initialized
INFO - 2023-06-11 16:06:32 --> Helper loaded: url_helper
INFO - 2023-06-11 16:06:32 --> Helper loaded: form_helper
INFO - 2023-06-11 16:06:32 --> Database Driver Class Initialized
INFO - 2023-06-11 16:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:06:32 --> Form Validation Class Initialized
INFO - 2023-06-11 16:06:32 --> Controller Class Initialized
INFO - 2023-06-11 16:06:32 --> Model "m_user" initialized
INFO - 2023-06-11 16:06:32 --> Model "m_datatrain" initialized
INFO - 2023-06-11 16:06:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:06:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:06:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 16:06:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:06:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:06:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 16:06:32 --> Final output sent to browser
INFO - 2023-06-11 16:08:07 --> Config Class Initialized
INFO - 2023-06-11 16:08:07 --> Hooks Class Initialized
INFO - 2023-06-11 16:08:07 --> Utf8 Class Initialized
INFO - 2023-06-11 16:08:07 --> URI Class Initialized
INFO - 2023-06-11 16:08:07 --> Router Class Initialized
INFO - 2023-06-11 16:08:07 --> Output Class Initialized
INFO - 2023-06-11 16:08:07 --> Security Class Initialized
INFO - 2023-06-11 16:08:07 --> Input Class Initialized
INFO - 2023-06-11 16:08:07 --> Language Class Initialized
INFO - 2023-06-11 16:08:07 --> Loader Class Initialized
INFO - 2023-06-11 16:08:07 --> Helper loaded: url_helper
INFO - 2023-06-11 16:08:07 --> Helper loaded: form_helper
INFO - 2023-06-11 16:08:07 --> Database Driver Class Initialized
INFO - 2023-06-11 16:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:08:07 --> Form Validation Class Initialized
INFO - 2023-06-11 16:08:07 --> Controller Class Initialized
INFO - 2023-06-11 16:08:07 --> Model "m_user" initialized
INFO - 2023-06-11 16:08:07 --> Config Class Initialized
INFO - 2023-06-11 16:08:07 --> Hooks Class Initialized
INFO - 2023-06-11 16:08:07 --> Utf8 Class Initialized
INFO - 2023-06-11 16:08:07 --> URI Class Initialized
INFO - 2023-06-11 16:08:07 --> Router Class Initialized
INFO - 2023-06-11 16:08:07 --> Output Class Initialized
INFO - 2023-06-11 16:08:07 --> Security Class Initialized
INFO - 2023-06-11 16:08:07 --> Input Class Initialized
INFO - 2023-06-11 16:08:07 --> Language Class Initialized
INFO - 2023-06-11 16:08:07 --> Loader Class Initialized
INFO - 2023-06-11 16:08:07 --> Helper loaded: url_helper
INFO - 2023-06-11 16:08:07 --> Helper loaded: form_helper
INFO - 2023-06-11 16:08:07 --> Database Driver Class Initialized
INFO - 2023-06-11 16:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:08:07 --> Form Validation Class Initialized
INFO - 2023-06-11 16:08:07 --> Controller Class Initialized
INFO - 2023-06-11 16:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 16:08:07 --> Final output sent to browser
INFO - 2023-06-11 16:08:09 --> Config Class Initialized
INFO - 2023-06-11 16:08:09 --> Hooks Class Initialized
INFO - 2023-06-11 16:08:09 --> Utf8 Class Initialized
INFO - 2023-06-11 16:08:09 --> URI Class Initialized
INFO - 2023-06-11 16:08:09 --> Router Class Initialized
INFO - 2023-06-11 16:08:09 --> Output Class Initialized
INFO - 2023-06-11 16:08:09 --> Security Class Initialized
INFO - 2023-06-11 16:08:09 --> Input Class Initialized
INFO - 2023-06-11 16:08:09 --> Language Class Initialized
INFO - 2023-06-11 16:08:09 --> Loader Class Initialized
INFO - 2023-06-11 16:08:09 --> Helper loaded: url_helper
INFO - 2023-06-11 16:08:09 --> Helper loaded: form_helper
INFO - 2023-06-11 16:08:09 --> Database Driver Class Initialized
INFO - 2023-06-11 16:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 16:08:09 --> Form Validation Class Initialized
INFO - 2023-06-11 16:08:09 --> Controller Class Initialized
INFO - 2023-06-11 16:08:09 --> Model "m_user" initialized
INFO - 2023-06-11 16:08:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 16:08:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 16:08:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 16:08:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 16:08:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 16:08:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-11 16:08:09 --> Final output sent to browser
INFO - 2023-06-11 17:16:00 --> Config Class Initialized
INFO - 2023-06-11 17:16:00 --> Hooks Class Initialized
INFO - 2023-06-11 17:16:00 --> Utf8 Class Initialized
INFO - 2023-06-11 17:16:00 --> URI Class Initialized
INFO - 2023-06-11 17:16:00 --> Router Class Initialized
INFO - 2023-06-11 17:16:00 --> Output Class Initialized
INFO - 2023-06-11 17:16:00 --> Security Class Initialized
INFO - 2023-06-11 17:16:00 --> Input Class Initialized
INFO - 2023-06-11 17:16:00 --> Language Class Initialized
INFO - 2023-06-11 17:16:00 --> Loader Class Initialized
INFO - 2023-06-11 17:16:00 --> Helper loaded: url_helper
INFO - 2023-06-11 17:16:00 --> Helper loaded: form_helper
INFO - 2023-06-11 17:16:00 --> Database Driver Class Initialized
INFO - 2023-06-11 17:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 17:16:00 --> Form Validation Class Initialized
INFO - 2023-06-11 17:16:00 --> Controller Class Initialized
INFO - 2023-06-11 17:16:00 --> Model "m_user" initialized
INFO - 2023-06-11 17:16:00 --> Config Class Initialized
INFO - 2023-06-11 17:16:00 --> Hooks Class Initialized
INFO - 2023-06-11 17:16:00 --> Utf8 Class Initialized
INFO - 2023-06-11 17:16:00 --> URI Class Initialized
INFO - 2023-06-11 17:16:00 --> Router Class Initialized
INFO - 2023-06-11 17:16:00 --> Output Class Initialized
INFO - 2023-06-11 17:16:00 --> Security Class Initialized
INFO - 2023-06-11 17:16:00 --> Input Class Initialized
INFO - 2023-06-11 17:16:00 --> Language Class Initialized
INFO - 2023-06-11 17:16:00 --> Loader Class Initialized
INFO - 2023-06-11 17:16:00 --> Helper loaded: url_helper
INFO - 2023-06-11 17:16:00 --> Helper loaded: form_helper
INFO - 2023-06-11 17:16:00 --> Database Driver Class Initialized
INFO - 2023-06-11 17:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 17:16:00 --> Form Validation Class Initialized
INFO - 2023-06-11 17:16:00 --> Controller Class Initialized
INFO - 2023-06-11 17:16:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 17:16:00 --> Final output sent to browser
INFO - 2023-06-11 17:16:13 --> Config Class Initialized
INFO - 2023-06-11 17:16:13 --> Hooks Class Initialized
INFO - 2023-06-11 17:16:13 --> Utf8 Class Initialized
INFO - 2023-06-11 17:16:13 --> URI Class Initialized
INFO - 2023-06-11 17:16:13 --> Router Class Initialized
INFO - 2023-06-11 17:16:13 --> Output Class Initialized
INFO - 2023-06-11 17:16:13 --> Security Class Initialized
INFO - 2023-06-11 17:16:13 --> Input Class Initialized
INFO - 2023-06-11 17:16:13 --> Language Class Initialized
INFO - 2023-06-11 17:16:13 --> Loader Class Initialized
INFO - 2023-06-11 17:16:13 --> Helper loaded: url_helper
INFO - 2023-06-11 17:16:13 --> Helper loaded: form_helper
INFO - 2023-06-11 17:16:13 --> Database Driver Class Initialized
INFO - 2023-06-11 17:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 17:16:13 --> Form Validation Class Initialized
INFO - 2023-06-11 17:16:13 --> Controller Class Initialized
INFO - 2023-06-11 17:16:13 --> Model "m_user" initialized
INFO - 2023-06-11 17:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 17:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 17:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-11 17:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 17:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 17:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-11 17:16:13 --> Final output sent to browser
INFO - 2023-06-11 17:16:15 --> Config Class Initialized
INFO - 2023-06-11 17:16:15 --> Hooks Class Initialized
INFO - 2023-06-11 17:16:15 --> Utf8 Class Initialized
INFO - 2023-06-11 17:16:15 --> URI Class Initialized
INFO - 2023-06-11 17:16:15 --> Router Class Initialized
INFO - 2023-06-11 17:16:15 --> Output Class Initialized
INFO - 2023-06-11 17:16:15 --> Security Class Initialized
INFO - 2023-06-11 17:16:15 --> Input Class Initialized
INFO - 2023-06-11 17:16:15 --> Language Class Initialized
INFO - 2023-06-11 17:16:15 --> Loader Class Initialized
INFO - 2023-06-11 17:16:15 --> Helper loaded: url_helper
INFO - 2023-06-11 17:16:15 --> Helper loaded: form_helper
INFO - 2023-06-11 17:16:15 --> Database Driver Class Initialized
INFO - 2023-06-11 17:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 17:16:15 --> Form Validation Class Initialized
INFO - 2023-06-11 17:16:15 --> Controller Class Initialized
INFO - 2023-06-11 17:16:16 --> Model "m_user" initialized
INFO - 2023-06-11 17:16:16 --> Config Class Initialized
INFO - 2023-06-11 17:16:16 --> Hooks Class Initialized
INFO - 2023-06-11 17:16:16 --> Utf8 Class Initialized
INFO - 2023-06-11 17:16:16 --> URI Class Initialized
INFO - 2023-06-11 17:16:16 --> Router Class Initialized
INFO - 2023-06-11 17:16:16 --> Output Class Initialized
INFO - 2023-06-11 17:16:16 --> Security Class Initialized
INFO - 2023-06-11 17:16:16 --> Input Class Initialized
INFO - 2023-06-11 17:16:16 --> Language Class Initialized
INFO - 2023-06-11 17:16:16 --> Loader Class Initialized
INFO - 2023-06-11 17:16:16 --> Helper loaded: url_helper
INFO - 2023-06-11 17:16:16 --> Helper loaded: form_helper
INFO - 2023-06-11 17:16:16 --> Database Driver Class Initialized
INFO - 2023-06-11 17:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 17:16:16 --> Form Validation Class Initialized
INFO - 2023-06-11 17:16:16 --> Controller Class Initialized
INFO - 2023-06-11 17:16:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-11 17:16:16 --> Final output sent to browser
INFO - 2023-06-11 17:16:17 --> Config Class Initialized
INFO - 2023-06-11 17:16:17 --> Hooks Class Initialized
INFO - 2023-06-11 17:16:17 --> Utf8 Class Initialized
INFO - 2023-06-11 17:16:17 --> URI Class Initialized
INFO - 2023-06-11 17:16:17 --> Router Class Initialized
INFO - 2023-06-11 17:16:17 --> Output Class Initialized
INFO - 2023-06-11 17:16:17 --> Security Class Initialized
INFO - 2023-06-11 17:16:17 --> Input Class Initialized
INFO - 2023-06-11 17:16:17 --> Language Class Initialized
INFO - 2023-06-11 17:16:17 --> Loader Class Initialized
INFO - 2023-06-11 17:16:17 --> Helper loaded: url_helper
INFO - 2023-06-11 17:16:17 --> Helper loaded: form_helper
INFO - 2023-06-11 17:16:17 --> Database Driver Class Initialized
INFO - 2023-06-11 17:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 17:16:17 --> Form Validation Class Initialized
INFO - 2023-06-11 17:16:17 --> Controller Class Initialized
INFO - 2023-06-11 17:16:17 --> Model "m_user" initialized
INFO - 2023-06-11 17:16:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-11 17:16:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-11 17:16:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-11 17:16:17 --> Final output sent to browser
INFO - 2023-06-11 17:16:22 --> Config Class Initialized
INFO - 2023-06-11 17:16:22 --> Hooks Class Initialized
INFO - 2023-06-11 17:16:22 --> Utf8 Class Initialized
INFO - 2023-06-11 17:16:22 --> URI Class Initialized
INFO - 2023-06-11 17:16:22 --> Router Class Initialized
INFO - 2023-06-11 17:16:22 --> Output Class Initialized
INFO - 2023-06-11 17:16:22 --> Security Class Initialized
INFO - 2023-06-11 17:16:22 --> Input Class Initialized
INFO - 2023-06-11 17:16:22 --> Language Class Initialized
INFO - 2023-06-11 17:16:22 --> Loader Class Initialized
INFO - 2023-06-11 17:16:22 --> Helper loaded: url_helper
INFO - 2023-06-11 17:16:22 --> Helper loaded: form_helper
INFO - 2023-06-11 17:16:22 --> Database Driver Class Initialized
INFO - 2023-06-11 17:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 17:16:22 --> Form Validation Class Initialized
INFO - 2023-06-11 17:16:22 --> Controller Class Initialized
INFO - 2023-06-11 17:16:22 --> Model "m_user" initialized
INFO - 2023-06-11 17:16:23 --> Config Class Initialized
INFO - 2023-06-11 17:16:23 --> Hooks Class Initialized
INFO - 2023-06-11 17:16:23 --> Utf8 Class Initialized
INFO - 2023-06-11 17:16:23 --> URI Class Initialized
INFO - 2023-06-11 17:16:23 --> Router Class Initialized
INFO - 2023-06-11 17:16:23 --> Output Class Initialized
INFO - 2023-06-11 17:16:23 --> Security Class Initialized
INFO - 2023-06-11 17:16:23 --> Input Class Initialized
INFO - 2023-06-11 17:16:23 --> Language Class Initialized
INFO - 2023-06-11 17:16:23 --> Loader Class Initialized
INFO - 2023-06-11 17:16:23 --> Helper loaded: url_helper
INFO - 2023-06-11 17:16:23 --> Helper loaded: form_helper
INFO - 2023-06-11 17:16:23 --> Database Driver Class Initialized
INFO - 2023-06-11 17:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 17:16:23 --> Form Validation Class Initialized
INFO - 2023-06-11 17:16:23 --> Controller Class Initialized
INFO - 2023-06-11 17:16:23 --> Model "m_user" initialized
INFO - 2023-06-11 17:16:23 --> Model "m_datatrain" initialized
INFO - 2023-06-11 17:16:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 17:16:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 17:16:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 17:16:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 17:16:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 17:16:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-11 17:16:23 --> Final output sent to browser
INFO - 2023-06-11 17:16:39 --> Config Class Initialized
INFO - 2023-06-11 17:16:39 --> Hooks Class Initialized
INFO - 2023-06-11 17:16:39 --> Utf8 Class Initialized
INFO - 2023-06-11 17:16:39 --> URI Class Initialized
INFO - 2023-06-11 17:16:39 --> Router Class Initialized
INFO - 2023-06-11 17:16:39 --> Output Class Initialized
INFO - 2023-06-11 17:16:39 --> Security Class Initialized
INFO - 2023-06-11 17:16:39 --> Input Class Initialized
INFO - 2023-06-11 17:16:39 --> Language Class Initialized
INFO - 2023-06-11 17:16:39 --> Loader Class Initialized
INFO - 2023-06-11 17:16:39 --> Helper loaded: url_helper
INFO - 2023-06-11 17:16:39 --> Helper loaded: form_helper
INFO - 2023-06-11 17:16:39 --> Database Driver Class Initialized
INFO - 2023-06-11 17:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-11 17:16:39 --> Form Validation Class Initialized
INFO - 2023-06-11 17:16:39 --> Controller Class Initialized
INFO - 2023-06-11 17:16:39 --> Model "m_datatest" initialized
INFO - 2023-06-11 17:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-11 17:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-11 17:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-11 17:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-11 17:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-11 17:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-11 17:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-11 17:16:39 --> Final output sent to browser
