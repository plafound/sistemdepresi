<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-30 11:58:33 --> Config Class Initialized
INFO - 2022-03-30 11:58:33 --> Hooks Class Initialized
INFO - 2022-03-30 11:58:33 --> Utf8 Class Initialized
INFO - 2022-03-30 11:58:33 --> URI Class Initialized
INFO - 2022-03-30 11:58:34 --> Router Class Initialized
INFO - 2022-03-30 11:58:34 --> Output Class Initialized
INFO - 2022-03-30 11:58:34 --> Security Class Initialized
INFO - 2022-03-30 11:58:34 --> Input Class Initialized
INFO - 2022-03-30 11:58:34 --> Language Class Initialized
ERROR - 2022-03-30 11:58:34 --> 404 Page Not Found: Faviconico/index
