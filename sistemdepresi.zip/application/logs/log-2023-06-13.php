<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-13 06:04:03 --> Config Class Initialized
INFO - 2023-06-13 06:04:03 --> Hooks Class Initialized
INFO - 2023-06-13 06:04:03 --> Utf8 Class Initialized
INFO - 2023-06-13 06:04:03 --> URI Class Initialized
INFO - 2023-06-13 06:04:03 --> Router Class Initialized
INFO - 2023-06-13 06:04:03 --> Output Class Initialized
INFO - 2023-06-13 06:04:03 --> Security Class Initialized
INFO - 2023-06-13 06:04:03 --> Input Class Initialized
INFO - 2023-06-13 06:04:03 --> Language Class Initialized
INFO - 2023-06-13 06:04:03 --> Loader Class Initialized
INFO - 2023-06-13 06:04:03 --> Helper loaded: url_helper
INFO - 2023-06-13 06:04:03 --> Helper loaded: form_helper
INFO - 2023-06-13 06:04:03 --> Database Driver Class Initialized
INFO - 2023-06-13 06:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:04:04 --> Form Validation Class Initialized
INFO - 2023-06-13 06:04:04 --> Controller Class Initialized
INFO - 2023-06-13 06:04:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-13 06:04:04 --> Final output sent to browser
INFO - 2023-06-13 06:04:08 --> Config Class Initialized
INFO - 2023-06-13 06:04:08 --> Hooks Class Initialized
INFO - 2023-06-13 06:04:08 --> Utf8 Class Initialized
INFO - 2023-06-13 06:04:08 --> URI Class Initialized
INFO - 2023-06-13 06:04:08 --> Router Class Initialized
INFO - 2023-06-13 06:04:08 --> Output Class Initialized
INFO - 2023-06-13 06:04:08 --> Security Class Initialized
INFO - 2023-06-13 06:04:08 --> Input Class Initialized
INFO - 2023-06-13 06:04:08 --> Language Class Initialized
INFO - 2023-06-13 06:04:09 --> Loader Class Initialized
INFO - 2023-06-13 06:04:09 --> Helper loaded: url_helper
INFO - 2023-06-13 06:04:09 --> Helper loaded: form_helper
INFO - 2023-06-13 06:04:09 --> Database Driver Class Initialized
INFO - 2023-06-13 06:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:04:09 --> Form Validation Class Initialized
INFO - 2023-06-13 06:04:09 --> Controller Class Initialized
INFO - 2023-06-13 06:04:09 --> Model "m_user" initialized
INFO - 2023-06-13 06:04:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-13 06:04:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-13 06:04:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-13 06:04:09 --> Final output sent to browser
INFO - 2023-06-13 06:04:14 --> Config Class Initialized
INFO - 2023-06-13 06:04:14 --> Hooks Class Initialized
INFO - 2023-06-13 06:04:14 --> Utf8 Class Initialized
INFO - 2023-06-13 06:04:14 --> URI Class Initialized
INFO - 2023-06-13 06:04:14 --> Router Class Initialized
INFO - 2023-06-13 06:04:14 --> Output Class Initialized
INFO - 2023-06-13 06:04:14 --> Security Class Initialized
INFO - 2023-06-13 06:04:14 --> Input Class Initialized
INFO - 2023-06-13 06:04:14 --> Language Class Initialized
INFO - 2023-06-13 06:04:14 --> Loader Class Initialized
INFO - 2023-06-13 06:04:14 --> Helper loaded: url_helper
INFO - 2023-06-13 06:04:14 --> Helper loaded: form_helper
INFO - 2023-06-13 06:04:14 --> Database Driver Class Initialized
INFO - 2023-06-13 06:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:04:14 --> Form Validation Class Initialized
INFO - 2023-06-13 06:04:14 --> Controller Class Initialized
INFO - 2023-06-13 06:04:14 --> Model "m_user" initialized
INFO - 2023-06-13 06:04:14 --> Config Class Initialized
INFO - 2023-06-13 06:04:14 --> Hooks Class Initialized
INFO - 2023-06-13 06:04:14 --> Utf8 Class Initialized
INFO - 2023-06-13 06:04:14 --> URI Class Initialized
INFO - 2023-06-13 06:04:14 --> Router Class Initialized
INFO - 2023-06-13 06:04:14 --> Output Class Initialized
INFO - 2023-06-13 06:04:15 --> Security Class Initialized
INFO - 2023-06-13 06:04:15 --> Input Class Initialized
INFO - 2023-06-13 06:04:15 --> Language Class Initialized
INFO - 2023-06-13 06:04:15 --> Loader Class Initialized
INFO - 2023-06-13 06:04:15 --> Helper loaded: url_helper
INFO - 2023-06-13 06:04:15 --> Helper loaded: form_helper
INFO - 2023-06-13 06:04:15 --> Database Driver Class Initialized
INFO - 2023-06-13 06:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:04:15 --> Form Validation Class Initialized
INFO - 2023-06-13 06:04:15 --> Controller Class Initialized
INFO - 2023-06-13 06:04:15 --> Model "m_user" initialized
INFO - 2023-06-13 06:04:15 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:04:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:04:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:04:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:04:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:04:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:04:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-13 06:04:15 --> Final output sent to browser
INFO - 2023-06-13 06:04:18 --> Config Class Initialized
INFO - 2023-06-13 06:04:18 --> Hooks Class Initialized
INFO - 2023-06-13 06:04:18 --> Utf8 Class Initialized
INFO - 2023-06-13 06:04:18 --> URI Class Initialized
INFO - 2023-06-13 06:04:18 --> Router Class Initialized
INFO - 2023-06-13 06:04:18 --> Output Class Initialized
INFO - 2023-06-13 06:04:18 --> Security Class Initialized
INFO - 2023-06-13 06:04:18 --> Input Class Initialized
INFO - 2023-06-13 06:04:18 --> Language Class Initialized
INFO - 2023-06-13 06:04:18 --> Loader Class Initialized
INFO - 2023-06-13 06:04:18 --> Helper loaded: url_helper
INFO - 2023-06-13 06:04:18 --> Helper loaded: form_helper
INFO - 2023-06-13 06:04:18 --> Database Driver Class Initialized
INFO - 2023-06-13 06:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:04:18 --> Form Validation Class Initialized
INFO - 2023-06-13 06:04:18 --> Controller Class Initialized
INFO - 2023-06-13 06:04:18 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-13 06:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:04:18 --> Final output sent to browser
INFO - 2023-06-13 06:04:44 --> Config Class Initialized
INFO - 2023-06-13 06:04:44 --> Hooks Class Initialized
INFO - 2023-06-13 06:04:44 --> Utf8 Class Initialized
INFO - 2023-06-13 06:04:44 --> URI Class Initialized
INFO - 2023-06-13 06:04:44 --> Router Class Initialized
INFO - 2023-06-13 06:04:44 --> Output Class Initialized
INFO - 2023-06-13 06:04:44 --> Security Class Initialized
INFO - 2023-06-13 06:04:44 --> Input Class Initialized
INFO - 2023-06-13 06:04:44 --> Language Class Initialized
INFO - 2023-06-13 06:04:44 --> Loader Class Initialized
INFO - 2023-06-13 06:04:44 --> Helper loaded: url_helper
INFO - 2023-06-13 06:04:44 --> Helper loaded: form_helper
INFO - 2023-06-13 06:04:44 --> Database Driver Class Initialized
INFO - 2023-06-13 06:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:04:44 --> Form Validation Class Initialized
INFO - 2023-06-13 06:04:44 --> Controller Class Initialized
INFO - 2023-06-13 06:04:44 --> Model "m_user" initialized
INFO - 2023-06-13 06:04:44 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:04:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:04:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:04:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:04:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:04:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:04:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-13 06:04:44 --> Final output sent to browser
INFO - 2023-06-13 06:04:46 --> Config Class Initialized
INFO - 2023-06-13 06:04:46 --> Hooks Class Initialized
INFO - 2023-06-13 06:04:46 --> Utf8 Class Initialized
INFO - 2023-06-13 06:04:46 --> URI Class Initialized
INFO - 2023-06-13 06:04:46 --> Router Class Initialized
INFO - 2023-06-13 06:04:46 --> Output Class Initialized
INFO - 2023-06-13 06:04:46 --> Security Class Initialized
INFO - 2023-06-13 06:04:46 --> Input Class Initialized
INFO - 2023-06-13 06:04:46 --> Language Class Initialized
INFO - 2023-06-13 06:04:46 --> Loader Class Initialized
INFO - 2023-06-13 06:04:46 --> Helper loaded: url_helper
INFO - 2023-06-13 06:04:46 --> Helper loaded: form_helper
INFO - 2023-06-13 06:04:46 --> Database Driver Class Initialized
INFO - 2023-06-13 06:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:04:47 --> Form Validation Class Initialized
INFO - 2023-06-13 06:04:47 --> Controller Class Initialized
INFO - 2023-06-13 06:04:47 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:04:47 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:04:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:04:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:04:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:04:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-13 06:04:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:04:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:04:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:04:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:04:47 --> Final output sent to browser
INFO - 2023-06-13 06:06:53 --> Config Class Initialized
INFO - 2023-06-13 06:06:53 --> Hooks Class Initialized
INFO - 2023-06-13 06:06:53 --> Utf8 Class Initialized
INFO - 2023-06-13 06:06:53 --> URI Class Initialized
INFO - 2023-06-13 06:06:53 --> Router Class Initialized
INFO - 2023-06-13 06:06:53 --> Output Class Initialized
INFO - 2023-06-13 06:06:53 --> Security Class Initialized
INFO - 2023-06-13 06:06:53 --> Input Class Initialized
INFO - 2023-06-13 06:06:53 --> Language Class Initialized
INFO - 2023-06-13 06:06:53 --> Loader Class Initialized
INFO - 2023-06-13 06:06:53 --> Helper loaded: url_helper
INFO - 2023-06-13 06:06:53 --> Helper loaded: form_helper
INFO - 2023-06-13 06:06:53 --> Database Driver Class Initialized
INFO - 2023-06-13 06:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:06:53 --> Form Validation Class Initialized
INFO - 2023-06-13 06:06:53 --> Controller Class Initialized
INFO - 2023-06-13 06:06:53 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:06:53 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:06:53 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-13 06:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:06:53 --> Final output sent to browser
INFO - 2023-06-13 06:07:01 --> Config Class Initialized
INFO - 2023-06-13 06:07:01 --> Hooks Class Initialized
INFO - 2023-06-13 06:07:01 --> Utf8 Class Initialized
INFO - 2023-06-13 06:07:01 --> URI Class Initialized
INFO - 2023-06-13 06:07:01 --> Router Class Initialized
INFO - 2023-06-13 06:07:01 --> Output Class Initialized
INFO - 2023-06-13 06:07:01 --> Security Class Initialized
INFO - 2023-06-13 06:07:01 --> Input Class Initialized
INFO - 2023-06-13 06:07:01 --> Language Class Initialized
INFO - 2023-06-13 06:07:01 --> Loader Class Initialized
INFO - 2023-06-13 06:07:01 --> Helper loaded: url_helper
INFO - 2023-06-13 06:07:01 --> Helper loaded: form_helper
INFO - 2023-06-13 06:07:01 --> Database Driver Class Initialized
INFO - 2023-06-13 06:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:07:01 --> Form Validation Class Initialized
INFO - 2023-06-13 06:07:01 --> Controller Class Initialized
INFO - 2023-06-13 06:07:01 --> Model "m_user" initialized
INFO - 2023-06-13 06:07:01 --> Config Class Initialized
INFO - 2023-06-13 06:07:01 --> Hooks Class Initialized
INFO - 2023-06-13 06:07:01 --> Utf8 Class Initialized
INFO - 2023-06-13 06:07:01 --> URI Class Initialized
INFO - 2023-06-13 06:07:01 --> Router Class Initialized
INFO - 2023-06-13 06:07:01 --> Output Class Initialized
INFO - 2023-06-13 06:07:01 --> Security Class Initialized
INFO - 2023-06-13 06:07:01 --> Input Class Initialized
INFO - 2023-06-13 06:07:01 --> Language Class Initialized
INFO - 2023-06-13 06:07:01 --> Loader Class Initialized
INFO - 2023-06-13 06:07:01 --> Helper loaded: url_helper
INFO - 2023-06-13 06:07:01 --> Helper loaded: form_helper
INFO - 2023-06-13 06:07:01 --> Database Driver Class Initialized
INFO - 2023-06-13 06:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:07:01 --> Form Validation Class Initialized
INFO - 2023-06-13 06:07:01 --> Controller Class Initialized
INFO - 2023-06-13 06:07:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-13 06:07:01 --> Final output sent to browser
INFO - 2023-06-13 06:07:03 --> Config Class Initialized
INFO - 2023-06-13 06:07:03 --> Hooks Class Initialized
INFO - 2023-06-13 06:07:03 --> Utf8 Class Initialized
INFO - 2023-06-13 06:07:03 --> URI Class Initialized
INFO - 2023-06-13 06:07:03 --> Router Class Initialized
INFO - 2023-06-13 06:07:03 --> Output Class Initialized
INFO - 2023-06-13 06:07:03 --> Security Class Initialized
INFO - 2023-06-13 06:07:03 --> Input Class Initialized
INFO - 2023-06-13 06:07:03 --> Language Class Initialized
INFO - 2023-06-13 06:07:03 --> Loader Class Initialized
INFO - 2023-06-13 06:07:03 --> Helper loaded: url_helper
INFO - 2023-06-13 06:07:03 --> Helper loaded: form_helper
INFO - 2023-06-13 06:07:03 --> Database Driver Class Initialized
INFO - 2023-06-13 06:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:07:03 --> Form Validation Class Initialized
INFO - 2023-06-13 06:07:03 --> Controller Class Initialized
INFO - 2023-06-13 06:07:03 --> Model "m_user" initialized
INFO - 2023-06-13 06:07:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:07:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:07:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 06:07:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:07:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:07:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-13 06:07:03 --> Final output sent to browser
INFO - 2023-06-13 06:07:22 --> Config Class Initialized
INFO - 2023-06-13 06:07:22 --> Hooks Class Initialized
INFO - 2023-06-13 06:07:22 --> Utf8 Class Initialized
INFO - 2023-06-13 06:07:22 --> URI Class Initialized
INFO - 2023-06-13 06:07:22 --> Router Class Initialized
INFO - 2023-06-13 06:07:22 --> Output Class Initialized
INFO - 2023-06-13 06:07:22 --> Security Class Initialized
INFO - 2023-06-13 06:07:22 --> Input Class Initialized
INFO - 2023-06-13 06:07:22 --> Language Class Initialized
INFO - 2023-06-13 06:07:22 --> Loader Class Initialized
INFO - 2023-06-13 06:07:22 --> Helper loaded: url_helper
INFO - 2023-06-13 06:07:22 --> Helper loaded: form_helper
INFO - 2023-06-13 06:07:22 --> Database Driver Class Initialized
INFO - 2023-06-13 06:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:07:22 --> Form Validation Class Initialized
INFO - 2023-06-13 06:07:22 --> Controller Class Initialized
INFO - 2023-06-13 06:07:22 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:07:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:07:22 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:07:22 --> Model "M_solusi" initialized
INFO - 2023-06-13 06:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-13 06:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 06:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-13 06:07:22 --> Final output sent to browser
INFO - 2023-06-13 06:07:26 --> Config Class Initialized
INFO - 2023-06-13 06:07:26 --> Hooks Class Initialized
INFO - 2023-06-13 06:07:26 --> Utf8 Class Initialized
INFO - 2023-06-13 06:07:26 --> URI Class Initialized
INFO - 2023-06-13 06:07:26 --> Router Class Initialized
INFO - 2023-06-13 06:07:26 --> Output Class Initialized
INFO - 2023-06-13 06:07:26 --> Security Class Initialized
INFO - 2023-06-13 06:07:26 --> Input Class Initialized
INFO - 2023-06-13 06:07:26 --> Language Class Initialized
INFO - 2023-06-13 06:07:26 --> Loader Class Initialized
INFO - 2023-06-13 06:07:26 --> Helper loaded: url_helper
INFO - 2023-06-13 06:07:26 --> Helper loaded: form_helper
INFO - 2023-06-13 06:07:26 --> Database Driver Class Initialized
INFO - 2023-06-13 06:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:07:26 --> Form Validation Class Initialized
INFO - 2023-06-13 06:07:26 --> Controller Class Initialized
INFO - 2023-06-13 06:07:26 --> Model "m_user" initialized
INFO - 2023-06-13 06:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 06:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-13 06:07:26 --> Final output sent to browser
INFO - 2023-06-13 06:07:34 --> Config Class Initialized
INFO - 2023-06-13 06:07:34 --> Hooks Class Initialized
INFO - 2023-06-13 06:07:34 --> Utf8 Class Initialized
INFO - 2023-06-13 06:07:34 --> URI Class Initialized
INFO - 2023-06-13 06:07:34 --> Router Class Initialized
INFO - 2023-06-13 06:07:34 --> Output Class Initialized
INFO - 2023-06-13 06:07:34 --> Security Class Initialized
INFO - 2023-06-13 06:07:34 --> Input Class Initialized
INFO - 2023-06-13 06:07:34 --> Language Class Initialized
INFO - 2023-06-13 06:07:34 --> Loader Class Initialized
INFO - 2023-06-13 06:07:34 --> Helper loaded: url_helper
INFO - 2023-06-13 06:07:34 --> Helper loaded: form_helper
INFO - 2023-06-13 06:07:34 --> Database Driver Class Initialized
INFO - 2023-06-13 06:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:07:35 --> Form Validation Class Initialized
INFO - 2023-06-13 06:07:35 --> Controller Class Initialized
INFO - 2023-06-13 06:07:35 --> Model "m_user" initialized
INFO - 2023-06-13 06:07:35 --> Config Class Initialized
INFO - 2023-06-13 06:07:35 --> Hooks Class Initialized
INFO - 2023-06-13 06:07:35 --> Utf8 Class Initialized
INFO - 2023-06-13 06:07:35 --> URI Class Initialized
INFO - 2023-06-13 06:07:35 --> Router Class Initialized
INFO - 2023-06-13 06:07:35 --> Output Class Initialized
INFO - 2023-06-13 06:07:35 --> Security Class Initialized
INFO - 2023-06-13 06:07:35 --> Input Class Initialized
INFO - 2023-06-13 06:07:35 --> Language Class Initialized
INFO - 2023-06-13 06:07:35 --> Loader Class Initialized
INFO - 2023-06-13 06:07:35 --> Helper loaded: url_helper
INFO - 2023-06-13 06:07:35 --> Helper loaded: form_helper
INFO - 2023-06-13 06:07:35 --> Database Driver Class Initialized
INFO - 2023-06-13 06:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:07:35 --> Form Validation Class Initialized
INFO - 2023-06-13 06:07:35 --> Controller Class Initialized
INFO - 2023-06-13 06:07:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-13 06:07:35 --> Final output sent to browser
INFO - 2023-06-13 06:07:36 --> Config Class Initialized
INFO - 2023-06-13 06:07:36 --> Hooks Class Initialized
INFO - 2023-06-13 06:07:36 --> Utf8 Class Initialized
INFO - 2023-06-13 06:07:36 --> URI Class Initialized
INFO - 2023-06-13 06:07:36 --> Router Class Initialized
INFO - 2023-06-13 06:07:36 --> Output Class Initialized
INFO - 2023-06-13 06:07:36 --> Security Class Initialized
INFO - 2023-06-13 06:07:36 --> Input Class Initialized
INFO - 2023-06-13 06:07:36 --> Language Class Initialized
INFO - 2023-06-13 06:07:36 --> Loader Class Initialized
INFO - 2023-06-13 06:07:36 --> Helper loaded: url_helper
INFO - 2023-06-13 06:07:36 --> Helper loaded: form_helper
INFO - 2023-06-13 06:07:36 --> Database Driver Class Initialized
INFO - 2023-06-13 06:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:07:36 --> Form Validation Class Initialized
INFO - 2023-06-13 06:07:36 --> Controller Class Initialized
INFO - 2023-06-13 06:07:36 --> Model "m_user" initialized
INFO - 2023-06-13 06:07:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-13 06:07:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-13 06:07:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-13 06:07:36 --> Final output sent to browser
INFO - 2023-06-13 06:07:39 --> Config Class Initialized
INFO - 2023-06-13 06:07:39 --> Hooks Class Initialized
INFO - 2023-06-13 06:07:39 --> Utf8 Class Initialized
INFO - 2023-06-13 06:07:39 --> URI Class Initialized
INFO - 2023-06-13 06:07:39 --> Router Class Initialized
INFO - 2023-06-13 06:07:39 --> Output Class Initialized
INFO - 2023-06-13 06:07:39 --> Security Class Initialized
INFO - 2023-06-13 06:07:39 --> Input Class Initialized
INFO - 2023-06-13 06:07:39 --> Language Class Initialized
INFO - 2023-06-13 06:07:39 --> Loader Class Initialized
INFO - 2023-06-13 06:07:39 --> Helper loaded: url_helper
INFO - 2023-06-13 06:07:39 --> Helper loaded: form_helper
INFO - 2023-06-13 06:07:39 --> Database Driver Class Initialized
INFO - 2023-06-13 06:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:07:39 --> Form Validation Class Initialized
INFO - 2023-06-13 06:07:39 --> Controller Class Initialized
INFO - 2023-06-13 06:07:39 --> Model "m_user" initialized
INFO - 2023-06-13 06:07:39 --> Config Class Initialized
INFO - 2023-06-13 06:07:39 --> Hooks Class Initialized
INFO - 2023-06-13 06:07:39 --> Utf8 Class Initialized
INFO - 2023-06-13 06:07:39 --> URI Class Initialized
INFO - 2023-06-13 06:07:39 --> Router Class Initialized
INFO - 2023-06-13 06:07:39 --> Output Class Initialized
INFO - 2023-06-13 06:07:39 --> Security Class Initialized
INFO - 2023-06-13 06:07:39 --> Input Class Initialized
INFO - 2023-06-13 06:07:39 --> Language Class Initialized
INFO - 2023-06-13 06:07:39 --> Loader Class Initialized
INFO - 2023-06-13 06:07:39 --> Helper loaded: url_helper
INFO - 2023-06-13 06:07:39 --> Helper loaded: form_helper
INFO - 2023-06-13 06:07:39 --> Database Driver Class Initialized
INFO - 2023-06-13 06:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:07:39 --> Form Validation Class Initialized
INFO - 2023-06-13 06:07:39 --> Controller Class Initialized
INFO - 2023-06-13 06:07:39 --> Model "m_user" initialized
INFO - 2023-06-13 06:07:39 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:07:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:07:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:07:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:07:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:07:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:07:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-13 06:07:39 --> Final output sent to browser
INFO - 2023-06-13 06:07:44 --> Config Class Initialized
INFO - 2023-06-13 06:07:44 --> Hooks Class Initialized
INFO - 2023-06-13 06:07:44 --> Utf8 Class Initialized
INFO - 2023-06-13 06:07:44 --> URI Class Initialized
INFO - 2023-06-13 06:07:44 --> Router Class Initialized
INFO - 2023-06-13 06:07:44 --> Output Class Initialized
INFO - 2023-06-13 06:07:44 --> Security Class Initialized
INFO - 2023-06-13 06:07:44 --> Input Class Initialized
INFO - 2023-06-13 06:07:44 --> Language Class Initialized
INFO - 2023-06-13 06:07:44 --> Loader Class Initialized
INFO - 2023-06-13 06:07:44 --> Helper loaded: url_helper
INFO - 2023-06-13 06:07:44 --> Helper loaded: form_helper
INFO - 2023-06-13 06:07:44 --> Database Driver Class Initialized
INFO - 2023-06-13 06:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:07:44 --> Form Validation Class Initialized
INFO - 2023-06-13 06:07:44 --> Controller Class Initialized
INFO - 2023-06-13 06:07:44 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-13 06:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:07:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:07:44 --> Final output sent to browser
INFO - 2023-06-13 06:08:31 --> Config Class Initialized
INFO - 2023-06-13 06:08:31 --> Hooks Class Initialized
INFO - 2023-06-13 06:08:31 --> Utf8 Class Initialized
INFO - 2023-06-13 06:08:31 --> URI Class Initialized
INFO - 2023-06-13 06:08:31 --> Router Class Initialized
INFO - 2023-06-13 06:08:31 --> Output Class Initialized
INFO - 2023-06-13 06:08:31 --> Security Class Initialized
INFO - 2023-06-13 06:08:31 --> Input Class Initialized
INFO - 2023-06-13 06:08:31 --> Language Class Initialized
INFO - 2023-06-13 06:08:31 --> Loader Class Initialized
INFO - 2023-06-13 06:08:31 --> Helper loaded: url_helper
INFO - 2023-06-13 06:08:31 --> Helper loaded: form_helper
INFO - 2023-06-13 06:08:31 --> Database Driver Class Initialized
INFO - 2023-06-13 06:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:08:31 --> Form Validation Class Initialized
INFO - 2023-06-13 06:08:31 --> Controller Class Initialized
INFO - 2023-06-13 06:08:31 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:08:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:08:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:08:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-13 06:08:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:08:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:08:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:08:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:08:31 --> Final output sent to browser
INFO - 2023-06-13 06:08:52 --> Config Class Initialized
INFO - 2023-06-13 06:08:52 --> Hooks Class Initialized
INFO - 2023-06-13 06:08:52 --> Utf8 Class Initialized
INFO - 2023-06-13 06:08:52 --> URI Class Initialized
INFO - 2023-06-13 06:08:52 --> Router Class Initialized
INFO - 2023-06-13 06:08:52 --> Output Class Initialized
INFO - 2023-06-13 06:08:52 --> Security Class Initialized
INFO - 2023-06-13 06:08:52 --> Input Class Initialized
INFO - 2023-06-13 06:08:52 --> Language Class Initialized
INFO - 2023-06-13 06:08:52 --> Loader Class Initialized
INFO - 2023-06-13 06:08:52 --> Helper loaded: url_helper
INFO - 2023-06-13 06:08:52 --> Helper loaded: form_helper
INFO - 2023-06-13 06:08:52 --> Database Driver Class Initialized
INFO - 2023-06-13 06:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:08:52 --> Form Validation Class Initialized
INFO - 2023-06-13 06:08:52 --> Controller Class Initialized
INFO - 2023-06-13 06:08:52 --> Model "m_user" initialized
INFO - 2023-06-13 06:08:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:08:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:08:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\admin/v_admin.php
INFO - 2023-06-13 06:08:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:08:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:08:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:08:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:08:52 --> Final output sent to browser
INFO - 2023-06-13 06:08:57 --> Config Class Initialized
INFO - 2023-06-13 06:08:57 --> Hooks Class Initialized
INFO - 2023-06-13 06:08:57 --> Utf8 Class Initialized
INFO - 2023-06-13 06:08:57 --> URI Class Initialized
INFO - 2023-06-13 06:08:57 --> Router Class Initialized
INFO - 2023-06-13 06:08:57 --> Output Class Initialized
INFO - 2023-06-13 06:08:57 --> Security Class Initialized
INFO - 2023-06-13 06:08:58 --> Input Class Initialized
INFO - 2023-06-13 06:08:58 --> Language Class Initialized
INFO - 2023-06-13 06:08:58 --> Loader Class Initialized
INFO - 2023-06-13 06:08:58 --> Helper loaded: url_helper
INFO - 2023-06-13 06:08:58 --> Helper loaded: form_helper
INFO - 2023-06-13 06:08:58 --> Database Driver Class Initialized
INFO - 2023-06-13 06:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:08:58 --> Form Validation Class Initialized
INFO - 2023-06-13 06:08:58 --> Controller Class Initialized
INFO - 2023-06-13 06:08:58 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:08:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:08:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:08:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-13 06:08:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:08:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:08:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:08:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:08:58 --> Final output sent to browser
INFO - 2023-06-13 06:09:04 --> Config Class Initialized
INFO - 2023-06-13 06:09:04 --> Hooks Class Initialized
INFO - 2023-06-13 06:09:04 --> Utf8 Class Initialized
INFO - 2023-06-13 06:09:04 --> URI Class Initialized
INFO - 2023-06-13 06:09:04 --> Router Class Initialized
INFO - 2023-06-13 06:09:04 --> Output Class Initialized
INFO - 2023-06-13 06:09:04 --> Security Class Initialized
INFO - 2023-06-13 06:09:04 --> Input Class Initialized
INFO - 2023-06-13 06:09:04 --> Language Class Initialized
INFO - 2023-06-13 06:09:04 --> Loader Class Initialized
INFO - 2023-06-13 06:09:04 --> Helper loaded: url_helper
INFO - 2023-06-13 06:09:04 --> Helper loaded: form_helper
INFO - 2023-06-13 06:09:04 --> Database Driver Class Initialized
INFO - 2023-06-13 06:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:09:04 --> Form Validation Class Initialized
INFO - 2023-06-13 06:09:04 --> Controller Class Initialized
INFO - 2023-06-13 06:09:04 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:09:04 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:09:04 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:09:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:09:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:09:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-13 06:09:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:09:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:09:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:09:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:09:04 --> Final output sent to browser
INFO - 2023-06-13 06:09:09 --> Config Class Initialized
INFO - 2023-06-13 06:09:09 --> Hooks Class Initialized
INFO - 2023-06-13 06:09:09 --> Utf8 Class Initialized
INFO - 2023-06-13 06:09:09 --> URI Class Initialized
INFO - 2023-06-13 06:09:09 --> Router Class Initialized
INFO - 2023-06-13 06:09:09 --> Output Class Initialized
INFO - 2023-06-13 06:09:09 --> Security Class Initialized
INFO - 2023-06-13 06:09:09 --> Input Class Initialized
INFO - 2023-06-13 06:09:09 --> Language Class Initialized
INFO - 2023-06-13 06:09:09 --> Loader Class Initialized
INFO - 2023-06-13 06:09:09 --> Helper loaded: url_helper
INFO - 2023-06-13 06:09:09 --> Helper loaded: form_helper
INFO - 2023-06-13 06:09:09 --> Database Driver Class Initialized
INFO - 2023-06-13 06:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:09:09 --> Form Validation Class Initialized
INFO - 2023-06-13 06:09:09 --> Controller Class Initialized
INFO - 2023-06-13 06:09:09 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:09:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:09:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:09:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-13 06:09:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:09:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:09:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:09:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:09:09 --> Final output sent to browser
INFO - 2023-06-13 06:09:11 --> Config Class Initialized
INFO - 2023-06-13 06:09:11 --> Hooks Class Initialized
INFO - 2023-06-13 06:09:11 --> Utf8 Class Initialized
INFO - 2023-06-13 06:09:11 --> URI Class Initialized
INFO - 2023-06-13 06:09:11 --> Router Class Initialized
INFO - 2023-06-13 06:09:11 --> Output Class Initialized
INFO - 2023-06-13 06:09:11 --> Security Class Initialized
INFO - 2023-06-13 06:09:11 --> Input Class Initialized
INFO - 2023-06-13 06:09:11 --> Language Class Initialized
INFO - 2023-06-13 06:09:11 --> Loader Class Initialized
INFO - 2023-06-13 06:09:11 --> Helper loaded: url_helper
INFO - 2023-06-13 06:09:11 --> Helper loaded: form_helper
INFO - 2023-06-13 06:09:11 --> Database Driver Class Initialized
INFO - 2023-06-13 06:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:09:11 --> Form Validation Class Initialized
INFO - 2023-06-13 06:09:11 --> Controller Class Initialized
INFO - 2023-06-13 06:09:11 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:09:11 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:09:11 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:09:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:09:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:09:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-13 06:09:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:09:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:09:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:09:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:09:11 --> Final output sent to browser
INFO - 2023-06-13 06:09:14 --> Config Class Initialized
INFO - 2023-06-13 06:09:14 --> Hooks Class Initialized
INFO - 2023-06-13 06:09:14 --> Utf8 Class Initialized
INFO - 2023-06-13 06:09:14 --> URI Class Initialized
INFO - 2023-06-13 06:09:14 --> Router Class Initialized
INFO - 2023-06-13 06:09:14 --> Output Class Initialized
INFO - 2023-06-13 06:09:14 --> Security Class Initialized
INFO - 2023-06-13 06:09:14 --> Input Class Initialized
INFO - 2023-06-13 06:09:14 --> Language Class Initialized
INFO - 2023-06-13 06:09:14 --> Loader Class Initialized
INFO - 2023-06-13 06:09:14 --> Helper loaded: url_helper
INFO - 2023-06-13 06:09:14 --> Helper loaded: form_helper
INFO - 2023-06-13 06:09:14 --> Database Driver Class Initialized
INFO - 2023-06-13 06:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:09:14 --> Form Validation Class Initialized
INFO - 2023-06-13 06:09:14 --> Controller Class Initialized
INFO - 2023-06-13 06:09:14 --> Model "m_user" initialized
INFO - 2023-06-13 06:09:14 --> Config Class Initialized
INFO - 2023-06-13 06:09:14 --> Hooks Class Initialized
INFO - 2023-06-13 06:09:14 --> Utf8 Class Initialized
INFO - 2023-06-13 06:09:14 --> URI Class Initialized
INFO - 2023-06-13 06:09:14 --> Router Class Initialized
INFO - 2023-06-13 06:09:14 --> Output Class Initialized
INFO - 2023-06-13 06:09:14 --> Security Class Initialized
INFO - 2023-06-13 06:09:14 --> Input Class Initialized
INFO - 2023-06-13 06:09:14 --> Language Class Initialized
INFO - 2023-06-13 06:09:14 --> Loader Class Initialized
INFO - 2023-06-13 06:09:14 --> Helper loaded: url_helper
INFO - 2023-06-13 06:09:14 --> Helper loaded: form_helper
INFO - 2023-06-13 06:09:14 --> Database Driver Class Initialized
INFO - 2023-06-13 06:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:09:14 --> Form Validation Class Initialized
INFO - 2023-06-13 06:09:14 --> Controller Class Initialized
INFO - 2023-06-13 06:09:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-13 06:09:14 --> Final output sent to browser
INFO - 2023-06-13 06:13:39 --> Config Class Initialized
INFO - 2023-06-13 06:13:39 --> Hooks Class Initialized
INFO - 2023-06-13 06:13:39 --> Utf8 Class Initialized
INFO - 2023-06-13 06:13:39 --> URI Class Initialized
INFO - 2023-06-13 06:13:39 --> Router Class Initialized
INFO - 2023-06-13 06:13:39 --> Output Class Initialized
INFO - 2023-06-13 06:13:39 --> Security Class Initialized
INFO - 2023-06-13 06:13:39 --> Input Class Initialized
INFO - 2023-06-13 06:13:39 --> Language Class Initialized
INFO - 2023-06-13 06:13:39 --> Loader Class Initialized
INFO - 2023-06-13 06:13:39 --> Helper loaded: url_helper
INFO - 2023-06-13 06:13:39 --> Helper loaded: form_helper
INFO - 2023-06-13 06:13:39 --> Database Driver Class Initialized
INFO - 2023-06-13 06:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:13:39 --> Form Validation Class Initialized
INFO - 2023-06-13 06:13:39 --> Controller Class Initialized
INFO - 2023-06-13 06:13:39 --> Model "m_user" initialized
INFO - 2023-06-13 06:13:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-13 06:13:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-13 06:13:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-13 06:13:39 --> Final output sent to browser
INFO - 2023-06-13 06:13:43 --> Config Class Initialized
INFO - 2023-06-13 06:13:43 --> Hooks Class Initialized
INFO - 2023-06-13 06:13:43 --> Utf8 Class Initialized
INFO - 2023-06-13 06:13:43 --> URI Class Initialized
INFO - 2023-06-13 06:13:43 --> Router Class Initialized
INFO - 2023-06-13 06:13:43 --> Output Class Initialized
INFO - 2023-06-13 06:13:43 --> Security Class Initialized
INFO - 2023-06-13 06:13:43 --> Input Class Initialized
INFO - 2023-06-13 06:13:43 --> Language Class Initialized
INFO - 2023-06-13 06:13:43 --> Loader Class Initialized
INFO - 2023-06-13 06:13:43 --> Helper loaded: url_helper
INFO - 2023-06-13 06:13:43 --> Helper loaded: form_helper
INFO - 2023-06-13 06:13:43 --> Database Driver Class Initialized
INFO - 2023-06-13 06:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:13:43 --> Form Validation Class Initialized
INFO - 2023-06-13 06:13:43 --> Controller Class Initialized
INFO - 2023-06-13 06:13:43 --> Model "m_user" initialized
INFO - 2023-06-13 06:13:43 --> Config Class Initialized
INFO - 2023-06-13 06:13:43 --> Hooks Class Initialized
INFO - 2023-06-13 06:13:43 --> Utf8 Class Initialized
INFO - 2023-06-13 06:13:43 --> URI Class Initialized
INFO - 2023-06-13 06:13:43 --> Router Class Initialized
INFO - 2023-06-13 06:13:43 --> Output Class Initialized
INFO - 2023-06-13 06:13:43 --> Security Class Initialized
INFO - 2023-06-13 06:13:43 --> Input Class Initialized
INFO - 2023-06-13 06:13:43 --> Language Class Initialized
INFO - 2023-06-13 06:13:43 --> Loader Class Initialized
INFO - 2023-06-13 06:13:43 --> Helper loaded: url_helper
INFO - 2023-06-13 06:13:43 --> Helper loaded: form_helper
INFO - 2023-06-13 06:13:43 --> Database Driver Class Initialized
INFO - 2023-06-13 06:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:13:43 --> Form Validation Class Initialized
INFO - 2023-06-13 06:13:43 --> Controller Class Initialized
INFO - 2023-06-13 06:13:43 --> Model "m_user" initialized
INFO - 2023-06-13 06:13:43 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:13:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:13:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:13:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:13:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:13:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:13:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-13 06:13:43 --> Final output sent to browser
INFO - 2023-06-13 06:13:47 --> Config Class Initialized
INFO - 2023-06-13 06:13:47 --> Hooks Class Initialized
INFO - 2023-06-13 06:13:47 --> Utf8 Class Initialized
INFO - 2023-06-13 06:13:47 --> URI Class Initialized
INFO - 2023-06-13 06:13:47 --> Router Class Initialized
INFO - 2023-06-13 06:13:47 --> Output Class Initialized
INFO - 2023-06-13 06:13:47 --> Security Class Initialized
INFO - 2023-06-13 06:13:47 --> Input Class Initialized
INFO - 2023-06-13 06:13:47 --> Language Class Initialized
INFO - 2023-06-13 06:13:47 --> Loader Class Initialized
INFO - 2023-06-13 06:13:47 --> Helper loaded: url_helper
INFO - 2023-06-13 06:13:47 --> Helper loaded: form_helper
INFO - 2023-06-13 06:13:47 --> Database Driver Class Initialized
INFO - 2023-06-13 06:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:13:47 --> Form Validation Class Initialized
INFO - 2023-06-13 06:13:47 --> Controller Class Initialized
INFO - 2023-06-13 06:13:47 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-13 06:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:13:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:13:47 --> Final output sent to browser
INFO - 2023-06-13 06:15:10 --> Config Class Initialized
INFO - 2023-06-13 06:15:10 --> Hooks Class Initialized
INFO - 2023-06-13 06:15:10 --> Utf8 Class Initialized
INFO - 2023-06-13 06:15:10 --> URI Class Initialized
INFO - 2023-06-13 06:15:10 --> Router Class Initialized
INFO - 2023-06-13 06:15:10 --> Output Class Initialized
INFO - 2023-06-13 06:15:10 --> Security Class Initialized
INFO - 2023-06-13 06:15:10 --> Input Class Initialized
INFO - 2023-06-13 06:15:10 --> Language Class Initialized
INFO - 2023-06-13 06:15:10 --> Loader Class Initialized
INFO - 2023-06-13 06:15:10 --> Helper loaded: url_helper
INFO - 2023-06-13 06:15:10 --> Helper loaded: form_helper
INFO - 2023-06-13 06:15:10 --> Database Driver Class Initialized
INFO - 2023-06-13 06:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:15:10 --> Form Validation Class Initialized
INFO - 2023-06-13 06:15:10 --> Controller Class Initialized
INFO - 2023-06-13 06:15:10 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:15:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:15:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:15:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-13 06:15:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:15:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:15:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:15:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:15:10 --> Final output sent to browser
INFO - 2023-06-13 06:15:14 --> Config Class Initialized
INFO - 2023-06-13 06:15:14 --> Hooks Class Initialized
INFO - 2023-06-13 06:15:14 --> Utf8 Class Initialized
INFO - 2023-06-13 06:15:14 --> URI Class Initialized
INFO - 2023-06-13 06:15:14 --> Router Class Initialized
INFO - 2023-06-13 06:15:14 --> Output Class Initialized
INFO - 2023-06-13 06:15:14 --> Security Class Initialized
INFO - 2023-06-13 06:15:14 --> Input Class Initialized
INFO - 2023-06-13 06:15:14 --> Language Class Initialized
INFO - 2023-06-13 06:15:14 --> Loader Class Initialized
INFO - 2023-06-13 06:15:14 --> Helper loaded: url_helper
INFO - 2023-06-13 06:15:14 --> Helper loaded: form_helper
INFO - 2023-06-13 06:15:14 --> Database Driver Class Initialized
INFO - 2023-06-13 06:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:15:14 --> Form Validation Class Initialized
INFO - 2023-06-13 06:15:14 --> Controller Class Initialized
INFO - 2023-06-13 06:15:14 --> Model "m_user" initialized
INFO - 2023-06-13 06:15:14 --> Config Class Initialized
INFO - 2023-06-13 06:15:14 --> Hooks Class Initialized
INFO - 2023-06-13 06:15:14 --> Utf8 Class Initialized
INFO - 2023-06-13 06:15:14 --> URI Class Initialized
INFO - 2023-06-13 06:15:14 --> Router Class Initialized
INFO - 2023-06-13 06:15:14 --> Output Class Initialized
INFO - 2023-06-13 06:15:14 --> Security Class Initialized
INFO - 2023-06-13 06:15:14 --> Input Class Initialized
INFO - 2023-06-13 06:15:14 --> Language Class Initialized
INFO - 2023-06-13 06:15:14 --> Loader Class Initialized
INFO - 2023-06-13 06:15:14 --> Helper loaded: url_helper
INFO - 2023-06-13 06:15:14 --> Helper loaded: form_helper
INFO - 2023-06-13 06:15:14 --> Database Driver Class Initialized
INFO - 2023-06-13 06:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:15:14 --> Form Validation Class Initialized
INFO - 2023-06-13 06:15:14 --> Controller Class Initialized
INFO - 2023-06-13 06:15:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-13 06:15:14 --> Final output sent to browser
INFO - 2023-06-13 06:15:16 --> Config Class Initialized
INFO - 2023-06-13 06:15:16 --> Hooks Class Initialized
INFO - 2023-06-13 06:15:16 --> Utf8 Class Initialized
INFO - 2023-06-13 06:15:16 --> URI Class Initialized
INFO - 2023-06-13 06:15:16 --> Router Class Initialized
INFO - 2023-06-13 06:15:16 --> Output Class Initialized
INFO - 2023-06-13 06:15:16 --> Security Class Initialized
INFO - 2023-06-13 06:15:16 --> Input Class Initialized
INFO - 2023-06-13 06:15:16 --> Language Class Initialized
INFO - 2023-06-13 06:15:16 --> Loader Class Initialized
INFO - 2023-06-13 06:15:16 --> Helper loaded: url_helper
INFO - 2023-06-13 06:15:16 --> Helper loaded: form_helper
INFO - 2023-06-13 06:15:16 --> Database Driver Class Initialized
INFO - 2023-06-13 06:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:15:16 --> Form Validation Class Initialized
INFO - 2023-06-13 06:15:16 --> Controller Class Initialized
INFO - 2023-06-13 06:15:16 --> Model "m_user" initialized
INFO - 2023-06-13 06:15:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:15:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:15:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 06:15:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:15:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:15:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-13 06:15:16 --> Final output sent to browser
INFO - 2023-06-13 06:15:19 --> Config Class Initialized
INFO - 2023-06-13 06:15:19 --> Hooks Class Initialized
INFO - 2023-06-13 06:15:19 --> Utf8 Class Initialized
INFO - 2023-06-13 06:15:19 --> URI Class Initialized
INFO - 2023-06-13 06:15:19 --> Router Class Initialized
INFO - 2023-06-13 06:15:19 --> Output Class Initialized
INFO - 2023-06-13 06:15:19 --> Security Class Initialized
INFO - 2023-06-13 06:15:19 --> Input Class Initialized
INFO - 2023-06-13 06:15:19 --> Language Class Initialized
INFO - 2023-06-13 06:15:19 --> Loader Class Initialized
INFO - 2023-06-13 06:15:19 --> Helper loaded: url_helper
INFO - 2023-06-13 06:15:19 --> Helper loaded: form_helper
INFO - 2023-06-13 06:15:19 --> Database Driver Class Initialized
INFO - 2023-06-13 06:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:15:19 --> Form Validation Class Initialized
INFO - 2023-06-13 06:15:19 --> Controller Class Initialized
INFO - 2023-06-13 06:15:19 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:15:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:15:19 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:15:19 --> Model "M_solusi" initialized
INFO - 2023-06-13 06:15:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:15:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:15:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-13 06:15:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 06:15:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:15:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:15:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-13 06:15:19 --> Final output sent to browser
INFO - 2023-06-13 06:15:21 --> Config Class Initialized
INFO - 2023-06-13 06:15:21 --> Hooks Class Initialized
INFO - 2023-06-13 06:15:21 --> Utf8 Class Initialized
INFO - 2023-06-13 06:15:21 --> URI Class Initialized
INFO - 2023-06-13 06:15:21 --> Router Class Initialized
INFO - 2023-06-13 06:15:21 --> Output Class Initialized
INFO - 2023-06-13 06:15:21 --> Security Class Initialized
INFO - 2023-06-13 06:15:21 --> Input Class Initialized
INFO - 2023-06-13 06:15:21 --> Language Class Initialized
INFO - 2023-06-13 06:15:21 --> Loader Class Initialized
INFO - 2023-06-13 06:15:21 --> Helper loaded: url_helper
INFO - 2023-06-13 06:15:21 --> Helper loaded: form_helper
INFO - 2023-06-13 06:15:21 --> Database Driver Class Initialized
INFO - 2023-06-13 06:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:15:21 --> Form Validation Class Initialized
INFO - 2023-06-13 06:15:21 --> Controller Class Initialized
INFO - 2023-06-13 06:15:21 --> Model "m_user" initialized
INFO - 2023-06-13 06:15:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:15:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:15:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 06:15:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:15:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:15:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-13 06:15:21 --> Final output sent to browser
INFO - 2023-06-13 06:15:29 --> Config Class Initialized
INFO - 2023-06-13 06:15:29 --> Hooks Class Initialized
INFO - 2023-06-13 06:15:29 --> Utf8 Class Initialized
INFO - 2023-06-13 06:15:29 --> URI Class Initialized
INFO - 2023-06-13 06:15:29 --> Router Class Initialized
INFO - 2023-06-13 06:15:29 --> Output Class Initialized
INFO - 2023-06-13 06:15:29 --> Security Class Initialized
INFO - 2023-06-13 06:15:29 --> Input Class Initialized
INFO - 2023-06-13 06:15:29 --> Language Class Initialized
INFO - 2023-06-13 06:15:29 --> Loader Class Initialized
INFO - 2023-06-13 06:15:29 --> Helper loaded: url_helper
INFO - 2023-06-13 06:15:29 --> Helper loaded: form_helper
INFO - 2023-06-13 06:15:29 --> Database Driver Class Initialized
INFO - 2023-06-13 06:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:15:29 --> Form Validation Class Initialized
INFO - 2023-06-13 06:15:29 --> Controller Class Initialized
INFO - 2023-06-13 06:15:29 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:15:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:15:29 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:15:29 --> Model "M_solusi" initialized
INFO - 2023-06-13 06:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-13 06:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 06:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:15:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-13 06:15:29 --> Final output sent to browser
INFO - 2023-06-13 06:16:41 --> Config Class Initialized
INFO - 2023-06-13 06:16:41 --> Hooks Class Initialized
INFO - 2023-06-13 06:16:41 --> Utf8 Class Initialized
INFO - 2023-06-13 06:16:41 --> URI Class Initialized
INFO - 2023-06-13 06:16:41 --> Router Class Initialized
INFO - 2023-06-13 06:16:41 --> Output Class Initialized
INFO - 2023-06-13 06:16:41 --> Security Class Initialized
INFO - 2023-06-13 06:16:41 --> Input Class Initialized
INFO - 2023-06-13 06:16:41 --> Language Class Initialized
INFO - 2023-06-13 06:16:41 --> Loader Class Initialized
INFO - 2023-06-13 06:16:41 --> Helper loaded: url_helper
INFO - 2023-06-13 06:16:41 --> Helper loaded: form_helper
INFO - 2023-06-13 06:16:41 --> Database Driver Class Initialized
INFO - 2023-06-13 06:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:16:41 --> Form Validation Class Initialized
INFO - 2023-06-13 06:16:41 --> Controller Class Initialized
INFO - 2023-06-13 06:16:41 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:16:41 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:16:41 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:16:41 --> Model "M_solusi" initialized
INFO - 2023-06-13 06:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-13 06:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 06:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-13 06:16:42 --> Final output sent to browser
INFO - 2023-06-13 06:16:56 --> Config Class Initialized
INFO - 2023-06-13 06:16:56 --> Hooks Class Initialized
INFO - 2023-06-13 06:16:56 --> Utf8 Class Initialized
INFO - 2023-06-13 06:16:56 --> URI Class Initialized
INFO - 2023-06-13 06:16:56 --> Router Class Initialized
INFO - 2023-06-13 06:16:56 --> Output Class Initialized
INFO - 2023-06-13 06:16:56 --> Security Class Initialized
INFO - 2023-06-13 06:16:56 --> Input Class Initialized
INFO - 2023-06-13 06:16:56 --> Language Class Initialized
INFO - 2023-06-13 06:16:56 --> Loader Class Initialized
INFO - 2023-06-13 06:16:56 --> Helper loaded: url_helper
INFO - 2023-06-13 06:16:56 --> Helper loaded: form_helper
INFO - 2023-06-13 06:16:56 --> Database Driver Class Initialized
INFO - 2023-06-13 06:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:16:56 --> Form Validation Class Initialized
INFO - 2023-06-13 06:16:56 --> Controller Class Initialized
INFO - 2023-06-13 06:16:56 --> Model "m_user" initialized
INFO - 2023-06-13 06:16:56 --> Config Class Initialized
INFO - 2023-06-13 06:16:56 --> Hooks Class Initialized
INFO - 2023-06-13 06:16:56 --> Utf8 Class Initialized
INFO - 2023-06-13 06:16:56 --> URI Class Initialized
INFO - 2023-06-13 06:16:56 --> Router Class Initialized
INFO - 2023-06-13 06:16:56 --> Output Class Initialized
INFO - 2023-06-13 06:16:56 --> Security Class Initialized
INFO - 2023-06-13 06:16:56 --> Input Class Initialized
INFO - 2023-06-13 06:16:56 --> Language Class Initialized
INFO - 2023-06-13 06:16:56 --> Loader Class Initialized
INFO - 2023-06-13 06:16:56 --> Helper loaded: url_helper
INFO - 2023-06-13 06:16:56 --> Helper loaded: form_helper
INFO - 2023-06-13 06:16:56 --> Database Driver Class Initialized
INFO - 2023-06-13 06:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:16:56 --> Form Validation Class Initialized
INFO - 2023-06-13 06:16:56 --> Controller Class Initialized
INFO - 2023-06-13 06:16:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-13 06:16:56 --> Final output sent to browser
INFO - 2023-06-13 06:16:58 --> Config Class Initialized
INFO - 2023-06-13 06:16:58 --> Hooks Class Initialized
INFO - 2023-06-13 06:16:58 --> Utf8 Class Initialized
INFO - 2023-06-13 06:16:58 --> URI Class Initialized
INFO - 2023-06-13 06:16:58 --> Router Class Initialized
INFO - 2023-06-13 06:16:58 --> Output Class Initialized
INFO - 2023-06-13 06:16:58 --> Security Class Initialized
INFO - 2023-06-13 06:16:58 --> Input Class Initialized
INFO - 2023-06-13 06:16:58 --> Language Class Initialized
INFO - 2023-06-13 06:16:58 --> Loader Class Initialized
INFO - 2023-06-13 06:16:58 --> Helper loaded: url_helper
INFO - 2023-06-13 06:16:58 --> Helper loaded: form_helper
INFO - 2023-06-13 06:16:58 --> Database Driver Class Initialized
INFO - 2023-06-13 06:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:16:58 --> Form Validation Class Initialized
INFO - 2023-06-13 06:16:58 --> Controller Class Initialized
INFO - 2023-06-13 06:16:58 --> Model "m_user" initialized
INFO - 2023-06-13 06:16:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-13 06:16:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-13 06:16:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-13 06:16:58 --> Final output sent to browser
INFO - 2023-06-13 06:17:02 --> Config Class Initialized
INFO - 2023-06-13 06:17:02 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:02 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:02 --> URI Class Initialized
INFO - 2023-06-13 06:17:02 --> Router Class Initialized
INFO - 2023-06-13 06:17:02 --> Output Class Initialized
INFO - 2023-06-13 06:17:02 --> Security Class Initialized
INFO - 2023-06-13 06:17:02 --> Input Class Initialized
INFO - 2023-06-13 06:17:02 --> Language Class Initialized
INFO - 2023-06-13 06:17:02 --> Loader Class Initialized
INFO - 2023-06-13 06:17:02 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:02 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:02 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:02 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:02 --> Controller Class Initialized
INFO - 2023-06-13 06:17:02 --> Model "m_user" initialized
INFO - 2023-06-13 06:17:02 --> Config Class Initialized
INFO - 2023-06-13 06:17:02 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:02 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:02 --> URI Class Initialized
INFO - 2023-06-13 06:17:02 --> Router Class Initialized
INFO - 2023-06-13 06:17:02 --> Output Class Initialized
INFO - 2023-06-13 06:17:02 --> Security Class Initialized
INFO - 2023-06-13 06:17:02 --> Input Class Initialized
INFO - 2023-06-13 06:17:02 --> Language Class Initialized
INFO - 2023-06-13 06:17:02 --> Loader Class Initialized
INFO - 2023-06-13 06:17:02 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:02 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:02 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:02 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:02 --> Controller Class Initialized
INFO - 2023-06-13 06:17:02 --> Model "m_user" initialized
INFO - 2023-06-13 06:17:02 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-13 06:17:02 --> Final output sent to browser
INFO - 2023-06-13 06:17:04 --> Config Class Initialized
INFO - 2023-06-13 06:17:04 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:04 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:04 --> URI Class Initialized
INFO - 2023-06-13 06:17:04 --> Router Class Initialized
INFO - 2023-06-13 06:17:04 --> Output Class Initialized
INFO - 2023-06-13 06:17:04 --> Security Class Initialized
INFO - 2023-06-13 06:17:04 --> Input Class Initialized
INFO - 2023-06-13 06:17:04 --> Language Class Initialized
INFO - 2023-06-13 06:17:04 --> Loader Class Initialized
INFO - 2023-06-13 06:17:04 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:04 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:04 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:04 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:04 --> Controller Class Initialized
INFO - 2023-06-13 06:17:04 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:17:04 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:17:04 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:17:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:17:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:17:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-13 06:17:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:17:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:17:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:17:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:17:04 --> Final output sent to browser
INFO - 2023-06-13 06:17:10 --> Config Class Initialized
INFO - 2023-06-13 06:17:10 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:10 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:10 --> URI Class Initialized
INFO - 2023-06-13 06:17:10 --> Router Class Initialized
INFO - 2023-06-13 06:17:10 --> Output Class Initialized
INFO - 2023-06-13 06:17:10 --> Security Class Initialized
INFO - 2023-06-13 06:17:10 --> Input Class Initialized
INFO - 2023-06-13 06:17:10 --> Language Class Initialized
INFO - 2023-06-13 06:17:10 --> Loader Class Initialized
INFO - 2023-06-13 06:17:10 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:10 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:10 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:10 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:10 --> Controller Class Initialized
INFO - 2023-06-13 06:17:10 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:17:10 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:17:10 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:17:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:17:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:17:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-13 06:17:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:17:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:17:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:17:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:17:10 --> Final output sent to browser
INFO - 2023-06-13 06:17:19 --> Config Class Initialized
INFO - 2023-06-13 06:17:19 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:19 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:19 --> URI Class Initialized
INFO - 2023-06-13 06:17:19 --> Router Class Initialized
INFO - 2023-06-13 06:17:19 --> Output Class Initialized
INFO - 2023-06-13 06:17:19 --> Security Class Initialized
INFO - 2023-06-13 06:17:19 --> Input Class Initialized
INFO - 2023-06-13 06:17:19 --> Language Class Initialized
INFO - 2023-06-13 06:17:19 --> Loader Class Initialized
INFO - 2023-06-13 06:17:19 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:19 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:19 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:19 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:19 --> Controller Class Initialized
INFO - 2023-06-13 06:17:19 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:17:19 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:17:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:17:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:17:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:17:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-13 06:17:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:17:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:17:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:17:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:17:19 --> Final output sent to browser
INFO - 2023-06-13 06:17:30 --> Config Class Initialized
INFO - 2023-06-13 06:17:30 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:30 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:30 --> URI Class Initialized
INFO - 2023-06-13 06:17:30 --> Router Class Initialized
INFO - 2023-06-13 06:17:30 --> Output Class Initialized
INFO - 2023-06-13 06:17:30 --> Security Class Initialized
INFO - 2023-06-13 06:17:30 --> Input Class Initialized
INFO - 2023-06-13 06:17:30 --> Language Class Initialized
INFO - 2023-06-13 06:17:30 --> Loader Class Initialized
INFO - 2023-06-13 06:17:30 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:31 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:31 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:31 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:31 --> Controller Class Initialized
INFO - 2023-06-13 06:17:31 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:17:31 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:17:31 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-13 06:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:17:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:17:31 --> Final output sent to browser
INFO - 2023-06-13 06:17:33 --> Config Class Initialized
INFO - 2023-06-13 06:17:33 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:33 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:33 --> URI Class Initialized
INFO - 2023-06-13 06:17:33 --> Router Class Initialized
INFO - 2023-06-13 06:17:33 --> Output Class Initialized
INFO - 2023-06-13 06:17:33 --> Security Class Initialized
INFO - 2023-06-13 06:17:33 --> Input Class Initialized
INFO - 2023-06-13 06:17:33 --> Language Class Initialized
INFO - 2023-06-13 06:17:33 --> Loader Class Initialized
INFO - 2023-06-13 06:17:33 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:33 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:33 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:33 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:33 --> Controller Class Initialized
INFO - 2023-06-13 06:17:33 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:17:33 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:17:33 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:17:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:17:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:17:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-13 06:17:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:17:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:17:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:17:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:17:33 --> Final output sent to browser
INFO - 2023-06-13 06:17:34 --> Config Class Initialized
INFO - 2023-06-13 06:17:34 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:34 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:34 --> URI Class Initialized
INFO - 2023-06-13 06:17:34 --> Router Class Initialized
INFO - 2023-06-13 06:17:34 --> Output Class Initialized
INFO - 2023-06-13 06:17:34 --> Security Class Initialized
INFO - 2023-06-13 06:17:34 --> Input Class Initialized
INFO - 2023-06-13 06:17:34 --> Language Class Initialized
INFO - 2023-06-13 06:17:35 --> Loader Class Initialized
INFO - 2023-06-13 06:17:35 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:35 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:35 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:35 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:35 --> Controller Class Initialized
INFO - 2023-06-13 06:17:35 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:17:35 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:17:35 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-13 06:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:17:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:17:35 --> Final output sent to browser
INFO - 2023-06-13 06:17:41 --> Config Class Initialized
INFO - 2023-06-13 06:17:41 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:41 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:41 --> URI Class Initialized
INFO - 2023-06-13 06:17:41 --> Router Class Initialized
INFO - 2023-06-13 06:17:41 --> Output Class Initialized
INFO - 2023-06-13 06:17:41 --> Security Class Initialized
INFO - 2023-06-13 06:17:41 --> Input Class Initialized
INFO - 2023-06-13 06:17:41 --> Language Class Initialized
INFO - 2023-06-13 06:17:41 --> Loader Class Initialized
INFO - 2023-06-13 06:17:41 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:41 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:41 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:41 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:41 --> Controller Class Initialized
INFO - 2023-06-13 06:17:41 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:17:41 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:17:41 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:17:41 --> Config Class Initialized
INFO - 2023-06-13 06:17:41 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:41 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:41 --> URI Class Initialized
INFO - 2023-06-13 06:17:41 --> Router Class Initialized
INFO - 2023-06-13 06:17:41 --> Output Class Initialized
INFO - 2023-06-13 06:17:41 --> Security Class Initialized
INFO - 2023-06-13 06:17:41 --> Input Class Initialized
INFO - 2023-06-13 06:17:41 --> Language Class Initialized
INFO - 2023-06-13 06:17:41 --> Loader Class Initialized
INFO - 2023-06-13 06:17:41 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:41 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:41 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:41 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:41 --> Controller Class Initialized
INFO - 2023-06-13 06:17:41 --> Model "m_datatest" initialized
INFO - 2023-06-13 06:17:41 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:17:41 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 06:17:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:17:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:17:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_addData.php
INFO - 2023-06-13 06:17:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:17:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:17:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:17:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:17:41 --> Final output sent to browser
INFO - 2023-06-13 06:17:48 --> Config Class Initialized
INFO - 2023-06-13 06:17:48 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:48 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:48 --> URI Class Initialized
INFO - 2023-06-13 06:17:48 --> Router Class Initialized
INFO - 2023-06-13 06:17:48 --> Output Class Initialized
INFO - 2023-06-13 06:17:48 --> Security Class Initialized
INFO - 2023-06-13 06:17:48 --> Input Class Initialized
INFO - 2023-06-13 06:17:48 --> Language Class Initialized
INFO - 2023-06-13 06:17:48 --> Loader Class Initialized
INFO - 2023-06-13 06:17:48 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:48 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:48 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:48 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:48 --> Controller Class Initialized
INFO - 2023-06-13 06:17:48 --> Model "m_datatrain" initialized
INFO - 2023-06-13 06:17:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 06:17:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 06:17:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-13 06:17:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 06:17:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 06:17:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 06:17:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 06:17:49 --> Final output sent to browser
INFO - 2023-06-13 06:17:52 --> Config Class Initialized
INFO - 2023-06-13 06:17:52 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:52 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:52 --> URI Class Initialized
INFO - 2023-06-13 06:17:52 --> Router Class Initialized
INFO - 2023-06-13 06:17:52 --> Output Class Initialized
INFO - 2023-06-13 06:17:52 --> Security Class Initialized
INFO - 2023-06-13 06:17:52 --> Input Class Initialized
INFO - 2023-06-13 06:17:52 --> Language Class Initialized
INFO - 2023-06-13 06:17:52 --> Loader Class Initialized
INFO - 2023-06-13 06:17:52 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:52 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:52 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:52 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:52 --> Controller Class Initialized
INFO - 2023-06-13 06:17:52 --> Model "m_user" initialized
INFO - 2023-06-13 06:17:52 --> Config Class Initialized
INFO - 2023-06-13 06:17:52 --> Hooks Class Initialized
INFO - 2023-06-13 06:17:52 --> Utf8 Class Initialized
INFO - 2023-06-13 06:17:52 --> URI Class Initialized
INFO - 2023-06-13 06:17:52 --> Router Class Initialized
INFO - 2023-06-13 06:17:52 --> Output Class Initialized
INFO - 2023-06-13 06:17:52 --> Security Class Initialized
INFO - 2023-06-13 06:17:52 --> Input Class Initialized
INFO - 2023-06-13 06:17:52 --> Language Class Initialized
INFO - 2023-06-13 06:17:52 --> Loader Class Initialized
INFO - 2023-06-13 06:17:52 --> Helper loaded: url_helper
INFO - 2023-06-13 06:17:52 --> Helper loaded: form_helper
INFO - 2023-06-13 06:17:52 --> Database Driver Class Initialized
INFO - 2023-06-13 06:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 06:17:52 --> Form Validation Class Initialized
INFO - 2023-06-13 06:17:52 --> Controller Class Initialized
INFO - 2023-06-13 06:17:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-13 06:17:52 --> Final output sent to browser
INFO - 2023-06-13 07:24:01 --> Config Class Initialized
INFO - 2023-06-13 07:24:01 --> Hooks Class Initialized
INFO - 2023-06-13 07:24:01 --> Utf8 Class Initialized
INFO - 2023-06-13 07:24:01 --> URI Class Initialized
INFO - 2023-06-13 07:24:01 --> Router Class Initialized
INFO - 2023-06-13 07:24:01 --> Output Class Initialized
INFO - 2023-06-13 07:24:01 --> Security Class Initialized
INFO - 2023-06-13 07:24:01 --> Input Class Initialized
INFO - 2023-06-13 07:24:01 --> Language Class Initialized
INFO - 2023-06-13 07:24:01 --> Loader Class Initialized
INFO - 2023-06-13 07:24:01 --> Helper loaded: url_helper
INFO - 2023-06-13 07:24:01 --> Helper loaded: form_helper
INFO - 2023-06-13 07:24:01 --> Database Driver Class Initialized
INFO - 2023-06-13 07:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:24:01 --> Form Validation Class Initialized
INFO - 2023-06-13 07:24:01 --> Controller Class Initialized
INFO - 2023-06-13 07:24:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-13 07:24:01 --> Final output sent to browser
INFO - 2023-06-13 07:26:58 --> Config Class Initialized
INFO - 2023-06-13 07:26:58 --> Hooks Class Initialized
INFO - 2023-06-13 07:26:58 --> Utf8 Class Initialized
INFO - 2023-06-13 07:26:58 --> URI Class Initialized
INFO - 2023-06-13 07:26:58 --> Router Class Initialized
INFO - 2023-06-13 07:26:58 --> Output Class Initialized
INFO - 2023-06-13 07:26:58 --> Security Class Initialized
INFO - 2023-06-13 07:26:58 --> Input Class Initialized
INFO - 2023-06-13 07:26:58 --> Language Class Initialized
INFO - 2023-06-13 07:26:58 --> Loader Class Initialized
INFO - 2023-06-13 07:26:58 --> Helper loaded: url_helper
INFO - 2023-06-13 07:26:58 --> Helper loaded: form_helper
INFO - 2023-06-13 07:26:58 --> Database Driver Class Initialized
INFO - 2023-06-13 07:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:26:58 --> Form Validation Class Initialized
INFO - 2023-06-13 07:26:58 --> Controller Class Initialized
INFO - 2023-06-13 07:26:58 --> Model "m_user" initialized
INFO - 2023-06-13 07:26:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-13 07:26:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-13 07:26:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-13 07:26:58 --> Final output sent to browser
INFO - 2023-06-13 07:27:07 --> Config Class Initialized
INFO - 2023-06-13 07:27:07 --> Hooks Class Initialized
INFO - 2023-06-13 07:27:07 --> Utf8 Class Initialized
INFO - 2023-06-13 07:27:07 --> URI Class Initialized
INFO - 2023-06-13 07:27:07 --> Router Class Initialized
INFO - 2023-06-13 07:27:07 --> Output Class Initialized
INFO - 2023-06-13 07:27:07 --> Security Class Initialized
INFO - 2023-06-13 07:27:07 --> Input Class Initialized
INFO - 2023-06-13 07:27:07 --> Language Class Initialized
INFO - 2023-06-13 07:27:07 --> Loader Class Initialized
INFO - 2023-06-13 07:27:07 --> Helper loaded: url_helper
INFO - 2023-06-13 07:27:07 --> Helper loaded: form_helper
INFO - 2023-06-13 07:27:07 --> Database Driver Class Initialized
INFO - 2023-06-13 07:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:27:07 --> Form Validation Class Initialized
INFO - 2023-06-13 07:27:07 --> Controller Class Initialized
INFO - 2023-06-13 07:27:07 --> Model "m_user" initialized
INFO - 2023-06-13 07:27:07 --> Config Class Initialized
INFO - 2023-06-13 07:27:07 --> Hooks Class Initialized
INFO - 2023-06-13 07:27:07 --> Utf8 Class Initialized
INFO - 2023-06-13 07:27:07 --> URI Class Initialized
INFO - 2023-06-13 07:27:07 --> Router Class Initialized
INFO - 2023-06-13 07:27:07 --> Output Class Initialized
INFO - 2023-06-13 07:27:07 --> Security Class Initialized
INFO - 2023-06-13 07:27:07 --> Input Class Initialized
INFO - 2023-06-13 07:27:07 --> Language Class Initialized
INFO - 2023-06-13 07:27:07 --> Loader Class Initialized
INFO - 2023-06-13 07:27:07 --> Helper loaded: url_helper
INFO - 2023-06-13 07:27:07 --> Helper loaded: form_helper
INFO - 2023-06-13 07:27:07 --> Database Driver Class Initialized
INFO - 2023-06-13 07:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:27:07 --> Form Validation Class Initialized
INFO - 2023-06-13 07:27:07 --> Controller Class Initialized
INFO - 2023-06-13 07:27:07 --> Model "m_user" initialized
INFO - 2023-06-13 07:27:07 --> Model "m_datatrain" initialized
INFO - 2023-06-13 07:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 07:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-13 07:27:07 --> Final output sent to browser
INFO - 2023-06-13 07:30:38 --> Config Class Initialized
INFO - 2023-06-13 07:30:38 --> Hooks Class Initialized
INFO - 2023-06-13 07:30:38 --> Utf8 Class Initialized
INFO - 2023-06-13 07:30:38 --> URI Class Initialized
INFO - 2023-06-13 07:30:38 --> Router Class Initialized
INFO - 2023-06-13 07:30:38 --> Output Class Initialized
INFO - 2023-06-13 07:30:38 --> Security Class Initialized
INFO - 2023-06-13 07:30:38 --> Input Class Initialized
INFO - 2023-06-13 07:30:38 --> Language Class Initialized
INFO - 2023-06-13 07:30:38 --> Loader Class Initialized
INFO - 2023-06-13 07:30:38 --> Helper loaded: url_helper
INFO - 2023-06-13 07:30:38 --> Helper loaded: form_helper
INFO - 2023-06-13 07:30:38 --> Database Driver Class Initialized
INFO - 2023-06-13 07:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:30:38 --> Form Validation Class Initialized
INFO - 2023-06-13 07:30:38 --> Controller Class Initialized
INFO - 2023-06-13 07:30:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-13 07:30:38 --> Final output sent to browser
INFO - 2023-06-13 07:30:40 --> Config Class Initialized
INFO - 2023-06-13 07:30:40 --> Hooks Class Initialized
INFO - 2023-06-13 07:30:40 --> Utf8 Class Initialized
INFO - 2023-06-13 07:30:40 --> URI Class Initialized
INFO - 2023-06-13 07:30:40 --> Router Class Initialized
INFO - 2023-06-13 07:30:40 --> Output Class Initialized
INFO - 2023-06-13 07:30:40 --> Security Class Initialized
INFO - 2023-06-13 07:30:40 --> Input Class Initialized
INFO - 2023-06-13 07:30:40 --> Language Class Initialized
INFO - 2023-06-13 07:30:40 --> Loader Class Initialized
INFO - 2023-06-13 07:30:40 --> Helper loaded: url_helper
INFO - 2023-06-13 07:30:40 --> Helper loaded: form_helper
INFO - 2023-06-13 07:30:40 --> Database Driver Class Initialized
INFO - 2023-06-13 07:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:30:40 --> Form Validation Class Initialized
INFO - 2023-06-13 07:30:40 --> Controller Class Initialized
INFO - 2023-06-13 07:30:40 --> Model "m_user" initialized
INFO - 2023-06-13 07:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 07:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-13 07:30:40 --> Final output sent to browser
INFO - 2023-06-13 07:30:42 --> Config Class Initialized
INFO - 2023-06-13 07:30:42 --> Hooks Class Initialized
INFO - 2023-06-13 07:30:42 --> Utf8 Class Initialized
INFO - 2023-06-13 07:30:42 --> URI Class Initialized
INFO - 2023-06-13 07:30:42 --> Router Class Initialized
INFO - 2023-06-13 07:30:42 --> Output Class Initialized
INFO - 2023-06-13 07:30:42 --> Security Class Initialized
INFO - 2023-06-13 07:30:42 --> Input Class Initialized
INFO - 2023-06-13 07:30:42 --> Language Class Initialized
INFO - 2023-06-13 07:30:42 --> Loader Class Initialized
INFO - 2023-06-13 07:30:42 --> Helper loaded: url_helper
INFO - 2023-06-13 07:30:42 --> Helper loaded: form_helper
INFO - 2023-06-13 07:30:42 --> Database Driver Class Initialized
INFO - 2023-06-13 07:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:30:42 --> Form Validation Class Initialized
INFO - 2023-06-13 07:30:42 --> Controller Class Initialized
INFO - 2023-06-13 07:30:42 --> Model "m_datatrain" initialized
INFO - 2023-06-13 07:30:42 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 07:30:42 --> Model "m_datatest" initialized
INFO - 2023-06-13 07:30:42 --> Model "M_solusi" initialized
INFO - 2023-06-13 07:30:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:30:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:30:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-13 07:30:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 07:30:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:30:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:30:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-13 07:30:42 --> Final output sent to browser
INFO - 2023-06-13 07:35:51 --> Config Class Initialized
INFO - 2023-06-13 07:35:51 --> Hooks Class Initialized
INFO - 2023-06-13 07:35:51 --> Utf8 Class Initialized
INFO - 2023-06-13 07:35:51 --> URI Class Initialized
INFO - 2023-06-13 07:35:51 --> Router Class Initialized
INFO - 2023-06-13 07:35:51 --> Output Class Initialized
INFO - 2023-06-13 07:35:51 --> Security Class Initialized
INFO - 2023-06-13 07:35:51 --> Input Class Initialized
INFO - 2023-06-13 07:35:51 --> Language Class Initialized
INFO - 2023-06-13 07:35:51 --> Loader Class Initialized
INFO - 2023-06-13 07:35:51 --> Helper loaded: url_helper
INFO - 2023-06-13 07:35:51 --> Helper loaded: form_helper
INFO - 2023-06-13 07:35:51 --> Database Driver Class Initialized
INFO - 2023-06-13 07:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:35:51 --> Form Validation Class Initialized
INFO - 2023-06-13 07:35:51 --> Controller Class Initialized
INFO - 2023-06-13 07:35:51 --> Model "m_datatest" initialized
INFO - 2023-06-13 07:35:51 --> Model "m_datatrain" initialized
INFO - 2023-06-13 07:35:51 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 07:35:51 --> Config Class Initialized
INFO - 2023-06-13 07:35:51 --> Hooks Class Initialized
INFO - 2023-06-13 07:35:51 --> Utf8 Class Initialized
INFO - 2023-06-13 07:35:51 --> URI Class Initialized
INFO - 2023-06-13 07:35:51 --> Router Class Initialized
INFO - 2023-06-13 07:35:51 --> Output Class Initialized
INFO - 2023-06-13 07:35:51 --> Security Class Initialized
INFO - 2023-06-13 07:35:51 --> Input Class Initialized
INFO - 2023-06-13 07:35:51 --> Language Class Initialized
INFO - 2023-06-13 07:35:51 --> Loader Class Initialized
INFO - 2023-06-13 07:35:51 --> Helper loaded: url_helper
INFO - 2023-06-13 07:35:51 --> Helper loaded: form_helper
INFO - 2023-06-13 07:35:51 --> Database Driver Class Initialized
INFO - 2023-06-13 07:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:35:51 --> Form Validation Class Initialized
INFO - 2023-06-13 07:35:51 --> Controller Class Initialized
INFO - 2023-06-13 07:35:51 --> Model "m_user" initialized
INFO - 2023-06-13 07:35:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-13 07:35:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-13 07:35:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-13 07:35:51 --> Final output sent to browser
INFO - 2023-06-13 07:36:03 --> Config Class Initialized
INFO - 2023-06-13 07:36:03 --> Hooks Class Initialized
INFO - 2023-06-13 07:36:03 --> Utf8 Class Initialized
INFO - 2023-06-13 07:36:03 --> URI Class Initialized
INFO - 2023-06-13 07:36:03 --> Router Class Initialized
INFO - 2023-06-13 07:36:03 --> Output Class Initialized
INFO - 2023-06-13 07:36:03 --> Security Class Initialized
INFO - 2023-06-13 07:36:03 --> Input Class Initialized
INFO - 2023-06-13 07:36:03 --> Language Class Initialized
INFO - 2023-06-13 07:36:03 --> Loader Class Initialized
INFO - 2023-06-13 07:36:03 --> Helper loaded: url_helper
INFO - 2023-06-13 07:36:03 --> Helper loaded: form_helper
INFO - 2023-06-13 07:36:03 --> Database Driver Class Initialized
INFO - 2023-06-13 07:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:36:03 --> Form Validation Class Initialized
INFO - 2023-06-13 07:36:03 --> Controller Class Initialized
INFO - 2023-06-13 07:36:03 --> Model "m_user" initialized
INFO - 2023-06-13 07:36:04 --> Config Class Initialized
INFO - 2023-06-13 07:36:04 --> Hooks Class Initialized
INFO - 2023-06-13 07:36:04 --> Utf8 Class Initialized
INFO - 2023-06-13 07:36:04 --> URI Class Initialized
INFO - 2023-06-13 07:36:04 --> Router Class Initialized
INFO - 2023-06-13 07:36:04 --> Output Class Initialized
INFO - 2023-06-13 07:36:04 --> Security Class Initialized
INFO - 2023-06-13 07:36:04 --> Input Class Initialized
INFO - 2023-06-13 07:36:04 --> Language Class Initialized
INFO - 2023-06-13 07:36:04 --> Loader Class Initialized
INFO - 2023-06-13 07:36:04 --> Helper loaded: url_helper
INFO - 2023-06-13 07:36:04 --> Helper loaded: form_helper
INFO - 2023-06-13 07:36:04 --> Database Driver Class Initialized
INFO - 2023-06-13 07:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:36:04 --> Form Validation Class Initialized
INFO - 2023-06-13 07:36:04 --> Controller Class Initialized
INFO - 2023-06-13 07:36:04 --> Model "m_user" initialized
INFO - 2023-06-13 07:36:04 --> Model "m_datatrain" initialized
INFO - 2023-06-13 07:36:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:36:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:36:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 07:36:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:36:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:36:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-13 07:36:04 --> Final output sent to browser
INFO - 2023-06-13 07:36:06 --> Config Class Initialized
INFO - 2023-06-13 07:36:06 --> Hooks Class Initialized
INFO - 2023-06-13 07:36:06 --> Utf8 Class Initialized
INFO - 2023-06-13 07:36:06 --> URI Class Initialized
INFO - 2023-06-13 07:36:06 --> Router Class Initialized
INFO - 2023-06-13 07:36:06 --> Output Class Initialized
INFO - 2023-06-13 07:36:06 --> Security Class Initialized
INFO - 2023-06-13 07:36:06 --> Input Class Initialized
INFO - 2023-06-13 07:36:06 --> Language Class Initialized
INFO - 2023-06-13 07:36:06 --> Loader Class Initialized
INFO - 2023-06-13 07:36:06 --> Helper loaded: url_helper
INFO - 2023-06-13 07:36:06 --> Helper loaded: form_helper
INFO - 2023-06-13 07:36:06 --> Database Driver Class Initialized
INFO - 2023-06-13 07:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:36:06 --> Form Validation Class Initialized
INFO - 2023-06-13 07:36:06 --> Controller Class Initialized
INFO - 2023-06-13 07:36:06 --> Model "m_datatest" initialized
INFO - 2023-06-13 07:36:06 --> Model "m_datatrain" initialized
INFO - 2023-06-13 07:36:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 07:36:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:36:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:36:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-13 07:36:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 07:36:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:36:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:36:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 07:36:06 --> Final output sent to browser
INFO - 2023-06-13 07:36:36 --> Config Class Initialized
INFO - 2023-06-13 07:36:36 --> Hooks Class Initialized
INFO - 2023-06-13 07:36:36 --> Utf8 Class Initialized
INFO - 2023-06-13 07:36:36 --> URI Class Initialized
INFO - 2023-06-13 07:36:36 --> Router Class Initialized
INFO - 2023-06-13 07:36:36 --> Output Class Initialized
INFO - 2023-06-13 07:36:36 --> Security Class Initialized
INFO - 2023-06-13 07:36:36 --> Input Class Initialized
INFO - 2023-06-13 07:36:36 --> Language Class Initialized
INFO - 2023-06-13 07:36:36 --> Loader Class Initialized
INFO - 2023-06-13 07:36:36 --> Helper loaded: url_helper
INFO - 2023-06-13 07:36:36 --> Helper loaded: form_helper
INFO - 2023-06-13 07:36:36 --> Database Driver Class Initialized
INFO - 2023-06-13 07:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:36:36 --> Form Validation Class Initialized
INFO - 2023-06-13 07:36:36 --> Controller Class Initialized
INFO - 2023-06-13 07:36:36 --> Model "m_datatest" initialized
INFO - 2023-06-13 07:36:36 --> Model "m_datatrain" initialized
INFO - 2023-06-13 07:36:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 07:36:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:36:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:36:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-13 07:36:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 07:36:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:36:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:36:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 07:36:36 --> Final output sent to browser
INFO - 2023-06-13 07:37:48 --> Config Class Initialized
INFO - 2023-06-13 07:37:48 --> Hooks Class Initialized
INFO - 2023-06-13 07:37:48 --> Utf8 Class Initialized
INFO - 2023-06-13 07:37:48 --> URI Class Initialized
INFO - 2023-06-13 07:37:48 --> Router Class Initialized
INFO - 2023-06-13 07:37:48 --> Output Class Initialized
INFO - 2023-06-13 07:37:48 --> Security Class Initialized
INFO - 2023-06-13 07:37:48 --> Input Class Initialized
INFO - 2023-06-13 07:37:48 --> Language Class Initialized
INFO - 2023-06-13 07:37:48 --> Loader Class Initialized
INFO - 2023-06-13 07:37:48 --> Helper loaded: url_helper
INFO - 2023-06-13 07:37:48 --> Helper loaded: form_helper
INFO - 2023-06-13 07:37:48 --> Database Driver Class Initialized
INFO - 2023-06-13 07:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:37:48 --> Form Validation Class Initialized
INFO - 2023-06-13 07:37:48 --> Controller Class Initialized
INFO - 2023-06-13 07:37:48 --> Model "m_datatest" initialized
INFO - 2023-06-13 07:37:48 --> Model "m_datatrain" initialized
INFO - 2023-06-13 07:37:48 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 07:37:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:37:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:37:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-13 07:37:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 07:37:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:37:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:37:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 07:37:48 --> Final output sent to browser
INFO - 2023-06-13 07:37:57 --> Config Class Initialized
INFO - 2023-06-13 07:37:57 --> Hooks Class Initialized
INFO - 2023-06-13 07:37:57 --> Utf8 Class Initialized
INFO - 2023-06-13 07:37:57 --> URI Class Initialized
INFO - 2023-06-13 07:37:57 --> Router Class Initialized
INFO - 2023-06-13 07:37:57 --> Output Class Initialized
INFO - 2023-06-13 07:37:57 --> Security Class Initialized
INFO - 2023-06-13 07:37:57 --> Input Class Initialized
INFO - 2023-06-13 07:37:57 --> Language Class Initialized
INFO - 2023-06-13 07:37:57 --> Loader Class Initialized
INFO - 2023-06-13 07:37:57 --> Helper loaded: url_helper
INFO - 2023-06-13 07:37:57 --> Helper loaded: form_helper
INFO - 2023-06-13 07:37:57 --> Database Driver Class Initialized
INFO - 2023-06-13 07:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:37:58 --> Form Validation Class Initialized
INFO - 2023-06-13 07:37:58 --> Controller Class Initialized
INFO - 2023-06-13 07:37:58 --> Model "m_datatest" initialized
INFO - 2023-06-13 07:37:58 --> Model "m_datatrain" initialized
INFO - 2023-06-13 07:37:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 07:37:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:37:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:37:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-13 07:37:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 07:37:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:37:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:37:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 07:37:58 --> Final output sent to browser
INFO - 2023-06-13 07:38:12 --> Config Class Initialized
INFO - 2023-06-13 07:38:12 --> Hooks Class Initialized
INFO - 2023-06-13 07:38:12 --> Utf8 Class Initialized
INFO - 2023-06-13 07:38:12 --> URI Class Initialized
INFO - 2023-06-13 07:38:12 --> Router Class Initialized
INFO - 2023-06-13 07:38:12 --> Output Class Initialized
INFO - 2023-06-13 07:38:12 --> Security Class Initialized
INFO - 2023-06-13 07:38:12 --> Input Class Initialized
INFO - 2023-06-13 07:38:12 --> Language Class Initialized
INFO - 2023-06-13 07:38:12 --> Loader Class Initialized
INFO - 2023-06-13 07:38:12 --> Helper loaded: url_helper
INFO - 2023-06-13 07:38:12 --> Helper loaded: form_helper
INFO - 2023-06-13 07:38:12 --> Database Driver Class Initialized
INFO - 2023-06-13 07:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:38:12 --> Form Validation Class Initialized
INFO - 2023-06-13 07:38:12 --> Controller Class Initialized
INFO - 2023-06-13 07:38:12 --> Model "m_datatrain" initialized
INFO - 2023-06-13 07:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-13 07:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 07:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 07:38:12 --> Final output sent to browser
INFO - 2023-06-13 07:38:25 --> Config Class Initialized
INFO - 2023-06-13 07:38:25 --> Hooks Class Initialized
INFO - 2023-06-13 07:38:25 --> Utf8 Class Initialized
INFO - 2023-06-13 07:38:25 --> URI Class Initialized
INFO - 2023-06-13 07:38:25 --> Router Class Initialized
INFO - 2023-06-13 07:38:25 --> Output Class Initialized
INFO - 2023-06-13 07:38:25 --> Security Class Initialized
INFO - 2023-06-13 07:38:25 --> Input Class Initialized
INFO - 2023-06-13 07:38:25 --> Language Class Initialized
INFO - 2023-06-13 07:38:25 --> Loader Class Initialized
INFO - 2023-06-13 07:38:25 --> Helper loaded: url_helper
INFO - 2023-06-13 07:38:25 --> Helper loaded: form_helper
INFO - 2023-06-13 07:38:25 --> Database Driver Class Initialized
INFO - 2023-06-13 07:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:38:25 --> Form Validation Class Initialized
INFO - 2023-06-13 07:38:25 --> Controller Class Initialized
INFO - 2023-06-13 07:38:25 --> Model "m_datatest" initialized
INFO - 2023-06-13 07:38:25 --> Model "m_datatrain" initialized
INFO - 2023-06-13 07:38:25 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 07:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-13 07:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 07:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 07:38:25 --> Final output sent to browser
INFO - 2023-06-13 07:38:29 --> Config Class Initialized
INFO - 2023-06-13 07:38:29 --> Hooks Class Initialized
INFO - 2023-06-13 07:38:29 --> Utf8 Class Initialized
INFO - 2023-06-13 07:38:29 --> URI Class Initialized
INFO - 2023-06-13 07:38:29 --> Router Class Initialized
INFO - 2023-06-13 07:38:29 --> Output Class Initialized
INFO - 2023-06-13 07:38:29 --> Security Class Initialized
INFO - 2023-06-13 07:38:29 --> Input Class Initialized
INFO - 2023-06-13 07:38:29 --> Language Class Initialized
INFO - 2023-06-13 07:38:29 --> Loader Class Initialized
INFO - 2023-06-13 07:38:29 --> Helper loaded: url_helper
INFO - 2023-06-13 07:38:29 --> Helper loaded: form_helper
INFO - 2023-06-13 07:38:29 --> Database Driver Class Initialized
INFO - 2023-06-13 07:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:38:29 --> Form Validation Class Initialized
INFO - 2023-06-13 07:38:29 --> Controller Class Initialized
INFO - 2023-06-13 07:38:29 --> Model "m_datatest" initialized
INFO - 2023-06-13 07:38:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:38:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:38:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-13 07:38:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-13 07:38:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:38:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:38:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-13 07:38:29 --> Final output sent to browser
INFO - 2023-06-13 07:39:15 --> Config Class Initialized
INFO - 2023-06-13 07:39:15 --> Hooks Class Initialized
INFO - 2023-06-13 07:39:15 --> Utf8 Class Initialized
INFO - 2023-06-13 07:39:15 --> URI Class Initialized
INFO - 2023-06-13 07:39:15 --> Router Class Initialized
INFO - 2023-06-13 07:39:15 --> Output Class Initialized
INFO - 2023-06-13 07:39:15 --> Security Class Initialized
INFO - 2023-06-13 07:39:15 --> Input Class Initialized
INFO - 2023-06-13 07:39:15 --> Language Class Initialized
INFO - 2023-06-13 07:39:15 --> Loader Class Initialized
INFO - 2023-06-13 07:39:15 --> Helper loaded: url_helper
INFO - 2023-06-13 07:39:15 --> Helper loaded: form_helper
INFO - 2023-06-13 07:39:15 --> Database Driver Class Initialized
INFO - 2023-06-13 07:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:39:15 --> Form Validation Class Initialized
INFO - 2023-06-13 07:39:15 --> Controller Class Initialized
INFO - 2023-06-13 07:39:15 --> Model "m_datatrain" initialized
INFO - 2023-06-13 07:39:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-13 07:39:15 --> Model "m_datatest" initialized
INFO - 2023-06-13 07:39:15 --> Model "M_solusi" initialized
INFO - 2023-06-13 07:39:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-13 07:39:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-13 07:39:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-13 07:39:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 07:39:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-13 07:39:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-13 07:39:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-13 07:39:15 --> Final output sent to browser
INFO - 2023-06-13 07:43:32 --> Config Class Initialized
INFO - 2023-06-13 07:43:32 --> Hooks Class Initialized
INFO - 2023-06-13 07:43:32 --> Utf8 Class Initialized
INFO - 2023-06-13 07:43:32 --> URI Class Initialized
INFO - 2023-06-13 07:43:32 --> Router Class Initialized
INFO - 2023-06-13 07:43:32 --> Output Class Initialized
INFO - 2023-06-13 07:43:32 --> Security Class Initialized
INFO - 2023-06-13 07:43:32 --> Input Class Initialized
INFO - 2023-06-13 07:43:32 --> Language Class Initialized
INFO - 2023-06-13 07:43:32 --> Loader Class Initialized
INFO - 2023-06-13 07:43:32 --> Helper loaded: url_helper
INFO - 2023-06-13 07:43:32 --> Helper loaded: form_helper
INFO - 2023-06-13 07:43:32 --> Database Driver Class Initialized
INFO - 2023-06-13 07:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:43:32 --> Form Validation Class Initialized
INFO - 2023-06-13 07:43:32 --> Controller Class Initialized
INFO - 2023-06-13 07:43:32 --> Model "m_user" initialized
INFO - 2023-06-13 07:43:32 --> Config Class Initialized
INFO - 2023-06-13 07:43:32 --> Hooks Class Initialized
INFO - 2023-06-13 07:43:32 --> Utf8 Class Initialized
INFO - 2023-06-13 07:43:32 --> URI Class Initialized
INFO - 2023-06-13 07:43:32 --> Router Class Initialized
INFO - 2023-06-13 07:43:32 --> Output Class Initialized
INFO - 2023-06-13 07:43:32 --> Security Class Initialized
INFO - 2023-06-13 07:43:32 --> Input Class Initialized
INFO - 2023-06-13 07:43:32 --> Language Class Initialized
INFO - 2023-06-13 07:43:32 --> Loader Class Initialized
INFO - 2023-06-13 07:43:32 --> Helper loaded: url_helper
INFO - 2023-06-13 07:43:32 --> Helper loaded: form_helper
INFO - 2023-06-13 07:43:32 --> Database Driver Class Initialized
INFO - 2023-06-13 07:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 07:43:32 --> Form Validation Class Initialized
INFO - 2023-06-13 07:43:32 --> Controller Class Initialized
INFO - 2023-06-13 07:43:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-13 07:43:32 --> Final output sent to browser
INFO - 2023-06-13 20:00:39 --> Config Class Initialized
INFO - 2023-06-13 20:00:39 --> Hooks Class Initialized
INFO - 2023-06-13 20:00:39 --> Utf8 Class Initialized
INFO - 2023-06-13 20:00:39 --> URI Class Initialized
INFO - 2023-06-13 20:00:39 --> Router Class Initialized
INFO - 2023-06-13 20:00:39 --> Output Class Initialized
INFO - 2023-06-13 20:00:39 --> Security Class Initialized
INFO - 2023-06-13 20:00:39 --> Input Class Initialized
INFO - 2023-06-13 20:00:39 --> Language Class Initialized
INFO - 2023-06-13 20:00:39 --> Loader Class Initialized
INFO - 2023-06-13 20:00:39 --> Helper loaded: url_helper
INFO - 2023-06-13 20:00:39 --> Helper loaded: form_helper
INFO - 2023-06-13 20:00:39 --> Database Driver Class Initialized
INFO - 2023-06-13 20:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:00:39 --> Form Validation Class Initialized
INFO - 2023-06-13 20:00:39 --> Controller Class Initialized
INFO - 2023-06-13 20:00:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-13 20:00:39 --> Final output sent to browser
INFO - 2023-06-13 20:00:49 --> Config Class Initialized
INFO - 2023-06-13 20:00:49 --> Hooks Class Initialized
INFO - 2023-06-13 20:00:49 --> Utf8 Class Initialized
INFO - 2023-06-13 20:00:49 --> URI Class Initialized
INFO - 2023-06-13 20:00:49 --> Router Class Initialized
INFO - 2023-06-13 20:00:49 --> Output Class Initialized
INFO - 2023-06-13 20:00:49 --> Security Class Initialized
INFO - 2023-06-13 20:00:49 --> Input Class Initialized
INFO - 2023-06-13 20:00:49 --> Language Class Initialized
INFO - 2023-06-13 20:00:49 --> Loader Class Initialized
INFO - 2023-06-13 20:00:49 --> Helper loaded: url_helper
INFO - 2023-06-13 20:00:49 --> Helper loaded: form_helper
INFO - 2023-06-13 20:00:49 --> Database Driver Class Initialized
INFO - 2023-06-13 20:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:00:49 --> Form Validation Class Initialized
INFO - 2023-06-13 20:00:49 --> Controller Class Initialized
INFO - 2023-06-13 20:00:49 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-13 20:00:49 --> Final output sent to browser
INFO - 2023-06-13 20:00:53 --> Config Class Initialized
INFO - 2023-06-13 20:00:53 --> Hooks Class Initialized
INFO - 2023-06-13 20:00:53 --> Utf8 Class Initialized
INFO - 2023-06-13 20:00:53 --> URI Class Initialized
INFO - 2023-06-13 20:00:53 --> Router Class Initialized
INFO - 2023-06-13 20:00:53 --> Output Class Initialized
INFO - 2023-06-13 20:00:53 --> Security Class Initialized
INFO - 2023-06-13 20:00:53 --> Input Class Initialized
INFO - 2023-06-13 20:00:53 --> Language Class Initialized
INFO - 2023-06-13 20:00:53 --> Loader Class Initialized
INFO - 2023-06-13 20:00:53 --> Helper loaded: url_helper
INFO - 2023-06-13 20:00:53 --> Helper loaded: form_helper
INFO - 2023-06-13 20:00:53 --> Database Driver Class Initialized
INFO - 2023-06-13 20:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:00:53 --> Form Validation Class Initialized
INFO - 2023-06-13 20:00:53 --> Controller Class Initialized
INFO - 2023-06-13 20:00:53 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-13 20:00:53 --> Final output sent to browser
INFO - 2023-06-13 20:07:16 --> Config Class Initialized
INFO - 2023-06-13 20:07:16 --> Hooks Class Initialized
INFO - 2023-06-13 20:07:16 --> Utf8 Class Initialized
INFO - 2023-06-13 20:07:16 --> URI Class Initialized
INFO - 2023-06-13 20:07:16 --> Router Class Initialized
INFO - 2023-06-13 20:07:16 --> Output Class Initialized
INFO - 2023-06-13 20:07:16 --> Security Class Initialized
INFO - 2023-06-13 20:07:16 --> Input Class Initialized
INFO - 2023-06-13 20:07:16 --> Language Class Initialized
INFO - 2023-06-13 20:07:16 --> Loader Class Initialized
INFO - 2023-06-13 20:07:16 --> Helper loaded: url_helper
INFO - 2023-06-13 20:07:16 --> Helper loaded: form_helper
INFO - 2023-06-13 20:07:16 --> Database Driver Class Initialized
INFO - 2023-06-13 20:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:07:16 --> Form Validation Class Initialized
INFO - 2023-06-13 20:07:16 --> Controller Class Initialized
INFO - 2023-06-13 20:07:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-13 20:07:16 --> Final output sent to browser
INFO - 2023-06-13 20:07:43 --> Config Class Initialized
INFO - 2023-06-13 20:07:43 --> Hooks Class Initialized
INFO - 2023-06-13 20:07:43 --> Utf8 Class Initialized
INFO - 2023-06-13 20:07:43 --> URI Class Initialized
INFO - 2023-06-13 20:07:43 --> Router Class Initialized
INFO - 2023-06-13 20:07:43 --> Output Class Initialized
INFO - 2023-06-13 20:07:43 --> Security Class Initialized
INFO - 2023-06-13 20:07:43 --> Input Class Initialized
INFO - 2023-06-13 20:07:43 --> Language Class Initialized
INFO - 2023-06-13 20:07:43 --> Loader Class Initialized
INFO - 2023-06-13 20:07:43 --> Helper loaded: url_helper
INFO - 2023-06-13 20:07:43 --> Helper loaded: form_helper
INFO - 2023-06-13 20:07:43 --> Database Driver Class Initialized
INFO - 2023-06-13 20:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:07:43 --> Form Validation Class Initialized
INFO - 2023-06-13 20:07:43 --> Controller Class Initialized
INFO - 2023-06-13 20:07:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-13 20:07:43 --> Final output sent to browser
INFO - 2023-06-13 20:07:49 --> Config Class Initialized
INFO - 2023-06-13 20:07:49 --> Hooks Class Initialized
INFO - 2023-06-13 20:07:49 --> Utf8 Class Initialized
INFO - 2023-06-13 20:07:49 --> URI Class Initialized
INFO - 2023-06-13 20:07:49 --> Router Class Initialized
INFO - 2023-06-13 20:07:49 --> Output Class Initialized
INFO - 2023-06-13 20:07:49 --> Security Class Initialized
INFO - 2023-06-13 20:07:49 --> Input Class Initialized
INFO - 2023-06-13 20:07:49 --> Language Class Initialized
INFO - 2023-06-13 20:07:49 --> Loader Class Initialized
INFO - 2023-06-13 20:07:49 --> Helper loaded: url_helper
INFO - 2023-06-13 20:07:49 --> Helper loaded: form_helper
INFO - 2023-06-13 20:07:49 --> Database Driver Class Initialized
INFO - 2023-06-13 20:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:07:49 --> Form Validation Class Initialized
INFO - 2023-06-13 20:07:49 --> Controller Class Initialized
INFO - 2023-06-13 20:07:49 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-13 20:07:49 --> Final output sent to browser
INFO - 2023-06-13 20:07:53 --> Config Class Initialized
INFO - 2023-06-13 20:07:53 --> Hooks Class Initialized
INFO - 2023-06-13 20:07:53 --> Utf8 Class Initialized
INFO - 2023-06-13 20:07:53 --> URI Class Initialized
INFO - 2023-06-13 20:07:53 --> Router Class Initialized
INFO - 2023-06-13 20:07:53 --> Output Class Initialized
INFO - 2023-06-13 20:07:53 --> Security Class Initialized
INFO - 2023-06-13 20:07:53 --> Input Class Initialized
INFO - 2023-06-13 20:07:53 --> Language Class Initialized
INFO - 2023-06-13 20:07:53 --> Loader Class Initialized
INFO - 2023-06-13 20:07:53 --> Helper loaded: url_helper
INFO - 2023-06-13 20:07:53 --> Helper loaded: form_helper
INFO - 2023-06-13 20:07:53 --> Database Driver Class Initialized
INFO - 2023-06-13 20:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:07:53 --> Form Validation Class Initialized
INFO - 2023-06-13 20:07:53 --> Controller Class Initialized
INFO - 2023-06-13 20:07:53 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-13 20:07:53 --> Final output sent to browser
INFO - 2023-06-13 20:10:29 --> Config Class Initialized
INFO - 2023-06-13 20:10:29 --> Hooks Class Initialized
INFO - 2023-06-13 20:10:29 --> Utf8 Class Initialized
INFO - 2023-06-13 20:10:29 --> URI Class Initialized
INFO - 2023-06-13 20:10:29 --> Router Class Initialized
INFO - 2023-06-13 20:10:29 --> Output Class Initialized
INFO - 2023-06-13 20:10:29 --> Security Class Initialized
INFO - 2023-06-13 20:10:29 --> Input Class Initialized
INFO - 2023-06-13 20:10:29 --> Language Class Initialized
INFO - 2023-06-13 20:10:29 --> Loader Class Initialized
INFO - 2023-06-13 20:10:29 --> Helper loaded: url_helper
INFO - 2023-06-13 20:10:29 --> Helper loaded: form_helper
INFO - 2023-06-13 20:10:29 --> Database Driver Class Initialized
INFO - 2023-06-13 20:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:10:29 --> Form Validation Class Initialized
INFO - 2023-06-13 20:10:29 --> Controller Class Initialized
INFO - 2023-06-13 20:10:29 --> Model "m_user" initialized
INFO - 2023-06-13 20:10:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-13 20:10:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-13 20:10:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-13 20:10:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-13 20:10:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-13 20:10:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-13 20:10:29 --> Final output sent to browser
INFO - 2023-06-13 20:10:32 --> Config Class Initialized
INFO - 2023-06-13 20:10:32 --> Hooks Class Initialized
INFO - 2023-06-13 20:10:32 --> Utf8 Class Initialized
INFO - 2023-06-13 20:10:32 --> URI Class Initialized
INFO - 2023-06-13 20:10:32 --> Router Class Initialized
INFO - 2023-06-13 20:10:32 --> Output Class Initialized
INFO - 2023-06-13 20:10:32 --> Security Class Initialized
INFO - 2023-06-13 20:10:32 --> Input Class Initialized
INFO - 2023-06-13 20:10:32 --> Language Class Initialized
INFO - 2023-06-13 20:10:32 --> Loader Class Initialized
INFO - 2023-06-13 20:10:32 --> Helper loaded: url_helper
INFO - 2023-06-13 20:10:32 --> Helper loaded: form_helper
INFO - 2023-06-13 20:10:32 --> Database Driver Class Initialized
INFO - 2023-06-13 20:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:10:32 --> Form Validation Class Initialized
INFO - 2023-06-13 20:10:32 --> Controller Class Initialized
INFO - 2023-06-13 20:10:32 --> Model "m_user" initialized
INFO - 2023-06-13 20:10:32 --> Config Class Initialized
INFO - 2023-06-13 20:10:32 --> Hooks Class Initialized
INFO - 2023-06-13 20:10:32 --> Utf8 Class Initialized
INFO - 2023-06-13 20:10:32 --> URI Class Initialized
INFO - 2023-06-13 20:10:32 --> Router Class Initialized
INFO - 2023-06-13 20:10:32 --> Output Class Initialized
INFO - 2023-06-13 20:10:32 --> Security Class Initialized
INFO - 2023-06-13 20:10:32 --> Input Class Initialized
INFO - 2023-06-13 20:10:32 --> Language Class Initialized
INFO - 2023-06-13 20:10:32 --> Loader Class Initialized
INFO - 2023-06-13 20:10:32 --> Helper loaded: url_helper
INFO - 2023-06-13 20:10:32 --> Helper loaded: form_helper
INFO - 2023-06-13 20:10:32 --> Database Driver Class Initialized
INFO - 2023-06-13 20:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:10:32 --> Form Validation Class Initialized
INFO - 2023-06-13 20:10:32 --> Controller Class Initialized
INFO - 2023-06-13 20:10:32 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-13 20:10:32 --> Final output sent to browser
INFO - 2023-06-13 20:10:34 --> Config Class Initialized
INFO - 2023-06-13 20:10:34 --> Hooks Class Initialized
INFO - 2023-06-13 20:10:34 --> Utf8 Class Initialized
INFO - 2023-06-13 20:10:34 --> URI Class Initialized
INFO - 2023-06-13 20:10:34 --> Router Class Initialized
INFO - 2023-06-13 20:10:34 --> Output Class Initialized
INFO - 2023-06-13 20:10:34 --> Security Class Initialized
INFO - 2023-06-13 20:10:34 --> Input Class Initialized
INFO - 2023-06-13 20:10:34 --> Language Class Initialized
INFO - 2023-06-13 20:10:34 --> Loader Class Initialized
INFO - 2023-06-13 20:10:34 --> Helper loaded: url_helper
INFO - 2023-06-13 20:10:34 --> Helper loaded: form_helper
INFO - 2023-06-13 20:10:34 --> Database Driver Class Initialized
INFO - 2023-06-13 20:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:10:34 --> Form Validation Class Initialized
INFO - 2023-06-13 20:10:34 --> Controller Class Initialized
INFO - 2023-06-13 20:10:34 --> Model "m_user" initialized
INFO - 2023-06-13 20:10:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_header.php
INFO - 2023-06-13 20:10:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\auth/login.php
INFO - 2023-06-13 20:10:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_footer.php
INFO - 2023-06-13 20:10:34 --> Final output sent to browser
INFO - 2023-06-13 20:10:37 --> Config Class Initialized
INFO - 2023-06-13 20:10:37 --> Hooks Class Initialized
INFO - 2023-06-13 20:10:37 --> Utf8 Class Initialized
INFO - 2023-06-13 20:10:37 --> URI Class Initialized
INFO - 2023-06-13 20:10:37 --> Router Class Initialized
INFO - 2023-06-13 20:10:37 --> Output Class Initialized
INFO - 2023-06-13 20:10:37 --> Security Class Initialized
INFO - 2023-06-13 20:10:37 --> Input Class Initialized
INFO - 2023-06-13 20:10:37 --> Language Class Initialized
INFO - 2023-06-13 20:10:38 --> Loader Class Initialized
INFO - 2023-06-13 20:10:38 --> Helper loaded: url_helper
INFO - 2023-06-13 20:10:38 --> Helper loaded: form_helper
INFO - 2023-06-13 20:10:38 --> Database Driver Class Initialized
INFO - 2023-06-13 20:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:10:38 --> Form Validation Class Initialized
INFO - 2023-06-13 20:10:38 --> Controller Class Initialized
INFO - 2023-06-13 20:10:38 --> Model "m_user" initialized
INFO - 2023-06-13 20:10:38 --> Config Class Initialized
INFO - 2023-06-13 20:10:38 --> Hooks Class Initialized
INFO - 2023-06-13 20:10:38 --> Utf8 Class Initialized
INFO - 2023-06-13 20:10:38 --> URI Class Initialized
INFO - 2023-06-13 20:10:38 --> Router Class Initialized
INFO - 2023-06-13 20:10:38 --> Output Class Initialized
INFO - 2023-06-13 20:10:38 --> Security Class Initialized
INFO - 2023-06-13 20:10:38 --> Input Class Initialized
INFO - 2023-06-13 20:10:38 --> Language Class Initialized
INFO - 2023-06-13 20:10:38 --> Loader Class Initialized
INFO - 2023-06-13 20:10:38 --> Helper loaded: url_helper
INFO - 2023-06-13 20:10:38 --> Helper loaded: form_helper
INFO - 2023-06-13 20:10:38 --> Database Driver Class Initialized
INFO - 2023-06-13 20:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:10:38 --> Form Validation Class Initialized
INFO - 2023-06-13 20:10:38 --> Controller Class Initialized
INFO - 2023-06-13 20:10:38 --> Model "m_user" initialized
INFO - 2023-06-13 20:10:38 --> Model "m_datatrain" initialized
INFO - 2023-06-13 20:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-13 20:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-13 20:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-13 20:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-13 20:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-13 20:10:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home.php
INFO - 2023-06-13 20:10:38 --> Final output sent to browser
INFO - 2023-06-13 20:10:41 --> Config Class Initialized
INFO - 2023-06-13 20:10:41 --> Hooks Class Initialized
INFO - 2023-06-13 20:10:41 --> Utf8 Class Initialized
INFO - 2023-06-13 20:10:41 --> URI Class Initialized
INFO - 2023-06-13 20:10:41 --> Router Class Initialized
INFO - 2023-06-13 20:10:41 --> Output Class Initialized
INFO - 2023-06-13 20:10:41 --> Security Class Initialized
INFO - 2023-06-13 20:10:41 --> Input Class Initialized
INFO - 2023-06-13 20:10:41 --> Language Class Initialized
INFO - 2023-06-13 20:10:41 --> Loader Class Initialized
INFO - 2023-06-13 20:10:41 --> Helper loaded: url_helper
INFO - 2023-06-13 20:10:41 --> Helper loaded: form_helper
INFO - 2023-06-13 20:10:41 --> Database Driver Class Initialized
INFO - 2023-06-13 20:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:10:41 --> Form Validation Class Initialized
INFO - 2023-06-13 20:10:41 --> Controller Class Initialized
INFO - 2023-06-13 20:10:41 --> Model "m_user" initialized
INFO - 2023-06-13 20:10:41 --> Config Class Initialized
INFO - 2023-06-13 20:10:41 --> Hooks Class Initialized
INFO - 2023-06-13 20:10:41 --> Utf8 Class Initialized
INFO - 2023-06-13 20:10:41 --> URI Class Initialized
INFO - 2023-06-13 20:10:41 --> Router Class Initialized
INFO - 2023-06-13 20:10:41 --> Output Class Initialized
INFO - 2023-06-13 20:10:41 --> Security Class Initialized
INFO - 2023-06-13 20:10:41 --> Input Class Initialized
INFO - 2023-06-13 20:10:41 --> Language Class Initialized
INFO - 2023-06-13 20:10:41 --> Loader Class Initialized
INFO - 2023-06-13 20:10:41 --> Helper loaded: url_helper
INFO - 2023-06-13 20:10:41 --> Helper loaded: form_helper
INFO - 2023-06-13 20:10:41 --> Database Driver Class Initialized
INFO - 2023-06-13 20:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-13 20:10:41 --> Form Validation Class Initialized
INFO - 2023-06-13 20:10:41 --> Controller Class Initialized
INFO - 2023-06-13 20:10:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-13 20:10:41 --> Final output sent to browser
