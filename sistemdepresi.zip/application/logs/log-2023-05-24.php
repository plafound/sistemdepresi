<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-24 07:44:19 --> Config Class Initialized
INFO - 2023-05-24 07:44:19 --> Hooks Class Initialized
INFO - 2023-05-24 07:44:19 --> Utf8 Class Initialized
INFO - 2023-05-24 07:44:19 --> URI Class Initialized
INFO - 2023-05-24 07:44:19 --> Router Class Initialized
INFO - 2023-05-24 07:44:19 --> Output Class Initialized
INFO - 2023-05-24 07:44:19 --> Security Class Initialized
INFO - 2023-05-24 07:44:19 --> Input Class Initialized
INFO - 2023-05-24 07:44:19 --> Language Class Initialized
INFO - 2023-05-24 07:44:19 --> Loader Class Initialized
INFO - 2023-05-24 07:44:19 --> Helper loaded: url_helper
INFO - 2023-05-24 07:44:19 --> Helper loaded: form_helper
INFO - 2023-05-24 07:44:19 --> Database Driver Class Initialized
INFO - 2023-05-24 07:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:44:19 --> Form Validation Class Initialized
INFO - 2023-05-24 07:44:19 --> Controller Class Initialized
INFO - 2023-05-24 07:44:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-24 07:44:19 --> Final output sent to browser
INFO - 2023-05-24 07:44:33 --> Config Class Initialized
INFO - 2023-05-24 07:44:33 --> Hooks Class Initialized
INFO - 2023-05-24 07:44:33 --> Utf8 Class Initialized
INFO - 2023-05-24 07:44:33 --> URI Class Initialized
INFO - 2023-05-24 07:44:33 --> Router Class Initialized
INFO - 2023-05-24 07:44:33 --> Output Class Initialized
INFO - 2023-05-24 07:44:33 --> Security Class Initialized
INFO - 2023-05-24 07:44:33 --> Input Class Initialized
INFO - 2023-05-24 07:44:33 --> Language Class Initialized
INFO - 2023-05-24 07:44:33 --> Loader Class Initialized
INFO - 2023-05-24 07:44:33 --> Helper loaded: url_helper
INFO - 2023-05-24 07:44:33 --> Helper loaded: form_helper
INFO - 2023-05-24 07:44:33 --> Database Driver Class Initialized
INFO - 2023-05-24 07:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:44:33 --> Form Validation Class Initialized
INFO - 2023-05-24 07:44:33 --> Controller Class Initialized
INFO - 2023-05-24 07:44:33 --> Model "m_user" initialized
INFO - 2023-05-24 07:44:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-24 07:44:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-24 07:44:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-24 07:44:33 --> Final output sent to browser
INFO - 2023-05-24 07:44:47 --> Config Class Initialized
INFO - 2023-05-24 07:44:47 --> Hooks Class Initialized
INFO - 2023-05-24 07:44:47 --> Utf8 Class Initialized
INFO - 2023-05-24 07:44:47 --> URI Class Initialized
INFO - 2023-05-24 07:44:47 --> Router Class Initialized
INFO - 2023-05-24 07:44:47 --> Output Class Initialized
INFO - 2023-05-24 07:44:47 --> Security Class Initialized
INFO - 2023-05-24 07:44:48 --> Input Class Initialized
INFO - 2023-05-24 07:44:48 --> Language Class Initialized
INFO - 2023-05-24 07:44:48 --> Loader Class Initialized
INFO - 2023-05-24 07:44:48 --> Helper loaded: url_helper
INFO - 2023-05-24 07:44:48 --> Helper loaded: form_helper
INFO - 2023-05-24 07:44:48 --> Database Driver Class Initialized
INFO - 2023-05-24 07:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:44:48 --> Form Validation Class Initialized
INFO - 2023-05-24 07:44:48 --> Controller Class Initialized
INFO - 2023-05-24 07:44:48 --> Model "m_user" initialized
INFO - 2023-05-24 07:44:48 --> Config Class Initialized
INFO - 2023-05-24 07:44:48 --> Hooks Class Initialized
INFO - 2023-05-24 07:44:48 --> Utf8 Class Initialized
INFO - 2023-05-24 07:44:48 --> URI Class Initialized
INFO - 2023-05-24 07:44:48 --> Router Class Initialized
INFO - 2023-05-24 07:44:48 --> Output Class Initialized
INFO - 2023-05-24 07:44:48 --> Security Class Initialized
INFO - 2023-05-24 07:44:48 --> Input Class Initialized
INFO - 2023-05-24 07:44:48 --> Language Class Initialized
INFO - 2023-05-24 07:44:48 --> Loader Class Initialized
INFO - 2023-05-24 07:44:48 --> Helper loaded: url_helper
INFO - 2023-05-24 07:44:48 --> Helper loaded: form_helper
INFO - 2023-05-24 07:44:48 --> Database Driver Class Initialized
INFO - 2023-05-24 07:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:44:48 --> Form Validation Class Initialized
INFO - 2023-05-24 07:44:48 --> Controller Class Initialized
INFO - 2023-05-24 07:44:48 --> Model "m_user" initialized
INFO - 2023-05-24 07:44:48 --> Model "m_datatrain" initialized
INFO - 2023-05-24 07:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-24 07:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-24 07:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-24 07:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-24 07:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-24 07:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-24 07:44:48 --> Final output sent to browser
INFO - 2023-05-24 07:44:51 --> Config Class Initialized
INFO - 2023-05-24 07:44:51 --> Hooks Class Initialized
INFO - 2023-05-24 07:44:51 --> Utf8 Class Initialized
INFO - 2023-05-24 07:44:51 --> URI Class Initialized
INFO - 2023-05-24 07:44:51 --> Router Class Initialized
INFO - 2023-05-24 07:44:51 --> Output Class Initialized
INFO - 2023-05-24 07:44:51 --> Security Class Initialized
INFO - 2023-05-24 07:44:51 --> Input Class Initialized
INFO - 2023-05-24 07:44:51 --> Language Class Initialized
INFO - 2023-05-24 07:44:51 --> Loader Class Initialized
INFO - 2023-05-24 07:44:51 --> Helper loaded: url_helper
INFO - 2023-05-24 07:44:51 --> Helper loaded: form_helper
INFO - 2023-05-24 07:44:51 --> Database Driver Class Initialized
INFO - 2023-05-24 07:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:44:51 --> Form Validation Class Initialized
INFO - 2023-05-24 07:44:51 --> Controller Class Initialized
INFO - 2023-05-24 07:44:51 --> Model "m_datatrain" initialized
INFO - 2023-05-24 07:44:51 --> Model "m_penghitungan" initialized
INFO - 2023-05-24 07:44:51 --> Model "m_datatest" initialized
INFO - 2023-05-24 07:44:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-24 07:44:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-24 07:44:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-24 07:44:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-24 07:44:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-24 07:44:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-24 07:44:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-24 07:44:52 --> Final output sent to browser
INFO - 2023-05-24 07:45:19 --> Config Class Initialized
INFO - 2023-05-24 07:45:19 --> Hooks Class Initialized
INFO - 2023-05-24 07:45:19 --> Utf8 Class Initialized
INFO - 2023-05-24 07:45:19 --> URI Class Initialized
INFO - 2023-05-24 07:45:19 --> Router Class Initialized
INFO - 2023-05-24 07:45:19 --> Output Class Initialized
INFO - 2023-05-24 07:45:19 --> Security Class Initialized
INFO - 2023-05-24 07:45:19 --> Input Class Initialized
INFO - 2023-05-24 07:45:19 --> Language Class Initialized
INFO - 2023-05-24 07:45:19 --> Loader Class Initialized
INFO - 2023-05-24 07:45:19 --> Helper loaded: url_helper
INFO - 2023-05-24 07:45:19 --> Helper loaded: form_helper
INFO - 2023-05-24 07:45:19 --> Database Driver Class Initialized
INFO - 2023-05-24 07:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:45:19 --> Form Validation Class Initialized
INFO - 2023-05-24 07:45:19 --> Controller Class Initialized
INFO - 2023-05-24 07:45:19 --> Model "m_datatrain" initialized
INFO - 2023-05-24 07:45:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-24 07:45:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-24 07:45:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-24 07:45:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-24 07:45:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-24 07:45:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-24 07:45:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-24 07:45:19 --> Final output sent to browser
INFO - 2023-05-24 07:45:29 --> Config Class Initialized
INFO - 2023-05-24 07:45:29 --> Hooks Class Initialized
INFO - 2023-05-24 07:45:29 --> Utf8 Class Initialized
INFO - 2023-05-24 07:45:29 --> URI Class Initialized
INFO - 2023-05-24 07:45:29 --> Router Class Initialized
INFO - 2023-05-24 07:45:29 --> Output Class Initialized
INFO - 2023-05-24 07:45:29 --> Security Class Initialized
INFO - 2023-05-24 07:45:29 --> Input Class Initialized
INFO - 2023-05-24 07:45:29 --> Language Class Initialized
INFO - 2023-05-24 07:45:29 --> Loader Class Initialized
INFO - 2023-05-24 07:45:29 --> Helper loaded: url_helper
INFO - 2023-05-24 07:45:29 --> Helper loaded: form_helper
INFO - 2023-05-24 07:45:29 --> Database Driver Class Initialized
INFO - 2023-05-24 07:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:45:29 --> Form Validation Class Initialized
INFO - 2023-05-24 07:45:29 --> Controller Class Initialized
INFO - 2023-05-24 07:45:29 --> Model "m_datatest" initialized
INFO - 2023-05-24 07:45:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-24 07:45:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-24 07:45:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-24 07:45:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-24 07:45:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-24 07:45:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-24 07:45:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-24 07:45:29 --> Final output sent to browser
INFO - 2023-05-24 07:45:40 --> Config Class Initialized
INFO - 2023-05-24 07:45:40 --> Hooks Class Initialized
INFO - 2023-05-24 07:45:40 --> Utf8 Class Initialized
INFO - 2023-05-24 07:45:40 --> URI Class Initialized
INFO - 2023-05-24 07:45:40 --> Router Class Initialized
INFO - 2023-05-24 07:45:40 --> Output Class Initialized
INFO - 2023-05-24 07:45:40 --> Security Class Initialized
INFO - 2023-05-24 07:45:40 --> Input Class Initialized
INFO - 2023-05-24 07:45:40 --> Language Class Initialized
INFO - 2023-05-24 07:45:40 --> Loader Class Initialized
INFO - 2023-05-24 07:45:40 --> Helper loaded: url_helper
INFO - 2023-05-24 07:45:40 --> Helper loaded: form_helper
INFO - 2023-05-24 07:45:40 --> Database Driver Class Initialized
INFO - 2023-05-24 07:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:45:40 --> Form Validation Class Initialized
INFO - 2023-05-24 07:45:40 --> Controller Class Initialized
INFO - 2023-05-24 07:45:40 --> Model "m_user" initialized
INFO - 2023-05-24 07:45:40 --> Model "m_datatrain" initialized
INFO - 2023-05-24 07:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-24 07:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-24 07:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-24 07:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-24 07:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-24 07:45:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-24 07:45:40 --> Final output sent to browser
INFO - 2023-05-24 07:45:46 --> Config Class Initialized
INFO - 2023-05-24 07:45:46 --> Hooks Class Initialized
INFO - 2023-05-24 07:45:46 --> Utf8 Class Initialized
INFO - 2023-05-24 07:45:46 --> URI Class Initialized
INFO - 2023-05-24 07:45:46 --> Router Class Initialized
INFO - 2023-05-24 07:45:46 --> Output Class Initialized
INFO - 2023-05-24 07:45:46 --> Security Class Initialized
INFO - 2023-05-24 07:45:46 --> Input Class Initialized
INFO - 2023-05-24 07:45:46 --> Language Class Initialized
INFO - 2023-05-24 07:45:46 --> Loader Class Initialized
INFO - 2023-05-24 07:45:46 --> Helper loaded: url_helper
INFO - 2023-05-24 07:45:46 --> Helper loaded: form_helper
INFO - 2023-05-24 07:45:46 --> Database Driver Class Initialized
INFO - 2023-05-24 07:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:45:46 --> Form Validation Class Initialized
INFO - 2023-05-24 07:45:46 --> Controller Class Initialized
INFO - 2023-05-24 07:45:46 --> Model "m_user" initialized
INFO - 2023-05-24 07:45:46 --> Config Class Initialized
INFO - 2023-05-24 07:45:46 --> Hooks Class Initialized
INFO - 2023-05-24 07:45:46 --> Utf8 Class Initialized
INFO - 2023-05-24 07:45:46 --> URI Class Initialized
INFO - 2023-05-24 07:45:46 --> Router Class Initialized
INFO - 2023-05-24 07:45:46 --> Output Class Initialized
INFO - 2023-05-24 07:45:46 --> Security Class Initialized
INFO - 2023-05-24 07:45:46 --> Input Class Initialized
INFO - 2023-05-24 07:45:46 --> Language Class Initialized
INFO - 2023-05-24 07:45:46 --> Loader Class Initialized
INFO - 2023-05-24 07:45:46 --> Helper loaded: url_helper
INFO - 2023-05-24 07:45:46 --> Helper loaded: form_helper
INFO - 2023-05-24 07:45:46 --> Database Driver Class Initialized
INFO - 2023-05-24 07:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:45:46 --> Form Validation Class Initialized
INFO - 2023-05-24 07:45:46 --> Controller Class Initialized
INFO - 2023-05-24 07:45:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-24 07:45:46 --> Final output sent to browser
INFO - 2023-05-24 07:45:48 --> Config Class Initialized
INFO - 2023-05-24 07:45:48 --> Hooks Class Initialized
INFO - 2023-05-24 07:45:48 --> Utf8 Class Initialized
INFO - 2023-05-24 07:45:48 --> URI Class Initialized
INFO - 2023-05-24 07:45:48 --> Router Class Initialized
INFO - 2023-05-24 07:45:48 --> Output Class Initialized
INFO - 2023-05-24 07:45:48 --> Security Class Initialized
INFO - 2023-05-24 07:45:48 --> Input Class Initialized
INFO - 2023-05-24 07:45:48 --> Language Class Initialized
INFO - 2023-05-24 07:45:48 --> Loader Class Initialized
INFO - 2023-05-24 07:45:48 --> Helper loaded: url_helper
INFO - 2023-05-24 07:45:48 --> Helper loaded: form_helper
INFO - 2023-05-24 07:45:48 --> Database Driver Class Initialized
INFO - 2023-05-24 07:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:45:48 --> Form Validation Class Initialized
INFO - 2023-05-24 07:45:48 --> Controller Class Initialized
INFO - 2023-05-24 07:45:48 --> Model "m_user" initialized
INFO - 2023-05-24 07:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-24 07:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-24 07:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-24 07:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-24 07:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-24 07:45:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-24 07:45:48 --> Final output sent to browser
INFO - 2023-05-24 07:45:50 --> Config Class Initialized
INFO - 2023-05-24 07:45:50 --> Hooks Class Initialized
INFO - 2023-05-24 07:45:50 --> Utf8 Class Initialized
INFO - 2023-05-24 07:45:50 --> URI Class Initialized
INFO - 2023-05-24 07:45:50 --> Router Class Initialized
INFO - 2023-05-24 07:45:50 --> Output Class Initialized
INFO - 2023-05-24 07:45:50 --> Security Class Initialized
INFO - 2023-05-24 07:45:50 --> Input Class Initialized
INFO - 2023-05-24 07:45:50 --> Language Class Initialized
INFO - 2023-05-24 07:45:51 --> Loader Class Initialized
INFO - 2023-05-24 07:45:51 --> Helper loaded: url_helper
INFO - 2023-05-24 07:45:51 --> Helper loaded: form_helper
INFO - 2023-05-24 07:45:51 --> Database Driver Class Initialized
INFO - 2023-05-24 07:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:45:51 --> Form Validation Class Initialized
INFO - 2023-05-24 07:45:51 --> Controller Class Initialized
INFO - 2023-05-24 07:45:51 --> Model "m_datatrain" initialized
INFO - 2023-05-24 07:45:51 --> Model "m_penghitungan" initialized
INFO - 2023-05-24 07:45:51 --> Model "m_datatest" initialized
INFO - 2023-05-24 07:45:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-24 07:45:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-24 07:45:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-24 07:45:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-24 07:45:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-24 07:45:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-24 07:45:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-24 07:45:51 --> Final output sent to browser
INFO - 2023-05-24 07:46:01 --> Config Class Initialized
INFO - 2023-05-24 07:46:01 --> Hooks Class Initialized
INFO - 2023-05-24 07:46:01 --> Utf8 Class Initialized
INFO - 2023-05-24 07:46:01 --> URI Class Initialized
INFO - 2023-05-24 07:46:01 --> Router Class Initialized
INFO - 2023-05-24 07:46:01 --> Output Class Initialized
INFO - 2023-05-24 07:46:01 --> Security Class Initialized
INFO - 2023-05-24 07:46:01 --> Input Class Initialized
INFO - 2023-05-24 07:46:01 --> Language Class Initialized
INFO - 2023-05-24 07:46:01 --> Loader Class Initialized
INFO - 2023-05-24 07:46:01 --> Helper loaded: url_helper
INFO - 2023-05-24 07:46:01 --> Helper loaded: form_helper
INFO - 2023-05-24 07:46:01 --> Database Driver Class Initialized
INFO - 2023-05-24 07:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:46:01 --> Form Validation Class Initialized
INFO - 2023-05-24 07:46:01 --> Controller Class Initialized
INFO - 2023-05-24 07:46:01 --> Model "m_user" initialized
INFO - 2023-05-24 07:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-24 07:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-24 07:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-24 07:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-24 07:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-24 07:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-24 07:46:01 --> Final output sent to browser
INFO - 2023-05-24 07:46:04 --> Config Class Initialized
INFO - 2023-05-24 07:46:04 --> Hooks Class Initialized
INFO - 2023-05-24 07:46:04 --> Utf8 Class Initialized
INFO - 2023-05-24 07:46:04 --> URI Class Initialized
INFO - 2023-05-24 07:46:04 --> Router Class Initialized
INFO - 2023-05-24 07:46:04 --> Output Class Initialized
INFO - 2023-05-24 07:46:04 --> Security Class Initialized
INFO - 2023-05-24 07:46:04 --> Input Class Initialized
INFO - 2023-05-24 07:46:04 --> Language Class Initialized
INFO - 2023-05-24 07:46:04 --> Loader Class Initialized
INFO - 2023-05-24 07:46:04 --> Helper loaded: url_helper
INFO - 2023-05-24 07:46:04 --> Helper loaded: form_helper
INFO - 2023-05-24 07:46:04 --> Database Driver Class Initialized
INFO - 2023-05-24 07:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-24 07:46:04 --> Form Validation Class Initialized
INFO - 2023-05-24 07:46:04 --> Controller Class Initialized
INFO - 2023-05-24 07:46:04 --> Model "m_user" initialized
INFO - 2023-05-24 07:46:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-24 07:46:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-24 07:46:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-24 07:46:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-24 07:46:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-24 07:46:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-24 07:46:04 --> Final output sent to browser
