<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-23 04:58:12 --> Config Class Initialized
INFO - 2023-06-23 04:58:12 --> Hooks Class Initialized
INFO - 2023-06-23 04:58:12 --> Utf8 Class Initialized
INFO - 2023-06-23 04:58:13 --> URI Class Initialized
INFO - 2023-06-23 04:58:13 --> Router Class Initialized
INFO - 2023-06-23 04:58:13 --> Output Class Initialized
INFO - 2023-06-23 04:58:13 --> Security Class Initialized
INFO - 2023-06-23 04:58:13 --> Input Class Initialized
INFO - 2023-06-23 04:58:13 --> Language Class Initialized
INFO - 2023-06-23 04:58:13 --> Loader Class Initialized
INFO - 2023-06-23 04:58:13 --> Helper loaded: url_helper
INFO - 2023-06-23 04:58:13 --> Helper loaded: form_helper
INFO - 2023-06-23 04:58:13 --> Database Driver Class Initialized
INFO - 2023-06-23 04:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 04:58:13 --> Form Validation Class Initialized
INFO - 2023-06-23 04:58:13 --> Controller Class Initialized
INFO - 2023-06-23 04:58:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-23 04:58:13 --> Final output sent to browser
INFO - 2023-06-23 04:58:17 --> Config Class Initialized
INFO - 2023-06-23 04:58:17 --> Hooks Class Initialized
INFO - 2023-06-23 04:58:17 --> Utf8 Class Initialized
INFO - 2023-06-23 04:58:17 --> URI Class Initialized
INFO - 2023-06-23 04:58:17 --> Router Class Initialized
INFO - 2023-06-23 04:58:17 --> Output Class Initialized
INFO - 2023-06-23 04:58:17 --> Security Class Initialized
INFO - 2023-06-23 04:58:17 --> Input Class Initialized
INFO - 2023-06-23 04:58:17 --> Language Class Initialized
INFO - 2023-06-23 04:58:17 --> Loader Class Initialized
INFO - 2023-06-23 04:58:17 --> Helper loaded: url_helper
INFO - 2023-06-23 04:58:17 --> Helper loaded: form_helper
INFO - 2023-06-23 04:58:17 --> Database Driver Class Initialized
INFO - 2023-06-23 04:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 04:58:17 --> Form Validation Class Initialized
INFO - 2023-06-23 04:58:17 --> Controller Class Initialized
INFO - 2023-06-23 04:58:17 --> Model "m_user" initialized
INFO - 2023-06-23 04:58:17 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_header.php
INFO - 2023-06-23 04:58:17 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\auth/login.php
INFO - 2023-06-23 04:58:17 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_footer.php
INFO - 2023-06-23 04:58:17 --> Final output sent to browser
INFO - 2023-06-23 04:58:20 --> Config Class Initialized
INFO - 2023-06-23 04:58:20 --> Hooks Class Initialized
INFO - 2023-06-23 04:58:20 --> Utf8 Class Initialized
INFO - 2023-06-23 04:58:20 --> URI Class Initialized
INFO - 2023-06-23 04:58:20 --> Router Class Initialized
INFO - 2023-06-23 04:58:20 --> Output Class Initialized
INFO - 2023-06-23 04:58:20 --> Security Class Initialized
INFO - 2023-06-23 04:58:20 --> Input Class Initialized
INFO - 2023-06-23 04:58:20 --> Language Class Initialized
INFO - 2023-06-23 04:58:20 --> Loader Class Initialized
INFO - 2023-06-23 04:58:20 --> Helper loaded: url_helper
INFO - 2023-06-23 04:58:20 --> Helper loaded: form_helper
INFO - 2023-06-23 04:58:20 --> Database Driver Class Initialized
INFO - 2023-06-23 04:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 04:58:20 --> Form Validation Class Initialized
INFO - 2023-06-23 04:58:20 --> Controller Class Initialized
INFO - 2023-06-23 04:58:20 --> Model "m_user" initialized
INFO - 2023-06-23 04:58:20 --> Config Class Initialized
INFO - 2023-06-23 04:58:20 --> Hooks Class Initialized
INFO - 2023-06-23 04:58:20 --> Utf8 Class Initialized
INFO - 2023-06-23 04:58:20 --> URI Class Initialized
INFO - 2023-06-23 04:58:20 --> Router Class Initialized
INFO - 2023-06-23 04:58:20 --> Output Class Initialized
INFO - 2023-06-23 04:58:20 --> Security Class Initialized
INFO - 2023-06-23 04:58:20 --> Input Class Initialized
INFO - 2023-06-23 04:58:20 --> Language Class Initialized
INFO - 2023-06-23 04:58:20 --> Loader Class Initialized
INFO - 2023-06-23 04:58:20 --> Helper loaded: url_helper
INFO - 2023-06-23 04:58:20 --> Helper loaded: form_helper
INFO - 2023-06-23 04:58:20 --> Database Driver Class Initialized
INFO - 2023-06-23 04:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 04:58:20 --> Form Validation Class Initialized
INFO - 2023-06-23 04:58:20 --> Controller Class Initialized
INFO - 2023-06-23 04:58:20 --> Model "m_user" initialized
INFO - 2023-06-23 04:58:20 --> Model "m_datatrain" initialized
INFO - 2023-06-23 04:58:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 04:58:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 04:58:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 04:58:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 04:58:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 04:58:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home.php
INFO - 2023-06-23 04:58:21 --> Final output sent to browser
INFO - 2023-06-23 04:58:29 --> Config Class Initialized
INFO - 2023-06-23 04:58:29 --> Hooks Class Initialized
INFO - 2023-06-23 04:58:29 --> Utf8 Class Initialized
INFO - 2023-06-23 04:58:29 --> URI Class Initialized
INFO - 2023-06-23 04:58:29 --> Router Class Initialized
INFO - 2023-06-23 04:58:29 --> Output Class Initialized
INFO - 2023-06-23 04:58:29 --> Security Class Initialized
INFO - 2023-06-23 04:58:29 --> Input Class Initialized
INFO - 2023-06-23 04:58:29 --> Language Class Initialized
INFO - 2023-06-23 04:58:29 --> Loader Class Initialized
INFO - 2023-06-23 04:58:29 --> Helper loaded: url_helper
INFO - 2023-06-23 04:58:29 --> Helper loaded: form_helper
INFO - 2023-06-23 04:58:29 --> Database Driver Class Initialized
INFO - 2023-06-23 04:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 04:58:29 --> Form Validation Class Initialized
INFO - 2023-06-23 04:58:29 --> Controller Class Initialized
INFO - 2023-06-23 04:58:29 --> Model "m_datatrain" initialized
INFO - 2023-06-23 04:58:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 04:58:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 04:58:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 04:58:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 04:58:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 04:58:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 04:58:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 04:58:29 --> Final output sent to browser
INFO - 2023-06-23 05:00:22 --> Config Class Initialized
INFO - 2023-06-23 05:00:22 --> Hooks Class Initialized
INFO - 2023-06-23 05:00:22 --> Utf8 Class Initialized
INFO - 2023-06-23 05:00:22 --> URI Class Initialized
INFO - 2023-06-23 05:00:22 --> Router Class Initialized
INFO - 2023-06-23 05:00:22 --> Output Class Initialized
INFO - 2023-06-23 05:00:22 --> Security Class Initialized
INFO - 2023-06-23 05:00:22 --> Input Class Initialized
INFO - 2023-06-23 05:00:22 --> Language Class Initialized
INFO - 2023-06-23 05:00:22 --> Loader Class Initialized
INFO - 2023-06-23 05:00:22 --> Helper loaded: url_helper
INFO - 2023-06-23 05:00:22 --> Helper loaded: form_helper
INFO - 2023-06-23 05:00:22 --> Database Driver Class Initialized
INFO - 2023-06-23 05:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:00:22 --> Form Validation Class Initialized
INFO - 2023-06-23 05:00:22 --> Controller Class Initialized
INFO - 2023-06-23 05:00:22 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:00:22 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:00:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:00:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:00:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:00:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_addData.php
INFO - 2023-06-23 05:00:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:00:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:00:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:00:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:00:22 --> Final output sent to browser
INFO - 2023-06-23 05:00:28 --> Config Class Initialized
INFO - 2023-06-23 05:00:28 --> Hooks Class Initialized
INFO - 2023-06-23 05:00:28 --> Utf8 Class Initialized
INFO - 2023-06-23 05:00:28 --> URI Class Initialized
INFO - 2023-06-23 05:00:28 --> Router Class Initialized
INFO - 2023-06-23 05:00:28 --> Output Class Initialized
INFO - 2023-06-23 05:00:28 --> Security Class Initialized
INFO - 2023-06-23 05:00:28 --> Input Class Initialized
INFO - 2023-06-23 05:00:28 --> Language Class Initialized
INFO - 2023-06-23 05:00:28 --> Loader Class Initialized
INFO - 2023-06-23 05:00:28 --> Helper loaded: url_helper
INFO - 2023-06-23 05:00:28 --> Helper loaded: form_helper
INFO - 2023-06-23 05:00:28 --> Database Driver Class Initialized
INFO - 2023-06-23 05:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:00:28 --> Form Validation Class Initialized
INFO - 2023-06-23 05:00:28 --> Controller Class Initialized
INFO - 2023-06-23 05:00:28 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:00:28 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:00:28 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:00:28 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:00:28 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:00:28 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 05:00:28 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:00:28 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:00:28 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:00:28 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:00:28 --> Final output sent to browser
INFO - 2023-06-23 05:02:06 --> Config Class Initialized
INFO - 2023-06-23 05:02:06 --> Hooks Class Initialized
INFO - 2023-06-23 05:02:06 --> Utf8 Class Initialized
INFO - 2023-06-23 05:02:06 --> URI Class Initialized
INFO - 2023-06-23 05:02:06 --> Router Class Initialized
INFO - 2023-06-23 05:02:06 --> Output Class Initialized
INFO - 2023-06-23 05:02:06 --> Security Class Initialized
INFO - 2023-06-23 05:02:06 --> Input Class Initialized
INFO - 2023-06-23 05:02:06 --> Language Class Initialized
INFO - 2023-06-23 05:02:06 --> Loader Class Initialized
INFO - 2023-06-23 05:02:06 --> Helper loaded: url_helper
INFO - 2023-06-23 05:02:06 --> Helper loaded: form_helper
INFO - 2023-06-23 05:02:06 --> Database Driver Class Initialized
INFO - 2023-06-23 05:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:02:06 --> Form Validation Class Initialized
INFO - 2023-06-23 05:02:06 --> Controller Class Initialized
INFO - 2023-06-23 05:02:06 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:02:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:02:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:02:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 05:02:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:02:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:02:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:02:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:02:06 --> Final output sent to browser
INFO - 2023-06-23 05:02:19 --> Config Class Initialized
INFO - 2023-06-23 05:02:19 --> Hooks Class Initialized
INFO - 2023-06-23 05:02:19 --> Utf8 Class Initialized
INFO - 2023-06-23 05:02:19 --> URI Class Initialized
INFO - 2023-06-23 05:02:19 --> Router Class Initialized
INFO - 2023-06-23 05:02:19 --> Output Class Initialized
INFO - 2023-06-23 05:02:19 --> Security Class Initialized
INFO - 2023-06-23 05:02:19 --> Input Class Initialized
INFO - 2023-06-23 05:02:19 --> Language Class Initialized
INFO - 2023-06-23 05:02:19 --> Loader Class Initialized
INFO - 2023-06-23 05:02:19 --> Helper loaded: url_helper
INFO - 2023-06-23 05:02:19 --> Helper loaded: form_helper
INFO - 2023-06-23 05:02:19 --> Database Driver Class Initialized
INFO - 2023-06-23 05:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:02:19 --> Form Validation Class Initialized
INFO - 2023-06-23 05:02:19 --> Controller Class Initialized
INFO - 2023-06-23 05:02:19 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:02:19 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:02:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:02:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:02:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:02:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_addData.php
INFO - 2023-06-23 05:02:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:02:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:02:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:02:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:02:19 --> Final output sent to browser
INFO - 2023-06-23 05:02:34 --> Config Class Initialized
INFO - 2023-06-23 05:02:34 --> Hooks Class Initialized
INFO - 2023-06-23 05:02:34 --> Utf8 Class Initialized
INFO - 2023-06-23 05:02:34 --> URI Class Initialized
INFO - 2023-06-23 05:02:34 --> Router Class Initialized
INFO - 2023-06-23 05:02:34 --> Output Class Initialized
INFO - 2023-06-23 05:02:34 --> Security Class Initialized
INFO - 2023-06-23 05:02:34 --> Input Class Initialized
INFO - 2023-06-23 05:02:34 --> Language Class Initialized
INFO - 2023-06-23 05:02:34 --> Loader Class Initialized
INFO - 2023-06-23 05:02:34 --> Helper loaded: url_helper
INFO - 2023-06-23 05:02:34 --> Helper loaded: form_helper
INFO - 2023-06-23 05:02:34 --> Database Driver Class Initialized
INFO - 2023-06-23 05:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:02:34 --> Form Validation Class Initialized
INFO - 2023-06-23 05:02:34 --> Controller Class Initialized
INFO - 2023-06-23 05:02:34 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:02:34 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:02:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:02:35 --> Config Class Initialized
INFO - 2023-06-23 05:02:35 --> Hooks Class Initialized
INFO - 2023-06-23 05:02:35 --> Utf8 Class Initialized
INFO - 2023-06-23 05:02:35 --> URI Class Initialized
INFO - 2023-06-23 05:02:35 --> Router Class Initialized
INFO - 2023-06-23 05:02:35 --> Output Class Initialized
INFO - 2023-06-23 05:02:35 --> Security Class Initialized
INFO - 2023-06-23 05:02:35 --> Input Class Initialized
INFO - 2023-06-23 05:02:35 --> Language Class Initialized
INFO - 2023-06-23 05:02:35 --> Loader Class Initialized
INFO - 2023-06-23 05:02:35 --> Helper loaded: url_helper
INFO - 2023-06-23 05:02:35 --> Helper loaded: form_helper
INFO - 2023-06-23 05:02:35 --> Database Driver Class Initialized
INFO - 2023-06-23 05:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:02:35 --> Form Validation Class Initialized
INFO - 2023-06-23 05:02:35 --> Controller Class Initialized
INFO - 2023-06-23 05:02:35 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:02:35 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:02:35 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:02:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:02:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:02:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_addData.php
INFO - 2023-06-23 05:02:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:02:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:02:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:02:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:02:35 --> Final output sent to browser
INFO - 2023-06-23 05:02:50 --> Config Class Initialized
INFO - 2023-06-23 05:02:50 --> Hooks Class Initialized
INFO - 2023-06-23 05:02:50 --> Utf8 Class Initialized
INFO - 2023-06-23 05:02:50 --> URI Class Initialized
INFO - 2023-06-23 05:02:50 --> Router Class Initialized
INFO - 2023-06-23 05:02:50 --> Output Class Initialized
INFO - 2023-06-23 05:02:50 --> Security Class Initialized
INFO - 2023-06-23 05:02:50 --> Input Class Initialized
INFO - 2023-06-23 05:02:50 --> Language Class Initialized
INFO - 2023-06-23 05:02:50 --> Loader Class Initialized
INFO - 2023-06-23 05:02:50 --> Helper loaded: url_helper
INFO - 2023-06-23 05:02:50 --> Helper loaded: form_helper
INFO - 2023-06-23 05:02:50 --> Database Driver Class Initialized
INFO - 2023-06-23 05:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:02:50 --> Form Validation Class Initialized
INFO - 2023-06-23 05:02:50 --> Controller Class Initialized
INFO - 2023-06-23 05:02:50 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:02:50 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:02:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:02:50 --> Config Class Initialized
INFO - 2023-06-23 05:02:50 --> Hooks Class Initialized
INFO - 2023-06-23 05:02:50 --> Utf8 Class Initialized
INFO - 2023-06-23 05:02:50 --> URI Class Initialized
INFO - 2023-06-23 05:02:50 --> Router Class Initialized
INFO - 2023-06-23 05:02:50 --> Output Class Initialized
INFO - 2023-06-23 05:02:50 --> Security Class Initialized
INFO - 2023-06-23 05:02:50 --> Input Class Initialized
INFO - 2023-06-23 05:02:50 --> Language Class Initialized
INFO - 2023-06-23 05:02:50 --> Loader Class Initialized
INFO - 2023-06-23 05:02:50 --> Helper loaded: url_helper
INFO - 2023-06-23 05:02:50 --> Helper loaded: form_helper
INFO - 2023-06-23 05:02:50 --> Database Driver Class Initialized
INFO - 2023-06-23 05:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:02:50 --> Form Validation Class Initialized
INFO - 2023-06-23 05:02:50 --> Controller Class Initialized
INFO - 2023-06-23 05:02:50 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:02:50 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:02:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_addData.php
INFO - 2023-06-23 05:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:02:50 --> Final output sent to browser
INFO - 2023-06-23 05:03:25 --> Config Class Initialized
INFO - 2023-06-23 05:03:25 --> Hooks Class Initialized
INFO - 2023-06-23 05:03:25 --> Utf8 Class Initialized
INFO - 2023-06-23 05:03:25 --> URI Class Initialized
INFO - 2023-06-23 05:03:25 --> Router Class Initialized
INFO - 2023-06-23 05:03:25 --> Output Class Initialized
INFO - 2023-06-23 05:03:25 --> Security Class Initialized
INFO - 2023-06-23 05:03:25 --> Input Class Initialized
INFO - 2023-06-23 05:03:25 --> Language Class Initialized
INFO - 2023-06-23 05:03:25 --> Loader Class Initialized
INFO - 2023-06-23 05:03:25 --> Helper loaded: url_helper
INFO - 2023-06-23 05:03:25 --> Helper loaded: form_helper
INFO - 2023-06-23 05:03:25 --> Database Driver Class Initialized
INFO - 2023-06-23 05:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:03:25 --> Form Validation Class Initialized
INFO - 2023-06-23 05:03:25 --> Controller Class Initialized
INFO - 2023-06-23 05:03:25 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:03:25 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:03:25 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:03:25 --> Config Class Initialized
INFO - 2023-06-23 05:03:25 --> Hooks Class Initialized
INFO - 2023-06-23 05:03:25 --> Utf8 Class Initialized
INFO - 2023-06-23 05:03:25 --> URI Class Initialized
INFO - 2023-06-23 05:03:25 --> Router Class Initialized
INFO - 2023-06-23 05:03:25 --> Output Class Initialized
INFO - 2023-06-23 05:03:25 --> Security Class Initialized
INFO - 2023-06-23 05:03:25 --> Input Class Initialized
INFO - 2023-06-23 05:03:25 --> Language Class Initialized
INFO - 2023-06-23 05:03:25 --> Loader Class Initialized
INFO - 2023-06-23 05:03:25 --> Helper loaded: url_helper
INFO - 2023-06-23 05:03:25 --> Helper loaded: form_helper
INFO - 2023-06-23 05:03:25 --> Database Driver Class Initialized
INFO - 2023-06-23 05:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:03:25 --> Form Validation Class Initialized
INFO - 2023-06-23 05:03:25 --> Controller Class Initialized
INFO - 2023-06-23 05:03:25 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:03:25 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:03:25 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:03:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:03:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:03:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_addData.php
INFO - 2023-06-23 05:03:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:03:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:03:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:03:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:03:25 --> Final output sent to browser
INFO - 2023-06-23 05:04:30 --> Config Class Initialized
INFO - 2023-06-23 05:04:30 --> Hooks Class Initialized
INFO - 2023-06-23 05:04:30 --> Utf8 Class Initialized
INFO - 2023-06-23 05:04:30 --> URI Class Initialized
INFO - 2023-06-23 05:04:30 --> Router Class Initialized
INFO - 2023-06-23 05:04:30 --> Output Class Initialized
INFO - 2023-06-23 05:04:30 --> Security Class Initialized
INFO - 2023-06-23 05:04:30 --> Input Class Initialized
INFO - 2023-06-23 05:04:30 --> Language Class Initialized
INFO - 2023-06-23 05:04:30 --> Loader Class Initialized
INFO - 2023-06-23 05:04:30 --> Helper loaded: url_helper
INFO - 2023-06-23 05:04:30 --> Helper loaded: form_helper
INFO - 2023-06-23 05:04:30 --> Database Driver Class Initialized
INFO - 2023-06-23 05:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:04:30 --> Form Validation Class Initialized
INFO - 2023-06-23 05:04:30 --> Controller Class Initialized
INFO - 2023-06-23 05:04:30 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:04:30 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:04:30 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:04:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:04:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:04:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 05:04:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:04:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:04:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:04:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:04:30 --> Final output sent to browser
INFO - 2023-06-23 05:04:39 --> Config Class Initialized
INFO - 2023-06-23 05:04:39 --> Hooks Class Initialized
INFO - 2023-06-23 05:04:39 --> Utf8 Class Initialized
INFO - 2023-06-23 05:04:39 --> URI Class Initialized
INFO - 2023-06-23 05:04:39 --> Router Class Initialized
INFO - 2023-06-23 05:04:39 --> Output Class Initialized
INFO - 2023-06-23 05:04:39 --> Security Class Initialized
INFO - 2023-06-23 05:04:39 --> Input Class Initialized
INFO - 2023-06-23 05:04:39 --> Language Class Initialized
INFO - 2023-06-23 05:04:39 --> Loader Class Initialized
INFO - 2023-06-23 05:04:39 --> Helper loaded: url_helper
INFO - 2023-06-23 05:04:39 --> Helper loaded: form_helper
INFO - 2023-06-23 05:04:39 --> Database Driver Class Initialized
INFO - 2023-06-23 05:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:04:39 --> Form Validation Class Initialized
INFO - 2023-06-23 05:04:39 --> Controller Class Initialized
INFO - 2023-06-23 05:04:39 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:04:39 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:04:39 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:04:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:04:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:04:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_addData.php
INFO - 2023-06-23 05:04:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:04:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:04:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:04:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:04:39 --> Final output sent to browser
INFO - 2023-06-23 05:04:41 --> Config Class Initialized
INFO - 2023-06-23 05:04:41 --> Hooks Class Initialized
INFO - 2023-06-23 05:04:41 --> Utf8 Class Initialized
INFO - 2023-06-23 05:04:41 --> URI Class Initialized
INFO - 2023-06-23 05:04:41 --> Router Class Initialized
INFO - 2023-06-23 05:04:41 --> Output Class Initialized
INFO - 2023-06-23 05:04:41 --> Security Class Initialized
INFO - 2023-06-23 05:04:41 --> Input Class Initialized
INFO - 2023-06-23 05:04:41 --> Language Class Initialized
INFO - 2023-06-23 05:04:41 --> Loader Class Initialized
INFO - 2023-06-23 05:04:41 --> Helper loaded: url_helper
INFO - 2023-06-23 05:04:41 --> Helper loaded: form_helper
INFO - 2023-06-23 05:04:41 --> Database Driver Class Initialized
INFO - 2023-06-23 05:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:04:41 --> Form Validation Class Initialized
INFO - 2023-06-23 05:04:41 --> Controller Class Initialized
INFO - 2023-06-23 05:04:41 --> Model "m_datatest" initialized
ERROR - 2023-06-23 05:04:41 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdepresi\application\controllers\C_pengujian.php 81
INFO - 2023-06-23 05:04:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:04:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:04:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\pengujian.php
INFO - 2023-06-23 05:04:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:04:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:04:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:04:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:04:42 --> Final output sent to browser
INFO - 2023-06-23 05:10:55 --> Config Class Initialized
INFO - 2023-06-23 05:10:55 --> Hooks Class Initialized
INFO - 2023-06-23 05:10:55 --> Utf8 Class Initialized
INFO - 2023-06-23 05:10:55 --> URI Class Initialized
INFO - 2023-06-23 05:10:55 --> Router Class Initialized
INFO - 2023-06-23 05:10:55 --> Output Class Initialized
INFO - 2023-06-23 05:10:55 --> Security Class Initialized
INFO - 2023-06-23 05:10:55 --> Input Class Initialized
INFO - 2023-06-23 05:10:55 --> Language Class Initialized
INFO - 2023-06-23 05:10:55 --> Loader Class Initialized
INFO - 2023-06-23 05:10:55 --> Helper loaded: url_helper
INFO - 2023-06-23 05:10:55 --> Helper loaded: form_helper
INFO - 2023-06-23 05:10:55 --> Database Driver Class Initialized
INFO - 2023-06-23 05:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:10:55 --> Form Validation Class Initialized
INFO - 2023-06-23 05:10:55 --> Controller Class Initialized
INFO - 2023-06-23 05:10:55 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:10:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:10:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:10:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\pengujian.php
INFO - 2023-06-23 05:10:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:10:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:10:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:10:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:10:55 --> Final output sent to browser
INFO - 2023-06-23 05:11:05 --> Config Class Initialized
INFO - 2023-06-23 05:11:05 --> Hooks Class Initialized
INFO - 2023-06-23 05:11:05 --> Utf8 Class Initialized
INFO - 2023-06-23 05:11:05 --> URI Class Initialized
INFO - 2023-06-23 05:11:05 --> Router Class Initialized
INFO - 2023-06-23 05:11:05 --> Output Class Initialized
INFO - 2023-06-23 05:11:05 --> Security Class Initialized
INFO - 2023-06-23 05:11:05 --> Input Class Initialized
INFO - 2023-06-23 05:11:05 --> Language Class Initialized
INFO - 2023-06-23 05:11:05 --> Loader Class Initialized
INFO - 2023-06-23 05:11:05 --> Helper loaded: url_helper
INFO - 2023-06-23 05:11:05 --> Helper loaded: form_helper
INFO - 2023-06-23 05:11:05 --> Database Driver Class Initialized
INFO - 2023-06-23 05:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:11:05 --> Form Validation Class Initialized
INFO - 2023-06-23 05:11:05 --> Controller Class Initialized
INFO - 2023-06-23 05:11:05 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:11:05 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:11:05 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:11:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:11:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:11:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 05:11:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:11:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:11:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:11:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:11:05 --> Final output sent to browser
INFO - 2023-06-23 05:11:06 --> Config Class Initialized
INFO - 2023-06-23 05:11:06 --> Hooks Class Initialized
INFO - 2023-06-23 05:11:06 --> Utf8 Class Initialized
INFO - 2023-06-23 05:11:06 --> URI Class Initialized
INFO - 2023-06-23 05:11:06 --> Router Class Initialized
INFO - 2023-06-23 05:11:06 --> Output Class Initialized
INFO - 2023-06-23 05:11:06 --> Security Class Initialized
INFO - 2023-06-23 05:11:06 --> Input Class Initialized
INFO - 2023-06-23 05:11:06 --> Language Class Initialized
INFO - 2023-06-23 05:11:06 --> Loader Class Initialized
INFO - 2023-06-23 05:11:06 --> Helper loaded: url_helper
INFO - 2023-06-23 05:11:06 --> Helper loaded: form_helper
INFO - 2023-06-23 05:11:06 --> Database Driver Class Initialized
INFO - 2023-06-23 05:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:11:06 --> Form Validation Class Initialized
INFO - 2023-06-23 05:11:06 --> Controller Class Initialized
INFO - 2023-06-23 05:11:06 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:11:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:11:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:11:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 05:11:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 05:11:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:11:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:11:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 05:11:06 --> Final output sent to browser
INFO - 2023-06-23 05:11:09 --> Config Class Initialized
INFO - 2023-06-23 05:11:09 --> Hooks Class Initialized
INFO - 2023-06-23 05:11:10 --> Utf8 Class Initialized
INFO - 2023-06-23 05:11:10 --> URI Class Initialized
INFO - 2023-06-23 05:11:10 --> Router Class Initialized
INFO - 2023-06-23 05:11:10 --> Output Class Initialized
INFO - 2023-06-23 05:11:10 --> Security Class Initialized
INFO - 2023-06-23 05:11:10 --> Input Class Initialized
INFO - 2023-06-23 05:11:10 --> Language Class Initialized
INFO - 2023-06-23 05:11:10 --> Loader Class Initialized
INFO - 2023-06-23 05:11:10 --> Helper loaded: url_helper
INFO - 2023-06-23 05:11:10 --> Helper loaded: form_helper
INFO - 2023-06-23 05:11:10 --> Database Driver Class Initialized
INFO - 2023-06-23 05:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:11:10 --> Form Validation Class Initialized
INFO - 2023-06-23 05:11:10 --> Controller Class Initialized
INFO - 2023-06-23 05:11:10 --> Model "m_user" initialized
INFO - 2023-06-23 05:11:10 --> Config Class Initialized
INFO - 2023-06-23 05:11:10 --> Hooks Class Initialized
INFO - 2023-06-23 05:11:10 --> Utf8 Class Initialized
INFO - 2023-06-23 05:11:10 --> URI Class Initialized
INFO - 2023-06-23 05:11:10 --> Router Class Initialized
INFO - 2023-06-23 05:11:10 --> Output Class Initialized
INFO - 2023-06-23 05:11:10 --> Security Class Initialized
INFO - 2023-06-23 05:11:10 --> Input Class Initialized
INFO - 2023-06-23 05:11:10 --> Language Class Initialized
INFO - 2023-06-23 05:11:10 --> Loader Class Initialized
INFO - 2023-06-23 05:11:10 --> Helper loaded: url_helper
INFO - 2023-06-23 05:11:10 --> Helper loaded: form_helper
INFO - 2023-06-23 05:11:10 --> Database Driver Class Initialized
INFO - 2023-06-23 05:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:11:10 --> Form Validation Class Initialized
INFO - 2023-06-23 05:11:10 --> Controller Class Initialized
INFO - 2023-06-23 05:11:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-23 05:11:10 --> Final output sent to browser
INFO - 2023-06-23 05:11:11 --> Config Class Initialized
INFO - 2023-06-23 05:11:11 --> Hooks Class Initialized
INFO - 2023-06-23 05:11:11 --> Utf8 Class Initialized
INFO - 2023-06-23 05:11:11 --> URI Class Initialized
INFO - 2023-06-23 05:11:11 --> Router Class Initialized
INFO - 2023-06-23 05:11:11 --> Output Class Initialized
INFO - 2023-06-23 05:11:11 --> Security Class Initialized
INFO - 2023-06-23 05:11:11 --> Input Class Initialized
INFO - 2023-06-23 05:11:11 --> Language Class Initialized
INFO - 2023-06-23 05:11:11 --> Loader Class Initialized
INFO - 2023-06-23 05:11:11 --> Helper loaded: url_helper
INFO - 2023-06-23 05:11:11 --> Helper loaded: form_helper
INFO - 2023-06-23 05:11:11 --> Database Driver Class Initialized
INFO - 2023-06-23 05:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:11:11 --> Form Validation Class Initialized
INFO - 2023-06-23 05:11:11 --> Controller Class Initialized
INFO - 2023-06-23 05:11:11 --> Model "m_user" initialized
INFO - 2023-06-23 05:11:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:11:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:11:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 05:11:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:11:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:11:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-23 05:11:11 --> Final output sent to browser
INFO - 2023-06-23 05:11:20 --> Config Class Initialized
INFO - 2023-06-23 05:11:20 --> Hooks Class Initialized
INFO - 2023-06-23 05:11:20 --> Utf8 Class Initialized
INFO - 2023-06-23 05:11:20 --> URI Class Initialized
INFO - 2023-06-23 05:11:20 --> Router Class Initialized
INFO - 2023-06-23 05:11:20 --> Output Class Initialized
INFO - 2023-06-23 05:11:20 --> Security Class Initialized
INFO - 2023-06-23 05:11:20 --> Input Class Initialized
INFO - 2023-06-23 05:11:20 --> Language Class Initialized
INFO - 2023-06-23 05:11:20 --> Loader Class Initialized
INFO - 2023-06-23 05:11:20 --> Helper loaded: url_helper
INFO - 2023-06-23 05:11:20 --> Helper loaded: form_helper
INFO - 2023-06-23 05:11:20 --> Database Driver Class Initialized
INFO - 2023-06-23 05:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 05:11:20 --> Form Validation Class Initialized
INFO - 2023-06-23 05:11:20 --> Controller Class Initialized
INFO - 2023-06-23 05:11:20 --> Model "m_datatrain" initialized
INFO - 2023-06-23 05:11:20 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 05:11:20 --> Model "m_datatest" initialized
INFO - 2023-06-23 05:11:20 --> Model "M_solusi" initialized
INFO - 2023-06-23 05:11:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 05:11:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 05:11:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-23 05:11:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 05:11:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 05:11:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 05:11:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 05:11:20 --> Final output sent to browser
INFO - 2023-06-23 08:58:40 --> Config Class Initialized
INFO - 2023-06-23 08:58:40 --> Hooks Class Initialized
INFO - 2023-06-23 08:58:40 --> Utf8 Class Initialized
INFO - 2023-06-23 08:58:40 --> URI Class Initialized
INFO - 2023-06-23 08:58:40 --> Router Class Initialized
INFO - 2023-06-23 08:58:40 --> Output Class Initialized
INFO - 2023-06-23 08:58:40 --> Security Class Initialized
INFO - 2023-06-23 08:58:40 --> Input Class Initialized
INFO - 2023-06-23 08:58:40 --> Language Class Initialized
INFO - 2023-06-23 08:58:40 --> Loader Class Initialized
INFO - 2023-06-23 08:58:40 --> Helper loaded: url_helper
INFO - 2023-06-23 08:58:40 --> Helper loaded: form_helper
INFO - 2023-06-23 08:58:40 --> Database Driver Class Initialized
INFO - 2023-06-23 08:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 08:58:40 --> Form Validation Class Initialized
INFO - 2023-06-23 08:58:40 --> Controller Class Initialized
INFO - 2023-06-23 08:58:40 --> Model "m_user" initialized
INFO - 2023-06-23 08:58:40 --> Config Class Initialized
INFO - 2023-06-23 08:58:40 --> Hooks Class Initialized
INFO - 2023-06-23 08:58:40 --> Utf8 Class Initialized
INFO - 2023-06-23 08:58:40 --> URI Class Initialized
INFO - 2023-06-23 08:58:40 --> Router Class Initialized
INFO - 2023-06-23 08:58:40 --> Output Class Initialized
INFO - 2023-06-23 08:58:40 --> Security Class Initialized
INFO - 2023-06-23 08:58:40 --> Input Class Initialized
INFO - 2023-06-23 08:58:40 --> Language Class Initialized
INFO - 2023-06-23 08:58:40 --> Loader Class Initialized
INFO - 2023-06-23 08:58:40 --> Helper loaded: url_helper
INFO - 2023-06-23 08:58:40 --> Helper loaded: form_helper
INFO - 2023-06-23 08:58:40 --> Database Driver Class Initialized
INFO - 2023-06-23 08:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 08:58:40 --> Form Validation Class Initialized
INFO - 2023-06-23 08:58:40 --> Controller Class Initialized
INFO - 2023-06-23 08:58:40 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-23 08:58:40 --> Final output sent to browser
INFO - 2023-06-23 08:58:41 --> Config Class Initialized
INFO - 2023-06-23 08:58:41 --> Hooks Class Initialized
INFO - 2023-06-23 08:58:41 --> Utf8 Class Initialized
INFO - 2023-06-23 08:58:41 --> URI Class Initialized
INFO - 2023-06-23 08:58:41 --> Router Class Initialized
INFO - 2023-06-23 08:58:41 --> Output Class Initialized
INFO - 2023-06-23 08:58:41 --> Security Class Initialized
INFO - 2023-06-23 08:58:41 --> Input Class Initialized
INFO - 2023-06-23 08:58:41 --> Language Class Initialized
INFO - 2023-06-23 08:58:41 --> Loader Class Initialized
INFO - 2023-06-23 08:58:41 --> Helper loaded: url_helper
INFO - 2023-06-23 08:58:41 --> Helper loaded: form_helper
INFO - 2023-06-23 08:58:41 --> Database Driver Class Initialized
INFO - 2023-06-23 08:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 08:58:41 --> Form Validation Class Initialized
INFO - 2023-06-23 08:58:41 --> Controller Class Initialized
INFO - 2023-06-23 08:58:41 --> Model "m_user" initialized
INFO - 2023-06-23 08:58:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_header.php
INFO - 2023-06-23 08:58:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\auth/login.php
INFO - 2023-06-23 08:58:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_footer.php
INFO - 2023-06-23 08:58:41 --> Final output sent to browser
INFO - 2023-06-23 08:58:46 --> Config Class Initialized
INFO - 2023-06-23 08:58:46 --> Hooks Class Initialized
INFO - 2023-06-23 08:58:46 --> Utf8 Class Initialized
INFO - 2023-06-23 08:58:46 --> URI Class Initialized
INFO - 2023-06-23 08:58:46 --> Router Class Initialized
INFO - 2023-06-23 08:58:46 --> Output Class Initialized
INFO - 2023-06-23 08:58:46 --> Security Class Initialized
INFO - 2023-06-23 08:58:46 --> Input Class Initialized
INFO - 2023-06-23 08:58:46 --> Language Class Initialized
INFO - 2023-06-23 08:58:46 --> Loader Class Initialized
INFO - 2023-06-23 08:58:46 --> Helper loaded: url_helper
INFO - 2023-06-23 08:58:46 --> Helper loaded: form_helper
INFO - 2023-06-23 08:58:47 --> Database Driver Class Initialized
INFO - 2023-06-23 08:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 08:58:47 --> Form Validation Class Initialized
INFO - 2023-06-23 08:58:47 --> Controller Class Initialized
INFO - 2023-06-23 08:58:47 --> Model "m_user" initialized
INFO - 2023-06-23 08:58:47 --> Config Class Initialized
INFO - 2023-06-23 08:58:47 --> Hooks Class Initialized
INFO - 2023-06-23 08:58:47 --> Utf8 Class Initialized
INFO - 2023-06-23 08:58:47 --> URI Class Initialized
INFO - 2023-06-23 08:58:47 --> Router Class Initialized
INFO - 2023-06-23 08:58:47 --> Output Class Initialized
INFO - 2023-06-23 08:58:47 --> Security Class Initialized
INFO - 2023-06-23 08:58:47 --> Input Class Initialized
INFO - 2023-06-23 08:58:47 --> Language Class Initialized
INFO - 2023-06-23 08:58:47 --> Loader Class Initialized
INFO - 2023-06-23 08:58:47 --> Helper loaded: url_helper
INFO - 2023-06-23 08:58:47 --> Helper loaded: form_helper
INFO - 2023-06-23 08:58:47 --> Database Driver Class Initialized
INFO - 2023-06-23 08:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 08:58:47 --> Form Validation Class Initialized
INFO - 2023-06-23 08:58:47 --> Controller Class Initialized
INFO - 2023-06-23 08:58:47 --> Model "m_user" initialized
INFO - 2023-06-23 08:58:47 --> Model "m_datatrain" initialized
INFO - 2023-06-23 08:58:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 08:58:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 08:58:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 08:58:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 08:58:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 08:58:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home.php
INFO - 2023-06-23 08:58:47 --> Final output sent to browser
INFO - 2023-06-23 08:58:48 --> Config Class Initialized
INFO - 2023-06-23 08:58:48 --> Hooks Class Initialized
INFO - 2023-06-23 08:58:48 --> Utf8 Class Initialized
INFO - 2023-06-23 08:58:48 --> URI Class Initialized
INFO - 2023-06-23 08:58:48 --> Router Class Initialized
INFO - 2023-06-23 08:58:48 --> Output Class Initialized
INFO - 2023-06-23 08:58:48 --> Security Class Initialized
INFO - 2023-06-23 08:58:48 --> Input Class Initialized
INFO - 2023-06-23 08:58:48 --> Language Class Initialized
INFO - 2023-06-23 08:58:48 --> Loader Class Initialized
INFO - 2023-06-23 08:58:48 --> Helper loaded: url_helper
INFO - 2023-06-23 08:58:48 --> Helper loaded: form_helper
INFO - 2023-06-23 08:58:48 --> Database Driver Class Initialized
INFO - 2023-06-23 08:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 08:58:48 --> Form Validation Class Initialized
INFO - 2023-06-23 08:58:48 --> Controller Class Initialized
INFO - 2023-06-23 08:58:48 --> Model "m_datatrain" initialized
INFO - 2023-06-23 08:58:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 08:58:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 08:58:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 08:58:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 08:58:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 08:58:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 08:58:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 08:58:48 --> Final output sent to browser
INFO - 2023-06-23 08:58:54 --> Config Class Initialized
INFO - 2023-06-23 08:58:54 --> Hooks Class Initialized
INFO - 2023-06-23 08:58:54 --> Utf8 Class Initialized
INFO - 2023-06-23 08:58:54 --> URI Class Initialized
INFO - 2023-06-23 08:58:54 --> Router Class Initialized
INFO - 2023-06-23 08:58:54 --> Output Class Initialized
INFO - 2023-06-23 08:58:54 --> Security Class Initialized
INFO - 2023-06-23 08:58:54 --> Input Class Initialized
INFO - 2023-06-23 08:58:54 --> Language Class Initialized
INFO - 2023-06-23 08:58:54 --> Loader Class Initialized
INFO - 2023-06-23 08:58:54 --> Helper loaded: url_helper
INFO - 2023-06-23 08:58:54 --> Helper loaded: form_helper
INFO - 2023-06-23 08:58:54 --> Database Driver Class Initialized
INFO - 2023-06-23 08:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 08:58:54 --> Form Validation Class Initialized
INFO - 2023-06-23 08:58:54 --> Controller Class Initialized
INFO - 2023-06-23 08:58:54 --> Model "m_datatest" initialized
INFO - 2023-06-23 08:58:54 --> Model "m_datatrain" initialized
INFO - 2023-06-23 08:58:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 08:58:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 08:58:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 08:58:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 08:58:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 08:58:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 08:58:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 08:58:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 08:58:54 --> Final output sent to browser
INFO - 2023-06-23 08:59:12 --> Config Class Initialized
INFO - 2023-06-23 08:59:12 --> Hooks Class Initialized
INFO - 2023-06-23 08:59:12 --> Utf8 Class Initialized
INFO - 2023-06-23 08:59:12 --> URI Class Initialized
INFO - 2023-06-23 08:59:12 --> Router Class Initialized
INFO - 2023-06-23 08:59:12 --> Output Class Initialized
INFO - 2023-06-23 08:59:12 --> Security Class Initialized
INFO - 2023-06-23 08:59:12 --> Input Class Initialized
INFO - 2023-06-23 08:59:12 --> Language Class Initialized
INFO - 2023-06-23 08:59:12 --> Loader Class Initialized
INFO - 2023-06-23 08:59:12 --> Helper loaded: url_helper
INFO - 2023-06-23 08:59:12 --> Helper loaded: form_helper
INFO - 2023-06-23 08:59:12 --> Database Driver Class Initialized
INFO - 2023-06-23 08:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 08:59:12 --> Form Validation Class Initialized
INFO - 2023-06-23 08:59:12 --> Controller Class Initialized
INFO - 2023-06-23 08:59:12 --> Model "m_datatest" initialized
INFO - 2023-06-23 08:59:12 --> Model "m_datatrain" initialized
INFO - 2023-06-23 08:59:12 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 08:59:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 08:59:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 08:59:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_addData.php
INFO - 2023-06-23 08:59:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 08:59:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 08:59:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 08:59:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 08:59:12 --> Final output sent to browser
INFO - 2023-06-23 08:59:41 --> Config Class Initialized
INFO - 2023-06-23 08:59:41 --> Hooks Class Initialized
INFO - 2023-06-23 08:59:41 --> Utf8 Class Initialized
INFO - 2023-06-23 08:59:41 --> URI Class Initialized
INFO - 2023-06-23 08:59:41 --> Router Class Initialized
INFO - 2023-06-23 08:59:41 --> Output Class Initialized
INFO - 2023-06-23 08:59:41 --> Security Class Initialized
INFO - 2023-06-23 08:59:41 --> Input Class Initialized
INFO - 2023-06-23 08:59:41 --> Language Class Initialized
INFO - 2023-06-23 08:59:41 --> Loader Class Initialized
INFO - 2023-06-23 08:59:41 --> Helper loaded: url_helper
INFO - 2023-06-23 08:59:41 --> Helper loaded: form_helper
INFO - 2023-06-23 08:59:41 --> Database Driver Class Initialized
INFO - 2023-06-23 08:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 08:59:41 --> Form Validation Class Initialized
INFO - 2023-06-23 08:59:41 --> Controller Class Initialized
INFO - 2023-06-23 08:59:41 --> Model "m_datatest" initialized
INFO - 2023-06-23 08:59:41 --> Model "m_datatrain" initialized
INFO - 2023-06-23 08:59:41 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 08:59:41 --> Config Class Initialized
INFO - 2023-06-23 08:59:41 --> Hooks Class Initialized
INFO - 2023-06-23 08:59:41 --> Utf8 Class Initialized
INFO - 2023-06-23 08:59:41 --> URI Class Initialized
INFO - 2023-06-23 08:59:41 --> Router Class Initialized
INFO - 2023-06-23 08:59:41 --> Output Class Initialized
INFO - 2023-06-23 08:59:41 --> Security Class Initialized
INFO - 2023-06-23 08:59:41 --> Input Class Initialized
INFO - 2023-06-23 08:59:41 --> Language Class Initialized
INFO - 2023-06-23 08:59:41 --> Loader Class Initialized
INFO - 2023-06-23 08:59:41 --> Helper loaded: url_helper
INFO - 2023-06-23 08:59:41 --> Helper loaded: form_helper
INFO - 2023-06-23 08:59:41 --> Database Driver Class Initialized
INFO - 2023-06-23 08:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 08:59:41 --> Form Validation Class Initialized
INFO - 2023-06-23 08:59:41 --> Controller Class Initialized
INFO - 2023-06-23 08:59:41 --> Model "m_datatrain" initialized
INFO - 2023-06-23 08:59:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 08:59:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 08:59:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 08:59:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 08:59:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 08:59:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 08:59:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 08:59:41 --> Final output sent to browser
INFO - 2023-06-23 08:59:46 --> Config Class Initialized
INFO - 2023-06-23 08:59:46 --> Hooks Class Initialized
INFO - 2023-06-23 08:59:46 --> Utf8 Class Initialized
INFO - 2023-06-23 08:59:46 --> URI Class Initialized
INFO - 2023-06-23 08:59:46 --> Router Class Initialized
INFO - 2023-06-23 08:59:46 --> Output Class Initialized
INFO - 2023-06-23 08:59:46 --> Security Class Initialized
INFO - 2023-06-23 08:59:46 --> Input Class Initialized
INFO - 2023-06-23 08:59:46 --> Language Class Initialized
INFO - 2023-06-23 08:59:46 --> Loader Class Initialized
INFO - 2023-06-23 08:59:46 --> Helper loaded: url_helper
INFO - 2023-06-23 08:59:46 --> Helper loaded: form_helper
INFO - 2023-06-23 08:59:46 --> Database Driver Class Initialized
INFO - 2023-06-23 08:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 08:59:46 --> Form Validation Class Initialized
INFO - 2023-06-23 08:59:46 --> Controller Class Initialized
INFO - 2023-06-23 08:59:46 --> Model "m_datatrain" initialized
INFO - 2023-06-23 08:59:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 08:59:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 08:59:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 08:59:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 08:59:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 08:59:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 08:59:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 08:59:46 --> Final output sent to browser
INFO - 2023-06-23 09:00:56 --> Config Class Initialized
INFO - 2023-06-23 09:00:56 --> Hooks Class Initialized
INFO - 2023-06-23 09:00:56 --> Utf8 Class Initialized
INFO - 2023-06-23 09:00:56 --> URI Class Initialized
INFO - 2023-06-23 09:00:56 --> Router Class Initialized
INFO - 2023-06-23 09:00:56 --> Output Class Initialized
INFO - 2023-06-23 09:00:56 --> Security Class Initialized
INFO - 2023-06-23 09:00:56 --> Input Class Initialized
INFO - 2023-06-23 09:00:56 --> Language Class Initialized
INFO - 2023-06-23 09:00:56 --> Loader Class Initialized
INFO - 2023-06-23 09:00:56 --> Helper loaded: url_helper
INFO - 2023-06-23 09:00:56 --> Helper loaded: form_helper
INFO - 2023-06-23 09:00:56 --> Database Driver Class Initialized
INFO - 2023-06-23 09:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:00:56 --> Form Validation Class Initialized
INFO - 2023-06-23 09:00:56 --> Controller Class Initialized
INFO - 2023-06-23 09:00:56 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:00:56 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:00:56 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:00:56 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 09:00:56 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:00:56 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:00:56 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:00:56 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:00:56 --> Final output sent to browser
INFO - 2023-06-23 09:00:58 --> Config Class Initialized
INFO - 2023-06-23 09:00:58 --> Hooks Class Initialized
INFO - 2023-06-23 09:00:58 --> Utf8 Class Initialized
INFO - 2023-06-23 09:00:58 --> URI Class Initialized
INFO - 2023-06-23 09:00:58 --> Router Class Initialized
INFO - 2023-06-23 09:00:58 --> Output Class Initialized
INFO - 2023-06-23 09:00:58 --> Security Class Initialized
INFO - 2023-06-23 09:00:58 --> Input Class Initialized
INFO - 2023-06-23 09:00:58 --> Language Class Initialized
INFO - 2023-06-23 09:00:58 --> Loader Class Initialized
INFO - 2023-06-23 09:00:58 --> Helper loaded: url_helper
INFO - 2023-06-23 09:00:58 --> Helper loaded: form_helper
INFO - 2023-06-23 09:00:58 --> Database Driver Class Initialized
INFO - 2023-06-23 09:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:00:58 --> Form Validation Class Initialized
INFO - 2023-06-23 09:00:58 --> Controller Class Initialized
INFO - 2023-06-23 09:00:58 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:00:58 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:00:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:00:58 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:00:58 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:00:58 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 09:00:58 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:00:58 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:00:58 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:00:58 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:00:58 --> Final output sent to browser
INFO - 2023-06-23 09:01:00 --> Config Class Initialized
INFO - 2023-06-23 09:01:00 --> Hooks Class Initialized
INFO - 2023-06-23 09:01:00 --> Utf8 Class Initialized
INFO - 2023-06-23 09:01:00 --> URI Class Initialized
INFO - 2023-06-23 09:01:00 --> Router Class Initialized
INFO - 2023-06-23 09:01:00 --> Output Class Initialized
INFO - 2023-06-23 09:01:00 --> Security Class Initialized
INFO - 2023-06-23 09:01:00 --> Input Class Initialized
INFO - 2023-06-23 09:01:00 --> Language Class Initialized
INFO - 2023-06-23 09:01:00 --> Loader Class Initialized
INFO - 2023-06-23 09:01:00 --> Helper loaded: url_helper
INFO - 2023-06-23 09:01:00 --> Helper loaded: form_helper
INFO - 2023-06-23 09:01:00 --> Database Driver Class Initialized
INFO - 2023-06-23 09:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:01:00 --> Form Validation Class Initialized
INFO - 2023-06-23 09:01:00 --> Controller Class Initialized
INFO - 2023-06-23 09:01:00 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:01:00 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:01:00 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:01:00 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\pengujian.php
INFO - 2023-06-23 09:01:00 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:01:00 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:01:00 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:01:00 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:01:00 --> Final output sent to browser
INFO - 2023-06-23 09:01:03 --> Config Class Initialized
INFO - 2023-06-23 09:01:03 --> Hooks Class Initialized
INFO - 2023-06-23 09:01:03 --> Utf8 Class Initialized
INFO - 2023-06-23 09:01:03 --> URI Class Initialized
INFO - 2023-06-23 09:01:03 --> Router Class Initialized
INFO - 2023-06-23 09:01:03 --> Output Class Initialized
INFO - 2023-06-23 09:01:03 --> Security Class Initialized
INFO - 2023-06-23 09:01:03 --> Input Class Initialized
INFO - 2023-06-23 09:01:03 --> Language Class Initialized
INFO - 2023-06-23 09:01:03 --> Loader Class Initialized
INFO - 2023-06-23 09:01:03 --> Helper loaded: url_helper
INFO - 2023-06-23 09:01:03 --> Helper loaded: form_helper
INFO - 2023-06-23 09:01:03 --> Database Driver Class Initialized
INFO - 2023-06-23 09:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:01:03 --> Form Validation Class Initialized
INFO - 2023-06-23 09:01:03 --> Controller Class Initialized
INFO - 2023-06-23 09:01:03 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:01:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:01:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:01:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 09:01:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:01:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:01:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:01:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:01:03 --> Final output sent to browser
INFO - 2023-06-23 09:01:05 --> Config Class Initialized
INFO - 2023-06-23 09:01:05 --> Hooks Class Initialized
INFO - 2023-06-23 09:01:05 --> Utf8 Class Initialized
INFO - 2023-06-23 09:01:05 --> URI Class Initialized
INFO - 2023-06-23 09:01:05 --> Router Class Initialized
INFO - 2023-06-23 09:01:05 --> Output Class Initialized
INFO - 2023-06-23 09:01:05 --> Security Class Initialized
INFO - 2023-06-23 09:01:05 --> Input Class Initialized
INFO - 2023-06-23 09:01:05 --> Language Class Initialized
INFO - 2023-06-23 09:01:05 --> Loader Class Initialized
INFO - 2023-06-23 09:01:05 --> Helper loaded: url_helper
INFO - 2023-06-23 09:01:05 --> Helper loaded: form_helper
INFO - 2023-06-23 09:01:05 --> Database Driver Class Initialized
INFO - 2023-06-23 09:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:01:05 --> Form Validation Class Initialized
INFO - 2023-06-23 09:01:05 --> Controller Class Initialized
INFO - 2023-06-23 09:01:05 --> Model "m_user" initialized
INFO - 2023-06-23 09:01:05 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:01:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:01:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:01:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:01:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:01:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:01:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home.php
INFO - 2023-06-23 09:01:05 --> Final output sent to browser
INFO - 2023-06-23 09:01:57 --> Config Class Initialized
INFO - 2023-06-23 09:01:57 --> Hooks Class Initialized
INFO - 2023-06-23 09:01:57 --> Utf8 Class Initialized
INFO - 2023-06-23 09:01:57 --> URI Class Initialized
INFO - 2023-06-23 09:01:57 --> Router Class Initialized
INFO - 2023-06-23 09:01:57 --> Output Class Initialized
INFO - 2023-06-23 09:01:57 --> Security Class Initialized
INFO - 2023-06-23 09:01:57 --> Input Class Initialized
INFO - 2023-06-23 09:01:57 --> Language Class Initialized
INFO - 2023-06-23 09:01:57 --> Loader Class Initialized
INFO - 2023-06-23 09:01:57 --> Helper loaded: url_helper
INFO - 2023-06-23 09:01:57 --> Helper loaded: form_helper
INFO - 2023-06-23 09:01:57 --> Database Driver Class Initialized
INFO - 2023-06-23 09:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:01:57 --> Form Validation Class Initialized
INFO - 2023-06-23 09:01:57 --> Controller Class Initialized
INFO - 2023-06-23 09:01:57 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:01:57 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:01:57 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:01:57 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 09:01:57 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:01:57 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:01:57 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:01:57 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:01:57 --> Final output sent to browser
INFO - 2023-06-23 09:02:12 --> Config Class Initialized
INFO - 2023-06-23 09:02:12 --> Hooks Class Initialized
INFO - 2023-06-23 09:02:12 --> Utf8 Class Initialized
INFO - 2023-06-23 09:02:12 --> URI Class Initialized
INFO - 2023-06-23 09:02:12 --> Router Class Initialized
INFO - 2023-06-23 09:02:12 --> Output Class Initialized
INFO - 2023-06-23 09:02:12 --> Security Class Initialized
INFO - 2023-06-23 09:02:12 --> Input Class Initialized
INFO - 2023-06-23 09:02:12 --> Language Class Initialized
INFO - 2023-06-23 09:02:12 --> Loader Class Initialized
INFO - 2023-06-23 09:02:12 --> Helper loaded: url_helper
INFO - 2023-06-23 09:02:12 --> Helper loaded: form_helper
INFO - 2023-06-23 09:02:12 --> Database Driver Class Initialized
INFO - 2023-06-23 09:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:02:12 --> Form Validation Class Initialized
INFO - 2023-06-23 09:02:12 --> Controller Class Initialized
INFO - 2023-06-23 09:02:12 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:02:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:02:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:02:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 09:02:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:02:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:02:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:02:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:02:12 --> Final output sent to browser
INFO - 2023-06-23 09:02:36 --> Config Class Initialized
INFO - 2023-06-23 09:02:36 --> Hooks Class Initialized
INFO - 2023-06-23 09:02:36 --> Utf8 Class Initialized
INFO - 2023-06-23 09:02:36 --> URI Class Initialized
INFO - 2023-06-23 09:02:36 --> Router Class Initialized
INFO - 2023-06-23 09:02:36 --> Output Class Initialized
INFO - 2023-06-23 09:02:36 --> Security Class Initialized
INFO - 2023-06-23 09:02:36 --> Input Class Initialized
INFO - 2023-06-23 09:02:36 --> Language Class Initialized
INFO - 2023-06-23 09:02:36 --> Loader Class Initialized
INFO - 2023-06-23 09:02:36 --> Helper loaded: url_helper
INFO - 2023-06-23 09:02:36 --> Helper loaded: form_helper
INFO - 2023-06-23 09:02:36 --> Database Driver Class Initialized
INFO - 2023-06-23 09:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:02:36 --> Form Validation Class Initialized
INFO - 2023-06-23 09:02:36 --> Controller Class Initialized
INFO - 2023-06-23 09:02:36 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:02:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:02:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:02:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 09:02:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:02:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:02:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:02:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:02:36 --> Final output sent to browser
INFO - 2023-06-23 09:02:50 --> Config Class Initialized
INFO - 2023-06-23 09:02:50 --> Hooks Class Initialized
INFO - 2023-06-23 09:02:50 --> Utf8 Class Initialized
INFO - 2023-06-23 09:02:50 --> URI Class Initialized
INFO - 2023-06-23 09:02:50 --> Router Class Initialized
INFO - 2023-06-23 09:02:50 --> Output Class Initialized
INFO - 2023-06-23 09:02:50 --> Security Class Initialized
INFO - 2023-06-23 09:02:50 --> Input Class Initialized
INFO - 2023-06-23 09:02:50 --> Language Class Initialized
INFO - 2023-06-23 09:02:50 --> Loader Class Initialized
INFO - 2023-06-23 09:02:50 --> Helper loaded: url_helper
INFO - 2023-06-23 09:02:50 --> Helper loaded: form_helper
INFO - 2023-06-23 09:02:50 --> Database Driver Class Initialized
INFO - 2023-06-23 09:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:02:50 --> Form Validation Class Initialized
INFO - 2023-06-23 09:02:50 --> Controller Class Initialized
INFO - 2023-06-23 09:02:50 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 09:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:02:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:02:50 --> Final output sent to browser
INFO - 2023-06-23 09:03:08 --> Config Class Initialized
INFO - 2023-06-23 09:03:08 --> Hooks Class Initialized
INFO - 2023-06-23 09:03:08 --> Utf8 Class Initialized
INFO - 2023-06-23 09:03:08 --> URI Class Initialized
INFO - 2023-06-23 09:03:08 --> Router Class Initialized
INFO - 2023-06-23 09:03:08 --> Output Class Initialized
INFO - 2023-06-23 09:03:08 --> Security Class Initialized
INFO - 2023-06-23 09:03:08 --> Input Class Initialized
INFO - 2023-06-23 09:03:08 --> Language Class Initialized
INFO - 2023-06-23 09:03:08 --> Loader Class Initialized
INFO - 2023-06-23 09:03:08 --> Helper loaded: url_helper
INFO - 2023-06-23 09:03:08 --> Helper loaded: form_helper
INFO - 2023-06-23 09:03:08 --> Database Driver Class Initialized
INFO - 2023-06-23 09:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:03:08 --> Form Validation Class Initialized
INFO - 2023-06-23 09:03:08 --> Controller Class Initialized
INFO - 2023-06-23 09:03:08 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:03:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:03:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:03:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 09:03:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:03:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:03:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:03:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:03:08 --> Final output sent to browser
INFO - 2023-06-23 09:03:23 --> Config Class Initialized
INFO - 2023-06-23 09:03:23 --> Hooks Class Initialized
INFO - 2023-06-23 09:03:23 --> Utf8 Class Initialized
INFO - 2023-06-23 09:03:23 --> URI Class Initialized
INFO - 2023-06-23 09:03:23 --> Router Class Initialized
INFO - 2023-06-23 09:03:23 --> Output Class Initialized
INFO - 2023-06-23 09:03:23 --> Security Class Initialized
INFO - 2023-06-23 09:03:23 --> Input Class Initialized
INFO - 2023-06-23 09:03:23 --> Language Class Initialized
INFO - 2023-06-23 09:03:23 --> Loader Class Initialized
INFO - 2023-06-23 09:03:23 --> Helper loaded: url_helper
INFO - 2023-06-23 09:03:23 --> Helper loaded: form_helper
INFO - 2023-06-23 09:03:23 --> Database Driver Class Initialized
INFO - 2023-06-23 09:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:03:23 --> Form Validation Class Initialized
INFO - 2023-06-23 09:03:23 --> Controller Class Initialized
INFO - 2023-06-23 09:03:23 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:03:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:03:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:03:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 09:03:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:03:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:03:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:03:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:03:23 --> Final output sent to browser
INFO - 2023-06-23 09:03:34 --> Config Class Initialized
INFO - 2023-06-23 09:03:34 --> Hooks Class Initialized
INFO - 2023-06-23 09:03:34 --> Utf8 Class Initialized
INFO - 2023-06-23 09:03:34 --> URI Class Initialized
INFO - 2023-06-23 09:03:34 --> Router Class Initialized
INFO - 2023-06-23 09:03:34 --> Output Class Initialized
INFO - 2023-06-23 09:03:34 --> Security Class Initialized
INFO - 2023-06-23 09:03:34 --> Input Class Initialized
INFO - 2023-06-23 09:03:34 --> Language Class Initialized
INFO - 2023-06-23 09:03:34 --> Loader Class Initialized
INFO - 2023-06-23 09:03:34 --> Helper loaded: url_helper
INFO - 2023-06-23 09:03:34 --> Helper loaded: form_helper
INFO - 2023-06-23 09:03:34 --> Database Driver Class Initialized
INFO - 2023-06-23 09:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:03:34 --> Form Validation Class Initialized
INFO - 2023-06-23 09:03:34 --> Controller Class Initialized
INFO - 2023-06-23 09:03:34 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:03:34 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:03:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:03:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:03:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:03:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 09:03:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:03:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:03:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:03:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:03:34 --> Final output sent to browser
INFO - 2023-06-23 09:03:36 --> Config Class Initialized
INFO - 2023-06-23 09:03:36 --> Hooks Class Initialized
INFO - 2023-06-23 09:03:36 --> Utf8 Class Initialized
INFO - 2023-06-23 09:03:36 --> URI Class Initialized
INFO - 2023-06-23 09:03:36 --> Router Class Initialized
INFO - 2023-06-23 09:03:36 --> Output Class Initialized
INFO - 2023-06-23 09:03:36 --> Security Class Initialized
INFO - 2023-06-23 09:03:36 --> Input Class Initialized
INFO - 2023-06-23 09:03:36 --> Language Class Initialized
INFO - 2023-06-23 09:03:36 --> Loader Class Initialized
INFO - 2023-06-23 09:03:36 --> Helper loaded: url_helper
INFO - 2023-06-23 09:03:36 --> Helper loaded: form_helper
INFO - 2023-06-23 09:03:36 --> Database Driver Class Initialized
INFO - 2023-06-23 09:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:03:36 --> Form Validation Class Initialized
INFO - 2023-06-23 09:03:36 --> Controller Class Initialized
INFO - 2023-06-23 09:03:36 --> Model "m_user" initialized
INFO - 2023-06-23 09:03:36 --> Config Class Initialized
INFO - 2023-06-23 09:03:36 --> Hooks Class Initialized
INFO - 2023-06-23 09:03:36 --> Utf8 Class Initialized
INFO - 2023-06-23 09:03:36 --> URI Class Initialized
INFO - 2023-06-23 09:03:36 --> Router Class Initialized
INFO - 2023-06-23 09:03:36 --> Output Class Initialized
INFO - 2023-06-23 09:03:36 --> Security Class Initialized
INFO - 2023-06-23 09:03:36 --> Input Class Initialized
INFO - 2023-06-23 09:03:36 --> Language Class Initialized
INFO - 2023-06-23 09:03:36 --> Loader Class Initialized
INFO - 2023-06-23 09:03:36 --> Helper loaded: url_helper
INFO - 2023-06-23 09:03:36 --> Helper loaded: form_helper
INFO - 2023-06-23 09:03:36 --> Database Driver Class Initialized
INFO - 2023-06-23 09:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:03:36 --> Form Validation Class Initialized
INFO - 2023-06-23 09:03:36 --> Controller Class Initialized
INFO - 2023-06-23 09:03:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-23 09:03:36 --> Final output sent to browser
INFO - 2023-06-23 09:03:37 --> Config Class Initialized
INFO - 2023-06-23 09:03:37 --> Hooks Class Initialized
INFO - 2023-06-23 09:03:37 --> Utf8 Class Initialized
INFO - 2023-06-23 09:03:37 --> URI Class Initialized
INFO - 2023-06-23 09:03:37 --> Router Class Initialized
INFO - 2023-06-23 09:03:37 --> Output Class Initialized
INFO - 2023-06-23 09:03:37 --> Security Class Initialized
INFO - 2023-06-23 09:03:37 --> Input Class Initialized
INFO - 2023-06-23 09:03:37 --> Language Class Initialized
INFO - 2023-06-23 09:03:37 --> Loader Class Initialized
INFO - 2023-06-23 09:03:37 --> Helper loaded: url_helper
INFO - 2023-06-23 09:03:37 --> Helper loaded: form_helper
INFO - 2023-06-23 09:03:37 --> Database Driver Class Initialized
INFO - 2023-06-23 09:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:03:37 --> Form Validation Class Initialized
INFO - 2023-06-23 09:03:37 --> Controller Class Initialized
INFO - 2023-06-23 09:03:37 --> Model "m_user" initialized
INFO - 2023-06-23 09:03:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:03:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:03:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:03:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:03:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:03:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-23 09:03:37 --> Final output sent to browser
INFO - 2023-06-23 09:09:53 --> Config Class Initialized
INFO - 2023-06-23 09:09:53 --> Hooks Class Initialized
INFO - 2023-06-23 09:09:53 --> Utf8 Class Initialized
INFO - 2023-06-23 09:09:53 --> URI Class Initialized
INFO - 2023-06-23 09:09:53 --> Router Class Initialized
INFO - 2023-06-23 09:09:53 --> Output Class Initialized
INFO - 2023-06-23 09:09:53 --> Security Class Initialized
INFO - 2023-06-23 09:09:53 --> Input Class Initialized
INFO - 2023-06-23 09:09:53 --> Language Class Initialized
INFO - 2023-06-23 09:09:53 --> Loader Class Initialized
INFO - 2023-06-23 09:09:53 --> Helper loaded: url_helper
INFO - 2023-06-23 09:09:53 --> Helper loaded: form_helper
INFO - 2023-06-23 09:09:53 --> Database Driver Class Initialized
INFO - 2023-06-23 09:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:09:53 --> Form Validation Class Initialized
INFO - 2023-06-23 09:09:53 --> Controller Class Initialized
INFO - 2023-06-23 09:09:53 --> Model "m_user" initialized
INFO - 2023-06-23 09:09:53 --> Config Class Initialized
INFO - 2023-06-23 09:09:53 --> Hooks Class Initialized
INFO - 2023-06-23 09:09:53 --> Utf8 Class Initialized
INFO - 2023-06-23 09:09:53 --> URI Class Initialized
INFO - 2023-06-23 09:09:53 --> Router Class Initialized
INFO - 2023-06-23 09:09:53 --> Output Class Initialized
INFO - 2023-06-23 09:09:53 --> Security Class Initialized
INFO - 2023-06-23 09:09:53 --> Input Class Initialized
INFO - 2023-06-23 09:09:53 --> Language Class Initialized
INFO - 2023-06-23 09:09:53 --> Loader Class Initialized
INFO - 2023-06-23 09:09:53 --> Helper loaded: url_helper
INFO - 2023-06-23 09:09:53 --> Helper loaded: form_helper
INFO - 2023-06-23 09:09:54 --> Database Driver Class Initialized
INFO - 2023-06-23 09:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:09:54 --> Form Validation Class Initialized
INFO - 2023-06-23 09:09:54 --> Controller Class Initialized
INFO - 2023-06-23 09:09:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-23 09:09:54 --> Final output sent to browser
INFO - 2023-06-23 09:09:55 --> Config Class Initialized
INFO - 2023-06-23 09:09:55 --> Hooks Class Initialized
INFO - 2023-06-23 09:09:55 --> Utf8 Class Initialized
INFO - 2023-06-23 09:09:55 --> URI Class Initialized
INFO - 2023-06-23 09:09:55 --> Router Class Initialized
INFO - 2023-06-23 09:09:55 --> Output Class Initialized
INFO - 2023-06-23 09:09:55 --> Security Class Initialized
INFO - 2023-06-23 09:09:55 --> Input Class Initialized
INFO - 2023-06-23 09:09:55 --> Language Class Initialized
INFO - 2023-06-23 09:09:55 --> Loader Class Initialized
INFO - 2023-06-23 09:09:55 --> Helper loaded: url_helper
INFO - 2023-06-23 09:09:55 --> Helper loaded: form_helper
INFO - 2023-06-23 09:09:55 --> Database Driver Class Initialized
INFO - 2023-06-23 09:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:09:55 --> Form Validation Class Initialized
INFO - 2023-06-23 09:09:55 --> Controller Class Initialized
INFO - 2023-06-23 09:09:55 --> Model "m_user" initialized
INFO - 2023-06-23 09:09:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_header.php
INFO - 2023-06-23 09:09:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\auth/login.php
INFO - 2023-06-23 09:09:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_footer.php
INFO - 2023-06-23 09:09:55 --> Final output sent to browser
INFO - 2023-06-23 09:09:58 --> Config Class Initialized
INFO - 2023-06-23 09:09:58 --> Hooks Class Initialized
INFO - 2023-06-23 09:09:58 --> Utf8 Class Initialized
INFO - 2023-06-23 09:09:58 --> URI Class Initialized
INFO - 2023-06-23 09:09:58 --> Router Class Initialized
INFO - 2023-06-23 09:09:58 --> Output Class Initialized
INFO - 2023-06-23 09:09:58 --> Security Class Initialized
INFO - 2023-06-23 09:09:58 --> Input Class Initialized
INFO - 2023-06-23 09:09:58 --> Language Class Initialized
INFO - 2023-06-23 09:09:58 --> Loader Class Initialized
INFO - 2023-06-23 09:09:58 --> Helper loaded: url_helper
INFO - 2023-06-23 09:09:58 --> Helper loaded: form_helper
INFO - 2023-06-23 09:09:58 --> Database Driver Class Initialized
INFO - 2023-06-23 09:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:09:58 --> Form Validation Class Initialized
INFO - 2023-06-23 09:09:58 --> Controller Class Initialized
INFO - 2023-06-23 09:09:58 --> Model "m_user" initialized
INFO - 2023-06-23 09:09:59 --> Config Class Initialized
INFO - 2023-06-23 09:09:59 --> Hooks Class Initialized
INFO - 2023-06-23 09:09:59 --> Utf8 Class Initialized
INFO - 2023-06-23 09:09:59 --> URI Class Initialized
INFO - 2023-06-23 09:09:59 --> Router Class Initialized
INFO - 2023-06-23 09:09:59 --> Output Class Initialized
INFO - 2023-06-23 09:09:59 --> Security Class Initialized
INFO - 2023-06-23 09:09:59 --> Input Class Initialized
INFO - 2023-06-23 09:09:59 --> Language Class Initialized
INFO - 2023-06-23 09:09:59 --> Loader Class Initialized
INFO - 2023-06-23 09:09:59 --> Helper loaded: url_helper
INFO - 2023-06-23 09:09:59 --> Helper loaded: form_helper
INFO - 2023-06-23 09:09:59 --> Database Driver Class Initialized
INFO - 2023-06-23 09:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:09:59 --> Form Validation Class Initialized
INFO - 2023-06-23 09:09:59 --> Controller Class Initialized
INFO - 2023-06-23 09:09:59 --> Model "m_user" initialized
INFO - 2023-06-23 09:09:59 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:09:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:09:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:09:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:09:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:09:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:09:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home.php
INFO - 2023-06-23 09:09:59 --> Final output sent to browser
INFO - 2023-06-23 09:10:18 --> Config Class Initialized
INFO - 2023-06-23 09:10:18 --> Hooks Class Initialized
INFO - 2023-06-23 09:10:18 --> Utf8 Class Initialized
INFO - 2023-06-23 09:10:18 --> URI Class Initialized
INFO - 2023-06-23 09:10:18 --> Router Class Initialized
INFO - 2023-06-23 09:10:18 --> Output Class Initialized
INFO - 2023-06-23 09:10:18 --> Security Class Initialized
INFO - 2023-06-23 09:10:18 --> Input Class Initialized
INFO - 2023-06-23 09:10:18 --> Language Class Initialized
INFO - 2023-06-23 09:10:18 --> Loader Class Initialized
INFO - 2023-06-23 09:10:18 --> Helper loaded: url_helper
INFO - 2023-06-23 09:10:18 --> Helper loaded: form_helper
INFO - 2023-06-23 09:10:18 --> Database Driver Class Initialized
INFO - 2023-06-23 09:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:10:18 --> Form Validation Class Initialized
INFO - 2023-06-23 09:10:18 --> Controller Class Initialized
INFO - 2023-06-23 09:10:18 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:10:18 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:10:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:10:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:10:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:10:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 09:10:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:10:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:10:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:10:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:10:18 --> Final output sent to browser
INFO - 2023-06-23 09:10:20 --> Config Class Initialized
INFO - 2023-06-23 09:10:20 --> Hooks Class Initialized
INFO - 2023-06-23 09:10:20 --> Utf8 Class Initialized
INFO - 2023-06-23 09:10:20 --> URI Class Initialized
INFO - 2023-06-23 09:10:20 --> Router Class Initialized
INFO - 2023-06-23 09:10:20 --> Output Class Initialized
INFO - 2023-06-23 09:10:20 --> Security Class Initialized
INFO - 2023-06-23 09:10:20 --> Input Class Initialized
INFO - 2023-06-23 09:10:20 --> Language Class Initialized
INFO - 2023-06-23 09:10:20 --> Loader Class Initialized
INFO - 2023-06-23 09:10:20 --> Helper loaded: url_helper
INFO - 2023-06-23 09:10:20 --> Helper loaded: form_helper
INFO - 2023-06-23 09:10:20 --> Database Driver Class Initialized
INFO - 2023-06-23 09:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:10:20 --> Form Validation Class Initialized
INFO - 2023-06-23 09:10:20 --> Controller Class Initialized
INFO - 2023-06-23 09:10:20 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:10:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:10:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:10:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\pengujian.php
INFO - 2023-06-23 09:10:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:10:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:10:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:10:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:10:20 --> Final output sent to browser
INFO - 2023-06-23 09:10:22 --> Config Class Initialized
INFO - 2023-06-23 09:10:22 --> Hooks Class Initialized
INFO - 2023-06-23 09:10:22 --> Utf8 Class Initialized
INFO - 2023-06-23 09:10:22 --> URI Class Initialized
INFO - 2023-06-23 09:10:22 --> Router Class Initialized
INFO - 2023-06-23 09:10:22 --> Output Class Initialized
INFO - 2023-06-23 09:10:22 --> Security Class Initialized
INFO - 2023-06-23 09:10:22 --> Input Class Initialized
INFO - 2023-06-23 09:10:22 --> Language Class Initialized
INFO - 2023-06-23 09:10:22 --> Loader Class Initialized
INFO - 2023-06-23 09:10:22 --> Helper loaded: url_helper
INFO - 2023-06-23 09:10:22 --> Helper loaded: form_helper
INFO - 2023-06-23 09:10:22 --> Database Driver Class Initialized
INFO - 2023-06-23 09:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:10:23 --> Form Validation Class Initialized
INFO - 2023-06-23 09:10:23 --> Controller Class Initialized
INFO - 2023-06-23 09:10:23 --> Model "m_user" initialized
INFO - 2023-06-23 09:10:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:10:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:10:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\admin/v_admin.php
INFO - 2023-06-23 09:10:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 09:10:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:10:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:10:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 09:10:23 --> Final output sent to browser
INFO - 2023-06-23 09:10:24 --> Config Class Initialized
INFO - 2023-06-23 09:10:24 --> Hooks Class Initialized
INFO - 2023-06-23 09:10:24 --> Utf8 Class Initialized
INFO - 2023-06-23 09:10:24 --> URI Class Initialized
INFO - 2023-06-23 09:10:24 --> Router Class Initialized
INFO - 2023-06-23 09:10:24 --> Output Class Initialized
INFO - 2023-06-23 09:10:24 --> Security Class Initialized
INFO - 2023-06-23 09:10:24 --> Input Class Initialized
INFO - 2023-06-23 09:10:24 --> Language Class Initialized
INFO - 2023-06-23 09:10:24 --> Loader Class Initialized
INFO - 2023-06-23 09:10:24 --> Helper loaded: url_helper
INFO - 2023-06-23 09:10:24 --> Helper loaded: form_helper
INFO - 2023-06-23 09:10:24 --> Database Driver Class Initialized
INFO - 2023-06-23 09:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:10:24 --> Form Validation Class Initialized
INFO - 2023-06-23 09:10:24 --> Controller Class Initialized
INFO - 2023-06-23 09:10:24 --> Model "m_user" initialized
INFO - 2023-06-23 09:10:24 --> Config Class Initialized
INFO - 2023-06-23 09:10:24 --> Hooks Class Initialized
INFO - 2023-06-23 09:10:24 --> Utf8 Class Initialized
INFO - 2023-06-23 09:10:24 --> URI Class Initialized
INFO - 2023-06-23 09:10:24 --> Router Class Initialized
INFO - 2023-06-23 09:10:24 --> Output Class Initialized
INFO - 2023-06-23 09:10:24 --> Security Class Initialized
INFO - 2023-06-23 09:10:24 --> Input Class Initialized
INFO - 2023-06-23 09:10:24 --> Language Class Initialized
INFO - 2023-06-23 09:10:24 --> Loader Class Initialized
INFO - 2023-06-23 09:10:24 --> Helper loaded: url_helper
INFO - 2023-06-23 09:10:24 --> Helper loaded: form_helper
INFO - 2023-06-23 09:10:24 --> Database Driver Class Initialized
INFO - 2023-06-23 09:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:10:24 --> Form Validation Class Initialized
INFO - 2023-06-23 09:10:24 --> Controller Class Initialized
INFO - 2023-06-23 09:10:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-23 09:10:24 --> Final output sent to browser
INFO - 2023-06-23 09:10:26 --> Config Class Initialized
INFO - 2023-06-23 09:10:26 --> Hooks Class Initialized
INFO - 2023-06-23 09:10:26 --> Utf8 Class Initialized
INFO - 2023-06-23 09:10:26 --> URI Class Initialized
INFO - 2023-06-23 09:10:26 --> Router Class Initialized
INFO - 2023-06-23 09:10:26 --> Output Class Initialized
INFO - 2023-06-23 09:10:26 --> Security Class Initialized
INFO - 2023-06-23 09:10:26 --> Input Class Initialized
INFO - 2023-06-23 09:10:26 --> Language Class Initialized
INFO - 2023-06-23 09:10:26 --> Loader Class Initialized
INFO - 2023-06-23 09:10:26 --> Helper loaded: url_helper
INFO - 2023-06-23 09:10:26 --> Helper loaded: form_helper
INFO - 2023-06-23 09:10:26 --> Database Driver Class Initialized
INFO - 2023-06-23 09:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:10:26 --> Form Validation Class Initialized
INFO - 2023-06-23 09:10:26 --> Controller Class Initialized
INFO - 2023-06-23 09:10:26 --> Model "m_user" initialized
INFO - 2023-06-23 09:10:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:10:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:10:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:10:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:10:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:10:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-23 09:10:26 --> Final output sent to browser
INFO - 2023-06-23 09:10:27 --> Config Class Initialized
INFO - 2023-06-23 09:10:27 --> Hooks Class Initialized
INFO - 2023-06-23 09:10:27 --> Utf8 Class Initialized
INFO - 2023-06-23 09:10:27 --> URI Class Initialized
INFO - 2023-06-23 09:10:27 --> Router Class Initialized
INFO - 2023-06-23 09:10:27 --> Output Class Initialized
INFO - 2023-06-23 09:10:27 --> Security Class Initialized
INFO - 2023-06-23 09:10:27 --> Input Class Initialized
INFO - 2023-06-23 09:10:27 --> Language Class Initialized
INFO - 2023-06-23 09:10:27 --> Loader Class Initialized
INFO - 2023-06-23 09:10:27 --> Helper loaded: url_helper
INFO - 2023-06-23 09:10:27 --> Helper loaded: form_helper
INFO - 2023-06-23 09:10:27 --> Database Driver Class Initialized
INFO - 2023-06-23 09:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:10:27 --> Form Validation Class Initialized
INFO - 2023-06-23 09:10:27 --> Controller Class Initialized
INFO - 2023-06-23 09:10:27 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:10:27 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:10:27 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:10:27 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:10:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:10:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:10:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-23 09:10:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:10:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:10:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:10:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 09:10:27 --> Final output sent to browser
INFO - 2023-06-23 09:11:26 --> Config Class Initialized
INFO - 2023-06-23 09:11:26 --> Hooks Class Initialized
INFO - 2023-06-23 09:11:26 --> Utf8 Class Initialized
INFO - 2023-06-23 09:11:26 --> URI Class Initialized
INFO - 2023-06-23 09:11:26 --> Router Class Initialized
INFO - 2023-06-23 09:11:26 --> Output Class Initialized
INFO - 2023-06-23 09:11:26 --> Security Class Initialized
INFO - 2023-06-23 09:11:26 --> Input Class Initialized
INFO - 2023-06-23 09:11:26 --> Language Class Initialized
INFO - 2023-06-23 09:11:26 --> Loader Class Initialized
INFO - 2023-06-23 09:11:26 --> Helper loaded: url_helper
INFO - 2023-06-23 09:11:26 --> Helper loaded: form_helper
INFO - 2023-06-23 09:11:26 --> Database Driver Class Initialized
INFO - 2023-06-23 09:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:11:26 --> Form Validation Class Initialized
INFO - 2023-06-23 09:11:26 --> Controller Class Initialized
INFO - 2023-06-23 09:11:26 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:11:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:11:26 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:11:26 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:11:26 --> Final output sent to browser
INFO - 2023-06-23 09:12:09 --> Config Class Initialized
INFO - 2023-06-23 09:12:09 --> Hooks Class Initialized
INFO - 2023-06-23 09:12:09 --> Utf8 Class Initialized
INFO - 2023-06-23 09:12:09 --> URI Class Initialized
INFO - 2023-06-23 09:12:09 --> Router Class Initialized
INFO - 2023-06-23 09:12:09 --> Output Class Initialized
INFO - 2023-06-23 09:12:09 --> Security Class Initialized
INFO - 2023-06-23 09:12:09 --> Input Class Initialized
INFO - 2023-06-23 09:12:09 --> Language Class Initialized
INFO - 2023-06-23 09:12:09 --> Loader Class Initialized
INFO - 2023-06-23 09:12:09 --> Helper loaded: url_helper
INFO - 2023-06-23 09:12:09 --> Helper loaded: form_helper
INFO - 2023-06-23 09:12:09 --> Database Driver Class Initialized
INFO - 2023-06-23 09:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:12:09 --> Form Validation Class Initialized
INFO - 2023-06-23 09:12:09 --> Controller Class Initialized
INFO - 2023-06-23 09:12:09 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:12:09 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:12:09 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:12:09 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:12:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:12:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:12:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 09:12:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:12:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:12:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:12:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 09:12:09 --> Final output sent to browser
INFO - 2023-06-23 09:13:30 --> Config Class Initialized
INFO - 2023-06-23 09:13:30 --> Hooks Class Initialized
INFO - 2023-06-23 09:13:30 --> Utf8 Class Initialized
INFO - 2023-06-23 09:13:30 --> URI Class Initialized
INFO - 2023-06-23 09:13:30 --> Router Class Initialized
INFO - 2023-06-23 09:13:30 --> Output Class Initialized
INFO - 2023-06-23 09:13:30 --> Security Class Initialized
INFO - 2023-06-23 09:13:30 --> Input Class Initialized
INFO - 2023-06-23 09:13:30 --> Language Class Initialized
INFO - 2023-06-23 09:13:30 --> Loader Class Initialized
INFO - 2023-06-23 09:13:30 --> Helper loaded: url_helper
INFO - 2023-06-23 09:13:30 --> Helper loaded: form_helper
INFO - 2023-06-23 09:13:30 --> Database Driver Class Initialized
INFO - 2023-06-23 09:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:13:31 --> Form Validation Class Initialized
INFO - 2023-06-23 09:13:31 --> Controller Class Initialized
INFO - 2023-06-23 09:13:31 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:13:31 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:13:31 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:13:31 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:13:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:13:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:13:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 09:13:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:13:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:13:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:13:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 09:13:31 --> Final output sent to browser
INFO - 2023-06-23 09:13:46 --> Config Class Initialized
INFO - 2023-06-23 09:13:46 --> Hooks Class Initialized
INFO - 2023-06-23 09:13:46 --> Utf8 Class Initialized
INFO - 2023-06-23 09:13:46 --> URI Class Initialized
INFO - 2023-06-23 09:13:46 --> Router Class Initialized
INFO - 2023-06-23 09:13:46 --> Output Class Initialized
INFO - 2023-06-23 09:13:46 --> Security Class Initialized
INFO - 2023-06-23 09:13:46 --> Input Class Initialized
INFO - 2023-06-23 09:13:46 --> Language Class Initialized
INFO - 2023-06-23 09:13:46 --> Loader Class Initialized
INFO - 2023-06-23 09:13:46 --> Helper loaded: url_helper
INFO - 2023-06-23 09:13:46 --> Helper loaded: form_helper
INFO - 2023-06-23 09:13:46 --> Database Driver Class Initialized
INFO - 2023-06-23 09:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:13:46 --> Form Validation Class Initialized
INFO - 2023-06-23 09:13:46 --> Controller Class Initialized
INFO - 2023-06-23 09:13:46 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:13:46 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:13:46 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:13:46 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:13:47 --> Final output sent to browser
INFO - 2023-06-23 09:14:49 --> Config Class Initialized
INFO - 2023-06-23 09:14:49 --> Hooks Class Initialized
INFO - 2023-06-23 09:14:49 --> Utf8 Class Initialized
INFO - 2023-06-23 09:14:49 --> URI Class Initialized
INFO - 2023-06-23 09:14:49 --> Router Class Initialized
INFO - 2023-06-23 09:14:49 --> Output Class Initialized
INFO - 2023-06-23 09:14:49 --> Security Class Initialized
INFO - 2023-06-23 09:14:49 --> Input Class Initialized
INFO - 2023-06-23 09:14:49 --> Language Class Initialized
INFO - 2023-06-23 09:14:49 --> Loader Class Initialized
INFO - 2023-06-23 09:14:49 --> Helper loaded: url_helper
INFO - 2023-06-23 09:14:49 --> Helper loaded: form_helper
INFO - 2023-06-23 09:14:49 --> Database Driver Class Initialized
INFO - 2023-06-23 09:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:14:49 --> Form Validation Class Initialized
INFO - 2023-06-23 09:14:49 --> Controller Class Initialized
INFO - 2023-06-23 09:14:49 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:14:49 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:14:49 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:14:49 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:14:49 --> Final output sent to browser
INFO - 2023-06-23 09:16:18 --> Config Class Initialized
INFO - 2023-06-23 09:16:18 --> Hooks Class Initialized
INFO - 2023-06-23 09:16:18 --> Utf8 Class Initialized
INFO - 2023-06-23 09:16:18 --> URI Class Initialized
INFO - 2023-06-23 09:16:18 --> Router Class Initialized
INFO - 2023-06-23 09:16:18 --> Output Class Initialized
INFO - 2023-06-23 09:16:18 --> Security Class Initialized
INFO - 2023-06-23 09:16:18 --> Input Class Initialized
INFO - 2023-06-23 09:16:18 --> Language Class Initialized
INFO - 2023-06-23 09:16:18 --> Loader Class Initialized
INFO - 2023-06-23 09:16:18 --> Helper loaded: url_helper
INFO - 2023-06-23 09:16:18 --> Helper loaded: form_helper
INFO - 2023-06-23 09:16:18 --> Database Driver Class Initialized
INFO - 2023-06-23 09:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:16:18 --> Form Validation Class Initialized
INFO - 2023-06-23 09:16:18 --> Controller Class Initialized
INFO - 2023-06-23 09:16:18 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:16:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:16:18 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:16:18 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:16:18 --> Final output sent to browser
INFO - 2023-06-23 09:17:17 --> Config Class Initialized
INFO - 2023-06-23 09:17:17 --> Hooks Class Initialized
INFO - 2023-06-23 09:17:17 --> Utf8 Class Initialized
INFO - 2023-06-23 09:17:17 --> URI Class Initialized
INFO - 2023-06-23 09:17:17 --> Router Class Initialized
INFO - 2023-06-23 09:17:17 --> Output Class Initialized
INFO - 2023-06-23 09:17:17 --> Security Class Initialized
INFO - 2023-06-23 09:17:17 --> Input Class Initialized
INFO - 2023-06-23 09:17:17 --> Language Class Initialized
INFO - 2023-06-23 09:17:17 --> Loader Class Initialized
INFO - 2023-06-23 09:17:17 --> Helper loaded: url_helper
INFO - 2023-06-23 09:17:17 --> Helper loaded: form_helper
INFO - 2023-06-23 09:17:17 --> Database Driver Class Initialized
INFO - 2023-06-23 09:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:17:17 --> Form Validation Class Initialized
INFO - 2023-06-23 09:17:17 --> Controller Class Initialized
INFO - 2023-06-23 09:17:17 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:17:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:17:17 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:17:17 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:17:17 --> Final output sent to browser
INFO - 2023-06-23 09:17:33 --> Config Class Initialized
INFO - 2023-06-23 09:17:33 --> Hooks Class Initialized
INFO - 2023-06-23 09:17:33 --> Utf8 Class Initialized
INFO - 2023-06-23 09:17:33 --> URI Class Initialized
INFO - 2023-06-23 09:17:33 --> Router Class Initialized
INFO - 2023-06-23 09:17:33 --> Output Class Initialized
INFO - 2023-06-23 09:17:33 --> Security Class Initialized
INFO - 2023-06-23 09:17:33 --> Input Class Initialized
INFO - 2023-06-23 09:17:33 --> Language Class Initialized
INFO - 2023-06-23 09:17:33 --> Loader Class Initialized
INFO - 2023-06-23 09:17:33 --> Helper loaded: url_helper
INFO - 2023-06-23 09:17:33 --> Helper loaded: form_helper
INFO - 2023-06-23 09:17:33 --> Database Driver Class Initialized
INFO - 2023-06-23 09:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:17:33 --> Form Validation Class Initialized
INFO - 2023-06-23 09:17:33 --> Controller Class Initialized
INFO - 2023-06-23 09:17:33 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:17:33 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:17:33 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:17:33 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:17:33 --> Final output sent to browser
INFO - 2023-06-23 09:18:03 --> Config Class Initialized
INFO - 2023-06-23 09:18:03 --> Hooks Class Initialized
INFO - 2023-06-23 09:18:03 --> Utf8 Class Initialized
INFO - 2023-06-23 09:18:03 --> URI Class Initialized
INFO - 2023-06-23 09:18:03 --> Router Class Initialized
INFO - 2023-06-23 09:18:03 --> Output Class Initialized
INFO - 2023-06-23 09:18:03 --> Security Class Initialized
INFO - 2023-06-23 09:18:03 --> Input Class Initialized
INFO - 2023-06-23 09:18:03 --> Language Class Initialized
INFO - 2023-06-23 09:18:03 --> Loader Class Initialized
INFO - 2023-06-23 09:18:03 --> Helper loaded: url_helper
INFO - 2023-06-23 09:18:03 --> Helper loaded: form_helper
INFO - 2023-06-23 09:18:03 --> Database Driver Class Initialized
INFO - 2023-06-23 09:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:18:03 --> Form Validation Class Initialized
INFO - 2023-06-23 09:18:03 --> Controller Class Initialized
INFO - 2023-06-23 09:18:03 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:18:03 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:18:03 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:18:03 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:18:03 --> Final output sent to browser
INFO - 2023-06-23 09:20:07 --> Config Class Initialized
INFO - 2023-06-23 09:20:07 --> Hooks Class Initialized
INFO - 2023-06-23 09:20:07 --> Utf8 Class Initialized
INFO - 2023-06-23 09:20:07 --> URI Class Initialized
INFO - 2023-06-23 09:20:07 --> Router Class Initialized
INFO - 2023-06-23 09:20:07 --> Output Class Initialized
INFO - 2023-06-23 09:20:07 --> Security Class Initialized
INFO - 2023-06-23 09:20:07 --> Input Class Initialized
INFO - 2023-06-23 09:20:07 --> Language Class Initialized
INFO - 2023-06-23 09:20:07 --> Loader Class Initialized
INFO - 2023-06-23 09:20:07 --> Helper loaded: url_helper
INFO - 2023-06-23 09:20:07 --> Helper loaded: form_helper
INFO - 2023-06-23 09:20:07 --> Database Driver Class Initialized
INFO - 2023-06-23 09:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:20:07 --> Form Validation Class Initialized
INFO - 2023-06-23 09:20:07 --> Controller Class Initialized
INFO - 2023-06-23 09:20:07 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:20:07 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:20:07 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:20:07 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:20:07 --> Final output sent to browser
INFO - 2023-06-23 09:20:27 --> Config Class Initialized
INFO - 2023-06-23 09:20:27 --> Hooks Class Initialized
INFO - 2023-06-23 09:20:27 --> Utf8 Class Initialized
INFO - 2023-06-23 09:20:27 --> URI Class Initialized
INFO - 2023-06-23 09:20:27 --> Router Class Initialized
INFO - 2023-06-23 09:20:27 --> Output Class Initialized
INFO - 2023-06-23 09:20:27 --> Security Class Initialized
INFO - 2023-06-23 09:20:27 --> Input Class Initialized
INFO - 2023-06-23 09:20:27 --> Language Class Initialized
INFO - 2023-06-23 09:20:27 --> Loader Class Initialized
INFO - 2023-06-23 09:20:27 --> Helper loaded: url_helper
INFO - 2023-06-23 09:20:27 --> Helper loaded: form_helper
INFO - 2023-06-23 09:20:27 --> Database Driver Class Initialized
INFO - 2023-06-23 09:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:20:27 --> Form Validation Class Initialized
INFO - 2023-06-23 09:20:27 --> Controller Class Initialized
INFO - 2023-06-23 09:20:27 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:20:27 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:20:27 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:20:27 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:20:27 --> Final output sent to browser
INFO - 2023-06-23 09:21:07 --> Config Class Initialized
INFO - 2023-06-23 09:21:07 --> Hooks Class Initialized
INFO - 2023-06-23 09:21:07 --> Utf8 Class Initialized
INFO - 2023-06-23 09:21:07 --> URI Class Initialized
INFO - 2023-06-23 09:21:07 --> Router Class Initialized
INFO - 2023-06-23 09:21:07 --> Output Class Initialized
INFO - 2023-06-23 09:21:07 --> Security Class Initialized
INFO - 2023-06-23 09:21:07 --> Input Class Initialized
INFO - 2023-06-23 09:21:07 --> Language Class Initialized
INFO - 2023-06-23 09:21:07 --> Loader Class Initialized
INFO - 2023-06-23 09:21:07 --> Helper loaded: url_helper
INFO - 2023-06-23 09:21:07 --> Helper loaded: form_helper
INFO - 2023-06-23 09:21:07 --> Database Driver Class Initialized
INFO - 2023-06-23 09:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:21:07 --> Form Validation Class Initialized
INFO - 2023-06-23 09:21:07 --> Controller Class Initialized
INFO - 2023-06-23 09:21:07 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:21:07 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:21:07 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:21:07 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:21:07 --> Final output sent to browser
INFO - 2023-06-23 09:21:27 --> Config Class Initialized
INFO - 2023-06-23 09:21:27 --> Hooks Class Initialized
INFO - 2023-06-23 09:21:27 --> Utf8 Class Initialized
INFO - 2023-06-23 09:21:27 --> URI Class Initialized
INFO - 2023-06-23 09:21:27 --> Router Class Initialized
INFO - 2023-06-23 09:21:27 --> Output Class Initialized
INFO - 2023-06-23 09:21:27 --> Security Class Initialized
INFO - 2023-06-23 09:21:27 --> Input Class Initialized
INFO - 2023-06-23 09:21:27 --> Language Class Initialized
INFO - 2023-06-23 09:21:27 --> Loader Class Initialized
INFO - 2023-06-23 09:21:27 --> Helper loaded: url_helper
INFO - 2023-06-23 09:21:27 --> Helper loaded: form_helper
INFO - 2023-06-23 09:21:27 --> Database Driver Class Initialized
INFO - 2023-06-23 09:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:21:27 --> Form Validation Class Initialized
INFO - 2023-06-23 09:21:27 --> Controller Class Initialized
INFO - 2023-06-23 09:21:27 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:21:27 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:21:27 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:21:27 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:21:27 --> Final output sent to browser
INFO - 2023-06-23 09:22:05 --> Config Class Initialized
INFO - 2023-06-23 09:22:05 --> Hooks Class Initialized
INFO - 2023-06-23 09:22:05 --> Utf8 Class Initialized
INFO - 2023-06-23 09:22:05 --> URI Class Initialized
INFO - 2023-06-23 09:22:05 --> Router Class Initialized
INFO - 2023-06-23 09:22:05 --> Output Class Initialized
INFO - 2023-06-23 09:22:05 --> Security Class Initialized
INFO - 2023-06-23 09:22:05 --> Input Class Initialized
INFO - 2023-06-23 09:22:05 --> Language Class Initialized
INFO - 2023-06-23 09:22:05 --> Loader Class Initialized
INFO - 2023-06-23 09:22:05 --> Helper loaded: url_helper
INFO - 2023-06-23 09:22:05 --> Helper loaded: form_helper
INFO - 2023-06-23 09:22:05 --> Database Driver Class Initialized
INFO - 2023-06-23 09:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:22:05 --> Form Validation Class Initialized
INFO - 2023-06-23 09:22:05 --> Controller Class Initialized
INFO - 2023-06-23 09:22:05 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:22:05 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:22:05 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:22:05 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:22:06 --> Final output sent to browser
INFO - 2023-06-23 09:32:19 --> Config Class Initialized
INFO - 2023-06-23 09:32:19 --> Hooks Class Initialized
INFO - 2023-06-23 09:32:19 --> Utf8 Class Initialized
INFO - 2023-06-23 09:32:19 --> URI Class Initialized
INFO - 2023-06-23 09:32:19 --> Router Class Initialized
INFO - 2023-06-23 09:32:19 --> Output Class Initialized
INFO - 2023-06-23 09:32:19 --> Security Class Initialized
INFO - 2023-06-23 09:32:19 --> Input Class Initialized
INFO - 2023-06-23 09:32:19 --> Language Class Initialized
INFO - 2023-06-23 09:32:19 --> Loader Class Initialized
INFO - 2023-06-23 09:32:19 --> Helper loaded: url_helper
INFO - 2023-06-23 09:32:19 --> Helper loaded: form_helper
INFO - 2023-06-23 09:32:19 --> Database Driver Class Initialized
INFO - 2023-06-23 09:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:32:19 --> Form Validation Class Initialized
INFO - 2023-06-23 09:32:19 --> Controller Class Initialized
INFO - 2023-06-23 09:32:19 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:32:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:32:19 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:32:19 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:32:19 --> Final output sent to browser
INFO - 2023-06-23 09:36:23 --> Config Class Initialized
INFO - 2023-06-23 09:36:23 --> Hooks Class Initialized
INFO - 2023-06-23 09:36:23 --> Utf8 Class Initialized
INFO - 2023-06-23 09:36:23 --> URI Class Initialized
INFO - 2023-06-23 09:36:23 --> Router Class Initialized
INFO - 2023-06-23 09:36:23 --> Output Class Initialized
INFO - 2023-06-23 09:36:23 --> Security Class Initialized
INFO - 2023-06-23 09:36:23 --> Input Class Initialized
INFO - 2023-06-23 09:36:23 --> Language Class Initialized
INFO - 2023-06-23 09:36:23 --> Loader Class Initialized
INFO - 2023-06-23 09:36:23 --> Helper loaded: url_helper
INFO - 2023-06-23 09:36:23 --> Helper loaded: form_helper
INFO - 2023-06-23 09:36:23 --> Database Driver Class Initialized
INFO - 2023-06-23 09:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:36:23 --> Form Validation Class Initialized
INFO - 2023-06-23 09:36:23 --> Controller Class Initialized
INFO - 2023-06-23 09:36:23 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:36:23 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:36:23 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:36:23 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:36:23 --> Final output sent to browser
INFO - 2023-06-23 09:36:41 --> Config Class Initialized
INFO - 2023-06-23 09:36:41 --> Hooks Class Initialized
INFO - 2023-06-23 09:36:41 --> Utf8 Class Initialized
INFO - 2023-06-23 09:36:41 --> URI Class Initialized
INFO - 2023-06-23 09:36:41 --> Router Class Initialized
INFO - 2023-06-23 09:36:41 --> Output Class Initialized
INFO - 2023-06-23 09:36:41 --> Security Class Initialized
INFO - 2023-06-23 09:36:41 --> Input Class Initialized
INFO - 2023-06-23 09:36:41 --> Language Class Initialized
INFO - 2023-06-23 09:36:41 --> Loader Class Initialized
INFO - 2023-06-23 09:36:41 --> Helper loaded: url_helper
INFO - 2023-06-23 09:36:41 --> Helper loaded: form_helper
INFO - 2023-06-23 09:36:41 --> Database Driver Class Initialized
INFO - 2023-06-23 09:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:36:41 --> Form Validation Class Initialized
INFO - 2023-06-23 09:36:41 --> Controller Class Initialized
INFO - 2023-06-23 09:36:41 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:36:41 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:36:41 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:36:41 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:36:42 --> Final output sent to browser
INFO - 2023-06-23 09:37:16 --> Config Class Initialized
INFO - 2023-06-23 09:37:16 --> Hooks Class Initialized
INFO - 2023-06-23 09:37:16 --> Utf8 Class Initialized
INFO - 2023-06-23 09:37:16 --> URI Class Initialized
INFO - 2023-06-23 09:37:16 --> Router Class Initialized
INFO - 2023-06-23 09:37:16 --> Output Class Initialized
INFO - 2023-06-23 09:37:16 --> Security Class Initialized
INFO - 2023-06-23 09:37:16 --> Input Class Initialized
INFO - 2023-06-23 09:37:16 --> Language Class Initialized
INFO - 2023-06-23 09:37:16 --> Loader Class Initialized
INFO - 2023-06-23 09:37:16 --> Helper loaded: url_helper
INFO - 2023-06-23 09:37:16 --> Helper loaded: form_helper
INFO - 2023-06-23 09:37:16 --> Database Driver Class Initialized
INFO - 2023-06-23 09:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:37:17 --> Form Validation Class Initialized
INFO - 2023-06-23 09:37:17 --> Controller Class Initialized
INFO - 2023-06-23 09:37:17 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:37:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:37:17 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:37:17 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:37:17 --> Final output sent to browser
INFO - 2023-06-23 09:37:36 --> Config Class Initialized
INFO - 2023-06-23 09:37:36 --> Hooks Class Initialized
INFO - 2023-06-23 09:37:36 --> Utf8 Class Initialized
INFO - 2023-06-23 09:37:36 --> URI Class Initialized
INFO - 2023-06-23 09:37:36 --> Router Class Initialized
INFO - 2023-06-23 09:37:36 --> Output Class Initialized
INFO - 2023-06-23 09:37:36 --> Security Class Initialized
INFO - 2023-06-23 09:37:36 --> Input Class Initialized
INFO - 2023-06-23 09:37:36 --> Language Class Initialized
INFO - 2023-06-23 09:37:36 --> Loader Class Initialized
INFO - 2023-06-23 09:37:36 --> Helper loaded: url_helper
INFO - 2023-06-23 09:37:36 --> Helper loaded: form_helper
INFO - 2023-06-23 09:37:36 --> Database Driver Class Initialized
INFO - 2023-06-23 09:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:37:36 --> Form Validation Class Initialized
INFO - 2023-06-23 09:37:36 --> Controller Class Initialized
INFO - 2023-06-23 09:37:36 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:37:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:37:36 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:37:36 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:37:36 --> Final output sent to browser
INFO - 2023-06-23 09:37:48 --> Config Class Initialized
INFO - 2023-06-23 09:37:48 --> Hooks Class Initialized
INFO - 2023-06-23 09:37:48 --> Utf8 Class Initialized
INFO - 2023-06-23 09:37:48 --> URI Class Initialized
INFO - 2023-06-23 09:37:48 --> Router Class Initialized
INFO - 2023-06-23 09:37:48 --> Output Class Initialized
INFO - 2023-06-23 09:37:48 --> Security Class Initialized
INFO - 2023-06-23 09:37:48 --> Input Class Initialized
INFO - 2023-06-23 09:37:48 --> Language Class Initialized
INFO - 2023-06-23 09:37:48 --> Loader Class Initialized
INFO - 2023-06-23 09:37:48 --> Helper loaded: url_helper
INFO - 2023-06-23 09:37:48 --> Helper loaded: form_helper
INFO - 2023-06-23 09:37:48 --> Database Driver Class Initialized
INFO - 2023-06-23 09:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:37:48 --> Form Validation Class Initialized
INFO - 2023-06-23 09:37:48 --> Controller Class Initialized
INFO - 2023-06-23 09:37:48 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:37:48 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:37:48 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:37:48 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:37:48 --> Final output sent to browser
INFO - 2023-06-23 09:38:18 --> Config Class Initialized
INFO - 2023-06-23 09:38:18 --> Hooks Class Initialized
INFO - 2023-06-23 09:38:18 --> Utf8 Class Initialized
INFO - 2023-06-23 09:38:18 --> URI Class Initialized
INFO - 2023-06-23 09:38:18 --> Router Class Initialized
INFO - 2023-06-23 09:38:18 --> Output Class Initialized
INFO - 2023-06-23 09:38:18 --> Security Class Initialized
INFO - 2023-06-23 09:38:18 --> Input Class Initialized
INFO - 2023-06-23 09:38:18 --> Language Class Initialized
INFO - 2023-06-23 09:38:18 --> Loader Class Initialized
INFO - 2023-06-23 09:38:18 --> Helper loaded: url_helper
INFO - 2023-06-23 09:38:18 --> Helper loaded: form_helper
INFO - 2023-06-23 09:38:18 --> Database Driver Class Initialized
INFO - 2023-06-23 09:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:38:18 --> Form Validation Class Initialized
INFO - 2023-06-23 09:38:18 --> Controller Class Initialized
INFO - 2023-06-23 09:38:18 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:38:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:38:18 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:38:18 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:38:18 --> Final output sent to browser
INFO - 2023-06-23 09:39:38 --> Config Class Initialized
INFO - 2023-06-23 09:39:38 --> Hooks Class Initialized
INFO - 2023-06-23 09:39:38 --> Utf8 Class Initialized
INFO - 2023-06-23 09:39:38 --> URI Class Initialized
INFO - 2023-06-23 09:39:38 --> Router Class Initialized
INFO - 2023-06-23 09:39:38 --> Output Class Initialized
INFO - 2023-06-23 09:39:38 --> Security Class Initialized
INFO - 2023-06-23 09:39:38 --> Input Class Initialized
INFO - 2023-06-23 09:39:38 --> Language Class Initialized
INFO - 2023-06-23 09:39:38 --> Loader Class Initialized
INFO - 2023-06-23 09:39:38 --> Helper loaded: url_helper
INFO - 2023-06-23 09:39:38 --> Helper loaded: form_helper
INFO - 2023-06-23 09:39:38 --> Database Driver Class Initialized
INFO - 2023-06-23 09:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:39:38 --> Form Validation Class Initialized
INFO - 2023-06-23 09:39:38 --> Controller Class Initialized
INFO - 2023-06-23 09:39:38 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:39:38 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:39:38 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:39:38 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:39:38 --> Final output sent to browser
INFO - 2023-06-23 09:40:25 --> Config Class Initialized
INFO - 2023-06-23 09:40:25 --> Hooks Class Initialized
INFO - 2023-06-23 09:40:25 --> Utf8 Class Initialized
INFO - 2023-06-23 09:40:25 --> URI Class Initialized
INFO - 2023-06-23 09:40:25 --> Router Class Initialized
INFO - 2023-06-23 09:40:25 --> Output Class Initialized
INFO - 2023-06-23 09:40:25 --> Security Class Initialized
INFO - 2023-06-23 09:40:25 --> Input Class Initialized
INFO - 2023-06-23 09:40:25 --> Language Class Initialized
INFO - 2023-06-23 09:40:25 --> Loader Class Initialized
INFO - 2023-06-23 09:40:25 --> Helper loaded: url_helper
INFO - 2023-06-23 09:40:25 --> Helper loaded: form_helper
INFO - 2023-06-23 09:40:25 --> Database Driver Class Initialized
INFO - 2023-06-23 09:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:40:25 --> Form Validation Class Initialized
INFO - 2023-06-23 09:40:25 --> Controller Class Initialized
INFO - 2023-06-23 09:40:25 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:40:25 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:40:25 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:40:25 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:40:25 --> Final output sent to browser
INFO - 2023-06-23 09:42:05 --> Config Class Initialized
INFO - 2023-06-23 09:42:05 --> Hooks Class Initialized
INFO - 2023-06-23 09:42:05 --> Utf8 Class Initialized
INFO - 2023-06-23 09:42:05 --> URI Class Initialized
INFO - 2023-06-23 09:42:05 --> Router Class Initialized
INFO - 2023-06-23 09:42:05 --> Output Class Initialized
INFO - 2023-06-23 09:42:05 --> Security Class Initialized
INFO - 2023-06-23 09:42:05 --> Input Class Initialized
INFO - 2023-06-23 09:42:05 --> Language Class Initialized
INFO - 2023-06-23 09:42:05 --> Loader Class Initialized
INFO - 2023-06-23 09:42:05 --> Helper loaded: url_helper
INFO - 2023-06-23 09:42:05 --> Helper loaded: form_helper
INFO - 2023-06-23 09:42:05 --> Database Driver Class Initialized
INFO - 2023-06-23 09:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:42:05 --> Form Validation Class Initialized
INFO - 2023-06-23 09:42:05 --> Controller Class Initialized
INFO - 2023-06-23 09:42:05 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:42:05 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:42:05 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:42:05 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:42:05 --> Final output sent to browser
INFO - 2023-06-23 09:43:06 --> Config Class Initialized
INFO - 2023-06-23 09:43:06 --> Hooks Class Initialized
INFO - 2023-06-23 09:43:06 --> Utf8 Class Initialized
INFO - 2023-06-23 09:43:06 --> URI Class Initialized
INFO - 2023-06-23 09:43:06 --> Router Class Initialized
INFO - 2023-06-23 09:43:06 --> Output Class Initialized
INFO - 2023-06-23 09:43:06 --> Security Class Initialized
INFO - 2023-06-23 09:43:06 --> Input Class Initialized
INFO - 2023-06-23 09:43:06 --> Language Class Initialized
INFO - 2023-06-23 09:43:06 --> Loader Class Initialized
INFO - 2023-06-23 09:43:06 --> Helper loaded: url_helper
INFO - 2023-06-23 09:43:06 --> Helper loaded: form_helper
INFO - 2023-06-23 09:43:06 --> Database Driver Class Initialized
INFO - 2023-06-23 09:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:43:06 --> Form Validation Class Initialized
INFO - 2023-06-23 09:43:06 --> Controller Class Initialized
INFO - 2023-06-23 09:43:06 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:43:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:43:06 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:43:06 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:43:06 --> Final output sent to browser
INFO - 2023-06-23 09:45:07 --> Config Class Initialized
INFO - 2023-06-23 09:45:07 --> Hooks Class Initialized
INFO - 2023-06-23 09:45:07 --> Utf8 Class Initialized
INFO - 2023-06-23 09:45:07 --> URI Class Initialized
INFO - 2023-06-23 09:45:07 --> Router Class Initialized
INFO - 2023-06-23 09:45:07 --> Output Class Initialized
INFO - 2023-06-23 09:45:07 --> Security Class Initialized
INFO - 2023-06-23 09:45:07 --> Input Class Initialized
INFO - 2023-06-23 09:45:07 --> Language Class Initialized
ERROR - 2023-06-23 09:45:08 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2048
INFO - 2023-06-23 09:45:23 --> Config Class Initialized
INFO - 2023-06-23 09:45:23 --> Hooks Class Initialized
INFO - 2023-06-23 09:45:23 --> Utf8 Class Initialized
INFO - 2023-06-23 09:45:23 --> URI Class Initialized
INFO - 2023-06-23 09:45:23 --> Router Class Initialized
INFO - 2023-06-23 09:45:23 --> Output Class Initialized
INFO - 2023-06-23 09:45:23 --> Security Class Initialized
INFO - 2023-06-23 09:45:23 --> Input Class Initialized
INFO - 2023-06-23 09:45:23 --> Language Class Initialized
ERROR - 2023-06-23 09:45:23 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2048
INFO - 2023-06-23 09:45:54 --> Config Class Initialized
INFO - 2023-06-23 09:45:54 --> Hooks Class Initialized
INFO - 2023-06-23 09:45:54 --> Utf8 Class Initialized
INFO - 2023-06-23 09:45:54 --> URI Class Initialized
INFO - 2023-06-23 09:45:54 --> Router Class Initialized
INFO - 2023-06-23 09:45:54 --> Output Class Initialized
INFO - 2023-06-23 09:45:54 --> Security Class Initialized
INFO - 2023-06-23 09:45:54 --> Input Class Initialized
INFO - 2023-06-23 09:45:54 --> Language Class Initialized
INFO - 2023-06-23 09:45:54 --> Loader Class Initialized
INFO - 2023-06-23 09:45:54 --> Helper loaded: url_helper
INFO - 2023-06-23 09:45:54 --> Helper loaded: form_helper
INFO - 2023-06-23 09:45:54 --> Database Driver Class Initialized
INFO - 2023-06-23 09:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:45:54 --> Form Validation Class Initialized
INFO - 2023-06-23 09:45:54 --> Controller Class Initialized
INFO - 2023-06-23 09:45:54 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:45:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:45:54 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:45:54 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:45:54 --> Final output sent to browser
INFO - 2023-06-23 09:46:13 --> Config Class Initialized
INFO - 2023-06-23 09:46:13 --> Hooks Class Initialized
INFO - 2023-06-23 09:46:13 --> Utf8 Class Initialized
INFO - 2023-06-23 09:46:13 --> URI Class Initialized
INFO - 2023-06-23 09:46:13 --> Router Class Initialized
INFO - 2023-06-23 09:46:13 --> Output Class Initialized
INFO - 2023-06-23 09:46:13 --> Security Class Initialized
INFO - 2023-06-23 09:46:13 --> Input Class Initialized
INFO - 2023-06-23 09:46:13 --> Language Class Initialized
INFO - 2023-06-23 09:46:13 --> Loader Class Initialized
INFO - 2023-06-23 09:46:13 --> Helper loaded: url_helper
INFO - 2023-06-23 09:46:13 --> Helper loaded: form_helper
INFO - 2023-06-23 09:46:13 --> Database Driver Class Initialized
INFO - 2023-06-23 09:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:46:13 --> Form Validation Class Initialized
INFO - 2023-06-23 09:46:13 --> Controller Class Initialized
INFO - 2023-06-23 09:46:13 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:46:13 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:46:13 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:46:13 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:46:13 --> Final output sent to browser
INFO - 2023-06-23 09:46:32 --> Config Class Initialized
INFO - 2023-06-23 09:46:32 --> Hooks Class Initialized
INFO - 2023-06-23 09:46:32 --> Utf8 Class Initialized
INFO - 2023-06-23 09:46:32 --> URI Class Initialized
INFO - 2023-06-23 09:46:32 --> Router Class Initialized
INFO - 2023-06-23 09:46:32 --> Output Class Initialized
INFO - 2023-06-23 09:46:32 --> Security Class Initialized
INFO - 2023-06-23 09:46:32 --> Input Class Initialized
INFO - 2023-06-23 09:46:32 --> Language Class Initialized
INFO - 2023-06-23 09:46:32 --> Loader Class Initialized
INFO - 2023-06-23 09:46:32 --> Helper loaded: url_helper
INFO - 2023-06-23 09:46:32 --> Helper loaded: form_helper
INFO - 2023-06-23 09:46:32 --> Database Driver Class Initialized
INFO - 2023-06-23 09:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:46:32 --> Form Validation Class Initialized
INFO - 2023-06-23 09:46:32 --> Controller Class Initialized
INFO - 2023-06-23 09:46:32 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:46:32 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:46:32 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:46:32 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:46:33 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:46:33 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:46:33 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 09:46:33 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:46:33 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:46:33 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:46:33 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 09:46:33 --> Final output sent to browser
INFO - 2023-06-23 09:47:51 --> Config Class Initialized
INFO - 2023-06-23 09:47:51 --> Hooks Class Initialized
INFO - 2023-06-23 09:47:51 --> Utf8 Class Initialized
INFO - 2023-06-23 09:47:51 --> URI Class Initialized
INFO - 2023-06-23 09:47:51 --> Router Class Initialized
INFO - 2023-06-23 09:47:51 --> Output Class Initialized
INFO - 2023-06-23 09:47:51 --> Security Class Initialized
INFO - 2023-06-23 09:47:51 --> Input Class Initialized
INFO - 2023-06-23 09:47:51 --> Language Class Initialized
INFO - 2023-06-23 09:47:51 --> Loader Class Initialized
INFO - 2023-06-23 09:47:51 --> Helper loaded: url_helper
INFO - 2023-06-23 09:47:51 --> Helper loaded: form_helper
INFO - 2023-06-23 09:47:51 --> Database Driver Class Initialized
INFO - 2023-06-23 09:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:47:51 --> Form Validation Class Initialized
INFO - 2023-06-23 09:47:51 --> Controller Class Initialized
INFO - 2023-06-23 09:47:51 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:47:51 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:47:51 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:47:51 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:47:51 --> Final output sent to browser
INFO - 2023-06-23 09:50:29 --> Config Class Initialized
INFO - 2023-06-23 09:50:29 --> Hooks Class Initialized
INFO - 2023-06-23 09:50:29 --> Utf8 Class Initialized
INFO - 2023-06-23 09:50:29 --> URI Class Initialized
INFO - 2023-06-23 09:50:29 --> Router Class Initialized
INFO - 2023-06-23 09:50:29 --> Output Class Initialized
INFO - 2023-06-23 09:50:29 --> Security Class Initialized
INFO - 2023-06-23 09:50:29 --> Input Class Initialized
INFO - 2023-06-23 09:50:29 --> Language Class Initialized
INFO - 2023-06-23 09:50:29 --> Loader Class Initialized
INFO - 2023-06-23 09:50:29 --> Helper loaded: url_helper
INFO - 2023-06-23 09:50:29 --> Helper loaded: form_helper
INFO - 2023-06-23 09:50:29 --> Database Driver Class Initialized
INFO - 2023-06-23 09:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:50:29 --> Form Validation Class Initialized
INFO - 2023-06-23 09:50:29 --> Controller Class Initialized
INFO - 2023-06-23 09:50:29 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:50:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:50:29 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:50:29 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:50:29 --> Final output sent to browser
INFO - 2023-06-23 09:50:45 --> Config Class Initialized
INFO - 2023-06-23 09:50:45 --> Hooks Class Initialized
INFO - 2023-06-23 09:50:45 --> Utf8 Class Initialized
INFO - 2023-06-23 09:50:45 --> URI Class Initialized
INFO - 2023-06-23 09:50:45 --> Router Class Initialized
INFO - 2023-06-23 09:50:45 --> Output Class Initialized
INFO - 2023-06-23 09:50:45 --> Security Class Initialized
INFO - 2023-06-23 09:50:45 --> Input Class Initialized
INFO - 2023-06-23 09:50:45 --> Language Class Initialized
INFO - 2023-06-23 09:50:45 --> Loader Class Initialized
INFO - 2023-06-23 09:50:45 --> Helper loaded: url_helper
INFO - 2023-06-23 09:50:45 --> Helper loaded: form_helper
INFO - 2023-06-23 09:50:45 --> Database Driver Class Initialized
INFO - 2023-06-23 09:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:50:45 --> Form Validation Class Initialized
INFO - 2023-06-23 09:50:45 --> Controller Class Initialized
INFO - 2023-06-23 09:50:45 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:50:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:50:45 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:50:45 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:50:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:50:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:50:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 09:50:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:50:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:50:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:50:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 09:50:46 --> Final output sent to browser
INFO - 2023-06-23 09:52:38 --> Config Class Initialized
INFO - 2023-06-23 09:52:38 --> Hooks Class Initialized
INFO - 2023-06-23 09:52:38 --> Utf8 Class Initialized
INFO - 2023-06-23 09:52:38 --> URI Class Initialized
INFO - 2023-06-23 09:52:38 --> Router Class Initialized
INFO - 2023-06-23 09:52:38 --> Output Class Initialized
INFO - 2023-06-23 09:52:38 --> Security Class Initialized
INFO - 2023-06-23 09:52:38 --> Input Class Initialized
INFO - 2023-06-23 09:52:38 --> Language Class Initialized
INFO - 2023-06-23 09:52:38 --> Loader Class Initialized
INFO - 2023-06-23 09:52:38 --> Helper loaded: url_helper
INFO - 2023-06-23 09:52:38 --> Helper loaded: form_helper
INFO - 2023-06-23 09:52:38 --> Database Driver Class Initialized
INFO - 2023-06-23 09:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:52:38 --> Form Validation Class Initialized
INFO - 2023-06-23 09:52:38 --> Controller Class Initialized
INFO - 2023-06-23 09:52:38 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:52:38 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:52:38 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:52:38 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:52:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:52:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:52:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 09:52:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:52:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:52:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:52:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 09:52:38 --> Final output sent to browser
INFO - 2023-06-23 09:53:11 --> Config Class Initialized
INFO - 2023-06-23 09:53:11 --> Hooks Class Initialized
INFO - 2023-06-23 09:53:11 --> Utf8 Class Initialized
INFO - 2023-06-23 09:53:11 --> URI Class Initialized
INFO - 2023-06-23 09:53:11 --> Router Class Initialized
INFO - 2023-06-23 09:53:11 --> Output Class Initialized
INFO - 2023-06-23 09:53:11 --> Security Class Initialized
INFO - 2023-06-23 09:53:11 --> Input Class Initialized
INFO - 2023-06-23 09:53:11 --> Language Class Initialized
INFO - 2023-06-23 09:53:11 --> Loader Class Initialized
INFO - 2023-06-23 09:53:11 --> Helper loaded: url_helper
INFO - 2023-06-23 09:53:11 --> Helper loaded: form_helper
INFO - 2023-06-23 09:53:11 --> Database Driver Class Initialized
INFO - 2023-06-23 09:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:53:11 --> Form Validation Class Initialized
INFO - 2023-06-23 09:53:11 --> Controller Class Initialized
INFO - 2023-06-23 09:53:11 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:53:11 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:53:11 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:53:11 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:53:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:53:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:53:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 09:53:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:53:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:53:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:53:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 09:53:11 --> Final output sent to browser
INFO - 2023-06-23 09:53:46 --> Config Class Initialized
INFO - 2023-06-23 09:53:46 --> Hooks Class Initialized
INFO - 2023-06-23 09:53:46 --> Utf8 Class Initialized
INFO - 2023-06-23 09:53:46 --> URI Class Initialized
INFO - 2023-06-23 09:53:46 --> Router Class Initialized
INFO - 2023-06-23 09:53:46 --> Output Class Initialized
INFO - 2023-06-23 09:53:46 --> Security Class Initialized
INFO - 2023-06-23 09:53:46 --> Input Class Initialized
INFO - 2023-06-23 09:53:46 --> Language Class Initialized
INFO - 2023-06-23 09:53:46 --> Loader Class Initialized
INFO - 2023-06-23 09:53:46 --> Helper loaded: url_helper
INFO - 2023-06-23 09:53:46 --> Helper loaded: form_helper
INFO - 2023-06-23 09:53:46 --> Database Driver Class Initialized
INFO - 2023-06-23 09:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:53:46 --> Form Validation Class Initialized
INFO - 2023-06-23 09:53:46 --> Controller Class Initialized
INFO - 2023-06-23 09:53:46 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:53:46 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:53:46 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:53:46 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:53:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:53:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:53:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 09:53:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:53:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:53:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:53:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 09:53:46 --> Final output sent to browser
INFO - 2023-06-23 09:54:05 --> Config Class Initialized
INFO - 2023-06-23 09:54:05 --> Hooks Class Initialized
INFO - 2023-06-23 09:54:05 --> Utf8 Class Initialized
INFO - 2023-06-23 09:54:05 --> URI Class Initialized
INFO - 2023-06-23 09:54:05 --> Router Class Initialized
INFO - 2023-06-23 09:54:05 --> Output Class Initialized
INFO - 2023-06-23 09:54:05 --> Security Class Initialized
INFO - 2023-06-23 09:54:05 --> Input Class Initialized
INFO - 2023-06-23 09:54:05 --> Language Class Initialized
INFO - 2023-06-23 09:54:05 --> Loader Class Initialized
INFO - 2023-06-23 09:54:05 --> Helper loaded: url_helper
INFO - 2023-06-23 09:54:05 --> Helper loaded: form_helper
INFO - 2023-06-23 09:54:05 --> Database Driver Class Initialized
INFO - 2023-06-23 09:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:54:05 --> Form Validation Class Initialized
INFO - 2023-06-23 09:54:05 --> Controller Class Initialized
INFO - 2023-06-23 09:54:05 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:54:05 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:54:05 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:54:05 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:54:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:54:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:54:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 09:54:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:54:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:54:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:54:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 09:54:05 --> Final output sent to browser
INFO - 2023-06-23 09:55:21 --> Config Class Initialized
INFO - 2023-06-23 09:55:21 --> Hooks Class Initialized
INFO - 2023-06-23 09:55:21 --> Utf8 Class Initialized
INFO - 2023-06-23 09:55:21 --> URI Class Initialized
INFO - 2023-06-23 09:55:21 --> Router Class Initialized
INFO - 2023-06-23 09:55:21 --> Output Class Initialized
INFO - 2023-06-23 09:55:21 --> Security Class Initialized
INFO - 2023-06-23 09:55:21 --> Input Class Initialized
INFO - 2023-06-23 09:55:21 --> Language Class Initialized
INFO - 2023-06-23 09:55:21 --> Loader Class Initialized
INFO - 2023-06-23 09:55:21 --> Helper loaded: url_helper
INFO - 2023-06-23 09:55:21 --> Helper loaded: form_helper
INFO - 2023-06-23 09:55:21 --> Database Driver Class Initialized
INFO - 2023-06-23 09:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:55:21 --> Form Validation Class Initialized
INFO - 2023-06-23 09:55:21 --> Controller Class Initialized
INFO - 2023-06-23 09:55:21 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:55:21 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:55:21 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:55:21 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:55:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:55:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:55:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 09:55:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:55:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:55:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:55:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 09:55:21 --> Final output sent to browser
INFO - 2023-06-23 09:56:50 --> Config Class Initialized
INFO - 2023-06-23 09:56:50 --> Hooks Class Initialized
INFO - 2023-06-23 09:56:50 --> Utf8 Class Initialized
INFO - 2023-06-23 09:56:50 --> URI Class Initialized
INFO - 2023-06-23 09:56:50 --> Router Class Initialized
INFO - 2023-06-23 09:56:50 --> Output Class Initialized
INFO - 2023-06-23 09:56:50 --> Security Class Initialized
INFO - 2023-06-23 09:56:50 --> Input Class Initialized
INFO - 2023-06-23 09:56:50 --> Language Class Initialized
INFO - 2023-06-23 09:56:50 --> Loader Class Initialized
INFO - 2023-06-23 09:56:50 --> Helper loaded: url_helper
INFO - 2023-06-23 09:56:50 --> Helper loaded: form_helper
INFO - 2023-06-23 09:56:50 --> Database Driver Class Initialized
INFO - 2023-06-23 09:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:56:50 --> Form Validation Class Initialized
INFO - 2023-06-23 09:56:50 --> Controller Class Initialized
INFO - 2023-06-23 09:56:50 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:56:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:56:50 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:56:50 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:56:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:56:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 09:56:50 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\sistemdepresi\application\views\diagnosa\V_hasil.php 31
INFO - 2023-06-23 09:57:44 --> Config Class Initialized
INFO - 2023-06-23 09:57:44 --> Hooks Class Initialized
INFO - 2023-06-23 09:57:44 --> Utf8 Class Initialized
INFO - 2023-06-23 09:57:44 --> URI Class Initialized
INFO - 2023-06-23 09:57:44 --> Router Class Initialized
INFO - 2023-06-23 09:57:44 --> Output Class Initialized
INFO - 2023-06-23 09:57:44 --> Security Class Initialized
INFO - 2023-06-23 09:57:44 --> Input Class Initialized
INFO - 2023-06-23 09:57:44 --> Language Class Initialized
INFO - 2023-06-23 09:57:44 --> Loader Class Initialized
INFO - 2023-06-23 09:57:44 --> Helper loaded: url_helper
INFO - 2023-06-23 09:57:44 --> Helper loaded: form_helper
INFO - 2023-06-23 09:57:44 --> Database Driver Class Initialized
INFO - 2023-06-23 09:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:57:44 --> Form Validation Class Initialized
INFO - 2023-06-23 09:57:44 --> Controller Class Initialized
INFO - 2023-06-23 09:57:44 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:57:44 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:57:44 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:57:44 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:57:44 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:57:44 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 09:57:44 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\sistemdepresi\application\views\diagnosa\V_hasil.php 31
INFO - 2023-06-23 09:59:34 --> Config Class Initialized
INFO - 2023-06-23 09:59:34 --> Hooks Class Initialized
INFO - 2023-06-23 09:59:34 --> Utf8 Class Initialized
INFO - 2023-06-23 09:59:34 --> URI Class Initialized
INFO - 2023-06-23 09:59:34 --> Router Class Initialized
INFO - 2023-06-23 09:59:34 --> Output Class Initialized
INFO - 2023-06-23 09:59:34 --> Security Class Initialized
INFO - 2023-06-23 09:59:34 --> Input Class Initialized
INFO - 2023-06-23 09:59:34 --> Language Class Initialized
INFO - 2023-06-23 09:59:34 --> Loader Class Initialized
INFO - 2023-06-23 09:59:34 --> Helper loaded: url_helper
INFO - 2023-06-23 09:59:34 --> Helper loaded: form_helper
INFO - 2023-06-23 09:59:34 --> Database Driver Class Initialized
INFO - 2023-06-23 09:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 09:59:34 --> Form Validation Class Initialized
INFO - 2023-06-23 09:59:34 --> Controller Class Initialized
INFO - 2023-06-23 09:59:34 --> Model "m_datatrain" initialized
INFO - 2023-06-23 09:59:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 09:59:34 --> Model "m_datatest" initialized
INFO - 2023-06-23 09:59:34 --> Model "M_solusi" initialized
INFO - 2023-06-23 09:59:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 09:59:34 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 09:59:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 09:59:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 09:59:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 09:59:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 09:59:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 09:59:35 --> Final output sent to browser
INFO - 2023-06-23 10:00:26 --> Config Class Initialized
INFO - 2023-06-23 10:00:26 --> Hooks Class Initialized
INFO - 2023-06-23 10:00:26 --> Utf8 Class Initialized
INFO - 2023-06-23 10:00:26 --> URI Class Initialized
INFO - 2023-06-23 10:00:26 --> Router Class Initialized
INFO - 2023-06-23 10:00:26 --> Output Class Initialized
INFO - 2023-06-23 10:00:26 --> Security Class Initialized
INFO - 2023-06-23 10:00:26 --> Input Class Initialized
INFO - 2023-06-23 10:00:26 --> Language Class Initialized
INFO - 2023-06-23 10:00:26 --> Loader Class Initialized
INFO - 2023-06-23 10:00:26 --> Helper loaded: url_helper
INFO - 2023-06-23 10:00:26 --> Helper loaded: form_helper
INFO - 2023-06-23 10:00:26 --> Database Driver Class Initialized
INFO - 2023-06-23 10:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:00:26 --> Form Validation Class Initialized
INFO - 2023-06-23 10:00:26 --> Controller Class Initialized
INFO - 2023-06-23 10:00:26 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:00:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:00:26 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:00:26 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:00:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 10:00:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 10:00:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 10:00:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 10:00:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 10:00:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 10:00:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 10:00:26 --> Final output sent to browser
INFO - 2023-06-23 10:03:35 --> Config Class Initialized
INFO - 2023-06-23 10:03:35 --> Hooks Class Initialized
INFO - 2023-06-23 10:03:35 --> Utf8 Class Initialized
INFO - 2023-06-23 10:03:35 --> URI Class Initialized
INFO - 2023-06-23 10:03:35 --> Router Class Initialized
INFO - 2023-06-23 10:03:35 --> Output Class Initialized
INFO - 2023-06-23 10:03:35 --> Security Class Initialized
INFO - 2023-06-23 10:03:36 --> Input Class Initialized
INFO - 2023-06-23 10:03:36 --> Language Class Initialized
INFO - 2023-06-23 10:03:36 --> Loader Class Initialized
INFO - 2023-06-23 10:03:36 --> Helper loaded: url_helper
INFO - 2023-06-23 10:03:36 --> Helper loaded: form_helper
INFO - 2023-06-23 10:03:36 --> Database Driver Class Initialized
INFO - 2023-06-23 10:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:03:36 --> Form Validation Class Initialized
INFO - 2023-06-23 10:03:36 --> Controller Class Initialized
INFO - 2023-06-23 10:03:36 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:03:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:03:36 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:03:36 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:03:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 10:03:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 10:03:36 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdepresi\application\views\diagnosa\V_hasil.php 152
INFO - 2023-06-23 10:04:15 --> Config Class Initialized
INFO - 2023-06-23 10:04:15 --> Hooks Class Initialized
INFO - 2023-06-23 10:04:15 --> Utf8 Class Initialized
INFO - 2023-06-23 10:04:15 --> URI Class Initialized
INFO - 2023-06-23 10:04:15 --> Router Class Initialized
INFO - 2023-06-23 10:04:15 --> Output Class Initialized
INFO - 2023-06-23 10:04:15 --> Security Class Initialized
INFO - 2023-06-23 10:04:15 --> Input Class Initialized
INFO - 2023-06-23 10:04:15 --> Language Class Initialized
INFO - 2023-06-23 10:04:15 --> Loader Class Initialized
INFO - 2023-06-23 10:04:15 --> Helper loaded: url_helper
INFO - 2023-06-23 10:04:15 --> Helper loaded: form_helper
INFO - 2023-06-23 10:04:15 --> Database Driver Class Initialized
INFO - 2023-06-23 10:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:04:15 --> Form Validation Class Initialized
INFO - 2023-06-23 10:04:15 --> Controller Class Initialized
INFO - 2023-06-23 10:04:15 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:04:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:04:16 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:04:16 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:04:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 10:04:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 10:04:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sistemdepresi\application\views\diagnosa\V_hasil.php 30
INFO - 2023-06-23 10:04:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 10:04:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 10:04:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 10:04:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 10:04:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 10:04:16 --> Final output sent to browser
INFO - 2023-06-23 10:14:48 --> Config Class Initialized
INFO - 2023-06-23 10:14:48 --> Hooks Class Initialized
INFO - 2023-06-23 10:14:48 --> Utf8 Class Initialized
INFO - 2023-06-23 10:14:48 --> URI Class Initialized
INFO - 2023-06-23 10:14:48 --> Router Class Initialized
INFO - 2023-06-23 10:14:48 --> Output Class Initialized
INFO - 2023-06-23 10:14:48 --> Security Class Initialized
INFO - 2023-06-23 10:14:48 --> Input Class Initialized
INFO - 2023-06-23 10:14:48 --> Language Class Initialized
INFO - 2023-06-23 10:14:48 --> Loader Class Initialized
INFO - 2023-06-23 10:14:48 --> Helper loaded: url_helper
INFO - 2023-06-23 10:14:48 --> Helper loaded: form_helper
INFO - 2023-06-23 10:14:48 --> Database Driver Class Initialized
INFO - 2023-06-23 10:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:14:49 --> Form Validation Class Initialized
INFO - 2023-06-23 10:14:49 --> Controller Class Initialized
INFO - 2023-06-23 10:14:49 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:14:49 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:14:49 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:14:49 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:14:49 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 10:14:49 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 10:14:49 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\sistemdepresi\application\views\diagnosa\V_hasil.php 43
INFO - 2023-06-23 10:15:04 --> Config Class Initialized
INFO - 2023-06-23 10:15:04 --> Hooks Class Initialized
INFO - 2023-06-23 10:15:04 --> Utf8 Class Initialized
INFO - 2023-06-23 10:15:04 --> URI Class Initialized
INFO - 2023-06-23 10:15:04 --> Router Class Initialized
INFO - 2023-06-23 10:15:04 --> Output Class Initialized
INFO - 2023-06-23 10:15:04 --> Security Class Initialized
INFO - 2023-06-23 10:15:04 --> Input Class Initialized
INFO - 2023-06-23 10:15:04 --> Language Class Initialized
INFO - 2023-06-23 10:15:04 --> Loader Class Initialized
INFO - 2023-06-23 10:15:04 --> Helper loaded: url_helper
INFO - 2023-06-23 10:15:04 --> Helper loaded: form_helper
INFO - 2023-06-23 10:15:04 --> Database Driver Class Initialized
INFO - 2023-06-23 10:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:15:04 --> Form Validation Class Initialized
INFO - 2023-06-23 10:15:04 --> Controller Class Initialized
INFO - 2023-06-23 10:15:04 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:15:04 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:15:04 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:15:04 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:15:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 10:15:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 10:15:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 10:15:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 10:15:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 10:15:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 10:15:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 10:15:04 --> Final output sent to browser
INFO - 2023-06-23 10:16:03 --> Config Class Initialized
INFO - 2023-06-23 10:16:03 --> Hooks Class Initialized
INFO - 2023-06-23 10:16:03 --> Utf8 Class Initialized
INFO - 2023-06-23 10:16:03 --> URI Class Initialized
INFO - 2023-06-23 10:16:03 --> Router Class Initialized
INFO - 2023-06-23 10:16:03 --> Output Class Initialized
INFO - 2023-06-23 10:16:03 --> Security Class Initialized
INFO - 2023-06-23 10:16:03 --> Input Class Initialized
INFO - 2023-06-23 10:16:03 --> Language Class Initialized
INFO - 2023-06-23 10:16:03 --> Loader Class Initialized
INFO - 2023-06-23 10:16:03 --> Helper loaded: url_helper
INFO - 2023-06-23 10:16:03 --> Helper loaded: form_helper
INFO - 2023-06-23 10:16:03 --> Database Driver Class Initialized
INFO - 2023-06-23 10:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:16:03 --> Form Validation Class Initialized
INFO - 2023-06-23 10:16:03 --> Controller Class Initialized
INFO - 2023-06-23 10:16:03 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:16:03 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:16:03 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:16:03 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:16:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 10:16:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 10:16:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 10:16:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 10:16:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 10:16:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 10:16:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 10:16:03 --> Final output sent to browser
INFO - 2023-06-23 10:16:42 --> Config Class Initialized
INFO - 2023-06-23 10:16:42 --> Hooks Class Initialized
INFO - 2023-06-23 10:16:42 --> Utf8 Class Initialized
INFO - 2023-06-23 10:16:42 --> URI Class Initialized
INFO - 2023-06-23 10:16:42 --> Router Class Initialized
INFO - 2023-06-23 10:16:42 --> Output Class Initialized
INFO - 2023-06-23 10:16:42 --> Security Class Initialized
INFO - 2023-06-23 10:16:42 --> Input Class Initialized
INFO - 2023-06-23 10:16:42 --> Language Class Initialized
INFO - 2023-06-23 10:16:42 --> Loader Class Initialized
INFO - 2023-06-23 10:16:42 --> Helper loaded: url_helper
INFO - 2023-06-23 10:16:42 --> Helper loaded: form_helper
INFO - 2023-06-23 10:16:42 --> Database Driver Class Initialized
INFO - 2023-06-23 10:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:16:42 --> Form Validation Class Initialized
INFO - 2023-06-23 10:16:42 --> Controller Class Initialized
INFO - 2023-06-23 10:16:42 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:16:42 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:16:42 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:16:42 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:16:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 10:16:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 10:16:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 10:16:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 10:16:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 10:16:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 10:16:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 10:16:42 --> Final output sent to browser
INFO - 2023-06-23 10:17:46 --> Config Class Initialized
INFO - 2023-06-23 10:17:46 --> Hooks Class Initialized
INFO - 2023-06-23 10:17:46 --> Utf8 Class Initialized
INFO - 2023-06-23 10:17:46 --> URI Class Initialized
INFO - 2023-06-23 10:17:46 --> Router Class Initialized
INFO - 2023-06-23 10:17:46 --> Output Class Initialized
INFO - 2023-06-23 10:17:46 --> Security Class Initialized
INFO - 2023-06-23 10:17:46 --> Input Class Initialized
INFO - 2023-06-23 10:17:46 --> Language Class Initialized
INFO - 2023-06-23 10:17:46 --> Loader Class Initialized
INFO - 2023-06-23 10:17:46 --> Helper loaded: url_helper
INFO - 2023-06-23 10:17:46 --> Helper loaded: form_helper
INFO - 2023-06-23 10:17:46 --> Database Driver Class Initialized
INFO - 2023-06-23 10:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:17:46 --> Form Validation Class Initialized
INFO - 2023-06-23 10:17:46 --> Controller Class Initialized
INFO - 2023-06-23 10:17:46 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:17:46 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:17:46 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:17:46 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:17:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 10:17:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 10:17:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 10:17:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 10:17:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 10:17:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 10:17:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 10:17:46 --> Final output sent to browser
INFO - 2023-06-23 10:18:03 --> Config Class Initialized
INFO - 2023-06-23 10:18:03 --> Hooks Class Initialized
INFO - 2023-06-23 10:18:03 --> Utf8 Class Initialized
INFO - 2023-06-23 10:18:03 --> URI Class Initialized
INFO - 2023-06-23 10:18:03 --> Router Class Initialized
INFO - 2023-06-23 10:18:03 --> Output Class Initialized
INFO - 2023-06-23 10:18:03 --> Security Class Initialized
INFO - 2023-06-23 10:18:03 --> Input Class Initialized
INFO - 2023-06-23 10:18:03 --> Language Class Initialized
INFO - 2023-06-23 10:18:03 --> Loader Class Initialized
INFO - 2023-06-23 10:18:03 --> Helper loaded: url_helper
INFO - 2023-06-23 10:18:03 --> Helper loaded: form_helper
INFO - 2023-06-23 10:18:03 --> Database Driver Class Initialized
INFO - 2023-06-23 10:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:18:03 --> Form Validation Class Initialized
INFO - 2023-06-23 10:18:03 --> Controller Class Initialized
INFO - 2023-06-23 10:18:03 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:18:03 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:18:03 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:18:03 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:18:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 10:18:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 10:18:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 10:18:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 10:18:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 10:18:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 10:18:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 10:18:04 --> Final output sent to browser
INFO - 2023-06-23 10:18:26 --> Config Class Initialized
INFO - 2023-06-23 10:18:26 --> Hooks Class Initialized
INFO - 2023-06-23 10:18:26 --> Utf8 Class Initialized
INFO - 2023-06-23 10:18:26 --> URI Class Initialized
INFO - 2023-06-23 10:18:26 --> Router Class Initialized
INFO - 2023-06-23 10:18:26 --> Output Class Initialized
INFO - 2023-06-23 10:18:26 --> Security Class Initialized
INFO - 2023-06-23 10:18:26 --> Input Class Initialized
INFO - 2023-06-23 10:18:26 --> Language Class Initialized
INFO - 2023-06-23 10:18:26 --> Loader Class Initialized
INFO - 2023-06-23 10:18:26 --> Helper loaded: url_helper
INFO - 2023-06-23 10:18:26 --> Helper loaded: form_helper
INFO - 2023-06-23 10:18:26 --> Database Driver Class Initialized
INFO - 2023-06-23 10:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:18:26 --> Form Validation Class Initialized
INFO - 2023-06-23 10:18:26 --> Controller Class Initialized
INFO - 2023-06-23 10:18:26 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:18:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:18:26 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:18:26 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:18:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 10:18:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 10:18:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 10:18:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 10:18:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 10:18:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 10:18:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 10:18:27 --> Final output sent to browser
INFO - 2023-06-23 10:23:31 --> Config Class Initialized
INFO - 2023-06-23 10:23:31 --> Hooks Class Initialized
INFO - 2023-06-23 10:23:31 --> Utf8 Class Initialized
INFO - 2023-06-23 10:23:31 --> URI Class Initialized
INFO - 2023-06-23 10:23:31 --> Router Class Initialized
INFO - 2023-06-23 10:23:31 --> Output Class Initialized
INFO - 2023-06-23 10:23:31 --> Security Class Initialized
INFO - 2023-06-23 10:23:31 --> Input Class Initialized
INFO - 2023-06-23 10:23:31 --> Language Class Initialized
INFO - 2023-06-23 10:23:31 --> Loader Class Initialized
INFO - 2023-06-23 10:23:31 --> Helper loaded: url_helper
INFO - 2023-06-23 10:23:31 --> Helper loaded: form_helper
INFO - 2023-06-23 10:23:31 --> Database Driver Class Initialized
INFO - 2023-06-23 10:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:23:31 --> Form Validation Class Initialized
INFO - 2023-06-23 10:23:31 --> Controller Class Initialized
INFO - 2023-06-23 10:23:31 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:23:31 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:23:31 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:23:31 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:23:31 --> Final output sent to browser
INFO - 2023-06-23 10:23:43 --> Config Class Initialized
INFO - 2023-06-23 10:23:43 --> Hooks Class Initialized
INFO - 2023-06-23 10:23:43 --> Utf8 Class Initialized
INFO - 2023-06-23 10:23:43 --> URI Class Initialized
INFO - 2023-06-23 10:23:43 --> Router Class Initialized
INFO - 2023-06-23 10:23:43 --> Output Class Initialized
INFO - 2023-06-23 10:23:43 --> Security Class Initialized
INFO - 2023-06-23 10:23:43 --> Input Class Initialized
INFO - 2023-06-23 10:23:43 --> Language Class Initialized
ERROR - 2023-06-23 10:23:43 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2036
INFO - 2023-06-23 10:25:02 --> Config Class Initialized
INFO - 2023-06-23 10:25:02 --> Hooks Class Initialized
INFO - 2023-06-23 10:25:02 --> Utf8 Class Initialized
INFO - 2023-06-23 10:25:02 --> URI Class Initialized
INFO - 2023-06-23 10:25:02 --> Router Class Initialized
INFO - 2023-06-23 10:25:02 --> Output Class Initialized
INFO - 2023-06-23 10:25:02 --> Security Class Initialized
INFO - 2023-06-23 10:25:02 --> Input Class Initialized
INFO - 2023-06-23 10:25:02 --> Language Class Initialized
INFO - 2023-06-23 10:25:02 --> Loader Class Initialized
INFO - 2023-06-23 10:25:02 --> Helper loaded: url_helper
INFO - 2023-06-23 10:25:02 --> Helper loaded: form_helper
INFO - 2023-06-23 10:25:02 --> Database Driver Class Initialized
INFO - 2023-06-23 10:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:25:02 --> Form Validation Class Initialized
INFO - 2023-06-23 10:25:02 --> Controller Class Initialized
INFO - 2023-06-23 10:25:02 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:25:02 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:25:02 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:25:02 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:25:02 --> Final output sent to browser
INFO - 2023-06-23 10:25:13 --> Config Class Initialized
INFO - 2023-06-23 10:25:13 --> Hooks Class Initialized
INFO - 2023-06-23 10:25:13 --> Utf8 Class Initialized
INFO - 2023-06-23 10:25:13 --> URI Class Initialized
INFO - 2023-06-23 10:25:13 --> Router Class Initialized
INFO - 2023-06-23 10:25:13 --> Output Class Initialized
INFO - 2023-06-23 10:25:13 --> Security Class Initialized
INFO - 2023-06-23 10:25:13 --> Input Class Initialized
INFO - 2023-06-23 10:25:13 --> Language Class Initialized
ERROR - 2023-06-23 10:25:13 --> Severity: Parsing Error --> syntax error, unexpected '$prob_GangguanMood_percent1' (T_VARIABLE) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2036
INFO - 2023-06-23 10:25:30 --> Config Class Initialized
INFO - 2023-06-23 10:25:30 --> Hooks Class Initialized
INFO - 2023-06-23 10:25:30 --> Utf8 Class Initialized
INFO - 2023-06-23 10:25:30 --> URI Class Initialized
INFO - 2023-06-23 10:25:30 --> Router Class Initialized
INFO - 2023-06-23 10:25:30 --> Output Class Initialized
INFO - 2023-06-23 10:25:30 --> Security Class Initialized
INFO - 2023-06-23 10:25:30 --> Input Class Initialized
INFO - 2023-06-23 10:25:30 --> Language Class Initialized
ERROR - 2023-06-23 10:25:30 --> Severity: Parsing Error --> syntax error, unexpected '$prob_GangguanMood_percent1' (T_VARIABLE) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2036
INFO - 2023-06-23 10:26:13 --> Config Class Initialized
INFO - 2023-06-23 10:26:13 --> Hooks Class Initialized
INFO - 2023-06-23 10:26:13 --> Utf8 Class Initialized
INFO - 2023-06-23 10:26:13 --> URI Class Initialized
INFO - 2023-06-23 10:26:13 --> Router Class Initialized
INFO - 2023-06-23 10:26:13 --> Output Class Initialized
INFO - 2023-06-23 10:26:13 --> Security Class Initialized
INFO - 2023-06-23 10:26:13 --> Input Class Initialized
INFO - 2023-06-23 10:26:13 --> Language Class Initialized
ERROR - 2023-06-23 10:26:13 --> Severity: Parsing Error --> syntax error, unexpected 'number_format' (T_STRING) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2036
INFO - 2023-06-23 10:26:24 --> Config Class Initialized
INFO - 2023-06-23 10:26:24 --> Hooks Class Initialized
INFO - 2023-06-23 10:26:24 --> Utf8 Class Initialized
INFO - 2023-06-23 10:26:24 --> URI Class Initialized
INFO - 2023-06-23 10:26:24 --> Router Class Initialized
INFO - 2023-06-23 10:26:24 --> Output Class Initialized
INFO - 2023-06-23 10:26:24 --> Security Class Initialized
INFO - 2023-06-23 10:26:24 --> Input Class Initialized
INFO - 2023-06-23 10:26:24 --> Language Class Initialized
ERROR - 2023-06-23 10:26:24 --> Severity: Parsing Error --> syntax error, unexpected 'number_format' (T_STRING) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2036
INFO - 2023-06-23 10:26:42 --> Config Class Initialized
INFO - 2023-06-23 10:26:42 --> Hooks Class Initialized
INFO - 2023-06-23 10:26:42 --> Utf8 Class Initialized
INFO - 2023-06-23 10:26:42 --> URI Class Initialized
INFO - 2023-06-23 10:26:42 --> Router Class Initialized
INFO - 2023-06-23 10:26:42 --> Output Class Initialized
INFO - 2023-06-23 10:26:42 --> Security Class Initialized
INFO - 2023-06-23 10:26:42 --> Input Class Initialized
INFO - 2023-06-23 10:26:42 --> Language Class Initialized
ERROR - 2023-06-23 10:26:42 --> Severity: Parsing Error --> syntax error, unexpected '(float)' (double) (T_DOUBLE_CAST) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2036
INFO - 2023-06-23 10:28:30 --> Config Class Initialized
INFO - 2023-06-23 10:28:30 --> Hooks Class Initialized
INFO - 2023-06-23 10:28:30 --> Utf8 Class Initialized
INFO - 2023-06-23 10:28:30 --> URI Class Initialized
INFO - 2023-06-23 10:28:30 --> Router Class Initialized
INFO - 2023-06-23 10:28:30 --> Output Class Initialized
INFO - 2023-06-23 10:28:30 --> Security Class Initialized
INFO - 2023-06-23 10:28:30 --> Input Class Initialized
INFO - 2023-06-23 10:28:30 --> Language Class Initialized
ERROR - 2023-06-23 10:28:30 --> Severity: Compile Error --> Can't use function return value in write context C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2036
INFO - 2023-06-23 10:29:58 --> Config Class Initialized
INFO - 2023-06-23 10:29:58 --> Hooks Class Initialized
INFO - 2023-06-23 10:29:58 --> Utf8 Class Initialized
INFO - 2023-06-23 10:29:58 --> URI Class Initialized
INFO - 2023-06-23 10:29:58 --> Router Class Initialized
INFO - 2023-06-23 10:29:58 --> Output Class Initialized
INFO - 2023-06-23 10:29:58 --> Security Class Initialized
INFO - 2023-06-23 10:29:58 --> Input Class Initialized
INFO - 2023-06-23 10:29:58 --> Language Class Initialized
INFO - 2023-06-23 10:29:58 --> Loader Class Initialized
INFO - 2023-06-23 10:29:58 --> Helper loaded: url_helper
INFO - 2023-06-23 10:29:58 --> Helper loaded: form_helper
INFO - 2023-06-23 10:29:58 --> Database Driver Class Initialized
INFO - 2023-06-23 10:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:29:58 --> Form Validation Class Initialized
INFO - 2023-06-23 10:29:58 --> Controller Class Initialized
INFO - 2023-06-23 10:29:58 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:29:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:29:58 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:29:58 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:29:58 --> Final output sent to browser
INFO - 2023-06-23 10:34:21 --> Config Class Initialized
INFO - 2023-06-23 10:34:21 --> Hooks Class Initialized
INFO - 2023-06-23 10:34:21 --> Utf8 Class Initialized
INFO - 2023-06-23 10:34:21 --> URI Class Initialized
INFO - 2023-06-23 10:34:21 --> Router Class Initialized
INFO - 2023-06-23 10:34:21 --> Output Class Initialized
INFO - 2023-06-23 10:34:21 --> Security Class Initialized
INFO - 2023-06-23 10:34:21 --> Input Class Initialized
INFO - 2023-06-23 10:34:21 --> Language Class Initialized
ERROR - 2023-06-23 10:34:21 --> Severity: Parsing Error --> syntax error, unexpected '$prob_GangguanMood' (T_VARIABLE) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2008
INFO - 2023-06-23 10:34:54 --> Config Class Initialized
INFO - 2023-06-23 10:34:54 --> Hooks Class Initialized
INFO - 2023-06-23 10:34:54 --> Utf8 Class Initialized
INFO - 2023-06-23 10:34:54 --> URI Class Initialized
INFO - 2023-06-23 10:34:54 --> Router Class Initialized
INFO - 2023-06-23 10:34:54 --> Output Class Initialized
INFO - 2023-06-23 10:34:54 --> Security Class Initialized
INFO - 2023-06-23 10:34:54 --> Input Class Initialized
INFO - 2023-06-23 10:34:54 --> Language Class Initialized
ERROR - 2023-06-23 10:34:54 --> Severity: Parsing Error --> syntax error, unexpected '$prob_Ringan' (T_VARIABLE) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2009
INFO - 2023-06-23 10:35:16 --> Config Class Initialized
INFO - 2023-06-23 10:35:16 --> Hooks Class Initialized
INFO - 2023-06-23 10:35:16 --> Utf8 Class Initialized
INFO - 2023-06-23 10:35:16 --> URI Class Initialized
INFO - 2023-06-23 10:35:16 --> Router Class Initialized
INFO - 2023-06-23 10:35:16 --> Output Class Initialized
INFO - 2023-06-23 10:35:16 --> Security Class Initialized
INFO - 2023-06-23 10:35:16 --> Input Class Initialized
INFO - 2023-06-23 10:35:16 --> Language Class Initialized
INFO - 2023-06-23 10:35:16 --> Loader Class Initialized
INFO - 2023-06-23 10:35:16 --> Helper loaded: url_helper
INFO - 2023-06-23 10:35:16 --> Helper loaded: form_helper
INFO - 2023-06-23 10:35:16 --> Database Driver Class Initialized
INFO - 2023-06-23 10:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:35:16 --> Form Validation Class Initialized
INFO - 2023-06-23 10:35:16 --> Controller Class Initialized
INFO - 2023-06-23 10:35:16 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:35:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:35:16 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:35:16 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:35:16 --> Final output sent to browser
INFO - 2023-06-23 10:37:00 --> Config Class Initialized
INFO - 2023-06-23 10:37:00 --> Hooks Class Initialized
INFO - 2023-06-23 10:37:00 --> Utf8 Class Initialized
INFO - 2023-06-23 10:37:00 --> URI Class Initialized
INFO - 2023-06-23 10:37:00 --> Router Class Initialized
INFO - 2023-06-23 10:37:00 --> Output Class Initialized
INFO - 2023-06-23 10:37:00 --> Security Class Initialized
INFO - 2023-06-23 10:37:00 --> Input Class Initialized
INFO - 2023-06-23 10:37:00 --> Language Class Initialized
INFO - 2023-06-23 10:37:00 --> Loader Class Initialized
INFO - 2023-06-23 10:37:00 --> Helper loaded: url_helper
INFO - 2023-06-23 10:37:00 --> Helper loaded: form_helper
INFO - 2023-06-23 10:37:00 --> Database Driver Class Initialized
INFO - 2023-06-23 10:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:37:00 --> Form Validation Class Initialized
INFO - 2023-06-23 10:37:00 --> Controller Class Initialized
INFO - 2023-06-23 10:37:00 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:37:00 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:37:00 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:37:00 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:37:00 --> Final output sent to browser
INFO - 2023-06-23 10:37:37 --> Config Class Initialized
INFO - 2023-06-23 10:37:37 --> Hooks Class Initialized
INFO - 2023-06-23 10:37:37 --> Utf8 Class Initialized
INFO - 2023-06-23 10:37:37 --> URI Class Initialized
INFO - 2023-06-23 10:37:37 --> Router Class Initialized
INFO - 2023-06-23 10:37:37 --> Output Class Initialized
INFO - 2023-06-23 10:37:37 --> Security Class Initialized
INFO - 2023-06-23 10:37:37 --> Input Class Initialized
INFO - 2023-06-23 10:37:37 --> Language Class Initialized
INFO - 2023-06-23 10:37:37 --> Loader Class Initialized
INFO - 2023-06-23 10:37:37 --> Helper loaded: url_helper
INFO - 2023-06-23 10:37:37 --> Helper loaded: form_helper
INFO - 2023-06-23 10:37:37 --> Database Driver Class Initialized
INFO - 2023-06-23 10:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:37:37 --> Form Validation Class Initialized
INFO - 2023-06-23 10:37:37 --> Controller Class Initialized
INFO - 2023-06-23 10:37:37 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:37:37 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:37:37 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:37:37 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:37:37 --> Final output sent to browser
INFO - 2023-06-23 10:38:33 --> Config Class Initialized
INFO - 2023-06-23 10:38:33 --> Hooks Class Initialized
INFO - 2023-06-23 10:38:33 --> Utf8 Class Initialized
INFO - 2023-06-23 10:38:33 --> URI Class Initialized
INFO - 2023-06-23 10:38:33 --> Router Class Initialized
INFO - 2023-06-23 10:38:33 --> Output Class Initialized
INFO - 2023-06-23 10:38:33 --> Security Class Initialized
INFO - 2023-06-23 10:38:33 --> Input Class Initialized
INFO - 2023-06-23 10:38:33 --> Language Class Initialized
INFO - 2023-06-23 10:38:33 --> Loader Class Initialized
INFO - 2023-06-23 10:38:33 --> Helper loaded: url_helper
INFO - 2023-06-23 10:38:33 --> Helper loaded: form_helper
INFO - 2023-06-23 10:38:33 --> Database Driver Class Initialized
INFO - 2023-06-23 10:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:38:33 --> Form Validation Class Initialized
INFO - 2023-06-23 10:38:33 --> Controller Class Initialized
INFO - 2023-06-23 10:38:33 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:38:33 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:38:33 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:38:33 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:38:33 --> Final output sent to browser
INFO - 2023-06-23 10:41:27 --> Config Class Initialized
INFO - 2023-06-23 10:41:27 --> Hooks Class Initialized
INFO - 2023-06-23 10:41:27 --> Utf8 Class Initialized
INFO - 2023-06-23 10:41:27 --> URI Class Initialized
INFO - 2023-06-23 10:41:27 --> Router Class Initialized
INFO - 2023-06-23 10:41:27 --> Output Class Initialized
INFO - 2023-06-23 10:41:27 --> Security Class Initialized
INFO - 2023-06-23 10:41:27 --> Input Class Initialized
INFO - 2023-06-23 10:41:27 --> Language Class Initialized
INFO - 2023-06-23 10:41:27 --> Loader Class Initialized
INFO - 2023-06-23 10:41:27 --> Helper loaded: url_helper
INFO - 2023-06-23 10:41:27 --> Helper loaded: form_helper
INFO - 2023-06-23 10:41:27 --> Database Driver Class Initialized
INFO - 2023-06-23 10:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:41:27 --> Form Validation Class Initialized
INFO - 2023-06-23 10:41:27 --> Controller Class Initialized
INFO - 2023-06-23 10:41:27 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:41:27 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:41:27 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:41:27 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:41:27 --> Final output sent to browser
INFO - 2023-06-23 10:42:06 --> Config Class Initialized
INFO - 2023-06-23 10:42:06 --> Hooks Class Initialized
INFO - 2023-06-23 10:42:06 --> Utf8 Class Initialized
INFO - 2023-06-23 10:42:06 --> URI Class Initialized
INFO - 2023-06-23 10:42:06 --> Router Class Initialized
INFO - 2023-06-23 10:42:06 --> Output Class Initialized
INFO - 2023-06-23 10:42:06 --> Security Class Initialized
INFO - 2023-06-23 10:42:06 --> Input Class Initialized
INFO - 2023-06-23 10:42:06 --> Language Class Initialized
INFO - 2023-06-23 10:42:06 --> Loader Class Initialized
INFO - 2023-06-23 10:42:06 --> Helper loaded: url_helper
INFO - 2023-06-23 10:42:06 --> Helper loaded: form_helper
INFO - 2023-06-23 10:42:06 --> Database Driver Class Initialized
INFO - 2023-06-23 10:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:42:06 --> Form Validation Class Initialized
INFO - 2023-06-23 10:42:06 --> Controller Class Initialized
INFO - 2023-06-23 10:42:06 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:42:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:42:06 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:42:06 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:42:06 --> Final output sent to browser
INFO - 2023-06-23 10:42:40 --> Config Class Initialized
INFO - 2023-06-23 10:42:40 --> Hooks Class Initialized
INFO - 2023-06-23 10:42:40 --> Utf8 Class Initialized
INFO - 2023-06-23 10:42:40 --> URI Class Initialized
INFO - 2023-06-23 10:42:40 --> Router Class Initialized
INFO - 2023-06-23 10:42:40 --> Output Class Initialized
INFO - 2023-06-23 10:42:40 --> Security Class Initialized
INFO - 2023-06-23 10:42:40 --> Input Class Initialized
INFO - 2023-06-23 10:42:40 --> Language Class Initialized
INFO - 2023-06-23 10:42:40 --> Loader Class Initialized
INFO - 2023-06-23 10:42:40 --> Helper loaded: url_helper
INFO - 2023-06-23 10:42:40 --> Helper loaded: form_helper
INFO - 2023-06-23 10:42:40 --> Database Driver Class Initialized
INFO - 2023-06-23 10:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:42:40 --> Form Validation Class Initialized
INFO - 2023-06-23 10:42:40 --> Controller Class Initialized
INFO - 2023-06-23 10:42:40 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:42:40 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:42:40 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:42:40 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:42:40 --> Final output sent to browser
INFO - 2023-06-23 10:42:58 --> Config Class Initialized
INFO - 2023-06-23 10:42:58 --> Hooks Class Initialized
INFO - 2023-06-23 10:42:58 --> Utf8 Class Initialized
INFO - 2023-06-23 10:42:58 --> URI Class Initialized
INFO - 2023-06-23 10:42:58 --> Router Class Initialized
INFO - 2023-06-23 10:42:58 --> Output Class Initialized
INFO - 2023-06-23 10:42:58 --> Security Class Initialized
INFO - 2023-06-23 10:42:58 --> Input Class Initialized
INFO - 2023-06-23 10:42:58 --> Language Class Initialized
INFO - 2023-06-23 10:42:58 --> Loader Class Initialized
INFO - 2023-06-23 10:42:58 --> Helper loaded: url_helper
INFO - 2023-06-23 10:42:58 --> Helper loaded: form_helper
INFO - 2023-06-23 10:42:58 --> Database Driver Class Initialized
INFO - 2023-06-23 10:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:42:58 --> Form Validation Class Initialized
INFO - 2023-06-23 10:42:58 --> Controller Class Initialized
INFO - 2023-06-23 10:42:58 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:42:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:42:58 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:42:58 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:42:58 --> Final output sent to browser
INFO - 2023-06-23 10:43:15 --> Config Class Initialized
INFO - 2023-06-23 10:43:15 --> Hooks Class Initialized
INFO - 2023-06-23 10:43:15 --> Utf8 Class Initialized
INFO - 2023-06-23 10:43:15 --> URI Class Initialized
INFO - 2023-06-23 10:43:15 --> Router Class Initialized
INFO - 2023-06-23 10:43:15 --> Output Class Initialized
INFO - 2023-06-23 10:43:15 --> Security Class Initialized
INFO - 2023-06-23 10:43:15 --> Input Class Initialized
INFO - 2023-06-23 10:43:15 --> Language Class Initialized
INFO - 2023-06-23 10:43:15 --> Loader Class Initialized
INFO - 2023-06-23 10:43:15 --> Helper loaded: url_helper
INFO - 2023-06-23 10:43:15 --> Helper loaded: form_helper
INFO - 2023-06-23 10:43:15 --> Database Driver Class Initialized
INFO - 2023-06-23 10:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:43:15 --> Form Validation Class Initialized
INFO - 2023-06-23 10:43:15 --> Controller Class Initialized
INFO - 2023-06-23 10:43:15 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:43:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:43:15 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:43:15 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:43:15 --> Final output sent to browser
INFO - 2023-06-23 10:43:34 --> Config Class Initialized
INFO - 2023-06-23 10:43:34 --> Hooks Class Initialized
INFO - 2023-06-23 10:43:34 --> Utf8 Class Initialized
INFO - 2023-06-23 10:43:34 --> URI Class Initialized
INFO - 2023-06-23 10:43:34 --> Router Class Initialized
INFO - 2023-06-23 10:43:34 --> Output Class Initialized
INFO - 2023-06-23 10:43:34 --> Security Class Initialized
INFO - 2023-06-23 10:43:34 --> Input Class Initialized
INFO - 2023-06-23 10:43:34 --> Language Class Initialized
INFO - 2023-06-23 10:43:34 --> Loader Class Initialized
INFO - 2023-06-23 10:43:34 --> Helper loaded: url_helper
INFO - 2023-06-23 10:43:34 --> Helper loaded: form_helper
INFO - 2023-06-23 10:43:34 --> Database Driver Class Initialized
INFO - 2023-06-23 10:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:43:34 --> Form Validation Class Initialized
INFO - 2023-06-23 10:43:34 --> Controller Class Initialized
INFO - 2023-06-23 10:43:34 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:43:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:43:34 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:43:34 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:43:34 --> Final output sent to browser
INFO - 2023-06-23 10:43:54 --> Config Class Initialized
INFO - 2023-06-23 10:43:54 --> Hooks Class Initialized
INFO - 2023-06-23 10:43:54 --> Utf8 Class Initialized
INFO - 2023-06-23 10:43:54 --> URI Class Initialized
INFO - 2023-06-23 10:43:54 --> Router Class Initialized
INFO - 2023-06-23 10:43:54 --> Output Class Initialized
INFO - 2023-06-23 10:43:54 --> Security Class Initialized
INFO - 2023-06-23 10:43:54 --> Input Class Initialized
INFO - 2023-06-23 10:43:54 --> Language Class Initialized
INFO - 2023-06-23 10:43:54 --> Loader Class Initialized
INFO - 2023-06-23 10:43:54 --> Helper loaded: url_helper
INFO - 2023-06-23 10:43:54 --> Helper loaded: form_helper
INFO - 2023-06-23 10:43:55 --> Database Driver Class Initialized
INFO - 2023-06-23 10:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:43:55 --> Form Validation Class Initialized
INFO - 2023-06-23 10:43:55 --> Controller Class Initialized
INFO - 2023-06-23 10:43:55 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:43:55 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:43:55 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:43:55 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:43:55 --> Final output sent to browser
INFO - 2023-06-23 10:44:12 --> Config Class Initialized
INFO - 2023-06-23 10:44:12 --> Hooks Class Initialized
INFO - 2023-06-23 10:44:12 --> Utf8 Class Initialized
INFO - 2023-06-23 10:44:12 --> URI Class Initialized
INFO - 2023-06-23 10:44:12 --> Router Class Initialized
INFO - 2023-06-23 10:44:12 --> Output Class Initialized
INFO - 2023-06-23 10:44:12 --> Security Class Initialized
INFO - 2023-06-23 10:44:12 --> Input Class Initialized
INFO - 2023-06-23 10:44:12 --> Language Class Initialized
INFO - 2023-06-23 10:44:12 --> Loader Class Initialized
INFO - 2023-06-23 10:44:12 --> Helper loaded: url_helper
INFO - 2023-06-23 10:44:12 --> Helper loaded: form_helper
INFO - 2023-06-23 10:44:12 --> Database Driver Class Initialized
INFO - 2023-06-23 10:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:44:12 --> Form Validation Class Initialized
INFO - 2023-06-23 10:44:12 --> Controller Class Initialized
INFO - 2023-06-23 10:44:12 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:44:12 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:44:12 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:44:12 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:44:12 --> Final output sent to browser
INFO - 2023-06-23 10:45:47 --> Config Class Initialized
INFO - 2023-06-23 10:45:47 --> Hooks Class Initialized
INFO - 2023-06-23 10:45:47 --> Utf8 Class Initialized
INFO - 2023-06-23 10:45:47 --> URI Class Initialized
INFO - 2023-06-23 10:45:47 --> Router Class Initialized
INFO - 2023-06-23 10:45:47 --> Output Class Initialized
INFO - 2023-06-23 10:45:47 --> Security Class Initialized
INFO - 2023-06-23 10:45:47 --> Input Class Initialized
INFO - 2023-06-23 10:45:47 --> Language Class Initialized
INFO - 2023-06-23 10:45:47 --> Loader Class Initialized
INFO - 2023-06-23 10:45:47 --> Helper loaded: url_helper
INFO - 2023-06-23 10:45:47 --> Helper loaded: form_helper
INFO - 2023-06-23 10:45:47 --> Database Driver Class Initialized
INFO - 2023-06-23 10:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:45:47 --> Form Validation Class Initialized
INFO - 2023-06-23 10:45:47 --> Controller Class Initialized
INFO - 2023-06-23 10:45:47 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:45:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:45:47 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:45:47 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:45:47 --> Final output sent to browser
INFO - 2023-06-23 10:47:03 --> Config Class Initialized
INFO - 2023-06-23 10:47:03 --> Hooks Class Initialized
INFO - 2023-06-23 10:47:03 --> Utf8 Class Initialized
INFO - 2023-06-23 10:47:03 --> URI Class Initialized
INFO - 2023-06-23 10:47:03 --> Router Class Initialized
INFO - 2023-06-23 10:47:03 --> Output Class Initialized
INFO - 2023-06-23 10:47:03 --> Security Class Initialized
INFO - 2023-06-23 10:47:03 --> Input Class Initialized
INFO - 2023-06-23 10:47:03 --> Language Class Initialized
INFO - 2023-06-23 10:47:03 --> Loader Class Initialized
INFO - 2023-06-23 10:47:03 --> Helper loaded: url_helper
INFO - 2023-06-23 10:47:03 --> Helper loaded: form_helper
INFO - 2023-06-23 10:47:03 --> Database Driver Class Initialized
INFO - 2023-06-23 10:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:47:03 --> Form Validation Class Initialized
INFO - 2023-06-23 10:47:03 --> Controller Class Initialized
INFO - 2023-06-23 10:47:03 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:47:03 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:47:03 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:47:03 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:47:03 --> Final output sent to browser
INFO - 2023-06-23 10:51:16 --> Config Class Initialized
INFO - 2023-06-23 10:51:16 --> Hooks Class Initialized
INFO - 2023-06-23 10:51:16 --> Utf8 Class Initialized
INFO - 2023-06-23 10:51:16 --> URI Class Initialized
INFO - 2023-06-23 10:51:16 --> Router Class Initialized
INFO - 2023-06-23 10:51:16 --> Output Class Initialized
INFO - 2023-06-23 10:51:16 --> Security Class Initialized
INFO - 2023-06-23 10:51:16 --> Input Class Initialized
INFO - 2023-06-23 10:51:16 --> Language Class Initialized
INFO - 2023-06-23 10:51:16 --> Loader Class Initialized
INFO - 2023-06-23 10:51:16 --> Helper loaded: url_helper
INFO - 2023-06-23 10:51:16 --> Helper loaded: form_helper
INFO - 2023-06-23 10:51:16 --> Database Driver Class Initialized
INFO - 2023-06-23 10:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:51:16 --> Form Validation Class Initialized
INFO - 2023-06-23 10:51:16 --> Controller Class Initialized
INFO - 2023-06-23 10:51:16 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:51:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:51:16 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:51:16 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:51:16 --> Final output sent to browser
INFO - 2023-06-23 10:51:53 --> Config Class Initialized
INFO - 2023-06-23 10:51:53 --> Hooks Class Initialized
INFO - 2023-06-23 10:51:53 --> Utf8 Class Initialized
INFO - 2023-06-23 10:51:53 --> URI Class Initialized
INFO - 2023-06-23 10:51:53 --> Router Class Initialized
INFO - 2023-06-23 10:51:53 --> Output Class Initialized
INFO - 2023-06-23 10:51:53 --> Security Class Initialized
INFO - 2023-06-23 10:51:53 --> Input Class Initialized
INFO - 2023-06-23 10:51:53 --> Language Class Initialized
INFO - 2023-06-23 10:51:53 --> Loader Class Initialized
INFO - 2023-06-23 10:51:53 --> Helper loaded: url_helper
INFO - 2023-06-23 10:51:53 --> Helper loaded: form_helper
INFO - 2023-06-23 10:51:53 --> Database Driver Class Initialized
INFO - 2023-06-23 10:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:51:53 --> Form Validation Class Initialized
INFO - 2023-06-23 10:51:53 --> Controller Class Initialized
INFO - 2023-06-23 10:51:53 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:51:53 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:51:53 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:51:53 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:51:53 --> Final output sent to browser
INFO - 2023-06-23 10:53:03 --> Config Class Initialized
INFO - 2023-06-23 10:53:03 --> Hooks Class Initialized
INFO - 2023-06-23 10:53:03 --> Utf8 Class Initialized
INFO - 2023-06-23 10:53:03 --> URI Class Initialized
INFO - 2023-06-23 10:53:03 --> Router Class Initialized
INFO - 2023-06-23 10:53:03 --> Output Class Initialized
INFO - 2023-06-23 10:53:03 --> Security Class Initialized
INFO - 2023-06-23 10:53:03 --> Input Class Initialized
INFO - 2023-06-23 10:53:03 --> Language Class Initialized
INFO - 2023-06-23 10:53:03 --> Loader Class Initialized
INFO - 2023-06-23 10:53:03 --> Helper loaded: url_helper
INFO - 2023-06-23 10:53:03 --> Helper loaded: form_helper
INFO - 2023-06-23 10:53:03 --> Database Driver Class Initialized
INFO - 2023-06-23 10:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:53:03 --> Form Validation Class Initialized
INFO - 2023-06-23 10:53:03 --> Controller Class Initialized
INFO - 2023-06-23 10:53:03 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:53:03 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:53:03 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:53:03 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:53:03 --> Final output sent to browser
INFO - 2023-06-23 10:53:33 --> Config Class Initialized
INFO - 2023-06-23 10:53:33 --> Hooks Class Initialized
INFO - 2023-06-23 10:53:33 --> Utf8 Class Initialized
INFO - 2023-06-23 10:53:33 --> URI Class Initialized
INFO - 2023-06-23 10:53:33 --> Router Class Initialized
INFO - 2023-06-23 10:53:33 --> Output Class Initialized
INFO - 2023-06-23 10:53:33 --> Security Class Initialized
INFO - 2023-06-23 10:53:33 --> Input Class Initialized
INFO - 2023-06-23 10:53:33 --> Language Class Initialized
ERROR - 2023-06-23 10:53:33 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2035
INFO - 2023-06-23 10:53:47 --> Config Class Initialized
INFO - 2023-06-23 10:53:47 --> Hooks Class Initialized
INFO - 2023-06-23 10:53:47 --> Utf8 Class Initialized
INFO - 2023-06-23 10:53:47 --> URI Class Initialized
INFO - 2023-06-23 10:53:47 --> Router Class Initialized
INFO - 2023-06-23 10:53:47 --> Output Class Initialized
INFO - 2023-06-23 10:53:47 --> Security Class Initialized
INFO - 2023-06-23 10:53:47 --> Input Class Initialized
INFO - 2023-06-23 10:53:47 --> Language Class Initialized
INFO - 2023-06-23 10:53:47 --> Loader Class Initialized
INFO - 2023-06-23 10:53:47 --> Helper loaded: url_helper
INFO - 2023-06-23 10:53:47 --> Helper loaded: form_helper
INFO - 2023-06-23 10:53:47 --> Database Driver Class Initialized
INFO - 2023-06-23 10:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:53:47 --> Form Validation Class Initialized
INFO - 2023-06-23 10:53:47 --> Controller Class Initialized
INFO - 2023-06-23 10:53:47 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:53:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:53:47 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:53:47 --> Model "M_solusi" initialized
ERROR - 2023-06-23 10:53:47 --> Severity: Notice --> Undefined variable: prob_Berat_percen C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2034
INFO - 2023-06-23 10:53:47 --> Final output sent to browser
INFO - 2023-06-23 10:53:58 --> Config Class Initialized
INFO - 2023-06-23 10:53:58 --> Hooks Class Initialized
INFO - 2023-06-23 10:53:58 --> Utf8 Class Initialized
INFO - 2023-06-23 10:53:58 --> URI Class Initialized
INFO - 2023-06-23 10:53:58 --> Router Class Initialized
INFO - 2023-06-23 10:53:58 --> Output Class Initialized
INFO - 2023-06-23 10:53:58 --> Security Class Initialized
INFO - 2023-06-23 10:53:59 --> Input Class Initialized
INFO - 2023-06-23 10:53:59 --> Language Class Initialized
INFO - 2023-06-23 10:53:59 --> Loader Class Initialized
INFO - 2023-06-23 10:53:59 --> Helper loaded: url_helper
INFO - 2023-06-23 10:53:59 --> Helper loaded: form_helper
INFO - 2023-06-23 10:53:59 --> Database Driver Class Initialized
INFO - 2023-06-23 10:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:53:59 --> Form Validation Class Initialized
INFO - 2023-06-23 10:53:59 --> Controller Class Initialized
INFO - 2023-06-23 10:53:59 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:53:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:53:59 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:53:59 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:53:59 --> Final output sent to browser
INFO - 2023-06-23 10:55:26 --> Config Class Initialized
INFO - 2023-06-23 10:55:26 --> Hooks Class Initialized
INFO - 2023-06-23 10:55:26 --> Utf8 Class Initialized
INFO - 2023-06-23 10:55:26 --> URI Class Initialized
INFO - 2023-06-23 10:55:26 --> Router Class Initialized
INFO - 2023-06-23 10:55:26 --> Output Class Initialized
INFO - 2023-06-23 10:55:26 --> Security Class Initialized
INFO - 2023-06-23 10:55:26 --> Input Class Initialized
INFO - 2023-06-23 10:55:26 --> Language Class Initialized
INFO - 2023-06-23 10:55:26 --> Loader Class Initialized
INFO - 2023-06-23 10:55:26 --> Helper loaded: url_helper
INFO - 2023-06-23 10:55:26 --> Helper loaded: form_helper
INFO - 2023-06-23 10:55:26 --> Database Driver Class Initialized
INFO - 2023-06-23 10:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:55:26 --> Form Validation Class Initialized
INFO - 2023-06-23 10:55:26 --> Controller Class Initialized
INFO - 2023-06-23 10:55:26 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:55:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:55:26 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:55:26 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:55:26 --> Final output sent to browser
INFO - 2023-06-23 10:56:01 --> Config Class Initialized
INFO - 2023-06-23 10:56:01 --> Hooks Class Initialized
INFO - 2023-06-23 10:56:01 --> Utf8 Class Initialized
INFO - 2023-06-23 10:56:01 --> URI Class Initialized
INFO - 2023-06-23 10:56:01 --> Router Class Initialized
INFO - 2023-06-23 10:56:01 --> Output Class Initialized
INFO - 2023-06-23 10:56:01 --> Security Class Initialized
INFO - 2023-06-23 10:56:01 --> Input Class Initialized
INFO - 2023-06-23 10:56:01 --> Language Class Initialized
INFO - 2023-06-23 10:56:01 --> Loader Class Initialized
INFO - 2023-06-23 10:56:01 --> Helper loaded: url_helper
INFO - 2023-06-23 10:56:01 --> Helper loaded: form_helper
INFO - 2023-06-23 10:56:01 --> Database Driver Class Initialized
INFO - 2023-06-23 10:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:56:01 --> Form Validation Class Initialized
INFO - 2023-06-23 10:56:01 --> Controller Class Initialized
INFO - 2023-06-23 10:56:01 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:56:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:56:01 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:56:01 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:56:01 --> Final output sent to browser
INFO - 2023-06-23 10:56:38 --> Config Class Initialized
INFO - 2023-06-23 10:56:38 --> Hooks Class Initialized
INFO - 2023-06-23 10:56:38 --> Utf8 Class Initialized
INFO - 2023-06-23 10:56:38 --> URI Class Initialized
INFO - 2023-06-23 10:56:38 --> Router Class Initialized
INFO - 2023-06-23 10:56:38 --> Output Class Initialized
INFO - 2023-06-23 10:56:38 --> Security Class Initialized
INFO - 2023-06-23 10:56:38 --> Input Class Initialized
INFO - 2023-06-23 10:56:38 --> Language Class Initialized
INFO - 2023-06-23 10:56:38 --> Loader Class Initialized
INFO - 2023-06-23 10:56:38 --> Helper loaded: url_helper
INFO - 2023-06-23 10:56:38 --> Helper loaded: form_helper
INFO - 2023-06-23 10:56:38 --> Database Driver Class Initialized
INFO - 2023-06-23 10:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:56:38 --> Form Validation Class Initialized
INFO - 2023-06-23 10:56:38 --> Controller Class Initialized
INFO - 2023-06-23 10:56:38 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:56:38 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:56:38 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:56:38 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:56:39 --> Final output sent to browser
INFO - 2023-06-23 10:56:53 --> Config Class Initialized
INFO - 2023-06-23 10:56:53 --> Hooks Class Initialized
INFO - 2023-06-23 10:56:53 --> Utf8 Class Initialized
INFO - 2023-06-23 10:56:53 --> URI Class Initialized
INFO - 2023-06-23 10:56:53 --> Router Class Initialized
INFO - 2023-06-23 10:56:53 --> Output Class Initialized
INFO - 2023-06-23 10:56:53 --> Security Class Initialized
INFO - 2023-06-23 10:56:53 --> Input Class Initialized
INFO - 2023-06-23 10:56:53 --> Language Class Initialized
INFO - 2023-06-23 10:56:53 --> Loader Class Initialized
INFO - 2023-06-23 10:56:53 --> Helper loaded: url_helper
INFO - 2023-06-23 10:56:53 --> Helper loaded: form_helper
INFO - 2023-06-23 10:56:53 --> Database Driver Class Initialized
INFO - 2023-06-23 10:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:56:53 --> Form Validation Class Initialized
INFO - 2023-06-23 10:56:53 --> Controller Class Initialized
INFO - 2023-06-23 10:56:54 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:56:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:56:54 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:56:54 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:56:54 --> Final output sent to browser
INFO - 2023-06-23 10:57:01 --> Config Class Initialized
INFO - 2023-06-23 10:57:01 --> Hooks Class Initialized
INFO - 2023-06-23 10:57:01 --> Utf8 Class Initialized
INFO - 2023-06-23 10:57:01 --> URI Class Initialized
INFO - 2023-06-23 10:57:01 --> Router Class Initialized
INFO - 2023-06-23 10:57:01 --> Output Class Initialized
INFO - 2023-06-23 10:57:01 --> Security Class Initialized
INFO - 2023-06-23 10:57:01 --> Input Class Initialized
INFO - 2023-06-23 10:57:01 --> Language Class Initialized
INFO - 2023-06-23 10:57:01 --> Loader Class Initialized
INFO - 2023-06-23 10:57:01 --> Helper loaded: url_helper
INFO - 2023-06-23 10:57:01 --> Helper loaded: form_helper
INFO - 2023-06-23 10:57:01 --> Database Driver Class Initialized
INFO - 2023-06-23 10:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:57:01 --> Form Validation Class Initialized
INFO - 2023-06-23 10:57:01 --> Controller Class Initialized
INFO - 2023-06-23 10:57:01 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:57:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:57:01 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:57:01 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:57:02 --> Final output sent to browser
INFO - 2023-06-23 10:57:13 --> Config Class Initialized
INFO - 2023-06-23 10:57:13 --> Hooks Class Initialized
INFO - 2023-06-23 10:57:13 --> Utf8 Class Initialized
INFO - 2023-06-23 10:57:13 --> URI Class Initialized
INFO - 2023-06-23 10:57:13 --> Router Class Initialized
INFO - 2023-06-23 10:57:13 --> Output Class Initialized
INFO - 2023-06-23 10:57:13 --> Security Class Initialized
INFO - 2023-06-23 10:57:13 --> Input Class Initialized
INFO - 2023-06-23 10:57:13 --> Language Class Initialized
INFO - 2023-06-23 10:57:13 --> Loader Class Initialized
INFO - 2023-06-23 10:57:13 --> Helper loaded: url_helper
INFO - 2023-06-23 10:57:13 --> Helper loaded: form_helper
INFO - 2023-06-23 10:57:13 --> Database Driver Class Initialized
INFO - 2023-06-23 10:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:57:13 --> Form Validation Class Initialized
INFO - 2023-06-23 10:57:13 --> Controller Class Initialized
INFO - 2023-06-23 10:57:13 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:57:13 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:57:13 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:57:13 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:57:13 --> Final output sent to browser
INFO - 2023-06-23 10:57:49 --> Config Class Initialized
INFO - 2023-06-23 10:57:49 --> Hooks Class Initialized
INFO - 2023-06-23 10:57:49 --> Utf8 Class Initialized
INFO - 2023-06-23 10:57:49 --> URI Class Initialized
INFO - 2023-06-23 10:57:49 --> Router Class Initialized
INFO - 2023-06-23 10:57:49 --> Output Class Initialized
INFO - 2023-06-23 10:57:49 --> Security Class Initialized
INFO - 2023-06-23 10:57:49 --> Input Class Initialized
INFO - 2023-06-23 10:57:49 --> Language Class Initialized
INFO - 2023-06-23 10:57:49 --> Loader Class Initialized
INFO - 2023-06-23 10:57:49 --> Helper loaded: url_helper
INFO - 2023-06-23 10:57:49 --> Helper loaded: form_helper
INFO - 2023-06-23 10:57:49 --> Database Driver Class Initialized
INFO - 2023-06-23 10:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:57:49 --> Form Validation Class Initialized
INFO - 2023-06-23 10:57:49 --> Controller Class Initialized
INFO - 2023-06-23 10:57:49 --> Model "m_datatrain" initialized
INFO - 2023-06-23 10:57:49 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 10:57:50 --> Model "m_datatest" initialized
INFO - 2023-06-23 10:57:50 --> Model "M_solusi" initialized
INFO - 2023-06-23 10:57:50 --> Final output sent to browser
INFO - 2023-06-23 11:02:26 --> Config Class Initialized
INFO - 2023-06-23 11:02:26 --> Hooks Class Initialized
INFO - 2023-06-23 11:02:26 --> Utf8 Class Initialized
INFO - 2023-06-23 11:02:26 --> URI Class Initialized
INFO - 2023-06-23 11:02:26 --> Router Class Initialized
INFO - 2023-06-23 11:02:26 --> Output Class Initialized
INFO - 2023-06-23 11:02:26 --> Security Class Initialized
INFO - 2023-06-23 11:02:26 --> Input Class Initialized
INFO - 2023-06-23 11:02:26 --> Language Class Initialized
INFO - 2023-06-23 11:02:27 --> Loader Class Initialized
INFO - 2023-06-23 11:02:27 --> Helper loaded: url_helper
INFO - 2023-06-23 11:02:27 --> Helper loaded: form_helper
INFO - 2023-06-23 11:02:27 --> Database Driver Class Initialized
INFO - 2023-06-23 11:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:02:27 --> Form Validation Class Initialized
INFO - 2023-06-23 11:02:27 --> Controller Class Initialized
INFO - 2023-06-23 11:02:27 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:02:27 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:02:27 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:02:27 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:02:27 --> Final output sent to browser
INFO - 2023-06-23 11:02:55 --> Config Class Initialized
INFO - 2023-06-23 11:02:55 --> Hooks Class Initialized
INFO - 2023-06-23 11:02:55 --> Utf8 Class Initialized
INFO - 2023-06-23 11:02:55 --> URI Class Initialized
INFO - 2023-06-23 11:02:55 --> Router Class Initialized
INFO - 2023-06-23 11:02:55 --> Output Class Initialized
INFO - 2023-06-23 11:02:55 --> Security Class Initialized
INFO - 2023-06-23 11:02:55 --> Input Class Initialized
INFO - 2023-06-23 11:02:55 --> Language Class Initialized
INFO - 2023-06-23 11:02:55 --> Loader Class Initialized
INFO - 2023-06-23 11:02:55 --> Helper loaded: url_helper
INFO - 2023-06-23 11:02:55 --> Helper loaded: form_helper
INFO - 2023-06-23 11:02:55 --> Database Driver Class Initialized
INFO - 2023-06-23 11:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:02:55 --> Form Validation Class Initialized
INFO - 2023-06-23 11:02:55 --> Controller Class Initialized
INFO - 2023-06-23 11:02:55 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:02:55 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:02:55 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:02:55 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:02:55 --> Final output sent to browser
INFO - 2023-06-23 11:03:50 --> Config Class Initialized
INFO - 2023-06-23 11:03:50 --> Hooks Class Initialized
INFO - 2023-06-23 11:03:50 --> Utf8 Class Initialized
INFO - 2023-06-23 11:03:50 --> URI Class Initialized
INFO - 2023-06-23 11:03:50 --> Router Class Initialized
INFO - 2023-06-23 11:03:50 --> Output Class Initialized
INFO - 2023-06-23 11:03:50 --> Security Class Initialized
INFO - 2023-06-23 11:03:50 --> Input Class Initialized
INFO - 2023-06-23 11:03:50 --> Language Class Initialized
ERROR - 2023-06-23 11:03:50 --> Severity: Parsing Error --> syntax error, unexpected '$format_jumlah' (T_VARIABLE) C:\xampp\htdocs\sistemdepresi\application\controllers\C_diagnosa.php 2088
INFO - 2023-06-23 11:03:58 --> Config Class Initialized
INFO - 2023-06-23 11:03:58 --> Hooks Class Initialized
INFO - 2023-06-23 11:03:58 --> Utf8 Class Initialized
INFO - 2023-06-23 11:03:58 --> URI Class Initialized
INFO - 2023-06-23 11:03:58 --> Router Class Initialized
INFO - 2023-06-23 11:03:58 --> Output Class Initialized
INFO - 2023-06-23 11:03:58 --> Security Class Initialized
INFO - 2023-06-23 11:03:58 --> Input Class Initialized
INFO - 2023-06-23 11:03:58 --> Language Class Initialized
INFO - 2023-06-23 11:03:58 --> Loader Class Initialized
INFO - 2023-06-23 11:03:58 --> Helper loaded: url_helper
INFO - 2023-06-23 11:03:58 --> Helper loaded: form_helper
INFO - 2023-06-23 11:03:58 --> Database Driver Class Initialized
INFO - 2023-06-23 11:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:03:58 --> Form Validation Class Initialized
INFO - 2023-06-23 11:03:58 --> Controller Class Initialized
INFO - 2023-06-23 11:03:58 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:03:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:03:58 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:03:58 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:03:58 --> Final output sent to browser
INFO - 2023-06-23 11:04:16 --> Config Class Initialized
INFO - 2023-06-23 11:04:16 --> Hooks Class Initialized
INFO - 2023-06-23 11:04:16 --> Utf8 Class Initialized
INFO - 2023-06-23 11:04:16 --> URI Class Initialized
INFO - 2023-06-23 11:04:16 --> Router Class Initialized
INFO - 2023-06-23 11:04:16 --> Output Class Initialized
INFO - 2023-06-23 11:04:16 --> Security Class Initialized
INFO - 2023-06-23 11:04:16 --> Input Class Initialized
INFO - 2023-06-23 11:04:16 --> Language Class Initialized
INFO - 2023-06-23 11:04:16 --> Loader Class Initialized
INFO - 2023-06-23 11:04:16 --> Helper loaded: url_helper
INFO - 2023-06-23 11:04:16 --> Helper loaded: form_helper
INFO - 2023-06-23 11:04:16 --> Database Driver Class Initialized
INFO - 2023-06-23 11:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:04:16 --> Form Validation Class Initialized
INFO - 2023-06-23 11:04:16 --> Controller Class Initialized
INFO - 2023-06-23 11:04:16 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:04:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:04:16 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:04:16 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:04:16 --> Final output sent to browser
INFO - 2023-06-23 11:04:18 --> Config Class Initialized
INFO - 2023-06-23 11:04:18 --> Hooks Class Initialized
INFO - 2023-06-23 11:04:18 --> Utf8 Class Initialized
INFO - 2023-06-23 11:04:18 --> URI Class Initialized
INFO - 2023-06-23 11:04:18 --> Router Class Initialized
INFO - 2023-06-23 11:04:18 --> Output Class Initialized
INFO - 2023-06-23 11:04:18 --> Security Class Initialized
INFO - 2023-06-23 11:04:18 --> Input Class Initialized
INFO - 2023-06-23 11:04:18 --> Language Class Initialized
INFO - 2023-06-23 11:04:18 --> Loader Class Initialized
INFO - 2023-06-23 11:04:18 --> Helper loaded: url_helper
INFO - 2023-06-23 11:04:18 --> Helper loaded: form_helper
INFO - 2023-06-23 11:04:18 --> Database Driver Class Initialized
INFO - 2023-06-23 11:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:04:18 --> Form Validation Class Initialized
INFO - 2023-06-23 11:04:18 --> Controller Class Initialized
INFO - 2023-06-23 11:04:18 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:04:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:04:18 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:04:18 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:04:18 --> Final output sent to browser
INFO - 2023-06-23 11:04:52 --> Config Class Initialized
INFO - 2023-06-23 11:04:52 --> Hooks Class Initialized
INFO - 2023-06-23 11:04:52 --> Utf8 Class Initialized
INFO - 2023-06-23 11:04:52 --> URI Class Initialized
INFO - 2023-06-23 11:04:52 --> Router Class Initialized
INFO - 2023-06-23 11:04:52 --> Output Class Initialized
INFO - 2023-06-23 11:04:52 --> Security Class Initialized
INFO - 2023-06-23 11:04:52 --> Input Class Initialized
INFO - 2023-06-23 11:04:52 --> Language Class Initialized
INFO - 2023-06-23 11:04:52 --> Loader Class Initialized
INFO - 2023-06-23 11:04:52 --> Helper loaded: url_helper
INFO - 2023-06-23 11:04:52 --> Helper loaded: form_helper
INFO - 2023-06-23 11:04:52 --> Database Driver Class Initialized
INFO - 2023-06-23 11:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:04:52 --> Form Validation Class Initialized
INFO - 2023-06-23 11:04:52 --> Controller Class Initialized
INFO - 2023-06-23 11:04:52 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:04:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:04:52 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:04:52 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:04:52 --> Final output sent to browser
INFO - 2023-06-23 11:05:51 --> Config Class Initialized
INFO - 2023-06-23 11:05:51 --> Hooks Class Initialized
INFO - 2023-06-23 11:05:51 --> Utf8 Class Initialized
INFO - 2023-06-23 11:05:51 --> URI Class Initialized
INFO - 2023-06-23 11:05:51 --> Router Class Initialized
INFO - 2023-06-23 11:05:51 --> Output Class Initialized
INFO - 2023-06-23 11:05:51 --> Security Class Initialized
INFO - 2023-06-23 11:05:51 --> Input Class Initialized
INFO - 2023-06-23 11:05:51 --> Language Class Initialized
ERROR - 2023-06-23 11:05:51 --> 404 Page Not Found: C_diagnosa/cek
INFO - 2023-06-23 11:05:54 --> Config Class Initialized
INFO - 2023-06-23 11:05:54 --> Hooks Class Initialized
INFO - 2023-06-23 11:05:54 --> Utf8 Class Initialized
INFO - 2023-06-23 11:05:54 --> URI Class Initialized
INFO - 2023-06-23 11:05:54 --> Router Class Initialized
INFO - 2023-06-23 11:05:54 --> Output Class Initialized
INFO - 2023-06-23 11:05:54 --> Security Class Initialized
INFO - 2023-06-23 11:05:54 --> Input Class Initialized
INFO - 2023-06-23 11:05:54 --> Language Class Initialized
INFO - 2023-06-23 11:05:54 --> Loader Class Initialized
INFO - 2023-06-23 11:05:54 --> Helper loaded: url_helper
INFO - 2023-06-23 11:05:54 --> Helper loaded: form_helper
INFO - 2023-06-23 11:05:54 --> Database Driver Class Initialized
INFO - 2023-06-23 11:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:05:54 --> Form Validation Class Initialized
INFO - 2023-06-23 11:05:54 --> Controller Class Initialized
INFO - 2023-06-23 11:05:54 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:05:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:05:54 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:05:54 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:05:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:05:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 11:05:55 --> Severity: Notice --> Undefined variable: prob_GangguanMood_percent C:\xampp\htdocs\sistemdepresi\application\views\diagnosa\V_hasil.php 23
INFO - 2023-06-23 11:05:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:05:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:05:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:05:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:05:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:05:55 --> Final output sent to browser
INFO - 2023-06-23 11:07:06 --> Config Class Initialized
INFO - 2023-06-23 11:07:06 --> Hooks Class Initialized
INFO - 2023-06-23 11:07:06 --> Utf8 Class Initialized
INFO - 2023-06-23 11:07:06 --> URI Class Initialized
INFO - 2023-06-23 11:07:06 --> Router Class Initialized
INFO - 2023-06-23 11:07:06 --> Output Class Initialized
INFO - 2023-06-23 11:07:06 --> Security Class Initialized
INFO - 2023-06-23 11:07:06 --> Input Class Initialized
INFO - 2023-06-23 11:07:06 --> Language Class Initialized
INFO - 2023-06-23 11:07:06 --> Loader Class Initialized
INFO - 2023-06-23 11:07:06 --> Helper loaded: url_helper
INFO - 2023-06-23 11:07:06 --> Helper loaded: form_helper
INFO - 2023-06-23 11:07:06 --> Database Driver Class Initialized
INFO - 2023-06-23 11:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:07:06 --> Form Validation Class Initialized
INFO - 2023-06-23 11:07:06 --> Controller Class Initialized
INFO - 2023-06-23 11:07:06 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:07:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:07:06 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:07:06 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:07:06 --> Final output sent to browser
INFO - 2023-06-23 11:14:18 --> Config Class Initialized
INFO - 2023-06-23 11:14:18 --> Hooks Class Initialized
INFO - 2023-06-23 11:14:18 --> Utf8 Class Initialized
INFO - 2023-06-23 11:14:18 --> URI Class Initialized
INFO - 2023-06-23 11:14:18 --> Router Class Initialized
INFO - 2023-06-23 11:14:18 --> Output Class Initialized
INFO - 2023-06-23 11:14:18 --> Security Class Initialized
INFO - 2023-06-23 11:14:18 --> Input Class Initialized
INFO - 2023-06-23 11:14:18 --> Language Class Initialized
INFO - 2023-06-23 11:14:18 --> Loader Class Initialized
INFO - 2023-06-23 11:14:18 --> Helper loaded: url_helper
INFO - 2023-06-23 11:14:18 --> Helper loaded: form_helper
INFO - 2023-06-23 11:14:18 --> Database Driver Class Initialized
INFO - 2023-06-23 11:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:14:18 --> Form Validation Class Initialized
INFO - 2023-06-23 11:14:18 --> Controller Class Initialized
INFO - 2023-06-23 11:14:18 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:14:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:14:18 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:14:18 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:14:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:14:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 11:14:18 --> Severity: Notice --> Undefined variable: prob_GangguanMood C:\xampp\htdocs\sistemdepresi\application\views\diagnosa\V_hasil.php 23
ERROR - 2023-06-23 11:14:18 --> Severity: Notice --> Undefined variable: prob_Ringan C:\xampp\htdocs\sistemdepresi\application\views\diagnosa\V_hasil.php 24
ERROR - 2023-06-23 11:14:18 --> Severity: Notice --> Undefined variable: prob_Sedang C:\xampp\htdocs\sistemdepresi\application\views\diagnosa\V_hasil.php 25
ERROR - 2023-06-23 11:14:18 --> Severity: Notice --> Undefined variable: prob_Berat C:\xampp\htdocs\sistemdepresi\application\views\diagnosa\V_hasil.php 26
INFO - 2023-06-23 11:14:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:14:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:14:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:14:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:14:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:14:18 --> Final output sent to browser
INFO - 2023-06-23 11:14:45 --> Config Class Initialized
INFO - 2023-06-23 11:14:45 --> Hooks Class Initialized
INFO - 2023-06-23 11:14:45 --> Utf8 Class Initialized
INFO - 2023-06-23 11:14:45 --> URI Class Initialized
INFO - 2023-06-23 11:14:45 --> Router Class Initialized
INFO - 2023-06-23 11:14:45 --> Output Class Initialized
INFO - 2023-06-23 11:14:45 --> Security Class Initialized
INFO - 2023-06-23 11:14:45 --> Input Class Initialized
INFO - 2023-06-23 11:14:45 --> Language Class Initialized
INFO - 2023-06-23 11:14:45 --> Loader Class Initialized
INFO - 2023-06-23 11:14:45 --> Helper loaded: url_helper
INFO - 2023-06-23 11:14:45 --> Helper loaded: form_helper
INFO - 2023-06-23 11:14:45 --> Database Driver Class Initialized
INFO - 2023-06-23 11:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:14:45 --> Form Validation Class Initialized
INFO - 2023-06-23 11:14:45 --> Controller Class Initialized
INFO - 2023-06-23 11:14:45 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:14:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:14:45 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:14:45 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:14:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:14:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:14:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:14:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:14:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:14:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:14:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:14:46 --> Final output sent to browser
INFO - 2023-06-23 11:16:06 --> Config Class Initialized
INFO - 2023-06-23 11:16:06 --> Hooks Class Initialized
INFO - 2023-06-23 11:16:06 --> Utf8 Class Initialized
INFO - 2023-06-23 11:16:06 --> URI Class Initialized
INFO - 2023-06-23 11:16:06 --> Router Class Initialized
INFO - 2023-06-23 11:16:06 --> Output Class Initialized
INFO - 2023-06-23 11:16:06 --> Security Class Initialized
INFO - 2023-06-23 11:16:06 --> Input Class Initialized
INFO - 2023-06-23 11:16:06 --> Language Class Initialized
INFO - 2023-06-23 11:16:06 --> Loader Class Initialized
INFO - 2023-06-23 11:16:06 --> Helper loaded: url_helper
INFO - 2023-06-23 11:16:06 --> Helper loaded: form_helper
INFO - 2023-06-23 11:16:06 --> Database Driver Class Initialized
INFO - 2023-06-23 11:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:16:06 --> Form Validation Class Initialized
INFO - 2023-06-23 11:16:06 --> Controller Class Initialized
INFO - 2023-06-23 11:16:06 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:16:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:16:06 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:16:06 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:16:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:16:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:16:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-23 11:16:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:16:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:16:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:16:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:16:06 --> Final output sent to browser
INFO - 2023-06-23 11:16:59 --> Config Class Initialized
INFO - 2023-06-23 11:16:59 --> Hooks Class Initialized
INFO - 2023-06-23 11:16:59 --> Utf8 Class Initialized
INFO - 2023-06-23 11:16:59 --> URI Class Initialized
INFO - 2023-06-23 11:16:59 --> Router Class Initialized
INFO - 2023-06-23 11:16:59 --> Output Class Initialized
INFO - 2023-06-23 11:16:59 --> Security Class Initialized
INFO - 2023-06-23 11:16:59 --> Input Class Initialized
INFO - 2023-06-23 11:16:59 --> Language Class Initialized
INFO - 2023-06-23 11:16:59 --> Loader Class Initialized
INFO - 2023-06-23 11:16:59 --> Helper loaded: url_helper
INFO - 2023-06-23 11:16:59 --> Helper loaded: form_helper
INFO - 2023-06-23 11:16:59 --> Database Driver Class Initialized
INFO - 2023-06-23 11:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:16:59 --> Form Validation Class Initialized
INFO - 2023-06-23 11:16:59 --> Controller Class Initialized
INFO - 2023-06-23 11:16:59 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:16:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:16:59 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:16:59 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:16:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:16:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:16:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:16:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:16:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:16:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:16:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:16:59 --> Final output sent to browser
INFO - 2023-06-23 11:17:18 --> Config Class Initialized
INFO - 2023-06-23 11:17:18 --> Hooks Class Initialized
INFO - 2023-06-23 11:17:18 --> Utf8 Class Initialized
INFO - 2023-06-23 11:17:18 --> URI Class Initialized
INFO - 2023-06-23 11:17:18 --> Router Class Initialized
INFO - 2023-06-23 11:17:18 --> Output Class Initialized
INFO - 2023-06-23 11:17:18 --> Security Class Initialized
INFO - 2023-06-23 11:17:18 --> Input Class Initialized
INFO - 2023-06-23 11:17:18 --> Language Class Initialized
INFO - 2023-06-23 11:17:18 --> Loader Class Initialized
INFO - 2023-06-23 11:17:18 --> Helper loaded: url_helper
INFO - 2023-06-23 11:17:18 --> Helper loaded: form_helper
INFO - 2023-06-23 11:17:18 --> Database Driver Class Initialized
INFO - 2023-06-23 11:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:17:18 --> Form Validation Class Initialized
INFO - 2023-06-23 11:17:18 --> Controller Class Initialized
INFO - 2023-06-23 11:17:18 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:17:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:17:18 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:17:18 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:17:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:17:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:17:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-23 11:17:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:17:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:17:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:17:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:17:18 --> Final output sent to browser
INFO - 2023-06-23 11:18:11 --> Config Class Initialized
INFO - 2023-06-23 11:18:11 --> Hooks Class Initialized
INFO - 2023-06-23 11:18:11 --> Utf8 Class Initialized
INFO - 2023-06-23 11:18:11 --> URI Class Initialized
INFO - 2023-06-23 11:18:11 --> Router Class Initialized
INFO - 2023-06-23 11:18:11 --> Output Class Initialized
INFO - 2023-06-23 11:18:11 --> Security Class Initialized
INFO - 2023-06-23 11:18:11 --> Input Class Initialized
INFO - 2023-06-23 11:18:11 --> Language Class Initialized
INFO - 2023-06-23 11:18:11 --> Loader Class Initialized
INFO - 2023-06-23 11:18:11 --> Helper loaded: url_helper
INFO - 2023-06-23 11:18:11 --> Helper loaded: form_helper
INFO - 2023-06-23 11:18:11 --> Database Driver Class Initialized
INFO - 2023-06-23 11:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:18:11 --> Form Validation Class Initialized
INFO - 2023-06-23 11:18:11 --> Controller Class Initialized
INFO - 2023-06-23 11:18:11 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:18:11 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:18:11 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:18:11 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:18:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:18:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:18:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:18:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:18:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:18:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:18:11 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:18:11 --> Final output sent to browser
INFO - 2023-06-23 11:18:30 --> Config Class Initialized
INFO - 2023-06-23 11:18:30 --> Hooks Class Initialized
INFO - 2023-06-23 11:18:30 --> Utf8 Class Initialized
INFO - 2023-06-23 11:18:30 --> URI Class Initialized
INFO - 2023-06-23 11:18:30 --> Router Class Initialized
INFO - 2023-06-23 11:18:30 --> Output Class Initialized
INFO - 2023-06-23 11:18:30 --> Security Class Initialized
INFO - 2023-06-23 11:18:30 --> Input Class Initialized
INFO - 2023-06-23 11:18:30 --> Language Class Initialized
INFO - 2023-06-23 11:18:30 --> Loader Class Initialized
INFO - 2023-06-23 11:18:30 --> Helper loaded: url_helper
INFO - 2023-06-23 11:18:30 --> Helper loaded: form_helper
INFO - 2023-06-23 11:18:30 --> Database Driver Class Initialized
INFO - 2023-06-23 11:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:18:30 --> Form Validation Class Initialized
INFO - 2023-06-23 11:18:30 --> Controller Class Initialized
INFO - 2023-06-23 11:18:30 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:18:30 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:18:30 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:18:30 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:18:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:18:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:18:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-23 11:18:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:18:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:18:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:18:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:18:30 --> Final output sent to browser
INFO - 2023-06-23 11:19:12 --> Config Class Initialized
INFO - 2023-06-23 11:19:12 --> Hooks Class Initialized
INFO - 2023-06-23 11:19:12 --> Utf8 Class Initialized
INFO - 2023-06-23 11:19:12 --> URI Class Initialized
INFO - 2023-06-23 11:19:12 --> Router Class Initialized
INFO - 2023-06-23 11:19:12 --> Output Class Initialized
INFO - 2023-06-23 11:19:12 --> Security Class Initialized
INFO - 2023-06-23 11:19:12 --> Input Class Initialized
INFO - 2023-06-23 11:19:12 --> Language Class Initialized
INFO - 2023-06-23 11:19:12 --> Loader Class Initialized
INFO - 2023-06-23 11:19:12 --> Helper loaded: url_helper
INFO - 2023-06-23 11:19:12 --> Helper loaded: form_helper
INFO - 2023-06-23 11:19:12 --> Database Driver Class Initialized
INFO - 2023-06-23 11:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:19:12 --> Form Validation Class Initialized
INFO - 2023-06-23 11:19:12 --> Controller Class Initialized
INFO - 2023-06-23 11:19:12 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:19:12 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:19:12 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:19:12 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:19:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:19:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:19:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:19:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:19:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:19:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:19:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:19:12 --> Final output sent to browser
INFO - 2023-06-23 11:19:22 --> Config Class Initialized
INFO - 2023-06-23 11:19:22 --> Hooks Class Initialized
INFO - 2023-06-23 11:19:22 --> Utf8 Class Initialized
INFO - 2023-06-23 11:19:22 --> URI Class Initialized
INFO - 2023-06-23 11:19:22 --> Router Class Initialized
INFO - 2023-06-23 11:19:22 --> Output Class Initialized
INFO - 2023-06-23 11:19:22 --> Security Class Initialized
INFO - 2023-06-23 11:19:22 --> Input Class Initialized
INFO - 2023-06-23 11:19:22 --> Language Class Initialized
INFO - 2023-06-23 11:19:22 --> Loader Class Initialized
INFO - 2023-06-23 11:19:22 --> Helper loaded: url_helper
INFO - 2023-06-23 11:19:22 --> Helper loaded: form_helper
INFO - 2023-06-23 11:19:22 --> Database Driver Class Initialized
INFO - 2023-06-23 11:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:19:22 --> Form Validation Class Initialized
INFO - 2023-06-23 11:19:22 --> Controller Class Initialized
INFO - 2023-06-23 11:19:22 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:19:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:19:22 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:19:22 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:19:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:19:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:19:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-23 11:19:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:19:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:19:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:19:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:19:22 --> Final output sent to browser
INFO - 2023-06-23 11:19:37 --> Config Class Initialized
INFO - 2023-06-23 11:19:37 --> Hooks Class Initialized
INFO - 2023-06-23 11:19:37 --> Utf8 Class Initialized
INFO - 2023-06-23 11:19:37 --> URI Class Initialized
INFO - 2023-06-23 11:19:37 --> Router Class Initialized
INFO - 2023-06-23 11:19:37 --> Output Class Initialized
INFO - 2023-06-23 11:19:37 --> Security Class Initialized
INFO - 2023-06-23 11:19:37 --> Input Class Initialized
INFO - 2023-06-23 11:19:37 --> Language Class Initialized
INFO - 2023-06-23 11:19:37 --> Loader Class Initialized
INFO - 2023-06-23 11:19:37 --> Helper loaded: url_helper
INFO - 2023-06-23 11:19:37 --> Helper loaded: form_helper
INFO - 2023-06-23 11:19:37 --> Database Driver Class Initialized
INFO - 2023-06-23 11:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:19:37 --> Form Validation Class Initialized
INFO - 2023-06-23 11:19:37 --> Controller Class Initialized
INFO - 2023-06-23 11:19:37 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:19:37 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:19:37 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:19:37 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:19:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:19:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:19:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:19:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:19:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:19:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:19:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:19:37 --> Final output sent to browser
INFO - 2023-06-23 11:20:24 --> Config Class Initialized
INFO - 2023-06-23 11:20:24 --> Hooks Class Initialized
INFO - 2023-06-23 11:20:24 --> Utf8 Class Initialized
INFO - 2023-06-23 11:20:24 --> URI Class Initialized
INFO - 2023-06-23 11:20:24 --> Router Class Initialized
INFO - 2023-06-23 11:20:24 --> Output Class Initialized
INFO - 2023-06-23 11:20:24 --> Security Class Initialized
INFO - 2023-06-23 11:20:24 --> Input Class Initialized
INFO - 2023-06-23 11:20:24 --> Language Class Initialized
INFO - 2023-06-23 11:20:24 --> Loader Class Initialized
INFO - 2023-06-23 11:20:24 --> Helper loaded: url_helper
INFO - 2023-06-23 11:20:24 --> Helper loaded: form_helper
INFO - 2023-06-23 11:20:24 --> Database Driver Class Initialized
INFO - 2023-06-23 11:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:20:24 --> Form Validation Class Initialized
INFO - 2023-06-23 11:20:24 --> Controller Class Initialized
INFO - 2023-06-23 11:20:24 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:20:24 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:20:24 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:20:24 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:20:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:20:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:20:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-23 11:20:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:20:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:20:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:20:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:20:24 --> Final output sent to browser
INFO - 2023-06-23 11:21:06 --> Config Class Initialized
INFO - 2023-06-23 11:21:06 --> Hooks Class Initialized
INFO - 2023-06-23 11:21:06 --> Utf8 Class Initialized
INFO - 2023-06-23 11:21:06 --> URI Class Initialized
INFO - 2023-06-23 11:21:06 --> Router Class Initialized
INFO - 2023-06-23 11:21:06 --> Output Class Initialized
INFO - 2023-06-23 11:21:06 --> Security Class Initialized
INFO - 2023-06-23 11:21:06 --> Input Class Initialized
INFO - 2023-06-23 11:21:06 --> Language Class Initialized
INFO - 2023-06-23 11:21:06 --> Loader Class Initialized
INFO - 2023-06-23 11:21:06 --> Helper loaded: url_helper
INFO - 2023-06-23 11:21:06 --> Helper loaded: form_helper
INFO - 2023-06-23 11:21:06 --> Database Driver Class Initialized
INFO - 2023-06-23 11:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:21:06 --> Form Validation Class Initialized
INFO - 2023-06-23 11:21:06 --> Controller Class Initialized
INFO - 2023-06-23 11:21:06 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:21:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:21:06 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:21:06 --> Model "M_solusi" initialized
ERROR - 2023-06-23 11:21:06 --> Query error: Unknown column 'prob_GangguanMood' in 'field list' - Invalid query: INSERT INTO `datatest` (`nama`, `semester`, `a1`, `a2`, `a3`, `a4`, `a5`, `a6`, `b1`, `b2`, `b3`, `b4`, `b5`, `b6`, `b7`, `b8`, `b9`, `b10`, `b11`, `b12`, `b13`, `b14`, `b15`, `b16`, `b17`, `b18`, `b19`, `b20`, `b21`, `bobot`, `hasil_bobot`, `prob_GangguanMood`, `prob_Ringan`, `prob_Sedang`, `prob_Berat`, `hasil`) VALUES ('pilihan A', '8', 'Rumah Sendiri', 'Sangat Buruk', 'Sangat Buruk', 'Sangat Buruk', 'Sangat Buruk', 'Sangat Buruk', 'Saya tidak merasa sedih', 'Saya tidak terlalu berkecil hati mengenai masa depan', 'Saya tidak menganggap diri saya sebagai orang yang gagal', 'Saya memperoleh banyak kepuasan dari hal-hal yang saya lakukan, sama seperti sebelumnya', 'Saya tidak terlalu merasa bersalah', 'Saya tidak merasa seolah saya sedang dihukum', 'Saya tidak merasa kecewa terhadap diri saya sendiri', 'Saya tidak merasa lebih buruk dari orang lain', 'Saya tidak punya sedikitpun pikiran untuk bunuh diri', 'Saya tidak lebih banyak menangis dibandingkan biasanya', 'Saya tidak lebih terganggu oleh berbagai hal dibandingkan biasanya', 'Saya tidak kehilangan minat saya terhadap orang lain', 'Saya mengambil keputusan-keputusan hampir sama baiknya dengan yang biasa saya lakukan', 'Saya tidak merasa bahwa keadaan saya tampak lebih buruk dari yang biasanya', 'Saya dapat bekerja sama baiknya dengan waktu-waktu sebelumnya', 'Saya dapat tidur seperti biasa', 'Saya merasa tidak lelah seperti biasanya', 'Nafsu makan saya tidak lebih buruk dari biasanya', 'Berat badan saya tidak turun banyak, atau bahkan tetap, akhir-akhir ini', 'Saya tidak lebih cemas mengenai kesehatan saya daripada biasanya', 'Saya tidak melihat adanya perubahan dalam minat saya terhadap hubungan dengan lawan jenis', 0, 'Gangguan Mood', 1.5574413478908E-15, 3.7044085890547E-21, 7.876903769803E-24, 7.2727272727273E-27, 'Gangguan Mood')
INFO - 2023-06-23 11:21:06 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-23 11:23:19 --> Config Class Initialized
INFO - 2023-06-23 11:23:19 --> Hooks Class Initialized
INFO - 2023-06-23 11:23:19 --> Utf8 Class Initialized
INFO - 2023-06-23 11:23:19 --> URI Class Initialized
INFO - 2023-06-23 11:23:19 --> Router Class Initialized
INFO - 2023-06-23 11:23:19 --> Output Class Initialized
INFO - 2023-06-23 11:23:19 --> Security Class Initialized
INFO - 2023-06-23 11:23:19 --> Input Class Initialized
INFO - 2023-06-23 11:23:19 --> Language Class Initialized
INFO - 2023-06-23 11:23:20 --> Loader Class Initialized
INFO - 2023-06-23 11:23:20 --> Helper loaded: url_helper
INFO - 2023-06-23 11:23:20 --> Helper loaded: form_helper
INFO - 2023-06-23 11:23:20 --> Database Driver Class Initialized
INFO - 2023-06-23 11:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:23:20 --> Form Validation Class Initialized
INFO - 2023-06-23 11:23:20 --> Controller Class Initialized
INFO - 2023-06-23 11:23:20 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:23:20 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:23:20 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:23:20 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:23:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:23:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:23:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:23:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:23:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:23:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:23:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:23:20 --> Final output sent to browser
INFO - 2023-06-23 11:25:14 --> Config Class Initialized
INFO - 2023-06-23 11:25:14 --> Hooks Class Initialized
INFO - 2023-06-23 11:25:14 --> Utf8 Class Initialized
INFO - 2023-06-23 11:25:14 --> URI Class Initialized
INFO - 2023-06-23 11:25:14 --> Router Class Initialized
INFO - 2023-06-23 11:25:14 --> Output Class Initialized
INFO - 2023-06-23 11:25:14 --> Security Class Initialized
INFO - 2023-06-23 11:25:14 --> Input Class Initialized
INFO - 2023-06-23 11:25:14 --> Language Class Initialized
INFO - 2023-06-23 11:25:14 --> Loader Class Initialized
INFO - 2023-06-23 11:25:14 --> Helper loaded: url_helper
INFO - 2023-06-23 11:25:14 --> Helper loaded: form_helper
INFO - 2023-06-23 11:25:14 --> Database Driver Class Initialized
INFO - 2023-06-23 11:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:25:14 --> Form Validation Class Initialized
INFO - 2023-06-23 11:25:14 --> Controller Class Initialized
INFO - 2023-06-23 11:25:14 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:25:14 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:25:14 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:25:14 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:25:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:25:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:25:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-23 11:25:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:25:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:25:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:25:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:25:14 --> Final output sent to browser
INFO - 2023-06-23 11:26:16 --> Config Class Initialized
INFO - 2023-06-23 11:26:16 --> Hooks Class Initialized
INFO - 2023-06-23 11:26:16 --> Utf8 Class Initialized
INFO - 2023-06-23 11:26:16 --> URI Class Initialized
INFO - 2023-06-23 11:26:16 --> Router Class Initialized
INFO - 2023-06-23 11:26:16 --> Output Class Initialized
INFO - 2023-06-23 11:26:16 --> Security Class Initialized
INFO - 2023-06-23 11:26:16 --> Input Class Initialized
INFO - 2023-06-23 11:26:16 --> Language Class Initialized
INFO - 2023-06-23 11:26:16 --> Loader Class Initialized
INFO - 2023-06-23 11:26:16 --> Helper loaded: url_helper
INFO - 2023-06-23 11:26:16 --> Helper loaded: form_helper
INFO - 2023-06-23 11:26:16 --> Database Driver Class Initialized
INFO - 2023-06-23 11:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:26:16 --> Form Validation Class Initialized
INFO - 2023-06-23 11:26:16 --> Controller Class Initialized
INFO - 2023-06-23 11:26:16 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:26:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:26:16 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:26:16 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:26:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:26:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:26:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:26:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:26:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:26:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:26:16 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:26:16 --> Final output sent to browser
INFO - 2023-06-23 11:27:01 --> Config Class Initialized
INFO - 2023-06-23 11:27:01 --> Hooks Class Initialized
INFO - 2023-06-23 11:27:01 --> Utf8 Class Initialized
INFO - 2023-06-23 11:27:01 --> URI Class Initialized
INFO - 2023-06-23 11:27:01 --> Router Class Initialized
INFO - 2023-06-23 11:27:01 --> Output Class Initialized
INFO - 2023-06-23 11:27:01 --> Security Class Initialized
INFO - 2023-06-23 11:27:01 --> Input Class Initialized
INFO - 2023-06-23 11:27:01 --> Language Class Initialized
INFO - 2023-06-23 11:27:01 --> Loader Class Initialized
INFO - 2023-06-23 11:27:01 --> Helper loaded: url_helper
INFO - 2023-06-23 11:27:01 --> Helper loaded: form_helper
INFO - 2023-06-23 11:27:01 --> Database Driver Class Initialized
INFO - 2023-06-23 11:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:27:01 --> Form Validation Class Initialized
INFO - 2023-06-23 11:27:01 --> Controller Class Initialized
INFO - 2023-06-23 11:27:01 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:27:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:27:01 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:27:01 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:27:01 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:27:01 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:27:01 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:27:01 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:27:01 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:27:01 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:27:01 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:27:01 --> Final output sent to browser
INFO - 2023-06-23 11:28:03 --> Config Class Initialized
INFO - 2023-06-23 11:28:03 --> Hooks Class Initialized
INFO - 2023-06-23 11:28:03 --> Utf8 Class Initialized
INFO - 2023-06-23 11:28:03 --> URI Class Initialized
INFO - 2023-06-23 11:28:03 --> Router Class Initialized
INFO - 2023-06-23 11:28:03 --> Output Class Initialized
INFO - 2023-06-23 11:28:03 --> Security Class Initialized
INFO - 2023-06-23 11:28:03 --> Input Class Initialized
INFO - 2023-06-23 11:28:03 --> Language Class Initialized
INFO - 2023-06-23 11:28:03 --> Loader Class Initialized
INFO - 2023-06-23 11:28:03 --> Helper loaded: url_helper
INFO - 2023-06-23 11:28:03 --> Helper loaded: form_helper
INFO - 2023-06-23 11:28:03 --> Database Driver Class Initialized
INFO - 2023-06-23 11:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:28:03 --> Form Validation Class Initialized
INFO - 2023-06-23 11:28:03 --> Controller Class Initialized
INFO - 2023-06-23 11:28:03 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:28:03 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:28:03 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:28:03 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:28:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:28:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:28:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-23 11:28:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:28:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:28:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:28:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:28:03 --> Final output sent to browser
INFO - 2023-06-23 11:28:59 --> Config Class Initialized
INFO - 2023-06-23 11:28:59 --> Hooks Class Initialized
INFO - 2023-06-23 11:28:59 --> Utf8 Class Initialized
INFO - 2023-06-23 11:28:59 --> URI Class Initialized
INFO - 2023-06-23 11:28:59 --> Router Class Initialized
INFO - 2023-06-23 11:28:59 --> Output Class Initialized
INFO - 2023-06-23 11:28:59 --> Security Class Initialized
INFO - 2023-06-23 11:28:59 --> Input Class Initialized
INFO - 2023-06-23 11:28:59 --> Language Class Initialized
INFO - 2023-06-23 11:28:59 --> Loader Class Initialized
INFO - 2023-06-23 11:28:59 --> Helper loaded: url_helper
INFO - 2023-06-23 11:28:59 --> Helper loaded: form_helper
INFO - 2023-06-23 11:28:59 --> Database Driver Class Initialized
INFO - 2023-06-23 11:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:28:59 --> Form Validation Class Initialized
INFO - 2023-06-23 11:28:59 --> Controller Class Initialized
INFO - 2023-06-23 11:28:59 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:28:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:28:59 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:28:59 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:28:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:28:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:28:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:28:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:28:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:28:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:28:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:28:59 --> Final output sent to browser
INFO - 2023-06-23 11:29:14 --> Config Class Initialized
INFO - 2023-06-23 11:29:14 --> Hooks Class Initialized
INFO - 2023-06-23 11:29:14 --> Utf8 Class Initialized
INFO - 2023-06-23 11:29:14 --> URI Class Initialized
INFO - 2023-06-23 11:29:14 --> Router Class Initialized
INFO - 2023-06-23 11:29:14 --> Output Class Initialized
INFO - 2023-06-23 11:29:14 --> Security Class Initialized
INFO - 2023-06-23 11:29:14 --> Input Class Initialized
INFO - 2023-06-23 11:29:14 --> Language Class Initialized
INFO - 2023-06-23 11:29:14 --> Loader Class Initialized
INFO - 2023-06-23 11:29:14 --> Helper loaded: url_helper
INFO - 2023-06-23 11:29:14 --> Helper loaded: form_helper
INFO - 2023-06-23 11:29:14 --> Database Driver Class Initialized
INFO - 2023-06-23 11:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:29:14 --> Form Validation Class Initialized
INFO - 2023-06-23 11:29:14 --> Controller Class Initialized
INFO - 2023-06-23 11:29:14 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:29:14 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:29:14 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:29:14 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:29:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:29:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:29:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-23 11:29:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:29:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:29:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:29:14 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:29:14 --> Final output sent to browser
INFO - 2023-06-23 11:30:12 --> Config Class Initialized
INFO - 2023-06-23 11:30:12 --> Hooks Class Initialized
INFO - 2023-06-23 11:30:12 --> Utf8 Class Initialized
INFO - 2023-06-23 11:30:12 --> URI Class Initialized
INFO - 2023-06-23 11:30:12 --> Router Class Initialized
INFO - 2023-06-23 11:30:12 --> Output Class Initialized
INFO - 2023-06-23 11:30:12 --> Security Class Initialized
INFO - 2023-06-23 11:30:12 --> Input Class Initialized
INFO - 2023-06-23 11:30:12 --> Language Class Initialized
INFO - 2023-06-23 11:30:12 --> Loader Class Initialized
INFO - 2023-06-23 11:30:12 --> Helper loaded: url_helper
INFO - 2023-06-23 11:30:12 --> Helper loaded: form_helper
INFO - 2023-06-23 11:30:12 --> Database Driver Class Initialized
INFO - 2023-06-23 11:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:30:12 --> Form Validation Class Initialized
INFO - 2023-06-23 11:30:12 --> Controller Class Initialized
INFO - 2023-06-23 11:30:12 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:30:12 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:30:12 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:30:12 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:30:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:30:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:30:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:30:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:30:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:30:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:30:12 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:30:12 --> Final output sent to browser
INFO - 2023-06-23 11:30:30 --> Config Class Initialized
INFO - 2023-06-23 11:30:30 --> Hooks Class Initialized
INFO - 2023-06-23 11:30:30 --> Utf8 Class Initialized
INFO - 2023-06-23 11:30:30 --> URI Class Initialized
INFO - 2023-06-23 11:30:30 --> Router Class Initialized
INFO - 2023-06-23 11:30:30 --> Output Class Initialized
INFO - 2023-06-23 11:30:30 --> Security Class Initialized
INFO - 2023-06-23 11:30:30 --> Input Class Initialized
INFO - 2023-06-23 11:30:30 --> Language Class Initialized
INFO - 2023-06-23 11:30:30 --> Loader Class Initialized
INFO - 2023-06-23 11:30:30 --> Helper loaded: url_helper
INFO - 2023-06-23 11:30:30 --> Helper loaded: form_helper
INFO - 2023-06-23 11:30:30 --> Database Driver Class Initialized
INFO - 2023-06-23 11:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:30:30 --> Form Validation Class Initialized
INFO - 2023-06-23 11:30:30 --> Controller Class Initialized
INFO - 2023-06-23 11:30:30 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:30:30 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:30:30 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:30:30 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:30:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:30:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:30:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-23 11:30:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:30:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:30:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:30:30 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:30:30 --> Final output sent to browser
INFO - 2023-06-23 11:30:47 --> Config Class Initialized
INFO - 2023-06-23 11:30:47 --> Hooks Class Initialized
INFO - 2023-06-23 11:30:47 --> Utf8 Class Initialized
INFO - 2023-06-23 11:30:47 --> URI Class Initialized
INFO - 2023-06-23 11:30:47 --> Router Class Initialized
INFO - 2023-06-23 11:30:47 --> Output Class Initialized
INFO - 2023-06-23 11:30:47 --> Security Class Initialized
INFO - 2023-06-23 11:30:47 --> Input Class Initialized
INFO - 2023-06-23 11:30:47 --> Language Class Initialized
INFO - 2023-06-23 11:30:47 --> Loader Class Initialized
INFO - 2023-06-23 11:30:47 --> Helper loaded: url_helper
INFO - 2023-06-23 11:30:47 --> Helper loaded: form_helper
INFO - 2023-06-23 11:30:47 --> Database Driver Class Initialized
INFO - 2023-06-23 11:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:30:47 --> Form Validation Class Initialized
INFO - 2023-06-23 11:30:47 --> Controller Class Initialized
INFO - 2023-06-23 11:30:47 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:30:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:30:47 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:30:47 --> Model "M_solusi" initialized
INFO - 2023-06-23 11:30:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:30:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:30:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_hasil.php
INFO - 2023-06-23 11:30:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 11:30:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:30:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:30:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-23 11:30:47 --> Final output sent to browser
INFO - 2023-06-23 11:30:53 --> Config Class Initialized
INFO - 2023-06-23 11:30:53 --> Hooks Class Initialized
INFO - 2023-06-23 11:30:53 --> Utf8 Class Initialized
INFO - 2023-06-23 11:30:53 --> URI Class Initialized
INFO - 2023-06-23 11:30:53 --> Router Class Initialized
INFO - 2023-06-23 11:30:53 --> Output Class Initialized
INFO - 2023-06-23 11:30:53 --> Security Class Initialized
INFO - 2023-06-23 11:30:53 --> Input Class Initialized
INFO - 2023-06-23 11:30:53 --> Language Class Initialized
INFO - 2023-06-23 11:30:53 --> Loader Class Initialized
INFO - 2023-06-23 11:30:53 --> Helper loaded: url_helper
INFO - 2023-06-23 11:30:53 --> Helper loaded: form_helper
INFO - 2023-06-23 11:30:53 --> Database Driver Class Initialized
INFO - 2023-06-23 11:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:30:53 --> Form Validation Class Initialized
INFO - 2023-06-23 11:30:53 --> Controller Class Initialized
INFO - 2023-06-23 11:30:54 --> Model "m_user" initialized
INFO - 2023-06-23 11:30:54 --> Config Class Initialized
INFO - 2023-06-23 11:30:54 --> Hooks Class Initialized
INFO - 2023-06-23 11:30:54 --> Utf8 Class Initialized
INFO - 2023-06-23 11:30:54 --> URI Class Initialized
INFO - 2023-06-23 11:30:54 --> Router Class Initialized
INFO - 2023-06-23 11:30:54 --> Output Class Initialized
INFO - 2023-06-23 11:30:54 --> Security Class Initialized
INFO - 2023-06-23 11:30:54 --> Input Class Initialized
INFO - 2023-06-23 11:30:54 --> Language Class Initialized
INFO - 2023-06-23 11:30:54 --> Loader Class Initialized
INFO - 2023-06-23 11:30:54 --> Helper loaded: url_helper
INFO - 2023-06-23 11:30:54 --> Helper loaded: form_helper
INFO - 2023-06-23 11:30:54 --> Database Driver Class Initialized
INFO - 2023-06-23 11:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:30:54 --> Form Validation Class Initialized
INFO - 2023-06-23 11:30:54 --> Controller Class Initialized
INFO - 2023-06-23 11:30:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-23 11:30:54 --> Final output sent to browser
INFO - 2023-06-23 11:30:55 --> Config Class Initialized
INFO - 2023-06-23 11:30:55 --> Hooks Class Initialized
INFO - 2023-06-23 11:30:55 --> Utf8 Class Initialized
INFO - 2023-06-23 11:30:55 --> URI Class Initialized
INFO - 2023-06-23 11:30:55 --> Router Class Initialized
INFO - 2023-06-23 11:30:55 --> Output Class Initialized
INFO - 2023-06-23 11:30:55 --> Security Class Initialized
INFO - 2023-06-23 11:30:55 --> Input Class Initialized
INFO - 2023-06-23 11:30:55 --> Language Class Initialized
INFO - 2023-06-23 11:30:55 --> Loader Class Initialized
INFO - 2023-06-23 11:30:55 --> Helper loaded: url_helper
INFO - 2023-06-23 11:30:55 --> Helper loaded: form_helper
INFO - 2023-06-23 11:30:55 --> Database Driver Class Initialized
INFO - 2023-06-23 11:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:30:55 --> Form Validation Class Initialized
INFO - 2023-06-23 11:30:55 --> Controller Class Initialized
INFO - 2023-06-23 11:30:55 --> Model "m_user" initialized
INFO - 2023-06-23 11:30:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_header.php
INFO - 2023-06-23 11:30:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\auth/login.php
INFO - 2023-06-23 11:30:55 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_footer.php
INFO - 2023-06-23 11:30:55 --> Final output sent to browser
INFO - 2023-06-23 11:30:58 --> Config Class Initialized
INFO - 2023-06-23 11:30:58 --> Hooks Class Initialized
INFO - 2023-06-23 11:30:58 --> Utf8 Class Initialized
INFO - 2023-06-23 11:30:58 --> URI Class Initialized
INFO - 2023-06-23 11:30:58 --> Router Class Initialized
INFO - 2023-06-23 11:30:58 --> Output Class Initialized
INFO - 2023-06-23 11:30:58 --> Security Class Initialized
INFO - 2023-06-23 11:30:58 --> Input Class Initialized
INFO - 2023-06-23 11:30:58 --> Language Class Initialized
INFO - 2023-06-23 11:30:58 --> Loader Class Initialized
INFO - 2023-06-23 11:30:58 --> Helper loaded: url_helper
INFO - 2023-06-23 11:30:58 --> Helper loaded: form_helper
INFO - 2023-06-23 11:30:58 --> Database Driver Class Initialized
INFO - 2023-06-23 11:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:30:58 --> Form Validation Class Initialized
INFO - 2023-06-23 11:30:58 --> Controller Class Initialized
INFO - 2023-06-23 11:30:58 --> Model "m_user" initialized
INFO - 2023-06-23 11:30:59 --> Config Class Initialized
INFO - 2023-06-23 11:30:59 --> Hooks Class Initialized
INFO - 2023-06-23 11:30:59 --> Utf8 Class Initialized
INFO - 2023-06-23 11:30:59 --> URI Class Initialized
INFO - 2023-06-23 11:30:59 --> Router Class Initialized
INFO - 2023-06-23 11:30:59 --> Output Class Initialized
INFO - 2023-06-23 11:30:59 --> Security Class Initialized
INFO - 2023-06-23 11:30:59 --> Input Class Initialized
INFO - 2023-06-23 11:30:59 --> Language Class Initialized
INFO - 2023-06-23 11:30:59 --> Loader Class Initialized
INFO - 2023-06-23 11:30:59 --> Helper loaded: url_helper
INFO - 2023-06-23 11:30:59 --> Helper loaded: form_helper
INFO - 2023-06-23 11:30:59 --> Database Driver Class Initialized
INFO - 2023-06-23 11:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:30:59 --> Form Validation Class Initialized
INFO - 2023-06-23 11:30:59 --> Controller Class Initialized
INFO - 2023-06-23 11:30:59 --> Model "m_user" initialized
INFO - 2023-06-23 11:30:59 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:30:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:30:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:30:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 11:30:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:30:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:30:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home.php
INFO - 2023-06-23 11:30:59 --> Final output sent to browser
INFO - 2023-06-23 11:39:47 --> Config Class Initialized
INFO - 2023-06-23 11:39:47 --> Hooks Class Initialized
INFO - 2023-06-23 11:39:47 --> Utf8 Class Initialized
INFO - 2023-06-23 11:39:47 --> URI Class Initialized
INFO - 2023-06-23 11:39:47 --> Router Class Initialized
INFO - 2023-06-23 11:39:47 --> Output Class Initialized
INFO - 2023-06-23 11:39:47 --> Security Class Initialized
INFO - 2023-06-23 11:39:47 --> Input Class Initialized
INFO - 2023-06-23 11:39:47 --> Language Class Initialized
INFO - 2023-06-23 11:39:47 --> Loader Class Initialized
INFO - 2023-06-23 11:39:47 --> Helper loaded: url_helper
INFO - 2023-06-23 11:39:47 --> Helper loaded: form_helper
INFO - 2023-06-23 11:39:47 --> Database Driver Class Initialized
INFO - 2023-06-23 11:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:39:47 --> Form Validation Class Initialized
INFO - 2023-06-23 11:39:47 --> Controller Class Initialized
INFO - 2023-06-23 11:39:47 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:39:47 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:39:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:39:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:39:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:39:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 11:39:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 11:39:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:39:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:39:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 11:39:47 --> Final output sent to browser
INFO - 2023-06-23 11:39:48 --> Config Class Initialized
INFO - 2023-06-23 11:39:48 --> Hooks Class Initialized
INFO - 2023-06-23 11:39:48 --> Utf8 Class Initialized
INFO - 2023-06-23 11:39:48 --> URI Class Initialized
INFO - 2023-06-23 11:39:48 --> Router Class Initialized
INFO - 2023-06-23 11:39:48 --> Output Class Initialized
INFO - 2023-06-23 11:39:48 --> Security Class Initialized
INFO - 2023-06-23 11:39:48 --> Input Class Initialized
INFO - 2023-06-23 11:39:48 --> Language Class Initialized
INFO - 2023-06-23 11:39:48 --> Loader Class Initialized
INFO - 2023-06-23 11:39:48 --> Helper loaded: url_helper
INFO - 2023-06-23 11:39:48 --> Helper loaded: form_helper
INFO - 2023-06-23 11:39:48 --> Database Driver Class Initialized
INFO - 2023-06-23 11:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:39:48 --> Form Validation Class Initialized
INFO - 2023-06-23 11:39:48 --> Controller Class Initialized
INFO - 2023-06-23 11:39:48 --> Model "m_datatest" initialized
INFO - 2023-06-23 11:39:48 --> Model "m_datatrain" initialized
INFO - 2023-06-23 11:39:48 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 11:39:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 11:39:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 11:39:49 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 11:39:49 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 11:39:49 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 11:39:49 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 11:39:49 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 11:39:49 --> Final output sent to browser
INFO - 2023-06-23 12:09:46 --> Config Class Initialized
INFO - 2023-06-23 12:09:46 --> Hooks Class Initialized
INFO - 2023-06-23 12:09:46 --> Utf8 Class Initialized
INFO - 2023-06-23 12:09:46 --> URI Class Initialized
INFO - 2023-06-23 12:09:46 --> Router Class Initialized
INFO - 2023-06-23 12:09:46 --> Output Class Initialized
INFO - 2023-06-23 12:09:46 --> Security Class Initialized
INFO - 2023-06-23 12:09:46 --> Input Class Initialized
INFO - 2023-06-23 12:09:46 --> Language Class Initialized
ERROR - 2023-06-23 12:09:46 --> 404 Page Not Found: Assets/admin
INFO - 2023-06-23 12:09:46 --> Config Class Initialized
INFO - 2023-06-23 12:09:46 --> Hooks Class Initialized
INFO - 2023-06-23 12:09:46 --> Config Class Initialized
INFO - 2023-06-23 12:09:46 --> Hooks Class Initialized
INFO - 2023-06-23 12:09:46 --> Utf8 Class Initialized
INFO - 2023-06-23 12:09:46 --> Utf8 Class Initialized
INFO - 2023-06-23 12:09:46 --> URI Class Initialized
INFO - 2023-06-23 12:09:46 --> URI Class Initialized
INFO - 2023-06-23 12:09:46 --> Router Class Initialized
INFO - 2023-06-23 12:09:46 --> Router Class Initialized
INFO - 2023-06-23 12:09:46 --> Output Class Initialized
INFO - 2023-06-23 12:09:46 --> Output Class Initialized
INFO - 2023-06-23 12:09:46 --> Security Class Initialized
INFO - 2023-06-23 12:09:46 --> Security Class Initialized
INFO - 2023-06-23 12:09:46 --> Input Class Initialized
INFO - 2023-06-23 12:09:46 --> Language Class Initialized
INFO - 2023-06-23 12:09:46 --> Input Class Initialized
INFO - 2023-06-23 12:09:46 --> Language Class Initialized
ERROR - 2023-06-23 12:09:46 --> 404 Page Not Found: Assets/admin
ERROR - 2023-06-23 12:09:46 --> 404 Page Not Found: Assets/admin
INFO - 2023-06-23 12:10:02 --> Config Class Initialized
INFO - 2023-06-23 12:10:02 --> Hooks Class Initialized
INFO - 2023-06-23 12:10:02 --> Utf8 Class Initialized
INFO - 2023-06-23 12:10:02 --> URI Class Initialized
INFO - 2023-06-23 12:10:02 --> Router Class Initialized
INFO - 2023-06-23 12:10:02 --> Output Class Initialized
INFO - 2023-06-23 12:10:02 --> Security Class Initialized
INFO - 2023-06-23 12:10:02 --> Input Class Initialized
INFO - 2023-06-23 12:10:02 --> Language Class Initialized
INFO - 2023-06-23 12:10:02 --> Loader Class Initialized
INFO - 2023-06-23 12:10:02 --> Helper loaded: url_helper
INFO - 2023-06-23 12:10:02 --> Helper loaded: form_helper
INFO - 2023-06-23 12:10:02 --> Database Driver Class Initialized
INFO - 2023-06-23 12:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 12:10:02 --> Form Validation Class Initialized
INFO - 2023-06-23 12:10:02 --> Controller Class Initialized
INFO - 2023-06-23 12:10:02 --> Model "m_datatest" initialized
INFO - 2023-06-23 12:10:02 --> Model "m_datatrain" initialized
INFO - 2023-06-23 12:10:02 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 12:10:02 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 12:10:02 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 12:10:02 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 12:10:02 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 12:10:02 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 12:10:02 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 12:10:02 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 12:10:02 --> Final output sent to browser
INFO - 2023-06-23 18:23:39 --> Config Class Initialized
INFO - 2023-06-23 18:23:39 --> Hooks Class Initialized
INFO - 2023-06-23 18:23:39 --> Utf8 Class Initialized
INFO - 2023-06-23 18:23:39 --> URI Class Initialized
INFO - 2023-06-23 18:23:39 --> Router Class Initialized
INFO - 2023-06-23 18:23:39 --> Output Class Initialized
INFO - 2023-06-23 18:23:39 --> Security Class Initialized
INFO - 2023-06-23 18:23:39 --> Input Class Initialized
INFO - 2023-06-23 18:23:39 --> Language Class Initialized
INFO - 2023-06-23 18:23:39 --> Loader Class Initialized
INFO - 2023-06-23 18:23:39 --> Helper loaded: url_helper
INFO - 2023-06-23 18:23:39 --> Helper loaded: form_helper
INFO - 2023-06-23 18:23:39 --> Database Driver Class Initialized
INFO - 2023-06-23 18:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:23:39 --> Form Validation Class Initialized
INFO - 2023-06-23 18:23:39 --> Controller Class Initialized
INFO - 2023-06-23 18:23:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-23 18:23:39 --> Final output sent to browser
INFO - 2023-06-23 18:23:41 --> Config Class Initialized
INFO - 2023-06-23 18:23:41 --> Hooks Class Initialized
INFO - 2023-06-23 18:23:41 --> Utf8 Class Initialized
INFO - 2023-06-23 18:23:41 --> URI Class Initialized
INFO - 2023-06-23 18:23:41 --> Router Class Initialized
INFO - 2023-06-23 18:23:41 --> Output Class Initialized
INFO - 2023-06-23 18:23:41 --> Security Class Initialized
INFO - 2023-06-23 18:23:41 --> Input Class Initialized
INFO - 2023-06-23 18:23:41 --> Language Class Initialized
INFO - 2023-06-23 18:23:41 --> Loader Class Initialized
INFO - 2023-06-23 18:23:41 --> Helper loaded: url_helper
INFO - 2023-06-23 18:23:41 --> Helper loaded: form_helper
INFO - 2023-06-23 18:23:41 --> Database Driver Class Initialized
INFO - 2023-06-23 18:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:23:41 --> Form Validation Class Initialized
INFO - 2023-06-23 18:23:41 --> Controller Class Initialized
INFO - 2023-06-23 18:23:41 --> Model "m_user" initialized
INFO - 2023-06-23 18:23:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_header.php
INFO - 2023-06-23 18:23:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\auth/login.php
INFO - 2023-06-23 18:23:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_footer.php
INFO - 2023-06-23 18:23:41 --> Final output sent to browser
INFO - 2023-06-23 18:23:45 --> Config Class Initialized
INFO - 2023-06-23 18:23:45 --> Hooks Class Initialized
INFO - 2023-06-23 18:23:45 --> Utf8 Class Initialized
INFO - 2023-06-23 18:23:45 --> URI Class Initialized
INFO - 2023-06-23 18:23:45 --> Router Class Initialized
INFO - 2023-06-23 18:23:45 --> Output Class Initialized
INFO - 2023-06-23 18:23:45 --> Security Class Initialized
INFO - 2023-06-23 18:23:45 --> Input Class Initialized
INFO - 2023-06-23 18:23:45 --> Language Class Initialized
INFO - 2023-06-23 18:23:45 --> Loader Class Initialized
INFO - 2023-06-23 18:23:45 --> Helper loaded: url_helper
INFO - 2023-06-23 18:23:45 --> Helper loaded: form_helper
INFO - 2023-06-23 18:23:45 --> Database Driver Class Initialized
INFO - 2023-06-23 18:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:23:45 --> Form Validation Class Initialized
INFO - 2023-06-23 18:23:45 --> Controller Class Initialized
INFO - 2023-06-23 18:23:45 --> Model "m_user" initialized
INFO - 2023-06-23 18:23:45 --> Config Class Initialized
INFO - 2023-06-23 18:23:45 --> Hooks Class Initialized
INFO - 2023-06-23 18:23:45 --> Utf8 Class Initialized
INFO - 2023-06-23 18:23:45 --> URI Class Initialized
INFO - 2023-06-23 18:23:45 --> Router Class Initialized
INFO - 2023-06-23 18:23:45 --> Output Class Initialized
INFO - 2023-06-23 18:23:45 --> Security Class Initialized
INFO - 2023-06-23 18:23:45 --> Input Class Initialized
INFO - 2023-06-23 18:23:45 --> Language Class Initialized
INFO - 2023-06-23 18:23:45 --> Loader Class Initialized
INFO - 2023-06-23 18:23:45 --> Helper loaded: url_helper
INFO - 2023-06-23 18:23:45 --> Helper loaded: form_helper
INFO - 2023-06-23 18:23:45 --> Database Driver Class Initialized
INFO - 2023-06-23 18:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:23:45 --> Form Validation Class Initialized
INFO - 2023-06-23 18:23:45 --> Controller Class Initialized
INFO - 2023-06-23 18:23:45 --> Model "m_user" initialized
INFO - 2023-06-23 18:23:45 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:23:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:23:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 18:23:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:23:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:23:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:23:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home.php
INFO - 2023-06-23 18:23:45 --> Final output sent to browser
INFO - 2023-06-23 18:23:47 --> Config Class Initialized
INFO - 2023-06-23 18:23:47 --> Hooks Class Initialized
INFO - 2023-06-23 18:23:47 --> Utf8 Class Initialized
INFO - 2023-06-23 18:23:47 --> URI Class Initialized
INFO - 2023-06-23 18:23:47 --> Router Class Initialized
INFO - 2023-06-23 18:23:47 --> Output Class Initialized
INFO - 2023-06-23 18:23:47 --> Security Class Initialized
INFO - 2023-06-23 18:23:47 --> Input Class Initialized
INFO - 2023-06-23 18:23:47 --> Language Class Initialized
INFO - 2023-06-23 18:23:47 --> Loader Class Initialized
INFO - 2023-06-23 18:23:47 --> Helper loaded: url_helper
INFO - 2023-06-23 18:23:47 --> Helper loaded: form_helper
INFO - 2023-06-23 18:23:47 --> Database Driver Class Initialized
INFO - 2023-06-23 18:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:23:47 --> Form Validation Class Initialized
INFO - 2023-06-23 18:23:47 --> Controller Class Initialized
INFO - 2023-06-23 18:23:47 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:23:47 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:23:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:23:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:23:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 18:23:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 18:23:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:23:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:23:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:23:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 18:23:47 --> Final output sent to browser
INFO - 2023-06-23 18:23:49 --> Config Class Initialized
INFO - 2023-06-23 18:23:49 --> Hooks Class Initialized
INFO - 2023-06-23 18:23:49 --> Utf8 Class Initialized
INFO - 2023-06-23 18:23:49 --> URI Class Initialized
INFO - 2023-06-23 18:23:49 --> Router Class Initialized
INFO - 2023-06-23 18:23:49 --> Output Class Initialized
INFO - 2023-06-23 18:23:49 --> Security Class Initialized
INFO - 2023-06-23 18:23:49 --> Input Class Initialized
INFO - 2023-06-23 18:23:49 --> Language Class Initialized
INFO - 2023-06-23 18:23:49 --> Loader Class Initialized
INFO - 2023-06-23 18:23:49 --> Helper loaded: url_helper
INFO - 2023-06-23 18:23:49 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:23:49 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:23:49 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 18:23:50 --> Severity: Parsing Error --> syntax error, unexpected '"B"' (T_CONSTANT_ENCAPSED_STRING), expecting variable (T_VARIABLE) or '$' C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
INFO - 2023-06-23 18:24:26 --> Config Class Initialized
INFO - 2023-06-23 18:24:26 --> Hooks Class Initialized
INFO - 2023-06-23 18:24:26 --> Utf8 Class Initialized
INFO - 2023-06-23 18:24:26 --> URI Class Initialized
INFO - 2023-06-23 18:24:26 --> Router Class Initialized
INFO - 2023-06-23 18:24:26 --> Output Class Initialized
INFO - 2023-06-23 18:24:26 --> Security Class Initialized
INFO - 2023-06-23 18:24:26 --> Input Class Initialized
INFO - 2023-06-23 18:24:26 --> Language Class Initialized
INFO - 2023-06-23 18:24:26 --> Loader Class Initialized
INFO - 2023-06-23 18:24:26 --> Helper loaded: url_helper
INFO - 2023-06-23 18:24:26 --> Helper loaded: form_helper
INFO - 2023-06-23 18:24:26 --> Database Driver Class Initialized
INFO - 2023-06-23 18:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:24:26 --> Form Validation Class Initialized
INFO - 2023-06-23 18:24:26 --> Controller Class Initialized
INFO - 2023-06-23 18:24:26 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:24:26 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:24:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:24:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:24:26 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 18:24:27 --> Severity: Parsing Error --> syntax error, unexpected '"B"' (T_CONSTANT_ENCAPSED_STRING), expecting variable (T_VARIABLE) or '$' C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 827
INFO - 2023-06-23 18:25:40 --> Config Class Initialized
INFO - 2023-06-23 18:25:40 --> Hooks Class Initialized
INFO - 2023-06-23 18:25:40 --> Utf8 Class Initialized
INFO - 2023-06-23 18:25:40 --> URI Class Initialized
INFO - 2023-06-23 18:25:40 --> Router Class Initialized
INFO - 2023-06-23 18:25:40 --> Output Class Initialized
INFO - 2023-06-23 18:25:40 --> Security Class Initialized
INFO - 2023-06-23 18:25:40 --> Input Class Initialized
INFO - 2023-06-23 18:25:40 --> Language Class Initialized
INFO - 2023-06-23 18:25:40 --> Loader Class Initialized
INFO - 2023-06-23 18:25:40 --> Helper loaded: url_helper
INFO - 2023-06-23 18:25:40 --> Helper loaded: form_helper
INFO - 2023-06-23 18:25:40 --> Database Driver Class Initialized
INFO - 2023-06-23 18:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:25:40 --> Form Validation Class Initialized
INFO - 2023-06-23 18:25:40 --> Controller Class Initialized
INFO - 2023-06-23 18:25:40 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:25:40 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:25:40 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:25:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:25:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 18:25:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 18:25:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:25:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:25:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:25:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 18:25:41 --> Final output sent to browser
INFO - 2023-06-23 18:31:27 --> Config Class Initialized
INFO - 2023-06-23 18:31:27 --> Hooks Class Initialized
INFO - 2023-06-23 18:31:27 --> Utf8 Class Initialized
INFO - 2023-06-23 18:31:27 --> URI Class Initialized
INFO - 2023-06-23 18:31:27 --> Router Class Initialized
INFO - 2023-06-23 18:31:27 --> Output Class Initialized
INFO - 2023-06-23 18:31:27 --> Security Class Initialized
INFO - 2023-06-23 18:31:27 --> Input Class Initialized
INFO - 2023-06-23 18:31:27 --> Language Class Initialized
INFO - 2023-06-23 18:31:27 --> Loader Class Initialized
INFO - 2023-06-23 18:31:27 --> Helper loaded: url_helper
INFO - 2023-06-23 18:31:27 --> Helper loaded: form_helper
INFO - 2023-06-23 18:31:27 --> Database Driver Class Initialized
INFO - 2023-06-23 18:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:31:27 --> Form Validation Class Initialized
INFO - 2023-06-23 18:31:27 --> Controller Class Initialized
INFO - 2023-06-23 18:31:27 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:31:27 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:31:27 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:31:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:31:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 18:31:28 --> Severity: Parsing Error --> syntax error, unexpected '$i' (T_VARIABLE), expecting ']' C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 829
INFO - 2023-06-23 18:32:06 --> Config Class Initialized
INFO - 2023-06-23 18:32:06 --> Hooks Class Initialized
INFO - 2023-06-23 18:32:06 --> Utf8 Class Initialized
INFO - 2023-06-23 18:32:06 --> URI Class Initialized
INFO - 2023-06-23 18:32:06 --> Router Class Initialized
INFO - 2023-06-23 18:32:06 --> Output Class Initialized
INFO - 2023-06-23 18:32:06 --> Security Class Initialized
INFO - 2023-06-23 18:32:06 --> Input Class Initialized
INFO - 2023-06-23 18:32:06 --> Language Class Initialized
INFO - 2023-06-23 18:32:06 --> Loader Class Initialized
INFO - 2023-06-23 18:32:06 --> Helper loaded: url_helper
INFO - 2023-06-23 18:32:06 --> Helper loaded: form_helper
INFO - 2023-06-23 18:32:06 --> Database Driver Class Initialized
INFO - 2023-06-23 18:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:32:06 --> Form Validation Class Initialized
INFO - 2023-06-23 18:32:06 --> Controller Class Initialized
INFO - 2023-06-23 18:32:06 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:32:06 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:32:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:32:07 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:32:07 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 18:32:08 --> Severity: Parsing Error --> syntax error, unexpected ']' C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 829
INFO - 2023-06-23 18:33:09 --> Config Class Initialized
INFO - 2023-06-23 18:33:09 --> Hooks Class Initialized
INFO - 2023-06-23 18:33:09 --> Utf8 Class Initialized
INFO - 2023-06-23 18:33:09 --> URI Class Initialized
INFO - 2023-06-23 18:33:09 --> Router Class Initialized
INFO - 2023-06-23 18:33:09 --> Output Class Initialized
INFO - 2023-06-23 18:33:09 --> Security Class Initialized
INFO - 2023-06-23 18:33:09 --> Input Class Initialized
INFO - 2023-06-23 18:33:09 --> Language Class Initialized
INFO - 2023-06-23 18:33:09 --> Loader Class Initialized
INFO - 2023-06-23 18:33:09 --> Helper loaded: url_helper
INFO - 2023-06-23 18:33:09 --> Helper loaded: form_helper
INFO - 2023-06-23 18:33:09 --> Database Driver Class Initialized
INFO - 2023-06-23 18:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:33:09 --> Form Validation Class Initialized
INFO - 2023-06-23 18:33:09 --> Controller Class Initialized
INFO - 2023-06-23 18:33:09 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:33:09 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:33:09 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:33:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:33:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 18:33:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 18:33:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:33:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:33:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:33:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 18:33:10 --> Final output sent to browser
INFO - 2023-06-23 18:34:18 --> Config Class Initialized
INFO - 2023-06-23 18:34:18 --> Hooks Class Initialized
INFO - 2023-06-23 18:34:18 --> Utf8 Class Initialized
INFO - 2023-06-23 18:34:18 --> URI Class Initialized
INFO - 2023-06-23 18:34:18 --> Router Class Initialized
INFO - 2023-06-23 18:34:18 --> Output Class Initialized
INFO - 2023-06-23 18:34:18 --> Security Class Initialized
INFO - 2023-06-23 18:34:18 --> Input Class Initialized
INFO - 2023-06-23 18:34:18 --> Language Class Initialized
INFO - 2023-06-23 18:34:18 --> Loader Class Initialized
INFO - 2023-06-23 18:34:18 --> Helper loaded: url_helper
INFO - 2023-06-23 18:34:18 --> Helper loaded: form_helper
INFO - 2023-06-23 18:34:18 --> Database Driver Class Initialized
INFO - 2023-06-23 18:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:34:18 --> Form Validation Class Initialized
INFO - 2023-06-23 18:34:18 --> Controller Class Initialized
INFO - 2023-06-23 18:34:18 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:34:18 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:34:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:34:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:34:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 18:34:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 18:34:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:34:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:34:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:34:20 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 18:34:20 --> Final output sent to browser
INFO - 2023-06-23 18:37:44 --> Config Class Initialized
INFO - 2023-06-23 18:37:44 --> Hooks Class Initialized
INFO - 2023-06-23 18:37:44 --> Utf8 Class Initialized
INFO - 2023-06-23 18:37:44 --> URI Class Initialized
INFO - 2023-06-23 18:37:44 --> Router Class Initialized
INFO - 2023-06-23 18:37:44 --> Output Class Initialized
INFO - 2023-06-23 18:37:44 --> Security Class Initialized
INFO - 2023-06-23 18:37:44 --> Input Class Initialized
INFO - 2023-06-23 18:37:44 --> Language Class Initialized
INFO - 2023-06-23 18:37:44 --> Loader Class Initialized
INFO - 2023-06-23 18:37:44 --> Helper loaded: url_helper
INFO - 2023-06-23 18:37:44 --> Helper loaded: form_helper
INFO - 2023-06-23 18:37:44 --> Database Driver Class Initialized
INFO - 2023-06-23 18:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:37:44 --> Form Validation Class Initialized
INFO - 2023-06-23 18:37:44 --> Controller Class Initialized
INFO - 2023-06-23 18:37:44 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:37:44 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:37:44 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:37:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:37:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 18:37:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 18:37:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:37:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:37:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:37:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 18:37:45 --> Final output sent to browser
INFO - 2023-06-23 18:39:35 --> Config Class Initialized
INFO - 2023-06-23 18:39:35 --> Hooks Class Initialized
INFO - 2023-06-23 18:39:35 --> Utf8 Class Initialized
INFO - 2023-06-23 18:39:35 --> URI Class Initialized
INFO - 2023-06-23 18:39:35 --> Router Class Initialized
INFO - 2023-06-23 18:39:35 --> Output Class Initialized
INFO - 2023-06-23 18:39:35 --> Security Class Initialized
INFO - 2023-06-23 18:39:35 --> Input Class Initialized
INFO - 2023-06-23 18:39:35 --> Language Class Initialized
INFO - 2023-06-23 18:39:35 --> Loader Class Initialized
INFO - 2023-06-23 18:39:35 --> Helper loaded: url_helper
INFO - 2023-06-23 18:39:35 --> Helper loaded: form_helper
INFO - 2023-06-23 18:39:35 --> Database Driver Class Initialized
INFO - 2023-06-23 18:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:39:35 --> Form Validation Class Initialized
INFO - 2023-06-23 18:39:35 --> Controller Class Initialized
INFO - 2023-06-23 18:39:36 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:39:36 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:39:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:39:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:39:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 18:39:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 18:39:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:39:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:39:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:39:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 18:39:37 --> Final output sent to browser
INFO - 2023-06-23 18:41:50 --> Config Class Initialized
INFO - 2023-06-23 18:41:50 --> Hooks Class Initialized
INFO - 2023-06-23 18:41:50 --> Utf8 Class Initialized
INFO - 2023-06-23 18:41:50 --> URI Class Initialized
INFO - 2023-06-23 18:41:50 --> Router Class Initialized
INFO - 2023-06-23 18:41:50 --> Output Class Initialized
INFO - 2023-06-23 18:41:50 --> Security Class Initialized
INFO - 2023-06-23 18:41:50 --> Input Class Initialized
INFO - 2023-06-23 18:41:50 --> Language Class Initialized
INFO - 2023-06-23 18:41:50 --> Loader Class Initialized
INFO - 2023-06-23 18:41:50 --> Helper loaded: url_helper
INFO - 2023-06-23 18:41:50 --> Helper loaded: form_helper
INFO - 2023-06-23 18:41:50 --> Database Driver Class Initialized
INFO - 2023-06-23 18:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:41:50 --> Form Validation Class Initialized
INFO - 2023-06-23 18:41:50 --> Controller Class Initialized
INFO - 2023-06-23 18:41:50 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:41:50 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:41:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:41:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:41:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 18:41:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 18:41:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:41:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:41:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:41:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 18:41:52 --> Final output sent to browser
INFO - 2023-06-23 18:42:06 --> Config Class Initialized
INFO - 2023-06-23 18:42:06 --> Hooks Class Initialized
INFO - 2023-06-23 18:42:06 --> Utf8 Class Initialized
INFO - 2023-06-23 18:42:06 --> URI Class Initialized
INFO - 2023-06-23 18:42:06 --> Router Class Initialized
INFO - 2023-06-23 18:42:06 --> Output Class Initialized
INFO - 2023-06-23 18:42:06 --> Security Class Initialized
INFO - 2023-06-23 18:42:06 --> Input Class Initialized
INFO - 2023-06-23 18:42:06 --> Language Class Initialized
INFO - 2023-06-23 18:42:06 --> Loader Class Initialized
INFO - 2023-06-23 18:42:06 --> Helper loaded: url_helper
INFO - 2023-06-23 18:42:06 --> Helper loaded: form_helper
INFO - 2023-06-23 18:42:06 --> Database Driver Class Initialized
INFO - 2023-06-23 18:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:42:06 --> Form Validation Class Initialized
INFO - 2023-06-23 18:42:06 --> Controller Class Initialized
INFO - 2023-06-23 18:42:06 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:42:06 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:42:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:42:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:42:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 18:42:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 18:42:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:42:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:42:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:42:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 18:42:06 --> Final output sent to browser
INFO - 2023-06-23 18:42:09 --> Config Class Initialized
INFO - 2023-06-23 18:42:09 --> Hooks Class Initialized
INFO - 2023-06-23 18:42:09 --> Utf8 Class Initialized
INFO - 2023-06-23 18:42:09 --> URI Class Initialized
INFO - 2023-06-23 18:42:09 --> Router Class Initialized
INFO - 2023-06-23 18:42:09 --> Output Class Initialized
INFO - 2023-06-23 18:42:09 --> Security Class Initialized
INFO - 2023-06-23 18:42:09 --> Input Class Initialized
INFO - 2023-06-23 18:42:09 --> Language Class Initialized
INFO - 2023-06-23 18:42:09 --> Loader Class Initialized
INFO - 2023-06-23 18:42:09 --> Helper loaded: url_helper
INFO - 2023-06-23 18:42:09 --> Helper loaded: form_helper
INFO - 2023-06-23 18:42:09 --> Database Driver Class Initialized
INFO - 2023-06-23 18:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:42:09 --> Form Validation Class Initialized
INFO - 2023-06-23 18:42:09 --> Controller Class Initialized
INFO - 2023-06-23 18:42:09 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:42:09 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:42:09 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:42:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:42:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 18:42:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 18:42:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:42:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:42:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:42:10 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 18:42:10 --> Final output sent to browser
INFO - 2023-06-23 18:42:52 --> Config Class Initialized
INFO - 2023-06-23 18:42:52 --> Hooks Class Initialized
INFO - 2023-06-23 18:42:52 --> Utf8 Class Initialized
INFO - 2023-06-23 18:42:52 --> URI Class Initialized
INFO - 2023-06-23 18:42:52 --> Router Class Initialized
INFO - 2023-06-23 18:42:52 --> Output Class Initialized
INFO - 2023-06-23 18:42:52 --> Security Class Initialized
INFO - 2023-06-23 18:42:52 --> Input Class Initialized
INFO - 2023-06-23 18:42:52 --> Language Class Initialized
INFO - 2023-06-23 18:42:52 --> Loader Class Initialized
INFO - 2023-06-23 18:42:52 --> Helper loaded: url_helper
INFO - 2023-06-23 18:42:52 --> Helper loaded: form_helper
INFO - 2023-06-23 18:42:53 --> Database Driver Class Initialized
INFO - 2023-06-23 18:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:42:53 --> Form Validation Class Initialized
INFO - 2023-06-23 18:42:53 --> Controller Class Initialized
INFO - 2023-06-23 18:42:53 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:42:53 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:42:53 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:42:53 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:42:53 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 18:42:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 18:42:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:42:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:42:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:42:54 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 18:42:54 --> Final output sent to browser
INFO - 2023-06-23 18:56:35 --> Config Class Initialized
INFO - 2023-06-23 18:56:35 --> Hooks Class Initialized
INFO - 2023-06-23 18:56:35 --> Utf8 Class Initialized
INFO - 2023-06-23 18:56:35 --> URI Class Initialized
INFO - 2023-06-23 18:56:35 --> Router Class Initialized
INFO - 2023-06-23 18:56:35 --> Output Class Initialized
INFO - 2023-06-23 18:56:35 --> Security Class Initialized
INFO - 2023-06-23 18:56:35 --> Input Class Initialized
INFO - 2023-06-23 18:56:35 --> Language Class Initialized
INFO - 2023-06-23 18:56:35 --> Loader Class Initialized
INFO - 2023-06-23 18:56:35 --> Helper loaded: url_helper
INFO - 2023-06-23 18:56:35 --> Helper loaded: form_helper
INFO - 2023-06-23 18:56:35 --> Database Driver Class Initialized
INFO - 2023-06-23 18:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 18:56:35 --> Form Validation Class Initialized
INFO - 2023-06-23 18:56:35 --> Controller Class Initialized
INFO - 2023-06-23 18:56:35 --> Model "m_datatest" initialized
INFO - 2023-06-23 18:56:35 --> Model "m_datatrain" initialized
INFO - 2023-06-23 18:56:35 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 18:56:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 18:56:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 18:56:37 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
INFO - 2023-06-23 18:56:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 18:56:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 18:56:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 18:56:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 18:56:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 18:56:37 --> Final output sent to browser
INFO - 2023-06-23 19:01:00 --> Config Class Initialized
INFO - 2023-06-23 19:01:00 --> Hooks Class Initialized
INFO - 2023-06-23 19:01:00 --> Utf8 Class Initialized
INFO - 2023-06-23 19:01:00 --> URI Class Initialized
INFO - 2023-06-23 19:01:00 --> Router Class Initialized
INFO - 2023-06-23 19:01:00 --> Output Class Initialized
INFO - 2023-06-23 19:01:00 --> Security Class Initialized
INFO - 2023-06-23 19:01:00 --> Input Class Initialized
INFO - 2023-06-23 19:01:00 --> Language Class Initialized
INFO - 2023-06-23 19:01:00 --> Loader Class Initialized
INFO - 2023-06-23 19:01:00 --> Helper loaded: url_helper
INFO - 2023-06-23 19:01:00 --> Helper loaded: form_helper
INFO - 2023-06-23 19:01:00 --> Database Driver Class Initialized
INFO - 2023-06-23 19:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:01:00 --> Form Validation Class Initialized
INFO - 2023-06-23 19:01:00 --> Controller Class Initialized
INFO - 2023-06-23 19:01:00 --> Model "m_datatest" initialized
INFO - 2023-06-23 19:01:00 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:01:00 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 19:01:01 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:01:01 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 19:01:02 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 822
INFO - 2023-06-23 19:03:27 --> Config Class Initialized
INFO - 2023-06-23 19:03:27 --> Hooks Class Initialized
INFO - 2023-06-23 19:03:27 --> Utf8 Class Initialized
INFO - 2023-06-23 19:03:27 --> URI Class Initialized
INFO - 2023-06-23 19:03:27 --> Router Class Initialized
INFO - 2023-06-23 19:03:27 --> Output Class Initialized
INFO - 2023-06-23 19:03:27 --> Security Class Initialized
INFO - 2023-06-23 19:03:27 --> Input Class Initialized
INFO - 2023-06-23 19:03:27 --> Language Class Initialized
INFO - 2023-06-23 19:03:27 --> Loader Class Initialized
INFO - 2023-06-23 19:03:27 --> Helper loaded: url_helper
INFO - 2023-06-23 19:03:27 --> Helper loaded: form_helper
INFO - 2023-06-23 19:03:27 --> Database Driver Class Initialized
INFO - 2023-06-23 19:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:03:27 --> Form Validation Class Initialized
INFO - 2023-06-23 19:03:27 --> Controller Class Initialized
INFO - 2023-06-23 19:03:27 --> Model "m_datatest" initialized
INFO - 2023-06-23 19:03:27 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:03:27 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 19:03:28 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:03:28 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B0 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B1 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B2 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B3 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B4 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B5 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B6 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B7 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B8 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B9 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B10 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B11 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B12 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B13 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B14 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B15 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B16 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B17 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B18 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B19 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-23 19:03:29 --> Severity: Notice --> Undefined index: B20 C:\xampp\htdocs\sistemdepresi\application\views\datatest\v_penghitungan.php 826
INFO - 2023-06-23 19:03:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 19:03:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:03:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:03:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:03:29 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:03:29 --> Final output sent to browser
INFO - 2023-06-23 19:04:17 --> Config Class Initialized
INFO - 2023-06-23 19:04:17 --> Hooks Class Initialized
INFO - 2023-06-23 19:04:17 --> Utf8 Class Initialized
INFO - 2023-06-23 19:04:17 --> URI Class Initialized
INFO - 2023-06-23 19:04:17 --> Router Class Initialized
INFO - 2023-06-23 19:04:17 --> Output Class Initialized
INFO - 2023-06-23 19:04:17 --> Security Class Initialized
INFO - 2023-06-23 19:04:17 --> Input Class Initialized
INFO - 2023-06-23 19:04:17 --> Language Class Initialized
INFO - 2023-06-23 19:04:17 --> Loader Class Initialized
INFO - 2023-06-23 19:04:17 --> Helper loaded: url_helper
INFO - 2023-06-23 19:04:17 --> Helper loaded: form_helper
INFO - 2023-06-23 19:04:17 --> Database Driver Class Initialized
INFO - 2023-06-23 19:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:04:17 --> Form Validation Class Initialized
INFO - 2023-06-23 19:04:17 --> Controller Class Initialized
INFO - 2023-06-23 19:04:17 --> Model "m_datatest" initialized
INFO - 2023-06-23 19:04:17 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:04:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 19:04:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:04:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:04:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 19:04:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:04:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:04:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:04:19 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:04:19 --> Final output sent to browser
INFO - 2023-06-23 19:05:47 --> Config Class Initialized
INFO - 2023-06-23 19:05:47 --> Hooks Class Initialized
INFO - 2023-06-23 19:05:47 --> Utf8 Class Initialized
INFO - 2023-06-23 19:05:47 --> URI Class Initialized
INFO - 2023-06-23 19:05:47 --> Router Class Initialized
INFO - 2023-06-23 19:05:47 --> Output Class Initialized
INFO - 2023-06-23 19:05:47 --> Security Class Initialized
INFO - 2023-06-23 19:05:47 --> Input Class Initialized
INFO - 2023-06-23 19:05:47 --> Language Class Initialized
INFO - 2023-06-23 19:05:47 --> Loader Class Initialized
INFO - 2023-06-23 19:05:47 --> Helper loaded: url_helper
INFO - 2023-06-23 19:05:47 --> Helper loaded: form_helper
INFO - 2023-06-23 19:05:47 --> Database Driver Class Initialized
INFO - 2023-06-23 19:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:05:47 --> Form Validation Class Initialized
INFO - 2023-06-23 19:05:47 --> Controller Class Initialized
INFO - 2023-06-23 19:05:47 --> Model "m_datatest" initialized
INFO - 2023-06-23 19:05:47 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:05:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 19:05:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:05:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:05:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 19:05:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:05:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:05:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:05:48 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:05:48 --> Final output sent to browser
INFO - 2023-06-23 19:07:52 --> Config Class Initialized
INFO - 2023-06-23 19:07:52 --> Hooks Class Initialized
INFO - 2023-06-23 19:07:52 --> Utf8 Class Initialized
INFO - 2023-06-23 19:07:52 --> URI Class Initialized
INFO - 2023-06-23 19:07:52 --> Router Class Initialized
INFO - 2023-06-23 19:07:52 --> Output Class Initialized
INFO - 2023-06-23 19:07:52 --> Security Class Initialized
INFO - 2023-06-23 19:07:52 --> Input Class Initialized
INFO - 2023-06-23 19:07:52 --> Language Class Initialized
INFO - 2023-06-23 19:07:52 --> Loader Class Initialized
INFO - 2023-06-23 19:07:52 --> Helper loaded: url_helper
INFO - 2023-06-23 19:07:52 --> Helper loaded: form_helper
INFO - 2023-06-23 19:07:52 --> Database Driver Class Initialized
INFO - 2023-06-23 19:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:07:52 --> Form Validation Class Initialized
INFO - 2023-06-23 19:07:52 --> Controller Class Initialized
INFO - 2023-06-23 19:07:52 --> Model "m_datatest" initialized
INFO - 2023-06-23 19:07:52 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:07:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 19:07:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:07:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:07:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 19:07:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:07:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:07:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:07:52 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:07:52 --> Final output sent to browser
INFO - 2023-06-23 19:08:03 --> Config Class Initialized
INFO - 2023-06-23 19:08:03 --> Hooks Class Initialized
INFO - 2023-06-23 19:08:03 --> Utf8 Class Initialized
INFO - 2023-06-23 19:08:03 --> URI Class Initialized
INFO - 2023-06-23 19:08:03 --> Router Class Initialized
INFO - 2023-06-23 19:08:03 --> Output Class Initialized
INFO - 2023-06-23 19:08:03 --> Security Class Initialized
INFO - 2023-06-23 19:08:03 --> Input Class Initialized
INFO - 2023-06-23 19:08:03 --> Language Class Initialized
INFO - 2023-06-23 19:08:03 --> Loader Class Initialized
INFO - 2023-06-23 19:08:03 --> Helper loaded: url_helper
INFO - 2023-06-23 19:08:03 --> Helper loaded: form_helper
INFO - 2023-06-23 19:08:03 --> Database Driver Class Initialized
INFO - 2023-06-23 19:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:08:03 --> Form Validation Class Initialized
INFO - 2023-06-23 19:08:03 --> Controller Class Initialized
INFO - 2023-06-23 19:08:03 --> Model "m_datatest" initialized
INFO - 2023-06-23 19:08:03 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:08:03 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 19:08:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:08:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:08:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_penghitungan.php
INFO - 2023-06-23 19:08:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:08:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:08:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:08:04 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:08:04 --> Final output sent to browser
INFO - 2023-06-23 19:08:13 --> Config Class Initialized
INFO - 2023-06-23 19:08:13 --> Hooks Class Initialized
INFO - 2023-06-23 19:08:13 --> Utf8 Class Initialized
INFO - 2023-06-23 19:08:13 --> URI Class Initialized
INFO - 2023-06-23 19:08:13 --> Router Class Initialized
INFO - 2023-06-23 19:08:13 --> Output Class Initialized
INFO - 2023-06-23 19:08:13 --> Security Class Initialized
INFO - 2023-06-23 19:08:13 --> Input Class Initialized
INFO - 2023-06-23 19:08:13 --> Language Class Initialized
INFO - 2023-06-23 19:08:13 --> Loader Class Initialized
INFO - 2023-06-23 19:08:13 --> Helper loaded: url_helper
INFO - 2023-06-23 19:08:13 --> Helper loaded: form_helper
INFO - 2023-06-23 19:08:13 --> Database Driver Class Initialized
INFO - 2023-06-23 19:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:08:13 --> Form Validation Class Initialized
INFO - 2023-06-23 19:08:13 --> Controller Class Initialized
INFO - 2023-06-23 19:08:13 --> Model "m_datatest" initialized
INFO - 2023-06-23 19:08:13 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:08:13 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 19:08:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:08:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:08:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 19:08:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:08:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:08:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:08:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:08:13 --> Final output sent to browser
INFO - 2023-06-23 19:08:22 --> Config Class Initialized
INFO - 2023-06-23 19:08:22 --> Hooks Class Initialized
INFO - 2023-06-23 19:08:22 --> Utf8 Class Initialized
INFO - 2023-06-23 19:08:22 --> URI Class Initialized
INFO - 2023-06-23 19:08:22 --> Router Class Initialized
INFO - 2023-06-23 19:08:22 --> Output Class Initialized
INFO - 2023-06-23 19:08:22 --> Security Class Initialized
INFO - 2023-06-23 19:08:22 --> Input Class Initialized
INFO - 2023-06-23 19:08:22 --> Language Class Initialized
INFO - 2023-06-23 19:08:22 --> Loader Class Initialized
INFO - 2023-06-23 19:08:22 --> Helper loaded: url_helper
INFO - 2023-06-23 19:08:22 --> Helper loaded: form_helper
INFO - 2023-06-23 19:08:22 --> Database Driver Class Initialized
INFO - 2023-06-23 19:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:08:22 --> Form Validation Class Initialized
INFO - 2023-06-23 19:08:22 --> Controller Class Initialized
INFO - 2023-06-23 19:08:22 --> Model "m_datatest" initialized
INFO - 2023-06-23 19:08:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:08:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:08:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\pengujian.php
INFO - 2023-06-23 19:08:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:08:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:08:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:08:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:08:22 --> Final output sent to browser
INFO - 2023-06-23 19:08:42 --> Config Class Initialized
INFO - 2023-06-23 19:08:42 --> Hooks Class Initialized
INFO - 2023-06-23 19:08:42 --> Utf8 Class Initialized
INFO - 2023-06-23 19:08:42 --> URI Class Initialized
INFO - 2023-06-23 19:08:42 --> Router Class Initialized
INFO - 2023-06-23 19:08:42 --> Output Class Initialized
INFO - 2023-06-23 19:08:42 --> Security Class Initialized
INFO - 2023-06-23 19:08:42 --> Input Class Initialized
INFO - 2023-06-23 19:08:42 --> Language Class Initialized
INFO - 2023-06-23 19:08:42 --> Loader Class Initialized
INFO - 2023-06-23 19:08:42 --> Helper loaded: url_helper
INFO - 2023-06-23 19:08:42 --> Helper loaded: form_helper
INFO - 2023-06-23 19:08:42 --> Database Driver Class Initialized
INFO - 2023-06-23 19:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:08:42 --> Form Validation Class Initialized
INFO - 2023-06-23 19:08:42 --> Controller Class Initialized
INFO - 2023-06-23 19:08:42 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:08:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:08:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:08:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 19:08:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:08:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:08:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:08:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:08:42 --> Final output sent to browser
INFO - 2023-06-23 19:20:37 --> Config Class Initialized
INFO - 2023-06-23 19:20:37 --> Hooks Class Initialized
INFO - 2023-06-23 19:20:37 --> Utf8 Class Initialized
INFO - 2023-06-23 19:20:37 --> URI Class Initialized
INFO - 2023-06-23 19:20:37 --> Router Class Initialized
INFO - 2023-06-23 19:20:37 --> Output Class Initialized
INFO - 2023-06-23 19:20:37 --> Security Class Initialized
INFO - 2023-06-23 19:20:37 --> Input Class Initialized
INFO - 2023-06-23 19:20:37 --> Language Class Initialized
INFO - 2023-06-23 19:20:37 --> Loader Class Initialized
INFO - 2023-06-23 19:20:37 --> Helper loaded: url_helper
INFO - 2023-06-23 19:20:37 --> Helper loaded: form_helper
INFO - 2023-06-23 19:20:37 --> Database Driver Class Initialized
INFO - 2023-06-23 19:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:20:37 --> Form Validation Class Initialized
INFO - 2023-06-23 19:20:37 --> Controller Class Initialized
INFO - 2023-06-23 19:20:37 --> Model "m_user" initialized
INFO - 2023-06-23 19:20:37 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:20:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:20:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:20:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:20:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:20:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:20:37 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home.php
INFO - 2023-06-23 19:20:37 --> Final output sent to browser
INFO - 2023-06-23 19:20:40 --> Config Class Initialized
INFO - 2023-06-23 19:20:40 --> Hooks Class Initialized
INFO - 2023-06-23 19:20:40 --> Utf8 Class Initialized
INFO - 2023-06-23 19:20:40 --> URI Class Initialized
INFO - 2023-06-23 19:20:40 --> Router Class Initialized
INFO - 2023-06-23 19:20:40 --> Output Class Initialized
INFO - 2023-06-23 19:20:40 --> Security Class Initialized
INFO - 2023-06-23 19:20:40 --> Input Class Initialized
INFO - 2023-06-23 19:20:40 --> Language Class Initialized
INFO - 2023-06-23 19:20:40 --> Loader Class Initialized
INFO - 2023-06-23 19:20:40 --> Helper loaded: url_helper
INFO - 2023-06-23 19:20:40 --> Helper loaded: form_helper
INFO - 2023-06-23 19:20:40 --> Database Driver Class Initialized
INFO - 2023-06-23 19:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:20:40 --> Form Validation Class Initialized
INFO - 2023-06-23 19:20:40 --> Controller Class Initialized
INFO - 2023-06-23 19:20:40 --> Model "m_user" initialized
INFO - 2023-06-23 19:20:40 --> Config Class Initialized
INFO - 2023-06-23 19:20:40 --> Hooks Class Initialized
INFO - 2023-06-23 19:20:40 --> Utf8 Class Initialized
INFO - 2023-06-23 19:20:40 --> URI Class Initialized
INFO - 2023-06-23 19:20:40 --> Router Class Initialized
INFO - 2023-06-23 19:20:40 --> Output Class Initialized
INFO - 2023-06-23 19:20:40 --> Security Class Initialized
INFO - 2023-06-23 19:20:40 --> Input Class Initialized
INFO - 2023-06-23 19:20:40 --> Language Class Initialized
INFO - 2023-06-23 19:20:40 --> Loader Class Initialized
INFO - 2023-06-23 19:20:40 --> Helper loaded: url_helper
INFO - 2023-06-23 19:20:40 --> Helper loaded: form_helper
INFO - 2023-06-23 19:20:40 --> Database Driver Class Initialized
INFO - 2023-06-23 19:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:20:40 --> Form Validation Class Initialized
INFO - 2023-06-23 19:20:40 --> Controller Class Initialized
INFO - 2023-06-23 19:20:40 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-23 19:20:40 --> Final output sent to browser
INFO - 2023-06-23 19:20:41 --> Config Class Initialized
INFO - 2023-06-23 19:20:41 --> Hooks Class Initialized
INFO - 2023-06-23 19:20:41 --> Utf8 Class Initialized
INFO - 2023-06-23 19:20:41 --> URI Class Initialized
INFO - 2023-06-23 19:20:41 --> Router Class Initialized
INFO - 2023-06-23 19:20:41 --> Output Class Initialized
INFO - 2023-06-23 19:20:41 --> Security Class Initialized
INFO - 2023-06-23 19:20:41 --> Input Class Initialized
INFO - 2023-06-23 19:20:41 --> Language Class Initialized
INFO - 2023-06-23 19:20:41 --> Loader Class Initialized
INFO - 2023-06-23 19:20:41 --> Helper loaded: url_helper
INFO - 2023-06-23 19:20:41 --> Helper loaded: form_helper
INFO - 2023-06-23 19:20:41 --> Database Driver Class Initialized
INFO - 2023-06-23 19:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:20:41 --> Form Validation Class Initialized
INFO - 2023-06-23 19:20:41 --> Controller Class Initialized
INFO - 2023-06-23 19:20:41 --> Model "m_user" initialized
INFO - 2023-06-23 19:20:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:20:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:20:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-23 19:20:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:20:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:20:41 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-23 19:20:41 --> Final output sent to browser
INFO - 2023-06-23 19:51:37 --> Config Class Initialized
INFO - 2023-06-23 19:51:37 --> Hooks Class Initialized
INFO - 2023-06-23 19:51:37 --> Utf8 Class Initialized
INFO - 2023-06-23 19:51:37 --> URI Class Initialized
INFO - 2023-06-23 19:51:37 --> Router Class Initialized
INFO - 2023-06-23 19:51:37 --> Output Class Initialized
INFO - 2023-06-23 19:51:38 --> Security Class Initialized
INFO - 2023-06-23 19:51:38 --> Input Class Initialized
INFO - 2023-06-23 19:51:38 --> Language Class Initialized
INFO - 2023-06-23 19:51:38 --> Loader Class Initialized
INFO - 2023-06-23 19:51:38 --> Helper loaded: url_helper
INFO - 2023-06-23 19:51:38 --> Helper loaded: form_helper
INFO - 2023-06-23 19:51:38 --> Database Driver Class Initialized
INFO - 2023-06-23 19:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:51:38 --> Form Validation Class Initialized
INFO - 2023-06-23 19:51:38 --> Controller Class Initialized
INFO - 2023-06-23 19:51:38 --> Model "m_user" initialized
INFO - 2023-06-23 19:51:38 --> Config Class Initialized
INFO - 2023-06-23 19:51:38 --> Hooks Class Initialized
INFO - 2023-06-23 19:51:38 --> Utf8 Class Initialized
INFO - 2023-06-23 19:51:38 --> URI Class Initialized
INFO - 2023-06-23 19:51:38 --> Router Class Initialized
INFO - 2023-06-23 19:51:38 --> Output Class Initialized
INFO - 2023-06-23 19:51:38 --> Security Class Initialized
INFO - 2023-06-23 19:51:38 --> Input Class Initialized
INFO - 2023-06-23 19:51:38 --> Language Class Initialized
INFO - 2023-06-23 19:51:38 --> Loader Class Initialized
INFO - 2023-06-23 19:51:38 --> Helper loaded: url_helper
INFO - 2023-06-23 19:51:38 --> Helper loaded: form_helper
INFO - 2023-06-23 19:51:38 --> Database Driver Class Initialized
INFO - 2023-06-23 19:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:51:38 --> Form Validation Class Initialized
INFO - 2023-06-23 19:51:38 --> Controller Class Initialized
INFO - 2023-06-23 19:51:38 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-23 19:51:38 --> Final output sent to browser
INFO - 2023-06-23 19:51:39 --> Config Class Initialized
INFO - 2023-06-23 19:51:39 --> Hooks Class Initialized
INFO - 2023-06-23 19:51:39 --> Utf8 Class Initialized
INFO - 2023-06-23 19:51:39 --> URI Class Initialized
INFO - 2023-06-23 19:51:39 --> Router Class Initialized
INFO - 2023-06-23 19:51:39 --> Output Class Initialized
INFO - 2023-06-23 19:51:39 --> Security Class Initialized
INFO - 2023-06-23 19:51:39 --> Input Class Initialized
INFO - 2023-06-23 19:51:39 --> Language Class Initialized
INFO - 2023-06-23 19:51:39 --> Loader Class Initialized
INFO - 2023-06-23 19:51:39 --> Helper loaded: url_helper
INFO - 2023-06-23 19:51:39 --> Helper loaded: form_helper
INFO - 2023-06-23 19:51:39 --> Database Driver Class Initialized
INFO - 2023-06-23 19:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:51:39 --> Form Validation Class Initialized
INFO - 2023-06-23 19:51:39 --> Controller Class Initialized
INFO - 2023-06-23 19:51:39 --> Model "m_user" initialized
INFO - 2023-06-23 19:51:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_header.php
INFO - 2023-06-23 19:51:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\auth/login.php
INFO - 2023-06-23 19:51:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\templates/auth_footer.php
INFO - 2023-06-23 19:51:39 --> Final output sent to browser
INFO - 2023-06-23 19:51:42 --> Config Class Initialized
INFO - 2023-06-23 19:51:42 --> Hooks Class Initialized
INFO - 2023-06-23 19:51:42 --> Utf8 Class Initialized
INFO - 2023-06-23 19:51:42 --> URI Class Initialized
INFO - 2023-06-23 19:51:42 --> Router Class Initialized
INFO - 2023-06-23 19:51:42 --> Output Class Initialized
INFO - 2023-06-23 19:51:42 --> Security Class Initialized
INFO - 2023-06-23 19:51:42 --> Input Class Initialized
INFO - 2023-06-23 19:51:42 --> Language Class Initialized
INFO - 2023-06-23 19:51:42 --> Loader Class Initialized
INFO - 2023-06-23 19:51:42 --> Helper loaded: url_helper
INFO - 2023-06-23 19:51:42 --> Helper loaded: form_helper
INFO - 2023-06-23 19:51:42 --> Database Driver Class Initialized
INFO - 2023-06-23 19:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:51:42 --> Form Validation Class Initialized
INFO - 2023-06-23 19:51:42 --> Controller Class Initialized
INFO - 2023-06-23 19:51:42 --> Model "m_user" initialized
INFO - 2023-06-23 19:51:43 --> Config Class Initialized
INFO - 2023-06-23 19:51:43 --> Hooks Class Initialized
INFO - 2023-06-23 19:51:43 --> Utf8 Class Initialized
INFO - 2023-06-23 19:51:43 --> URI Class Initialized
INFO - 2023-06-23 19:51:43 --> Router Class Initialized
INFO - 2023-06-23 19:51:43 --> Output Class Initialized
INFO - 2023-06-23 19:51:43 --> Security Class Initialized
INFO - 2023-06-23 19:51:43 --> Input Class Initialized
INFO - 2023-06-23 19:51:43 --> Language Class Initialized
INFO - 2023-06-23 19:51:43 --> Loader Class Initialized
INFO - 2023-06-23 19:51:43 --> Helper loaded: url_helper
INFO - 2023-06-23 19:51:43 --> Helper loaded: form_helper
INFO - 2023-06-23 19:51:43 --> Database Driver Class Initialized
INFO - 2023-06-23 19:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:51:43 --> Form Validation Class Initialized
INFO - 2023-06-23 19:51:43 --> Controller Class Initialized
INFO - 2023-06-23 19:51:43 --> Model "m_user" initialized
INFO - 2023-06-23 19:51:43 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:51:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:51:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:51:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:51:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:51:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:51:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home.php
INFO - 2023-06-23 19:51:43 --> Final output sent to browser
INFO - 2023-06-23 19:51:44 --> Config Class Initialized
INFO - 2023-06-23 19:51:44 --> Hooks Class Initialized
INFO - 2023-06-23 19:51:44 --> Utf8 Class Initialized
INFO - 2023-06-23 19:51:44 --> URI Class Initialized
INFO - 2023-06-23 19:51:44 --> Router Class Initialized
INFO - 2023-06-23 19:51:44 --> Output Class Initialized
INFO - 2023-06-23 19:51:44 --> Security Class Initialized
INFO - 2023-06-23 19:51:44 --> Input Class Initialized
INFO - 2023-06-23 19:51:44 --> Language Class Initialized
INFO - 2023-06-23 19:51:44 --> Loader Class Initialized
INFO - 2023-06-23 19:51:44 --> Helper loaded: url_helper
INFO - 2023-06-23 19:51:44 --> Helper loaded: form_helper
INFO - 2023-06-23 19:51:44 --> Database Driver Class Initialized
INFO - 2023-06-23 19:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:51:44 --> Form Validation Class Initialized
INFO - 2023-06-23 19:51:44 --> Controller Class Initialized
INFO - 2023-06-23 19:51:44 --> Model "m_datatest" initialized
INFO - 2023-06-23 19:51:44 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:51:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:51:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:51:45 --> Final output sent to browser
INFO - 2023-06-23 19:51:46 --> Config Class Initialized
INFO - 2023-06-23 19:51:46 --> Hooks Class Initialized
INFO - 2023-06-23 19:51:46 --> Utf8 Class Initialized
INFO - 2023-06-23 19:51:46 --> URI Class Initialized
INFO - 2023-06-23 19:51:46 --> Router Class Initialized
INFO - 2023-06-23 19:51:46 --> Output Class Initialized
INFO - 2023-06-23 19:51:46 --> Security Class Initialized
INFO - 2023-06-23 19:51:46 --> Input Class Initialized
INFO - 2023-06-23 19:51:46 --> Language Class Initialized
INFO - 2023-06-23 19:51:46 --> Loader Class Initialized
INFO - 2023-06-23 19:51:46 --> Helper loaded: url_helper
INFO - 2023-06-23 19:51:46 --> Helper loaded: form_helper
INFO - 2023-06-23 19:51:46 --> Database Driver Class Initialized
INFO - 2023-06-23 19:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:51:46 --> Form Validation Class Initialized
INFO - 2023-06-23 19:51:46 --> Controller Class Initialized
INFO - 2023-06-23 19:51:46 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:51:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:51:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:51:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 19:51:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:51:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:51:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:51:47 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:51:47 --> Final output sent to browser
INFO - 2023-06-23 19:51:58 --> Config Class Initialized
INFO - 2023-06-23 19:51:58 --> Hooks Class Initialized
INFO - 2023-06-23 19:51:58 --> Utf8 Class Initialized
INFO - 2023-06-23 19:51:58 --> URI Class Initialized
INFO - 2023-06-23 19:51:59 --> Router Class Initialized
INFO - 2023-06-23 19:51:59 --> Output Class Initialized
INFO - 2023-06-23 19:51:59 --> Security Class Initialized
INFO - 2023-06-23 19:51:59 --> Input Class Initialized
INFO - 2023-06-23 19:51:59 --> Language Class Initialized
INFO - 2023-06-23 19:51:59 --> Loader Class Initialized
INFO - 2023-06-23 19:51:59 --> Helper loaded: url_helper
INFO - 2023-06-23 19:51:59 --> Helper loaded: form_helper
INFO - 2023-06-23 19:51:59 --> Database Driver Class Initialized
INFO - 2023-06-23 19:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:51:59 --> Form Validation Class Initialized
INFO - 2023-06-23 19:51:59 --> Controller Class Initialized
INFO - 2023-06-23 19:51:59 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:51:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:51:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:51:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatrain/v_datatrain.php
INFO - 2023-06-23 19:51:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:51:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:51:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:51:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:51:59 --> Final output sent to browser
INFO - 2023-06-23 19:52:06 --> Config Class Initialized
INFO - 2023-06-23 19:52:06 --> Hooks Class Initialized
INFO - 2023-06-23 19:52:06 --> Utf8 Class Initialized
INFO - 2023-06-23 19:52:06 --> URI Class Initialized
INFO - 2023-06-23 19:52:06 --> Router Class Initialized
INFO - 2023-06-23 19:52:06 --> Output Class Initialized
INFO - 2023-06-23 19:52:06 --> Security Class Initialized
INFO - 2023-06-23 19:52:06 --> Input Class Initialized
INFO - 2023-06-23 19:52:06 --> Language Class Initialized
INFO - 2023-06-23 19:52:06 --> Loader Class Initialized
INFO - 2023-06-23 19:52:06 --> Helper loaded: url_helper
INFO - 2023-06-23 19:52:06 --> Helper loaded: form_helper
INFO - 2023-06-23 19:52:06 --> Database Driver Class Initialized
INFO - 2023-06-23 19:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 19:52:06 --> Form Validation Class Initialized
INFO - 2023-06-23 19:52:06 --> Controller Class Initialized
INFO - 2023-06-23 19:52:06 --> Model "m_datatest" initialized
INFO - 2023-06-23 19:52:06 --> Model "m_datatrain" initialized
INFO - 2023-06-23 19:52:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-23 19:52:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-23 19:52:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-23 19:52:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\datatest/v_datatest.php
INFO - 2023-06-23 19:52:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar.php
INFO - 2023-06-23 19:52:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-23 19:52:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-23 19:52:06 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template.php
INFO - 2023-06-23 19:52:06 --> Final output sent to browser
