<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-30 10:31:40 --> Config Class Initialized
INFO - 2023-03-30 10:31:40 --> Hooks Class Initialized
INFO - 2023-03-30 10:31:40 --> Utf8 Class Initialized
INFO - 2023-03-30 10:31:40 --> URI Class Initialized
INFO - 2023-03-30 10:31:40 --> Router Class Initialized
INFO - 2023-03-30 10:31:40 --> Output Class Initialized
INFO - 2023-03-30 10:31:40 --> Security Class Initialized
INFO - 2023-03-30 10:31:40 --> Input Class Initialized
INFO - 2023-03-30 10:31:40 --> Language Class Initialized
INFO - 2023-03-30 10:31:40 --> Loader Class Initialized
INFO - 2023-03-30 10:31:40 --> Helper loaded: url_helper
INFO - 2023-03-30 10:31:40 --> Helper loaded: form_helper
INFO - 2023-03-30 10:31:40 --> Database Driver Class Initialized
INFO - 2023-03-30 10:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-30 10:31:40 --> Form Validation Class Initialized
INFO - 2023-03-30 10:31:40 --> Controller Class Initialized
INFO - 2023-03-30 10:31:40 --> Model "M_tutor" initialized
INFO - 2023-03-30 10:31:40 --> File loaded: C:\xampp\htdocs\lisa-todo1\application\views\templates/auth_header.php
INFO - 2023-03-30 10:31:40 --> File loaded: C:\xampp\htdocs\lisa-todo1\application\views\auth/login.php
INFO - 2023-03-30 10:31:40 --> File loaded: C:\xampp\htdocs\lisa-todo1\application\views\templates/auth_footer.php
INFO - 2023-03-30 10:31:40 --> Final output sent to browser
