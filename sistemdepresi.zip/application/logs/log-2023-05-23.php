<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-23 08:54:23 --> Config Class Initialized
INFO - 2023-05-23 08:54:23 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:23 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:23 --> URI Class Initialized
INFO - 2023-05-23 08:54:23 --> Router Class Initialized
INFO - 2023-05-23 08:54:23 --> Output Class Initialized
INFO - 2023-05-23 08:54:23 --> Security Class Initialized
INFO - 2023-05-23 08:54:23 --> Input Class Initialized
INFO - 2023-05-23 08:54:23 --> Language Class Initialized
INFO - 2023-05-23 08:54:23 --> Loader Class Initialized
INFO - 2023-05-23 08:54:23 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:23 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:24 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:24 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:24 --> Controller Class Initialized
INFO - 2023-05-23 08:54:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-23 08:54:24 --> Final output sent to browser
INFO - 2023-05-23 08:54:25 --> Config Class Initialized
INFO - 2023-05-23 08:54:25 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:25 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:25 --> URI Class Initialized
INFO - 2023-05-23 08:54:25 --> Router Class Initialized
INFO - 2023-05-23 08:54:25 --> Output Class Initialized
INFO - 2023-05-23 08:54:25 --> Security Class Initialized
INFO - 2023-05-23 08:54:25 --> Input Class Initialized
INFO - 2023-05-23 08:54:25 --> Language Class Initialized
INFO - 2023-05-23 08:54:25 --> Loader Class Initialized
INFO - 2023-05-23 08:54:25 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:25 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:25 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:25 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:25 --> Controller Class Initialized
INFO - 2023-05-23 08:54:25 --> Model "m_user" initialized
INFO - 2023-05-23 08:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-23 08:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-23 08:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-23 08:54:25 --> Final output sent to browser
INFO - 2023-05-23 08:54:28 --> Config Class Initialized
INFO - 2023-05-23 08:54:28 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:28 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:28 --> URI Class Initialized
INFO - 2023-05-23 08:54:28 --> Router Class Initialized
INFO - 2023-05-23 08:54:28 --> Output Class Initialized
INFO - 2023-05-23 08:54:28 --> Security Class Initialized
INFO - 2023-05-23 08:54:28 --> Input Class Initialized
INFO - 2023-05-23 08:54:28 --> Language Class Initialized
INFO - 2023-05-23 08:54:28 --> Loader Class Initialized
INFO - 2023-05-23 08:54:28 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:28 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:28 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:28 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:28 --> Controller Class Initialized
INFO - 2023-05-23 08:54:28 --> Model "m_user" initialized
INFO - 2023-05-23 08:54:28 --> Config Class Initialized
INFO - 2023-05-23 08:54:28 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:28 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:28 --> URI Class Initialized
INFO - 2023-05-23 08:54:28 --> Router Class Initialized
INFO - 2023-05-23 08:54:28 --> Output Class Initialized
INFO - 2023-05-23 08:54:28 --> Security Class Initialized
INFO - 2023-05-23 08:54:28 --> Input Class Initialized
INFO - 2023-05-23 08:54:28 --> Language Class Initialized
INFO - 2023-05-23 08:54:28 --> Loader Class Initialized
INFO - 2023-05-23 08:54:28 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:28 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:28 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:28 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:28 --> Controller Class Initialized
INFO - 2023-05-23 08:54:28 --> Model "m_user" initialized
INFO - 2023-05-23 08:54:28 --> Model "m_datatrain" initialized
INFO - 2023-05-23 08:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 08:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 08:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 08:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 08:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 08:54:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 08:54:29 --> Final output sent to browser
INFO - 2023-05-23 08:54:31 --> Config Class Initialized
INFO - 2023-05-23 08:54:31 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:31 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:31 --> URI Class Initialized
INFO - 2023-05-23 08:54:31 --> Router Class Initialized
INFO - 2023-05-23 08:54:31 --> Output Class Initialized
INFO - 2023-05-23 08:54:31 --> Security Class Initialized
INFO - 2023-05-23 08:54:31 --> Input Class Initialized
INFO - 2023-05-23 08:54:31 --> Language Class Initialized
INFO - 2023-05-23 08:54:31 --> Loader Class Initialized
INFO - 2023-05-23 08:54:31 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:31 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:31 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:31 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:31 --> Controller Class Initialized
INFO - 2023-05-23 08:54:31 --> Model "m_datatest" initialized
INFO - 2023-05-23 08:54:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 08:54:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 08:54:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-23 08:54:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 08:54:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 08:54:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 08:54:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 08:54:31 --> Final output sent to browser
INFO - 2023-05-23 08:54:36 --> Config Class Initialized
INFO - 2023-05-23 08:54:36 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:36 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:36 --> URI Class Initialized
INFO - 2023-05-23 08:54:36 --> Router Class Initialized
INFO - 2023-05-23 08:54:36 --> Output Class Initialized
INFO - 2023-05-23 08:54:36 --> Security Class Initialized
INFO - 2023-05-23 08:54:36 --> Input Class Initialized
INFO - 2023-05-23 08:54:36 --> Language Class Initialized
INFO - 2023-05-23 08:54:36 --> Loader Class Initialized
INFO - 2023-05-23 08:54:36 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:36 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:36 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:36 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:36 --> Controller Class Initialized
INFO - 2023-05-23 08:54:36 --> Model "m_datatrain" initialized
INFO - 2023-05-23 08:54:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 08:54:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 08:54:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-23 08:54:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 08:54:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 08:54:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 08:54:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 08:54:37 --> Final output sent to browser
INFO - 2023-05-23 08:54:38 --> Config Class Initialized
INFO - 2023-05-23 08:54:38 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:38 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:38 --> URI Class Initialized
INFO - 2023-05-23 08:54:38 --> Router Class Initialized
INFO - 2023-05-23 08:54:38 --> Output Class Initialized
INFO - 2023-05-23 08:54:38 --> Security Class Initialized
INFO - 2023-05-23 08:54:38 --> Input Class Initialized
INFO - 2023-05-23 08:54:38 --> Language Class Initialized
INFO - 2023-05-23 08:54:38 --> Loader Class Initialized
INFO - 2023-05-23 08:54:38 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:38 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:38 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:38 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:38 --> Controller Class Initialized
INFO - 2023-05-23 08:54:38 --> Model "m_user" initialized
INFO - 2023-05-23 08:54:38 --> Config Class Initialized
INFO - 2023-05-23 08:54:38 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:38 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:38 --> URI Class Initialized
INFO - 2023-05-23 08:54:38 --> Router Class Initialized
INFO - 2023-05-23 08:54:38 --> Output Class Initialized
INFO - 2023-05-23 08:54:38 --> Security Class Initialized
INFO - 2023-05-23 08:54:38 --> Input Class Initialized
INFO - 2023-05-23 08:54:38 --> Language Class Initialized
INFO - 2023-05-23 08:54:38 --> Loader Class Initialized
INFO - 2023-05-23 08:54:38 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:38 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:38 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:38 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:38 --> Controller Class Initialized
INFO - 2023-05-23 08:54:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-23 08:54:38 --> Final output sent to browser
INFO - 2023-05-23 08:54:40 --> Config Class Initialized
INFO - 2023-05-23 08:54:40 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:40 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:40 --> URI Class Initialized
INFO - 2023-05-23 08:54:40 --> Router Class Initialized
INFO - 2023-05-23 08:54:40 --> Output Class Initialized
INFO - 2023-05-23 08:54:40 --> Security Class Initialized
INFO - 2023-05-23 08:54:40 --> Input Class Initialized
INFO - 2023-05-23 08:54:40 --> Language Class Initialized
INFO - 2023-05-23 08:54:40 --> Loader Class Initialized
INFO - 2023-05-23 08:54:40 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:40 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:40 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:40 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:40 --> Controller Class Initialized
INFO - 2023-05-23 08:54:40 --> Model "m_user" initialized
INFO - 2023-05-23 08:54:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 08:54:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 08:54:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 08:54:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 08:54:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 08:54:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-23 08:54:40 --> Final output sent to browser
INFO - 2023-05-23 08:54:43 --> Config Class Initialized
INFO - 2023-05-23 08:54:43 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:43 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:43 --> URI Class Initialized
INFO - 2023-05-23 08:54:43 --> Router Class Initialized
INFO - 2023-05-23 08:54:43 --> Output Class Initialized
INFO - 2023-05-23 08:54:43 --> Security Class Initialized
INFO - 2023-05-23 08:54:43 --> Input Class Initialized
INFO - 2023-05-23 08:54:43 --> Language Class Initialized
INFO - 2023-05-23 08:54:43 --> Loader Class Initialized
INFO - 2023-05-23 08:54:43 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:43 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:43 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:43 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:43 --> Controller Class Initialized
INFO - 2023-05-23 08:54:43 --> Model "m_datatrain" initialized
INFO - 2023-05-23 08:54:43 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 08:54:43 --> Model "m_datatest" initialized
INFO - 2023-05-23 08:54:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 08:54:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 08:54:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-23 08:54:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 08:54:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 08:54:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 08:54:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-23 08:54:43 --> Final output sent to browser
INFO - 2023-05-23 08:54:44 --> Config Class Initialized
INFO - 2023-05-23 08:54:44 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:44 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:44 --> URI Class Initialized
INFO - 2023-05-23 08:54:44 --> Router Class Initialized
INFO - 2023-05-23 08:54:44 --> Output Class Initialized
INFO - 2023-05-23 08:54:44 --> Security Class Initialized
INFO - 2023-05-23 08:54:44 --> Input Class Initialized
INFO - 2023-05-23 08:54:44 --> Language Class Initialized
INFO - 2023-05-23 08:54:44 --> Loader Class Initialized
INFO - 2023-05-23 08:54:44 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:44 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:44 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:44 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:44 --> Controller Class Initialized
INFO - 2023-05-23 08:54:44 --> Model "m_user" initialized
INFO - 2023-05-23 08:54:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 08:54:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 08:54:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 08:54:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 08:54:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 08:54:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-23 08:54:44 --> Final output sent to browser
INFO - 2023-05-23 08:54:45 --> Config Class Initialized
INFO - 2023-05-23 08:54:45 --> Hooks Class Initialized
INFO - 2023-05-23 08:54:45 --> Utf8 Class Initialized
INFO - 2023-05-23 08:54:45 --> URI Class Initialized
INFO - 2023-05-23 08:54:45 --> Router Class Initialized
INFO - 2023-05-23 08:54:45 --> Output Class Initialized
INFO - 2023-05-23 08:54:45 --> Security Class Initialized
INFO - 2023-05-23 08:54:45 --> Input Class Initialized
INFO - 2023-05-23 08:54:45 --> Language Class Initialized
INFO - 2023-05-23 08:54:45 --> Loader Class Initialized
INFO - 2023-05-23 08:54:45 --> Helper loaded: url_helper
INFO - 2023-05-23 08:54:45 --> Helper loaded: form_helper
INFO - 2023-05-23 08:54:45 --> Database Driver Class Initialized
INFO - 2023-05-23 08:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:54:45 --> Form Validation Class Initialized
INFO - 2023-05-23 08:54:45 --> Controller Class Initialized
INFO - 2023-05-23 08:54:45 --> Model "m_datatrain" initialized
INFO - 2023-05-23 08:54:45 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 08:54:45 --> Model "m_datatest" initialized
INFO - 2023-05-23 08:54:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 08:54:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 08:54:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-23 08:54:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 08:54:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 08:54:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 08:54:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-23 08:54:45 --> Final output sent to browser
INFO - 2023-05-23 08:55:16 --> Config Class Initialized
INFO - 2023-05-23 08:55:16 --> Hooks Class Initialized
INFO - 2023-05-23 08:55:16 --> Utf8 Class Initialized
INFO - 2023-05-23 08:55:16 --> URI Class Initialized
INFO - 2023-05-23 08:55:16 --> Router Class Initialized
INFO - 2023-05-23 08:55:16 --> Output Class Initialized
INFO - 2023-05-23 08:55:16 --> Security Class Initialized
INFO - 2023-05-23 08:55:16 --> Input Class Initialized
INFO - 2023-05-23 08:55:16 --> Language Class Initialized
INFO - 2023-05-23 08:55:16 --> Loader Class Initialized
INFO - 2023-05-23 08:55:16 --> Helper loaded: url_helper
INFO - 2023-05-23 08:55:16 --> Helper loaded: form_helper
INFO - 2023-05-23 08:55:16 --> Database Driver Class Initialized
INFO - 2023-05-23 08:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:55:16 --> Form Validation Class Initialized
INFO - 2023-05-23 08:55:16 --> Controller Class Initialized
INFO - 2023-05-23 08:55:16 --> Model "m_user" initialized
INFO - 2023-05-23 08:55:16 --> Config Class Initialized
INFO - 2023-05-23 08:55:16 --> Hooks Class Initialized
INFO - 2023-05-23 08:55:16 --> Utf8 Class Initialized
INFO - 2023-05-23 08:55:16 --> URI Class Initialized
INFO - 2023-05-23 08:55:16 --> Router Class Initialized
INFO - 2023-05-23 08:55:16 --> Output Class Initialized
INFO - 2023-05-23 08:55:16 --> Security Class Initialized
INFO - 2023-05-23 08:55:16 --> Input Class Initialized
INFO - 2023-05-23 08:55:16 --> Language Class Initialized
INFO - 2023-05-23 08:55:16 --> Loader Class Initialized
INFO - 2023-05-23 08:55:16 --> Helper loaded: url_helper
INFO - 2023-05-23 08:55:16 --> Helper loaded: form_helper
INFO - 2023-05-23 08:55:16 --> Database Driver Class Initialized
INFO - 2023-05-23 08:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:55:16 --> Form Validation Class Initialized
INFO - 2023-05-23 08:55:16 --> Controller Class Initialized
INFO - 2023-05-23 08:55:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-23 08:55:16 --> Final output sent to browser
INFO - 2023-05-23 08:55:17 --> Config Class Initialized
INFO - 2023-05-23 08:55:17 --> Hooks Class Initialized
INFO - 2023-05-23 08:55:17 --> Utf8 Class Initialized
INFO - 2023-05-23 08:55:17 --> URI Class Initialized
INFO - 2023-05-23 08:55:17 --> Router Class Initialized
INFO - 2023-05-23 08:55:17 --> Output Class Initialized
INFO - 2023-05-23 08:55:17 --> Security Class Initialized
INFO - 2023-05-23 08:55:17 --> Input Class Initialized
INFO - 2023-05-23 08:55:17 --> Language Class Initialized
INFO - 2023-05-23 08:55:17 --> Loader Class Initialized
INFO - 2023-05-23 08:55:17 --> Helper loaded: url_helper
INFO - 2023-05-23 08:55:17 --> Helper loaded: form_helper
INFO - 2023-05-23 08:55:17 --> Database Driver Class Initialized
INFO - 2023-05-23 08:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:55:17 --> Form Validation Class Initialized
INFO - 2023-05-23 08:55:17 --> Controller Class Initialized
INFO - 2023-05-23 08:55:17 --> Model "m_user" initialized
INFO - 2023-05-23 08:55:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-23 08:55:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-23 08:55:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-23 08:55:17 --> Final output sent to browser
INFO - 2023-05-23 08:55:20 --> Config Class Initialized
INFO - 2023-05-23 08:55:20 --> Hooks Class Initialized
INFO - 2023-05-23 08:55:20 --> Utf8 Class Initialized
INFO - 2023-05-23 08:55:20 --> URI Class Initialized
INFO - 2023-05-23 08:55:20 --> Router Class Initialized
INFO - 2023-05-23 08:55:20 --> Output Class Initialized
INFO - 2023-05-23 08:55:20 --> Security Class Initialized
INFO - 2023-05-23 08:55:20 --> Input Class Initialized
INFO - 2023-05-23 08:55:20 --> Language Class Initialized
INFO - 2023-05-23 08:55:20 --> Loader Class Initialized
INFO - 2023-05-23 08:55:20 --> Helper loaded: url_helper
INFO - 2023-05-23 08:55:20 --> Helper loaded: form_helper
INFO - 2023-05-23 08:55:20 --> Database Driver Class Initialized
INFO - 2023-05-23 08:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:55:20 --> Form Validation Class Initialized
INFO - 2023-05-23 08:55:20 --> Controller Class Initialized
INFO - 2023-05-23 08:55:20 --> Model "m_user" initialized
INFO - 2023-05-23 08:55:20 --> Config Class Initialized
INFO - 2023-05-23 08:55:20 --> Hooks Class Initialized
INFO - 2023-05-23 08:55:20 --> Utf8 Class Initialized
INFO - 2023-05-23 08:55:20 --> URI Class Initialized
INFO - 2023-05-23 08:55:20 --> Router Class Initialized
INFO - 2023-05-23 08:55:20 --> Output Class Initialized
INFO - 2023-05-23 08:55:20 --> Security Class Initialized
INFO - 2023-05-23 08:55:20 --> Input Class Initialized
INFO - 2023-05-23 08:55:20 --> Language Class Initialized
INFO - 2023-05-23 08:55:20 --> Loader Class Initialized
INFO - 2023-05-23 08:55:21 --> Helper loaded: url_helper
INFO - 2023-05-23 08:55:21 --> Helper loaded: form_helper
INFO - 2023-05-23 08:55:21 --> Database Driver Class Initialized
INFO - 2023-05-23 08:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:55:21 --> Form Validation Class Initialized
INFO - 2023-05-23 08:55:21 --> Controller Class Initialized
INFO - 2023-05-23 08:55:21 --> Model "m_user" initialized
INFO - 2023-05-23 08:55:21 --> Model "m_datatrain" initialized
INFO - 2023-05-23 08:55:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 08:55:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 08:55:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 08:55:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 08:55:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 08:55:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 08:55:21 --> Final output sent to browser
INFO - 2023-05-23 08:55:22 --> Config Class Initialized
INFO - 2023-05-23 08:55:22 --> Hooks Class Initialized
INFO - 2023-05-23 08:55:22 --> Utf8 Class Initialized
INFO - 2023-05-23 08:55:22 --> URI Class Initialized
INFO - 2023-05-23 08:55:22 --> Router Class Initialized
INFO - 2023-05-23 08:55:22 --> Output Class Initialized
INFO - 2023-05-23 08:55:22 --> Security Class Initialized
INFO - 2023-05-23 08:55:22 --> Input Class Initialized
INFO - 2023-05-23 08:55:22 --> Language Class Initialized
INFO - 2023-05-23 08:55:22 --> Loader Class Initialized
INFO - 2023-05-23 08:55:22 --> Helper loaded: url_helper
INFO - 2023-05-23 08:55:22 --> Helper loaded: form_helper
INFO - 2023-05-23 08:55:22 --> Database Driver Class Initialized
INFO - 2023-05-23 08:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:55:22 --> Form Validation Class Initialized
INFO - 2023-05-23 08:55:22 --> Controller Class Initialized
INFO - 2023-05-23 08:55:22 --> Model "m_datatrain" initialized
INFO - 2023-05-23 08:55:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 08:55:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 08:55:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-23 08:55:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 08:55:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 08:55:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 08:55:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 08:55:22 --> Final output sent to browser
INFO - 2023-05-23 08:59:52 --> Config Class Initialized
INFO - 2023-05-23 08:59:52 --> Hooks Class Initialized
INFO - 2023-05-23 08:59:52 --> Utf8 Class Initialized
INFO - 2023-05-23 08:59:52 --> URI Class Initialized
INFO - 2023-05-23 08:59:52 --> Router Class Initialized
INFO - 2023-05-23 08:59:52 --> Output Class Initialized
INFO - 2023-05-23 08:59:52 --> Security Class Initialized
INFO - 2023-05-23 08:59:52 --> Input Class Initialized
INFO - 2023-05-23 08:59:52 --> Language Class Initialized
INFO - 2023-05-23 08:59:52 --> Loader Class Initialized
INFO - 2023-05-23 08:59:52 --> Helper loaded: url_helper
INFO - 2023-05-23 08:59:52 --> Helper loaded: form_helper
INFO - 2023-05-23 08:59:52 --> Database Driver Class Initialized
INFO - 2023-05-23 08:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:59:52 --> Form Validation Class Initialized
INFO - 2023-05-23 08:59:52 --> Controller Class Initialized
INFO - 2023-05-23 08:59:52 --> Model "m_user" initialized
INFO - 2023-05-23 08:59:52 --> Config Class Initialized
INFO - 2023-05-23 08:59:52 --> Hooks Class Initialized
INFO - 2023-05-23 08:59:52 --> Utf8 Class Initialized
INFO - 2023-05-23 08:59:52 --> URI Class Initialized
INFO - 2023-05-23 08:59:53 --> Router Class Initialized
INFO - 2023-05-23 08:59:53 --> Output Class Initialized
INFO - 2023-05-23 08:59:53 --> Security Class Initialized
INFO - 2023-05-23 08:59:53 --> Input Class Initialized
INFO - 2023-05-23 08:59:53 --> Language Class Initialized
INFO - 2023-05-23 08:59:53 --> Loader Class Initialized
INFO - 2023-05-23 08:59:53 --> Helper loaded: url_helper
INFO - 2023-05-23 08:59:53 --> Helper loaded: form_helper
INFO - 2023-05-23 08:59:53 --> Database Driver Class Initialized
INFO - 2023-05-23 08:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:59:53 --> Form Validation Class Initialized
INFO - 2023-05-23 08:59:53 --> Controller Class Initialized
INFO - 2023-05-23 08:59:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-23 08:59:53 --> Final output sent to browser
INFO - 2023-05-23 08:59:54 --> Config Class Initialized
INFO - 2023-05-23 08:59:54 --> Hooks Class Initialized
INFO - 2023-05-23 08:59:54 --> Utf8 Class Initialized
INFO - 2023-05-23 08:59:54 --> URI Class Initialized
INFO - 2023-05-23 08:59:54 --> Router Class Initialized
INFO - 2023-05-23 08:59:54 --> Output Class Initialized
INFO - 2023-05-23 08:59:54 --> Security Class Initialized
INFO - 2023-05-23 08:59:54 --> Input Class Initialized
INFO - 2023-05-23 08:59:54 --> Language Class Initialized
INFO - 2023-05-23 08:59:54 --> Loader Class Initialized
INFO - 2023-05-23 08:59:54 --> Helper loaded: url_helper
INFO - 2023-05-23 08:59:54 --> Helper loaded: form_helper
INFO - 2023-05-23 08:59:54 --> Database Driver Class Initialized
INFO - 2023-05-23 08:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:59:54 --> Form Validation Class Initialized
INFO - 2023-05-23 08:59:54 --> Controller Class Initialized
INFO - 2023-05-23 08:59:54 --> Model "m_user" initialized
INFO - 2023-05-23 08:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 08:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 08:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 08:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 08:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 08:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-23 08:59:54 --> Final output sent to browser
INFO - 2023-05-23 08:59:55 --> Config Class Initialized
INFO - 2023-05-23 08:59:55 --> Hooks Class Initialized
INFO - 2023-05-23 08:59:55 --> Utf8 Class Initialized
INFO - 2023-05-23 08:59:55 --> URI Class Initialized
INFO - 2023-05-23 08:59:55 --> Router Class Initialized
INFO - 2023-05-23 08:59:55 --> Output Class Initialized
INFO - 2023-05-23 08:59:55 --> Security Class Initialized
INFO - 2023-05-23 08:59:55 --> Input Class Initialized
INFO - 2023-05-23 08:59:55 --> Language Class Initialized
INFO - 2023-05-23 08:59:55 --> Loader Class Initialized
INFO - 2023-05-23 08:59:55 --> Helper loaded: url_helper
INFO - 2023-05-23 08:59:55 --> Helper loaded: form_helper
INFO - 2023-05-23 08:59:55 --> Database Driver Class Initialized
INFO - 2023-05-23 08:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 08:59:55 --> Form Validation Class Initialized
INFO - 2023-05-23 08:59:55 --> Controller Class Initialized
INFO - 2023-05-23 08:59:55 --> Model "m_datatrain" initialized
INFO - 2023-05-23 08:59:55 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 08:59:55 --> Model "m_datatest" initialized
INFO - 2023-05-23 08:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 08:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 08:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-23 08:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 08:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 08:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 08:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-23 08:59:55 --> Final output sent to browser
INFO - 2023-05-23 09:48:36 --> Config Class Initialized
INFO - 2023-05-23 09:48:36 --> Hooks Class Initialized
INFO - 2023-05-23 09:48:36 --> Utf8 Class Initialized
INFO - 2023-05-23 09:48:36 --> URI Class Initialized
INFO - 2023-05-23 09:48:36 --> Router Class Initialized
INFO - 2023-05-23 09:48:36 --> Output Class Initialized
INFO - 2023-05-23 09:48:36 --> Security Class Initialized
INFO - 2023-05-23 09:48:36 --> Input Class Initialized
INFO - 2023-05-23 09:48:36 --> Language Class Initialized
INFO - 2023-05-23 09:48:36 --> Loader Class Initialized
INFO - 2023-05-23 09:48:36 --> Helper loaded: url_helper
INFO - 2023-05-23 09:48:36 --> Helper loaded: form_helper
INFO - 2023-05-23 09:48:36 --> Database Driver Class Initialized
INFO - 2023-05-23 09:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 09:48:36 --> Form Validation Class Initialized
INFO - 2023-05-23 09:48:36 --> Controller Class Initialized
INFO - 2023-05-23 09:48:36 --> Model "m_datatrain" initialized
INFO - 2023-05-23 09:48:36 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 09:48:36 --> Model "m_datatest" initialized
INFO - 2023-05-23 09:48:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 09:48:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 09:48:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-23 09:48:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 09:48:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 09:48:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 09:48:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-23 09:48:36 --> Final output sent to browser
INFO - 2023-05-23 09:48:41 --> Config Class Initialized
INFO - 2023-05-23 09:48:41 --> Hooks Class Initialized
INFO - 2023-05-23 09:48:41 --> Utf8 Class Initialized
INFO - 2023-05-23 09:48:41 --> URI Class Initialized
INFO - 2023-05-23 09:48:41 --> Router Class Initialized
INFO - 2023-05-23 09:48:41 --> Output Class Initialized
INFO - 2023-05-23 09:48:41 --> Security Class Initialized
INFO - 2023-05-23 09:48:41 --> Input Class Initialized
INFO - 2023-05-23 09:48:41 --> Language Class Initialized
INFO - 2023-05-23 09:48:41 --> Loader Class Initialized
INFO - 2023-05-23 09:48:41 --> Helper loaded: url_helper
INFO - 2023-05-23 09:48:41 --> Helper loaded: form_helper
INFO - 2023-05-23 09:48:41 --> Database Driver Class Initialized
INFO - 2023-05-23 09:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 09:48:41 --> Form Validation Class Initialized
INFO - 2023-05-23 09:48:41 --> Controller Class Initialized
INFO - 2023-05-23 09:48:41 --> Model "m_user" initialized
INFO - 2023-05-23 09:48:41 --> Config Class Initialized
INFO - 2023-05-23 09:48:41 --> Hooks Class Initialized
INFO - 2023-05-23 09:48:41 --> Utf8 Class Initialized
INFO - 2023-05-23 09:48:41 --> URI Class Initialized
INFO - 2023-05-23 09:48:41 --> Router Class Initialized
INFO - 2023-05-23 09:48:41 --> Output Class Initialized
INFO - 2023-05-23 09:48:41 --> Security Class Initialized
INFO - 2023-05-23 09:48:41 --> Input Class Initialized
INFO - 2023-05-23 09:48:41 --> Language Class Initialized
INFO - 2023-05-23 09:48:41 --> Loader Class Initialized
INFO - 2023-05-23 09:48:41 --> Helper loaded: url_helper
INFO - 2023-05-23 09:48:41 --> Helper loaded: form_helper
INFO - 2023-05-23 09:48:41 --> Database Driver Class Initialized
INFO - 2023-05-23 09:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 09:48:41 --> Form Validation Class Initialized
INFO - 2023-05-23 09:48:41 --> Controller Class Initialized
INFO - 2023-05-23 09:48:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-23 09:48:41 --> Final output sent to browser
INFO - 2023-05-23 09:48:44 --> Config Class Initialized
INFO - 2023-05-23 09:48:44 --> Hooks Class Initialized
INFO - 2023-05-23 09:48:44 --> Utf8 Class Initialized
INFO - 2023-05-23 09:48:44 --> URI Class Initialized
INFO - 2023-05-23 09:48:44 --> Router Class Initialized
INFO - 2023-05-23 09:48:44 --> Output Class Initialized
INFO - 2023-05-23 09:48:44 --> Security Class Initialized
INFO - 2023-05-23 09:48:44 --> Input Class Initialized
INFO - 2023-05-23 09:48:44 --> Language Class Initialized
INFO - 2023-05-23 09:48:44 --> Loader Class Initialized
INFO - 2023-05-23 09:48:44 --> Helper loaded: url_helper
INFO - 2023-05-23 09:48:44 --> Helper loaded: form_helper
INFO - 2023-05-23 09:48:44 --> Database Driver Class Initialized
INFO - 2023-05-23 09:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 09:48:44 --> Form Validation Class Initialized
INFO - 2023-05-23 09:48:44 --> Controller Class Initialized
INFO - 2023-05-23 09:48:44 --> Model "m_user" initialized
INFO - 2023-05-23 09:48:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-23 09:48:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-23 09:48:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-23 09:48:44 --> Final output sent to browser
INFO - 2023-05-23 09:48:48 --> Config Class Initialized
INFO - 2023-05-23 09:48:48 --> Hooks Class Initialized
INFO - 2023-05-23 09:48:48 --> Utf8 Class Initialized
INFO - 2023-05-23 09:48:48 --> URI Class Initialized
INFO - 2023-05-23 09:48:48 --> Router Class Initialized
INFO - 2023-05-23 09:48:48 --> Output Class Initialized
INFO - 2023-05-23 09:48:48 --> Security Class Initialized
INFO - 2023-05-23 09:48:48 --> Input Class Initialized
INFO - 2023-05-23 09:48:48 --> Language Class Initialized
INFO - 2023-05-23 09:48:48 --> Loader Class Initialized
INFO - 2023-05-23 09:48:48 --> Helper loaded: url_helper
INFO - 2023-05-23 09:48:48 --> Helper loaded: form_helper
INFO - 2023-05-23 09:48:48 --> Database Driver Class Initialized
INFO - 2023-05-23 09:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 09:48:48 --> Form Validation Class Initialized
INFO - 2023-05-23 09:48:48 --> Controller Class Initialized
INFO - 2023-05-23 09:48:48 --> Model "m_user" initialized
INFO - 2023-05-23 09:48:48 --> Config Class Initialized
INFO - 2023-05-23 09:48:48 --> Hooks Class Initialized
INFO - 2023-05-23 09:48:48 --> Utf8 Class Initialized
INFO - 2023-05-23 09:48:48 --> URI Class Initialized
INFO - 2023-05-23 09:48:48 --> Router Class Initialized
INFO - 2023-05-23 09:48:48 --> Output Class Initialized
INFO - 2023-05-23 09:48:48 --> Security Class Initialized
INFO - 2023-05-23 09:48:48 --> Input Class Initialized
INFO - 2023-05-23 09:48:48 --> Language Class Initialized
INFO - 2023-05-23 09:48:48 --> Loader Class Initialized
INFO - 2023-05-23 09:48:48 --> Helper loaded: url_helper
INFO - 2023-05-23 09:48:48 --> Helper loaded: form_helper
INFO - 2023-05-23 09:48:48 --> Database Driver Class Initialized
INFO - 2023-05-23 09:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 09:48:48 --> Form Validation Class Initialized
INFO - 2023-05-23 09:48:48 --> Controller Class Initialized
INFO - 2023-05-23 09:48:48 --> Model "m_user" initialized
INFO - 2023-05-23 09:48:48 --> Model "m_datatrain" initialized
INFO - 2023-05-23 09:48:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 09:48:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 09:48:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 09:48:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 09:48:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 09:48:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 09:48:48 --> Final output sent to browser
INFO - 2023-05-23 09:50:56 --> Config Class Initialized
INFO - 2023-05-23 09:50:56 --> Hooks Class Initialized
INFO - 2023-05-23 09:50:56 --> Utf8 Class Initialized
INFO - 2023-05-23 09:50:56 --> URI Class Initialized
INFO - 2023-05-23 09:50:56 --> Router Class Initialized
INFO - 2023-05-23 09:50:56 --> Output Class Initialized
INFO - 2023-05-23 09:50:56 --> Security Class Initialized
INFO - 2023-05-23 09:50:56 --> Input Class Initialized
INFO - 2023-05-23 09:50:56 --> Language Class Initialized
INFO - 2023-05-23 09:50:56 --> Loader Class Initialized
INFO - 2023-05-23 09:50:56 --> Helper loaded: url_helper
INFO - 2023-05-23 09:50:56 --> Helper loaded: form_helper
INFO - 2023-05-23 09:50:56 --> Database Driver Class Initialized
INFO - 2023-05-23 09:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 09:50:56 --> Form Validation Class Initialized
INFO - 2023-05-23 09:50:56 --> Controller Class Initialized
INFO - 2023-05-23 09:50:56 --> Model "m_user" initialized
INFO - 2023-05-23 09:50:56 --> Model "m_datatrain" initialized
INFO - 2023-05-23 09:50:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 09:50:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 09:50:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 09:50:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 09:50:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 09:50:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 09:50:56 --> Final output sent to browser
INFO - 2023-05-23 09:51:10 --> Config Class Initialized
INFO - 2023-05-23 09:51:10 --> Hooks Class Initialized
INFO - 2023-05-23 09:51:10 --> Utf8 Class Initialized
INFO - 2023-05-23 09:51:10 --> URI Class Initialized
INFO - 2023-05-23 09:51:10 --> Router Class Initialized
INFO - 2023-05-23 09:51:10 --> Output Class Initialized
INFO - 2023-05-23 09:51:10 --> Security Class Initialized
INFO - 2023-05-23 09:51:10 --> Input Class Initialized
INFO - 2023-05-23 09:51:10 --> Language Class Initialized
INFO - 2023-05-23 09:51:10 --> Loader Class Initialized
INFO - 2023-05-23 09:51:10 --> Helper loaded: url_helper
INFO - 2023-05-23 09:51:10 --> Helper loaded: form_helper
INFO - 2023-05-23 09:51:10 --> Database Driver Class Initialized
INFO - 2023-05-23 09:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 09:51:10 --> Form Validation Class Initialized
INFO - 2023-05-23 09:51:10 --> Controller Class Initialized
INFO - 2023-05-23 09:51:10 --> Model "m_user" initialized
INFO - 2023-05-23 09:51:10 --> Model "m_datatrain" initialized
INFO - 2023-05-23 09:51:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 09:51:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 09:51:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 09:51:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 09:51:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 09:51:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 09:51:10 --> Final output sent to browser
INFO - 2023-05-23 10:45:55 --> Config Class Initialized
INFO - 2023-05-23 10:45:55 --> Hooks Class Initialized
INFO - 2023-05-23 10:45:55 --> Utf8 Class Initialized
INFO - 2023-05-23 10:45:55 --> URI Class Initialized
INFO - 2023-05-23 10:45:55 --> Router Class Initialized
INFO - 2023-05-23 10:45:55 --> Output Class Initialized
INFO - 2023-05-23 10:45:55 --> Security Class Initialized
INFO - 2023-05-23 10:45:55 --> Input Class Initialized
INFO - 2023-05-23 10:45:55 --> Language Class Initialized
INFO - 2023-05-23 10:45:55 --> Loader Class Initialized
INFO - 2023-05-23 10:45:55 --> Helper loaded: url_helper
INFO - 2023-05-23 10:45:55 --> Helper loaded: form_helper
INFO - 2023-05-23 10:45:55 --> Database Driver Class Initialized
INFO - 2023-05-23 10:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 10:45:55 --> Form Validation Class Initialized
INFO - 2023-05-23 10:45:55 --> Controller Class Initialized
INFO - 2023-05-23 10:45:55 --> Model "m_datatrain" initialized
INFO - 2023-05-23 10:45:55 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 10:45:55 --> Model "m_datatest" initialized
INFO - 2023-05-23 10:45:55 --> Final output sent to browser
INFO - 2023-05-23 10:46:01 --> Config Class Initialized
INFO - 2023-05-23 10:46:01 --> Hooks Class Initialized
INFO - 2023-05-23 10:46:01 --> Utf8 Class Initialized
INFO - 2023-05-23 10:46:01 --> URI Class Initialized
INFO - 2023-05-23 10:46:01 --> Router Class Initialized
INFO - 2023-05-23 10:46:01 --> Output Class Initialized
INFO - 2023-05-23 10:46:01 --> Security Class Initialized
INFO - 2023-05-23 10:46:01 --> Input Class Initialized
INFO - 2023-05-23 10:46:01 --> Language Class Initialized
INFO - 2023-05-23 10:46:01 --> Loader Class Initialized
INFO - 2023-05-23 10:46:01 --> Helper loaded: url_helper
INFO - 2023-05-23 10:46:01 --> Helper loaded: form_helper
INFO - 2023-05-23 10:46:01 --> Database Driver Class Initialized
INFO - 2023-05-23 10:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 10:46:01 --> Form Validation Class Initialized
INFO - 2023-05-23 10:46:01 --> Controller Class Initialized
INFO - 2023-05-23 10:46:01 --> Model "m_user" initialized
INFO - 2023-05-23 10:46:01 --> Model "m_datatrain" initialized
INFO - 2023-05-23 10:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 10:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 10:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 10:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 10:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 10:46:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 10:46:01 --> Final output sent to browser
INFO - 2023-05-23 10:49:39 --> Config Class Initialized
INFO - 2023-05-23 10:49:39 --> Hooks Class Initialized
INFO - 2023-05-23 10:49:39 --> Utf8 Class Initialized
INFO - 2023-05-23 10:49:39 --> URI Class Initialized
INFO - 2023-05-23 10:49:39 --> Router Class Initialized
INFO - 2023-05-23 10:49:39 --> Output Class Initialized
INFO - 2023-05-23 10:49:39 --> Security Class Initialized
INFO - 2023-05-23 10:49:39 --> Input Class Initialized
INFO - 2023-05-23 10:49:39 --> Language Class Initialized
INFO - 2023-05-23 10:49:39 --> Loader Class Initialized
INFO - 2023-05-23 10:49:39 --> Helper loaded: url_helper
INFO - 2023-05-23 10:49:39 --> Helper loaded: form_helper
INFO - 2023-05-23 10:49:39 --> Database Driver Class Initialized
INFO - 2023-05-23 10:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 10:49:39 --> Form Validation Class Initialized
INFO - 2023-05-23 10:49:39 --> Controller Class Initialized
INFO - 2023-05-23 10:49:39 --> Model "m_user" initialized
INFO - 2023-05-23 10:49:39 --> Model "m_datatrain" initialized
INFO - 2023-05-23 10:49:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 10:49:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 10:49:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 10:49:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 10:49:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 10:49:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 10:49:39 --> Final output sent to browser
INFO - 2023-05-23 10:49:40 --> Config Class Initialized
INFO - 2023-05-23 10:49:40 --> Hooks Class Initialized
INFO - 2023-05-23 10:49:40 --> Utf8 Class Initialized
INFO - 2023-05-23 10:49:40 --> URI Class Initialized
INFO - 2023-05-23 10:49:40 --> Router Class Initialized
INFO - 2023-05-23 10:49:40 --> Output Class Initialized
INFO - 2023-05-23 10:49:40 --> Security Class Initialized
INFO - 2023-05-23 10:49:40 --> Input Class Initialized
INFO - 2023-05-23 10:49:40 --> Language Class Initialized
INFO - 2023-05-23 10:49:40 --> Loader Class Initialized
INFO - 2023-05-23 10:49:40 --> Helper loaded: url_helper
INFO - 2023-05-23 10:49:40 --> Helper loaded: form_helper
INFO - 2023-05-23 10:49:40 --> Database Driver Class Initialized
INFO - 2023-05-23 10:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 10:49:40 --> Form Validation Class Initialized
INFO - 2023-05-23 10:49:40 --> Controller Class Initialized
INFO - 2023-05-23 10:49:40 --> Model "m_datatrain" initialized
INFO - 2023-05-23 10:49:40 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 10:49:40 --> Model "m_datatest" initialized
INFO - 2023-05-23 10:49:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 10:49:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 10:49:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 70
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 71
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 83
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 83
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 84
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 84
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 105
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 106
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 107
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 108
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 109
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 123
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 123
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 124
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 124
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 145
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 146
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 147
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 148
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 149
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 163
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 163
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 164
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 164
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 186
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 187
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 188
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 189
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 190
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 204
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 204
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 205
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 205
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 226
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 227
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 228
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 229
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 230
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 244
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 244
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 245
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 245
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 266
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 267
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 268
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 269
ERROR - 2023-05-23 10:49:41 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 270
INFO - 2023-05-23 10:57:39 --> Config Class Initialized
INFO - 2023-05-23 10:57:39 --> Hooks Class Initialized
INFO - 2023-05-23 10:57:39 --> Utf8 Class Initialized
INFO - 2023-05-23 10:57:39 --> URI Class Initialized
INFO - 2023-05-23 10:57:39 --> Router Class Initialized
INFO - 2023-05-23 10:57:39 --> Output Class Initialized
INFO - 2023-05-23 10:57:39 --> Security Class Initialized
INFO - 2023-05-23 10:57:39 --> Input Class Initialized
INFO - 2023-05-23 10:57:39 --> Language Class Initialized
INFO - 2023-05-23 10:57:39 --> Loader Class Initialized
INFO - 2023-05-23 10:57:39 --> Helper loaded: url_helper
INFO - 2023-05-23 10:57:39 --> Helper loaded: form_helper
INFO - 2023-05-23 10:57:39 --> Database Driver Class Initialized
INFO - 2023-05-23 10:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 10:57:39 --> Form Validation Class Initialized
INFO - 2023-05-23 10:57:39 --> Controller Class Initialized
INFO - 2023-05-23 10:57:39 --> Model "m_datatrain" initialized
INFO - 2023-05-23 10:57:39 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 10:57:39 --> Model "m_datatest" initialized
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 25
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 25
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 26
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 26
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 74
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 74
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 75
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 75
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 76
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 76
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 77
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 77
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 99
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 100
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 101
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 102
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 103
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 114
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 114
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 115
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 115
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 116
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 116
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 117
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 117
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 139
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 140
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 141
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 142
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 143
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 154
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 154
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 155
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 155
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 156
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 156
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 157
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 157
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 180
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 181
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 182
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 183
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 184
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 195
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 195
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 196
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 196
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 197
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 197
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 198
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 198
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 220
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 221
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 222
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 223
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 224
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 235
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 235
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 236
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 236
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 237
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 237
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 238
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 238
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 260
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 261
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 262
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 263
ERROR - 2023-05-23 10:57:39 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 264
INFO - 2023-05-23 10:59:17 --> Config Class Initialized
INFO - 2023-05-23 10:59:17 --> Hooks Class Initialized
INFO - 2023-05-23 10:59:17 --> Utf8 Class Initialized
INFO - 2023-05-23 10:59:17 --> URI Class Initialized
INFO - 2023-05-23 10:59:17 --> Router Class Initialized
INFO - 2023-05-23 10:59:17 --> Output Class Initialized
INFO - 2023-05-23 10:59:17 --> Security Class Initialized
INFO - 2023-05-23 10:59:17 --> Input Class Initialized
INFO - 2023-05-23 10:59:17 --> Language Class Initialized
INFO - 2023-05-23 10:59:17 --> Loader Class Initialized
INFO - 2023-05-23 10:59:17 --> Helper loaded: url_helper
INFO - 2023-05-23 10:59:17 --> Helper loaded: form_helper
INFO - 2023-05-23 10:59:17 --> Database Driver Class Initialized
INFO - 2023-05-23 10:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 10:59:17 --> Form Validation Class Initialized
INFO - 2023-05-23 10:59:17 --> Controller Class Initialized
INFO - 2023-05-23 10:59:17 --> Model "m_datatrain" initialized
INFO - 2023-05-23 10:59:17 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 10:59:17 --> Model "m_datatest" initialized
INFO - 2023-05-23 10:59:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 10:59:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 25
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 25
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 26
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 26
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 74
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 74
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 75
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 75
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 76
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 76
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 77
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 77
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 99
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 100
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 101
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 102
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 103
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 114
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 114
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 115
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 115
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 116
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 116
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 117
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 117
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 139
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 140
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 141
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 142
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 143
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 154
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 154
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 155
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 155
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 156
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 156
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 157
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 157
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 180
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 181
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 182
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 183
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 184
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 195
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 195
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 196
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 196
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 197
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 197
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 198
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 198
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 220
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 221
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 222
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 223
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 224
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 235
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 235
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 236
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 236
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 237
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 237
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 238
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 238
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 260
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 261
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 262
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 263
ERROR - 2023-05-23 10:59:17 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 264
INFO - 2023-05-23 10:59:29 --> Config Class Initialized
INFO - 2023-05-23 10:59:29 --> Hooks Class Initialized
INFO - 2023-05-23 10:59:29 --> Utf8 Class Initialized
INFO - 2023-05-23 10:59:29 --> URI Class Initialized
INFO - 2023-05-23 10:59:29 --> Router Class Initialized
INFO - 2023-05-23 10:59:29 --> Output Class Initialized
INFO - 2023-05-23 10:59:29 --> Security Class Initialized
INFO - 2023-05-23 10:59:29 --> Input Class Initialized
INFO - 2023-05-23 10:59:29 --> Language Class Initialized
INFO - 2023-05-23 10:59:29 --> Loader Class Initialized
INFO - 2023-05-23 10:59:29 --> Helper loaded: url_helper
INFO - 2023-05-23 10:59:29 --> Helper loaded: form_helper
INFO - 2023-05-23 10:59:29 --> Database Driver Class Initialized
INFO - 2023-05-23 10:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 10:59:29 --> Form Validation Class Initialized
INFO - 2023-05-23 10:59:29 --> Controller Class Initialized
INFO - 2023-05-23 10:59:29 --> Model "m_datatrain" initialized
INFO - 2023-05-23 10:59:29 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 10:59:29 --> Model "m_datatest" initialized
INFO - 2023-05-23 10:59:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 10:59:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 25
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 25
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 26
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 26
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 74
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 74
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 75
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 75
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 76
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 76
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 77
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 77
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 99
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 100
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 101
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 102
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 103
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 114
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 114
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 115
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 115
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 116
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 116
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 117
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 117
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 139
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 140
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 141
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 142
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 143
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 154
ERROR - 2023-05-23 10:59:29 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 154
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 155
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 155
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 156
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 156
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 157
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 157
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 180
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 181
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 182
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 183
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 184
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 195
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 195
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 196
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 196
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 197
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 197
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 198
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 198
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 220
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 221
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 222
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 223
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 224
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 235
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 235
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 236
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 236
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 237
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 237
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 238
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 238
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 260
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 261
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 262
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 263
ERROR - 2023-05-23 10:59:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 264
INFO - 2023-05-23 10:59:39 --> Config Class Initialized
INFO - 2023-05-23 10:59:39 --> Hooks Class Initialized
INFO - 2023-05-23 10:59:39 --> Utf8 Class Initialized
INFO - 2023-05-23 10:59:39 --> URI Class Initialized
INFO - 2023-05-23 10:59:39 --> Router Class Initialized
INFO - 2023-05-23 10:59:39 --> Output Class Initialized
INFO - 2023-05-23 10:59:39 --> Security Class Initialized
INFO - 2023-05-23 10:59:39 --> Input Class Initialized
INFO - 2023-05-23 10:59:39 --> Language Class Initialized
INFO - 2023-05-23 10:59:39 --> Loader Class Initialized
INFO - 2023-05-23 10:59:39 --> Helper loaded: url_helper
INFO - 2023-05-23 10:59:39 --> Helper loaded: form_helper
INFO - 2023-05-23 10:59:39 --> Database Driver Class Initialized
INFO - 2023-05-23 10:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 10:59:39 --> Form Validation Class Initialized
INFO - 2023-05-23 10:59:39 --> Controller Class Initialized
INFO - 2023-05-23 10:59:39 --> Model "m_datatrain" initialized
INFO - 2023-05-23 10:59:39 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 10:59:39 --> Model "m_datatest" initialized
INFO - 2023-05-23 10:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 10:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 10:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-23 10:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 10:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 10:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 10:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-23 10:59:39 --> Final output sent to browser
INFO - 2023-05-23 10:59:53 --> Config Class Initialized
INFO - 2023-05-23 10:59:53 --> Hooks Class Initialized
INFO - 2023-05-23 10:59:53 --> Utf8 Class Initialized
INFO - 2023-05-23 10:59:53 --> URI Class Initialized
INFO - 2023-05-23 10:59:53 --> Router Class Initialized
INFO - 2023-05-23 10:59:53 --> Output Class Initialized
INFO - 2023-05-23 10:59:53 --> Security Class Initialized
INFO - 2023-05-23 10:59:53 --> Input Class Initialized
INFO - 2023-05-23 10:59:53 --> Language Class Initialized
INFO - 2023-05-23 10:59:53 --> Loader Class Initialized
INFO - 2023-05-23 10:59:53 --> Helper loaded: url_helper
INFO - 2023-05-23 10:59:53 --> Helper loaded: form_helper
INFO - 2023-05-23 10:59:53 --> Database Driver Class Initialized
INFO - 2023-05-23 10:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 10:59:53 --> Form Validation Class Initialized
INFO - 2023-05-23 10:59:53 --> Controller Class Initialized
INFO - 2023-05-23 10:59:53 --> Model "m_datatrain" initialized
INFO - 2023-05-23 10:59:53 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 10:59:53 --> Model "m_datatest" initialized
INFO - 2023-05-23 10:59:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 10:59:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 10:59:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-23 10:59:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 10:59:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 10:59:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 10:59:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-23 10:59:53 --> Final output sent to browser
INFO - 2023-05-23 10:59:55 --> Config Class Initialized
INFO - 2023-05-23 10:59:55 --> Hooks Class Initialized
INFO - 2023-05-23 10:59:55 --> Utf8 Class Initialized
INFO - 2023-05-23 10:59:55 --> URI Class Initialized
INFO - 2023-05-23 10:59:55 --> Router Class Initialized
INFO - 2023-05-23 10:59:55 --> Output Class Initialized
INFO - 2023-05-23 10:59:55 --> Security Class Initialized
INFO - 2023-05-23 10:59:55 --> Input Class Initialized
INFO - 2023-05-23 10:59:55 --> Language Class Initialized
INFO - 2023-05-23 10:59:55 --> Loader Class Initialized
INFO - 2023-05-23 10:59:55 --> Helper loaded: url_helper
INFO - 2023-05-23 10:59:55 --> Helper loaded: form_helper
INFO - 2023-05-23 10:59:55 --> Database Driver Class Initialized
INFO - 2023-05-23 10:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 10:59:55 --> Form Validation Class Initialized
INFO - 2023-05-23 10:59:55 --> Controller Class Initialized
INFO - 2023-05-23 10:59:55 --> Model "m_user" initialized
INFO - 2023-05-23 10:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 10:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 10:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 10:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 10:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 10:59:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-23 10:59:55 --> Final output sent to browser
INFO - 2023-05-23 11:00:10 --> Config Class Initialized
INFO - 2023-05-23 11:00:10 --> Hooks Class Initialized
INFO - 2023-05-23 11:00:10 --> Utf8 Class Initialized
INFO - 2023-05-23 11:00:10 --> URI Class Initialized
INFO - 2023-05-23 11:00:10 --> Router Class Initialized
INFO - 2023-05-23 11:00:10 --> Output Class Initialized
INFO - 2023-05-23 11:00:10 --> Security Class Initialized
INFO - 2023-05-23 11:00:10 --> Input Class Initialized
INFO - 2023-05-23 11:00:10 --> Language Class Initialized
INFO - 2023-05-23 11:00:10 --> Loader Class Initialized
INFO - 2023-05-23 11:00:10 --> Helper loaded: url_helper
INFO - 2023-05-23 11:00:10 --> Helper loaded: form_helper
INFO - 2023-05-23 11:00:10 --> Database Driver Class Initialized
INFO - 2023-05-23 11:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:00:10 --> Form Validation Class Initialized
INFO - 2023-05-23 11:00:10 --> Controller Class Initialized
INFO - 2023-05-23 11:00:10 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:00:10 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:00:10 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:00:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:00:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:00:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-23 11:00:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 11:00:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:00:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:00:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-23 11:00:10 --> Final output sent to browser
INFO - 2023-05-23 11:00:21 --> Config Class Initialized
INFO - 2023-05-23 11:00:21 --> Hooks Class Initialized
INFO - 2023-05-23 11:00:21 --> Utf8 Class Initialized
INFO - 2023-05-23 11:00:21 --> URI Class Initialized
INFO - 2023-05-23 11:00:21 --> Router Class Initialized
INFO - 2023-05-23 11:00:21 --> Output Class Initialized
INFO - 2023-05-23 11:00:21 --> Security Class Initialized
INFO - 2023-05-23 11:00:21 --> Input Class Initialized
INFO - 2023-05-23 11:00:21 --> Language Class Initialized
INFO - 2023-05-23 11:00:21 --> Loader Class Initialized
INFO - 2023-05-23 11:00:21 --> Helper loaded: url_helper
INFO - 2023-05-23 11:00:21 --> Helper loaded: form_helper
INFO - 2023-05-23 11:00:21 --> Database Driver Class Initialized
INFO - 2023-05-23 11:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:00:21 --> Form Validation Class Initialized
INFO - 2023-05-23 11:00:21 --> Controller Class Initialized
INFO - 2023-05-23 11:00:21 --> Model "m_user" initialized
INFO - 2023-05-23 11:00:21 --> Config Class Initialized
INFO - 2023-05-23 11:00:21 --> Hooks Class Initialized
INFO - 2023-05-23 11:00:21 --> Utf8 Class Initialized
INFO - 2023-05-23 11:00:21 --> URI Class Initialized
INFO - 2023-05-23 11:00:21 --> Router Class Initialized
INFO - 2023-05-23 11:00:21 --> Output Class Initialized
INFO - 2023-05-23 11:00:21 --> Security Class Initialized
INFO - 2023-05-23 11:00:21 --> Input Class Initialized
INFO - 2023-05-23 11:00:21 --> Language Class Initialized
INFO - 2023-05-23 11:00:21 --> Loader Class Initialized
INFO - 2023-05-23 11:00:21 --> Helper loaded: url_helper
INFO - 2023-05-23 11:00:21 --> Helper loaded: form_helper
INFO - 2023-05-23 11:00:21 --> Database Driver Class Initialized
INFO - 2023-05-23 11:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:00:21 --> Form Validation Class Initialized
INFO - 2023-05-23 11:00:21 --> Controller Class Initialized
INFO - 2023-05-23 11:00:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-23 11:00:21 --> Final output sent to browser
INFO - 2023-05-23 11:00:22 --> Config Class Initialized
INFO - 2023-05-23 11:00:22 --> Hooks Class Initialized
INFO - 2023-05-23 11:00:22 --> Utf8 Class Initialized
INFO - 2023-05-23 11:00:22 --> URI Class Initialized
INFO - 2023-05-23 11:00:22 --> Router Class Initialized
INFO - 2023-05-23 11:00:22 --> Output Class Initialized
INFO - 2023-05-23 11:00:22 --> Security Class Initialized
INFO - 2023-05-23 11:00:22 --> Input Class Initialized
INFO - 2023-05-23 11:00:22 --> Language Class Initialized
INFO - 2023-05-23 11:00:22 --> Loader Class Initialized
INFO - 2023-05-23 11:00:22 --> Helper loaded: url_helper
INFO - 2023-05-23 11:00:22 --> Helper loaded: form_helper
INFO - 2023-05-23 11:00:22 --> Database Driver Class Initialized
INFO - 2023-05-23 11:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:00:22 --> Form Validation Class Initialized
INFO - 2023-05-23 11:00:22 --> Controller Class Initialized
INFO - 2023-05-23 11:00:22 --> Model "m_user" initialized
INFO - 2023-05-23 11:00:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-23 11:00:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-23 11:00:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-23 11:00:22 --> Final output sent to browser
INFO - 2023-05-23 11:00:25 --> Config Class Initialized
INFO - 2023-05-23 11:00:25 --> Hooks Class Initialized
INFO - 2023-05-23 11:00:25 --> Utf8 Class Initialized
INFO - 2023-05-23 11:00:25 --> URI Class Initialized
INFO - 2023-05-23 11:00:25 --> Router Class Initialized
INFO - 2023-05-23 11:00:25 --> Output Class Initialized
INFO - 2023-05-23 11:00:25 --> Security Class Initialized
INFO - 2023-05-23 11:00:25 --> Input Class Initialized
INFO - 2023-05-23 11:00:25 --> Language Class Initialized
INFO - 2023-05-23 11:00:25 --> Loader Class Initialized
INFO - 2023-05-23 11:00:25 --> Helper loaded: url_helper
INFO - 2023-05-23 11:00:25 --> Helper loaded: form_helper
INFO - 2023-05-23 11:00:25 --> Database Driver Class Initialized
INFO - 2023-05-23 11:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:00:25 --> Form Validation Class Initialized
INFO - 2023-05-23 11:00:25 --> Controller Class Initialized
INFO - 2023-05-23 11:00:25 --> Model "m_user" initialized
INFO - 2023-05-23 11:00:25 --> Config Class Initialized
INFO - 2023-05-23 11:00:25 --> Hooks Class Initialized
INFO - 2023-05-23 11:00:25 --> Utf8 Class Initialized
INFO - 2023-05-23 11:00:25 --> URI Class Initialized
INFO - 2023-05-23 11:00:25 --> Router Class Initialized
INFO - 2023-05-23 11:00:25 --> Output Class Initialized
INFO - 2023-05-23 11:00:25 --> Security Class Initialized
INFO - 2023-05-23 11:00:25 --> Input Class Initialized
INFO - 2023-05-23 11:00:25 --> Language Class Initialized
INFO - 2023-05-23 11:00:25 --> Loader Class Initialized
INFO - 2023-05-23 11:00:25 --> Helper loaded: url_helper
INFO - 2023-05-23 11:00:25 --> Helper loaded: form_helper
INFO - 2023-05-23 11:00:25 --> Database Driver Class Initialized
INFO - 2023-05-23 11:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:00:25 --> Form Validation Class Initialized
INFO - 2023-05-23 11:00:25 --> Controller Class Initialized
INFO - 2023-05-23 11:00:25 --> Model "m_user" initialized
INFO - 2023-05-23 11:00:25 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:00:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:00:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:00:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 11:00:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:00:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:00:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 11:00:25 --> Final output sent to browser
INFO - 2023-05-23 11:00:27 --> Config Class Initialized
INFO - 2023-05-23 11:00:27 --> Hooks Class Initialized
INFO - 2023-05-23 11:00:27 --> Utf8 Class Initialized
INFO - 2023-05-23 11:00:27 --> URI Class Initialized
INFO - 2023-05-23 11:00:27 --> Router Class Initialized
INFO - 2023-05-23 11:00:27 --> Output Class Initialized
INFO - 2023-05-23 11:00:27 --> Security Class Initialized
INFO - 2023-05-23 11:00:27 --> Input Class Initialized
INFO - 2023-05-23 11:00:27 --> Language Class Initialized
INFO - 2023-05-23 11:00:27 --> Loader Class Initialized
INFO - 2023-05-23 11:00:27 --> Helper loaded: url_helper
INFO - 2023-05-23 11:00:27 --> Helper loaded: form_helper
INFO - 2023-05-23 11:00:27 --> Database Driver Class Initialized
INFO - 2023-05-23 11:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:00:27 --> Form Validation Class Initialized
INFO - 2023-05-23 11:00:27 --> Controller Class Initialized
INFO - 2023-05-23 11:00:27 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:00:27 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:00:27 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:00:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:00:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 25
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 25
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 26
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 26
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 74
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 74
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 75
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 75
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 76
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 76
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 77
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 77
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 99
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 100
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 101
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 102
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 103
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 114
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 114
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 115
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 115
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 116
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 116
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 117
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 117
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 139
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 140
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 141
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 142
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 143
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 154
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 154
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 155
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 155
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 156
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 156
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 157
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 157
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 180
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 181
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 182
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 183
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 184
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 195
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 195
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 196
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 196
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 197
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 197
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 198
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 198
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 220
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 221
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 222
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 223
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 224
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 235
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 235
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 236
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 236
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 237
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 237
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 238
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 238
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 260
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 261
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 262
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 263
ERROR - 2023-05-23 11:00:27 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 264
INFO - 2023-05-23 11:03:58 --> Config Class Initialized
INFO - 2023-05-23 11:03:58 --> Hooks Class Initialized
INFO - 2023-05-23 11:03:58 --> Utf8 Class Initialized
INFO - 2023-05-23 11:03:58 --> URI Class Initialized
INFO - 2023-05-23 11:03:58 --> Router Class Initialized
INFO - 2023-05-23 11:03:58 --> Output Class Initialized
INFO - 2023-05-23 11:03:58 --> Security Class Initialized
INFO - 2023-05-23 11:03:58 --> Input Class Initialized
INFO - 2023-05-23 11:03:58 --> Language Class Initialized
INFO - 2023-05-23 11:03:58 --> Loader Class Initialized
INFO - 2023-05-23 11:03:58 --> Helper loaded: url_helper
INFO - 2023-05-23 11:03:58 --> Helper loaded: form_helper
INFO - 2023-05-23 11:03:58 --> Database Driver Class Initialized
INFO - 2023-05-23 11:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:03:58 --> Form Validation Class Initialized
INFO - 2023-05-23 11:03:58 --> Controller Class Initialized
INFO - 2023-05-23 11:03:58 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:03:58 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:03:58 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:03:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:03:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 79
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 79
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 103
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 104
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 105
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 106
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 107
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 119
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 119
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 143
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 144
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 145
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 146
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 147
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 159
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 159
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 184
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 185
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 186
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 187
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 188
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 200
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 200
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 224
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 225
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 226
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 227
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 228
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 240
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 240
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 264
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 265
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 266
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 267
ERROR - 2023-05-23 11:03:58 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 268
INFO - 2023-05-23 11:06:51 --> Config Class Initialized
INFO - 2023-05-23 11:06:51 --> Hooks Class Initialized
INFO - 2023-05-23 11:06:51 --> Utf8 Class Initialized
INFO - 2023-05-23 11:06:51 --> URI Class Initialized
INFO - 2023-05-23 11:06:51 --> Router Class Initialized
INFO - 2023-05-23 11:06:51 --> Output Class Initialized
INFO - 2023-05-23 11:06:51 --> Security Class Initialized
INFO - 2023-05-23 11:06:51 --> Input Class Initialized
INFO - 2023-05-23 11:06:51 --> Language Class Initialized
INFO - 2023-05-23 11:06:51 --> Loader Class Initialized
INFO - 2023-05-23 11:06:51 --> Helper loaded: url_helper
INFO - 2023-05-23 11:06:51 --> Helper loaded: form_helper
INFO - 2023-05-23 11:06:51 --> Database Driver Class Initialized
INFO - 2023-05-23 11:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:06:51 --> Form Validation Class Initialized
INFO - 2023-05-23 11:06:51 --> Controller Class Initialized
INFO - 2023-05-23 11:06:51 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:06:51 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:06:51 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:06:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:06:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:06:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 11:07:06 --> Config Class Initialized
INFO - 2023-05-23 11:07:06 --> Hooks Class Initialized
INFO - 2023-05-23 11:07:06 --> Utf8 Class Initialized
INFO - 2023-05-23 11:07:06 --> URI Class Initialized
INFO - 2023-05-23 11:07:06 --> Router Class Initialized
INFO - 2023-05-23 11:07:06 --> Output Class Initialized
INFO - 2023-05-23 11:07:06 --> Security Class Initialized
INFO - 2023-05-23 11:07:06 --> Input Class Initialized
INFO - 2023-05-23 11:07:06 --> Language Class Initialized
INFO - 2023-05-23 11:07:06 --> Loader Class Initialized
INFO - 2023-05-23 11:07:06 --> Helper loaded: url_helper
INFO - 2023-05-23 11:07:06 --> Helper loaded: form_helper
INFO - 2023-05-23 11:07:06 --> Database Driver Class Initialized
INFO - 2023-05-23 11:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:07:06 --> Form Validation Class Initialized
INFO - 2023-05-23 11:07:06 --> Controller Class Initialized
INFO - 2023-05-23 11:07:06 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:07:06 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:07:06 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 28
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 36
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 37
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 45
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 46
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 63
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 64
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 78
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 79
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 79
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 103
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 104
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 105
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 106
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 107
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 118
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 119
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 119
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 143
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 144
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 145
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 146
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 147
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 158
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 159
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 159
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 184
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 185
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 186
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 187
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 188
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 199
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 200
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 200
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 224
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 225
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 226
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 227
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 228
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 239
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 240
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 240
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 264
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 265
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 266
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 267
ERROR - 2023-05-23 11:07:06 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 268
INFO - 2023-05-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 11:07:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:07:06 --> Final output sent to browser
INFO - 2023-05-23 11:10:09 --> Config Class Initialized
INFO - 2023-05-23 11:10:09 --> Hooks Class Initialized
INFO - 2023-05-23 11:10:09 --> Utf8 Class Initialized
INFO - 2023-05-23 11:10:09 --> URI Class Initialized
INFO - 2023-05-23 11:10:09 --> Router Class Initialized
INFO - 2023-05-23 11:10:09 --> Output Class Initialized
INFO - 2023-05-23 11:10:09 --> Security Class Initialized
INFO - 2023-05-23 11:10:09 --> Input Class Initialized
INFO - 2023-05-23 11:10:09 --> Language Class Initialized
INFO - 2023-05-23 11:10:09 --> Loader Class Initialized
INFO - 2023-05-23 11:10:09 --> Helper loaded: url_helper
INFO - 2023-05-23 11:10:09 --> Helper loaded: form_helper
INFO - 2023-05-23 11:10:09 --> Database Driver Class Initialized
INFO - 2023-05-23 11:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:10:09 --> Form Validation Class Initialized
INFO - 2023-05-23 11:10:09 --> Controller Class Initialized
INFO - 2023-05-23 11:10:09 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:10:09 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:10:09 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:10:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:10:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:10:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 70
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 71
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 83
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 83
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 84
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 84
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 105
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 106
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 107
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 108
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 109
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 123
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 123
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 124
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 124
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 145
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 146
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 147
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 148
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 149
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 163
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 163
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 164
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 164
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 186
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 187
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 188
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 189
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 190
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 204
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 204
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 205
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 205
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 226
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 227
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 228
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 229
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 230
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 244
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 244
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 245
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 245
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 266
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 267
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 268
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 269
ERROR - 2023-05-23 11:10:09 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 270
INFO - 2023-05-23 11:10:19 --> Config Class Initialized
INFO - 2023-05-23 11:10:19 --> Hooks Class Initialized
INFO - 2023-05-23 11:10:19 --> Utf8 Class Initialized
INFO - 2023-05-23 11:10:19 --> URI Class Initialized
INFO - 2023-05-23 11:10:19 --> Router Class Initialized
INFO - 2023-05-23 11:10:19 --> Output Class Initialized
INFO - 2023-05-23 11:10:19 --> Security Class Initialized
INFO - 2023-05-23 11:10:19 --> Input Class Initialized
INFO - 2023-05-23 11:10:19 --> Language Class Initialized
INFO - 2023-05-23 11:10:19 --> Loader Class Initialized
INFO - 2023-05-23 11:10:19 --> Helper loaded: url_helper
INFO - 2023-05-23 11:10:19 --> Helper loaded: form_helper
INFO - 2023-05-23 11:10:19 --> Database Driver Class Initialized
INFO - 2023-05-23 11:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:10:19 --> Form Validation Class Initialized
INFO - 2023-05-23 11:10:19 --> Controller Class Initialized
INFO - 2023-05-23 11:10:19 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:10:19 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:10:19 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-23 11:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-23 11:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-23 11:10:19 --> Final output sent to browser
INFO - 2023-05-23 11:10:22 --> Config Class Initialized
INFO - 2023-05-23 11:10:22 --> Hooks Class Initialized
INFO - 2023-05-23 11:10:22 --> Utf8 Class Initialized
INFO - 2023-05-23 11:10:22 --> URI Class Initialized
INFO - 2023-05-23 11:10:22 --> Router Class Initialized
INFO - 2023-05-23 11:10:22 --> Output Class Initialized
INFO - 2023-05-23 11:10:22 --> Security Class Initialized
INFO - 2023-05-23 11:10:22 --> Input Class Initialized
INFO - 2023-05-23 11:10:22 --> Language Class Initialized
INFO - 2023-05-23 11:10:22 --> Loader Class Initialized
INFO - 2023-05-23 11:10:22 --> Helper loaded: url_helper
INFO - 2023-05-23 11:10:22 --> Helper loaded: form_helper
INFO - 2023-05-23 11:10:22 --> Database Driver Class Initialized
INFO - 2023-05-23 11:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:10:22 --> Form Validation Class Initialized
INFO - 2023-05-23 11:10:22 --> Controller Class Initialized
INFO - 2023-05-23 11:10:22 --> Model "m_user" initialized
INFO - 2023-05-23 11:10:22 --> Config Class Initialized
INFO - 2023-05-23 11:10:22 --> Hooks Class Initialized
INFO - 2023-05-23 11:10:22 --> Utf8 Class Initialized
INFO - 2023-05-23 11:10:22 --> URI Class Initialized
INFO - 2023-05-23 11:10:22 --> Router Class Initialized
INFO - 2023-05-23 11:10:22 --> Output Class Initialized
INFO - 2023-05-23 11:10:22 --> Security Class Initialized
INFO - 2023-05-23 11:10:22 --> Input Class Initialized
INFO - 2023-05-23 11:10:22 --> Language Class Initialized
INFO - 2023-05-23 11:10:22 --> Loader Class Initialized
INFO - 2023-05-23 11:10:22 --> Helper loaded: url_helper
INFO - 2023-05-23 11:10:22 --> Helper loaded: form_helper
INFO - 2023-05-23 11:10:22 --> Database Driver Class Initialized
INFO - 2023-05-23 11:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:10:22 --> Form Validation Class Initialized
INFO - 2023-05-23 11:10:22 --> Controller Class Initialized
INFO - 2023-05-23 11:10:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-23 11:10:22 --> Final output sent to browser
INFO - 2023-05-23 11:10:23 --> Config Class Initialized
INFO - 2023-05-23 11:10:23 --> Hooks Class Initialized
INFO - 2023-05-23 11:10:23 --> Utf8 Class Initialized
INFO - 2023-05-23 11:10:23 --> URI Class Initialized
INFO - 2023-05-23 11:10:23 --> Router Class Initialized
INFO - 2023-05-23 11:10:23 --> Output Class Initialized
INFO - 2023-05-23 11:10:23 --> Security Class Initialized
INFO - 2023-05-23 11:10:23 --> Input Class Initialized
INFO - 2023-05-23 11:10:23 --> Language Class Initialized
INFO - 2023-05-23 11:10:23 --> Loader Class Initialized
INFO - 2023-05-23 11:10:23 --> Helper loaded: url_helper
INFO - 2023-05-23 11:10:23 --> Helper loaded: form_helper
INFO - 2023-05-23 11:10:23 --> Database Driver Class Initialized
INFO - 2023-05-23 11:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:10:23 --> Form Validation Class Initialized
INFO - 2023-05-23 11:10:23 --> Controller Class Initialized
INFO - 2023-05-23 11:10:23 --> Model "m_user" initialized
INFO - 2023-05-23 11:10:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-23 11:10:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-23 11:10:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-23 11:10:23 --> Final output sent to browser
INFO - 2023-05-23 11:10:28 --> Config Class Initialized
INFO - 2023-05-23 11:10:28 --> Hooks Class Initialized
INFO - 2023-05-23 11:10:28 --> Utf8 Class Initialized
INFO - 2023-05-23 11:10:28 --> URI Class Initialized
INFO - 2023-05-23 11:10:28 --> Router Class Initialized
INFO - 2023-05-23 11:10:28 --> Output Class Initialized
INFO - 2023-05-23 11:10:28 --> Security Class Initialized
INFO - 2023-05-23 11:10:28 --> Input Class Initialized
INFO - 2023-05-23 11:10:28 --> Language Class Initialized
INFO - 2023-05-23 11:10:28 --> Loader Class Initialized
INFO - 2023-05-23 11:10:28 --> Helper loaded: url_helper
INFO - 2023-05-23 11:10:28 --> Helper loaded: form_helper
INFO - 2023-05-23 11:10:28 --> Database Driver Class Initialized
INFO - 2023-05-23 11:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:10:28 --> Form Validation Class Initialized
INFO - 2023-05-23 11:10:28 --> Controller Class Initialized
INFO - 2023-05-23 11:10:28 --> Model "m_user" initialized
INFO - 2023-05-23 11:10:28 --> Config Class Initialized
INFO - 2023-05-23 11:10:28 --> Hooks Class Initialized
INFO - 2023-05-23 11:10:28 --> Utf8 Class Initialized
INFO - 2023-05-23 11:10:28 --> URI Class Initialized
INFO - 2023-05-23 11:10:28 --> Router Class Initialized
INFO - 2023-05-23 11:10:28 --> Output Class Initialized
INFO - 2023-05-23 11:10:28 --> Security Class Initialized
INFO - 2023-05-23 11:10:28 --> Input Class Initialized
INFO - 2023-05-23 11:10:28 --> Language Class Initialized
INFO - 2023-05-23 11:10:28 --> Loader Class Initialized
INFO - 2023-05-23 11:10:28 --> Helper loaded: url_helper
INFO - 2023-05-23 11:10:28 --> Helper loaded: form_helper
INFO - 2023-05-23 11:10:28 --> Database Driver Class Initialized
INFO - 2023-05-23 11:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:10:28 --> Form Validation Class Initialized
INFO - 2023-05-23 11:10:28 --> Controller Class Initialized
INFO - 2023-05-23 11:10:28 --> Model "m_user" initialized
INFO - 2023-05-23 11:10:28 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:10:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:10:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:10:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 11:10:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:10:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:10:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 11:10:28 --> Final output sent to browser
INFO - 2023-05-23 11:10:30 --> Config Class Initialized
INFO - 2023-05-23 11:10:30 --> Hooks Class Initialized
INFO - 2023-05-23 11:10:30 --> Utf8 Class Initialized
INFO - 2023-05-23 11:10:30 --> URI Class Initialized
INFO - 2023-05-23 11:10:30 --> Router Class Initialized
INFO - 2023-05-23 11:10:30 --> Output Class Initialized
INFO - 2023-05-23 11:10:30 --> Security Class Initialized
INFO - 2023-05-23 11:10:30 --> Input Class Initialized
INFO - 2023-05-23 11:10:30 --> Language Class Initialized
INFO - 2023-05-23 11:10:30 --> Loader Class Initialized
INFO - 2023-05-23 11:10:30 --> Helper loaded: url_helper
INFO - 2023-05-23 11:10:30 --> Helper loaded: form_helper
INFO - 2023-05-23 11:10:30 --> Database Driver Class Initialized
INFO - 2023-05-23 11:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:10:30 --> Form Validation Class Initialized
INFO - 2023-05-23 11:10:30 --> Controller Class Initialized
INFO - 2023-05-23 11:10:30 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:10:30 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:10:30 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:10:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:10:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:10:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 70
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 71
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 83
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 83
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 84
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 84
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 105
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 106
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 107
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 108
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 109
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 123
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 123
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 124
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 124
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 145
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 146
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 147
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 148
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 149
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 163
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 163
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 164
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 164
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 186
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 187
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 188
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 189
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 190
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 204
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 204
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 205
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 205
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 226
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 227
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 228
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 229
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 230
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 244
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 244
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 245
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 245
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 266
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 267
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 268
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 269
ERROR - 2023-05-23 11:10:30 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 270
INFO - 2023-05-23 11:13:53 --> Config Class Initialized
INFO - 2023-05-23 11:13:53 --> Hooks Class Initialized
INFO - 2023-05-23 11:13:53 --> Utf8 Class Initialized
INFO - 2023-05-23 11:13:53 --> URI Class Initialized
INFO - 2023-05-23 11:13:53 --> Router Class Initialized
INFO - 2023-05-23 11:13:53 --> Output Class Initialized
INFO - 2023-05-23 11:13:53 --> Security Class Initialized
INFO - 2023-05-23 11:13:53 --> Input Class Initialized
INFO - 2023-05-23 11:13:53 --> Language Class Initialized
INFO - 2023-05-23 11:13:53 --> Loader Class Initialized
INFO - 2023-05-23 11:13:53 --> Helper loaded: url_helper
INFO - 2023-05-23 11:13:53 --> Helper loaded: form_helper
INFO - 2023-05-23 11:13:53 --> Database Driver Class Initialized
INFO - 2023-05-23 11:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:13:53 --> Form Validation Class Initialized
INFO - 2023-05-23 11:13:53 --> Controller Class Initialized
INFO - 2023-05-23 11:13:53 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:13:53 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:13:53 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 70
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 71
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 83
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 83
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 84
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 84
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 105
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 106
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 107
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 108
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 109
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 123
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 123
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 124
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 124
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 145
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 146
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 147
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 148
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 149
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 163
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 163
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 164
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 164
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 186
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 187
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 188
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 189
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 190
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 204
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 204
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 205
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 205
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 226
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 227
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 228
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 229
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 230
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 244
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 244
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 245
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 245
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 266
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 267
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 268
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 269
ERROR - 2023-05-23 11:13:53 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 270
INFO - 2023-05-23 11:14:48 --> Config Class Initialized
INFO - 2023-05-23 11:14:48 --> Hooks Class Initialized
INFO - 2023-05-23 11:14:48 --> Utf8 Class Initialized
INFO - 2023-05-23 11:14:48 --> URI Class Initialized
INFO - 2023-05-23 11:14:48 --> Router Class Initialized
INFO - 2023-05-23 11:14:48 --> Output Class Initialized
INFO - 2023-05-23 11:14:48 --> Security Class Initialized
INFO - 2023-05-23 11:14:48 --> Input Class Initialized
INFO - 2023-05-23 11:14:48 --> Language Class Initialized
INFO - 2023-05-23 11:14:48 --> Loader Class Initialized
INFO - 2023-05-23 11:14:48 --> Helper loaded: url_helper
INFO - 2023-05-23 11:14:48 --> Helper loaded: form_helper
INFO - 2023-05-23 11:14:48 --> Database Driver Class Initialized
INFO - 2023-05-23 11:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:14:48 --> Form Validation Class Initialized
INFO - 2023-05-23 11:14:48 --> Controller Class Initialized
INFO - 2023-05-23 11:14:48 --> Model "m_user" initialized
INFO - 2023-05-23 11:14:48 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:14:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:14:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:14:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 11:14:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:14:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:14:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 11:14:48 --> Final output sent to browser
INFO - 2023-05-23 11:14:49 --> Config Class Initialized
INFO - 2023-05-23 11:14:49 --> Hooks Class Initialized
INFO - 2023-05-23 11:14:49 --> Utf8 Class Initialized
INFO - 2023-05-23 11:14:49 --> URI Class Initialized
INFO - 2023-05-23 11:14:49 --> Router Class Initialized
INFO - 2023-05-23 11:14:49 --> Output Class Initialized
INFO - 2023-05-23 11:14:49 --> Security Class Initialized
INFO - 2023-05-23 11:14:49 --> Input Class Initialized
INFO - 2023-05-23 11:14:49 --> Language Class Initialized
INFO - 2023-05-23 11:14:49 --> Loader Class Initialized
INFO - 2023-05-23 11:14:49 --> Helper loaded: url_helper
INFO - 2023-05-23 11:14:49 --> Helper loaded: form_helper
INFO - 2023-05-23 11:14:49 --> Database Driver Class Initialized
INFO - 2023-05-23 11:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:14:49 --> Form Validation Class Initialized
INFO - 2023-05-23 11:14:49 --> Controller Class Initialized
INFO - 2023-05-23 11:14:49 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:14:49 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:14:49 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 29
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 30
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 31
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 32
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 33
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 34
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 35
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 38
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 39
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 40
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 41
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 42
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 43
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 44
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 47
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 48
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 49
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 50
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 51
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 57
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 58
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 59
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 60
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 61
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 62
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 65
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 66
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 67
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 68
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 69
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 70
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 71
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 80
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 81
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 82
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 83
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 83
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 84
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 84
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 105
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 106
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 107
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 108
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 109
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 120
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 121
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 122
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 123
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 123
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 124
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 124
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 145
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 146
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 147
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 148
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v2hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 149
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 160
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 161
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 162
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 163
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 163
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 164
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 164
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 186
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 187
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 188
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 189
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v3hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 190
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 201
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 202
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 203
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 204
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 204
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 205
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 205
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 226
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 227
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 228
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 229
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v4hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 230
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5sp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 241
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5puas C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 242
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5netral C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 243
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5tp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 244
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 244
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5stp C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 245
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: totaldb C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 245
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 266
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 267
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 268
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 269
ERROR - 2023-05-23 11:14:50 --> Severity: Notice --> Undefined variable: v5hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 270
INFO - 2023-05-23 11:15:24 --> Config Class Initialized
INFO - 2023-05-23 11:15:24 --> Hooks Class Initialized
INFO - 2023-05-23 11:15:24 --> Utf8 Class Initialized
INFO - 2023-05-23 11:15:24 --> URI Class Initialized
INFO - 2023-05-23 11:15:24 --> Router Class Initialized
INFO - 2023-05-23 11:15:24 --> Output Class Initialized
INFO - 2023-05-23 11:15:24 --> Security Class Initialized
INFO - 2023-05-23 11:15:24 --> Input Class Initialized
INFO - 2023-05-23 11:15:24 --> Language Class Initialized
INFO - 2023-05-23 11:15:24 --> Loader Class Initialized
INFO - 2023-05-23 11:15:24 --> Helper loaded: url_helper
INFO - 2023-05-23 11:15:24 --> Helper loaded: form_helper
INFO - 2023-05-23 11:15:24 --> Database Driver Class Initialized
INFO - 2023-05-23 11:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:15:24 --> Form Validation Class Initialized
INFO - 2023-05-23 11:15:24 --> Controller Class Initialized
INFO - 2023-05-23 11:15:24 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:15:24 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:15:24 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:15:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:15:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:15:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 11:15:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 11:15:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:15:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:15:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 11:15:24 --> Final output sent to browser
INFO - 2023-05-23 11:17:44 --> Config Class Initialized
INFO - 2023-05-23 11:17:44 --> Hooks Class Initialized
INFO - 2023-05-23 11:17:44 --> Utf8 Class Initialized
INFO - 2023-05-23 11:17:44 --> URI Class Initialized
INFO - 2023-05-23 11:17:44 --> Router Class Initialized
INFO - 2023-05-23 11:17:44 --> Output Class Initialized
INFO - 2023-05-23 11:17:44 --> Security Class Initialized
INFO - 2023-05-23 11:17:44 --> Input Class Initialized
INFO - 2023-05-23 11:17:44 --> Language Class Initialized
INFO - 2023-05-23 11:17:44 --> Loader Class Initialized
INFO - 2023-05-23 11:17:44 --> Helper loaded: url_helper
INFO - 2023-05-23 11:17:44 --> Helper loaded: form_helper
INFO - 2023-05-23 11:17:44 --> Database Driver Class Initialized
INFO - 2023-05-23 11:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:17:44 --> Form Validation Class Initialized
INFO - 2023-05-23 11:17:44 --> Controller Class Initialized
INFO - 2023-05-23 11:17:44 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:17:44 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:17:44 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:17:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:17:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:17:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 11:17:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 11:17:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:17:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:17:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 11:17:44 --> Final output sent to browser
INFO - 2023-05-23 11:17:53 --> Config Class Initialized
INFO - 2023-05-23 11:17:53 --> Hooks Class Initialized
INFO - 2023-05-23 11:17:53 --> Utf8 Class Initialized
INFO - 2023-05-23 11:17:53 --> URI Class Initialized
INFO - 2023-05-23 11:17:53 --> Router Class Initialized
INFO - 2023-05-23 11:17:53 --> Output Class Initialized
INFO - 2023-05-23 11:17:53 --> Security Class Initialized
INFO - 2023-05-23 11:17:53 --> Input Class Initialized
INFO - 2023-05-23 11:17:53 --> Language Class Initialized
INFO - 2023-05-23 11:17:53 --> Loader Class Initialized
INFO - 2023-05-23 11:17:53 --> Helper loaded: url_helper
INFO - 2023-05-23 11:17:53 --> Helper loaded: form_helper
INFO - 2023-05-23 11:17:53 --> Database Driver Class Initialized
INFO - 2023-05-23 11:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:17:53 --> Form Validation Class Initialized
INFO - 2023-05-23 11:17:53 --> Controller Class Initialized
INFO - 2023-05-23 11:17:53 --> Model "m_user" initialized
INFO - 2023-05-23 11:17:53 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:17:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:17:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:17:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 11:17:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:17:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:17:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 11:17:53 --> Final output sent to browser
INFO - 2023-05-23 11:17:55 --> Config Class Initialized
INFO - 2023-05-23 11:17:55 --> Hooks Class Initialized
INFO - 2023-05-23 11:17:55 --> Utf8 Class Initialized
INFO - 2023-05-23 11:17:55 --> URI Class Initialized
INFO - 2023-05-23 11:17:55 --> Router Class Initialized
INFO - 2023-05-23 11:17:55 --> Output Class Initialized
INFO - 2023-05-23 11:17:55 --> Security Class Initialized
INFO - 2023-05-23 11:17:55 --> Input Class Initialized
INFO - 2023-05-23 11:17:55 --> Language Class Initialized
INFO - 2023-05-23 11:17:55 --> Loader Class Initialized
INFO - 2023-05-23 11:17:55 --> Helper loaded: url_helper
INFO - 2023-05-23 11:17:55 --> Helper loaded: form_helper
INFO - 2023-05-23 11:17:55 --> Database Driver Class Initialized
INFO - 2023-05-23 11:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:17:55 --> Form Validation Class Initialized
INFO - 2023-05-23 11:17:55 --> Controller Class Initialized
INFO - 2023-05-23 11:17:55 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:17:55 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:17:55 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 11:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 11:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:17:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 11:17:56 --> Final output sent to browser
INFO - 2023-05-23 11:18:51 --> Config Class Initialized
INFO - 2023-05-23 11:18:51 --> Hooks Class Initialized
INFO - 2023-05-23 11:18:51 --> Utf8 Class Initialized
INFO - 2023-05-23 11:18:51 --> URI Class Initialized
INFO - 2023-05-23 11:18:51 --> Router Class Initialized
INFO - 2023-05-23 11:18:51 --> Output Class Initialized
INFO - 2023-05-23 11:18:51 --> Security Class Initialized
INFO - 2023-05-23 11:18:51 --> Input Class Initialized
INFO - 2023-05-23 11:18:51 --> Language Class Initialized
INFO - 2023-05-23 11:18:51 --> Loader Class Initialized
INFO - 2023-05-23 11:18:51 --> Helper loaded: url_helper
INFO - 2023-05-23 11:18:51 --> Helper loaded: form_helper
INFO - 2023-05-23 11:18:51 --> Database Driver Class Initialized
INFO - 2023-05-23 11:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:18:51 --> Form Validation Class Initialized
INFO - 2023-05-23 11:18:51 --> Controller Class Initialized
INFO - 2023-05-23 11:18:51 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:18:51 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:18:51 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:18:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:18:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:18:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 11:18:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 11:18:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:18:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:18:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 11:18:51 --> Final output sent to browser
INFO - 2023-05-23 11:20:04 --> Config Class Initialized
INFO - 2023-05-23 11:20:04 --> Hooks Class Initialized
INFO - 2023-05-23 11:20:04 --> Utf8 Class Initialized
INFO - 2023-05-23 11:20:04 --> URI Class Initialized
INFO - 2023-05-23 11:20:04 --> Router Class Initialized
INFO - 2023-05-23 11:20:04 --> Output Class Initialized
INFO - 2023-05-23 11:20:04 --> Security Class Initialized
INFO - 2023-05-23 11:20:04 --> Input Class Initialized
INFO - 2023-05-23 11:20:04 --> Language Class Initialized
INFO - 2023-05-23 11:20:04 --> Loader Class Initialized
INFO - 2023-05-23 11:20:04 --> Helper loaded: url_helper
INFO - 2023-05-23 11:20:04 --> Helper loaded: form_helper
INFO - 2023-05-23 11:20:04 --> Database Driver Class Initialized
INFO - 2023-05-23 11:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:20:04 --> Form Validation Class Initialized
INFO - 2023-05-23 11:20:04 --> Controller Class Initialized
INFO - 2023-05-23 11:20:04 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:20:04 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:20:04 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:20:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:20:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:20:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 11:20:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 11:20:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:20:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:20:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 11:20:04 --> Final output sent to browser
INFO - 2023-05-23 11:21:43 --> Config Class Initialized
INFO - 2023-05-23 11:21:43 --> Hooks Class Initialized
INFO - 2023-05-23 11:21:43 --> Utf8 Class Initialized
INFO - 2023-05-23 11:21:43 --> URI Class Initialized
INFO - 2023-05-23 11:21:43 --> Router Class Initialized
INFO - 2023-05-23 11:21:43 --> Output Class Initialized
INFO - 2023-05-23 11:21:43 --> Security Class Initialized
INFO - 2023-05-23 11:21:43 --> Input Class Initialized
INFO - 2023-05-23 11:21:43 --> Language Class Initialized
INFO - 2023-05-23 11:21:43 --> Loader Class Initialized
INFO - 2023-05-23 11:21:43 --> Helper loaded: url_helper
INFO - 2023-05-23 11:21:43 --> Helper loaded: form_helper
INFO - 2023-05-23 11:21:43 --> Database Driver Class Initialized
INFO - 2023-05-23 11:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 11:21:43 --> Form Validation Class Initialized
INFO - 2023-05-23 11:21:43 --> Controller Class Initialized
INFO - 2023-05-23 11:21:43 --> Model "m_datatrain" initialized
INFO - 2023-05-23 11:21:43 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 11:21:43 --> Model "m_datatest" initialized
INFO - 2023-05-23 11:21:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 11:21:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 11:21:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 11:21:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 11:21:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 11:21:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 11:21:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 11:21:43 --> Final output sent to browser
INFO - 2023-05-23 16:51:13 --> Config Class Initialized
INFO - 2023-05-23 16:51:13 --> Hooks Class Initialized
INFO - 2023-05-23 16:51:13 --> Utf8 Class Initialized
INFO - 2023-05-23 16:51:13 --> URI Class Initialized
INFO - 2023-05-23 16:51:13 --> Router Class Initialized
INFO - 2023-05-23 16:51:13 --> Output Class Initialized
INFO - 2023-05-23 16:51:13 --> Security Class Initialized
INFO - 2023-05-23 16:51:13 --> Input Class Initialized
INFO - 2023-05-23 16:51:13 --> Language Class Initialized
INFO - 2023-05-23 16:51:13 --> Loader Class Initialized
INFO - 2023-05-23 16:51:13 --> Helper loaded: url_helper
INFO - 2023-05-23 16:51:13 --> Helper loaded: form_helper
INFO - 2023-05-23 16:51:13 --> Database Driver Class Initialized
INFO - 2023-05-23 16:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:51:13 --> Form Validation Class Initialized
INFO - 2023-05-23 16:51:13 --> Controller Class Initialized
INFO - 2023-05-23 16:51:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-23 16:51:13 --> Final output sent to browser
INFO - 2023-05-23 16:54:18 --> Config Class Initialized
INFO - 2023-05-23 16:54:18 --> Hooks Class Initialized
INFO - 2023-05-23 16:54:18 --> Utf8 Class Initialized
INFO - 2023-05-23 16:54:18 --> URI Class Initialized
INFO - 2023-05-23 16:54:18 --> Router Class Initialized
INFO - 2023-05-23 16:54:18 --> Output Class Initialized
INFO - 2023-05-23 16:54:18 --> Security Class Initialized
INFO - 2023-05-23 16:54:18 --> Input Class Initialized
INFO - 2023-05-23 16:54:18 --> Language Class Initialized
INFO - 2023-05-23 16:54:18 --> Loader Class Initialized
INFO - 2023-05-23 16:54:18 --> Helper loaded: url_helper
INFO - 2023-05-23 16:54:18 --> Helper loaded: form_helper
INFO - 2023-05-23 16:54:18 --> Database Driver Class Initialized
INFO - 2023-05-23 16:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:54:18 --> Form Validation Class Initialized
INFO - 2023-05-23 16:54:18 --> Controller Class Initialized
INFO - 2023-05-23 16:54:18 --> Model "m_user" initialized
INFO - 2023-05-23 16:54:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-23 16:54:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-23 16:54:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-23 16:54:18 --> Final output sent to browser
INFO - 2023-05-23 16:54:22 --> Config Class Initialized
INFO - 2023-05-23 16:54:22 --> Hooks Class Initialized
INFO - 2023-05-23 16:54:22 --> Utf8 Class Initialized
INFO - 2023-05-23 16:54:22 --> URI Class Initialized
INFO - 2023-05-23 16:54:22 --> Router Class Initialized
INFO - 2023-05-23 16:54:22 --> Output Class Initialized
INFO - 2023-05-23 16:54:22 --> Security Class Initialized
INFO - 2023-05-23 16:54:22 --> Input Class Initialized
INFO - 2023-05-23 16:54:22 --> Language Class Initialized
INFO - 2023-05-23 16:54:22 --> Loader Class Initialized
INFO - 2023-05-23 16:54:22 --> Helper loaded: url_helper
INFO - 2023-05-23 16:54:22 --> Helper loaded: form_helper
INFO - 2023-05-23 16:54:22 --> Database Driver Class Initialized
INFO - 2023-05-23 16:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:54:22 --> Form Validation Class Initialized
INFO - 2023-05-23 16:54:22 --> Controller Class Initialized
INFO - 2023-05-23 16:54:22 --> Model "m_user" initialized
INFO - 2023-05-23 16:54:22 --> Config Class Initialized
INFO - 2023-05-23 16:54:22 --> Hooks Class Initialized
INFO - 2023-05-23 16:54:22 --> Utf8 Class Initialized
INFO - 2023-05-23 16:54:22 --> URI Class Initialized
INFO - 2023-05-23 16:54:22 --> Router Class Initialized
INFO - 2023-05-23 16:54:22 --> Output Class Initialized
INFO - 2023-05-23 16:54:22 --> Security Class Initialized
INFO - 2023-05-23 16:54:22 --> Input Class Initialized
INFO - 2023-05-23 16:54:22 --> Language Class Initialized
INFO - 2023-05-23 16:54:22 --> Loader Class Initialized
INFO - 2023-05-23 16:54:22 --> Helper loaded: url_helper
INFO - 2023-05-23 16:54:22 --> Helper loaded: form_helper
INFO - 2023-05-23 16:54:22 --> Database Driver Class Initialized
INFO - 2023-05-23 16:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:54:23 --> Form Validation Class Initialized
INFO - 2023-05-23 16:54:23 --> Controller Class Initialized
INFO - 2023-05-23 16:54:23 --> Model "m_user" initialized
INFO - 2023-05-23 16:54:23 --> Model "m_datatrain" initialized
INFO - 2023-05-23 16:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 16:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 16:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 16:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 16:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 16:54:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-23 16:54:23 --> Final output sent to browser
INFO - 2023-05-23 16:54:25 --> Config Class Initialized
INFO - 2023-05-23 16:54:25 --> Hooks Class Initialized
INFO - 2023-05-23 16:54:25 --> Utf8 Class Initialized
INFO - 2023-05-23 16:54:25 --> URI Class Initialized
INFO - 2023-05-23 16:54:25 --> Router Class Initialized
INFO - 2023-05-23 16:54:25 --> Output Class Initialized
INFO - 2023-05-23 16:54:25 --> Security Class Initialized
INFO - 2023-05-23 16:54:25 --> Input Class Initialized
INFO - 2023-05-23 16:54:25 --> Language Class Initialized
INFO - 2023-05-23 16:54:25 --> Loader Class Initialized
INFO - 2023-05-23 16:54:25 --> Helper loaded: url_helper
INFO - 2023-05-23 16:54:25 --> Helper loaded: form_helper
INFO - 2023-05-23 16:54:25 --> Database Driver Class Initialized
INFO - 2023-05-23 16:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:54:25 --> Form Validation Class Initialized
INFO - 2023-05-23 16:54:25 --> Controller Class Initialized
INFO - 2023-05-23 16:54:25 --> Model "m_datatrain" initialized
INFO - 2023-05-23 16:54:25 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 16:54:25 --> Model "m_datatest" initialized
INFO - 2023-05-23 16:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 16:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 16:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 16:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 16:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 16:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 16:54:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 16:54:25 --> Final output sent to browser
INFO - 2023-05-23 16:55:43 --> Config Class Initialized
INFO - 2023-05-23 16:55:43 --> Hooks Class Initialized
INFO - 2023-05-23 16:55:43 --> Utf8 Class Initialized
INFO - 2023-05-23 16:55:43 --> URI Class Initialized
INFO - 2023-05-23 16:55:43 --> Router Class Initialized
INFO - 2023-05-23 16:55:43 --> Output Class Initialized
INFO - 2023-05-23 16:55:43 --> Security Class Initialized
INFO - 2023-05-23 16:55:43 --> Input Class Initialized
INFO - 2023-05-23 16:55:43 --> Language Class Initialized
INFO - 2023-05-23 16:55:43 --> Loader Class Initialized
INFO - 2023-05-23 16:55:43 --> Helper loaded: url_helper
INFO - 2023-05-23 16:55:43 --> Helper loaded: form_helper
INFO - 2023-05-23 16:55:43 --> Database Driver Class Initialized
INFO - 2023-05-23 16:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:55:43 --> Form Validation Class Initialized
INFO - 2023-05-23 16:55:43 --> Controller Class Initialized
INFO - 2023-05-23 16:55:43 --> Model "m_datatrain" initialized
INFO - 2023-05-23 16:55:43 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 16:55:43 --> Model "m_datatest" initialized
INFO - 2023-05-23 16:55:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 16:55:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 16:55:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 16:55:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 16:55:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 16:55:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 16:55:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 16:55:43 --> Final output sent to browser
INFO - 2023-05-23 16:55:59 --> Config Class Initialized
INFO - 2023-05-23 16:55:59 --> Hooks Class Initialized
INFO - 2023-05-23 16:55:59 --> Utf8 Class Initialized
INFO - 2023-05-23 16:55:59 --> URI Class Initialized
INFO - 2023-05-23 16:55:59 --> Router Class Initialized
INFO - 2023-05-23 16:55:59 --> Output Class Initialized
INFO - 2023-05-23 16:55:59 --> Security Class Initialized
INFO - 2023-05-23 16:55:59 --> Input Class Initialized
INFO - 2023-05-23 16:55:59 --> Language Class Initialized
INFO - 2023-05-23 16:55:59 --> Loader Class Initialized
INFO - 2023-05-23 16:55:59 --> Helper loaded: url_helper
INFO - 2023-05-23 16:55:59 --> Helper loaded: form_helper
INFO - 2023-05-23 16:55:59 --> Database Driver Class Initialized
INFO - 2023-05-23 16:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:56:00 --> Form Validation Class Initialized
INFO - 2023-05-23 16:56:00 --> Controller Class Initialized
INFO - 2023-05-23 16:56:00 --> Model "m_datatrain" initialized
INFO - 2023-05-23 16:56:00 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 16:56:00 --> Model "m_datatest" initialized
INFO - 2023-05-23 16:56:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 16:56:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 16:56:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 16:56:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 16:56:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 16:56:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 16:56:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 16:56:00 --> Final output sent to browser
INFO - 2023-05-23 16:56:15 --> Config Class Initialized
INFO - 2023-05-23 16:56:15 --> Hooks Class Initialized
INFO - 2023-05-23 16:56:15 --> Utf8 Class Initialized
INFO - 2023-05-23 16:56:15 --> URI Class Initialized
INFO - 2023-05-23 16:56:15 --> Router Class Initialized
INFO - 2023-05-23 16:56:15 --> Output Class Initialized
INFO - 2023-05-23 16:56:15 --> Security Class Initialized
INFO - 2023-05-23 16:56:15 --> Input Class Initialized
INFO - 2023-05-23 16:56:15 --> Language Class Initialized
INFO - 2023-05-23 16:56:15 --> Loader Class Initialized
INFO - 2023-05-23 16:56:15 --> Helper loaded: url_helper
INFO - 2023-05-23 16:56:15 --> Helper loaded: form_helper
INFO - 2023-05-23 16:56:15 --> Database Driver Class Initialized
INFO - 2023-05-23 16:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:56:15 --> Form Validation Class Initialized
INFO - 2023-05-23 16:56:15 --> Controller Class Initialized
INFO - 2023-05-23 16:56:15 --> Model "m_datatrain" initialized
INFO - 2023-05-23 16:56:15 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 16:56:15 --> Model "m_datatest" initialized
INFO - 2023-05-23 16:56:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 16:56:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 16:56:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 16:56:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 16:56:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 16:56:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 16:56:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 16:56:16 --> Final output sent to browser
INFO - 2023-05-23 16:56:42 --> Config Class Initialized
INFO - 2023-05-23 16:56:42 --> Hooks Class Initialized
INFO - 2023-05-23 16:56:42 --> Utf8 Class Initialized
INFO - 2023-05-23 16:56:42 --> URI Class Initialized
INFO - 2023-05-23 16:56:42 --> Router Class Initialized
INFO - 2023-05-23 16:56:42 --> Output Class Initialized
INFO - 2023-05-23 16:56:42 --> Security Class Initialized
INFO - 2023-05-23 16:56:42 --> Input Class Initialized
INFO - 2023-05-23 16:56:42 --> Language Class Initialized
INFO - 2023-05-23 16:56:42 --> Loader Class Initialized
INFO - 2023-05-23 16:56:42 --> Helper loaded: url_helper
INFO - 2023-05-23 16:56:42 --> Helper loaded: form_helper
INFO - 2023-05-23 16:56:42 --> Database Driver Class Initialized
INFO - 2023-05-23 16:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:56:42 --> Form Validation Class Initialized
INFO - 2023-05-23 16:56:42 --> Controller Class Initialized
INFO - 2023-05-23 16:56:42 --> Model "m_datatrain" initialized
INFO - 2023-05-23 16:56:42 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 16:56:42 --> Model "m_datatest" initialized
INFO - 2023-05-23 16:56:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 16:56:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 16:56:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 16:56:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 16:56:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 16:56:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 16:56:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 16:56:42 --> Final output sent to browser
INFO - 2023-05-23 16:57:04 --> Config Class Initialized
INFO - 2023-05-23 16:57:04 --> Hooks Class Initialized
INFO - 2023-05-23 16:57:04 --> Utf8 Class Initialized
INFO - 2023-05-23 16:57:04 --> URI Class Initialized
INFO - 2023-05-23 16:57:04 --> Router Class Initialized
INFO - 2023-05-23 16:57:04 --> Output Class Initialized
INFO - 2023-05-23 16:57:04 --> Security Class Initialized
INFO - 2023-05-23 16:57:04 --> Input Class Initialized
INFO - 2023-05-23 16:57:04 --> Language Class Initialized
INFO - 2023-05-23 16:57:04 --> Loader Class Initialized
INFO - 2023-05-23 16:57:04 --> Helper loaded: url_helper
INFO - 2023-05-23 16:57:04 --> Helper loaded: form_helper
INFO - 2023-05-23 16:57:04 --> Database Driver Class Initialized
INFO - 2023-05-23 16:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:57:04 --> Form Validation Class Initialized
INFO - 2023-05-23 16:57:04 --> Controller Class Initialized
INFO - 2023-05-23 16:57:04 --> Model "m_datatrain" initialized
INFO - 2023-05-23 16:57:04 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 16:57:04 --> Model "m_datatest" initialized
INFO - 2023-05-23 16:57:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 16:57:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 16:57:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 16:57:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 16:57:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 16:57:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 16:57:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 16:57:04 --> Final output sent to browser
INFO - 2023-05-23 16:57:20 --> Config Class Initialized
INFO - 2023-05-23 16:57:20 --> Hooks Class Initialized
INFO - 2023-05-23 16:57:20 --> Utf8 Class Initialized
INFO - 2023-05-23 16:57:20 --> URI Class Initialized
INFO - 2023-05-23 16:57:20 --> Router Class Initialized
INFO - 2023-05-23 16:57:20 --> Output Class Initialized
INFO - 2023-05-23 16:57:20 --> Security Class Initialized
INFO - 2023-05-23 16:57:20 --> Input Class Initialized
INFO - 2023-05-23 16:57:20 --> Language Class Initialized
INFO - 2023-05-23 16:57:20 --> Loader Class Initialized
INFO - 2023-05-23 16:57:20 --> Helper loaded: url_helper
INFO - 2023-05-23 16:57:20 --> Helper loaded: form_helper
INFO - 2023-05-23 16:57:20 --> Database Driver Class Initialized
INFO - 2023-05-23 16:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:57:20 --> Form Validation Class Initialized
INFO - 2023-05-23 16:57:20 --> Controller Class Initialized
INFO - 2023-05-23 16:57:20 --> Model "m_datatrain" initialized
INFO - 2023-05-23 16:57:20 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 16:57:20 --> Model "m_datatest" initialized
INFO - 2023-05-23 16:57:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 16:57:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 16:57:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 16:57:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 16:57:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 16:57:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 16:57:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 16:57:20 --> Final output sent to browser
INFO - 2023-05-23 16:57:38 --> Config Class Initialized
INFO - 2023-05-23 16:57:38 --> Hooks Class Initialized
INFO - 2023-05-23 16:57:38 --> Utf8 Class Initialized
INFO - 2023-05-23 16:57:38 --> URI Class Initialized
INFO - 2023-05-23 16:57:38 --> Router Class Initialized
INFO - 2023-05-23 16:57:38 --> Output Class Initialized
INFO - 2023-05-23 16:57:38 --> Security Class Initialized
INFO - 2023-05-23 16:57:38 --> Input Class Initialized
INFO - 2023-05-23 16:57:38 --> Language Class Initialized
INFO - 2023-05-23 16:57:38 --> Loader Class Initialized
INFO - 2023-05-23 16:57:38 --> Helper loaded: url_helper
INFO - 2023-05-23 16:57:38 --> Helper loaded: form_helper
INFO - 2023-05-23 16:57:38 --> Database Driver Class Initialized
INFO - 2023-05-23 16:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:57:38 --> Form Validation Class Initialized
INFO - 2023-05-23 16:57:38 --> Controller Class Initialized
INFO - 2023-05-23 16:57:38 --> Model "m_datatrain" initialized
INFO - 2023-05-23 16:57:38 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 16:57:38 --> Model "m_datatest" initialized
INFO - 2023-05-23 16:57:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 16:57:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 16:57:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 16:57:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 16:57:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 16:57:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 16:57:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 16:57:38 --> Final output sent to browser
INFO - 2023-05-23 16:57:58 --> Config Class Initialized
INFO - 2023-05-23 16:57:58 --> Hooks Class Initialized
INFO - 2023-05-23 16:57:58 --> Utf8 Class Initialized
INFO - 2023-05-23 16:57:58 --> URI Class Initialized
INFO - 2023-05-23 16:57:58 --> Router Class Initialized
INFO - 2023-05-23 16:57:58 --> Output Class Initialized
INFO - 2023-05-23 16:57:58 --> Security Class Initialized
INFO - 2023-05-23 16:57:58 --> Input Class Initialized
INFO - 2023-05-23 16:57:58 --> Language Class Initialized
INFO - 2023-05-23 16:57:58 --> Loader Class Initialized
INFO - 2023-05-23 16:57:58 --> Helper loaded: url_helper
INFO - 2023-05-23 16:57:58 --> Helper loaded: form_helper
INFO - 2023-05-23 16:57:58 --> Database Driver Class Initialized
INFO - 2023-05-23 16:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:57:58 --> Form Validation Class Initialized
INFO - 2023-05-23 16:57:58 --> Controller Class Initialized
INFO - 2023-05-23 16:57:58 --> Model "m_datatrain" initialized
INFO - 2023-05-23 16:57:58 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 16:57:58 --> Model "m_datatest" initialized
INFO - 2023-05-23 16:57:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 16:57:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 16:57:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 16:57:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 16:57:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 16:57:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 16:57:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 16:57:58 --> Final output sent to browser
INFO - 2023-05-23 16:58:19 --> Config Class Initialized
INFO - 2023-05-23 16:58:19 --> Hooks Class Initialized
INFO - 2023-05-23 16:58:19 --> Utf8 Class Initialized
INFO - 2023-05-23 16:58:19 --> URI Class Initialized
INFO - 2023-05-23 16:58:19 --> Router Class Initialized
INFO - 2023-05-23 16:58:19 --> Output Class Initialized
INFO - 2023-05-23 16:58:19 --> Security Class Initialized
INFO - 2023-05-23 16:58:19 --> Input Class Initialized
INFO - 2023-05-23 16:58:19 --> Language Class Initialized
INFO - 2023-05-23 16:58:19 --> Loader Class Initialized
INFO - 2023-05-23 16:58:19 --> Helper loaded: url_helper
INFO - 2023-05-23 16:58:19 --> Helper loaded: form_helper
INFO - 2023-05-23 16:58:19 --> Database Driver Class Initialized
INFO - 2023-05-23 16:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 16:58:19 --> Form Validation Class Initialized
INFO - 2023-05-23 16:58:19 --> Controller Class Initialized
INFO - 2023-05-23 16:58:19 --> Model "m_datatrain" initialized
INFO - 2023-05-23 16:58:19 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 16:58:19 --> Model "m_datatest" initialized
INFO - 2023-05-23 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 16:58:19 --> Final output sent to browser
INFO - 2023-05-23 17:04:06 --> Config Class Initialized
INFO - 2023-05-23 17:04:06 --> Hooks Class Initialized
INFO - 2023-05-23 17:04:06 --> Utf8 Class Initialized
INFO - 2023-05-23 17:04:06 --> URI Class Initialized
INFO - 2023-05-23 17:04:06 --> Router Class Initialized
INFO - 2023-05-23 17:04:06 --> Output Class Initialized
INFO - 2023-05-23 17:04:06 --> Security Class Initialized
INFO - 2023-05-23 17:04:06 --> Input Class Initialized
INFO - 2023-05-23 17:04:06 --> Language Class Initialized
INFO - 2023-05-23 17:04:06 --> Loader Class Initialized
INFO - 2023-05-23 17:04:06 --> Helper loaded: url_helper
INFO - 2023-05-23 17:04:06 --> Helper loaded: form_helper
INFO - 2023-05-23 17:04:06 --> Database Driver Class Initialized
INFO - 2023-05-23 17:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:04:06 --> Form Validation Class Initialized
INFO - 2023-05-23 17:04:06 --> Controller Class Initialized
INFO - 2023-05-23 17:04:06 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:04:06 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:04:06 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:04:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:04:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:04:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:04:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:04:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:04:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:04:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:04:06 --> Final output sent to browser
INFO - 2023-05-23 17:04:18 --> Config Class Initialized
INFO - 2023-05-23 17:04:18 --> Hooks Class Initialized
INFO - 2023-05-23 17:04:18 --> Utf8 Class Initialized
INFO - 2023-05-23 17:04:18 --> URI Class Initialized
INFO - 2023-05-23 17:04:18 --> Router Class Initialized
INFO - 2023-05-23 17:04:18 --> Output Class Initialized
INFO - 2023-05-23 17:04:18 --> Security Class Initialized
INFO - 2023-05-23 17:04:18 --> Input Class Initialized
INFO - 2023-05-23 17:04:18 --> Language Class Initialized
INFO - 2023-05-23 17:04:18 --> Loader Class Initialized
INFO - 2023-05-23 17:04:18 --> Helper loaded: url_helper
INFO - 2023-05-23 17:04:18 --> Helper loaded: form_helper
INFO - 2023-05-23 17:04:18 --> Database Driver Class Initialized
INFO - 2023-05-23 17:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:04:18 --> Form Validation Class Initialized
INFO - 2023-05-23 17:04:18 --> Controller Class Initialized
INFO - 2023-05-23 17:04:18 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:04:18 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:04:18 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:04:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:04:18 --> Final output sent to browser
INFO - 2023-05-23 17:04:28 --> Config Class Initialized
INFO - 2023-05-23 17:04:28 --> Hooks Class Initialized
INFO - 2023-05-23 17:04:28 --> Utf8 Class Initialized
INFO - 2023-05-23 17:04:28 --> URI Class Initialized
INFO - 2023-05-23 17:04:28 --> Router Class Initialized
INFO - 2023-05-23 17:04:28 --> Output Class Initialized
INFO - 2023-05-23 17:04:28 --> Security Class Initialized
INFO - 2023-05-23 17:04:28 --> Input Class Initialized
INFO - 2023-05-23 17:04:28 --> Language Class Initialized
INFO - 2023-05-23 17:04:28 --> Loader Class Initialized
INFO - 2023-05-23 17:04:28 --> Helper loaded: url_helper
INFO - 2023-05-23 17:04:28 --> Helper loaded: form_helper
INFO - 2023-05-23 17:04:28 --> Database Driver Class Initialized
INFO - 2023-05-23 17:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:04:28 --> Form Validation Class Initialized
INFO - 2023-05-23 17:04:28 --> Controller Class Initialized
INFO - 2023-05-23 17:04:28 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:04:28 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:04:28 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:04:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:04:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:04:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:04:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:04:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:04:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:04:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:04:28 --> Final output sent to browser
INFO - 2023-05-23 17:05:27 --> Config Class Initialized
INFO - 2023-05-23 17:05:27 --> Hooks Class Initialized
INFO - 2023-05-23 17:05:27 --> Utf8 Class Initialized
INFO - 2023-05-23 17:05:27 --> URI Class Initialized
INFO - 2023-05-23 17:05:27 --> Router Class Initialized
INFO - 2023-05-23 17:05:27 --> Output Class Initialized
INFO - 2023-05-23 17:05:27 --> Security Class Initialized
INFO - 2023-05-23 17:05:27 --> Input Class Initialized
INFO - 2023-05-23 17:05:27 --> Language Class Initialized
INFO - 2023-05-23 17:05:27 --> Loader Class Initialized
INFO - 2023-05-23 17:05:27 --> Helper loaded: url_helper
INFO - 2023-05-23 17:05:27 --> Helper loaded: form_helper
INFO - 2023-05-23 17:05:27 --> Database Driver Class Initialized
INFO - 2023-05-23 17:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:05:27 --> Form Validation Class Initialized
INFO - 2023-05-23 17:05:27 --> Controller Class Initialized
INFO - 2023-05-23 17:05:27 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:05:27 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:05:27 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:05:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:05:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:05:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:05:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:05:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:05:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:05:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:05:28 --> Final output sent to browser
INFO - 2023-05-23 17:06:07 --> Config Class Initialized
INFO - 2023-05-23 17:06:07 --> Hooks Class Initialized
INFO - 2023-05-23 17:06:07 --> Utf8 Class Initialized
INFO - 2023-05-23 17:06:07 --> URI Class Initialized
INFO - 2023-05-23 17:06:07 --> Router Class Initialized
INFO - 2023-05-23 17:06:07 --> Output Class Initialized
INFO - 2023-05-23 17:06:07 --> Security Class Initialized
INFO - 2023-05-23 17:06:07 --> Input Class Initialized
INFO - 2023-05-23 17:06:07 --> Language Class Initialized
INFO - 2023-05-23 17:06:07 --> Loader Class Initialized
INFO - 2023-05-23 17:06:07 --> Helper loaded: url_helper
INFO - 2023-05-23 17:06:07 --> Helper loaded: form_helper
INFO - 2023-05-23 17:06:07 --> Database Driver Class Initialized
INFO - 2023-05-23 17:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:06:07 --> Form Validation Class Initialized
INFO - 2023-05-23 17:06:07 --> Controller Class Initialized
INFO - 2023-05-23 17:06:07 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:06:07 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:06:07 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:06:07 --> Final output sent to browser
INFO - 2023-05-23 17:06:31 --> Config Class Initialized
INFO - 2023-05-23 17:06:31 --> Hooks Class Initialized
INFO - 2023-05-23 17:06:31 --> Utf8 Class Initialized
INFO - 2023-05-23 17:06:31 --> URI Class Initialized
INFO - 2023-05-23 17:06:31 --> Router Class Initialized
INFO - 2023-05-23 17:06:31 --> Output Class Initialized
INFO - 2023-05-23 17:06:31 --> Security Class Initialized
INFO - 2023-05-23 17:06:31 --> Input Class Initialized
INFO - 2023-05-23 17:06:31 --> Language Class Initialized
INFO - 2023-05-23 17:06:31 --> Loader Class Initialized
INFO - 2023-05-23 17:06:31 --> Helper loaded: url_helper
INFO - 2023-05-23 17:06:31 --> Helper loaded: form_helper
INFO - 2023-05-23 17:06:31 --> Database Driver Class Initialized
INFO - 2023-05-23 17:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:06:31 --> Form Validation Class Initialized
INFO - 2023-05-23 17:06:31 --> Controller Class Initialized
INFO - 2023-05-23 17:06:31 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:06:31 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:06:31 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:06:31 --> Final output sent to browser
INFO - 2023-05-23 17:07:05 --> Config Class Initialized
INFO - 2023-05-23 17:07:05 --> Hooks Class Initialized
INFO - 2023-05-23 17:07:05 --> Utf8 Class Initialized
INFO - 2023-05-23 17:07:05 --> URI Class Initialized
INFO - 2023-05-23 17:07:05 --> Router Class Initialized
INFO - 2023-05-23 17:07:05 --> Output Class Initialized
INFO - 2023-05-23 17:07:05 --> Security Class Initialized
INFO - 2023-05-23 17:07:05 --> Input Class Initialized
INFO - 2023-05-23 17:07:05 --> Language Class Initialized
INFO - 2023-05-23 17:07:05 --> Loader Class Initialized
INFO - 2023-05-23 17:07:05 --> Helper loaded: url_helper
INFO - 2023-05-23 17:07:05 --> Helper loaded: form_helper
INFO - 2023-05-23 17:07:05 --> Database Driver Class Initialized
INFO - 2023-05-23 17:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:07:05 --> Form Validation Class Initialized
INFO - 2023-05-23 17:07:05 --> Controller Class Initialized
INFO - 2023-05-23 17:07:05 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:07:05 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:07:05 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:07:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:07:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:07:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:07:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:07:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:07:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:07:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:07:05 --> Final output sent to browser
INFO - 2023-05-23 17:07:59 --> Config Class Initialized
INFO - 2023-05-23 17:07:59 --> Hooks Class Initialized
INFO - 2023-05-23 17:07:59 --> Utf8 Class Initialized
INFO - 2023-05-23 17:07:59 --> URI Class Initialized
INFO - 2023-05-23 17:07:59 --> Router Class Initialized
INFO - 2023-05-23 17:07:59 --> Output Class Initialized
INFO - 2023-05-23 17:07:59 --> Security Class Initialized
INFO - 2023-05-23 17:07:59 --> Input Class Initialized
INFO - 2023-05-23 17:07:59 --> Language Class Initialized
INFO - 2023-05-23 17:07:59 --> Loader Class Initialized
INFO - 2023-05-23 17:07:59 --> Helper loaded: url_helper
INFO - 2023-05-23 17:07:59 --> Helper loaded: form_helper
INFO - 2023-05-23 17:07:59 --> Database Driver Class Initialized
INFO - 2023-05-23 17:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:07:59 --> Form Validation Class Initialized
INFO - 2023-05-23 17:07:59 --> Controller Class Initialized
INFO - 2023-05-23 17:07:59 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:07:59 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:07:59 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:08:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:08:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:08:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:08:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:08:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:08:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:08:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:08:00 --> Final output sent to browser
INFO - 2023-05-23 17:08:07 --> Config Class Initialized
INFO - 2023-05-23 17:08:07 --> Hooks Class Initialized
INFO - 2023-05-23 17:08:07 --> Utf8 Class Initialized
INFO - 2023-05-23 17:08:07 --> URI Class Initialized
INFO - 2023-05-23 17:08:07 --> Router Class Initialized
INFO - 2023-05-23 17:08:07 --> Output Class Initialized
INFO - 2023-05-23 17:08:07 --> Security Class Initialized
INFO - 2023-05-23 17:08:07 --> Input Class Initialized
INFO - 2023-05-23 17:08:07 --> Language Class Initialized
INFO - 2023-05-23 17:08:07 --> Loader Class Initialized
INFO - 2023-05-23 17:08:07 --> Helper loaded: url_helper
INFO - 2023-05-23 17:08:07 --> Helper loaded: form_helper
INFO - 2023-05-23 17:08:07 --> Database Driver Class Initialized
INFO - 2023-05-23 17:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:08:07 --> Form Validation Class Initialized
INFO - 2023-05-23 17:08:07 --> Controller Class Initialized
INFO - 2023-05-23 17:08:07 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:08:07 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:08:07 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:08:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:08:07 --> Final output sent to browser
INFO - 2023-05-23 17:08:44 --> Config Class Initialized
INFO - 2023-05-23 17:08:44 --> Hooks Class Initialized
INFO - 2023-05-23 17:08:44 --> Utf8 Class Initialized
INFO - 2023-05-23 17:08:44 --> URI Class Initialized
INFO - 2023-05-23 17:08:44 --> Router Class Initialized
INFO - 2023-05-23 17:08:44 --> Output Class Initialized
INFO - 2023-05-23 17:08:44 --> Security Class Initialized
INFO - 2023-05-23 17:08:44 --> Input Class Initialized
INFO - 2023-05-23 17:08:44 --> Language Class Initialized
INFO - 2023-05-23 17:08:44 --> Loader Class Initialized
INFO - 2023-05-23 17:08:44 --> Helper loaded: url_helper
INFO - 2023-05-23 17:08:44 --> Helper loaded: form_helper
INFO - 2023-05-23 17:08:44 --> Database Driver Class Initialized
INFO - 2023-05-23 17:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:08:44 --> Form Validation Class Initialized
INFO - 2023-05-23 17:08:44 --> Controller Class Initialized
INFO - 2023-05-23 17:08:44 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:08:44 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:08:44 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:08:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:08:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:08:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:08:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:08:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:08:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:08:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:08:45 --> Final output sent to browser
INFO - 2023-05-23 17:08:47 --> Config Class Initialized
INFO - 2023-05-23 17:08:47 --> Hooks Class Initialized
INFO - 2023-05-23 17:08:47 --> Utf8 Class Initialized
INFO - 2023-05-23 17:08:47 --> URI Class Initialized
INFO - 2023-05-23 17:08:47 --> Router Class Initialized
INFO - 2023-05-23 17:08:47 --> Output Class Initialized
INFO - 2023-05-23 17:08:47 --> Security Class Initialized
INFO - 2023-05-23 17:08:47 --> Input Class Initialized
INFO - 2023-05-23 17:08:47 --> Language Class Initialized
INFO - 2023-05-23 17:08:47 --> Loader Class Initialized
INFO - 2023-05-23 17:08:47 --> Helper loaded: url_helper
INFO - 2023-05-23 17:08:47 --> Helper loaded: form_helper
INFO - 2023-05-23 17:08:47 --> Database Driver Class Initialized
INFO - 2023-05-23 17:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:08:47 --> Form Validation Class Initialized
INFO - 2023-05-23 17:08:47 --> Controller Class Initialized
INFO - 2023-05-23 17:08:47 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:08:47 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:08:47 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:08:47 --> Final output sent to browser
INFO - 2023-05-23 17:08:59 --> Config Class Initialized
INFO - 2023-05-23 17:08:59 --> Hooks Class Initialized
INFO - 2023-05-23 17:08:59 --> Utf8 Class Initialized
INFO - 2023-05-23 17:08:59 --> URI Class Initialized
INFO - 2023-05-23 17:08:59 --> Router Class Initialized
INFO - 2023-05-23 17:08:59 --> Output Class Initialized
INFO - 2023-05-23 17:08:59 --> Security Class Initialized
INFO - 2023-05-23 17:08:59 --> Input Class Initialized
INFO - 2023-05-23 17:08:59 --> Language Class Initialized
INFO - 2023-05-23 17:08:59 --> Loader Class Initialized
INFO - 2023-05-23 17:08:59 --> Helper loaded: url_helper
INFO - 2023-05-23 17:08:59 --> Helper loaded: form_helper
INFO - 2023-05-23 17:08:59 --> Database Driver Class Initialized
INFO - 2023-05-23 17:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:08:59 --> Form Validation Class Initialized
INFO - 2023-05-23 17:08:59 --> Controller Class Initialized
INFO - 2023-05-23 17:08:59 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:08:59 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:08:59 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:08:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:08:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:08:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:08:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:08:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:08:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:08:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:08:59 --> Final output sent to browser
INFO - 2023-05-23 17:09:13 --> Config Class Initialized
INFO - 2023-05-23 17:09:13 --> Hooks Class Initialized
INFO - 2023-05-23 17:09:13 --> Utf8 Class Initialized
INFO - 2023-05-23 17:09:13 --> URI Class Initialized
INFO - 2023-05-23 17:09:13 --> Router Class Initialized
INFO - 2023-05-23 17:09:13 --> Output Class Initialized
INFO - 2023-05-23 17:09:13 --> Security Class Initialized
INFO - 2023-05-23 17:09:13 --> Input Class Initialized
INFO - 2023-05-23 17:09:13 --> Language Class Initialized
INFO - 2023-05-23 17:09:13 --> Loader Class Initialized
INFO - 2023-05-23 17:09:13 --> Helper loaded: url_helper
INFO - 2023-05-23 17:09:13 --> Helper loaded: form_helper
INFO - 2023-05-23 17:09:13 --> Database Driver Class Initialized
INFO - 2023-05-23 17:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:09:13 --> Form Validation Class Initialized
INFO - 2023-05-23 17:09:13 --> Controller Class Initialized
INFO - 2023-05-23 17:09:13 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:09:13 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:09:13 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:09:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:09:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:09:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:09:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:09:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:09:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:09:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:09:13 --> Final output sent to browser
INFO - 2023-05-23 17:13:13 --> Config Class Initialized
INFO - 2023-05-23 17:13:13 --> Hooks Class Initialized
INFO - 2023-05-23 17:13:13 --> Utf8 Class Initialized
INFO - 2023-05-23 17:13:13 --> URI Class Initialized
INFO - 2023-05-23 17:13:13 --> Router Class Initialized
INFO - 2023-05-23 17:13:13 --> Output Class Initialized
INFO - 2023-05-23 17:13:13 --> Security Class Initialized
INFO - 2023-05-23 17:13:13 --> Input Class Initialized
INFO - 2023-05-23 17:13:13 --> Language Class Initialized
INFO - 2023-05-23 17:13:13 --> Loader Class Initialized
INFO - 2023-05-23 17:13:13 --> Helper loaded: url_helper
INFO - 2023-05-23 17:13:13 --> Helper loaded: form_helper
INFO - 2023-05-23 17:13:13 --> Database Driver Class Initialized
INFO - 2023-05-23 17:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:13:13 --> Form Validation Class Initialized
INFO - 2023-05-23 17:13:13 --> Controller Class Initialized
INFO - 2023-05-23 17:13:13 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:13:13 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:13:13 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:13:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:13:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:13:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:13:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:13:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:13:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:13:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:13:13 --> Final output sent to browser
INFO - 2023-05-23 17:15:54 --> Config Class Initialized
INFO - 2023-05-23 17:15:54 --> Hooks Class Initialized
INFO - 2023-05-23 17:15:54 --> Utf8 Class Initialized
INFO - 2023-05-23 17:15:54 --> URI Class Initialized
INFO - 2023-05-23 17:15:54 --> Router Class Initialized
INFO - 2023-05-23 17:15:54 --> Output Class Initialized
INFO - 2023-05-23 17:15:54 --> Security Class Initialized
INFO - 2023-05-23 17:15:54 --> Input Class Initialized
INFO - 2023-05-23 17:15:54 --> Language Class Initialized
INFO - 2023-05-23 17:15:55 --> Loader Class Initialized
INFO - 2023-05-23 17:15:55 --> Helper loaded: url_helper
INFO - 2023-05-23 17:15:55 --> Helper loaded: form_helper
INFO - 2023-05-23 17:15:55 --> Database Driver Class Initialized
INFO - 2023-05-23 17:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:15:55 --> Form Validation Class Initialized
INFO - 2023-05-23 17:15:55 --> Controller Class Initialized
INFO - 2023-05-23 17:15:55 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:15:55 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:15:55 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:15:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:15:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:15:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:15:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:15:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:15:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:15:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:15:55 --> Final output sent to browser
INFO - 2023-05-23 17:18:51 --> Config Class Initialized
INFO - 2023-05-23 17:18:51 --> Hooks Class Initialized
INFO - 2023-05-23 17:18:51 --> Utf8 Class Initialized
INFO - 2023-05-23 17:18:51 --> URI Class Initialized
INFO - 2023-05-23 17:18:51 --> Router Class Initialized
INFO - 2023-05-23 17:18:51 --> Output Class Initialized
INFO - 2023-05-23 17:18:51 --> Security Class Initialized
INFO - 2023-05-23 17:18:51 --> Input Class Initialized
INFO - 2023-05-23 17:18:51 --> Language Class Initialized
INFO - 2023-05-23 17:18:51 --> Loader Class Initialized
INFO - 2023-05-23 17:18:51 --> Helper loaded: url_helper
INFO - 2023-05-23 17:18:51 --> Helper loaded: form_helper
INFO - 2023-05-23 17:18:51 --> Database Driver Class Initialized
INFO - 2023-05-23 17:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:18:51 --> Form Validation Class Initialized
INFO - 2023-05-23 17:18:51 --> Controller Class Initialized
INFO - 2023-05-23 17:18:51 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:18:51 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:18:51 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:18:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:18:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:18:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:18:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:18:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:18:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:18:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:18:52 --> Final output sent to browser
INFO - 2023-05-23 17:19:09 --> Config Class Initialized
INFO - 2023-05-23 17:19:09 --> Hooks Class Initialized
INFO - 2023-05-23 17:19:09 --> Utf8 Class Initialized
INFO - 2023-05-23 17:19:09 --> URI Class Initialized
INFO - 2023-05-23 17:19:09 --> Router Class Initialized
INFO - 2023-05-23 17:19:09 --> Output Class Initialized
INFO - 2023-05-23 17:19:09 --> Security Class Initialized
INFO - 2023-05-23 17:19:09 --> Input Class Initialized
INFO - 2023-05-23 17:19:09 --> Language Class Initialized
INFO - 2023-05-23 17:19:09 --> Loader Class Initialized
INFO - 2023-05-23 17:19:09 --> Helper loaded: url_helper
INFO - 2023-05-23 17:19:09 --> Helper loaded: form_helper
INFO - 2023-05-23 17:19:09 --> Database Driver Class Initialized
INFO - 2023-05-23 17:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:19:10 --> Form Validation Class Initialized
INFO - 2023-05-23 17:19:10 --> Controller Class Initialized
INFO - 2023-05-23 17:19:10 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:19:10 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:19:10 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:19:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:19:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:19:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:19:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:19:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:19:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:19:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:19:10 --> Final output sent to browser
INFO - 2023-05-23 17:19:55 --> Config Class Initialized
INFO - 2023-05-23 17:19:55 --> Hooks Class Initialized
INFO - 2023-05-23 17:19:55 --> Utf8 Class Initialized
INFO - 2023-05-23 17:19:55 --> URI Class Initialized
INFO - 2023-05-23 17:19:55 --> Router Class Initialized
INFO - 2023-05-23 17:19:55 --> Output Class Initialized
INFO - 2023-05-23 17:19:55 --> Security Class Initialized
INFO - 2023-05-23 17:19:55 --> Input Class Initialized
INFO - 2023-05-23 17:19:55 --> Language Class Initialized
INFO - 2023-05-23 17:19:55 --> Loader Class Initialized
INFO - 2023-05-23 17:19:55 --> Helper loaded: url_helper
INFO - 2023-05-23 17:19:55 --> Helper loaded: form_helper
INFO - 2023-05-23 17:19:55 --> Database Driver Class Initialized
INFO - 2023-05-23 17:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:19:55 --> Form Validation Class Initialized
INFO - 2023-05-23 17:19:55 --> Controller Class Initialized
INFO - 2023-05-23 17:19:55 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:19:55 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:19:55 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:19:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:19:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:19:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:19:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:19:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:19:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:19:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:19:56 --> Final output sent to browser
INFO - 2023-05-23 17:20:32 --> Config Class Initialized
INFO - 2023-05-23 17:20:32 --> Hooks Class Initialized
INFO - 2023-05-23 17:20:33 --> Utf8 Class Initialized
INFO - 2023-05-23 17:20:33 --> URI Class Initialized
INFO - 2023-05-23 17:20:33 --> Router Class Initialized
INFO - 2023-05-23 17:20:33 --> Output Class Initialized
INFO - 2023-05-23 17:20:33 --> Security Class Initialized
INFO - 2023-05-23 17:20:33 --> Input Class Initialized
INFO - 2023-05-23 17:20:33 --> Language Class Initialized
INFO - 2023-05-23 17:20:33 --> Loader Class Initialized
INFO - 2023-05-23 17:20:33 --> Helper loaded: url_helper
INFO - 2023-05-23 17:20:33 --> Helper loaded: form_helper
INFO - 2023-05-23 17:20:33 --> Database Driver Class Initialized
INFO - 2023-05-23 17:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:20:33 --> Form Validation Class Initialized
INFO - 2023-05-23 17:20:33 --> Controller Class Initialized
INFO - 2023-05-23 17:20:33 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:20:33 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:20:33 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:20:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:20:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:20:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:20:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:20:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:20:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:20:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:20:33 --> Final output sent to browser
INFO - 2023-05-23 17:27:27 --> Config Class Initialized
INFO - 2023-05-23 17:27:27 --> Hooks Class Initialized
INFO - 2023-05-23 17:27:27 --> Utf8 Class Initialized
INFO - 2023-05-23 17:27:27 --> URI Class Initialized
INFO - 2023-05-23 17:27:27 --> Router Class Initialized
INFO - 2023-05-23 17:27:27 --> Output Class Initialized
INFO - 2023-05-23 17:27:27 --> Security Class Initialized
INFO - 2023-05-23 17:27:27 --> Input Class Initialized
INFO - 2023-05-23 17:27:27 --> Language Class Initialized
INFO - 2023-05-23 17:27:27 --> Loader Class Initialized
INFO - 2023-05-23 17:27:27 --> Helper loaded: url_helper
INFO - 2023-05-23 17:27:27 --> Helper loaded: form_helper
INFO - 2023-05-23 17:27:27 --> Database Driver Class Initialized
INFO - 2023-05-23 17:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:27:27 --> Form Validation Class Initialized
INFO - 2023-05-23 17:27:27 --> Controller Class Initialized
INFO - 2023-05-23 17:27:27 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:27:27 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:27:27 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:27:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:27:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 17:27:27 --> Severity: Notice --> Undefined variable: hasilGangguanMood C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 17:27:27 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 17:27:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 17:27:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 24
ERROR - 2023-05-23 17:27:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 25
ERROR - 2023-05-23 17:27:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 25
ERROR - 2023-05-23 17:27:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 26
ERROR - 2023-05-23 17:27:27 --> Severity: Notice --> Undefined variable: v1hasilbagi C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 27
INFO - 2023-05-23 17:27:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:27:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:27:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:27:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:27:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:27:27 --> Final output sent to browser
INFO - 2023-05-23 17:28:14 --> Config Class Initialized
INFO - 2023-05-23 17:28:14 --> Hooks Class Initialized
INFO - 2023-05-23 17:28:14 --> Utf8 Class Initialized
INFO - 2023-05-23 17:28:14 --> URI Class Initialized
INFO - 2023-05-23 17:28:14 --> Router Class Initialized
INFO - 2023-05-23 17:28:14 --> Output Class Initialized
INFO - 2023-05-23 17:28:14 --> Security Class Initialized
INFO - 2023-05-23 17:28:14 --> Input Class Initialized
INFO - 2023-05-23 17:28:14 --> Language Class Initialized
INFO - 2023-05-23 17:28:14 --> Loader Class Initialized
INFO - 2023-05-23 17:28:14 --> Helper loaded: url_helper
INFO - 2023-05-23 17:28:14 --> Helper loaded: form_helper
INFO - 2023-05-23 17:28:14 --> Database Driver Class Initialized
INFO - 2023-05-23 17:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:28:14 --> Form Validation Class Initialized
INFO - 2023-05-23 17:28:14 --> Controller Class Initialized
INFO - 2023-05-23 17:28:14 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:28:14 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:28:14 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:28:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:28:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 17:28:15 --> Severity: Notice --> Undefined variable: hasilGangguanMood C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 17:28:15 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
INFO - 2023-05-23 17:28:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:28:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:28:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:28:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:28:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:28:15 --> Final output sent to browser
INFO - 2023-05-23 17:29:00 --> Config Class Initialized
INFO - 2023-05-23 17:29:00 --> Hooks Class Initialized
INFO - 2023-05-23 17:29:00 --> Utf8 Class Initialized
INFO - 2023-05-23 17:29:00 --> URI Class Initialized
INFO - 2023-05-23 17:29:00 --> Router Class Initialized
INFO - 2023-05-23 17:29:00 --> Output Class Initialized
INFO - 2023-05-23 17:29:00 --> Security Class Initialized
INFO - 2023-05-23 17:29:00 --> Input Class Initialized
INFO - 2023-05-23 17:29:00 --> Language Class Initialized
INFO - 2023-05-23 17:29:00 --> Loader Class Initialized
INFO - 2023-05-23 17:29:00 --> Helper loaded: url_helper
INFO - 2023-05-23 17:29:00 --> Helper loaded: form_helper
INFO - 2023-05-23 17:29:00 --> Database Driver Class Initialized
INFO - 2023-05-23 17:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:29:00 --> Form Validation Class Initialized
INFO - 2023-05-23 17:29:00 --> Controller Class Initialized
INFO - 2023-05-23 17:29:00 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:29:00 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:29:00 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:29:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:29:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 17:29:01 --> Severity: Notice --> Undefined variable: HasilGangguanMood C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 17:29:01 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
INFO - 2023-05-23 17:29:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:29:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:29:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:29:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:29:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:29:01 --> Final output sent to browser
INFO - 2023-05-23 17:32:46 --> Config Class Initialized
INFO - 2023-05-23 17:32:46 --> Hooks Class Initialized
INFO - 2023-05-23 17:32:46 --> Utf8 Class Initialized
INFO - 2023-05-23 17:32:46 --> URI Class Initialized
INFO - 2023-05-23 17:32:46 --> Router Class Initialized
INFO - 2023-05-23 17:32:46 --> Output Class Initialized
INFO - 2023-05-23 17:32:46 --> Security Class Initialized
INFO - 2023-05-23 17:32:46 --> Input Class Initialized
INFO - 2023-05-23 17:32:46 --> Language Class Initialized
INFO - 2023-05-23 17:32:46 --> Loader Class Initialized
INFO - 2023-05-23 17:32:46 --> Helper loaded: url_helper
INFO - 2023-05-23 17:32:46 --> Helper loaded: form_helper
INFO - 2023-05-23 17:32:46 --> Database Driver Class Initialized
INFO - 2023-05-23 17:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:32:46 --> Form Validation Class Initialized
INFO - 2023-05-23 17:32:46 --> Controller Class Initialized
INFO - 2023-05-23 17:32:46 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:32:46 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:32:46 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:32:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:32:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 17:32:47 --> Severity: Notice --> Undefined variable: HasilGangguanMood C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 17:32:47 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 17:32:47 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
INFO - 2023-05-23 17:32:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:32:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:32:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:32:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:32:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:32:47 --> Final output sent to browser
INFO - 2023-05-23 17:34:01 --> Config Class Initialized
INFO - 2023-05-23 17:34:01 --> Hooks Class Initialized
INFO - 2023-05-23 17:34:01 --> Utf8 Class Initialized
INFO - 2023-05-23 17:34:01 --> URI Class Initialized
INFO - 2023-05-23 17:34:01 --> Router Class Initialized
INFO - 2023-05-23 17:34:01 --> Output Class Initialized
INFO - 2023-05-23 17:34:01 --> Security Class Initialized
INFO - 2023-05-23 17:34:01 --> Input Class Initialized
INFO - 2023-05-23 17:34:01 --> Language Class Initialized
INFO - 2023-05-23 17:34:01 --> Loader Class Initialized
INFO - 2023-05-23 17:34:02 --> Helper loaded: url_helper
INFO - 2023-05-23 17:34:02 --> Helper loaded: form_helper
INFO - 2023-05-23 17:34:02 --> Database Driver Class Initialized
INFO - 2023-05-23 17:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:34:02 --> Form Validation Class Initialized
INFO - 2023-05-23 17:34:02 --> Controller Class Initialized
INFO - 2023-05-23 17:34:02 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:34:02 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:34:02 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:34:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:34:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 17:34:02 --> Severity: Notice --> Undefined variable: HasilGangguanMood C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
ERROR - 2023-05-23 17:34:02 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
INFO - 2023-05-23 17:34:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:34:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:34:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:34:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:34:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:34:02 --> Final output sent to browser
INFO - 2023-05-23 17:35:50 --> Config Class Initialized
INFO - 2023-05-23 17:35:50 --> Hooks Class Initialized
INFO - 2023-05-23 17:35:50 --> Utf8 Class Initialized
INFO - 2023-05-23 17:35:50 --> URI Class Initialized
INFO - 2023-05-23 17:35:50 --> Router Class Initialized
INFO - 2023-05-23 17:35:50 --> Output Class Initialized
INFO - 2023-05-23 17:35:50 --> Security Class Initialized
INFO - 2023-05-23 17:35:50 --> Input Class Initialized
INFO - 2023-05-23 17:35:50 --> Language Class Initialized
INFO - 2023-05-23 17:35:50 --> Loader Class Initialized
INFO - 2023-05-23 17:35:50 --> Helper loaded: url_helper
INFO - 2023-05-23 17:35:50 --> Helper loaded: form_helper
INFO - 2023-05-23 17:35:50 --> Database Driver Class Initialized
INFO - 2023-05-23 17:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:35:50 --> Form Validation Class Initialized
INFO - 2023-05-23 17:35:50 --> Controller Class Initialized
INFO - 2023-05-23 17:35:50 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:35:50 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:35:50 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:35:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:35:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 17:35:51 --> Severity: Notice --> Undefined variable: HasilGangguanMood C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
INFO - 2023-05-23 17:35:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:35:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:35:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:35:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:35:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:35:51 --> Final output sent to browser
INFO - 2023-05-23 17:36:24 --> Config Class Initialized
INFO - 2023-05-23 17:36:24 --> Hooks Class Initialized
INFO - 2023-05-23 17:36:24 --> Utf8 Class Initialized
INFO - 2023-05-23 17:36:24 --> URI Class Initialized
INFO - 2023-05-23 17:36:24 --> Router Class Initialized
INFO - 2023-05-23 17:36:24 --> Output Class Initialized
INFO - 2023-05-23 17:36:24 --> Security Class Initialized
INFO - 2023-05-23 17:36:24 --> Input Class Initialized
INFO - 2023-05-23 17:36:24 --> Language Class Initialized
INFO - 2023-05-23 17:36:24 --> Loader Class Initialized
INFO - 2023-05-23 17:36:24 --> Helper loaded: url_helper
INFO - 2023-05-23 17:36:24 --> Helper loaded: form_helper
INFO - 2023-05-23 17:36:24 --> Database Driver Class Initialized
INFO - 2023-05-23 17:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:36:24 --> Form Validation Class Initialized
INFO - 2023-05-23 17:36:24 --> Controller Class Initialized
INFO - 2023-05-23 17:36:24 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:36:24 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:36:24 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:36:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:36:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 17:36:24 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
INFO - 2023-05-23 17:36:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:36:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:36:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:36:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:36:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:36:24 --> Final output sent to browser
INFO - 2023-05-23 17:42:10 --> Config Class Initialized
INFO - 2023-05-23 17:42:10 --> Hooks Class Initialized
INFO - 2023-05-23 17:42:10 --> Utf8 Class Initialized
INFO - 2023-05-23 17:42:10 --> URI Class Initialized
INFO - 2023-05-23 17:42:10 --> Router Class Initialized
INFO - 2023-05-23 17:42:10 --> Output Class Initialized
INFO - 2023-05-23 17:42:10 --> Security Class Initialized
INFO - 2023-05-23 17:42:10 --> Input Class Initialized
INFO - 2023-05-23 17:42:10 --> Language Class Initialized
INFO - 2023-05-23 17:42:10 --> Loader Class Initialized
INFO - 2023-05-23 17:42:10 --> Helper loaded: url_helper
INFO - 2023-05-23 17:42:10 --> Helper loaded: form_helper
INFO - 2023-05-23 17:42:10 --> Database Driver Class Initialized
INFO - 2023-05-23 17:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:42:10 --> Form Validation Class Initialized
INFO - 2023-05-23 17:42:10 --> Controller Class Initialized
INFO - 2023-05-23 17:42:10 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:42:10 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:42:10 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:42:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:42:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:42:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:42:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:42:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:42:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:42:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:42:11 --> Final output sent to browser
INFO - 2023-05-23 17:42:46 --> Config Class Initialized
INFO - 2023-05-23 17:42:46 --> Hooks Class Initialized
INFO - 2023-05-23 17:42:46 --> Utf8 Class Initialized
INFO - 2023-05-23 17:42:46 --> URI Class Initialized
INFO - 2023-05-23 17:42:46 --> Router Class Initialized
INFO - 2023-05-23 17:42:46 --> Output Class Initialized
INFO - 2023-05-23 17:42:46 --> Security Class Initialized
INFO - 2023-05-23 17:42:46 --> Input Class Initialized
INFO - 2023-05-23 17:42:46 --> Language Class Initialized
INFO - 2023-05-23 17:42:46 --> Loader Class Initialized
INFO - 2023-05-23 17:42:46 --> Helper loaded: url_helper
INFO - 2023-05-23 17:42:46 --> Helper loaded: form_helper
INFO - 2023-05-23 17:42:46 --> Database Driver Class Initialized
INFO - 2023-05-23 17:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:42:46 --> Form Validation Class Initialized
INFO - 2023-05-23 17:42:46 --> Controller Class Initialized
INFO - 2023-05-23 17:42:46 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:42:46 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:42:46 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:42:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:42:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 17:42:46 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 23
INFO - 2023-05-23 17:42:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:42:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:42:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:42:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:42:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:42:46 --> Final output sent to browser
INFO - 2023-05-23 17:47:23 --> Config Class Initialized
INFO - 2023-05-23 17:47:23 --> Hooks Class Initialized
INFO - 2023-05-23 17:47:23 --> Utf8 Class Initialized
INFO - 2023-05-23 17:47:23 --> URI Class Initialized
INFO - 2023-05-23 17:47:23 --> Router Class Initialized
INFO - 2023-05-23 17:47:23 --> Output Class Initialized
INFO - 2023-05-23 17:47:23 --> Security Class Initialized
INFO - 2023-05-23 17:47:23 --> Input Class Initialized
INFO - 2023-05-23 17:47:23 --> Language Class Initialized
INFO - 2023-05-23 17:47:23 --> Loader Class Initialized
INFO - 2023-05-23 17:47:23 --> Helper loaded: url_helper
INFO - 2023-05-23 17:47:23 --> Helper loaded: form_helper
INFO - 2023-05-23 17:47:23 --> Database Driver Class Initialized
INFO - 2023-05-23 17:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:47:23 --> Form Validation Class Initialized
INFO - 2023-05-23 17:47:23 --> Controller Class Initialized
INFO - 2023-05-23 17:47:23 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:47:23 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:47:23 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:47:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:47:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:47:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:47:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:47:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:47:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:47:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:47:24 --> Final output sent to browser
INFO - 2023-05-23 17:47:56 --> Config Class Initialized
INFO - 2023-05-23 17:47:56 --> Hooks Class Initialized
INFO - 2023-05-23 17:47:56 --> Utf8 Class Initialized
INFO - 2023-05-23 17:47:56 --> URI Class Initialized
INFO - 2023-05-23 17:47:56 --> Router Class Initialized
INFO - 2023-05-23 17:47:56 --> Output Class Initialized
INFO - 2023-05-23 17:47:56 --> Security Class Initialized
INFO - 2023-05-23 17:47:56 --> Input Class Initialized
INFO - 2023-05-23 17:47:56 --> Language Class Initialized
INFO - 2023-05-23 17:47:56 --> Loader Class Initialized
INFO - 2023-05-23 17:47:56 --> Helper loaded: url_helper
INFO - 2023-05-23 17:47:56 --> Helper loaded: form_helper
INFO - 2023-05-23 17:47:56 --> Database Driver Class Initialized
INFO - 2023-05-23 17:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:47:56 --> Form Validation Class Initialized
INFO - 2023-05-23 17:47:56 --> Controller Class Initialized
INFO - 2023-05-23 17:47:56 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:47:56 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:47:56 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:47:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:47:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:47:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:47:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:47:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:47:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:47:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:47:56 --> Final output sent to browser
INFO - 2023-05-23 17:50:19 --> Config Class Initialized
INFO - 2023-05-23 17:50:19 --> Hooks Class Initialized
INFO - 2023-05-23 17:50:19 --> Utf8 Class Initialized
INFO - 2023-05-23 17:50:19 --> URI Class Initialized
INFO - 2023-05-23 17:50:19 --> Router Class Initialized
INFO - 2023-05-23 17:50:19 --> Output Class Initialized
INFO - 2023-05-23 17:50:19 --> Security Class Initialized
INFO - 2023-05-23 17:50:19 --> Input Class Initialized
INFO - 2023-05-23 17:50:19 --> Language Class Initialized
ERROR - 2023-05-23 17:50:19 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_penghitungan.php 17
INFO - 2023-05-23 17:50:46 --> Config Class Initialized
INFO - 2023-05-23 17:50:46 --> Hooks Class Initialized
INFO - 2023-05-23 17:50:46 --> Utf8 Class Initialized
INFO - 2023-05-23 17:50:46 --> URI Class Initialized
INFO - 2023-05-23 17:50:46 --> Router Class Initialized
INFO - 2023-05-23 17:50:46 --> Output Class Initialized
INFO - 2023-05-23 17:50:46 --> Security Class Initialized
INFO - 2023-05-23 17:50:46 --> Input Class Initialized
INFO - 2023-05-23 17:50:46 --> Language Class Initialized
INFO - 2023-05-23 17:50:46 --> Loader Class Initialized
INFO - 2023-05-23 17:50:46 --> Helper loaded: url_helper
INFO - 2023-05-23 17:50:46 --> Helper loaded: form_helper
INFO - 2023-05-23 17:50:46 --> Database Driver Class Initialized
INFO - 2023-05-23 17:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 17:50:46 --> Form Validation Class Initialized
INFO - 2023-05-23 17:50:46 --> Controller Class Initialized
INFO - 2023-05-23 17:50:46 --> Model "m_datatrain" initialized
INFO - 2023-05-23 17:50:46 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 17:50:46 --> Model "m_datatest" initialized
INFO - 2023-05-23 17:50:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 17:50:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 17:50:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 17:50:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 17:50:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 17:50:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 17:50:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 17:50:46 --> Final output sent to browser
INFO - 2023-05-23 18:06:58 --> Config Class Initialized
INFO - 2023-05-23 18:06:58 --> Hooks Class Initialized
INFO - 2023-05-23 18:06:58 --> Utf8 Class Initialized
INFO - 2023-05-23 18:06:58 --> URI Class Initialized
INFO - 2023-05-23 18:06:58 --> Router Class Initialized
INFO - 2023-05-23 18:06:58 --> Output Class Initialized
INFO - 2023-05-23 18:06:58 --> Security Class Initialized
INFO - 2023-05-23 18:06:58 --> Input Class Initialized
INFO - 2023-05-23 18:06:58 --> Language Class Initialized
INFO - 2023-05-23 18:06:58 --> Loader Class Initialized
INFO - 2023-05-23 18:06:58 --> Helper loaded: url_helper
INFO - 2023-05-23 18:06:58 --> Helper loaded: form_helper
INFO - 2023-05-23 18:06:58 --> Database Driver Class Initialized
INFO - 2023-05-23 18:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:06:58 --> Form Validation Class Initialized
INFO - 2023-05-23 18:06:58 --> Controller Class Initialized
INFO - 2023-05-23 18:06:58 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:06:58 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:06:58 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:06:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:06:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:06:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:06:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:06:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:06:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:06:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:06:58 --> Final output sent to browser
INFO - 2023-05-23 18:09:14 --> Config Class Initialized
INFO - 2023-05-23 18:09:14 --> Hooks Class Initialized
INFO - 2023-05-23 18:09:14 --> Utf8 Class Initialized
INFO - 2023-05-23 18:09:14 --> URI Class Initialized
INFO - 2023-05-23 18:09:14 --> Router Class Initialized
INFO - 2023-05-23 18:09:14 --> Output Class Initialized
INFO - 2023-05-23 18:09:14 --> Security Class Initialized
INFO - 2023-05-23 18:09:14 --> Input Class Initialized
INFO - 2023-05-23 18:09:14 --> Language Class Initialized
INFO - 2023-05-23 18:09:14 --> Loader Class Initialized
INFO - 2023-05-23 18:09:14 --> Helper loaded: url_helper
INFO - 2023-05-23 18:09:14 --> Helper loaded: form_helper
INFO - 2023-05-23 18:09:14 --> Database Driver Class Initialized
INFO - 2023-05-23 18:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:09:15 --> Form Validation Class Initialized
INFO - 2023-05-23 18:09:15 --> Controller Class Initialized
INFO - 2023-05-23 18:09:15 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:09:15 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:09:15 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:09:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:09:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:09:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:09:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:09:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:09:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:09:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:09:15 --> Final output sent to browser
INFO - 2023-05-23 18:20:29 --> Config Class Initialized
INFO - 2023-05-23 18:20:29 --> Hooks Class Initialized
INFO - 2023-05-23 18:20:29 --> Utf8 Class Initialized
INFO - 2023-05-23 18:20:29 --> URI Class Initialized
INFO - 2023-05-23 18:20:29 --> Router Class Initialized
INFO - 2023-05-23 18:20:29 --> Output Class Initialized
INFO - 2023-05-23 18:20:29 --> Security Class Initialized
INFO - 2023-05-23 18:20:29 --> Input Class Initialized
INFO - 2023-05-23 18:20:29 --> Language Class Initialized
INFO - 2023-05-23 18:20:29 --> Loader Class Initialized
INFO - 2023-05-23 18:20:29 --> Helper loaded: url_helper
INFO - 2023-05-23 18:20:29 --> Helper loaded: form_helper
INFO - 2023-05-23 18:20:29 --> Database Driver Class Initialized
INFO - 2023-05-23 18:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:20:29 --> Form Validation Class Initialized
INFO - 2023-05-23 18:20:29 --> Controller Class Initialized
INFO - 2023-05-23 18:20:29 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:20:29 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:20:29 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:20:29 --> Final output sent to browser
INFO - 2023-05-23 18:21:55 --> Config Class Initialized
INFO - 2023-05-23 18:21:55 --> Hooks Class Initialized
INFO - 2023-05-23 18:21:55 --> Utf8 Class Initialized
INFO - 2023-05-23 18:21:55 --> URI Class Initialized
INFO - 2023-05-23 18:21:55 --> Router Class Initialized
INFO - 2023-05-23 18:21:55 --> Output Class Initialized
INFO - 2023-05-23 18:21:55 --> Security Class Initialized
INFO - 2023-05-23 18:21:55 --> Input Class Initialized
INFO - 2023-05-23 18:21:55 --> Language Class Initialized
INFO - 2023-05-23 18:21:55 --> Loader Class Initialized
INFO - 2023-05-23 18:21:55 --> Helper loaded: url_helper
INFO - 2023-05-23 18:21:55 --> Helper loaded: form_helper
INFO - 2023-05-23 18:21:55 --> Database Driver Class Initialized
INFO - 2023-05-23 18:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:21:55 --> Form Validation Class Initialized
INFO - 2023-05-23 18:21:55 --> Controller Class Initialized
INFO - 2023-05-23 18:21:55 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:21:55 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:21:55 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:21:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:21:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:21:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:21:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:21:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:21:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:21:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:21:56 --> Final output sent to browser
INFO - 2023-05-23 18:23:05 --> Config Class Initialized
INFO - 2023-05-23 18:23:05 --> Hooks Class Initialized
INFO - 2023-05-23 18:23:05 --> Utf8 Class Initialized
INFO - 2023-05-23 18:23:06 --> URI Class Initialized
INFO - 2023-05-23 18:23:06 --> Router Class Initialized
INFO - 2023-05-23 18:23:06 --> Output Class Initialized
INFO - 2023-05-23 18:23:06 --> Security Class Initialized
INFO - 2023-05-23 18:23:06 --> Input Class Initialized
INFO - 2023-05-23 18:23:06 --> Language Class Initialized
INFO - 2023-05-23 18:23:06 --> Loader Class Initialized
INFO - 2023-05-23 18:23:06 --> Helper loaded: url_helper
INFO - 2023-05-23 18:23:06 --> Helper loaded: form_helper
INFO - 2023-05-23 18:23:06 --> Database Driver Class Initialized
INFO - 2023-05-23 18:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:23:06 --> Form Validation Class Initialized
INFO - 2023-05-23 18:23:06 --> Controller Class Initialized
INFO - 2023-05-23 18:23:06 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:23:06 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:23:06 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:23:06 --> Final output sent to browser
INFO - 2023-05-23 18:26:56 --> Config Class Initialized
INFO - 2023-05-23 18:26:56 --> Hooks Class Initialized
INFO - 2023-05-23 18:26:56 --> Utf8 Class Initialized
INFO - 2023-05-23 18:26:56 --> URI Class Initialized
INFO - 2023-05-23 18:26:56 --> Router Class Initialized
INFO - 2023-05-23 18:26:56 --> Output Class Initialized
INFO - 2023-05-23 18:26:56 --> Security Class Initialized
INFO - 2023-05-23 18:26:56 --> Input Class Initialized
INFO - 2023-05-23 18:26:56 --> Language Class Initialized
INFO - 2023-05-23 18:26:56 --> Loader Class Initialized
INFO - 2023-05-23 18:26:56 --> Helper loaded: url_helper
INFO - 2023-05-23 18:26:56 --> Helper loaded: form_helper
INFO - 2023-05-23 18:26:56 --> Database Driver Class Initialized
INFO - 2023-05-23 18:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:26:56 --> Form Validation Class Initialized
INFO - 2023-05-23 18:26:56 --> Controller Class Initialized
INFO - 2023-05-23 18:26:56 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:26:56 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:26:56 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:26:57 --> Final output sent to browser
INFO - 2023-05-23 18:27:33 --> Config Class Initialized
INFO - 2023-05-23 18:27:33 --> Hooks Class Initialized
INFO - 2023-05-23 18:27:33 --> Utf8 Class Initialized
INFO - 2023-05-23 18:27:33 --> URI Class Initialized
INFO - 2023-05-23 18:27:33 --> Router Class Initialized
INFO - 2023-05-23 18:27:33 --> Output Class Initialized
INFO - 2023-05-23 18:27:33 --> Security Class Initialized
INFO - 2023-05-23 18:27:33 --> Input Class Initialized
INFO - 2023-05-23 18:27:33 --> Language Class Initialized
INFO - 2023-05-23 18:27:33 --> Loader Class Initialized
INFO - 2023-05-23 18:27:33 --> Helper loaded: url_helper
INFO - 2023-05-23 18:27:33 --> Helper loaded: form_helper
INFO - 2023-05-23 18:27:33 --> Database Driver Class Initialized
INFO - 2023-05-23 18:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:27:33 --> Form Validation Class Initialized
INFO - 2023-05-23 18:27:33 --> Controller Class Initialized
INFO - 2023-05-23 18:27:33 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:27:33 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:27:33 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:27:33 --> Final output sent to browser
INFO - 2023-05-23 18:30:18 --> Config Class Initialized
INFO - 2023-05-23 18:30:18 --> Hooks Class Initialized
INFO - 2023-05-23 18:30:18 --> Utf8 Class Initialized
INFO - 2023-05-23 18:30:18 --> URI Class Initialized
INFO - 2023-05-23 18:30:18 --> Router Class Initialized
INFO - 2023-05-23 18:30:18 --> Output Class Initialized
INFO - 2023-05-23 18:30:18 --> Security Class Initialized
INFO - 2023-05-23 18:30:18 --> Input Class Initialized
INFO - 2023-05-23 18:30:18 --> Language Class Initialized
INFO - 2023-05-23 18:30:18 --> Loader Class Initialized
INFO - 2023-05-23 18:30:18 --> Helper loaded: url_helper
INFO - 2023-05-23 18:30:18 --> Helper loaded: form_helper
INFO - 2023-05-23 18:30:18 --> Database Driver Class Initialized
INFO - 2023-05-23 18:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:30:18 --> Form Validation Class Initialized
INFO - 2023-05-23 18:30:18 --> Controller Class Initialized
INFO - 2023-05-23 18:30:18 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:30:18 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:30:18 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:30:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:30:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:30:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:30:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:30:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:30:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:30:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:30:18 --> Final output sent to browser
INFO - 2023-05-23 18:31:38 --> Config Class Initialized
INFO - 2023-05-23 18:31:38 --> Hooks Class Initialized
INFO - 2023-05-23 18:31:38 --> Utf8 Class Initialized
INFO - 2023-05-23 18:31:38 --> URI Class Initialized
INFO - 2023-05-23 18:31:38 --> Router Class Initialized
INFO - 2023-05-23 18:31:38 --> Output Class Initialized
INFO - 2023-05-23 18:31:38 --> Security Class Initialized
INFO - 2023-05-23 18:31:38 --> Input Class Initialized
INFO - 2023-05-23 18:31:38 --> Language Class Initialized
INFO - 2023-05-23 18:31:38 --> Loader Class Initialized
INFO - 2023-05-23 18:31:38 --> Helper loaded: url_helper
INFO - 2023-05-23 18:31:38 --> Helper loaded: form_helper
INFO - 2023-05-23 18:31:38 --> Database Driver Class Initialized
INFO - 2023-05-23 18:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:31:38 --> Form Validation Class Initialized
INFO - 2023-05-23 18:31:38 --> Controller Class Initialized
INFO - 2023-05-23 18:31:38 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:31:38 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:31:38 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:31:38 --> Final output sent to browser
INFO - 2023-05-23 18:32:10 --> Config Class Initialized
INFO - 2023-05-23 18:32:10 --> Hooks Class Initialized
INFO - 2023-05-23 18:32:10 --> Utf8 Class Initialized
INFO - 2023-05-23 18:32:10 --> URI Class Initialized
INFO - 2023-05-23 18:32:10 --> Router Class Initialized
INFO - 2023-05-23 18:32:10 --> Output Class Initialized
INFO - 2023-05-23 18:32:10 --> Security Class Initialized
INFO - 2023-05-23 18:32:10 --> Input Class Initialized
INFO - 2023-05-23 18:32:10 --> Language Class Initialized
INFO - 2023-05-23 18:32:10 --> Loader Class Initialized
INFO - 2023-05-23 18:32:10 --> Helper loaded: url_helper
INFO - 2023-05-23 18:32:10 --> Helper loaded: form_helper
INFO - 2023-05-23 18:32:10 --> Database Driver Class Initialized
INFO - 2023-05-23 18:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:32:10 --> Form Validation Class Initialized
INFO - 2023-05-23 18:32:10 --> Controller Class Initialized
INFO - 2023-05-23 18:32:10 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:32:10 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:32:10 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:32:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:32:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:32:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:32:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:32:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:32:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:32:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:32:10 --> Final output sent to browser
INFO - 2023-05-23 18:32:20 --> Config Class Initialized
INFO - 2023-05-23 18:32:20 --> Hooks Class Initialized
INFO - 2023-05-23 18:32:20 --> Utf8 Class Initialized
INFO - 2023-05-23 18:32:20 --> URI Class Initialized
INFO - 2023-05-23 18:32:20 --> Router Class Initialized
INFO - 2023-05-23 18:32:20 --> Output Class Initialized
INFO - 2023-05-23 18:32:20 --> Security Class Initialized
INFO - 2023-05-23 18:32:20 --> Input Class Initialized
INFO - 2023-05-23 18:32:20 --> Language Class Initialized
INFO - 2023-05-23 18:32:20 --> Loader Class Initialized
INFO - 2023-05-23 18:32:20 --> Helper loaded: url_helper
INFO - 2023-05-23 18:32:20 --> Helper loaded: form_helper
INFO - 2023-05-23 18:32:20 --> Database Driver Class Initialized
INFO - 2023-05-23 18:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:32:20 --> Form Validation Class Initialized
INFO - 2023-05-23 18:32:20 --> Controller Class Initialized
INFO - 2023-05-23 18:32:20 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:32:20 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:32:20 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:32:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:32:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:32:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:32:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:32:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:32:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:32:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:32:20 --> Final output sent to browser
INFO - 2023-05-23 18:33:13 --> Config Class Initialized
INFO - 2023-05-23 18:33:13 --> Hooks Class Initialized
INFO - 2023-05-23 18:33:13 --> Utf8 Class Initialized
INFO - 2023-05-23 18:33:13 --> URI Class Initialized
INFO - 2023-05-23 18:33:13 --> Router Class Initialized
INFO - 2023-05-23 18:33:13 --> Output Class Initialized
INFO - 2023-05-23 18:33:13 --> Security Class Initialized
INFO - 2023-05-23 18:33:13 --> Input Class Initialized
INFO - 2023-05-23 18:33:13 --> Language Class Initialized
INFO - 2023-05-23 18:33:13 --> Loader Class Initialized
INFO - 2023-05-23 18:33:13 --> Helper loaded: url_helper
INFO - 2023-05-23 18:33:13 --> Helper loaded: form_helper
INFO - 2023-05-23 18:33:13 --> Database Driver Class Initialized
INFO - 2023-05-23 18:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:33:13 --> Form Validation Class Initialized
INFO - 2023-05-23 18:33:13 --> Controller Class Initialized
INFO - 2023-05-23 18:33:13 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:33:13 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:33:13 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:33:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:33:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:33:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:33:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:33:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:33:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:33:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:33:13 --> Final output sent to browser
INFO - 2023-05-23 18:34:18 --> Config Class Initialized
INFO - 2023-05-23 18:34:18 --> Hooks Class Initialized
INFO - 2023-05-23 18:34:18 --> Utf8 Class Initialized
INFO - 2023-05-23 18:34:18 --> URI Class Initialized
INFO - 2023-05-23 18:34:18 --> Router Class Initialized
INFO - 2023-05-23 18:34:18 --> Output Class Initialized
INFO - 2023-05-23 18:34:18 --> Security Class Initialized
INFO - 2023-05-23 18:34:18 --> Input Class Initialized
INFO - 2023-05-23 18:34:18 --> Language Class Initialized
INFO - 2023-05-23 18:34:18 --> Loader Class Initialized
INFO - 2023-05-23 18:34:18 --> Helper loaded: url_helper
INFO - 2023-05-23 18:34:18 --> Helper loaded: form_helper
INFO - 2023-05-23 18:34:18 --> Database Driver Class Initialized
INFO - 2023-05-23 18:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:34:18 --> Form Validation Class Initialized
INFO - 2023-05-23 18:34:18 --> Controller Class Initialized
INFO - 2023-05-23 18:34:18 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:34:18 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:34:18 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:34:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:34:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:34:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:34:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:34:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:34:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:34:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:34:18 --> Final output sent to browser
INFO - 2023-05-23 18:35:14 --> Config Class Initialized
INFO - 2023-05-23 18:35:14 --> Hooks Class Initialized
INFO - 2023-05-23 18:35:14 --> Utf8 Class Initialized
INFO - 2023-05-23 18:35:14 --> URI Class Initialized
INFO - 2023-05-23 18:35:14 --> Router Class Initialized
INFO - 2023-05-23 18:35:14 --> Output Class Initialized
INFO - 2023-05-23 18:35:14 --> Security Class Initialized
INFO - 2023-05-23 18:35:14 --> Input Class Initialized
INFO - 2023-05-23 18:35:14 --> Language Class Initialized
INFO - 2023-05-23 18:35:14 --> Loader Class Initialized
INFO - 2023-05-23 18:35:14 --> Helper loaded: url_helper
INFO - 2023-05-23 18:35:14 --> Helper loaded: form_helper
INFO - 2023-05-23 18:35:14 --> Database Driver Class Initialized
INFO - 2023-05-23 18:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:35:14 --> Form Validation Class Initialized
INFO - 2023-05-23 18:35:14 --> Controller Class Initialized
INFO - 2023-05-23 18:35:14 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:35:15 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:35:15 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:35:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:35:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:35:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:35:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:35:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:35:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:35:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:35:15 --> Final output sent to browser
INFO - 2023-05-23 18:35:59 --> Config Class Initialized
INFO - 2023-05-23 18:35:59 --> Hooks Class Initialized
INFO - 2023-05-23 18:35:59 --> Utf8 Class Initialized
INFO - 2023-05-23 18:35:59 --> URI Class Initialized
INFO - 2023-05-23 18:35:59 --> Router Class Initialized
INFO - 2023-05-23 18:35:59 --> Output Class Initialized
INFO - 2023-05-23 18:35:59 --> Security Class Initialized
INFO - 2023-05-23 18:35:59 --> Input Class Initialized
INFO - 2023-05-23 18:35:59 --> Language Class Initialized
INFO - 2023-05-23 18:35:59 --> Loader Class Initialized
INFO - 2023-05-23 18:35:59 --> Helper loaded: url_helper
INFO - 2023-05-23 18:35:59 --> Helper loaded: form_helper
INFO - 2023-05-23 18:35:59 --> Database Driver Class Initialized
INFO - 2023-05-23 18:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:35:59 --> Form Validation Class Initialized
INFO - 2023-05-23 18:35:59 --> Controller Class Initialized
INFO - 2023-05-23 18:35:59 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:35:59 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:35:59 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:35:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:35:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:35:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:35:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:35:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:35:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:35:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:35:59 --> Final output sent to browser
INFO - 2023-05-23 18:37:20 --> Config Class Initialized
INFO - 2023-05-23 18:37:20 --> Hooks Class Initialized
INFO - 2023-05-23 18:37:20 --> Utf8 Class Initialized
INFO - 2023-05-23 18:37:20 --> URI Class Initialized
INFO - 2023-05-23 18:37:20 --> Router Class Initialized
INFO - 2023-05-23 18:37:20 --> Output Class Initialized
INFO - 2023-05-23 18:37:20 --> Security Class Initialized
INFO - 2023-05-23 18:37:20 --> Input Class Initialized
INFO - 2023-05-23 18:37:20 --> Language Class Initialized
INFO - 2023-05-23 18:37:20 --> Loader Class Initialized
INFO - 2023-05-23 18:37:20 --> Helper loaded: url_helper
INFO - 2023-05-23 18:37:20 --> Helper loaded: form_helper
INFO - 2023-05-23 18:37:20 --> Database Driver Class Initialized
INFO - 2023-05-23 18:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:37:20 --> Form Validation Class Initialized
INFO - 2023-05-23 18:37:20 --> Controller Class Initialized
INFO - 2023-05-23 18:37:20 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:37:20 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:37:20 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:37:20 --> Final output sent to browser
INFO - 2023-05-23 18:38:34 --> Config Class Initialized
INFO - 2023-05-23 18:38:34 --> Hooks Class Initialized
INFO - 2023-05-23 18:38:34 --> Utf8 Class Initialized
INFO - 2023-05-23 18:38:34 --> URI Class Initialized
INFO - 2023-05-23 18:38:34 --> Router Class Initialized
INFO - 2023-05-23 18:38:34 --> Output Class Initialized
INFO - 2023-05-23 18:38:34 --> Security Class Initialized
INFO - 2023-05-23 18:38:34 --> Input Class Initialized
INFO - 2023-05-23 18:38:34 --> Language Class Initialized
INFO - 2023-05-23 18:38:34 --> Loader Class Initialized
INFO - 2023-05-23 18:38:34 --> Helper loaded: url_helper
INFO - 2023-05-23 18:38:34 --> Helper loaded: form_helper
INFO - 2023-05-23 18:38:34 --> Database Driver Class Initialized
INFO - 2023-05-23 18:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:38:34 --> Form Validation Class Initialized
INFO - 2023-05-23 18:38:34 --> Controller Class Initialized
INFO - 2023-05-23 18:38:34 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:38:34 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:38:34 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:38:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:38:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:38:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:38:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:38:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:38:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:38:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:38:35 --> Final output sent to browser
INFO - 2023-05-23 18:57:55 --> Config Class Initialized
INFO - 2023-05-23 18:57:55 --> Hooks Class Initialized
INFO - 2023-05-23 18:57:55 --> Utf8 Class Initialized
INFO - 2023-05-23 18:57:55 --> URI Class Initialized
INFO - 2023-05-23 18:57:55 --> Router Class Initialized
INFO - 2023-05-23 18:57:55 --> Output Class Initialized
INFO - 2023-05-23 18:57:55 --> Security Class Initialized
INFO - 2023-05-23 18:57:55 --> Input Class Initialized
INFO - 2023-05-23 18:57:55 --> Language Class Initialized
INFO - 2023-05-23 18:57:55 --> Loader Class Initialized
INFO - 2023-05-23 18:57:55 --> Helper loaded: url_helper
INFO - 2023-05-23 18:57:55 --> Helper loaded: form_helper
INFO - 2023-05-23 18:57:55 --> Database Driver Class Initialized
INFO - 2023-05-23 18:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:57:55 --> Form Validation Class Initialized
INFO - 2023-05-23 18:57:55 --> Controller Class Initialized
INFO - 2023-05-23 18:57:55 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:57:55 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:57:55 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:57:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:57:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:57:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:57:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:57:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:57:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:57:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:57:56 --> Final output sent to browser
INFO - 2023-05-23 18:59:38 --> Config Class Initialized
INFO - 2023-05-23 18:59:38 --> Hooks Class Initialized
INFO - 2023-05-23 18:59:39 --> Utf8 Class Initialized
INFO - 2023-05-23 18:59:39 --> URI Class Initialized
INFO - 2023-05-23 18:59:39 --> Router Class Initialized
INFO - 2023-05-23 18:59:39 --> Output Class Initialized
INFO - 2023-05-23 18:59:39 --> Security Class Initialized
INFO - 2023-05-23 18:59:39 --> Input Class Initialized
INFO - 2023-05-23 18:59:39 --> Language Class Initialized
INFO - 2023-05-23 18:59:39 --> Loader Class Initialized
INFO - 2023-05-23 18:59:39 --> Helper loaded: url_helper
INFO - 2023-05-23 18:59:39 --> Helper loaded: form_helper
INFO - 2023-05-23 18:59:39 --> Database Driver Class Initialized
INFO - 2023-05-23 18:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 18:59:39 --> Form Validation Class Initialized
INFO - 2023-05-23 18:59:39 --> Controller Class Initialized
INFO - 2023-05-23 18:59:39 --> Model "m_datatrain" initialized
INFO - 2023-05-23 18:59:39 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 18:59:39 --> Model "m_datatest" initialized
INFO - 2023-05-23 18:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 18:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 18:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 18:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 18:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 18:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 18:59:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 18:59:39 --> Final output sent to browser
INFO - 2023-05-23 19:08:28 --> Config Class Initialized
INFO - 2023-05-23 19:08:28 --> Hooks Class Initialized
INFO - 2023-05-23 19:08:28 --> Utf8 Class Initialized
INFO - 2023-05-23 19:08:28 --> URI Class Initialized
INFO - 2023-05-23 19:08:28 --> Router Class Initialized
INFO - 2023-05-23 19:08:28 --> Output Class Initialized
INFO - 2023-05-23 19:08:28 --> Security Class Initialized
INFO - 2023-05-23 19:08:28 --> Input Class Initialized
INFO - 2023-05-23 19:08:28 --> Language Class Initialized
INFO - 2023-05-23 19:08:28 --> Loader Class Initialized
INFO - 2023-05-23 19:08:28 --> Helper loaded: url_helper
INFO - 2023-05-23 19:08:28 --> Helper loaded: form_helper
INFO - 2023-05-23 19:08:28 --> Database Driver Class Initialized
INFO - 2023-05-23 19:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:08:28 --> Form Validation Class Initialized
INFO - 2023-05-23 19:08:28 --> Controller Class Initialized
INFO - 2023-05-23 19:08:28 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:08:28 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 19:08:28 --> Model "m_datatest" initialized
INFO - 2023-05-23 19:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 19:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 19:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:08:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:08:28 --> Final output sent to browser
INFO - 2023-05-23 19:11:45 --> Config Class Initialized
INFO - 2023-05-23 19:11:45 --> Hooks Class Initialized
INFO - 2023-05-23 19:11:45 --> Utf8 Class Initialized
INFO - 2023-05-23 19:11:45 --> URI Class Initialized
INFO - 2023-05-23 19:11:45 --> Router Class Initialized
INFO - 2023-05-23 19:11:45 --> Output Class Initialized
INFO - 2023-05-23 19:11:45 --> Security Class Initialized
INFO - 2023-05-23 19:11:45 --> Input Class Initialized
INFO - 2023-05-23 19:11:45 --> Language Class Initialized
INFO - 2023-05-23 19:11:45 --> Loader Class Initialized
INFO - 2023-05-23 19:11:45 --> Helper loaded: url_helper
INFO - 2023-05-23 19:11:45 --> Helper loaded: form_helper
INFO - 2023-05-23 19:11:45 --> Database Driver Class Initialized
INFO - 2023-05-23 19:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:11:45 --> Form Validation Class Initialized
INFO - 2023-05-23 19:11:45 --> Controller Class Initialized
INFO - 2023-05-23 19:11:45 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:11:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:11:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 19:11:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-23 19:11:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:11:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:11:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:11:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:11:45 --> Final output sent to browser
INFO - 2023-05-23 19:15:36 --> Config Class Initialized
INFO - 2023-05-23 19:15:36 --> Hooks Class Initialized
INFO - 2023-05-23 19:15:36 --> Utf8 Class Initialized
INFO - 2023-05-23 19:15:36 --> URI Class Initialized
INFO - 2023-05-23 19:15:36 --> Router Class Initialized
INFO - 2023-05-23 19:15:36 --> Output Class Initialized
INFO - 2023-05-23 19:15:36 --> Security Class Initialized
INFO - 2023-05-23 19:15:36 --> Input Class Initialized
INFO - 2023-05-23 19:15:36 --> Language Class Initialized
INFO - 2023-05-23 19:15:36 --> Loader Class Initialized
INFO - 2023-05-23 19:15:36 --> Helper loaded: url_helper
INFO - 2023-05-23 19:15:36 --> Helper loaded: form_helper
INFO - 2023-05-23 19:15:36 --> Database Driver Class Initialized
INFO - 2023-05-23 19:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:15:36 --> Form Validation Class Initialized
INFO - 2023-05-23 19:15:36 --> Controller Class Initialized
INFO - 2023-05-23 19:15:36 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:15:36 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 19:15:36 --> Model "m_datatest" initialized
INFO - 2023-05-23 19:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 19:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 19:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:15:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:15:36 --> Final output sent to browser
INFO - 2023-05-23 19:30:08 --> Config Class Initialized
INFO - 2023-05-23 19:30:08 --> Hooks Class Initialized
INFO - 2023-05-23 19:30:08 --> Utf8 Class Initialized
INFO - 2023-05-23 19:30:08 --> URI Class Initialized
INFO - 2023-05-23 19:30:08 --> Router Class Initialized
INFO - 2023-05-23 19:30:08 --> Output Class Initialized
INFO - 2023-05-23 19:30:08 --> Security Class Initialized
INFO - 2023-05-23 19:30:08 --> Input Class Initialized
INFO - 2023-05-23 19:30:08 --> Language Class Initialized
INFO - 2023-05-23 19:30:08 --> Loader Class Initialized
INFO - 2023-05-23 19:30:08 --> Helper loaded: url_helper
INFO - 2023-05-23 19:30:08 --> Helper loaded: form_helper
INFO - 2023-05-23 19:30:08 --> Database Driver Class Initialized
INFO - 2023-05-23 19:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:30:09 --> Form Validation Class Initialized
INFO - 2023-05-23 19:30:09 --> Controller Class Initialized
INFO - 2023-05-23 19:30:09 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:30:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:30:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 19:30:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-23 19:30:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:30:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:30:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:30:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:30:09 --> Final output sent to browser
INFO - 2023-05-23 19:34:52 --> Config Class Initialized
INFO - 2023-05-23 19:34:52 --> Hooks Class Initialized
INFO - 2023-05-23 19:34:52 --> Utf8 Class Initialized
INFO - 2023-05-23 19:34:52 --> URI Class Initialized
INFO - 2023-05-23 19:34:52 --> Router Class Initialized
INFO - 2023-05-23 19:34:52 --> Output Class Initialized
INFO - 2023-05-23 19:34:52 --> Security Class Initialized
INFO - 2023-05-23 19:34:52 --> Input Class Initialized
INFO - 2023-05-23 19:34:52 --> Language Class Initialized
INFO - 2023-05-23 19:34:52 --> Loader Class Initialized
INFO - 2023-05-23 19:34:52 --> Helper loaded: url_helper
INFO - 2023-05-23 19:34:52 --> Helper loaded: form_helper
INFO - 2023-05-23 19:34:52 --> Database Driver Class Initialized
INFO - 2023-05-23 19:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:34:52 --> Form Validation Class Initialized
INFO - 2023-05-23 19:34:52 --> Controller Class Initialized
INFO - 2023-05-23 19:34:52 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:34:52 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 19:34:52 --> Model "m_datatest" initialized
ERROR - 2023-05-23 19:34:52 --> Severity: Error --> Call to undefined method m_penghitungan::getHasilRinganA1Ortu() C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_penghitungan.php 78
INFO - 2023-05-23 19:43:06 --> Config Class Initialized
INFO - 2023-05-23 19:43:06 --> Hooks Class Initialized
INFO - 2023-05-23 19:43:06 --> Utf8 Class Initialized
INFO - 2023-05-23 19:43:06 --> URI Class Initialized
INFO - 2023-05-23 19:43:06 --> Router Class Initialized
INFO - 2023-05-23 19:43:06 --> Output Class Initialized
INFO - 2023-05-23 19:43:06 --> Security Class Initialized
INFO - 2023-05-23 19:43:06 --> Input Class Initialized
INFO - 2023-05-23 19:43:06 --> Language Class Initialized
INFO - 2023-05-23 19:43:06 --> Loader Class Initialized
INFO - 2023-05-23 19:43:06 --> Helper loaded: url_helper
INFO - 2023-05-23 19:43:06 --> Helper loaded: form_helper
INFO - 2023-05-23 19:43:06 --> Database Driver Class Initialized
INFO - 2023-05-23 19:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:43:06 --> Form Validation Class Initialized
INFO - 2023-05-23 19:43:06 --> Controller Class Initialized
INFO - 2023-05-23 19:43:06 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:43:06 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 19:43:06 --> Model "m_datatest" initialized
INFO - 2023-05-23 19:43:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:43:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 19:43:06 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA1SangatBuruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 52
ERROR - 2023-05-23 19:43:06 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA1Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 53
ERROR - 2023-05-23 19:43:06 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA1Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 54
ERROR - 2023-05-23 19:43:06 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA1Baik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 55
ERROR - 2023-05-23 19:43:06 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA1SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 56
INFO - 2023-05-23 19:43:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 19:43:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:43:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:43:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:43:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:43:06 --> Final output sent to browser
INFO - 2023-05-23 19:45:25 --> Config Class Initialized
INFO - 2023-05-23 19:45:25 --> Hooks Class Initialized
INFO - 2023-05-23 19:45:25 --> Utf8 Class Initialized
INFO - 2023-05-23 19:45:25 --> URI Class Initialized
INFO - 2023-05-23 19:45:25 --> Router Class Initialized
INFO - 2023-05-23 19:45:25 --> Output Class Initialized
INFO - 2023-05-23 19:45:25 --> Security Class Initialized
INFO - 2023-05-23 19:45:25 --> Input Class Initialized
INFO - 2023-05-23 19:45:25 --> Language Class Initialized
INFO - 2023-05-23 19:45:25 --> Loader Class Initialized
INFO - 2023-05-23 19:45:25 --> Helper loaded: url_helper
INFO - 2023-05-23 19:45:25 --> Helper loaded: form_helper
INFO - 2023-05-23 19:45:25 --> Database Driver Class Initialized
INFO - 2023-05-23 19:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:45:25 --> Form Validation Class Initialized
INFO - 2023-05-23 19:45:25 --> Controller Class Initialized
INFO - 2023-05-23 19:45:25 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:45:25 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 19:45:25 --> Model "m_datatest" initialized
INFO - 2023-05-23 19:45:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:45:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 19:45:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 19:45:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:45:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:45:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:45:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:45:25 --> Final output sent to browser
INFO - 2023-05-23 19:47:47 --> Config Class Initialized
INFO - 2023-05-23 19:47:47 --> Hooks Class Initialized
INFO - 2023-05-23 19:47:47 --> Utf8 Class Initialized
INFO - 2023-05-23 19:47:47 --> URI Class Initialized
INFO - 2023-05-23 19:47:47 --> Router Class Initialized
INFO - 2023-05-23 19:47:47 --> Output Class Initialized
INFO - 2023-05-23 19:47:47 --> Security Class Initialized
INFO - 2023-05-23 19:47:47 --> Input Class Initialized
INFO - 2023-05-23 19:47:47 --> Language Class Initialized
INFO - 2023-05-23 19:47:47 --> Loader Class Initialized
INFO - 2023-05-23 19:47:47 --> Helper loaded: url_helper
INFO - 2023-05-23 19:47:47 --> Helper loaded: form_helper
INFO - 2023-05-23 19:47:47 --> Database Driver Class Initialized
INFO - 2023-05-23 19:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:47:47 --> Form Validation Class Initialized
INFO - 2023-05-23 19:47:47 --> Controller Class Initialized
INFO - 2023-05-23 19:47:47 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:47:47 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 19:47:47 --> Model "m_datatest" initialized
INFO - 2023-05-23 19:47:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:47:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 19:47:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 19:47:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:47:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:47:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:47:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:47:47 --> Final output sent to browser
INFO - 2023-05-23 19:49:51 --> Config Class Initialized
INFO - 2023-05-23 19:49:51 --> Hooks Class Initialized
INFO - 2023-05-23 19:49:51 --> Utf8 Class Initialized
INFO - 2023-05-23 19:49:51 --> URI Class Initialized
INFO - 2023-05-23 19:49:51 --> Router Class Initialized
INFO - 2023-05-23 19:49:51 --> Output Class Initialized
INFO - 2023-05-23 19:49:51 --> Security Class Initialized
INFO - 2023-05-23 19:49:52 --> Input Class Initialized
INFO - 2023-05-23 19:49:52 --> Language Class Initialized
INFO - 2023-05-23 19:49:52 --> Loader Class Initialized
INFO - 2023-05-23 19:49:52 --> Helper loaded: url_helper
INFO - 2023-05-23 19:49:52 --> Helper loaded: form_helper
INFO - 2023-05-23 19:49:52 --> Database Driver Class Initialized
INFO - 2023-05-23 19:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:49:52 --> Form Validation Class Initialized
INFO - 2023-05-23 19:49:52 --> Controller Class Initialized
INFO - 2023-05-23 19:49:52 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:49:52 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 19:49:52 --> Model "m_datatest" initialized
INFO - 2023-05-23 19:49:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:49:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 19:49:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 19:49:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:49:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:49:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:49:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:49:52 --> Final output sent to browser
INFO - 2023-05-23 19:52:14 --> Config Class Initialized
INFO - 2023-05-23 19:52:14 --> Hooks Class Initialized
INFO - 2023-05-23 19:52:14 --> Utf8 Class Initialized
INFO - 2023-05-23 19:52:14 --> URI Class Initialized
INFO - 2023-05-23 19:52:14 --> Router Class Initialized
INFO - 2023-05-23 19:52:14 --> Output Class Initialized
INFO - 2023-05-23 19:52:14 --> Security Class Initialized
INFO - 2023-05-23 19:52:14 --> Input Class Initialized
INFO - 2023-05-23 19:52:14 --> Language Class Initialized
INFO - 2023-05-23 19:52:14 --> Loader Class Initialized
INFO - 2023-05-23 19:52:14 --> Helper loaded: url_helper
INFO - 2023-05-23 19:52:14 --> Helper loaded: form_helper
INFO - 2023-05-23 19:52:14 --> Database Driver Class Initialized
INFO - 2023-05-23 19:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:52:14 --> Form Validation Class Initialized
INFO - 2023-05-23 19:52:14 --> Controller Class Initialized
INFO - 2023-05-23 19:52:14 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:52:14 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 19:52:14 --> Model "m_datatest" initialized
INFO - 2023-05-23 19:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 19:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 19:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:52:14 --> Final output sent to browser
INFO - 2023-05-23 19:52:40 --> Config Class Initialized
INFO - 2023-05-23 19:52:40 --> Hooks Class Initialized
INFO - 2023-05-23 19:52:40 --> Utf8 Class Initialized
INFO - 2023-05-23 19:52:40 --> URI Class Initialized
INFO - 2023-05-23 19:52:40 --> Router Class Initialized
INFO - 2023-05-23 19:52:40 --> Output Class Initialized
INFO - 2023-05-23 19:52:40 --> Security Class Initialized
INFO - 2023-05-23 19:52:40 --> Input Class Initialized
INFO - 2023-05-23 19:52:40 --> Language Class Initialized
INFO - 2023-05-23 19:52:40 --> Loader Class Initialized
INFO - 2023-05-23 19:52:40 --> Helper loaded: url_helper
INFO - 2023-05-23 19:52:40 --> Helper loaded: form_helper
INFO - 2023-05-23 19:52:40 --> Database Driver Class Initialized
INFO - 2023-05-23 19:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:52:40 --> Form Validation Class Initialized
INFO - 2023-05-23 19:52:40 --> Controller Class Initialized
INFO - 2023-05-23 19:52:40 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:52:40 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 19:52:40 --> Model "m_datatest" initialized
INFO - 2023-05-23 19:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 19:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 19:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:52:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:52:40 --> Final output sent to browser
INFO - 2023-05-23 19:56:17 --> Config Class Initialized
INFO - 2023-05-23 19:56:17 --> Hooks Class Initialized
INFO - 2023-05-23 19:56:17 --> Utf8 Class Initialized
INFO - 2023-05-23 19:56:17 --> URI Class Initialized
INFO - 2023-05-23 19:56:17 --> Router Class Initialized
INFO - 2023-05-23 19:56:17 --> Output Class Initialized
INFO - 2023-05-23 19:56:17 --> Security Class Initialized
INFO - 2023-05-23 19:56:17 --> Input Class Initialized
INFO - 2023-05-23 19:56:17 --> Language Class Initialized
INFO - 2023-05-23 19:56:17 --> Loader Class Initialized
INFO - 2023-05-23 19:56:17 --> Helper loaded: url_helper
INFO - 2023-05-23 19:56:17 --> Helper loaded: form_helper
INFO - 2023-05-23 19:56:17 --> Database Driver Class Initialized
INFO - 2023-05-23 19:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:56:17 --> Form Validation Class Initialized
INFO - 2023-05-23 19:56:17 --> Controller Class Initialized
INFO - 2023-05-23 19:56:17 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:56:17 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 19:56:17 --> Model "m_datatest" initialized
INFO - 2023-05-23 19:56:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:56:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 19:56:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 19:56:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:56:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:56:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:56:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:56:17 --> Final output sent to browser
INFO - 2023-05-23 19:59:40 --> Config Class Initialized
INFO - 2023-05-23 19:59:40 --> Hooks Class Initialized
INFO - 2023-05-23 19:59:40 --> Utf8 Class Initialized
INFO - 2023-05-23 19:59:40 --> URI Class Initialized
INFO - 2023-05-23 19:59:40 --> Router Class Initialized
INFO - 2023-05-23 19:59:40 --> Output Class Initialized
INFO - 2023-05-23 19:59:40 --> Security Class Initialized
INFO - 2023-05-23 19:59:40 --> Input Class Initialized
INFO - 2023-05-23 19:59:40 --> Language Class Initialized
INFO - 2023-05-23 19:59:40 --> Loader Class Initialized
INFO - 2023-05-23 19:59:40 --> Helper loaded: url_helper
INFO - 2023-05-23 19:59:40 --> Helper loaded: form_helper
INFO - 2023-05-23 19:59:40 --> Database Driver Class Initialized
INFO - 2023-05-23 19:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 19:59:40 --> Form Validation Class Initialized
INFO - 2023-05-23 19:59:40 --> Controller Class Initialized
INFO - 2023-05-23 19:59:40 --> Model "m_datatrain" initialized
INFO - 2023-05-23 19:59:40 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 19:59:40 --> Model "m_datatest" initialized
INFO - 2023-05-23 19:59:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 19:59:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA1Ortu C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 226
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA1Kos C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 227
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA1Sendiri C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 228
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA2SangatBuruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 248
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA2Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 249
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA2Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 250
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 251
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA2SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 252
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA3SangatBuruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 256
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 257
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA3Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 258
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA3Baik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 259
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA3SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 260
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA4SangatBuruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 264
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA4Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 265
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA4Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 266
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA4Baik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 267
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 268
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA5SangatBuruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 272
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA5Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 273
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 274
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA5Baik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 275
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA5SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 276
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA6SangatBuruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 280
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 281
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA6Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 282
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA6Baik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 283
ERROR - 2023-05-23 19:59:40 --> Severity: Notice --> Undefined variable: P_HasilRinganA6SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\v_penghitungan.php 284
INFO - 2023-05-23 19:59:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 19:59:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 19:59:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 19:59:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 19:59:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 19:59:40 --> Final output sent to browser
INFO - 2023-05-23 20:01:02 --> Config Class Initialized
INFO - 2023-05-23 20:01:02 --> Hooks Class Initialized
INFO - 2023-05-23 20:01:02 --> Utf8 Class Initialized
INFO - 2023-05-23 20:01:02 --> URI Class Initialized
INFO - 2023-05-23 20:01:02 --> Router Class Initialized
INFO - 2023-05-23 20:01:02 --> Output Class Initialized
INFO - 2023-05-23 20:01:02 --> Security Class Initialized
INFO - 2023-05-23 20:01:02 --> Input Class Initialized
INFO - 2023-05-23 20:01:02 --> Language Class Initialized
INFO - 2023-05-23 20:01:02 --> Loader Class Initialized
INFO - 2023-05-23 20:01:02 --> Helper loaded: url_helper
INFO - 2023-05-23 20:01:02 --> Helper loaded: form_helper
INFO - 2023-05-23 20:01:02 --> Database Driver Class Initialized
INFO - 2023-05-23 20:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 20:01:02 --> Form Validation Class Initialized
INFO - 2023-05-23 20:01:02 --> Controller Class Initialized
INFO - 2023-05-23 20:01:02 --> Model "m_datatrain" initialized
INFO - 2023-05-23 20:01:02 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 20:01:02 --> Model "m_datatest" initialized
INFO - 2023-05-23 20:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 20:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 20:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 20:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 20:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 20:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 20:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 20:01:02 --> Final output sent to browser
INFO - 2023-05-23 20:24:17 --> Config Class Initialized
INFO - 2023-05-23 20:24:17 --> Hooks Class Initialized
INFO - 2023-05-23 20:24:17 --> Utf8 Class Initialized
INFO - 2023-05-23 20:24:17 --> URI Class Initialized
INFO - 2023-05-23 20:24:17 --> Router Class Initialized
INFO - 2023-05-23 20:24:17 --> Output Class Initialized
INFO - 2023-05-23 20:24:17 --> Security Class Initialized
INFO - 2023-05-23 20:24:17 --> Input Class Initialized
INFO - 2023-05-23 20:24:17 --> Language Class Initialized
INFO - 2023-05-23 20:24:17 --> Loader Class Initialized
INFO - 2023-05-23 20:24:17 --> Helper loaded: url_helper
INFO - 2023-05-23 20:24:17 --> Helper loaded: form_helper
INFO - 2023-05-23 20:24:17 --> Database Driver Class Initialized
INFO - 2023-05-23 20:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 20:24:17 --> Form Validation Class Initialized
INFO - 2023-05-23 20:24:17 --> Controller Class Initialized
INFO - 2023-05-23 20:24:17 --> Model "m_datatrain" initialized
INFO - 2023-05-23 20:24:17 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 20:24:17 --> Model "m_datatest" initialized
INFO - 2023-05-23 20:24:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 20:24:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 20:24:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 20:24:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 20:24:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 20:24:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 20:24:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 20:24:17 --> Final output sent to browser
INFO - 2023-05-23 20:26:40 --> Config Class Initialized
INFO - 2023-05-23 20:26:40 --> Hooks Class Initialized
INFO - 2023-05-23 20:26:40 --> Utf8 Class Initialized
INFO - 2023-05-23 20:26:40 --> URI Class Initialized
INFO - 2023-05-23 20:26:40 --> Router Class Initialized
INFO - 2023-05-23 20:26:40 --> Output Class Initialized
INFO - 2023-05-23 20:26:40 --> Security Class Initialized
INFO - 2023-05-23 20:26:40 --> Input Class Initialized
INFO - 2023-05-23 20:26:40 --> Language Class Initialized
INFO - 2023-05-23 20:26:40 --> Loader Class Initialized
INFO - 2023-05-23 20:26:40 --> Helper loaded: url_helper
INFO - 2023-05-23 20:26:40 --> Helper loaded: form_helper
INFO - 2023-05-23 20:26:40 --> Database Driver Class Initialized
INFO - 2023-05-23 20:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 20:26:40 --> Form Validation Class Initialized
INFO - 2023-05-23 20:26:40 --> Controller Class Initialized
INFO - 2023-05-23 20:26:40 --> Model "m_datatrain" initialized
INFO - 2023-05-23 20:26:40 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 20:26:40 --> Model "m_datatest" initialized
INFO - 2023-05-23 20:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 20:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 20:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 20:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 20:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 20:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 20:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 20:26:40 --> Final output sent to browser
INFO - 2023-05-23 20:27:55 --> Config Class Initialized
INFO - 2023-05-23 20:27:55 --> Hooks Class Initialized
INFO - 2023-05-23 20:27:55 --> Utf8 Class Initialized
INFO - 2023-05-23 20:27:55 --> URI Class Initialized
INFO - 2023-05-23 20:27:55 --> Router Class Initialized
INFO - 2023-05-23 20:27:55 --> Output Class Initialized
INFO - 2023-05-23 20:27:55 --> Security Class Initialized
INFO - 2023-05-23 20:27:55 --> Input Class Initialized
INFO - 2023-05-23 20:27:55 --> Language Class Initialized
INFO - 2023-05-23 20:27:55 --> Loader Class Initialized
INFO - 2023-05-23 20:27:55 --> Helper loaded: url_helper
INFO - 2023-05-23 20:27:55 --> Helper loaded: form_helper
INFO - 2023-05-23 20:27:55 --> Database Driver Class Initialized
INFO - 2023-05-23 20:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 20:27:55 --> Form Validation Class Initialized
INFO - 2023-05-23 20:27:55 --> Controller Class Initialized
INFO - 2023-05-23 20:27:55 --> Model "m_datatrain" initialized
INFO - 2023-05-23 20:27:55 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 20:27:55 --> Model "m_datatest" initialized
INFO - 2023-05-23 20:27:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 20:27:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 20:27:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 20:27:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 20:27:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 20:27:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 20:27:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 20:27:56 --> Final output sent to browser
INFO - 2023-05-23 20:28:12 --> Config Class Initialized
INFO - 2023-05-23 20:28:12 --> Hooks Class Initialized
INFO - 2023-05-23 20:28:12 --> Utf8 Class Initialized
INFO - 2023-05-23 20:28:12 --> URI Class Initialized
INFO - 2023-05-23 20:28:12 --> Router Class Initialized
INFO - 2023-05-23 20:28:12 --> Output Class Initialized
INFO - 2023-05-23 20:28:12 --> Security Class Initialized
INFO - 2023-05-23 20:28:12 --> Input Class Initialized
INFO - 2023-05-23 20:28:12 --> Language Class Initialized
INFO - 2023-05-23 20:28:12 --> Loader Class Initialized
INFO - 2023-05-23 20:28:12 --> Helper loaded: url_helper
INFO - 2023-05-23 20:28:12 --> Helper loaded: form_helper
INFO - 2023-05-23 20:28:12 --> Database Driver Class Initialized
INFO - 2023-05-23 20:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 20:28:12 --> Form Validation Class Initialized
INFO - 2023-05-23 20:28:12 --> Controller Class Initialized
INFO - 2023-05-23 20:28:12 --> Model "m_datatrain" initialized
INFO - 2023-05-23 20:28:12 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 20:28:12 --> Model "m_datatest" initialized
INFO - 2023-05-23 20:28:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 20:28:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 20:28:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 20:28:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 20:28:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 20:28:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 20:28:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 20:28:12 --> Final output sent to browser
INFO - 2023-05-23 20:28:27 --> Config Class Initialized
INFO - 2023-05-23 20:28:27 --> Hooks Class Initialized
INFO - 2023-05-23 20:28:27 --> Utf8 Class Initialized
INFO - 2023-05-23 20:28:27 --> URI Class Initialized
INFO - 2023-05-23 20:28:27 --> Router Class Initialized
INFO - 2023-05-23 20:28:27 --> Output Class Initialized
INFO - 2023-05-23 20:28:27 --> Security Class Initialized
INFO - 2023-05-23 20:28:27 --> Input Class Initialized
INFO - 2023-05-23 20:28:27 --> Language Class Initialized
INFO - 2023-05-23 20:28:27 --> Loader Class Initialized
INFO - 2023-05-23 20:28:28 --> Helper loaded: url_helper
INFO - 2023-05-23 20:28:28 --> Helper loaded: form_helper
INFO - 2023-05-23 20:28:28 --> Database Driver Class Initialized
INFO - 2023-05-23 20:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-23 20:28:28 --> Form Validation Class Initialized
INFO - 2023-05-23 20:28:28 --> Controller Class Initialized
INFO - 2023-05-23 20:28:28 --> Model "m_datatrain" initialized
INFO - 2023-05-23 20:28:28 --> Model "m_penghitungan" initialized
INFO - 2023-05-23 20:28:28 --> Model "m_datatest" initialized
INFO - 2023-05-23 20:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-23 20:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-23 20:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-23 20:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-23 20:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-23 20:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-23 20:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-23 20:28:28 --> Final output sent to browser
