<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-26 16:27:38 --> Config Class Initialized
INFO - 2023-05-26 16:27:38 --> Hooks Class Initialized
INFO - 2023-05-26 16:27:38 --> Utf8 Class Initialized
INFO - 2023-05-26 16:27:38 --> URI Class Initialized
INFO - 2023-05-26 16:27:38 --> Router Class Initialized
INFO - 2023-05-26 16:27:38 --> Output Class Initialized
INFO - 2023-05-26 16:27:38 --> Security Class Initialized
INFO - 2023-05-26 16:27:39 --> Input Class Initialized
INFO - 2023-05-26 16:27:39 --> Language Class Initialized
INFO - 2023-05-26 16:27:39 --> Loader Class Initialized
INFO - 2023-05-26 16:27:39 --> Helper loaded: url_helper
INFO - 2023-05-26 16:27:39 --> Helper loaded: form_helper
INFO - 2023-05-26 16:27:39 --> Database Driver Class Initialized
INFO - 2023-05-26 16:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:27:39 --> Form Validation Class Initialized
INFO - 2023-05-26 16:27:39 --> Controller Class Initialized
INFO - 2023-05-26 16:27:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-26 16:27:39 --> Final output sent to browser
INFO - 2023-05-26 16:27:42 --> Config Class Initialized
INFO - 2023-05-26 16:27:42 --> Hooks Class Initialized
INFO - 2023-05-26 16:27:42 --> Utf8 Class Initialized
INFO - 2023-05-26 16:27:42 --> URI Class Initialized
INFO - 2023-05-26 16:27:42 --> Router Class Initialized
INFO - 2023-05-26 16:27:42 --> Output Class Initialized
INFO - 2023-05-26 16:27:42 --> Security Class Initialized
INFO - 2023-05-26 16:27:42 --> Input Class Initialized
INFO - 2023-05-26 16:27:42 --> Language Class Initialized
INFO - 2023-05-26 16:27:42 --> Loader Class Initialized
INFO - 2023-05-26 16:27:42 --> Helper loaded: url_helper
INFO - 2023-05-26 16:27:42 --> Helper loaded: form_helper
INFO - 2023-05-26 16:27:42 --> Database Driver Class Initialized
INFO - 2023-05-26 16:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:27:42 --> Form Validation Class Initialized
INFO - 2023-05-26 16:27:42 --> Controller Class Initialized
INFO - 2023-05-26 16:27:42 --> Model "m_user" initialized
INFO - 2023-05-26 16:27:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:27:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:27:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 16:27:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:27:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:27:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-26 16:27:43 --> Final output sent to browser
INFO - 2023-05-26 16:27:45 --> Config Class Initialized
INFO - 2023-05-26 16:27:45 --> Hooks Class Initialized
INFO - 2023-05-26 16:27:45 --> Utf8 Class Initialized
INFO - 2023-05-26 16:27:45 --> URI Class Initialized
INFO - 2023-05-26 16:27:45 --> Router Class Initialized
INFO - 2023-05-26 16:27:45 --> Output Class Initialized
INFO - 2023-05-26 16:27:45 --> Security Class Initialized
INFO - 2023-05-26 16:27:45 --> Input Class Initialized
INFO - 2023-05-26 16:27:45 --> Language Class Initialized
INFO - 2023-05-26 16:27:45 --> Loader Class Initialized
INFO - 2023-05-26 16:27:45 --> Helper loaded: url_helper
INFO - 2023-05-26 16:27:45 --> Helper loaded: form_helper
INFO - 2023-05-26 16:27:45 --> Database Driver Class Initialized
INFO - 2023-05-26 16:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:27:45 --> Form Validation Class Initialized
INFO - 2023-05-26 16:27:45 --> Controller Class Initialized
INFO - 2023-05-26 16:27:45 --> Model "m_datatrain" initialized
INFO - 2023-05-26 16:27:45 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 16:27:45 --> Model "m_datatest" initialized
INFO - 2023-05-26 16:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-26 16:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 16:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 16:27:45 --> Final output sent to browser
INFO - 2023-05-26 16:28:39 --> Config Class Initialized
INFO - 2023-05-26 16:28:39 --> Hooks Class Initialized
INFO - 2023-05-26 16:28:39 --> Utf8 Class Initialized
INFO - 2023-05-26 16:28:39 --> URI Class Initialized
INFO - 2023-05-26 16:28:39 --> Router Class Initialized
INFO - 2023-05-26 16:28:39 --> Output Class Initialized
INFO - 2023-05-26 16:28:39 --> Security Class Initialized
INFO - 2023-05-26 16:28:39 --> Input Class Initialized
INFO - 2023-05-26 16:28:39 --> Language Class Initialized
INFO - 2023-05-26 16:28:39 --> Loader Class Initialized
INFO - 2023-05-26 16:28:39 --> Helper loaded: url_helper
INFO - 2023-05-26 16:28:39 --> Helper loaded: form_helper
INFO - 2023-05-26 16:28:39 --> Database Driver Class Initialized
INFO - 2023-05-26 16:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:28:39 --> Form Validation Class Initialized
INFO - 2023-05-26 16:28:39 --> Controller Class Initialized
INFO - 2023-05-26 16:28:39 --> Model "m_datatrain" initialized
INFO - 2023-05-26 16:28:39 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 16:28:39 --> Model "m_datatest" initialized
INFO - 2023-05-26 16:28:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:28:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:28:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 16:28:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 16:28:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:28:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:28:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 16:28:39 --> Final output sent to browser
INFO - 2023-05-26 16:38:39 --> Config Class Initialized
INFO - 2023-05-26 16:38:39 --> Hooks Class Initialized
INFO - 2023-05-26 16:38:39 --> Utf8 Class Initialized
INFO - 2023-05-26 16:38:39 --> URI Class Initialized
INFO - 2023-05-26 16:38:39 --> Router Class Initialized
INFO - 2023-05-26 16:38:39 --> Output Class Initialized
INFO - 2023-05-26 16:38:39 --> Security Class Initialized
INFO - 2023-05-26 16:38:39 --> Input Class Initialized
INFO - 2023-05-26 16:38:39 --> Language Class Initialized
INFO - 2023-05-26 16:38:39 --> Loader Class Initialized
INFO - 2023-05-26 16:38:39 --> Helper loaded: url_helper
INFO - 2023-05-26 16:38:39 --> Helper loaded: form_helper
INFO - 2023-05-26 16:38:39 --> Database Driver Class Initialized
INFO - 2023-05-26 16:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:38:39 --> Form Validation Class Initialized
INFO - 2023-05-26 16:38:39 --> Controller Class Initialized
INFO - 2023-05-26 16:38:39 --> Model "m_datatrain" initialized
INFO - 2023-05-26 16:38:39 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 16:38:39 --> Model "m_datatest" initialized
INFO - 2023-05-26 16:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 16:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 16:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 16:38:39 --> Final output sent to browser
INFO - 2023-05-26 16:39:34 --> Config Class Initialized
INFO - 2023-05-26 16:39:34 --> Hooks Class Initialized
INFO - 2023-05-26 16:39:34 --> Utf8 Class Initialized
INFO - 2023-05-26 16:39:34 --> URI Class Initialized
INFO - 2023-05-26 16:39:34 --> Router Class Initialized
INFO - 2023-05-26 16:39:34 --> Output Class Initialized
INFO - 2023-05-26 16:39:34 --> Security Class Initialized
INFO - 2023-05-26 16:39:34 --> Input Class Initialized
INFO - 2023-05-26 16:39:34 --> Language Class Initialized
INFO - 2023-05-26 16:39:34 --> Loader Class Initialized
INFO - 2023-05-26 16:39:34 --> Helper loaded: url_helper
INFO - 2023-05-26 16:39:34 --> Helper loaded: form_helper
INFO - 2023-05-26 16:39:34 --> Database Driver Class Initialized
INFO - 2023-05-26 16:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:39:34 --> Form Validation Class Initialized
INFO - 2023-05-26 16:39:34 --> Controller Class Initialized
INFO - 2023-05-26 16:39:34 --> Model "m_datatrain" initialized
INFO - 2023-05-26 16:39:34 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 16:39:34 --> Model "m_datatest" initialized
INFO - 2023-05-26 16:39:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:39:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:39:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 16:39:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 16:39:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:39:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:39:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 16:39:35 --> Final output sent to browser
INFO - 2023-05-26 16:41:22 --> Config Class Initialized
INFO - 2023-05-26 16:41:22 --> Hooks Class Initialized
INFO - 2023-05-26 16:41:22 --> Utf8 Class Initialized
INFO - 2023-05-26 16:41:22 --> URI Class Initialized
INFO - 2023-05-26 16:41:22 --> Router Class Initialized
INFO - 2023-05-26 16:41:22 --> Output Class Initialized
INFO - 2023-05-26 16:41:22 --> Security Class Initialized
INFO - 2023-05-26 16:41:22 --> Input Class Initialized
INFO - 2023-05-26 16:41:22 --> Language Class Initialized
INFO - 2023-05-26 16:41:23 --> Loader Class Initialized
INFO - 2023-05-26 16:41:23 --> Helper loaded: url_helper
INFO - 2023-05-26 16:41:23 --> Helper loaded: form_helper
INFO - 2023-05-26 16:41:23 --> Database Driver Class Initialized
INFO - 2023-05-26 16:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:41:23 --> Form Validation Class Initialized
INFO - 2023-05-26 16:41:23 --> Controller Class Initialized
INFO - 2023-05-26 16:41:23 --> Model "m_datatrain" initialized
INFO - 2023-05-26 16:41:23 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 16:41:23 --> Model "m_datatest" initialized
INFO - 2023-05-26 16:41:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:41:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:41:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 16:41:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 16:41:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:41:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:41:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 16:41:23 --> Final output sent to browser
INFO - 2023-05-26 16:51:56 --> Config Class Initialized
INFO - 2023-05-26 16:51:56 --> Hooks Class Initialized
INFO - 2023-05-26 16:51:56 --> Utf8 Class Initialized
INFO - 2023-05-26 16:51:56 --> URI Class Initialized
INFO - 2023-05-26 16:51:56 --> Router Class Initialized
INFO - 2023-05-26 16:51:56 --> Output Class Initialized
INFO - 2023-05-26 16:51:56 --> Security Class Initialized
INFO - 2023-05-26 16:51:56 --> Input Class Initialized
INFO - 2023-05-26 16:51:56 --> Language Class Initialized
INFO - 2023-05-26 16:51:56 --> Loader Class Initialized
INFO - 2023-05-26 16:51:56 --> Helper loaded: url_helper
INFO - 2023-05-26 16:51:56 --> Helper loaded: form_helper
INFO - 2023-05-26 16:51:56 --> Database Driver Class Initialized
INFO - 2023-05-26 16:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:51:56 --> Form Validation Class Initialized
INFO - 2023-05-26 16:51:56 --> Controller Class Initialized
INFO - 2023-05-26 16:51:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-26 16:51:56 --> Final output sent to browser
INFO - 2023-05-26 16:51:57 --> Config Class Initialized
INFO - 2023-05-26 16:51:57 --> Hooks Class Initialized
INFO - 2023-05-26 16:51:57 --> Utf8 Class Initialized
INFO - 2023-05-26 16:51:57 --> URI Class Initialized
INFO - 2023-05-26 16:51:57 --> Router Class Initialized
INFO - 2023-05-26 16:51:57 --> Output Class Initialized
INFO - 2023-05-26 16:51:57 --> Security Class Initialized
INFO - 2023-05-26 16:51:57 --> Input Class Initialized
INFO - 2023-05-26 16:51:57 --> Language Class Initialized
INFO - 2023-05-26 16:51:58 --> Loader Class Initialized
INFO - 2023-05-26 16:51:58 --> Helper loaded: url_helper
INFO - 2023-05-26 16:51:58 --> Helper loaded: form_helper
INFO - 2023-05-26 16:51:58 --> Database Driver Class Initialized
INFO - 2023-05-26 16:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:51:58 --> Form Validation Class Initialized
INFO - 2023-05-26 16:51:58 --> Controller Class Initialized
INFO - 2023-05-26 16:51:58 --> Model "m_user" initialized
INFO - 2023-05-26 16:51:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-26 16:51:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-26 16:51:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-26 16:51:58 --> Final output sent to browser
INFO - 2023-05-26 16:52:01 --> Config Class Initialized
INFO - 2023-05-26 16:52:01 --> Hooks Class Initialized
INFO - 2023-05-26 16:52:01 --> Utf8 Class Initialized
INFO - 2023-05-26 16:52:01 --> URI Class Initialized
INFO - 2023-05-26 16:52:01 --> Router Class Initialized
INFO - 2023-05-26 16:52:01 --> Output Class Initialized
INFO - 2023-05-26 16:52:01 --> Security Class Initialized
INFO - 2023-05-26 16:52:01 --> Input Class Initialized
INFO - 2023-05-26 16:52:01 --> Language Class Initialized
INFO - 2023-05-26 16:52:01 --> Loader Class Initialized
INFO - 2023-05-26 16:52:01 --> Helper loaded: url_helper
INFO - 2023-05-26 16:52:01 --> Helper loaded: form_helper
INFO - 2023-05-26 16:52:01 --> Database Driver Class Initialized
INFO - 2023-05-26 16:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:52:01 --> Form Validation Class Initialized
INFO - 2023-05-26 16:52:01 --> Controller Class Initialized
INFO - 2023-05-26 16:52:01 --> Model "m_user" initialized
INFO - 2023-05-26 16:52:01 --> Config Class Initialized
INFO - 2023-05-26 16:52:01 --> Hooks Class Initialized
INFO - 2023-05-26 16:52:01 --> Utf8 Class Initialized
INFO - 2023-05-26 16:52:01 --> URI Class Initialized
INFO - 2023-05-26 16:52:01 --> Router Class Initialized
INFO - 2023-05-26 16:52:01 --> Output Class Initialized
INFO - 2023-05-26 16:52:01 --> Security Class Initialized
INFO - 2023-05-26 16:52:01 --> Input Class Initialized
INFO - 2023-05-26 16:52:01 --> Language Class Initialized
INFO - 2023-05-26 16:52:01 --> Loader Class Initialized
INFO - 2023-05-26 16:52:01 --> Helper loaded: url_helper
INFO - 2023-05-26 16:52:01 --> Helper loaded: form_helper
INFO - 2023-05-26 16:52:01 --> Database Driver Class Initialized
INFO - 2023-05-26 16:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:52:01 --> Form Validation Class Initialized
INFO - 2023-05-26 16:52:01 --> Controller Class Initialized
INFO - 2023-05-26 16:52:01 --> Model "m_user" initialized
INFO - 2023-05-26 16:52:01 --> Model "m_datatrain" initialized
INFO - 2023-05-26 16:52:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:52:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:52:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 16:52:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:52:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:52:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-26 16:52:01 --> Final output sent to browser
INFO - 2023-05-26 16:53:30 --> Config Class Initialized
INFO - 2023-05-26 16:53:30 --> Hooks Class Initialized
INFO - 2023-05-26 16:53:30 --> Utf8 Class Initialized
INFO - 2023-05-26 16:53:30 --> URI Class Initialized
INFO - 2023-05-26 16:53:30 --> Router Class Initialized
INFO - 2023-05-26 16:53:30 --> Output Class Initialized
INFO - 2023-05-26 16:53:30 --> Security Class Initialized
INFO - 2023-05-26 16:53:30 --> Input Class Initialized
INFO - 2023-05-26 16:53:30 --> Language Class Initialized
INFO - 2023-05-26 16:53:30 --> Loader Class Initialized
INFO - 2023-05-26 16:53:30 --> Helper loaded: url_helper
INFO - 2023-05-26 16:53:30 --> Helper loaded: form_helper
INFO - 2023-05-26 16:53:30 --> Database Driver Class Initialized
INFO - 2023-05-26 16:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:53:30 --> Form Validation Class Initialized
INFO - 2023-05-26 16:53:30 --> Controller Class Initialized
INFO - 2023-05-26 16:53:30 --> Model "m_user" initialized
INFO - 2023-05-26 16:53:30 --> Model "m_datatrain" initialized
INFO - 2023-05-26 16:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 16:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:53:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-26 16:53:30 --> Final output sent to browser
INFO - 2023-05-26 16:55:25 --> Config Class Initialized
INFO - 2023-05-26 16:55:25 --> Hooks Class Initialized
INFO - 2023-05-26 16:55:25 --> Utf8 Class Initialized
INFO - 2023-05-26 16:55:25 --> URI Class Initialized
INFO - 2023-05-26 16:55:25 --> Router Class Initialized
INFO - 2023-05-26 16:55:25 --> Output Class Initialized
INFO - 2023-05-26 16:55:25 --> Security Class Initialized
INFO - 2023-05-26 16:55:25 --> Input Class Initialized
INFO - 2023-05-26 16:55:25 --> Language Class Initialized
INFO - 2023-05-26 16:55:25 --> Loader Class Initialized
INFO - 2023-05-26 16:55:25 --> Helper loaded: url_helper
INFO - 2023-05-26 16:55:25 --> Helper loaded: form_helper
INFO - 2023-05-26 16:55:25 --> Database Driver Class Initialized
INFO - 2023-05-26 16:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:55:25 --> Form Validation Class Initialized
INFO - 2023-05-26 16:55:25 --> Controller Class Initialized
INFO - 2023-05-26 16:55:25 --> Model "m_user" initialized
INFO - 2023-05-26 16:55:25 --> Model "m_datatrain" initialized
INFO - 2023-05-26 16:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 16:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-26 16:55:25 --> Final output sent to browser
INFO - 2023-05-26 16:57:46 --> Config Class Initialized
INFO - 2023-05-26 16:57:46 --> Hooks Class Initialized
INFO - 2023-05-26 16:57:46 --> Utf8 Class Initialized
INFO - 2023-05-26 16:57:46 --> URI Class Initialized
INFO - 2023-05-26 16:57:46 --> Router Class Initialized
INFO - 2023-05-26 16:57:46 --> Output Class Initialized
INFO - 2023-05-26 16:57:46 --> Security Class Initialized
INFO - 2023-05-26 16:57:46 --> Input Class Initialized
INFO - 2023-05-26 16:57:46 --> Language Class Initialized
INFO - 2023-05-26 16:57:46 --> Loader Class Initialized
INFO - 2023-05-26 16:57:46 --> Helper loaded: url_helper
INFO - 2023-05-26 16:57:46 --> Helper loaded: form_helper
INFO - 2023-05-26 16:57:46 --> Database Driver Class Initialized
INFO - 2023-05-26 16:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:57:46 --> Form Validation Class Initialized
INFO - 2023-05-26 16:57:46 --> Controller Class Initialized
INFO - 2023-05-26 16:57:46 --> Model "m_user" initialized
INFO - 2023-05-26 16:57:46 --> Model "m_datatrain" initialized
INFO - 2023-05-26 16:57:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:57:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:57:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 16:57:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:57:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:57:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-26 16:57:46 --> Final output sent to browser
INFO - 2023-05-26 16:58:11 --> Config Class Initialized
INFO - 2023-05-26 16:58:11 --> Hooks Class Initialized
INFO - 2023-05-26 16:58:11 --> Utf8 Class Initialized
INFO - 2023-05-26 16:58:11 --> URI Class Initialized
INFO - 2023-05-26 16:58:11 --> Router Class Initialized
INFO - 2023-05-26 16:58:11 --> Output Class Initialized
INFO - 2023-05-26 16:58:11 --> Security Class Initialized
INFO - 2023-05-26 16:58:11 --> Input Class Initialized
INFO - 2023-05-26 16:58:11 --> Language Class Initialized
INFO - 2023-05-26 16:58:11 --> Loader Class Initialized
INFO - 2023-05-26 16:58:11 --> Helper loaded: url_helper
INFO - 2023-05-26 16:58:11 --> Helper loaded: form_helper
INFO - 2023-05-26 16:58:11 --> Database Driver Class Initialized
INFO - 2023-05-26 16:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:58:11 --> Form Validation Class Initialized
INFO - 2023-05-26 16:58:11 --> Controller Class Initialized
INFO - 2023-05-26 16:58:11 --> Model "m_datatrain" initialized
INFO - 2023-05-26 16:58:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:58:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:58:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-26 16:58:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 16:58:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:58:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:58:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 16:58:11 --> Final output sent to browser
INFO - 2023-05-26 16:58:14 --> Config Class Initialized
INFO - 2023-05-26 16:58:14 --> Hooks Class Initialized
INFO - 2023-05-26 16:58:14 --> Utf8 Class Initialized
INFO - 2023-05-26 16:58:14 --> URI Class Initialized
INFO - 2023-05-26 16:58:14 --> Router Class Initialized
INFO - 2023-05-26 16:58:14 --> Output Class Initialized
INFO - 2023-05-26 16:58:14 --> Security Class Initialized
INFO - 2023-05-26 16:58:14 --> Input Class Initialized
INFO - 2023-05-26 16:58:14 --> Language Class Initialized
INFO - 2023-05-26 16:58:14 --> Loader Class Initialized
INFO - 2023-05-26 16:58:14 --> Helper loaded: url_helper
INFO - 2023-05-26 16:58:14 --> Helper loaded: form_helper
INFO - 2023-05-26 16:58:14 --> Database Driver Class Initialized
INFO - 2023-05-26 16:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:58:14 --> Form Validation Class Initialized
INFO - 2023-05-26 16:58:14 --> Controller Class Initialized
INFO - 2023-05-26 16:58:14 --> Model "m_datatest" initialized
INFO - 2023-05-26 16:58:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:58:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:58:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-26 16:58:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 16:58:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:58:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:58:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 16:58:14 --> Final output sent to browser
INFO - 2023-05-26 16:58:20 --> Config Class Initialized
INFO - 2023-05-26 16:58:20 --> Hooks Class Initialized
INFO - 2023-05-26 16:58:20 --> Utf8 Class Initialized
INFO - 2023-05-26 16:58:20 --> URI Class Initialized
INFO - 2023-05-26 16:58:20 --> Router Class Initialized
INFO - 2023-05-26 16:58:20 --> Output Class Initialized
INFO - 2023-05-26 16:58:20 --> Security Class Initialized
INFO - 2023-05-26 16:58:20 --> Input Class Initialized
INFO - 2023-05-26 16:58:20 --> Language Class Initialized
INFO - 2023-05-26 16:58:20 --> Loader Class Initialized
INFO - 2023-05-26 16:58:20 --> Helper loaded: url_helper
INFO - 2023-05-26 16:58:20 --> Helper loaded: form_helper
INFO - 2023-05-26 16:58:20 --> Database Driver Class Initialized
INFO - 2023-05-26 16:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 16:58:20 --> Form Validation Class Initialized
INFO - 2023-05-26 16:58:20 --> Controller Class Initialized
INFO - 2023-05-26 16:58:20 --> Model "m_datatrain" initialized
INFO - 2023-05-26 16:58:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 16:58:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 16:58:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-26 16:58:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 16:58:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 16:58:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 16:58:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 16:58:20 --> Final output sent to browser
INFO - 2023-05-26 17:01:17 --> Config Class Initialized
INFO - 2023-05-26 17:01:17 --> Hooks Class Initialized
INFO - 2023-05-26 17:01:17 --> Utf8 Class Initialized
INFO - 2023-05-26 17:01:17 --> URI Class Initialized
INFO - 2023-05-26 17:01:17 --> Router Class Initialized
INFO - 2023-05-26 17:01:17 --> Output Class Initialized
INFO - 2023-05-26 17:01:17 --> Security Class Initialized
INFO - 2023-05-26 17:01:17 --> Input Class Initialized
INFO - 2023-05-26 17:01:17 --> Language Class Initialized
INFO - 2023-05-26 17:01:17 --> Loader Class Initialized
INFO - 2023-05-26 17:01:17 --> Helper loaded: url_helper
INFO - 2023-05-26 17:01:17 --> Helper loaded: form_helper
INFO - 2023-05-26 17:01:17 --> Database Driver Class Initialized
INFO - 2023-05-26 17:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:01:17 --> Form Validation Class Initialized
INFO - 2023-05-26 17:01:17 --> Controller Class Initialized
INFO - 2023-05-26 17:01:17 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:01:17 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:01:17 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:01:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:01:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 17:01:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 17:01:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 17:01:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:01:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:01:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 17:01:17 --> Final output sent to browser
INFO - 2023-05-26 17:03:40 --> Config Class Initialized
INFO - 2023-05-26 17:03:40 --> Hooks Class Initialized
INFO - 2023-05-26 17:03:40 --> Utf8 Class Initialized
INFO - 2023-05-26 17:03:40 --> URI Class Initialized
INFO - 2023-05-26 17:03:40 --> Router Class Initialized
INFO - 2023-05-26 17:03:40 --> Output Class Initialized
INFO - 2023-05-26 17:03:40 --> Security Class Initialized
INFO - 2023-05-26 17:03:40 --> Input Class Initialized
INFO - 2023-05-26 17:03:40 --> Language Class Initialized
INFO - 2023-05-26 17:03:40 --> Loader Class Initialized
INFO - 2023-05-26 17:03:40 --> Helper loaded: url_helper
INFO - 2023-05-26 17:03:40 --> Helper loaded: form_helper
INFO - 2023-05-26 17:03:40 --> Database Driver Class Initialized
INFO - 2023-05-26 17:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:03:40 --> Form Validation Class Initialized
INFO - 2023-05-26 17:03:40 --> Controller Class Initialized
INFO - 2023-05-26 17:03:40 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:03:40 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:03:40 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:03:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:03:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 17:03:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 17:03:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 17:03:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:03:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:03:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 17:03:40 --> Final output sent to browser
INFO - 2023-05-26 17:05:03 --> Config Class Initialized
INFO - 2023-05-26 17:05:03 --> Hooks Class Initialized
INFO - 2023-05-26 17:05:03 --> Utf8 Class Initialized
INFO - 2023-05-26 17:05:03 --> URI Class Initialized
INFO - 2023-05-26 17:05:03 --> Router Class Initialized
INFO - 2023-05-26 17:05:03 --> Output Class Initialized
INFO - 2023-05-26 17:05:03 --> Security Class Initialized
INFO - 2023-05-26 17:05:03 --> Input Class Initialized
INFO - 2023-05-26 17:05:03 --> Language Class Initialized
INFO - 2023-05-26 17:05:03 --> Loader Class Initialized
INFO - 2023-05-26 17:05:03 --> Helper loaded: url_helper
INFO - 2023-05-26 17:05:03 --> Helper loaded: form_helper
INFO - 2023-05-26 17:05:03 --> Database Driver Class Initialized
INFO - 2023-05-26 17:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:05:03 --> Form Validation Class Initialized
INFO - 2023-05-26 17:05:03 --> Controller Class Initialized
INFO - 2023-05-26 17:05:03 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:05:03 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:05:03 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:05:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:05:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 17:05:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-26 17:05:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 17:05:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:05:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:05:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 17:05:03 --> Final output sent to browser
INFO - 2023-05-26 17:07:18 --> Config Class Initialized
INFO - 2023-05-26 17:07:18 --> Hooks Class Initialized
INFO - 2023-05-26 17:07:18 --> Utf8 Class Initialized
INFO - 2023-05-26 17:07:18 --> URI Class Initialized
INFO - 2023-05-26 17:07:18 --> Router Class Initialized
INFO - 2023-05-26 17:07:18 --> Output Class Initialized
INFO - 2023-05-26 17:07:18 --> Security Class Initialized
INFO - 2023-05-26 17:07:18 --> Input Class Initialized
INFO - 2023-05-26 17:07:18 --> Language Class Initialized
INFO - 2023-05-26 17:07:18 --> Loader Class Initialized
INFO - 2023-05-26 17:07:18 --> Helper loaded: url_helper
INFO - 2023-05-26 17:07:18 --> Helper loaded: form_helper
INFO - 2023-05-26 17:07:18 --> Database Driver Class Initialized
INFO - 2023-05-26 17:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:07:18 --> Form Validation Class Initialized
INFO - 2023-05-26 17:07:18 --> Controller Class Initialized
INFO - 2023-05-26 17:07:18 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:07:18 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:07:18 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:07:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:07:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 17:07:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 17:07:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 17:07:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:07:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:07:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 17:07:18 --> Final output sent to browser
INFO - 2023-05-26 17:09:18 --> Config Class Initialized
INFO - 2023-05-26 17:09:18 --> Hooks Class Initialized
INFO - 2023-05-26 17:09:18 --> Utf8 Class Initialized
INFO - 2023-05-26 17:09:18 --> URI Class Initialized
INFO - 2023-05-26 17:09:18 --> Router Class Initialized
INFO - 2023-05-26 17:09:18 --> Output Class Initialized
INFO - 2023-05-26 17:09:18 --> Security Class Initialized
INFO - 2023-05-26 17:09:18 --> Input Class Initialized
INFO - 2023-05-26 17:09:18 --> Language Class Initialized
INFO - 2023-05-26 17:09:18 --> Loader Class Initialized
INFO - 2023-05-26 17:09:18 --> Helper loaded: url_helper
INFO - 2023-05-26 17:09:18 --> Helper loaded: form_helper
INFO - 2023-05-26 17:09:18 --> Database Driver Class Initialized
INFO - 2023-05-26 17:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:09:18 --> Form Validation Class Initialized
INFO - 2023-05-26 17:09:18 --> Controller Class Initialized
INFO - 2023-05-26 17:09:18 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:09:18 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:09:18 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:09:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:09:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-26 17:09:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 24
INFO - 2023-05-26 17:09:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 17:09:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 17:09:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:09:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:09:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 17:09:18 --> Final output sent to browser
INFO - 2023-05-26 17:09:43 --> Config Class Initialized
INFO - 2023-05-26 17:09:43 --> Hooks Class Initialized
INFO - 2023-05-26 17:09:43 --> Utf8 Class Initialized
INFO - 2023-05-26 17:09:43 --> URI Class Initialized
INFO - 2023-05-26 17:09:43 --> Router Class Initialized
INFO - 2023-05-26 17:09:43 --> Output Class Initialized
INFO - 2023-05-26 17:09:43 --> Security Class Initialized
INFO - 2023-05-26 17:09:43 --> Input Class Initialized
INFO - 2023-05-26 17:09:43 --> Language Class Initialized
INFO - 2023-05-26 17:09:43 --> Loader Class Initialized
INFO - 2023-05-26 17:09:43 --> Helper loaded: url_helper
INFO - 2023-05-26 17:09:43 --> Helper loaded: form_helper
INFO - 2023-05-26 17:09:43 --> Database Driver Class Initialized
INFO - 2023-05-26 17:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:09:43 --> Form Validation Class Initialized
INFO - 2023-05-26 17:09:43 --> Controller Class Initialized
INFO - 2023-05-26 17:09:43 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:09:43 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:09:43 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 17:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 17:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 17:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:09:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 17:09:43 --> Final output sent to browser
INFO - 2023-05-26 17:12:32 --> Config Class Initialized
INFO - 2023-05-26 17:12:32 --> Hooks Class Initialized
INFO - 2023-05-26 17:12:32 --> Utf8 Class Initialized
INFO - 2023-05-26 17:12:32 --> URI Class Initialized
INFO - 2023-05-26 17:12:32 --> Router Class Initialized
INFO - 2023-05-26 17:12:32 --> Output Class Initialized
INFO - 2023-05-26 17:12:32 --> Security Class Initialized
INFO - 2023-05-26 17:12:32 --> Input Class Initialized
INFO - 2023-05-26 17:12:32 --> Language Class Initialized
INFO - 2023-05-26 17:12:32 --> Loader Class Initialized
INFO - 2023-05-26 17:12:32 --> Helper loaded: url_helper
INFO - 2023-05-26 17:12:32 --> Helper loaded: form_helper
INFO - 2023-05-26 17:12:32 --> Database Driver Class Initialized
INFO - 2023-05-26 17:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:12:32 --> Form Validation Class Initialized
INFO - 2023-05-26 17:12:32 --> Controller Class Initialized
INFO - 2023-05-26 17:12:32 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:12:32 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:12:32 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:12:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:12:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 17:12:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 17:12:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 17:12:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:12:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:12:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 17:12:32 --> Final output sent to browser
INFO - 2023-05-26 17:21:18 --> Config Class Initialized
INFO - 2023-05-26 17:21:18 --> Hooks Class Initialized
INFO - 2023-05-26 17:21:18 --> Utf8 Class Initialized
INFO - 2023-05-26 17:21:18 --> URI Class Initialized
INFO - 2023-05-26 17:21:18 --> Router Class Initialized
INFO - 2023-05-26 17:21:18 --> Output Class Initialized
INFO - 2023-05-26 17:21:18 --> Security Class Initialized
INFO - 2023-05-26 17:21:18 --> Input Class Initialized
INFO - 2023-05-26 17:21:18 --> Language Class Initialized
INFO - 2023-05-26 17:21:18 --> Loader Class Initialized
INFO - 2023-05-26 17:21:18 --> Helper loaded: url_helper
INFO - 2023-05-26 17:21:18 --> Helper loaded: form_helper
INFO - 2023-05-26 17:21:18 --> Database Driver Class Initialized
INFO - 2023-05-26 17:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:21:18 --> Form Validation Class Initialized
INFO - 2023-05-26 17:21:18 --> Controller Class Initialized
INFO - 2023-05-26 17:21:18 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:21:18 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:21:18 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:21:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:21:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 17:21:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 17:21:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 17:21:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:21:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:21:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 17:21:18 --> Final output sent to browser
INFO - 2023-05-26 17:25:06 --> Config Class Initialized
INFO - 2023-05-26 17:25:06 --> Hooks Class Initialized
INFO - 2023-05-26 17:25:06 --> Utf8 Class Initialized
INFO - 2023-05-26 17:25:06 --> URI Class Initialized
INFO - 2023-05-26 17:25:06 --> Router Class Initialized
INFO - 2023-05-26 17:25:06 --> Output Class Initialized
INFO - 2023-05-26 17:25:06 --> Security Class Initialized
INFO - 2023-05-26 17:25:06 --> Input Class Initialized
INFO - 2023-05-26 17:25:06 --> Language Class Initialized
INFO - 2023-05-26 17:25:06 --> Loader Class Initialized
INFO - 2023-05-26 17:25:06 --> Helper loaded: url_helper
INFO - 2023-05-26 17:25:06 --> Helper loaded: form_helper
INFO - 2023-05-26 17:25:06 --> Database Driver Class Initialized
INFO - 2023-05-26 17:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:25:06 --> Form Validation Class Initialized
INFO - 2023-05-26 17:25:06 --> Controller Class Initialized
INFO - 2023-05-26 17:25:06 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:25:06 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:25:06 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:25:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:25:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 17:25:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 17:25:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 17:25:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:25:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:25:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 17:25:06 --> Final output sent to browser
INFO - 2023-05-26 17:28:47 --> Config Class Initialized
INFO - 2023-05-26 17:28:47 --> Hooks Class Initialized
INFO - 2023-05-26 17:28:47 --> Utf8 Class Initialized
INFO - 2023-05-26 17:28:47 --> URI Class Initialized
INFO - 2023-05-26 17:28:47 --> Router Class Initialized
INFO - 2023-05-26 17:28:47 --> Output Class Initialized
INFO - 2023-05-26 17:28:47 --> Security Class Initialized
INFO - 2023-05-26 17:28:47 --> Input Class Initialized
INFO - 2023-05-26 17:28:47 --> Language Class Initialized
INFO - 2023-05-26 17:28:47 --> Loader Class Initialized
INFO - 2023-05-26 17:28:47 --> Helper loaded: url_helper
INFO - 2023-05-26 17:28:47 --> Helper loaded: form_helper
INFO - 2023-05-26 17:28:47 --> Database Driver Class Initialized
INFO - 2023-05-26 17:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:28:47 --> Form Validation Class Initialized
INFO - 2023-05-26 17:28:47 --> Controller Class Initialized
INFO - 2023-05-26 17:28:47 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:28:47 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:28:47 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:28:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:28:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 17:28:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 17:28:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 17:28:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:28:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:28:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 17:28:47 --> Final output sent to browser
INFO - 2023-05-26 17:29:57 --> Config Class Initialized
INFO - 2023-05-26 17:29:57 --> Hooks Class Initialized
INFO - 2023-05-26 17:29:57 --> Utf8 Class Initialized
INFO - 2023-05-26 17:29:57 --> URI Class Initialized
INFO - 2023-05-26 17:29:57 --> Router Class Initialized
INFO - 2023-05-26 17:29:57 --> Output Class Initialized
INFO - 2023-05-26 17:29:57 --> Security Class Initialized
INFO - 2023-05-26 17:29:57 --> Input Class Initialized
INFO - 2023-05-26 17:29:57 --> Language Class Initialized
INFO - 2023-05-26 17:29:57 --> Loader Class Initialized
INFO - 2023-05-26 17:29:57 --> Helper loaded: url_helper
INFO - 2023-05-26 17:29:57 --> Helper loaded: form_helper
INFO - 2023-05-26 17:29:57 --> Database Driver Class Initialized
INFO - 2023-05-26 17:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:29:57 --> Form Validation Class Initialized
INFO - 2023-05-26 17:29:57 --> Controller Class Initialized
INFO - 2023-05-26 17:29:57 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:29:57 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:29:57 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:29:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:29:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 17:29:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 17:29:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 17:29:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:29:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:29:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 17:29:57 --> Final output sent to browser
INFO - 2023-05-26 17:31:38 --> Config Class Initialized
INFO - 2023-05-26 17:31:38 --> Hooks Class Initialized
INFO - 2023-05-26 17:31:38 --> Utf8 Class Initialized
INFO - 2023-05-26 17:31:38 --> URI Class Initialized
INFO - 2023-05-26 17:31:38 --> Router Class Initialized
INFO - 2023-05-26 17:31:38 --> Output Class Initialized
INFO - 2023-05-26 17:31:38 --> Security Class Initialized
INFO - 2023-05-26 17:31:38 --> Input Class Initialized
INFO - 2023-05-26 17:31:38 --> Language Class Initialized
INFO - 2023-05-26 17:31:38 --> Loader Class Initialized
INFO - 2023-05-26 17:31:38 --> Helper loaded: url_helper
INFO - 2023-05-26 17:31:38 --> Helper loaded: form_helper
INFO - 2023-05-26 17:31:38 --> Database Driver Class Initialized
INFO - 2023-05-26 17:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 17:31:38 --> Form Validation Class Initialized
INFO - 2023-05-26 17:31:38 --> Controller Class Initialized
INFO - 2023-05-26 17:31:38 --> Model "m_datatrain" initialized
INFO - 2023-05-26 17:31:38 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 17:31:38 --> Model "m_datatest" initialized
INFO - 2023-05-26 17:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 17:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 17:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-26 17:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 17:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 17:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 17:31:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 17:31:38 --> Final output sent to browser
INFO - 2023-05-26 18:19:04 --> Config Class Initialized
INFO - 2023-05-26 18:19:04 --> Hooks Class Initialized
INFO - 2023-05-26 18:19:04 --> Utf8 Class Initialized
INFO - 2023-05-26 18:19:04 --> URI Class Initialized
INFO - 2023-05-26 18:19:04 --> Router Class Initialized
INFO - 2023-05-26 18:19:04 --> Output Class Initialized
INFO - 2023-05-26 18:19:04 --> Security Class Initialized
INFO - 2023-05-26 18:19:04 --> Input Class Initialized
INFO - 2023-05-26 18:19:04 --> Language Class Initialized
INFO - 2023-05-26 18:19:04 --> Loader Class Initialized
INFO - 2023-05-26 18:19:04 --> Helper loaded: url_helper
INFO - 2023-05-26 18:19:04 --> Helper loaded: form_helper
INFO - 2023-05-26 18:19:04 --> Database Driver Class Initialized
INFO - 2023-05-26 18:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:19:04 --> Form Validation Class Initialized
INFO - 2023-05-26 18:19:04 --> Controller Class Initialized
INFO - 2023-05-26 18:19:04 --> Model "m_datatest" initialized
INFO - 2023-05-26 18:19:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:19:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:19:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-26 18:19:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:19:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:19:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:19:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 18:19:05 --> Final output sent to browser
INFO - 2023-05-26 18:20:13 --> Config Class Initialized
INFO - 2023-05-26 18:20:13 --> Hooks Class Initialized
INFO - 2023-05-26 18:20:13 --> Utf8 Class Initialized
INFO - 2023-05-26 18:20:13 --> URI Class Initialized
INFO - 2023-05-26 18:20:13 --> Router Class Initialized
INFO - 2023-05-26 18:20:13 --> Output Class Initialized
INFO - 2023-05-26 18:20:13 --> Security Class Initialized
INFO - 2023-05-26 18:20:13 --> Input Class Initialized
INFO - 2023-05-26 18:20:13 --> Language Class Initialized
INFO - 2023-05-26 18:20:13 --> Loader Class Initialized
INFO - 2023-05-26 18:20:13 --> Helper loaded: url_helper
INFO - 2023-05-26 18:20:13 --> Helper loaded: form_helper
INFO - 2023-05-26 18:20:13 --> Database Driver Class Initialized
INFO - 2023-05-26 18:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:20:13 --> Form Validation Class Initialized
INFO - 2023-05-26 18:20:13 --> Controller Class Initialized
INFO - 2023-05-26 18:20:13 --> Model "m_datatest" initialized
INFO - 2023-05-26 18:20:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:20:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:20:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-26 18:20:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:20:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:20:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:20:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 18:20:13 --> Final output sent to browser
INFO - 2023-05-26 18:21:51 --> Config Class Initialized
INFO - 2023-05-26 18:21:51 --> Hooks Class Initialized
INFO - 2023-05-26 18:21:51 --> Utf8 Class Initialized
INFO - 2023-05-26 18:21:51 --> URI Class Initialized
INFO - 2023-05-26 18:21:51 --> Router Class Initialized
INFO - 2023-05-26 18:21:51 --> Output Class Initialized
INFO - 2023-05-26 18:21:51 --> Security Class Initialized
INFO - 2023-05-26 18:21:51 --> Input Class Initialized
INFO - 2023-05-26 18:21:51 --> Language Class Initialized
INFO - 2023-05-26 18:21:51 --> Loader Class Initialized
INFO - 2023-05-26 18:21:51 --> Helper loaded: url_helper
INFO - 2023-05-26 18:21:51 --> Helper loaded: form_helper
INFO - 2023-05-26 18:21:51 --> Database Driver Class Initialized
INFO - 2023-05-26 18:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:21:51 --> Form Validation Class Initialized
INFO - 2023-05-26 18:21:51 --> Controller Class Initialized
INFO - 2023-05-26 18:21:51 --> Model "m_datatrain" initialized
INFO - 2023-05-26 18:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-26 18:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 18:21:51 --> Final output sent to browser
INFO - 2023-05-26 18:21:54 --> Config Class Initialized
INFO - 2023-05-26 18:21:54 --> Hooks Class Initialized
INFO - 2023-05-26 18:21:54 --> Utf8 Class Initialized
INFO - 2023-05-26 18:21:54 --> URI Class Initialized
INFO - 2023-05-26 18:21:54 --> Router Class Initialized
INFO - 2023-05-26 18:21:54 --> Output Class Initialized
INFO - 2023-05-26 18:21:54 --> Security Class Initialized
INFO - 2023-05-26 18:21:54 --> Input Class Initialized
INFO - 2023-05-26 18:21:54 --> Language Class Initialized
INFO - 2023-05-26 18:21:54 --> Loader Class Initialized
INFO - 2023-05-26 18:21:54 --> Helper loaded: url_helper
INFO - 2023-05-26 18:21:54 --> Helper loaded: form_helper
INFO - 2023-05-26 18:21:54 --> Database Driver Class Initialized
INFO - 2023-05-26 18:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:21:54 --> Form Validation Class Initialized
INFO - 2023-05-26 18:21:54 --> Controller Class Initialized
INFO - 2023-05-26 18:21:54 --> Model "m_datatest" initialized
INFO - 2023-05-26 18:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-26 18:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 18:21:54 --> Final output sent to browser
INFO - 2023-05-26 18:21:55 --> Config Class Initialized
INFO - 2023-05-26 18:21:55 --> Hooks Class Initialized
INFO - 2023-05-26 18:21:55 --> Utf8 Class Initialized
INFO - 2023-05-26 18:21:55 --> URI Class Initialized
INFO - 2023-05-26 18:21:55 --> Router Class Initialized
INFO - 2023-05-26 18:21:55 --> Output Class Initialized
INFO - 2023-05-26 18:21:55 --> Security Class Initialized
INFO - 2023-05-26 18:21:55 --> Input Class Initialized
INFO - 2023-05-26 18:21:55 --> Language Class Initialized
INFO - 2023-05-26 18:21:55 --> Loader Class Initialized
INFO - 2023-05-26 18:21:55 --> Helper loaded: url_helper
INFO - 2023-05-26 18:21:55 --> Helper loaded: form_helper
INFO - 2023-05-26 18:21:55 --> Database Driver Class Initialized
INFO - 2023-05-26 18:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:21:55 --> Form Validation Class Initialized
INFO - 2023-05-26 18:21:55 --> Controller Class Initialized
INFO - 2023-05-26 18:21:55 --> Model "m_datatrain" initialized
INFO - 2023-05-26 18:21:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:21:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:21:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-26 18:21:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:21:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:21:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:21:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 18:21:55 --> Final output sent to browser
INFO - 2023-05-26 18:23:03 --> Config Class Initialized
INFO - 2023-05-26 18:23:03 --> Hooks Class Initialized
INFO - 2023-05-26 18:23:03 --> Utf8 Class Initialized
INFO - 2023-05-26 18:23:03 --> URI Class Initialized
INFO - 2023-05-26 18:23:03 --> Router Class Initialized
INFO - 2023-05-26 18:23:03 --> Output Class Initialized
INFO - 2023-05-26 18:23:03 --> Security Class Initialized
INFO - 2023-05-26 18:23:03 --> Input Class Initialized
INFO - 2023-05-26 18:23:03 --> Language Class Initialized
INFO - 2023-05-26 18:23:03 --> Loader Class Initialized
INFO - 2023-05-26 18:23:03 --> Helper loaded: url_helper
INFO - 2023-05-26 18:23:03 --> Helper loaded: form_helper
INFO - 2023-05-26 18:23:03 --> Database Driver Class Initialized
INFO - 2023-05-26 18:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:23:03 --> Form Validation Class Initialized
INFO - 2023-05-26 18:23:03 --> Controller Class Initialized
INFO - 2023-05-26 18:23:03 --> Model "m_datatest" initialized
INFO - 2023-05-26 18:23:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:23:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:23:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-26 18:23:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:23:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:23:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:23:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 18:23:03 --> Final output sent to browser
INFO - 2023-05-26 18:23:04 --> Config Class Initialized
INFO - 2023-05-26 18:23:04 --> Hooks Class Initialized
INFO - 2023-05-26 18:23:04 --> Utf8 Class Initialized
INFO - 2023-05-26 18:23:04 --> URI Class Initialized
INFO - 2023-05-26 18:23:04 --> Router Class Initialized
INFO - 2023-05-26 18:23:04 --> Output Class Initialized
INFO - 2023-05-26 18:23:04 --> Security Class Initialized
INFO - 2023-05-26 18:23:04 --> Input Class Initialized
INFO - 2023-05-26 18:23:04 --> Language Class Initialized
INFO - 2023-05-26 18:23:04 --> Loader Class Initialized
INFO - 2023-05-26 18:23:04 --> Helper loaded: url_helper
INFO - 2023-05-26 18:23:04 --> Helper loaded: form_helper
INFO - 2023-05-26 18:23:04 --> Database Driver Class Initialized
INFO - 2023-05-26 18:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:23:04 --> Form Validation Class Initialized
INFO - 2023-05-26 18:23:04 --> Controller Class Initialized
INFO - 2023-05-26 18:23:04 --> Model "m_datatrain" initialized
INFO - 2023-05-26 18:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-26 18:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 18:23:04 --> Final output sent to browser
INFO - 2023-05-26 18:23:07 --> Config Class Initialized
INFO - 2023-05-26 18:23:07 --> Hooks Class Initialized
INFO - 2023-05-26 18:23:07 --> Utf8 Class Initialized
INFO - 2023-05-26 18:23:07 --> URI Class Initialized
INFO - 2023-05-26 18:23:07 --> Router Class Initialized
INFO - 2023-05-26 18:23:07 --> Output Class Initialized
INFO - 2023-05-26 18:23:07 --> Security Class Initialized
INFO - 2023-05-26 18:23:07 --> Input Class Initialized
INFO - 2023-05-26 18:23:07 --> Language Class Initialized
INFO - 2023-05-26 18:23:07 --> Loader Class Initialized
INFO - 2023-05-26 18:23:07 --> Helper loaded: url_helper
INFO - 2023-05-26 18:23:07 --> Helper loaded: form_helper
INFO - 2023-05-26 18:23:07 --> Database Driver Class Initialized
INFO - 2023-05-26 18:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:23:07 --> Form Validation Class Initialized
INFO - 2023-05-26 18:23:07 --> Controller Class Initialized
INFO - 2023-05-26 18:23:07 --> Model "m_user" initialized
INFO - 2023-05-26 18:23:07 --> Model "m_datatrain" initialized
INFO - 2023-05-26 18:23:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:23:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:23:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:23:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:23:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:23:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-26 18:23:07 --> Final output sent to browser
INFO - 2023-05-26 18:23:09 --> Config Class Initialized
INFO - 2023-05-26 18:23:09 --> Hooks Class Initialized
INFO - 2023-05-26 18:23:09 --> Utf8 Class Initialized
INFO - 2023-05-26 18:23:09 --> URI Class Initialized
INFO - 2023-05-26 18:23:09 --> Router Class Initialized
INFO - 2023-05-26 18:23:09 --> Output Class Initialized
INFO - 2023-05-26 18:23:09 --> Security Class Initialized
INFO - 2023-05-26 18:23:09 --> Input Class Initialized
INFO - 2023-05-26 18:23:09 --> Language Class Initialized
INFO - 2023-05-26 18:23:09 --> Loader Class Initialized
INFO - 2023-05-26 18:23:09 --> Helper loaded: url_helper
INFO - 2023-05-26 18:23:09 --> Helper loaded: form_helper
INFO - 2023-05-26 18:23:09 --> Database Driver Class Initialized
INFO - 2023-05-26 18:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:23:09 --> Form Validation Class Initialized
INFO - 2023-05-26 18:23:09 --> Controller Class Initialized
INFO - 2023-05-26 18:23:09 --> Model "m_datatest" initialized
INFO - 2023-05-26 18:23:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:23:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:23:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-26 18:23:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:23:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:23:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:23:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 18:23:09 --> Final output sent to browser
INFO - 2023-05-26 18:23:15 --> Config Class Initialized
INFO - 2023-05-26 18:23:15 --> Hooks Class Initialized
INFO - 2023-05-26 18:23:15 --> Utf8 Class Initialized
INFO - 2023-05-26 18:23:15 --> URI Class Initialized
INFO - 2023-05-26 18:23:15 --> Router Class Initialized
INFO - 2023-05-26 18:23:15 --> Output Class Initialized
INFO - 2023-05-26 18:23:15 --> Security Class Initialized
INFO - 2023-05-26 18:23:15 --> Input Class Initialized
INFO - 2023-05-26 18:23:15 --> Language Class Initialized
INFO - 2023-05-26 18:23:15 --> Loader Class Initialized
INFO - 2023-05-26 18:23:15 --> Helper loaded: url_helper
INFO - 2023-05-26 18:23:15 --> Helper loaded: form_helper
INFO - 2023-05-26 18:23:15 --> Database Driver Class Initialized
INFO - 2023-05-26 18:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:23:15 --> Form Validation Class Initialized
INFO - 2023-05-26 18:23:15 --> Controller Class Initialized
INFO - 2023-05-26 18:23:15 --> Model "m_datatrain" initialized
INFO - 2023-05-26 18:23:15 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 18:23:15 --> Model "m_datatest" initialized
INFO - 2023-05-26 18:23:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:23:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:23:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-26 18:23:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:23:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:23:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:23:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-26 18:23:16 --> Final output sent to browser
INFO - 2023-05-26 18:23:19 --> Config Class Initialized
INFO - 2023-05-26 18:23:19 --> Hooks Class Initialized
INFO - 2023-05-26 18:23:19 --> Utf8 Class Initialized
INFO - 2023-05-26 18:23:19 --> URI Class Initialized
INFO - 2023-05-26 18:23:19 --> Router Class Initialized
INFO - 2023-05-26 18:23:19 --> Output Class Initialized
INFO - 2023-05-26 18:23:19 --> Security Class Initialized
INFO - 2023-05-26 18:23:19 --> Input Class Initialized
INFO - 2023-05-26 18:23:19 --> Language Class Initialized
INFO - 2023-05-26 18:23:19 --> Loader Class Initialized
INFO - 2023-05-26 18:23:19 --> Helper loaded: url_helper
INFO - 2023-05-26 18:23:19 --> Helper loaded: form_helper
INFO - 2023-05-26 18:23:19 --> Database Driver Class Initialized
INFO - 2023-05-26 18:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:23:19 --> Form Validation Class Initialized
INFO - 2023-05-26 18:23:19 --> Controller Class Initialized
INFO - 2023-05-26 18:23:19 --> Model "m_user" initialized
INFO - 2023-05-26 18:23:19 --> Model "m_datatrain" initialized
INFO - 2023-05-26 18:23:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:23:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:23:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:23:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:23:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:23:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-26 18:23:19 --> Final output sent to browser
INFO - 2023-05-26 18:24:35 --> Config Class Initialized
INFO - 2023-05-26 18:24:35 --> Hooks Class Initialized
INFO - 2023-05-26 18:24:35 --> Utf8 Class Initialized
INFO - 2023-05-26 18:24:35 --> URI Class Initialized
INFO - 2023-05-26 18:24:35 --> Router Class Initialized
INFO - 2023-05-26 18:24:35 --> Output Class Initialized
INFO - 2023-05-26 18:24:35 --> Security Class Initialized
INFO - 2023-05-26 18:24:35 --> Input Class Initialized
INFO - 2023-05-26 18:24:35 --> Language Class Initialized
ERROR - 2023-05-26 18:24:35 --> 404 Page Not Found: C_todo_list/index
INFO - 2023-05-26 18:24:38 --> Config Class Initialized
INFO - 2023-05-26 18:24:38 --> Hooks Class Initialized
INFO - 2023-05-26 18:24:38 --> Utf8 Class Initialized
INFO - 2023-05-26 18:24:38 --> URI Class Initialized
INFO - 2023-05-26 18:24:38 --> Router Class Initialized
INFO - 2023-05-26 18:24:38 --> Output Class Initialized
INFO - 2023-05-26 18:24:38 --> Security Class Initialized
INFO - 2023-05-26 18:24:38 --> Input Class Initialized
INFO - 2023-05-26 18:24:38 --> Language Class Initialized
INFO - 2023-05-26 18:24:38 --> Loader Class Initialized
INFO - 2023-05-26 18:24:38 --> Helper loaded: url_helper
INFO - 2023-05-26 18:24:38 --> Helper loaded: form_helper
INFO - 2023-05-26 18:24:38 --> Database Driver Class Initialized
INFO - 2023-05-26 18:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:24:38 --> Form Validation Class Initialized
INFO - 2023-05-26 18:24:38 --> Controller Class Initialized
INFO - 2023-05-26 18:24:38 --> Model "m_user" initialized
INFO - 2023-05-26 18:24:38 --> Model "m_datatrain" initialized
INFO - 2023-05-26 18:24:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:24:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:24:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-26 18:24:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:24:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:24:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-26 18:24:38 --> Final output sent to browser
INFO - 2023-05-26 18:27:00 --> Config Class Initialized
INFO - 2023-05-26 18:27:00 --> Hooks Class Initialized
INFO - 2023-05-26 18:27:00 --> Utf8 Class Initialized
INFO - 2023-05-26 18:27:00 --> URI Class Initialized
INFO - 2023-05-26 18:27:00 --> Router Class Initialized
INFO - 2023-05-26 18:27:00 --> Output Class Initialized
INFO - 2023-05-26 18:27:00 --> Security Class Initialized
INFO - 2023-05-26 18:27:00 --> Input Class Initialized
INFO - 2023-05-26 18:27:00 --> Language Class Initialized
INFO - 2023-05-26 18:27:00 --> Loader Class Initialized
INFO - 2023-05-26 18:27:00 --> Helper loaded: url_helper
INFO - 2023-05-26 18:27:00 --> Helper loaded: form_helper
INFO - 2023-05-26 18:27:00 --> Database Driver Class Initialized
INFO - 2023-05-26 18:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-26 18:27:00 --> Form Validation Class Initialized
INFO - 2023-05-26 18:27:00 --> Controller Class Initialized
INFO - 2023-05-26 18:27:00 --> Model "m_datatrain" initialized
INFO - 2023-05-26 18:27:00 --> Model "m_penghitungan" initialized
INFO - 2023-05-26 18:27:00 --> Model "m_datatest" initialized
INFO - 2023-05-26 18:27:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-26 18:27:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-26 18:27:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-26 18:27:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-26 18:27:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-26 18:27:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-26 18:27:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-26 18:27:00 --> Final output sent to browser
