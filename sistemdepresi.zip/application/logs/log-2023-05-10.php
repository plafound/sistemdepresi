<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-10 07:00:37 --> Config Class Initialized
INFO - 2023-05-10 07:00:37 --> Hooks Class Initialized
INFO - 2023-05-10 07:00:37 --> Utf8 Class Initialized
INFO - 2023-05-10 07:00:37 --> URI Class Initialized
INFO - 2023-05-10 07:00:37 --> Router Class Initialized
INFO - 2023-05-10 07:00:37 --> Output Class Initialized
INFO - 2023-05-10 07:00:37 --> Security Class Initialized
INFO - 2023-05-10 07:00:37 --> Input Class Initialized
INFO - 2023-05-10 07:00:38 --> Language Class Initialized
INFO - 2023-05-10 07:00:38 --> Loader Class Initialized
INFO - 2023-05-10 07:00:38 --> Helper loaded: url_helper
INFO - 2023-05-10 07:00:38 --> Helper loaded: form_helper
INFO - 2023-05-10 07:00:38 --> Database Driver Class Initialized
INFO - 2023-05-10 07:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:00:38 --> Form Validation Class Initialized
INFO - 2023-05-10 07:00:38 --> Controller Class Initialized
INFO - 2023-05-10 07:00:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-10 07:00:38 --> Final output sent to browser
INFO - 2023-05-10 07:00:41 --> Config Class Initialized
INFO - 2023-05-10 07:00:41 --> Hooks Class Initialized
INFO - 2023-05-10 07:00:41 --> Utf8 Class Initialized
INFO - 2023-05-10 07:00:41 --> URI Class Initialized
INFO - 2023-05-10 07:00:41 --> Router Class Initialized
INFO - 2023-05-10 07:00:41 --> Output Class Initialized
INFO - 2023-05-10 07:00:41 --> Security Class Initialized
INFO - 2023-05-10 07:00:41 --> Input Class Initialized
INFO - 2023-05-10 07:00:41 --> Language Class Initialized
INFO - 2023-05-10 07:00:41 --> Loader Class Initialized
INFO - 2023-05-10 07:00:41 --> Helper loaded: url_helper
INFO - 2023-05-10 07:00:41 --> Helper loaded: form_helper
INFO - 2023-05-10 07:00:41 --> Database Driver Class Initialized
INFO - 2023-05-10 07:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:00:41 --> Form Validation Class Initialized
INFO - 2023-05-10 07:00:41 --> Controller Class Initialized
INFO - 2023-05-10 07:00:41 --> Model "m_user" initialized
INFO - 2023-05-10 07:00:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 07:00:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 07:00:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 07:00:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 07:00:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 07:00:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-10 07:00:42 --> Final output sent to browser
INFO - 2023-05-10 07:01:02 --> Config Class Initialized
INFO - 2023-05-10 07:01:02 --> Hooks Class Initialized
INFO - 2023-05-10 07:01:02 --> Utf8 Class Initialized
INFO - 2023-05-10 07:01:02 --> URI Class Initialized
INFO - 2023-05-10 07:01:02 --> Router Class Initialized
INFO - 2023-05-10 07:01:02 --> Output Class Initialized
INFO - 2023-05-10 07:01:02 --> Security Class Initialized
INFO - 2023-05-10 07:01:02 --> Input Class Initialized
INFO - 2023-05-10 07:01:02 --> Language Class Initialized
INFO - 2023-05-10 07:01:02 --> Loader Class Initialized
INFO - 2023-05-10 07:01:02 --> Helper loaded: url_helper
INFO - 2023-05-10 07:01:02 --> Helper loaded: form_helper
INFO - 2023-05-10 07:01:02 --> Database Driver Class Initialized
INFO - 2023-05-10 07:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:01:02 --> Form Validation Class Initialized
INFO - 2023-05-10 07:01:02 --> Controller Class Initialized
INFO - 2023-05-10 07:01:02 --> Model "m_user" initialized
INFO - 2023-05-10 07:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 07:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 07:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 07:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 07:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 07:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-10 07:01:02 --> Final output sent to browser
INFO - 2023-05-10 07:10:26 --> Config Class Initialized
INFO - 2023-05-10 07:10:26 --> Hooks Class Initialized
INFO - 2023-05-10 07:10:27 --> Utf8 Class Initialized
INFO - 2023-05-10 07:10:27 --> URI Class Initialized
INFO - 2023-05-10 07:10:27 --> Router Class Initialized
INFO - 2023-05-10 07:10:27 --> Output Class Initialized
INFO - 2023-05-10 07:10:27 --> Security Class Initialized
INFO - 2023-05-10 07:10:27 --> Input Class Initialized
INFO - 2023-05-10 07:10:27 --> Language Class Initialized
ERROR - 2023-05-10 07:10:27 --> 404 Page Not Found: C_diagnosa/cek
INFO - 2023-05-10 07:12:10 --> Config Class Initialized
INFO - 2023-05-10 07:12:10 --> Hooks Class Initialized
INFO - 2023-05-10 07:12:10 --> Utf8 Class Initialized
INFO - 2023-05-10 07:12:10 --> URI Class Initialized
INFO - 2023-05-10 07:12:10 --> Router Class Initialized
INFO - 2023-05-10 07:12:10 --> Output Class Initialized
INFO - 2023-05-10 07:12:10 --> Security Class Initialized
INFO - 2023-05-10 07:12:10 --> Input Class Initialized
INFO - 2023-05-10 07:12:10 --> Language Class Initialized
ERROR - 2023-05-10 07:12:10 --> 404 Page Not Found: Home/cek
INFO - 2023-05-10 07:12:30 --> Config Class Initialized
INFO - 2023-05-10 07:12:30 --> Hooks Class Initialized
INFO - 2023-05-10 07:12:30 --> Utf8 Class Initialized
INFO - 2023-05-10 07:12:30 --> URI Class Initialized
INFO - 2023-05-10 07:12:30 --> Router Class Initialized
INFO - 2023-05-10 07:12:30 --> Output Class Initialized
INFO - 2023-05-10 07:12:30 --> Security Class Initialized
INFO - 2023-05-10 07:12:30 --> Input Class Initialized
INFO - 2023-05-10 07:12:30 --> Language Class Initialized
ERROR - 2023-05-10 07:12:30 --> 404 Page Not Found: Home/cek
INFO - 2023-05-10 07:12:33 --> Config Class Initialized
INFO - 2023-05-10 07:12:33 --> Hooks Class Initialized
INFO - 2023-05-10 07:12:33 --> Utf8 Class Initialized
INFO - 2023-05-10 07:12:33 --> URI Class Initialized
INFO - 2023-05-10 07:12:33 --> Router Class Initialized
INFO - 2023-05-10 07:12:33 --> Output Class Initialized
INFO - 2023-05-10 07:12:33 --> Security Class Initialized
INFO - 2023-05-10 07:12:33 --> Input Class Initialized
INFO - 2023-05-10 07:12:33 --> Language Class Initialized
ERROR - 2023-05-10 07:12:33 --> 404 Page Not Found: Home/cek
INFO - 2023-05-10 07:12:35 --> Config Class Initialized
INFO - 2023-05-10 07:12:35 --> Hooks Class Initialized
INFO - 2023-05-10 07:12:35 --> Utf8 Class Initialized
INFO - 2023-05-10 07:12:35 --> URI Class Initialized
INFO - 2023-05-10 07:12:35 --> Router Class Initialized
INFO - 2023-05-10 07:12:35 --> Output Class Initialized
INFO - 2023-05-10 07:12:35 --> Security Class Initialized
INFO - 2023-05-10 07:12:35 --> Input Class Initialized
INFO - 2023-05-10 07:12:35 --> Language Class Initialized
INFO - 2023-05-10 07:12:35 --> Loader Class Initialized
INFO - 2023-05-10 07:12:35 --> Helper loaded: url_helper
INFO - 2023-05-10 07:12:35 --> Helper loaded: form_helper
INFO - 2023-05-10 07:12:35 --> Database Driver Class Initialized
INFO - 2023-05-10 07:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:12:35 --> Form Validation Class Initialized
INFO - 2023-05-10 07:12:35 --> Controller Class Initialized
INFO - 2023-05-10 07:12:35 --> Model "m_user" initialized
INFO - 2023-05-10 07:12:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 07:12:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 07:12:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 07:12:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 07:12:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 07:12:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-10 07:12:36 --> Final output sent to browser
INFO - 2023-05-10 07:12:40 --> Config Class Initialized
INFO - 2023-05-10 07:12:40 --> Hooks Class Initialized
INFO - 2023-05-10 07:12:40 --> Utf8 Class Initialized
INFO - 2023-05-10 07:12:40 --> URI Class Initialized
INFO - 2023-05-10 07:12:40 --> Router Class Initialized
INFO - 2023-05-10 07:12:40 --> Output Class Initialized
INFO - 2023-05-10 07:12:40 --> Security Class Initialized
INFO - 2023-05-10 07:12:40 --> Input Class Initialized
INFO - 2023-05-10 07:12:40 --> Language Class Initialized
INFO - 2023-05-10 07:12:40 --> Loader Class Initialized
INFO - 2023-05-10 07:12:40 --> Helper loaded: url_helper
INFO - 2023-05-10 07:12:40 --> Helper loaded: form_helper
INFO - 2023-05-10 07:12:40 --> Database Driver Class Initialized
INFO - 2023-05-10 07:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:12:40 --> Form Validation Class Initialized
INFO - 2023-05-10 07:12:40 --> Controller Class Initialized
INFO - 2023-05-10 07:12:40 --> Model "m_user" initialized
INFO - 2023-05-10 07:12:40 --> Config Class Initialized
INFO - 2023-05-10 07:12:40 --> Hooks Class Initialized
INFO - 2023-05-10 07:12:40 --> Utf8 Class Initialized
INFO - 2023-05-10 07:12:40 --> URI Class Initialized
INFO - 2023-05-10 07:12:40 --> Router Class Initialized
INFO - 2023-05-10 07:12:40 --> Output Class Initialized
INFO - 2023-05-10 07:12:40 --> Security Class Initialized
INFO - 2023-05-10 07:12:40 --> Input Class Initialized
INFO - 2023-05-10 07:12:40 --> Language Class Initialized
INFO - 2023-05-10 07:12:40 --> Loader Class Initialized
INFO - 2023-05-10 07:12:40 --> Helper loaded: url_helper
INFO - 2023-05-10 07:12:40 --> Helper loaded: form_helper
INFO - 2023-05-10 07:12:40 --> Database Driver Class Initialized
INFO - 2023-05-10 07:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:12:40 --> Form Validation Class Initialized
INFO - 2023-05-10 07:12:40 --> Controller Class Initialized
INFO - 2023-05-10 07:12:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-10 07:12:40 --> Final output sent to browser
INFO - 2023-05-10 07:12:42 --> Config Class Initialized
INFO - 2023-05-10 07:12:42 --> Hooks Class Initialized
INFO - 2023-05-10 07:12:42 --> Utf8 Class Initialized
INFO - 2023-05-10 07:12:42 --> URI Class Initialized
INFO - 2023-05-10 07:12:42 --> Router Class Initialized
INFO - 2023-05-10 07:12:42 --> Output Class Initialized
INFO - 2023-05-10 07:12:42 --> Security Class Initialized
INFO - 2023-05-10 07:12:42 --> Input Class Initialized
INFO - 2023-05-10 07:12:42 --> Language Class Initialized
INFO - 2023-05-10 07:12:42 --> Loader Class Initialized
INFO - 2023-05-10 07:12:42 --> Helper loaded: url_helper
INFO - 2023-05-10 07:12:42 --> Helper loaded: form_helper
INFO - 2023-05-10 07:12:42 --> Database Driver Class Initialized
INFO - 2023-05-10 07:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:12:42 --> Form Validation Class Initialized
INFO - 2023-05-10 07:12:42 --> Controller Class Initialized
INFO - 2023-05-10 07:12:42 --> Model "m_user" initialized
INFO - 2023-05-10 07:12:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-10 07:12:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-10 07:12:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-10 07:12:42 --> Final output sent to browser
INFO - 2023-05-10 07:12:48 --> Config Class Initialized
INFO - 2023-05-10 07:12:48 --> Hooks Class Initialized
INFO - 2023-05-10 07:12:48 --> Utf8 Class Initialized
INFO - 2023-05-10 07:12:48 --> URI Class Initialized
INFO - 2023-05-10 07:12:48 --> Router Class Initialized
INFO - 2023-05-10 07:12:48 --> Output Class Initialized
INFO - 2023-05-10 07:12:48 --> Security Class Initialized
INFO - 2023-05-10 07:12:48 --> Input Class Initialized
INFO - 2023-05-10 07:12:48 --> Language Class Initialized
INFO - 2023-05-10 07:12:48 --> Loader Class Initialized
INFO - 2023-05-10 07:12:48 --> Helper loaded: url_helper
INFO - 2023-05-10 07:12:48 --> Helper loaded: form_helper
INFO - 2023-05-10 07:12:48 --> Database Driver Class Initialized
INFO - 2023-05-10 07:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:12:48 --> Form Validation Class Initialized
INFO - 2023-05-10 07:12:48 --> Controller Class Initialized
INFO - 2023-05-10 07:12:48 --> Model "m_user" initialized
INFO - 2023-05-10 07:12:48 --> Config Class Initialized
INFO - 2023-05-10 07:12:48 --> Hooks Class Initialized
INFO - 2023-05-10 07:12:48 --> Utf8 Class Initialized
INFO - 2023-05-10 07:12:48 --> URI Class Initialized
INFO - 2023-05-10 07:12:48 --> Router Class Initialized
INFO - 2023-05-10 07:12:48 --> Output Class Initialized
INFO - 2023-05-10 07:12:48 --> Security Class Initialized
INFO - 2023-05-10 07:12:48 --> Input Class Initialized
INFO - 2023-05-10 07:12:48 --> Language Class Initialized
INFO - 2023-05-10 07:12:48 --> Loader Class Initialized
INFO - 2023-05-10 07:12:48 --> Helper loaded: url_helper
INFO - 2023-05-10 07:12:48 --> Helper loaded: form_helper
INFO - 2023-05-10 07:12:48 --> Database Driver Class Initialized
INFO - 2023-05-10 07:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:12:48 --> Form Validation Class Initialized
INFO - 2023-05-10 07:12:48 --> Controller Class Initialized
INFO - 2023-05-10 07:12:48 --> Model "m_user" initialized
INFO - 2023-05-10 07:12:48 --> Model "m_datatrain" initialized
INFO - 2023-05-10 07:12:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 07:12:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 07:12:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-10 07:12:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 07:12:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 07:12:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-10 07:12:48 --> Final output sent to browser
INFO - 2023-05-10 07:12:55 --> Config Class Initialized
INFO - 2023-05-10 07:12:55 --> Hooks Class Initialized
INFO - 2023-05-10 07:12:55 --> Utf8 Class Initialized
INFO - 2023-05-10 07:12:55 --> URI Class Initialized
INFO - 2023-05-10 07:12:55 --> Router Class Initialized
INFO - 2023-05-10 07:12:55 --> Output Class Initialized
INFO - 2023-05-10 07:12:55 --> Security Class Initialized
INFO - 2023-05-10 07:12:55 --> Input Class Initialized
INFO - 2023-05-10 07:12:55 --> Language Class Initialized
ERROR - 2023-05-10 07:12:55 --> 404 Page Not Found: Home/cek
INFO - 2023-05-10 07:13:08 --> Config Class Initialized
INFO - 2023-05-10 07:13:08 --> Hooks Class Initialized
INFO - 2023-05-10 07:13:08 --> Utf8 Class Initialized
INFO - 2023-05-10 07:13:08 --> URI Class Initialized
INFO - 2023-05-10 07:13:08 --> Router Class Initialized
INFO - 2023-05-10 07:13:08 --> Output Class Initialized
INFO - 2023-05-10 07:13:08 --> Security Class Initialized
INFO - 2023-05-10 07:13:08 --> Input Class Initialized
INFO - 2023-05-10 07:13:08 --> Language Class Initialized
INFO - 2023-05-10 07:13:08 --> Loader Class Initialized
INFO - 2023-05-10 07:13:08 --> Helper loaded: url_helper
INFO - 2023-05-10 07:13:08 --> Helper loaded: form_helper
INFO - 2023-05-10 07:13:08 --> Database Driver Class Initialized
INFO - 2023-05-10 07:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:13:08 --> Form Validation Class Initialized
INFO - 2023-05-10 07:13:08 --> Controller Class Initialized
INFO - 2023-05-10 07:13:08 --> Model "m_user" initialized
INFO - 2023-05-10 07:13:08 --> Model "m_datatrain" initialized
INFO - 2023-05-10 07:13:08 --> Final output sent to browser
INFO - 2023-05-10 07:15:18 --> Config Class Initialized
INFO - 2023-05-10 07:15:18 --> Hooks Class Initialized
INFO - 2023-05-10 07:15:18 --> Utf8 Class Initialized
INFO - 2023-05-10 07:15:18 --> URI Class Initialized
INFO - 2023-05-10 07:15:18 --> Router Class Initialized
INFO - 2023-05-10 07:15:18 --> Output Class Initialized
INFO - 2023-05-10 07:15:18 --> Security Class Initialized
INFO - 2023-05-10 07:15:18 --> Input Class Initialized
INFO - 2023-05-10 07:15:18 --> Language Class Initialized
ERROR - 2023-05-10 07:15:18 --> 404 Page Not Found: C_diagnosa/cek
INFO - 2023-05-10 07:15:22 --> Config Class Initialized
INFO - 2023-05-10 07:15:22 --> Hooks Class Initialized
INFO - 2023-05-10 07:15:22 --> Utf8 Class Initialized
INFO - 2023-05-10 07:15:22 --> URI Class Initialized
INFO - 2023-05-10 07:15:22 --> Router Class Initialized
INFO - 2023-05-10 07:15:22 --> Output Class Initialized
INFO - 2023-05-10 07:15:22 --> Security Class Initialized
INFO - 2023-05-10 07:15:22 --> Input Class Initialized
INFO - 2023-05-10 07:15:22 --> Language Class Initialized
INFO - 2023-05-10 07:15:22 --> Loader Class Initialized
INFO - 2023-05-10 07:15:22 --> Helper loaded: url_helper
INFO - 2023-05-10 07:15:22 --> Helper loaded: form_helper
INFO - 2023-05-10 07:15:22 --> Database Driver Class Initialized
INFO - 2023-05-10 07:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:15:22 --> Form Validation Class Initialized
INFO - 2023-05-10 07:15:22 --> Controller Class Initialized
INFO - 2023-05-10 07:15:22 --> Model "m_user" initialized
INFO - 2023-05-10 07:15:22 --> Model "m_datatrain" initialized
INFO - 2023-05-10 07:15:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 07:15:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 07:15:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-10 07:15:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 07:15:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 07:15:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-10 07:15:22 --> Final output sent to browser
INFO - 2023-05-10 07:15:26 --> Config Class Initialized
INFO - 2023-05-10 07:15:26 --> Hooks Class Initialized
INFO - 2023-05-10 07:15:26 --> Utf8 Class Initialized
INFO - 2023-05-10 07:15:26 --> URI Class Initialized
INFO - 2023-05-10 07:15:26 --> Router Class Initialized
INFO - 2023-05-10 07:15:26 --> Output Class Initialized
INFO - 2023-05-10 07:15:26 --> Security Class Initialized
INFO - 2023-05-10 07:15:26 --> Input Class Initialized
INFO - 2023-05-10 07:15:26 --> Language Class Initialized
INFO - 2023-05-10 07:15:26 --> Loader Class Initialized
INFO - 2023-05-10 07:15:26 --> Helper loaded: url_helper
INFO - 2023-05-10 07:15:26 --> Helper loaded: form_helper
INFO - 2023-05-10 07:15:26 --> Database Driver Class Initialized
INFO - 2023-05-10 07:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:15:26 --> Form Validation Class Initialized
INFO - 2023-05-10 07:15:26 --> Controller Class Initialized
INFO - 2023-05-10 07:15:26 --> Model "m_user" initialized
INFO - 2023-05-10 07:15:26 --> Config Class Initialized
INFO - 2023-05-10 07:15:26 --> Hooks Class Initialized
INFO - 2023-05-10 07:15:26 --> Utf8 Class Initialized
INFO - 2023-05-10 07:15:26 --> URI Class Initialized
INFO - 2023-05-10 07:15:26 --> Router Class Initialized
INFO - 2023-05-10 07:15:26 --> Output Class Initialized
INFO - 2023-05-10 07:15:26 --> Security Class Initialized
INFO - 2023-05-10 07:15:26 --> Input Class Initialized
INFO - 2023-05-10 07:15:26 --> Language Class Initialized
INFO - 2023-05-10 07:15:26 --> Loader Class Initialized
INFO - 2023-05-10 07:15:26 --> Helper loaded: url_helper
INFO - 2023-05-10 07:15:26 --> Helper loaded: form_helper
INFO - 2023-05-10 07:15:26 --> Database Driver Class Initialized
INFO - 2023-05-10 07:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:15:26 --> Form Validation Class Initialized
INFO - 2023-05-10 07:15:26 --> Controller Class Initialized
INFO - 2023-05-10 07:15:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-10 07:15:26 --> Final output sent to browser
INFO - 2023-05-10 07:15:27 --> Config Class Initialized
INFO - 2023-05-10 07:15:27 --> Hooks Class Initialized
INFO - 2023-05-10 07:15:28 --> Utf8 Class Initialized
INFO - 2023-05-10 07:15:28 --> URI Class Initialized
INFO - 2023-05-10 07:15:28 --> Router Class Initialized
INFO - 2023-05-10 07:15:28 --> Output Class Initialized
INFO - 2023-05-10 07:15:28 --> Security Class Initialized
INFO - 2023-05-10 07:15:28 --> Input Class Initialized
INFO - 2023-05-10 07:15:28 --> Language Class Initialized
INFO - 2023-05-10 07:15:28 --> Loader Class Initialized
INFO - 2023-05-10 07:15:28 --> Helper loaded: url_helper
INFO - 2023-05-10 07:15:28 --> Helper loaded: form_helper
INFO - 2023-05-10 07:15:28 --> Database Driver Class Initialized
INFO - 2023-05-10 07:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:15:28 --> Form Validation Class Initialized
INFO - 2023-05-10 07:15:28 --> Controller Class Initialized
INFO - 2023-05-10 07:15:28 --> Model "m_user" initialized
INFO - 2023-05-10 07:15:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 07:15:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 07:15:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 07:15:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 07:15:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 07:15:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-10 07:15:28 --> Final output sent to browser
INFO - 2023-05-10 07:15:46 --> Config Class Initialized
INFO - 2023-05-10 07:15:46 --> Hooks Class Initialized
INFO - 2023-05-10 07:15:46 --> Utf8 Class Initialized
INFO - 2023-05-10 07:15:46 --> URI Class Initialized
INFO - 2023-05-10 07:15:46 --> Router Class Initialized
INFO - 2023-05-10 07:15:46 --> Output Class Initialized
INFO - 2023-05-10 07:15:46 --> Security Class Initialized
INFO - 2023-05-10 07:15:46 --> Input Class Initialized
INFO - 2023-05-10 07:15:46 --> Language Class Initialized
ERROR - 2023-05-10 07:15:46 --> 404 Page Not Found: C_diagnosa/cek
INFO - 2023-05-10 07:22:32 --> Config Class Initialized
INFO - 2023-05-10 07:22:32 --> Hooks Class Initialized
INFO - 2023-05-10 07:22:32 --> Utf8 Class Initialized
INFO - 2023-05-10 07:22:32 --> URI Class Initialized
INFO - 2023-05-10 07:22:32 --> Router Class Initialized
INFO - 2023-05-10 07:22:32 --> Output Class Initialized
INFO - 2023-05-10 07:22:32 --> Security Class Initialized
INFO - 2023-05-10 07:22:32 --> Input Class Initialized
INFO - 2023-05-10 07:22:32 --> Language Class Initialized
ERROR - 2023-05-10 07:22:32 --> 404 Page Not Found: C_diagnosa/cek
INFO - 2023-05-10 07:22:35 --> Config Class Initialized
INFO - 2023-05-10 07:22:35 --> Hooks Class Initialized
INFO - 2023-05-10 07:22:35 --> Utf8 Class Initialized
INFO - 2023-05-10 07:22:35 --> URI Class Initialized
INFO - 2023-05-10 07:22:35 --> Router Class Initialized
INFO - 2023-05-10 07:22:35 --> Output Class Initialized
INFO - 2023-05-10 07:22:35 --> Security Class Initialized
INFO - 2023-05-10 07:22:35 --> Input Class Initialized
INFO - 2023-05-10 07:22:35 --> Language Class Initialized
ERROR - 2023-05-10 07:22:35 --> 404 Page Not Found: C_diagnosa/cek
INFO - 2023-05-10 07:22:49 --> Config Class Initialized
INFO - 2023-05-10 07:22:49 --> Hooks Class Initialized
INFO - 2023-05-10 07:22:49 --> Utf8 Class Initialized
INFO - 2023-05-10 07:22:49 --> URI Class Initialized
INFO - 2023-05-10 07:22:49 --> Router Class Initialized
INFO - 2023-05-10 07:22:49 --> Output Class Initialized
INFO - 2023-05-10 07:22:49 --> Security Class Initialized
INFO - 2023-05-10 07:22:49 --> Input Class Initialized
INFO - 2023-05-10 07:22:49 --> Language Class Initialized
ERROR - 2023-05-10 07:22:49 --> 404 Page Not Found: C_diagnosa/cek
INFO - 2023-05-10 07:23:19 --> Config Class Initialized
INFO - 2023-05-10 07:23:19 --> Hooks Class Initialized
INFO - 2023-05-10 07:23:19 --> Utf8 Class Initialized
INFO - 2023-05-10 07:23:19 --> URI Class Initialized
INFO - 2023-05-10 07:23:19 --> Router Class Initialized
INFO - 2023-05-10 07:23:19 --> Output Class Initialized
INFO - 2023-05-10 07:23:19 --> Security Class Initialized
INFO - 2023-05-10 07:23:19 --> Input Class Initialized
INFO - 2023-05-10 07:23:19 --> Language Class Initialized
ERROR - 2023-05-10 07:23:19 --> 404 Page Not Found: C_diagnosa/index
INFO - 2023-05-10 07:23:48 --> Config Class Initialized
INFO - 2023-05-10 07:23:48 --> Hooks Class Initialized
INFO - 2023-05-10 07:23:48 --> Utf8 Class Initialized
INFO - 2023-05-10 07:23:48 --> URI Class Initialized
INFO - 2023-05-10 07:23:48 --> Router Class Initialized
INFO - 2023-05-10 07:23:48 --> Output Class Initialized
INFO - 2023-05-10 07:23:48 --> Security Class Initialized
INFO - 2023-05-10 07:23:48 --> Input Class Initialized
INFO - 2023-05-10 07:23:48 --> Language Class Initialized
ERROR - 2023-05-10 07:23:48 --> 404 Page Not Found: C_diagnosa/index
INFO - 2023-05-10 07:24:41 --> Config Class Initialized
INFO - 2023-05-10 07:24:41 --> Hooks Class Initialized
INFO - 2023-05-10 07:24:41 --> Utf8 Class Initialized
INFO - 2023-05-10 07:24:41 --> URI Class Initialized
INFO - 2023-05-10 07:24:41 --> Router Class Initialized
INFO - 2023-05-10 07:24:41 --> Output Class Initialized
INFO - 2023-05-10 07:24:41 --> Security Class Initialized
INFO - 2023-05-10 07:24:41 --> Input Class Initialized
INFO - 2023-05-10 07:24:41 --> Language Class Initialized
INFO - 2023-05-10 07:24:41 --> Loader Class Initialized
INFO - 2023-05-10 07:24:41 --> Helper loaded: url_helper
INFO - 2023-05-10 07:24:41 --> Helper loaded: form_helper
INFO - 2023-05-10 07:24:41 --> Database Driver Class Initialized
INFO - 2023-05-10 07:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:24:41 --> Form Validation Class Initialized
INFO - 2023-05-10 07:24:41 --> Controller Class Initialized
INFO - 2023-05-10 07:24:41 --> Model "m_datatrain" initialized
INFO - 2023-05-10 07:24:41 --> Final output sent to browser
INFO - 2023-05-10 07:26:19 --> Config Class Initialized
INFO - 2023-05-10 07:26:19 --> Hooks Class Initialized
INFO - 2023-05-10 07:26:19 --> Utf8 Class Initialized
INFO - 2023-05-10 07:26:19 --> URI Class Initialized
INFO - 2023-05-10 07:26:19 --> Router Class Initialized
INFO - 2023-05-10 07:26:19 --> Output Class Initialized
INFO - 2023-05-10 07:26:19 --> Security Class Initialized
INFO - 2023-05-10 07:26:19 --> Input Class Initialized
INFO - 2023-05-10 07:26:19 --> Language Class Initialized
INFO - 2023-05-10 07:26:19 --> Loader Class Initialized
INFO - 2023-05-10 07:26:19 --> Helper loaded: url_helper
INFO - 2023-05-10 07:26:19 --> Helper loaded: form_helper
INFO - 2023-05-10 07:26:19 --> Database Driver Class Initialized
INFO - 2023-05-10 07:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:26:19 --> Form Validation Class Initialized
INFO - 2023-05-10 07:26:19 --> Controller Class Initialized
INFO - 2023-05-10 07:26:19 --> Model "m_datatrain" initialized
INFO - 2023-05-10 07:26:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 07:26:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 07:26:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 07:26:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-10 07:26:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 07:26:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 07:26:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-10 07:26:19 --> Final output sent to browser
INFO - 2023-05-10 07:29:39 --> Config Class Initialized
INFO - 2023-05-10 07:29:39 --> Hooks Class Initialized
INFO - 2023-05-10 07:29:39 --> Utf8 Class Initialized
INFO - 2023-05-10 07:29:39 --> URI Class Initialized
INFO - 2023-05-10 07:29:39 --> Router Class Initialized
INFO - 2023-05-10 07:29:39 --> Output Class Initialized
INFO - 2023-05-10 07:29:39 --> Security Class Initialized
INFO - 2023-05-10 07:29:39 --> Input Class Initialized
INFO - 2023-05-10 07:29:39 --> Language Class Initialized
INFO - 2023-05-10 07:29:39 --> Loader Class Initialized
INFO - 2023-05-10 07:29:39 --> Helper loaded: url_helper
INFO - 2023-05-10 07:29:39 --> Helper loaded: form_helper
INFO - 2023-05-10 07:29:39 --> Database Driver Class Initialized
INFO - 2023-05-10 07:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:29:39 --> Form Validation Class Initialized
INFO - 2023-05-10 07:29:39 --> Controller Class Initialized
INFO - 2023-05-10 07:29:39 --> Model "m_datatrain" initialized
INFO - 2023-05-10 07:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 07:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 07:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 07:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-10 07:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 07:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 07:29:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-10 07:29:39 --> Final output sent to browser
INFO - 2023-05-10 07:33:35 --> Config Class Initialized
INFO - 2023-05-10 07:33:35 --> Hooks Class Initialized
INFO - 2023-05-10 07:33:35 --> Utf8 Class Initialized
INFO - 2023-05-10 07:33:35 --> URI Class Initialized
INFO - 2023-05-10 07:33:35 --> Router Class Initialized
INFO - 2023-05-10 07:33:35 --> Output Class Initialized
INFO - 2023-05-10 07:33:35 --> Security Class Initialized
INFO - 2023-05-10 07:33:35 --> Input Class Initialized
INFO - 2023-05-10 07:33:35 --> Language Class Initialized
INFO - 2023-05-10 07:33:35 --> Loader Class Initialized
INFO - 2023-05-10 07:33:35 --> Helper loaded: url_helper
INFO - 2023-05-10 07:33:35 --> Helper loaded: form_helper
INFO - 2023-05-10 07:33:35 --> Database Driver Class Initialized
INFO - 2023-05-10 07:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:33:35 --> Form Validation Class Initialized
INFO - 2023-05-10 07:33:35 --> Controller Class Initialized
INFO - 2023-05-10 07:33:35 --> Model "m_datatrain" initialized
INFO - 2023-05-10 07:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 07:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 07:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 07:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 07:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 07:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 07:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 07:33:35 --> Final output sent to browser
INFO - 2023-05-10 07:53:03 --> Config Class Initialized
INFO - 2023-05-10 07:53:03 --> Hooks Class Initialized
INFO - 2023-05-10 07:53:03 --> Utf8 Class Initialized
INFO - 2023-05-10 07:53:03 --> URI Class Initialized
INFO - 2023-05-10 07:53:03 --> Router Class Initialized
INFO - 2023-05-10 07:53:03 --> Output Class Initialized
INFO - 2023-05-10 07:53:03 --> Security Class Initialized
INFO - 2023-05-10 07:53:03 --> Input Class Initialized
INFO - 2023-05-10 07:53:03 --> Language Class Initialized
INFO - 2023-05-10 07:53:03 --> Loader Class Initialized
INFO - 2023-05-10 07:53:03 --> Helper loaded: url_helper
INFO - 2023-05-10 07:53:03 --> Helper loaded: form_helper
INFO - 2023-05-10 07:53:03 --> Database Driver Class Initialized
INFO - 2023-05-10 07:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 07:53:03 --> Form Validation Class Initialized
INFO - 2023-05-10 07:53:03 --> Controller Class Initialized
INFO - 2023-05-10 07:53:03 --> Model "m_datatrain" initialized
INFO - 2023-05-10 07:53:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 07:53:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 07:53:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 07:53:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 07:53:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 07:53:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 07:53:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 07:53:03 --> Final output sent to browser
INFO - 2023-05-10 08:06:53 --> Config Class Initialized
INFO - 2023-05-10 08:06:53 --> Hooks Class Initialized
INFO - 2023-05-10 08:06:53 --> Utf8 Class Initialized
INFO - 2023-05-10 08:06:53 --> URI Class Initialized
INFO - 2023-05-10 08:06:53 --> Router Class Initialized
INFO - 2023-05-10 08:06:53 --> Output Class Initialized
INFO - 2023-05-10 08:06:53 --> Security Class Initialized
INFO - 2023-05-10 08:06:53 --> Input Class Initialized
INFO - 2023-05-10 08:06:53 --> Language Class Initialized
INFO - 2023-05-10 08:06:53 --> Loader Class Initialized
INFO - 2023-05-10 08:06:53 --> Helper loaded: url_helper
INFO - 2023-05-10 08:06:53 --> Helper loaded: form_helper
INFO - 2023-05-10 08:06:53 --> Database Driver Class Initialized
INFO - 2023-05-10 08:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:06:53 --> Form Validation Class Initialized
INFO - 2023-05-10 08:06:53 --> Controller Class Initialized
INFO - 2023-05-10 08:06:53 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:06:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:06:53 --> Final output sent to browser
INFO - 2023-05-10 08:07:11 --> Config Class Initialized
INFO - 2023-05-10 08:07:11 --> Hooks Class Initialized
INFO - 2023-05-10 08:07:11 --> Utf8 Class Initialized
INFO - 2023-05-10 08:07:11 --> URI Class Initialized
INFO - 2023-05-10 08:07:11 --> Router Class Initialized
INFO - 2023-05-10 08:07:11 --> Output Class Initialized
INFO - 2023-05-10 08:07:11 --> Security Class Initialized
INFO - 2023-05-10 08:07:11 --> Input Class Initialized
INFO - 2023-05-10 08:07:11 --> Language Class Initialized
INFO - 2023-05-10 08:07:11 --> Loader Class Initialized
INFO - 2023-05-10 08:07:11 --> Helper loaded: url_helper
INFO - 2023-05-10 08:07:11 --> Helper loaded: form_helper
INFO - 2023-05-10 08:07:11 --> Database Driver Class Initialized
INFO - 2023-05-10 08:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:07:11 --> Form Validation Class Initialized
INFO - 2023-05-10 08:07:11 --> Controller Class Initialized
INFO - 2023-05-10 08:07:11 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:07:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:07:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:07:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:07:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:07:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:07:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:07:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:07:11 --> Final output sent to browser
INFO - 2023-05-10 08:07:22 --> Config Class Initialized
INFO - 2023-05-10 08:07:22 --> Hooks Class Initialized
INFO - 2023-05-10 08:07:22 --> Utf8 Class Initialized
INFO - 2023-05-10 08:07:22 --> URI Class Initialized
INFO - 2023-05-10 08:07:22 --> Router Class Initialized
INFO - 2023-05-10 08:07:22 --> Output Class Initialized
INFO - 2023-05-10 08:07:22 --> Security Class Initialized
INFO - 2023-05-10 08:07:22 --> Input Class Initialized
INFO - 2023-05-10 08:07:22 --> Language Class Initialized
INFO - 2023-05-10 08:07:22 --> Loader Class Initialized
INFO - 2023-05-10 08:07:22 --> Helper loaded: url_helper
INFO - 2023-05-10 08:07:22 --> Helper loaded: form_helper
INFO - 2023-05-10 08:07:22 --> Database Driver Class Initialized
INFO - 2023-05-10 08:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:07:22 --> Form Validation Class Initialized
INFO - 2023-05-10 08:07:22 --> Controller Class Initialized
INFO - 2023-05-10 08:07:22 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:07:22 --> Final output sent to browser
INFO - 2023-05-10 08:07:38 --> Config Class Initialized
INFO - 2023-05-10 08:07:38 --> Hooks Class Initialized
INFO - 2023-05-10 08:07:38 --> Utf8 Class Initialized
INFO - 2023-05-10 08:07:38 --> URI Class Initialized
INFO - 2023-05-10 08:07:38 --> Router Class Initialized
INFO - 2023-05-10 08:07:38 --> Output Class Initialized
INFO - 2023-05-10 08:07:38 --> Security Class Initialized
INFO - 2023-05-10 08:07:38 --> Input Class Initialized
INFO - 2023-05-10 08:07:38 --> Language Class Initialized
INFO - 2023-05-10 08:07:38 --> Loader Class Initialized
INFO - 2023-05-10 08:07:38 --> Helper loaded: url_helper
INFO - 2023-05-10 08:07:38 --> Helper loaded: form_helper
INFO - 2023-05-10 08:07:38 --> Database Driver Class Initialized
INFO - 2023-05-10 08:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:07:38 --> Form Validation Class Initialized
INFO - 2023-05-10 08:07:38 --> Controller Class Initialized
INFO - 2023-05-10 08:07:38 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:07:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:07:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:07:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:07:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:07:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:07:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:07:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:07:38 --> Final output sent to browser
INFO - 2023-05-10 08:07:48 --> Config Class Initialized
INFO - 2023-05-10 08:07:48 --> Hooks Class Initialized
INFO - 2023-05-10 08:07:48 --> Utf8 Class Initialized
INFO - 2023-05-10 08:07:48 --> URI Class Initialized
INFO - 2023-05-10 08:07:48 --> Router Class Initialized
INFO - 2023-05-10 08:07:48 --> Output Class Initialized
INFO - 2023-05-10 08:07:48 --> Security Class Initialized
INFO - 2023-05-10 08:07:48 --> Input Class Initialized
INFO - 2023-05-10 08:07:48 --> Language Class Initialized
INFO - 2023-05-10 08:07:48 --> Loader Class Initialized
INFO - 2023-05-10 08:07:48 --> Helper loaded: url_helper
INFO - 2023-05-10 08:07:48 --> Helper loaded: form_helper
INFO - 2023-05-10 08:07:48 --> Database Driver Class Initialized
INFO - 2023-05-10 08:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:07:48 --> Form Validation Class Initialized
INFO - 2023-05-10 08:07:48 --> Controller Class Initialized
INFO - 2023-05-10 08:07:48 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:07:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:07:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:07:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:07:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:07:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:07:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:07:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:07:48 --> Final output sent to browser
INFO - 2023-05-10 08:15:06 --> Config Class Initialized
INFO - 2023-05-10 08:15:06 --> Hooks Class Initialized
INFO - 2023-05-10 08:15:06 --> Utf8 Class Initialized
INFO - 2023-05-10 08:15:06 --> URI Class Initialized
INFO - 2023-05-10 08:15:06 --> Router Class Initialized
INFO - 2023-05-10 08:15:06 --> Output Class Initialized
INFO - 2023-05-10 08:15:06 --> Security Class Initialized
INFO - 2023-05-10 08:15:06 --> Input Class Initialized
INFO - 2023-05-10 08:15:06 --> Language Class Initialized
INFO - 2023-05-10 08:15:06 --> Loader Class Initialized
INFO - 2023-05-10 08:15:06 --> Helper loaded: url_helper
INFO - 2023-05-10 08:15:06 --> Helper loaded: form_helper
INFO - 2023-05-10 08:15:06 --> Database Driver Class Initialized
INFO - 2023-05-10 08:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:15:06 --> Form Validation Class Initialized
INFO - 2023-05-10 08:15:06 --> Controller Class Initialized
INFO - 2023-05-10 08:15:06 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:15:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:15:06 --> Final output sent to browser
INFO - 2023-05-10 08:16:27 --> Config Class Initialized
INFO - 2023-05-10 08:16:27 --> Hooks Class Initialized
INFO - 2023-05-10 08:16:27 --> Utf8 Class Initialized
INFO - 2023-05-10 08:16:27 --> URI Class Initialized
INFO - 2023-05-10 08:16:27 --> Router Class Initialized
INFO - 2023-05-10 08:16:27 --> Output Class Initialized
INFO - 2023-05-10 08:16:27 --> Security Class Initialized
INFO - 2023-05-10 08:16:27 --> Input Class Initialized
INFO - 2023-05-10 08:16:27 --> Language Class Initialized
INFO - 2023-05-10 08:16:27 --> Loader Class Initialized
INFO - 2023-05-10 08:16:27 --> Helper loaded: url_helper
INFO - 2023-05-10 08:16:27 --> Helper loaded: form_helper
INFO - 2023-05-10 08:16:27 --> Database Driver Class Initialized
INFO - 2023-05-10 08:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:16:27 --> Form Validation Class Initialized
INFO - 2023-05-10 08:16:27 --> Controller Class Initialized
INFO - 2023-05-10 08:16:27 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:16:27 --> Final output sent to browser
INFO - 2023-05-10 08:16:38 --> Config Class Initialized
INFO - 2023-05-10 08:16:38 --> Hooks Class Initialized
INFO - 2023-05-10 08:16:38 --> Utf8 Class Initialized
INFO - 2023-05-10 08:16:38 --> URI Class Initialized
INFO - 2023-05-10 08:16:38 --> Router Class Initialized
INFO - 2023-05-10 08:16:38 --> Output Class Initialized
INFO - 2023-05-10 08:16:38 --> Security Class Initialized
INFO - 2023-05-10 08:16:38 --> Input Class Initialized
INFO - 2023-05-10 08:16:38 --> Language Class Initialized
INFO - 2023-05-10 08:16:38 --> Loader Class Initialized
INFO - 2023-05-10 08:16:38 --> Helper loaded: url_helper
INFO - 2023-05-10 08:16:38 --> Helper loaded: form_helper
INFO - 2023-05-10 08:16:38 --> Database Driver Class Initialized
INFO - 2023-05-10 08:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:16:38 --> Form Validation Class Initialized
INFO - 2023-05-10 08:16:38 --> Controller Class Initialized
INFO - 2023-05-10 08:16:38 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:16:39 --> Final output sent to browser
INFO - 2023-05-10 08:17:02 --> Config Class Initialized
INFO - 2023-05-10 08:17:02 --> Hooks Class Initialized
INFO - 2023-05-10 08:17:02 --> Utf8 Class Initialized
INFO - 2023-05-10 08:17:02 --> URI Class Initialized
INFO - 2023-05-10 08:17:02 --> Router Class Initialized
INFO - 2023-05-10 08:17:02 --> Output Class Initialized
INFO - 2023-05-10 08:17:02 --> Security Class Initialized
INFO - 2023-05-10 08:17:02 --> Input Class Initialized
INFO - 2023-05-10 08:17:02 --> Language Class Initialized
INFO - 2023-05-10 08:17:02 --> Loader Class Initialized
INFO - 2023-05-10 08:17:02 --> Helper loaded: url_helper
INFO - 2023-05-10 08:17:02 --> Helper loaded: form_helper
INFO - 2023-05-10 08:17:02 --> Database Driver Class Initialized
INFO - 2023-05-10 08:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:17:02 --> Form Validation Class Initialized
INFO - 2023-05-10 08:17:02 --> Controller Class Initialized
INFO - 2023-05-10 08:17:02 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:17:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:17:02 --> Final output sent to browser
INFO - 2023-05-10 08:18:56 --> Config Class Initialized
INFO - 2023-05-10 08:18:56 --> Hooks Class Initialized
INFO - 2023-05-10 08:18:56 --> Utf8 Class Initialized
INFO - 2023-05-10 08:18:56 --> URI Class Initialized
INFO - 2023-05-10 08:18:56 --> Router Class Initialized
INFO - 2023-05-10 08:18:56 --> Output Class Initialized
INFO - 2023-05-10 08:18:56 --> Security Class Initialized
INFO - 2023-05-10 08:18:56 --> Input Class Initialized
INFO - 2023-05-10 08:18:56 --> Language Class Initialized
INFO - 2023-05-10 08:18:56 --> Loader Class Initialized
INFO - 2023-05-10 08:18:56 --> Helper loaded: url_helper
INFO - 2023-05-10 08:18:56 --> Helper loaded: form_helper
INFO - 2023-05-10 08:18:56 --> Database Driver Class Initialized
INFO - 2023-05-10 08:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:18:56 --> Form Validation Class Initialized
INFO - 2023-05-10 08:18:56 --> Controller Class Initialized
INFO - 2023-05-10 08:18:56 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:18:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:18:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:18:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:18:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:18:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:18:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:18:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:18:56 --> Final output sent to browser
INFO - 2023-05-10 08:31:40 --> Config Class Initialized
INFO - 2023-05-10 08:31:40 --> Hooks Class Initialized
INFO - 2023-05-10 08:31:40 --> Utf8 Class Initialized
INFO - 2023-05-10 08:31:40 --> URI Class Initialized
INFO - 2023-05-10 08:31:40 --> Router Class Initialized
INFO - 2023-05-10 08:31:40 --> Output Class Initialized
INFO - 2023-05-10 08:31:40 --> Security Class Initialized
INFO - 2023-05-10 08:31:40 --> Input Class Initialized
INFO - 2023-05-10 08:31:40 --> Language Class Initialized
INFO - 2023-05-10 08:31:40 --> Loader Class Initialized
INFO - 2023-05-10 08:31:40 --> Helper loaded: url_helper
INFO - 2023-05-10 08:31:40 --> Helper loaded: form_helper
INFO - 2023-05-10 08:31:40 --> Database Driver Class Initialized
INFO - 2023-05-10 08:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:31:40 --> Form Validation Class Initialized
INFO - 2023-05-10 08:31:40 --> Controller Class Initialized
INFO - 2023-05-10 08:31:40 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:31:40 --> Final output sent to browser
INFO - 2023-05-10 08:56:48 --> Config Class Initialized
INFO - 2023-05-10 08:56:48 --> Hooks Class Initialized
INFO - 2023-05-10 08:56:48 --> Utf8 Class Initialized
INFO - 2023-05-10 08:56:48 --> URI Class Initialized
INFO - 2023-05-10 08:56:48 --> Router Class Initialized
INFO - 2023-05-10 08:56:48 --> Output Class Initialized
INFO - 2023-05-10 08:56:48 --> Security Class Initialized
INFO - 2023-05-10 08:56:48 --> Input Class Initialized
INFO - 2023-05-10 08:56:48 --> Language Class Initialized
INFO - 2023-05-10 08:56:48 --> Loader Class Initialized
INFO - 2023-05-10 08:56:48 --> Helper loaded: url_helper
INFO - 2023-05-10 08:56:48 --> Helper loaded: form_helper
INFO - 2023-05-10 08:56:48 --> Database Driver Class Initialized
INFO - 2023-05-10 08:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:56:48 --> Form Validation Class Initialized
INFO - 2023-05-10 08:56:48 --> Controller Class Initialized
INFO - 2023-05-10 08:56:48 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:56:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-10 08:56:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-10 08:56:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-10 08:56:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-10 08:56:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-10 08:56:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-10 08:56:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-10 08:56:48 --> Final output sent to browser
INFO - 2023-05-10 08:59:27 --> Config Class Initialized
INFO - 2023-05-10 08:59:27 --> Hooks Class Initialized
INFO - 2023-05-10 08:59:27 --> Utf8 Class Initialized
INFO - 2023-05-10 08:59:27 --> URI Class Initialized
INFO - 2023-05-10 08:59:27 --> Router Class Initialized
INFO - 2023-05-10 08:59:27 --> Output Class Initialized
INFO - 2023-05-10 08:59:27 --> Security Class Initialized
INFO - 2023-05-10 08:59:27 --> Input Class Initialized
INFO - 2023-05-10 08:59:27 --> Language Class Initialized
INFO - 2023-05-10 08:59:27 --> Loader Class Initialized
INFO - 2023-05-10 08:59:27 --> Helper loaded: url_helper
INFO - 2023-05-10 08:59:27 --> Helper loaded: form_helper
INFO - 2023-05-10 08:59:27 --> Database Driver Class Initialized
INFO - 2023-05-10 08:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 08:59:27 --> Form Validation Class Initialized
INFO - 2023-05-10 08:59:27 --> Controller Class Initialized
INFO - 2023-05-10 08:59:27 --> Model "m_datatrain" initialized
INFO - 2023-05-10 08:59:27 --> Final output sent to browser
INFO - 2023-05-10 09:02:40 --> Config Class Initialized
INFO - 2023-05-10 09:02:40 --> Hooks Class Initialized
INFO - 2023-05-10 09:02:40 --> Utf8 Class Initialized
INFO - 2023-05-10 09:02:40 --> URI Class Initialized
INFO - 2023-05-10 09:02:40 --> Router Class Initialized
INFO - 2023-05-10 09:02:40 --> Output Class Initialized
INFO - 2023-05-10 09:02:40 --> Security Class Initialized
INFO - 2023-05-10 09:02:40 --> Input Class Initialized
INFO - 2023-05-10 09:02:40 --> Language Class Initialized
INFO - 2023-05-10 09:02:40 --> Loader Class Initialized
INFO - 2023-05-10 09:02:40 --> Helper loaded: url_helper
INFO - 2023-05-10 09:02:40 --> Helper loaded: form_helper
INFO - 2023-05-10 09:02:40 --> Database Driver Class Initialized
INFO - 2023-05-10 09:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 09:02:40 --> Form Validation Class Initialized
INFO - 2023-05-10 09:02:40 --> Controller Class Initialized
INFO - 2023-05-10 09:02:40 --> Model "m_datatrain" initialized
INFO - 2023-05-10 09:02:40 --> Final output sent to browser
INFO - 2023-05-10 09:02:51 --> Config Class Initialized
INFO - 2023-05-10 09:02:51 --> Hooks Class Initialized
INFO - 2023-05-10 09:02:51 --> Utf8 Class Initialized
INFO - 2023-05-10 09:02:51 --> URI Class Initialized
INFO - 2023-05-10 09:02:51 --> Router Class Initialized
INFO - 2023-05-10 09:02:51 --> Output Class Initialized
INFO - 2023-05-10 09:02:51 --> Security Class Initialized
INFO - 2023-05-10 09:02:51 --> Input Class Initialized
INFO - 2023-05-10 09:02:51 --> Language Class Initialized
INFO - 2023-05-10 09:02:51 --> Loader Class Initialized
INFO - 2023-05-10 09:02:51 --> Helper loaded: url_helper
INFO - 2023-05-10 09:02:51 --> Helper loaded: form_helper
INFO - 2023-05-10 09:02:51 --> Database Driver Class Initialized
INFO - 2023-05-10 09:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 09:02:51 --> Form Validation Class Initialized
INFO - 2023-05-10 09:02:51 --> Controller Class Initialized
INFO - 2023-05-10 09:02:51 --> Model "m_datatrain" initialized
INFO - 2023-05-10 09:02:51 --> Final output sent to browser
INFO - 2023-05-10 09:05:06 --> Config Class Initialized
INFO - 2023-05-10 09:05:06 --> Hooks Class Initialized
INFO - 2023-05-10 09:05:06 --> Utf8 Class Initialized
INFO - 2023-05-10 09:05:06 --> URI Class Initialized
INFO - 2023-05-10 09:05:06 --> Router Class Initialized
INFO - 2023-05-10 09:05:06 --> Output Class Initialized
INFO - 2023-05-10 09:05:06 --> Security Class Initialized
INFO - 2023-05-10 09:05:06 --> Input Class Initialized
INFO - 2023-05-10 09:05:06 --> Language Class Initialized
INFO - 2023-05-10 09:05:06 --> Loader Class Initialized
INFO - 2023-05-10 09:05:06 --> Helper loaded: url_helper
INFO - 2023-05-10 09:05:06 --> Helper loaded: form_helper
INFO - 2023-05-10 09:05:06 --> Database Driver Class Initialized
INFO - 2023-05-10 09:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-10 09:05:06 --> Form Validation Class Initialized
INFO - 2023-05-10 09:05:06 --> Controller Class Initialized
INFO - 2023-05-10 09:05:06 --> Model "m_datatrain" initialized
INFO - 2023-05-10 09:05:06 --> Final output sent to browser
