<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-14 09:00:41 --> Config Class Initialized
INFO - 2022-03-14 09:00:41 --> Hooks Class Initialized
INFO - 2022-03-14 09:00:41 --> Utf8 Class Initialized
INFO - 2022-03-14 09:00:41 --> URI Class Initialized
INFO - 2022-03-14 09:00:41 --> Router Class Initialized
INFO - 2022-03-14 09:00:41 --> Output Class Initialized
INFO - 2022-03-14 09:00:41 --> Security Class Initialized
INFO - 2022-03-14 09:00:41 --> Input Class Initialized
INFO - 2022-03-14 09:00:41 --> Language Class Initialized
INFO - 2022-03-14 09:00:41 --> Loader Class Initialized
INFO - 2022-03-14 09:00:41 --> Helper loaded: url_helper
INFO - 2022-03-14 09:00:41 --> Helper loaded: form_helper
INFO - 2022-03-14 09:00:58 --> Config Class Initialized
INFO - 2022-03-14 09:00:58 --> Hooks Class Initialized
INFO - 2022-03-14 09:00:58 --> Utf8 Class Initialized
INFO - 2022-03-14 09:00:58 --> URI Class Initialized
INFO - 2022-03-14 09:00:58 --> Router Class Initialized
INFO - 2022-03-14 09:00:58 --> Output Class Initialized
INFO - 2022-03-14 09:00:58 --> Security Class Initialized
INFO - 2022-03-14 09:00:58 --> Input Class Initialized
INFO - 2022-03-14 09:00:58 --> Language Class Initialized
INFO - 2022-03-14 09:00:58 --> Loader Class Initialized
INFO - 2022-03-14 09:00:58 --> Helper loaded: url_helper
INFO - 2022-03-14 09:00:58 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:13 --> Config Class Initialized
INFO - 2022-03-14 09:01:13 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:13 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:13 --> URI Class Initialized
INFO - 2022-03-14 09:01:13 --> Router Class Initialized
INFO - 2022-03-14 09:01:13 --> Output Class Initialized
INFO - 2022-03-14 09:01:13 --> Security Class Initialized
INFO - 2022-03-14 09:01:13 --> Input Class Initialized
INFO - 2022-03-14 09:01:13 --> Language Class Initialized
INFO - 2022-03-14 09:01:13 --> Loader Class Initialized
INFO - 2022-03-14 09:01:13 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:13 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:14 --> Config Class Initialized
INFO - 2022-03-14 09:01:14 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:14 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:14 --> URI Class Initialized
INFO - 2022-03-14 09:01:14 --> Router Class Initialized
INFO - 2022-03-14 09:01:14 --> Output Class Initialized
INFO - 2022-03-14 09:01:14 --> Security Class Initialized
INFO - 2022-03-14 09:01:14 --> Input Class Initialized
INFO - 2022-03-14 09:01:14 --> Language Class Initialized
INFO - 2022-03-14 09:01:14 --> Loader Class Initialized
INFO - 2022-03-14 09:01:14 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:14 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:14 --> Config Class Initialized
INFO - 2022-03-14 09:01:14 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:14 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:14 --> URI Class Initialized
INFO - 2022-03-14 09:01:14 --> Router Class Initialized
INFO - 2022-03-14 09:01:14 --> Output Class Initialized
INFO - 2022-03-14 09:01:14 --> Security Class Initialized
INFO - 2022-03-14 09:01:14 --> Input Class Initialized
INFO - 2022-03-14 09:01:14 --> Language Class Initialized
INFO - 2022-03-14 09:01:14 --> Loader Class Initialized
INFO - 2022-03-14 09:01:14 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:14 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:18 --> Config Class Initialized
INFO - 2022-03-14 09:01:18 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:18 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:18 --> URI Class Initialized
INFO - 2022-03-14 09:01:18 --> Router Class Initialized
INFO - 2022-03-14 09:01:18 --> Output Class Initialized
INFO - 2022-03-14 09:01:18 --> Security Class Initialized
INFO - 2022-03-14 09:01:18 --> Input Class Initialized
INFO - 2022-03-14 09:01:18 --> Language Class Initialized
INFO - 2022-03-14 09:01:18 --> Loader Class Initialized
INFO - 2022-03-14 09:01:18 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:18 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:26 --> Config Class Initialized
INFO - 2022-03-14 09:01:26 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:26 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:26 --> URI Class Initialized
INFO - 2022-03-14 09:01:26 --> Router Class Initialized
INFO - 2022-03-14 09:01:26 --> Output Class Initialized
INFO - 2022-03-14 09:01:26 --> Security Class Initialized
INFO - 2022-03-14 09:01:26 --> Input Class Initialized
INFO - 2022-03-14 09:01:26 --> Language Class Initialized
INFO - 2022-03-14 09:01:26 --> Loader Class Initialized
INFO - 2022-03-14 09:01:26 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:26 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:26 --> Config Class Initialized
INFO - 2022-03-14 09:01:26 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:26 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:26 --> URI Class Initialized
INFO - 2022-03-14 09:01:26 --> Router Class Initialized
INFO - 2022-03-14 09:01:26 --> Output Class Initialized
INFO - 2022-03-14 09:01:26 --> Security Class Initialized
INFO - 2022-03-14 09:01:26 --> Input Class Initialized
INFO - 2022-03-14 09:01:26 --> Language Class Initialized
INFO - 2022-03-14 09:01:26 --> Loader Class Initialized
INFO - 2022-03-14 09:01:26 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:26 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:27 --> Config Class Initialized
INFO - 2022-03-14 09:01:27 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:27 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:27 --> URI Class Initialized
INFO - 2022-03-14 09:01:27 --> Router Class Initialized
INFO - 2022-03-14 09:01:27 --> Output Class Initialized
INFO - 2022-03-14 09:01:27 --> Security Class Initialized
INFO - 2022-03-14 09:01:27 --> Input Class Initialized
INFO - 2022-03-14 09:01:27 --> Language Class Initialized
INFO - 2022-03-14 09:01:27 --> Loader Class Initialized
INFO - 2022-03-14 09:01:27 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:27 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:27 --> Config Class Initialized
INFO - 2022-03-14 09:01:27 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:27 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:27 --> URI Class Initialized
INFO - 2022-03-14 09:01:27 --> Router Class Initialized
INFO - 2022-03-14 09:01:27 --> Output Class Initialized
INFO - 2022-03-14 09:01:27 --> Security Class Initialized
INFO - 2022-03-14 09:01:27 --> Input Class Initialized
INFO - 2022-03-14 09:01:27 --> Language Class Initialized
INFO - 2022-03-14 09:01:27 --> Loader Class Initialized
INFO - 2022-03-14 09:01:27 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:27 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:27 --> Config Class Initialized
INFO - 2022-03-14 09:01:27 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:27 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:27 --> URI Class Initialized
INFO - 2022-03-14 09:01:27 --> Router Class Initialized
INFO - 2022-03-14 09:01:27 --> Output Class Initialized
INFO - 2022-03-14 09:01:27 --> Security Class Initialized
INFO - 2022-03-14 09:01:27 --> Input Class Initialized
INFO - 2022-03-14 09:01:27 --> Language Class Initialized
INFO - 2022-03-14 09:01:27 --> Loader Class Initialized
INFO - 2022-03-14 09:01:27 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:27 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:27 --> Config Class Initialized
INFO - 2022-03-14 09:01:27 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:27 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:27 --> URI Class Initialized
INFO - 2022-03-14 09:01:27 --> Router Class Initialized
INFO - 2022-03-14 09:01:27 --> Output Class Initialized
INFO - 2022-03-14 09:01:27 --> Security Class Initialized
INFO - 2022-03-14 09:01:27 --> Input Class Initialized
INFO - 2022-03-14 09:01:27 --> Language Class Initialized
INFO - 2022-03-14 09:01:27 --> Loader Class Initialized
INFO - 2022-03-14 09:01:27 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:27 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:27 --> Config Class Initialized
INFO - 2022-03-14 09:01:27 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:27 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:27 --> URI Class Initialized
INFO - 2022-03-14 09:01:27 --> Router Class Initialized
INFO - 2022-03-14 09:01:27 --> Output Class Initialized
INFO - 2022-03-14 09:01:27 --> Security Class Initialized
INFO - 2022-03-14 09:01:27 --> Input Class Initialized
INFO - 2022-03-14 09:01:27 --> Language Class Initialized
INFO - 2022-03-14 09:01:27 --> Loader Class Initialized
INFO - 2022-03-14 09:01:27 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:27 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:28 --> Config Class Initialized
INFO - 2022-03-14 09:01:28 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:28 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:28 --> URI Class Initialized
INFO - 2022-03-14 09:01:28 --> Router Class Initialized
INFO - 2022-03-14 09:01:28 --> Output Class Initialized
INFO - 2022-03-14 09:01:28 --> Security Class Initialized
INFO - 2022-03-14 09:01:28 --> Input Class Initialized
INFO - 2022-03-14 09:01:28 --> Language Class Initialized
INFO - 2022-03-14 09:01:28 --> Loader Class Initialized
INFO - 2022-03-14 09:01:28 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:28 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:28 --> Config Class Initialized
INFO - 2022-03-14 09:01:28 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:28 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:28 --> URI Class Initialized
INFO - 2022-03-14 09:01:28 --> Router Class Initialized
INFO - 2022-03-14 09:01:28 --> Output Class Initialized
INFO - 2022-03-14 09:01:28 --> Security Class Initialized
INFO - 2022-03-14 09:01:28 --> Input Class Initialized
INFO - 2022-03-14 09:01:28 --> Language Class Initialized
INFO - 2022-03-14 09:01:28 --> Loader Class Initialized
INFO - 2022-03-14 09:01:28 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:28 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:28 --> Config Class Initialized
INFO - 2022-03-14 09:01:28 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:28 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:28 --> URI Class Initialized
INFO - 2022-03-14 09:01:28 --> Router Class Initialized
INFO - 2022-03-14 09:01:28 --> Output Class Initialized
INFO - 2022-03-14 09:01:28 --> Security Class Initialized
INFO - 2022-03-14 09:01:28 --> Input Class Initialized
INFO - 2022-03-14 09:01:28 --> Language Class Initialized
INFO - 2022-03-14 09:01:28 --> Loader Class Initialized
INFO - 2022-03-14 09:01:28 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:28 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:28 --> Config Class Initialized
INFO - 2022-03-14 09:01:28 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:28 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:28 --> URI Class Initialized
INFO - 2022-03-14 09:01:28 --> Router Class Initialized
INFO - 2022-03-14 09:01:28 --> Output Class Initialized
INFO - 2022-03-14 09:01:28 --> Security Class Initialized
INFO - 2022-03-14 09:01:28 --> Input Class Initialized
INFO - 2022-03-14 09:01:28 --> Language Class Initialized
INFO - 2022-03-14 09:01:28 --> Loader Class Initialized
INFO - 2022-03-14 09:01:28 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:28 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:28 --> Config Class Initialized
INFO - 2022-03-14 09:01:28 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:28 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:28 --> URI Class Initialized
INFO - 2022-03-14 09:01:28 --> Router Class Initialized
INFO - 2022-03-14 09:01:28 --> Output Class Initialized
INFO - 2022-03-14 09:01:28 --> Security Class Initialized
INFO - 2022-03-14 09:01:28 --> Input Class Initialized
INFO - 2022-03-14 09:01:28 --> Language Class Initialized
INFO - 2022-03-14 09:01:28 --> Loader Class Initialized
INFO - 2022-03-14 09:01:28 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:28 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:29 --> Config Class Initialized
INFO - 2022-03-14 09:01:29 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:29 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:29 --> URI Class Initialized
INFO - 2022-03-14 09:01:29 --> Router Class Initialized
INFO - 2022-03-14 09:01:29 --> Output Class Initialized
INFO - 2022-03-14 09:01:29 --> Security Class Initialized
INFO - 2022-03-14 09:01:29 --> Input Class Initialized
INFO - 2022-03-14 09:01:29 --> Language Class Initialized
INFO - 2022-03-14 09:01:29 --> Loader Class Initialized
INFO - 2022-03-14 09:01:29 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:29 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:29 --> Config Class Initialized
INFO - 2022-03-14 09:01:29 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:29 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:29 --> URI Class Initialized
INFO - 2022-03-14 09:01:29 --> Router Class Initialized
INFO - 2022-03-14 09:01:29 --> Output Class Initialized
INFO - 2022-03-14 09:01:29 --> Security Class Initialized
INFO - 2022-03-14 09:01:29 --> Input Class Initialized
INFO - 2022-03-14 09:01:29 --> Language Class Initialized
INFO - 2022-03-14 09:01:29 --> Loader Class Initialized
INFO - 2022-03-14 09:01:29 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:29 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:29 --> Config Class Initialized
INFO - 2022-03-14 09:01:29 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:29 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:29 --> URI Class Initialized
INFO - 2022-03-14 09:01:29 --> Router Class Initialized
INFO - 2022-03-14 09:01:29 --> Output Class Initialized
INFO - 2022-03-14 09:01:29 --> Security Class Initialized
INFO - 2022-03-14 09:01:29 --> Input Class Initialized
INFO - 2022-03-14 09:01:29 --> Language Class Initialized
INFO - 2022-03-14 09:01:29 --> Loader Class Initialized
INFO - 2022-03-14 09:01:29 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:29 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:29 --> Config Class Initialized
INFO - 2022-03-14 09:01:29 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:29 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:29 --> URI Class Initialized
INFO - 2022-03-14 09:01:29 --> Router Class Initialized
INFO - 2022-03-14 09:01:29 --> Output Class Initialized
INFO - 2022-03-14 09:01:29 --> Security Class Initialized
INFO - 2022-03-14 09:01:29 --> Input Class Initialized
INFO - 2022-03-14 09:01:29 --> Language Class Initialized
INFO - 2022-03-14 09:01:29 --> Loader Class Initialized
INFO - 2022-03-14 09:01:29 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:29 --> Helper loaded: form_helper
INFO - 2022-03-14 09:01:29 --> Config Class Initialized
INFO - 2022-03-14 09:01:29 --> Hooks Class Initialized
INFO - 2022-03-14 09:01:29 --> Utf8 Class Initialized
INFO - 2022-03-14 09:01:29 --> URI Class Initialized
INFO - 2022-03-14 09:01:29 --> Router Class Initialized
INFO - 2022-03-14 09:01:29 --> Output Class Initialized
INFO - 2022-03-14 09:01:29 --> Security Class Initialized
INFO - 2022-03-14 09:01:29 --> Input Class Initialized
INFO - 2022-03-14 09:01:29 --> Language Class Initialized
INFO - 2022-03-14 09:01:29 --> Loader Class Initialized
INFO - 2022-03-14 09:01:29 --> Helper loaded: url_helper
INFO - 2022-03-14 09:01:29 --> Helper loaded: form_helper
INFO - 2022-03-14 09:02:01 --> Config Class Initialized
INFO - 2022-03-14 09:02:01 --> Hooks Class Initialized
INFO - 2022-03-14 09:02:01 --> Utf8 Class Initialized
INFO - 2022-03-14 09:02:01 --> URI Class Initialized
INFO - 2022-03-14 09:02:01 --> Router Class Initialized
INFO - 2022-03-14 09:02:01 --> Output Class Initialized
INFO - 2022-03-14 09:02:01 --> Security Class Initialized
INFO - 2022-03-14 09:02:01 --> Input Class Initialized
INFO - 2022-03-14 09:02:01 --> Language Class Initialized
INFO - 2022-03-14 09:02:01 --> Loader Class Initialized
INFO - 2022-03-14 09:02:01 --> Helper loaded: url_helper
INFO - 2022-03-14 09:02:01 --> Helper loaded: form_helper
INFO - 2022-03-14 09:02:01 --> Database Driver Class Initialized
INFO - 2022-03-14 09:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:02:01 --> Controller Class Initialized
INFO - 2022-03-14 09:02:01 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:02:01 --> Final output sent to browser
INFO - 2022-03-14 09:02:02 --> Config Class Initialized
INFO - 2022-03-14 09:02:02 --> Hooks Class Initialized
INFO - 2022-03-14 09:02:02 --> Utf8 Class Initialized
INFO - 2022-03-14 09:02:02 --> URI Class Initialized
INFO - 2022-03-14 09:02:02 --> Router Class Initialized
INFO - 2022-03-14 09:02:02 --> Output Class Initialized
INFO - 2022-03-14 09:02:02 --> Security Class Initialized
INFO - 2022-03-14 09:02:02 --> Input Class Initialized
INFO - 2022-03-14 09:02:02 --> Language Class Initialized
INFO - 2022-03-14 09:02:02 --> Loader Class Initialized
INFO - 2022-03-14 09:02:02 --> Helper loaded: url_helper
INFO - 2022-03-14 09:02:02 --> Helper loaded: form_helper
INFO - 2022-03-14 09:02:02 --> Database Driver Class Initialized
INFO - 2022-03-14 09:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:02:02 --> Controller Class Initialized
INFO - 2022-03-14 09:02:02 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:02:02 --> Final output sent to browser
INFO - 2022-03-14 09:02:03 --> Config Class Initialized
INFO - 2022-03-14 09:02:03 --> Hooks Class Initialized
INFO - 2022-03-14 09:02:03 --> Utf8 Class Initialized
INFO - 2022-03-14 09:02:03 --> URI Class Initialized
INFO - 2022-03-14 09:02:03 --> Router Class Initialized
INFO - 2022-03-14 09:02:03 --> Output Class Initialized
INFO - 2022-03-14 09:02:03 --> Security Class Initialized
INFO - 2022-03-14 09:02:03 --> Input Class Initialized
INFO - 2022-03-14 09:02:03 --> Language Class Initialized
INFO - 2022-03-14 09:02:03 --> Loader Class Initialized
INFO - 2022-03-14 09:02:03 --> Helper loaded: url_helper
INFO - 2022-03-14 09:02:03 --> Helper loaded: form_helper
INFO - 2022-03-14 09:02:03 --> Database Driver Class Initialized
INFO - 2022-03-14 09:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:02:03 --> Controller Class Initialized
INFO - 2022-03-14 09:02:03 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:02:03 --> Final output sent to browser
INFO - 2022-03-14 09:02:03 --> Config Class Initialized
INFO - 2022-03-14 09:02:03 --> Hooks Class Initialized
INFO - 2022-03-14 09:02:03 --> Utf8 Class Initialized
INFO - 2022-03-14 09:02:03 --> URI Class Initialized
INFO - 2022-03-14 09:02:03 --> Router Class Initialized
INFO - 2022-03-14 09:02:03 --> Output Class Initialized
INFO - 2022-03-14 09:02:03 --> Security Class Initialized
INFO - 2022-03-14 09:02:03 --> Input Class Initialized
INFO - 2022-03-14 09:02:03 --> Language Class Initialized
INFO - 2022-03-14 09:02:03 --> Loader Class Initialized
INFO - 2022-03-14 09:02:03 --> Helper loaded: url_helper
INFO - 2022-03-14 09:02:03 --> Helper loaded: form_helper
INFO - 2022-03-14 09:02:03 --> Database Driver Class Initialized
INFO - 2022-03-14 09:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:02:03 --> Controller Class Initialized
INFO - 2022-03-14 09:02:03 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:02:03 --> Final output sent to browser
INFO - 2022-03-14 09:02:04 --> Config Class Initialized
INFO - 2022-03-14 09:02:04 --> Hooks Class Initialized
INFO - 2022-03-14 09:02:04 --> Utf8 Class Initialized
INFO - 2022-03-14 09:02:04 --> URI Class Initialized
INFO - 2022-03-14 09:02:04 --> Router Class Initialized
INFO - 2022-03-14 09:02:04 --> Output Class Initialized
INFO - 2022-03-14 09:02:04 --> Security Class Initialized
INFO - 2022-03-14 09:02:04 --> Input Class Initialized
INFO - 2022-03-14 09:02:04 --> Language Class Initialized
INFO - 2022-03-14 09:02:04 --> Loader Class Initialized
INFO - 2022-03-14 09:02:04 --> Helper loaded: url_helper
INFO - 2022-03-14 09:02:04 --> Helper loaded: form_helper
INFO - 2022-03-14 09:02:04 --> Database Driver Class Initialized
INFO - 2022-03-14 09:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:02:04 --> Controller Class Initialized
INFO - 2022-03-14 09:02:04 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:02:04 --> Final output sent to browser
INFO - 2022-03-14 09:02:04 --> Config Class Initialized
INFO - 2022-03-14 09:02:04 --> Hooks Class Initialized
INFO - 2022-03-14 09:02:04 --> Utf8 Class Initialized
INFO - 2022-03-14 09:02:04 --> URI Class Initialized
INFO - 2022-03-14 09:02:04 --> Router Class Initialized
INFO - 2022-03-14 09:02:04 --> Output Class Initialized
INFO - 2022-03-14 09:02:04 --> Security Class Initialized
INFO - 2022-03-14 09:02:04 --> Input Class Initialized
INFO - 2022-03-14 09:02:04 --> Language Class Initialized
INFO - 2022-03-14 09:02:04 --> Loader Class Initialized
INFO - 2022-03-14 09:02:04 --> Helper loaded: url_helper
INFO - 2022-03-14 09:02:04 --> Helper loaded: form_helper
INFO - 2022-03-14 09:02:04 --> Database Driver Class Initialized
INFO - 2022-03-14 09:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:02:04 --> Controller Class Initialized
INFO - 2022-03-14 09:02:04 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:02:04 --> Final output sent to browser
INFO - 2022-03-14 09:02:11 --> Config Class Initialized
INFO - 2022-03-14 09:02:11 --> Hooks Class Initialized
INFO - 2022-03-14 09:02:11 --> Utf8 Class Initialized
INFO - 2022-03-14 09:02:11 --> URI Class Initialized
INFO - 2022-03-14 09:02:11 --> Router Class Initialized
INFO - 2022-03-14 09:02:11 --> Output Class Initialized
INFO - 2022-03-14 09:02:11 --> Security Class Initialized
INFO - 2022-03-14 09:02:11 --> Input Class Initialized
INFO - 2022-03-14 09:02:11 --> Language Class Initialized
INFO - 2022-03-14 09:02:11 --> Loader Class Initialized
INFO - 2022-03-14 09:02:11 --> Helper loaded: url_helper
INFO - 2022-03-14 09:02:11 --> Helper loaded: form_helper
INFO - 2022-03-14 09:02:11 --> Database Driver Class Initialized
INFO - 2022-03-14 09:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:02:11 --> Controller Class Initialized
INFO - 2022-03-14 09:02:11 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:02:11 --> Final output sent to browser
INFO - 2022-03-14 09:02:11 --> Config Class Initialized
INFO - 2022-03-14 09:02:11 --> Hooks Class Initialized
INFO - 2022-03-14 09:02:11 --> Utf8 Class Initialized
INFO - 2022-03-14 09:02:11 --> URI Class Initialized
INFO - 2022-03-14 09:02:11 --> Router Class Initialized
INFO - 2022-03-14 09:02:11 --> Output Class Initialized
INFO - 2022-03-14 09:02:11 --> Security Class Initialized
INFO - 2022-03-14 09:02:11 --> Input Class Initialized
INFO - 2022-03-14 09:02:11 --> Language Class Initialized
INFO - 2022-03-14 09:02:11 --> Loader Class Initialized
INFO - 2022-03-14 09:02:11 --> Helper loaded: url_helper
INFO - 2022-03-14 09:02:11 --> Helper loaded: form_helper
INFO - 2022-03-14 09:02:11 --> Database Driver Class Initialized
INFO - 2022-03-14 09:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:02:11 --> Controller Class Initialized
INFO - 2022-03-14 09:02:11 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:02:11 --> Final output sent to browser
INFO - 2022-03-14 09:02:12 --> Config Class Initialized
INFO - 2022-03-14 09:02:12 --> Hooks Class Initialized
INFO - 2022-03-14 09:02:12 --> Utf8 Class Initialized
INFO - 2022-03-14 09:02:12 --> URI Class Initialized
INFO - 2022-03-14 09:02:12 --> Router Class Initialized
INFO - 2022-03-14 09:02:12 --> Output Class Initialized
INFO - 2022-03-14 09:02:12 --> Security Class Initialized
INFO - 2022-03-14 09:02:12 --> Input Class Initialized
INFO - 2022-03-14 09:02:12 --> Language Class Initialized
INFO - 2022-03-14 09:02:12 --> Loader Class Initialized
INFO - 2022-03-14 09:02:12 --> Helper loaded: url_helper
INFO - 2022-03-14 09:02:12 --> Helper loaded: form_helper
INFO - 2022-03-14 09:02:12 --> Database Driver Class Initialized
INFO - 2022-03-14 09:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:02:12 --> Controller Class Initialized
INFO - 2022-03-14 09:02:12 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:02:12 --> Final output sent to browser
INFO - 2022-03-14 09:02:12 --> Config Class Initialized
INFO - 2022-03-14 09:02:12 --> Hooks Class Initialized
INFO - 2022-03-14 09:02:12 --> Utf8 Class Initialized
INFO - 2022-03-14 09:02:12 --> URI Class Initialized
INFO - 2022-03-14 09:02:12 --> Router Class Initialized
INFO - 2022-03-14 09:02:12 --> Output Class Initialized
INFO - 2022-03-14 09:02:12 --> Security Class Initialized
INFO - 2022-03-14 09:02:12 --> Input Class Initialized
INFO - 2022-03-14 09:02:12 --> Language Class Initialized
INFO - 2022-03-14 09:02:12 --> Loader Class Initialized
INFO - 2022-03-14 09:02:12 --> Helper loaded: url_helper
INFO - 2022-03-14 09:02:12 --> Helper loaded: form_helper
INFO - 2022-03-14 09:02:12 --> Database Driver Class Initialized
INFO - 2022-03-14 09:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:02:12 --> Controller Class Initialized
INFO - 2022-03-14 09:02:12 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:02:12 --> Final output sent to browser
INFO - 2022-03-14 09:04:12 --> Config Class Initialized
INFO - 2022-03-14 09:04:12 --> Hooks Class Initialized
INFO - 2022-03-14 09:04:12 --> Utf8 Class Initialized
INFO - 2022-03-14 09:04:12 --> URI Class Initialized
INFO - 2022-03-14 09:04:12 --> Router Class Initialized
INFO - 2022-03-14 09:04:12 --> Output Class Initialized
INFO - 2022-03-14 09:04:12 --> Security Class Initialized
INFO - 2022-03-14 09:04:12 --> Input Class Initialized
INFO - 2022-03-14 09:04:12 --> Language Class Initialized
INFO - 2022-03-14 09:04:12 --> Loader Class Initialized
INFO - 2022-03-14 09:04:12 --> Helper loaded: url_helper
INFO - 2022-03-14 09:04:12 --> Helper loaded: form_helper
INFO - 2022-03-14 09:04:12 --> Database Driver Class Initialized
INFO - 2022-03-14 09:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:04:12 --> Controller Class Initialized
INFO - 2022-03-14 09:04:12 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:04:12 --> Final output sent to browser
INFO - 2022-03-14 09:05:55 --> Config Class Initialized
INFO - 2022-03-14 09:05:55 --> Hooks Class Initialized
INFO - 2022-03-14 09:05:55 --> Utf8 Class Initialized
INFO - 2022-03-14 09:05:55 --> URI Class Initialized
INFO - 2022-03-14 09:05:55 --> Router Class Initialized
INFO - 2022-03-14 09:05:55 --> Output Class Initialized
INFO - 2022-03-14 09:05:55 --> Security Class Initialized
INFO - 2022-03-14 09:05:55 --> Input Class Initialized
INFO - 2022-03-14 09:05:55 --> Language Class Initialized
INFO - 2022-03-14 09:05:55 --> Loader Class Initialized
INFO - 2022-03-14 09:05:55 --> Helper loaded: url_helper
INFO - 2022-03-14 09:05:55 --> Helper loaded: form_helper
INFO - 2022-03-14 09:05:55 --> Database Driver Class Initialized
INFO - 2022-03-14 09:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:05:55 --> Controller Class Initialized
INFO - 2022-03-14 09:05:55 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:05:55 --> Final output sent to browser
INFO - 2022-03-14 09:17:38 --> Config Class Initialized
INFO - 2022-03-14 09:17:38 --> Hooks Class Initialized
INFO - 2022-03-14 09:17:38 --> Utf8 Class Initialized
INFO - 2022-03-14 09:17:38 --> URI Class Initialized
INFO - 2022-03-14 09:17:38 --> Router Class Initialized
INFO - 2022-03-14 09:17:38 --> Output Class Initialized
INFO - 2022-03-14 09:17:38 --> Security Class Initialized
INFO - 2022-03-14 09:17:38 --> Input Class Initialized
INFO - 2022-03-14 09:17:38 --> Language Class Initialized
INFO - 2022-03-14 09:17:38 --> Loader Class Initialized
INFO - 2022-03-14 09:17:38 --> Helper loaded: url_helper
INFO - 2022-03-14 09:17:38 --> Helper loaded: form_helper
INFO - 2022-03-14 09:17:38 --> Database Driver Class Initialized
INFO - 2022-03-14 09:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:17:38 --> Controller Class Initialized
INFO - 2022-03-14 09:17:38 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:17:38 --> Final output sent to browser
INFO - 2022-03-14 09:21:33 --> Config Class Initialized
INFO - 2022-03-14 09:21:33 --> Hooks Class Initialized
INFO - 2022-03-14 09:21:33 --> Utf8 Class Initialized
INFO - 2022-03-14 09:21:33 --> URI Class Initialized
INFO - 2022-03-14 09:21:33 --> Router Class Initialized
INFO - 2022-03-14 09:21:33 --> Output Class Initialized
INFO - 2022-03-14 09:21:33 --> Security Class Initialized
INFO - 2022-03-14 09:21:33 --> Input Class Initialized
INFO - 2022-03-14 09:21:33 --> Language Class Initialized
INFO - 2022-03-14 09:21:33 --> Loader Class Initialized
INFO - 2022-03-14 09:21:34 --> Helper loaded: url_helper
INFO - 2022-03-14 09:21:34 --> Helper loaded: form_helper
INFO - 2022-03-14 09:21:34 --> Database Driver Class Initialized
INFO - 2022-03-14 09:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:21:34 --> Controller Class Initialized
INFO - 2022-03-14 09:21:34 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:21:34 --> Final output sent to browser
INFO - 2022-03-14 09:21:35 --> Config Class Initialized
INFO - 2022-03-14 09:21:35 --> Hooks Class Initialized
INFO - 2022-03-14 09:21:35 --> Utf8 Class Initialized
INFO - 2022-03-14 09:21:35 --> URI Class Initialized
INFO - 2022-03-14 09:21:35 --> Router Class Initialized
INFO - 2022-03-14 09:21:35 --> Output Class Initialized
INFO - 2022-03-14 09:21:35 --> Security Class Initialized
INFO - 2022-03-14 09:21:35 --> Input Class Initialized
INFO - 2022-03-14 09:21:35 --> Language Class Initialized
INFO - 2022-03-14 09:21:35 --> Loader Class Initialized
INFO - 2022-03-14 09:21:35 --> Helper loaded: url_helper
INFO - 2022-03-14 09:21:35 --> Helper loaded: form_helper
INFO - 2022-03-14 09:21:35 --> Database Driver Class Initialized
INFO - 2022-03-14 09:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:21:35 --> Controller Class Initialized
INFO - 2022-03-14 09:21:35 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:21:35 --> Final output sent to browser
INFO - 2022-03-14 09:21:38 --> Config Class Initialized
INFO - 2022-03-14 09:21:38 --> Hooks Class Initialized
INFO - 2022-03-14 09:21:38 --> Utf8 Class Initialized
INFO - 2022-03-14 09:21:38 --> URI Class Initialized
INFO - 2022-03-14 09:21:38 --> Router Class Initialized
INFO - 2022-03-14 09:21:38 --> Output Class Initialized
INFO - 2022-03-14 09:21:38 --> Security Class Initialized
INFO - 2022-03-14 09:21:38 --> Input Class Initialized
INFO - 2022-03-14 09:21:38 --> Language Class Initialized
INFO - 2022-03-14 09:21:38 --> Loader Class Initialized
INFO - 2022-03-14 09:21:38 --> Helper loaded: url_helper
INFO - 2022-03-14 09:21:38 --> Helper loaded: form_helper
INFO - 2022-03-14 09:21:38 --> Database Driver Class Initialized
INFO - 2022-03-14 09:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:21:38 --> Controller Class Initialized
INFO - 2022-03-14 09:21:38 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:21:38 --> Final output sent to browser
INFO - 2022-03-14 09:22:55 --> Config Class Initialized
INFO - 2022-03-14 09:22:55 --> Hooks Class Initialized
INFO - 2022-03-14 09:22:55 --> Utf8 Class Initialized
INFO - 2022-03-14 09:22:55 --> URI Class Initialized
INFO - 2022-03-14 09:22:55 --> Router Class Initialized
INFO - 2022-03-14 09:22:55 --> Output Class Initialized
INFO - 2022-03-14 09:22:55 --> Security Class Initialized
INFO - 2022-03-14 09:22:55 --> Input Class Initialized
INFO - 2022-03-14 09:22:55 --> Language Class Initialized
INFO - 2022-03-14 09:22:55 --> Loader Class Initialized
INFO - 2022-03-14 09:22:55 --> Helper loaded: url_helper
INFO - 2022-03-14 09:22:55 --> Helper loaded: form_helper
INFO - 2022-03-14 09:22:55 --> Database Driver Class Initialized
INFO - 2022-03-14 09:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:22:55 --> Controller Class Initialized
INFO - 2022-03-14 09:22:55 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:22:55 --> Final output sent to browser
INFO - 2022-03-14 09:26:44 --> Config Class Initialized
INFO - 2022-03-14 09:26:44 --> Hooks Class Initialized
INFO - 2022-03-14 09:26:44 --> Utf8 Class Initialized
INFO - 2022-03-14 09:26:44 --> URI Class Initialized
INFO - 2022-03-14 09:26:44 --> Router Class Initialized
INFO - 2022-03-14 09:26:44 --> Output Class Initialized
INFO - 2022-03-14 09:26:44 --> Security Class Initialized
INFO - 2022-03-14 09:26:44 --> Input Class Initialized
INFO - 2022-03-14 09:26:44 --> Language Class Initialized
INFO - 2022-03-14 09:26:44 --> Loader Class Initialized
INFO - 2022-03-14 09:26:44 --> Helper loaded: url_helper
INFO - 2022-03-14 09:26:44 --> Helper loaded: form_helper
INFO - 2022-03-14 09:26:44 --> Database Driver Class Initialized
INFO - 2022-03-14 09:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:26:44 --> Controller Class Initialized
INFO - 2022-03-14 09:26:44 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:26:44 --> Final output sent to browser
INFO - 2022-03-14 09:28:58 --> Config Class Initialized
INFO - 2022-03-14 09:28:58 --> Hooks Class Initialized
INFO - 2022-03-14 09:28:58 --> Utf8 Class Initialized
INFO - 2022-03-14 09:28:58 --> URI Class Initialized
INFO - 2022-03-14 09:28:58 --> Router Class Initialized
INFO - 2022-03-14 09:28:58 --> Output Class Initialized
INFO - 2022-03-14 09:28:58 --> Security Class Initialized
INFO - 2022-03-14 09:28:58 --> Input Class Initialized
INFO - 2022-03-14 09:28:58 --> Language Class Initialized
INFO - 2022-03-14 09:28:58 --> Loader Class Initialized
INFO - 2022-03-14 09:28:58 --> Helper loaded: url_helper
INFO - 2022-03-14 09:28:58 --> Helper loaded: form_helper
INFO - 2022-03-14 09:28:58 --> Database Driver Class Initialized
INFO - 2022-03-14 09:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:28:58 --> Controller Class Initialized
INFO - 2022-03-14 09:28:58 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:28:58 --> Final output sent to browser
INFO - 2022-03-14 09:29:24 --> Config Class Initialized
INFO - 2022-03-14 09:29:24 --> Hooks Class Initialized
INFO - 2022-03-14 09:29:24 --> Utf8 Class Initialized
INFO - 2022-03-14 09:29:24 --> URI Class Initialized
INFO - 2022-03-14 09:29:24 --> Router Class Initialized
INFO - 2022-03-14 09:29:24 --> Output Class Initialized
INFO - 2022-03-14 09:29:24 --> Security Class Initialized
INFO - 2022-03-14 09:29:24 --> Input Class Initialized
INFO - 2022-03-14 09:29:24 --> Language Class Initialized
INFO - 2022-03-14 09:29:24 --> Loader Class Initialized
INFO - 2022-03-14 09:29:24 --> Helper loaded: url_helper
INFO - 2022-03-14 09:29:24 --> Helper loaded: form_helper
INFO - 2022-03-14 09:29:24 --> Database Driver Class Initialized
INFO - 2022-03-14 09:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:29:24 --> Controller Class Initialized
INFO - 2022-03-14 09:29:24 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:29:24 --> Final output sent to browser
INFO - 2022-03-14 09:30:35 --> Config Class Initialized
INFO - 2022-03-14 09:30:35 --> Hooks Class Initialized
INFO - 2022-03-14 09:30:35 --> Utf8 Class Initialized
INFO - 2022-03-14 09:30:35 --> URI Class Initialized
INFO - 2022-03-14 09:30:35 --> Router Class Initialized
INFO - 2022-03-14 09:30:35 --> Output Class Initialized
INFO - 2022-03-14 09:30:35 --> Security Class Initialized
INFO - 2022-03-14 09:30:35 --> Input Class Initialized
INFO - 2022-03-14 09:30:35 --> Language Class Initialized
INFO - 2022-03-14 09:30:35 --> Loader Class Initialized
INFO - 2022-03-14 09:30:35 --> Helper loaded: url_helper
INFO - 2022-03-14 09:30:35 --> Helper loaded: form_helper
INFO - 2022-03-14 09:30:35 --> Database Driver Class Initialized
INFO - 2022-03-14 09:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:30:35 --> Controller Class Initialized
INFO - 2022-03-14 09:30:35 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:30:35 --> Final output sent to browser
INFO - 2022-03-14 09:31:34 --> Config Class Initialized
INFO - 2022-03-14 09:31:34 --> Hooks Class Initialized
INFO - 2022-03-14 09:31:34 --> Utf8 Class Initialized
INFO - 2022-03-14 09:31:34 --> URI Class Initialized
INFO - 2022-03-14 09:31:34 --> Router Class Initialized
INFO - 2022-03-14 09:31:34 --> Output Class Initialized
INFO - 2022-03-14 09:31:34 --> Security Class Initialized
INFO - 2022-03-14 09:31:34 --> Input Class Initialized
INFO - 2022-03-14 09:31:34 --> Language Class Initialized
INFO - 2022-03-14 09:31:34 --> Loader Class Initialized
INFO - 2022-03-14 09:31:34 --> Helper loaded: url_helper
INFO - 2022-03-14 09:31:34 --> Helper loaded: form_helper
INFO - 2022-03-14 09:31:34 --> Database Driver Class Initialized
INFO - 2022-03-14 09:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:31:34 --> Controller Class Initialized
INFO - 2022-03-14 09:31:34 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:31:34 --> Final output sent to browser
INFO - 2022-03-14 09:31:35 --> Config Class Initialized
INFO - 2022-03-14 09:31:35 --> Hooks Class Initialized
INFO - 2022-03-14 09:31:35 --> Utf8 Class Initialized
INFO - 2022-03-14 09:31:35 --> URI Class Initialized
INFO - 2022-03-14 09:31:35 --> Router Class Initialized
INFO - 2022-03-14 09:31:35 --> Output Class Initialized
INFO - 2022-03-14 09:31:35 --> Security Class Initialized
INFO - 2022-03-14 09:31:35 --> Input Class Initialized
INFO - 2022-03-14 09:31:35 --> Language Class Initialized
INFO - 2022-03-14 09:31:35 --> Loader Class Initialized
INFO - 2022-03-14 09:31:35 --> Helper loaded: url_helper
INFO - 2022-03-14 09:31:35 --> Helper loaded: form_helper
INFO - 2022-03-14 09:31:35 --> Database Driver Class Initialized
INFO - 2022-03-14 09:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:31:35 --> Controller Class Initialized
INFO - 2022-03-14 09:31:35 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:31:35 --> Final output sent to browser
INFO - 2022-03-14 09:32:49 --> Config Class Initialized
INFO - 2022-03-14 09:32:49 --> Hooks Class Initialized
INFO - 2022-03-14 09:32:49 --> Utf8 Class Initialized
INFO - 2022-03-14 09:32:49 --> URI Class Initialized
INFO - 2022-03-14 09:32:49 --> Router Class Initialized
INFO - 2022-03-14 09:32:49 --> Output Class Initialized
INFO - 2022-03-14 09:32:49 --> Security Class Initialized
INFO - 2022-03-14 09:32:49 --> Input Class Initialized
INFO - 2022-03-14 09:32:49 --> Language Class Initialized
INFO - 2022-03-14 09:32:49 --> Loader Class Initialized
INFO - 2022-03-14 09:32:49 --> Helper loaded: url_helper
INFO - 2022-03-14 09:32:49 --> Helper loaded: form_helper
INFO - 2022-03-14 09:32:49 --> Database Driver Class Initialized
INFO - 2022-03-14 09:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:32:49 --> Controller Class Initialized
INFO - 2022-03-14 09:32:49 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:32:49 --> Final output sent to browser
INFO - 2022-03-14 09:34:03 --> Config Class Initialized
INFO - 2022-03-14 09:34:03 --> Hooks Class Initialized
INFO - 2022-03-14 09:34:03 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:03 --> URI Class Initialized
INFO - 2022-03-14 09:34:03 --> Router Class Initialized
INFO - 2022-03-14 09:34:03 --> Output Class Initialized
INFO - 2022-03-14 09:34:03 --> Security Class Initialized
INFO - 2022-03-14 09:34:03 --> Input Class Initialized
INFO - 2022-03-14 09:34:03 --> Language Class Initialized
INFO - 2022-03-14 09:34:03 --> Loader Class Initialized
INFO - 2022-03-14 09:34:03 --> Helper loaded: url_helper
INFO - 2022-03-14 09:34:03 --> Helper loaded: form_helper
INFO - 2022-03-14 09:34:03 --> Database Driver Class Initialized
INFO - 2022-03-14 09:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:34:03 --> Controller Class Initialized
INFO - 2022-03-14 09:34:03 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:34:03 --> Final output sent to browser
INFO - 2022-03-14 09:34:04 --> Config Class Initialized
INFO - 2022-03-14 09:34:04 --> Hooks Class Initialized
INFO - 2022-03-14 09:34:04 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:04 --> URI Class Initialized
INFO - 2022-03-14 09:34:04 --> Router Class Initialized
INFO - 2022-03-14 09:34:04 --> Output Class Initialized
INFO - 2022-03-14 09:34:04 --> Security Class Initialized
INFO - 2022-03-14 09:34:04 --> Input Class Initialized
INFO - 2022-03-14 09:34:04 --> Language Class Initialized
INFO - 2022-03-14 09:34:04 --> Loader Class Initialized
INFO - 2022-03-14 09:34:04 --> Helper loaded: url_helper
INFO - 2022-03-14 09:34:04 --> Helper loaded: form_helper
INFO - 2022-03-14 09:34:04 --> Database Driver Class Initialized
INFO - 2022-03-14 09:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:34:04 --> Controller Class Initialized
INFO - 2022-03-14 09:34:04 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:34:04 --> Final output sent to browser
INFO - 2022-03-14 09:34:05 --> Config Class Initialized
INFO - 2022-03-14 09:34:05 --> Hooks Class Initialized
INFO - 2022-03-14 09:34:05 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:05 --> URI Class Initialized
INFO - 2022-03-14 09:34:05 --> Router Class Initialized
INFO - 2022-03-14 09:34:05 --> Output Class Initialized
INFO - 2022-03-14 09:34:05 --> Security Class Initialized
INFO - 2022-03-14 09:34:05 --> Input Class Initialized
INFO - 2022-03-14 09:34:05 --> Language Class Initialized
INFO - 2022-03-14 09:34:05 --> Loader Class Initialized
INFO - 2022-03-14 09:34:05 --> Helper loaded: url_helper
INFO - 2022-03-14 09:34:05 --> Helper loaded: form_helper
INFO - 2022-03-14 09:34:05 --> Database Driver Class Initialized
INFO - 2022-03-14 09:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:34:05 --> Controller Class Initialized
INFO - 2022-03-14 09:34:05 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:34:05 --> Final output sent to browser
INFO - 2022-03-14 09:34:05 --> Config Class Initialized
INFO - 2022-03-14 09:34:05 --> Hooks Class Initialized
INFO - 2022-03-14 09:34:05 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:05 --> URI Class Initialized
INFO - 2022-03-14 09:34:05 --> Router Class Initialized
INFO - 2022-03-14 09:34:05 --> Output Class Initialized
INFO - 2022-03-14 09:34:05 --> Security Class Initialized
INFO - 2022-03-14 09:34:05 --> Input Class Initialized
INFO - 2022-03-14 09:34:05 --> Language Class Initialized
INFO - 2022-03-14 09:34:05 --> Loader Class Initialized
INFO - 2022-03-14 09:34:05 --> Helper loaded: url_helper
INFO - 2022-03-14 09:34:05 --> Helper loaded: form_helper
INFO - 2022-03-14 09:34:05 --> Database Driver Class Initialized
INFO - 2022-03-14 09:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:34:05 --> Controller Class Initialized
INFO - 2022-03-14 09:34:05 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:34:05 --> Final output sent to browser
INFO - 2022-03-14 09:34:31 --> Config Class Initialized
INFO - 2022-03-14 09:34:31 --> Hooks Class Initialized
INFO - 2022-03-14 09:34:31 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:31 --> URI Class Initialized
INFO - 2022-03-14 09:34:31 --> Router Class Initialized
INFO - 2022-03-14 09:34:31 --> Output Class Initialized
INFO - 2022-03-14 09:34:31 --> Security Class Initialized
INFO - 2022-03-14 09:34:31 --> Input Class Initialized
INFO - 2022-03-14 09:34:31 --> Language Class Initialized
INFO - 2022-03-14 09:34:31 --> Loader Class Initialized
INFO - 2022-03-14 09:34:31 --> Helper loaded: url_helper
INFO - 2022-03-14 09:34:31 --> Helper loaded: form_helper
INFO - 2022-03-14 09:34:31 --> Database Driver Class Initialized
INFO - 2022-03-14 09:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:34:31 --> Controller Class Initialized
INFO - 2022-03-14 09:34:31 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:34:31 --> Final output sent to browser
INFO - 2022-03-14 09:42:25 --> Config Class Initialized
INFO - 2022-03-14 09:42:25 --> Hooks Class Initialized
INFO - 2022-03-14 09:42:25 --> Utf8 Class Initialized
INFO - 2022-03-14 09:42:25 --> URI Class Initialized
INFO - 2022-03-14 09:42:25 --> Router Class Initialized
INFO - 2022-03-14 09:42:25 --> Output Class Initialized
INFO - 2022-03-14 09:42:25 --> Security Class Initialized
INFO - 2022-03-14 09:42:25 --> Input Class Initialized
INFO - 2022-03-14 09:42:25 --> Language Class Initialized
INFO - 2022-03-14 09:42:25 --> Loader Class Initialized
INFO - 2022-03-14 09:42:25 --> Helper loaded: url_helper
INFO - 2022-03-14 09:42:25 --> Helper loaded: form_helper
INFO - 2022-03-14 09:42:25 --> Database Driver Class Initialized
INFO - 2022-03-14 09:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:42:25 --> Controller Class Initialized
INFO - 2022-03-14 09:42:25 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 09:42:25 --> Final output sent to browser
INFO - 2022-03-14 09:54:54 --> Config Class Initialized
INFO - 2022-03-14 09:54:54 --> Hooks Class Initialized
INFO - 2022-03-14 09:54:54 --> Utf8 Class Initialized
INFO - 2022-03-14 09:54:54 --> URI Class Initialized
INFO - 2022-03-14 09:54:54 --> Router Class Initialized
INFO - 2022-03-14 09:54:54 --> Output Class Initialized
INFO - 2022-03-14 09:54:54 --> Security Class Initialized
INFO - 2022-03-14 09:54:54 --> Input Class Initialized
INFO - 2022-03-14 09:54:54 --> Language Class Initialized
INFO - 2022-03-14 09:54:54 --> Loader Class Initialized
INFO - 2022-03-14 09:54:54 --> Helper loaded: url_helper
INFO - 2022-03-14 09:54:54 --> Helper loaded: form_helper
INFO - 2022-03-14 09:54:54 --> Database Driver Class Initialized
INFO - 2022-03-14 09:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:54:54 --> Controller Class Initialized
INFO - 2022-03-14 09:54:54 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 09:54:54 --> Final output sent to browser
INFO - 2022-03-14 10:02:37 --> Config Class Initialized
INFO - 2022-03-14 10:02:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:02:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:02:37 --> URI Class Initialized
INFO - 2022-03-14 10:02:37 --> Router Class Initialized
INFO - 2022-03-14 10:02:37 --> Output Class Initialized
INFO - 2022-03-14 10:02:37 --> Security Class Initialized
INFO - 2022-03-14 10:02:37 --> Input Class Initialized
INFO - 2022-03-14 10:02:37 --> Language Class Initialized
ERROR - 2022-03-14 10:02:37 --> 404 Page Not Found: C_overview/index
INFO - 2022-03-14 10:03:08 --> Config Class Initialized
INFO - 2022-03-14 10:03:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:03:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:03:08 --> URI Class Initialized
INFO - 2022-03-14 10:03:08 --> Router Class Initialized
INFO - 2022-03-14 10:03:08 --> Output Class Initialized
INFO - 2022-03-14 10:03:08 --> Security Class Initialized
INFO - 2022-03-14 10:03:08 --> Input Class Initialized
INFO - 2022-03-14 10:03:08 --> Language Class Initialized
INFO - 2022-03-14 10:03:08 --> Loader Class Initialized
INFO - 2022-03-14 10:03:08 --> Helper loaded: url_helper
INFO - 2022-03-14 10:03:08 --> Helper loaded: form_helper
INFO - 2022-03-14 10:03:08 --> Database Driver Class Initialized
INFO - 2022-03-14 10:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 10:03:08 --> Controller Class Initialized
INFO - 2022-03-14 10:03:08 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 10:03:08 --> Final output sent to browser
INFO - 2022-03-14 10:04:02 --> Config Class Initialized
INFO - 2022-03-14 10:04:02 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:02 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:02 --> URI Class Initialized
INFO - 2022-03-14 10:04:02 --> Router Class Initialized
INFO - 2022-03-14 10:04:02 --> Output Class Initialized
INFO - 2022-03-14 10:04:02 --> Security Class Initialized
INFO - 2022-03-14 10:04:02 --> Input Class Initialized
INFO - 2022-03-14 10:04:02 --> Language Class Initialized
ERROR - 2022-03-14 10:04:02 --> 404 Page Not Found: C_overview/index
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
INFO - 2022-03-14 10:04:36 --> Loader Class Initialized
INFO - 2022-03-14 10:04:36 --> Helper loaded: url_helper
INFO - 2022-03-14 10:04:36 --> Helper loaded: form_helper
INFO - 2022-03-14 10:04:36 --> Database Driver Class Initialized
INFO - 2022-03-14 10:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 10:04:36 --> Controller Class Initialized
INFO - 2022-03-14 10:04:36 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 10:04:36 --> Final output sent to browser
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Css/style.css
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Plugins/font-awesome
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Plugins/switchery
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Plugins/bootstrap-select
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Css/demo
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Plugins/summernote
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Css/demo
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Plugins/pace
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Plugins/pace
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Security Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> Config Class Initialized
INFO - 2022-03-14 10:04:36 --> Input Class Initialized
INFO - 2022-03-14 10:04:36 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Language Class Initialized
INFO - 2022-03-14 10:04:36 --> Router Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
ERROR - 2022-03-14 10:04:36 --> 404 Page Not Found: Js/jquery-2.1.1.min.js
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> Output Class Initialized
INFO - 2022-03-14 10:04:36 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:36 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/fast-click
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Js/bootstrap.min.js
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Js/scripts.js
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/metismenu
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/nanoscrollerjs
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/switchery
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/parsley
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/bootstrap-select
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/jquery-steps
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/bootstrap-wizard
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/masked-input
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/flot-charts
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/flot-charts
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/moment
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/moment-range
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/summernote
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/screenfull
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Img/av2.png
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Img/av4.png
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Img/av6.png
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Img/av3.png
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/fast-click
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/nanoscrollerjs
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/metismenu
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Js/scripts.js
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:37 --> Output Class Initialized
INFO - 2022-03-14 10:04:37 --> Security Class Initialized
INFO - 2022-03-14 10:04:37 --> Input Class Initialized
INFO - 2022-03-14 10:04:37 --> Language Class Initialized
ERROR - 2022-03-14 10:04:37 --> 404 Page Not Found: Plugins/switchery
INFO - 2022-03-14 10:04:37 --> Config Class Initialized
INFO - 2022-03-14 10:04:37 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:37 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:37 --> URI Class Initialized
INFO - 2022-03-14 10:04:37 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/parsley
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/jquery-steps
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/bootstrap-select
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/bootstrap-wizard
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/masked-input
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/moment
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/moment-range
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:38 --> Input Class Initialized
INFO - 2022-03-14 10:04:38 --> Language Class Initialized
ERROR - 2022-03-14 10:04:38 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:04:38 --> Config Class Initialized
INFO - 2022-03-14 10:04:38 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:38 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:38 --> URI Class Initialized
INFO - 2022-03-14 10:04:38 --> Router Class Initialized
INFO - 2022-03-14 10:04:38 --> Output Class Initialized
INFO - 2022-03-14 10:04:38 --> Security Class Initialized
INFO - 2022-03-14 10:04:39 --> Input Class Initialized
INFO - 2022-03-14 10:04:39 --> Language Class Initialized
ERROR - 2022-03-14 10:04:39 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:04:39 --> Config Class Initialized
INFO - 2022-03-14 10:04:39 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:39 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:39 --> URI Class Initialized
INFO - 2022-03-14 10:04:39 --> Router Class Initialized
INFO - 2022-03-14 10:04:39 --> Output Class Initialized
INFO - 2022-03-14 10:04:39 --> Security Class Initialized
INFO - 2022-03-14 10:04:39 --> Input Class Initialized
INFO - 2022-03-14 10:04:39 --> Language Class Initialized
ERROR - 2022-03-14 10:04:39 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:04:39 --> Config Class Initialized
INFO - 2022-03-14 10:04:39 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:39 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:39 --> URI Class Initialized
INFO - 2022-03-14 10:04:39 --> Router Class Initialized
INFO - 2022-03-14 10:04:39 --> Output Class Initialized
INFO - 2022-03-14 10:04:39 --> Security Class Initialized
INFO - 2022-03-14 10:04:39 --> Input Class Initialized
INFO - 2022-03-14 10:04:39 --> Language Class Initialized
ERROR - 2022-03-14 10:04:39 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:04:39 --> Config Class Initialized
INFO - 2022-03-14 10:04:39 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:39 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:39 --> URI Class Initialized
INFO - 2022-03-14 10:04:39 --> Router Class Initialized
INFO - 2022-03-14 10:04:39 --> Output Class Initialized
INFO - 2022-03-14 10:04:39 --> Security Class Initialized
INFO - 2022-03-14 10:04:39 --> Input Class Initialized
INFO - 2022-03-14 10:04:39 --> Language Class Initialized
ERROR - 2022-03-14 10:04:39 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:04:39 --> Config Class Initialized
INFO - 2022-03-14 10:04:39 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:39 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:39 --> URI Class Initialized
INFO - 2022-03-14 10:04:39 --> Router Class Initialized
INFO - 2022-03-14 10:04:39 --> Output Class Initialized
INFO - 2022-03-14 10:04:39 --> Security Class Initialized
INFO - 2022-03-14 10:04:39 --> Input Class Initialized
INFO - 2022-03-14 10:04:39 --> Language Class Initialized
ERROR - 2022-03-14 10:04:39 --> 404 Page Not Found: Plugins/summernote
INFO - 2022-03-14 10:04:39 --> Config Class Initialized
INFO - 2022-03-14 10:04:39 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:39 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:39 --> URI Class Initialized
INFO - 2022-03-14 10:04:39 --> Router Class Initialized
INFO - 2022-03-14 10:04:39 --> Output Class Initialized
INFO - 2022-03-14 10:04:39 --> Security Class Initialized
INFO - 2022-03-14 10:04:39 --> Input Class Initialized
INFO - 2022-03-14 10:04:39 --> Language Class Initialized
ERROR - 2022-03-14 10:04:39 --> 404 Page Not Found: Plugins/screenfull
INFO - 2022-03-14 10:04:39 --> Config Class Initialized
INFO - 2022-03-14 10:04:39 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:39 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:39 --> URI Class Initialized
INFO - 2022-03-14 10:04:39 --> Router Class Initialized
INFO - 2022-03-14 10:04:39 --> Output Class Initialized
INFO - 2022-03-14 10:04:39 --> Security Class Initialized
INFO - 2022-03-14 10:04:39 --> Input Class Initialized
INFO - 2022-03-14 10:04:39 --> Language Class Initialized
ERROR - 2022-03-14 10:04:39 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:04:39 --> Config Class Initialized
INFO - 2022-03-14 10:04:39 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:39 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:39 --> URI Class Initialized
INFO - 2022-03-14 10:04:39 --> Router Class Initialized
INFO - 2022-03-14 10:04:39 --> Output Class Initialized
INFO - 2022-03-14 10:04:39 --> Security Class Initialized
INFO - 2022-03-14 10:04:39 --> Input Class Initialized
INFO - 2022-03-14 10:04:39 --> Language Class Initialized
ERROR - 2022-03-14 10:04:39 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:04:39 --> Config Class Initialized
INFO - 2022-03-14 10:04:39 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:39 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:39 --> URI Class Initialized
INFO - 2022-03-14 10:04:39 --> Router Class Initialized
INFO - 2022-03-14 10:04:39 --> Output Class Initialized
INFO - 2022-03-14 10:04:39 --> Security Class Initialized
INFO - 2022-03-14 10:04:39 --> Input Class Initialized
INFO - 2022-03-14 10:04:39 --> Language Class Initialized
ERROR - 2022-03-14 10:04:39 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:04:39 --> Config Class Initialized
INFO - 2022-03-14 10:04:39 --> Hooks Class Initialized
INFO - 2022-03-14 10:04:39 --> Utf8 Class Initialized
INFO - 2022-03-14 10:04:39 --> URI Class Initialized
INFO - 2022-03-14 10:04:39 --> Router Class Initialized
INFO - 2022-03-14 10:04:39 --> Output Class Initialized
INFO - 2022-03-14 10:04:39 --> Security Class Initialized
INFO - 2022-03-14 10:04:39 --> Input Class Initialized
INFO - 2022-03-14 10:04:39 --> Language Class Initialized
ERROR - 2022-03-14 10:04:39 --> 404 Page Not Found: Img/favicon.ico
INFO - 2022-03-14 10:05:08 --> Config Class Initialized
INFO - 2022-03-14 10:05:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:08 --> URI Class Initialized
INFO - 2022-03-14 10:05:08 --> Router Class Initialized
INFO - 2022-03-14 10:05:08 --> Output Class Initialized
INFO - 2022-03-14 10:05:08 --> Security Class Initialized
INFO - 2022-03-14 10:05:08 --> Input Class Initialized
INFO - 2022-03-14 10:05:08 --> Language Class Initialized
INFO - 2022-03-14 10:05:08 --> Loader Class Initialized
INFO - 2022-03-14 10:05:08 --> Helper loaded: url_helper
INFO - 2022-03-14 10:05:08 --> Helper loaded: form_helper
INFO - 2022-03-14 10:05:08 --> Database Driver Class Initialized
INFO - 2022-03-14 10:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 10:05:08 --> Controller Class Initialized
INFO - 2022-03-14 10:05:08 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 10:05:08 --> Final output sent to browser
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/font-awesome
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/bootstrap-select
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/switchery
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Css/demo
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/summernote
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Css/demo
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/pace
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/pace
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Js/jquery-2.1.1.min.js
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Js/bootstrap.min.js
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/fast-click
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/nanoscrollerjs
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Js/scripts.js
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/metismenu
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/switchery
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/parsley
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/jquery-steps
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/bootstrap-select
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/bootstrap-wizard
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/masked-input
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> URI Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Router Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Output Class Initialized
INFO - 2022-03-14 10:05:09 --> Input Class Initialized
INFO - 2022-03-14 10:05:09 --> Config Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Language Class Initialized
INFO - 2022-03-14 10:05:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:09 --> Security Class Initialized
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/flot-charts
ERROR - 2022-03-14 10:05:09 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/moment
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/moment-range
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/summernote
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Js/demo
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/screenfull
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Img/av2.png
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Img/av6.png
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Img/av3.png
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Js/bootstrap.min.js
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/fast-click
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/nanoscrollerjs
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/metismenu
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Js/scripts.js
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/switchery
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/parsley
INFO - 2022-03-14 10:05:10 --> Config Class Initialized
INFO - 2022-03-14 10:05:10 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:10 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:10 --> URI Class Initialized
INFO - 2022-03-14 10:05:10 --> Router Class Initialized
INFO - 2022-03-14 10:05:10 --> Output Class Initialized
INFO - 2022-03-14 10:05:10 --> Security Class Initialized
INFO - 2022-03-14 10:05:10 --> Input Class Initialized
INFO - 2022-03-14 10:05:10 --> Language Class Initialized
ERROR - 2022-03-14 10:05:10 --> 404 Page Not Found: Plugins/jquery-steps
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/bootstrap-select
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/bootstrap-wizard
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/masked-input
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/moment
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/moment-range
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:11 --> URI Class Initialized
INFO - 2022-03-14 10:05:11 --> Router Class Initialized
INFO - 2022-03-14 10:05:11 --> Output Class Initialized
INFO - 2022-03-14 10:05:11 --> Security Class Initialized
INFO - 2022-03-14 10:05:11 --> Input Class Initialized
INFO - 2022-03-14 10:05:11 --> Language Class Initialized
ERROR - 2022-03-14 10:05:11 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:05:11 --> Config Class Initialized
INFO - 2022-03-14 10:05:11 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:12 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:12 --> URI Class Initialized
INFO - 2022-03-14 10:05:12 --> Router Class Initialized
INFO - 2022-03-14 10:05:12 --> Output Class Initialized
INFO - 2022-03-14 10:05:12 --> Security Class Initialized
INFO - 2022-03-14 10:05:12 --> Input Class Initialized
INFO - 2022-03-14 10:05:12 --> Language Class Initialized
ERROR - 2022-03-14 10:05:12 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:05:12 --> Config Class Initialized
INFO - 2022-03-14 10:05:12 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:12 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:12 --> URI Class Initialized
INFO - 2022-03-14 10:05:12 --> Router Class Initialized
INFO - 2022-03-14 10:05:12 --> Output Class Initialized
INFO - 2022-03-14 10:05:12 --> Security Class Initialized
INFO - 2022-03-14 10:05:12 --> Input Class Initialized
INFO - 2022-03-14 10:05:12 --> Language Class Initialized
ERROR - 2022-03-14 10:05:12 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:05:12 --> Config Class Initialized
INFO - 2022-03-14 10:05:12 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:12 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:12 --> URI Class Initialized
INFO - 2022-03-14 10:05:12 --> Router Class Initialized
INFO - 2022-03-14 10:05:12 --> Output Class Initialized
INFO - 2022-03-14 10:05:12 --> Security Class Initialized
INFO - 2022-03-14 10:05:12 --> Input Class Initialized
INFO - 2022-03-14 10:05:12 --> Language Class Initialized
ERROR - 2022-03-14 10:05:12 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:05:12 --> Config Class Initialized
INFO - 2022-03-14 10:05:12 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:12 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:12 --> URI Class Initialized
INFO - 2022-03-14 10:05:12 --> Router Class Initialized
INFO - 2022-03-14 10:05:12 --> Output Class Initialized
INFO - 2022-03-14 10:05:12 --> Security Class Initialized
INFO - 2022-03-14 10:05:12 --> Input Class Initialized
INFO - 2022-03-14 10:05:12 --> Language Class Initialized
ERROR - 2022-03-14 10:05:12 --> 404 Page Not Found: Plugins/summernote
INFO - 2022-03-14 10:05:12 --> Config Class Initialized
INFO - 2022-03-14 10:05:12 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:12 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:12 --> URI Class Initialized
INFO - 2022-03-14 10:05:12 --> Router Class Initialized
INFO - 2022-03-14 10:05:12 --> Output Class Initialized
INFO - 2022-03-14 10:05:12 --> Security Class Initialized
INFO - 2022-03-14 10:05:12 --> Input Class Initialized
INFO - 2022-03-14 10:05:12 --> Language Class Initialized
ERROR - 2022-03-14 10:05:12 --> 404 Page Not Found: Plugins/screenfull
INFO - 2022-03-14 10:05:12 --> Config Class Initialized
INFO - 2022-03-14 10:05:12 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:12 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:12 --> URI Class Initialized
INFO - 2022-03-14 10:05:12 --> Router Class Initialized
INFO - 2022-03-14 10:05:12 --> Output Class Initialized
INFO - 2022-03-14 10:05:12 --> Security Class Initialized
INFO - 2022-03-14 10:05:12 --> Input Class Initialized
INFO - 2022-03-14 10:05:12 --> Language Class Initialized
ERROR - 2022-03-14 10:05:12 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:05:13 --> Config Class Initialized
INFO - 2022-03-14 10:05:13 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:13 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:13 --> URI Class Initialized
INFO - 2022-03-14 10:05:13 --> Router Class Initialized
INFO - 2022-03-14 10:05:13 --> Output Class Initialized
INFO - 2022-03-14 10:05:13 --> Security Class Initialized
INFO - 2022-03-14 10:05:13 --> Input Class Initialized
INFO - 2022-03-14 10:05:13 --> Language Class Initialized
ERROR - 2022-03-14 10:05:13 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:05:13 --> Config Class Initialized
INFO - 2022-03-14 10:05:13 --> Hooks Class Initialized
INFO - 2022-03-14 10:05:13 --> Utf8 Class Initialized
INFO - 2022-03-14 10:05:13 --> URI Class Initialized
INFO - 2022-03-14 10:05:13 --> Router Class Initialized
INFO - 2022-03-14 10:05:13 --> Output Class Initialized
INFO - 2022-03-14 10:05:13 --> Security Class Initialized
INFO - 2022-03-14 10:05:13 --> Input Class Initialized
INFO - 2022-03-14 10:05:13 --> Language Class Initialized
ERROR - 2022-03-14 10:05:13 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:01 --> Config Class Initialized
INFO - 2022-03-14 10:06:01 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:01 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:01 --> URI Class Initialized
INFO - 2022-03-14 10:06:01 --> Router Class Initialized
INFO - 2022-03-14 10:06:01 --> Output Class Initialized
INFO - 2022-03-14 10:06:01 --> Security Class Initialized
INFO - 2022-03-14 10:06:01 --> Input Class Initialized
INFO - 2022-03-14 10:06:01 --> Language Class Initialized
INFO - 2022-03-14 10:06:01 --> Loader Class Initialized
INFO - 2022-03-14 10:06:01 --> Helper loaded: url_helper
INFO - 2022-03-14 10:06:01 --> Helper loaded: form_helper
INFO - 2022-03-14 10:06:01 --> Database Driver Class Initialized
INFO - 2022-03-14 10:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 10:06:01 --> Controller Class Initialized
INFO - 2022-03-14 10:06:01 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 10:06:01 --> Final output sent to browser
INFO - 2022-03-14 10:06:04 --> Config Class Initialized
INFO - 2022-03-14 10:06:04 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:04 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:04 --> URI Class Initialized
INFO - 2022-03-14 10:06:04 --> Router Class Initialized
INFO - 2022-03-14 10:06:04 --> Output Class Initialized
INFO - 2022-03-14 10:06:04 --> Security Class Initialized
INFO - 2022-03-14 10:06:04 --> Input Class Initialized
INFO - 2022-03-14 10:06:04 --> Language Class Initialized
INFO - 2022-03-14 10:06:04 --> Loader Class Initialized
INFO - 2022-03-14 10:06:04 --> Helper loaded: url_helper
INFO - 2022-03-14 10:06:04 --> Helper loaded: form_helper
INFO - 2022-03-14 10:06:04 --> Database Driver Class Initialized
INFO - 2022-03-14 10:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 10:06:04 --> Controller Class Initialized
INFO - 2022-03-14 10:06:04 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 10:06:04 --> Final output sent to browser
INFO - 2022-03-14 10:06:05 --> Config Class Initialized
INFO - 2022-03-14 10:06:05 --> Config Class Initialized
INFO - 2022-03-14 10:06:05 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:05 --> Config Class Initialized
INFO - 2022-03-14 10:06:05 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:05 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:05 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:05 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:05 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:05 --> URI Class Initialized
INFO - 2022-03-14 10:06:05 --> URI Class Initialized
INFO - 2022-03-14 10:06:05 --> URI Class Initialized
INFO - 2022-03-14 10:06:05 --> Router Class Initialized
INFO - 2022-03-14 10:06:05 --> Router Class Initialized
INFO - 2022-03-14 10:06:05 --> Router Class Initialized
INFO - 2022-03-14 10:06:05 --> Output Class Initialized
INFO - 2022-03-14 10:06:05 --> Security Class Initialized
INFO - 2022-03-14 10:06:05 --> Output Class Initialized
INFO - 2022-03-14 10:06:05 --> Output Class Initialized
INFO - 2022-03-14 10:06:05 --> Input Class Initialized
INFO - 2022-03-14 10:06:05 --> Language Class Initialized
INFO - 2022-03-14 10:06:05 --> Security Class Initialized
INFO - 2022-03-14 10:06:05 --> Security Class Initialized
ERROR - 2022-03-14 10:06:05 --> 404 Page Not Found: Plugins/switchery
INFO - 2022-03-14 10:06:05 --> Input Class Initialized
INFO - 2022-03-14 10:06:05 --> Input Class Initialized
INFO - 2022-03-14 10:06:05 --> Language Class Initialized
INFO - 2022-03-14 10:06:05 --> Language Class Initialized
ERROR - 2022-03-14 10:06:05 --> 404 Page Not Found: Plugins/font-awesome
ERROR - 2022-03-14 10:06:05 --> 404 Page Not Found: Plugins/bootstrap-select
INFO - 2022-03-14 10:06:05 --> Config Class Initialized
INFO - 2022-03-14 10:06:05 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:05 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:05 --> URI Class Initialized
INFO - 2022-03-14 10:06:05 --> Router Class Initialized
INFO - 2022-03-14 10:06:05 --> Output Class Initialized
INFO - 2022-03-14 10:06:05 --> Security Class Initialized
INFO - 2022-03-14 10:06:05 --> Input Class Initialized
INFO - 2022-03-14 10:06:05 --> Language Class Initialized
ERROR - 2022-03-14 10:06:05 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:05 --> Config Class Initialized
INFO - 2022-03-14 10:06:05 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:05 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:05 --> URI Class Initialized
INFO - 2022-03-14 10:06:05 --> Router Class Initialized
INFO - 2022-03-14 10:06:05 --> Output Class Initialized
INFO - 2022-03-14 10:06:05 --> Security Class Initialized
INFO - 2022-03-14 10:06:05 --> Input Class Initialized
INFO - 2022-03-14 10:06:05 --> Language Class Initialized
ERROR - 2022-03-14 10:06:05 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Css/demo
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Css/demo
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Js/bootstrap.min.js
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/metismenu
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Js/jquery-2.1.1.min.js
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/moment
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/nanoscrollerjs
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/masked-input
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/bootstrap-select
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/fast-click
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/summernote
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/parsley
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/pace
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/pace
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Js/scripts.js
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/jquery-steps
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/switchery
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/bootstrap-wizard
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/moment-range
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
ERROR - 2022-03-14 10:06:06 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Router Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Config Class Initialized
INFO - 2022-03-14 10:06:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:06 --> Output Class Initialized
INFO - 2022-03-14 10:06:06 --> Security Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> Input Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> URI Class Initialized
INFO - 2022-03-14 10:06:06 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/summernote
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/screenfull
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Img/av2.png
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Img/av3.png
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Img/av6.png
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Js/jquery-2.1.1.min.js
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Js/bootstrap.min.js
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/fast-click
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/nanoscrollerjs
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/metismenu
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Js/scripts.js
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/switchery
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/parsley
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/jquery-steps
INFO - 2022-03-14 10:06:07 --> Config Class Initialized
INFO - 2022-03-14 10:06:07 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:07 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:07 --> URI Class Initialized
INFO - 2022-03-14 10:06:07 --> Router Class Initialized
INFO - 2022-03-14 10:06:07 --> Output Class Initialized
INFO - 2022-03-14 10:06:07 --> Security Class Initialized
INFO - 2022-03-14 10:06:07 --> Input Class Initialized
INFO - 2022-03-14 10:06:07 --> Language Class Initialized
ERROR - 2022-03-14 10:06:07 --> 404 Page Not Found: Plugins/bootstrap-select
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/bootstrap-wizard
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/masked-input
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/moment
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/moment-range
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:08 --> Config Class Initialized
INFO - 2022-03-14 10:06:08 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:08 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:08 --> URI Class Initialized
INFO - 2022-03-14 10:06:08 --> Router Class Initialized
INFO - 2022-03-14 10:06:08 --> Output Class Initialized
INFO - 2022-03-14 10:06:08 --> Security Class Initialized
INFO - 2022-03-14 10:06:08 --> Input Class Initialized
INFO - 2022-03-14 10:06:08 --> Language Class Initialized
ERROR - 2022-03-14 10:06:08 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:09 --> Config Class Initialized
INFO - 2022-03-14 10:06:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:09 --> URI Class Initialized
INFO - 2022-03-14 10:06:09 --> Router Class Initialized
INFO - 2022-03-14 10:06:09 --> Output Class Initialized
INFO - 2022-03-14 10:06:09 --> Security Class Initialized
INFO - 2022-03-14 10:06:09 --> Input Class Initialized
INFO - 2022-03-14 10:06:09 --> Language Class Initialized
ERROR - 2022-03-14 10:06:09 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:09 --> Config Class Initialized
INFO - 2022-03-14 10:06:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:09 --> URI Class Initialized
INFO - 2022-03-14 10:06:09 --> Router Class Initialized
INFO - 2022-03-14 10:06:09 --> Output Class Initialized
INFO - 2022-03-14 10:06:09 --> Security Class Initialized
INFO - 2022-03-14 10:06:09 --> Input Class Initialized
INFO - 2022-03-14 10:06:09 --> Language Class Initialized
ERROR - 2022-03-14 10:06:09 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:09 --> Config Class Initialized
INFO - 2022-03-14 10:06:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:09 --> URI Class Initialized
INFO - 2022-03-14 10:06:09 --> Router Class Initialized
INFO - 2022-03-14 10:06:09 --> Output Class Initialized
INFO - 2022-03-14 10:06:09 --> Security Class Initialized
INFO - 2022-03-14 10:06:09 --> Input Class Initialized
INFO - 2022-03-14 10:06:09 --> Language Class Initialized
ERROR - 2022-03-14 10:06:09 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:09 --> Config Class Initialized
INFO - 2022-03-14 10:06:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:09 --> URI Class Initialized
INFO - 2022-03-14 10:06:09 --> Router Class Initialized
INFO - 2022-03-14 10:06:09 --> Output Class Initialized
INFO - 2022-03-14 10:06:09 --> Security Class Initialized
INFO - 2022-03-14 10:06:09 --> Input Class Initialized
INFO - 2022-03-14 10:06:09 --> Language Class Initialized
ERROR - 2022-03-14 10:06:09 --> 404 Page Not Found: Plugins/summernote
INFO - 2022-03-14 10:06:09 --> Config Class Initialized
INFO - 2022-03-14 10:06:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:09 --> URI Class Initialized
INFO - 2022-03-14 10:06:09 --> Router Class Initialized
INFO - 2022-03-14 10:06:09 --> Output Class Initialized
INFO - 2022-03-14 10:06:09 --> Security Class Initialized
INFO - 2022-03-14 10:06:09 --> Input Class Initialized
INFO - 2022-03-14 10:06:09 --> Language Class Initialized
ERROR - 2022-03-14 10:06:09 --> 404 Page Not Found: Plugins/screenfull
INFO - 2022-03-14 10:06:09 --> Config Class Initialized
INFO - 2022-03-14 10:06:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:09 --> URI Class Initialized
INFO - 2022-03-14 10:06:09 --> Router Class Initialized
INFO - 2022-03-14 10:06:09 --> Output Class Initialized
INFO - 2022-03-14 10:06:09 --> Security Class Initialized
INFO - 2022-03-14 10:06:09 --> Input Class Initialized
INFO - 2022-03-14 10:06:09 --> Language Class Initialized
ERROR - 2022-03-14 10:06:09 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:09 --> Config Class Initialized
INFO - 2022-03-14 10:06:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:09 --> URI Class Initialized
INFO - 2022-03-14 10:06:09 --> Router Class Initialized
INFO - 2022-03-14 10:06:09 --> Output Class Initialized
INFO - 2022-03-14 10:06:09 --> Security Class Initialized
INFO - 2022-03-14 10:06:09 --> Input Class Initialized
INFO - 2022-03-14 10:06:09 --> Language Class Initialized
ERROR - 2022-03-14 10:06:09 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:09 --> Config Class Initialized
INFO - 2022-03-14 10:06:09 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:09 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:09 --> URI Class Initialized
INFO - 2022-03-14 10:06:09 --> Router Class Initialized
INFO - 2022-03-14 10:06:09 --> Output Class Initialized
INFO - 2022-03-14 10:06:09 --> Security Class Initialized
INFO - 2022-03-14 10:06:09 --> Input Class Initialized
INFO - 2022-03-14 10:06:09 --> Language Class Initialized
ERROR - 2022-03-14 10:06:09 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:15 --> Config Class Initialized
INFO - 2022-03-14 10:06:15 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:15 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:15 --> URI Class Initialized
INFO - 2022-03-14 10:06:15 --> Router Class Initialized
INFO - 2022-03-14 10:06:15 --> Output Class Initialized
INFO - 2022-03-14 10:06:15 --> Security Class Initialized
INFO - 2022-03-14 10:06:15 --> Input Class Initialized
INFO - 2022-03-14 10:06:15 --> Language Class Initialized
INFO - 2022-03-14 10:06:15 --> Loader Class Initialized
INFO - 2022-03-14 10:06:15 --> Helper loaded: url_helper
INFO - 2022-03-14 10:06:15 --> Helper loaded: form_helper
INFO - 2022-03-14 10:06:15 --> Database Driver Class Initialized
INFO - 2022-03-14 10:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 10:06:15 --> Controller Class Initialized
INFO - 2022-03-14 10:06:15 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 10:06:15 --> Final output sent to browser
INFO - 2022-03-14 10:06:16 --> Config Class Initialized
INFO - 2022-03-14 10:06:16 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:16 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:16 --> URI Class Initialized
INFO - 2022-03-14 10:06:16 --> Router Class Initialized
INFO - 2022-03-14 10:06:16 --> Output Class Initialized
INFO - 2022-03-14 10:06:16 --> Security Class Initialized
INFO - 2022-03-14 10:06:16 --> Input Class Initialized
INFO - 2022-03-14 10:06:16 --> Language Class Initialized
ERROR - 2022-03-14 10:06:16 --> 404 Page Not Found: Plugins/font-awesome
INFO - 2022-03-14 10:06:16 --> Config Class Initialized
INFO - 2022-03-14 10:06:16 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/bootstrap-select
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Css/demo
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/switchery
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/summernote
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Css/demo
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/pace
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/pace
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/metismenu
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/fast-click
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Js/jquery-2.1.1.min.js
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Js/bootstrap.min.js
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Js/scripts.js
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/nanoscrollerjs
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/switchery
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/parsley
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/jquery-steps
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/bootstrap-select
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/bootstrap-wizard
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/masked-input
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/flot-charts
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/flot-charts
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/moment
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/moment-range
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/screenfull
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/summernote
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Img/av6.png
INFO - 2022-03-14 10:06:17 --> Config Class Initialized
INFO - 2022-03-14 10:06:17 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Img/av2.png
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
INFO - 2022-03-14 10:06:17 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> URI Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
INFO - 2022-03-14 10:06:17 --> Router Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-14 10:06:17 --> Output Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Img/av3.png
INFO - 2022-03-14 10:06:17 --> Security Class Initialized
INFO - 2022-03-14 10:06:17 --> Input Class Initialized
INFO - 2022-03-14 10:06:17 --> Language Class Initialized
ERROR - 2022-03-14 10:06:17 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-14 10:06:20 --> Config Class Initialized
INFO - 2022-03-14 10:06:20 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:20 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:20 --> URI Class Initialized
INFO - 2022-03-14 10:06:20 --> Router Class Initialized
INFO - 2022-03-14 10:06:20 --> Output Class Initialized
INFO - 2022-03-14 10:06:20 --> Security Class Initialized
INFO - 2022-03-14 10:06:20 --> Input Class Initialized
INFO - 2022-03-14 10:06:20 --> Language Class Initialized
ERROR - 2022-03-14 10:06:20 --> 404 Page Not Found: Plugins/fast-click
INFO - 2022-03-14 10:06:20 --> Config Class Initialized
INFO - 2022-03-14 10:06:20 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:20 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:20 --> URI Class Initialized
INFO - 2022-03-14 10:06:20 --> Router Class Initialized
INFO - 2022-03-14 10:06:20 --> Output Class Initialized
INFO - 2022-03-14 10:06:20 --> Security Class Initialized
INFO - 2022-03-14 10:06:20 --> Input Class Initialized
INFO - 2022-03-14 10:06:20 --> Language Class Initialized
ERROR - 2022-03-14 10:06:20 --> 404 Page Not Found: Plugins/nanoscrollerjs
INFO - 2022-03-14 10:06:20 --> Config Class Initialized
INFO - 2022-03-14 10:06:20 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:20 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:20 --> URI Class Initialized
INFO - 2022-03-14 10:06:20 --> Router Class Initialized
INFO - 2022-03-14 10:06:20 --> Output Class Initialized
INFO - 2022-03-14 10:06:20 --> Security Class Initialized
INFO - 2022-03-14 10:06:20 --> Input Class Initialized
INFO - 2022-03-14 10:06:20 --> Language Class Initialized
ERROR - 2022-03-14 10:06:20 --> 404 Page Not Found: Plugins/metismenu
INFO - 2022-03-14 10:06:21 --> Config Class Initialized
INFO - 2022-03-14 10:06:21 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:21 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:21 --> URI Class Initialized
INFO - 2022-03-14 10:06:21 --> Router Class Initialized
INFO - 2022-03-14 10:06:21 --> Output Class Initialized
INFO - 2022-03-14 10:06:21 --> Security Class Initialized
INFO - 2022-03-14 10:06:21 --> Input Class Initialized
INFO - 2022-03-14 10:06:21 --> Language Class Initialized
ERROR - 2022-03-14 10:06:21 --> 404 Page Not Found: Js/scripts.js
INFO - 2022-03-14 10:06:21 --> Config Class Initialized
INFO - 2022-03-14 10:06:21 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:21 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:21 --> URI Class Initialized
INFO - 2022-03-14 10:06:21 --> Router Class Initialized
INFO - 2022-03-14 10:06:21 --> Output Class Initialized
INFO - 2022-03-14 10:06:21 --> Security Class Initialized
INFO - 2022-03-14 10:06:21 --> Input Class Initialized
INFO - 2022-03-14 10:06:21 --> Language Class Initialized
ERROR - 2022-03-14 10:06:21 --> 404 Page Not Found: Plugins/switchery
INFO - 2022-03-14 10:06:21 --> Config Class Initialized
INFO - 2022-03-14 10:06:21 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:21 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:21 --> URI Class Initialized
INFO - 2022-03-14 10:06:21 --> Router Class Initialized
INFO - 2022-03-14 10:06:21 --> Output Class Initialized
INFO - 2022-03-14 10:06:21 --> Security Class Initialized
INFO - 2022-03-14 10:06:21 --> Input Class Initialized
INFO - 2022-03-14 10:06:21 --> Language Class Initialized
ERROR - 2022-03-14 10:06:21 --> 404 Page Not Found: Plugins/parsley
INFO - 2022-03-14 10:06:21 --> Config Class Initialized
INFO - 2022-03-14 10:06:21 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:21 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:21 --> URI Class Initialized
INFO - 2022-03-14 10:06:21 --> Router Class Initialized
INFO - 2022-03-14 10:06:21 --> Output Class Initialized
INFO - 2022-03-14 10:06:21 --> Security Class Initialized
INFO - 2022-03-14 10:06:21 --> Input Class Initialized
INFO - 2022-03-14 10:06:21 --> Language Class Initialized
ERROR - 2022-03-14 10:06:21 --> 404 Page Not Found: Plugins/jquery-steps
INFO - 2022-03-14 10:06:21 --> Config Class Initialized
INFO - 2022-03-14 10:06:21 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:21 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:21 --> URI Class Initialized
INFO - 2022-03-14 10:06:21 --> Router Class Initialized
INFO - 2022-03-14 10:06:21 --> Output Class Initialized
INFO - 2022-03-14 10:06:21 --> Security Class Initialized
INFO - 2022-03-14 10:06:21 --> Input Class Initialized
INFO - 2022-03-14 10:06:21 --> Language Class Initialized
ERROR - 2022-03-14 10:06:21 --> 404 Page Not Found: Plugins/bootstrap-select
INFO - 2022-03-14 10:06:22 --> Config Class Initialized
INFO - 2022-03-14 10:06:22 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:22 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:22 --> URI Class Initialized
INFO - 2022-03-14 10:06:22 --> Router Class Initialized
INFO - 2022-03-14 10:06:22 --> Output Class Initialized
INFO - 2022-03-14 10:06:22 --> Security Class Initialized
INFO - 2022-03-14 10:06:22 --> Input Class Initialized
INFO - 2022-03-14 10:06:22 --> Language Class Initialized
ERROR - 2022-03-14 10:06:22 --> 404 Page Not Found: Plugins/bootstrap-wizard
INFO - 2022-03-14 10:06:22 --> Config Class Initialized
INFO - 2022-03-14 10:06:22 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:22 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:22 --> URI Class Initialized
INFO - 2022-03-14 10:06:22 --> Router Class Initialized
INFO - 2022-03-14 10:06:22 --> Output Class Initialized
INFO - 2022-03-14 10:06:22 --> Security Class Initialized
INFO - 2022-03-14 10:06:22 --> Input Class Initialized
INFO - 2022-03-14 10:06:22 --> Language Class Initialized
ERROR - 2022-03-14 10:06:22 --> 404 Page Not Found: Plugins/masked-input
INFO - 2022-03-14 10:06:22 --> Config Class Initialized
INFO - 2022-03-14 10:06:22 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:22 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:22 --> URI Class Initialized
INFO - 2022-03-14 10:06:22 --> Router Class Initialized
INFO - 2022-03-14 10:06:22 --> Output Class Initialized
INFO - 2022-03-14 10:06:22 --> Security Class Initialized
INFO - 2022-03-14 10:06:22 --> Input Class Initialized
INFO - 2022-03-14 10:06:22 --> Language Class Initialized
ERROR - 2022-03-14 10:06:22 --> 404 Page Not Found: Plugins/bootstrap-validator
INFO - 2022-03-14 10:06:22 --> Config Class Initialized
INFO - 2022-03-14 10:06:22 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:22 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:22 --> URI Class Initialized
INFO - 2022-03-14 10:06:22 --> Router Class Initialized
INFO - 2022-03-14 10:06:22 --> Output Class Initialized
INFO - 2022-03-14 10:06:22 --> Security Class Initialized
INFO - 2022-03-14 10:06:22 --> Input Class Initialized
INFO - 2022-03-14 10:06:22 --> Language Class Initialized
ERROR - 2022-03-14 10:06:22 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:22 --> Config Class Initialized
INFO - 2022-03-14 10:06:22 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:22 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:22 --> URI Class Initialized
INFO - 2022-03-14 10:06:22 --> Router Class Initialized
INFO - 2022-03-14 10:06:22 --> Output Class Initialized
INFO - 2022-03-14 10:06:22 --> Security Class Initialized
INFO - 2022-03-14 10:06:22 --> Input Class Initialized
INFO - 2022-03-14 10:06:22 --> Language Class Initialized
ERROR - 2022-03-14 10:06:22 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:22 --> Config Class Initialized
INFO - 2022-03-14 10:06:22 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:22 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:22 --> URI Class Initialized
INFO - 2022-03-14 10:06:22 --> Router Class Initialized
INFO - 2022-03-14 10:06:22 --> Output Class Initialized
INFO - 2022-03-14 10:06:22 --> Security Class Initialized
INFO - 2022-03-14 10:06:22 --> Input Class Initialized
INFO - 2022-03-14 10:06:22 --> Language Class Initialized
ERROR - 2022-03-14 10:06:22 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:23 --> Config Class Initialized
INFO - 2022-03-14 10:06:23 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:23 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:23 --> URI Class Initialized
INFO - 2022-03-14 10:06:23 --> Router Class Initialized
INFO - 2022-03-14 10:06:23 --> Output Class Initialized
INFO - 2022-03-14 10:06:23 --> Security Class Initialized
INFO - 2022-03-14 10:06:23 --> Input Class Initialized
INFO - 2022-03-14 10:06:23 --> Language Class Initialized
ERROR - 2022-03-14 10:06:23 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:24 --> Config Class Initialized
INFO - 2022-03-14 10:06:24 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:24 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:24 --> URI Class Initialized
INFO - 2022-03-14 10:06:24 --> Router Class Initialized
INFO - 2022-03-14 10:06:24 --> Output Class Initialized
INFO - 2022-03-14 10:06:24 --> Security Class Initialized
INFO - 2022-03-14 10:06:24 --> Input Class Initialized
INFO - 2022-03-14 10:06:24 --> Language Class Initialized
ERROR - 2022-03-14 10:06:24 --> 404 Page Not Found: Plugins/moment
INFO - 2022-03-14 10:06:24 --> Config Class Initialized
INFO - 2022-03-14 10:06:24 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:24 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:24 --> URI Class Initialized
INFO - 2022-03-14 10:06:24 --> Router Class Initialized
INFO - 2022-03-14 10:06:24 --> Output Class Initialized
INFO - 2022-03-14 10:06:24 --> Security Class Initialized
INFO - 2022-03-14 10:06:24 --> Input Class Initialized
INFO - 2022-03-14 10:06:24 --> Language Class Initialized
ERROR - 2022-03-14 10:06:24 --> 404 Page Not Found: Plugins/moment-range
INFO - 2022-03-14 10:06:24 --> Config Class Initialized
INFO - 2022-03-14 10:06:24 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:24 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:24 --> URI Class Initialized
INFO - 2022-03-14 10:06:24 --> Router Class Initialized
INFO - 2022-03-14 10:06:24 --> Output Class Initialized
INFO - 2022-03-14 10:06:24 --> Security Class Initialized
INFO - 2022-03-14 10:06:24 --> Input Class Initialized
INFO - 2022-03-14 10:06:24 --> Language Class Initialized
ERROR - 2022-03-14 10:06:24 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:24 --> Config Class Initialized
INFO - 2022-03-14 10:06:24 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:24 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:24 --> URI Class Initialized
INFO - 2022-03-14 10:06:24 --> Router Class Initialized
INFO - 2022-03-14 10:06:24 --> Output Class Initialized
INFO - 2022-03-14 10:06:24 --> Security Class Initialized
INFO - 2022-03-14 10:06:24 --> Input Class Initialized
INFO - 2022-03-14 10:06:24 --> Language Class Initialized
ERROR - 2022-03-14 10:06:24 --> 404 Page Not Found: Plugins/flot-charts
INFO - 2022-03-14 10:06:25 --> Config Class Initialized
INFO - 2022-03-14 10:06:25 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:25 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:25 --> URI Class Initialized
INFO - 2022-03-14 10:06:25 --> Router Class Initialized
INFO - 2022-03-14 10:06:25 --> Output Class Initialized
INFO - 2022-03-14 10:06:25 --> Security Class Initialized
INFO - 2022-03-14 10:06:25 --> Input Class Initialized
INFO - 2022-03-14 10:06:25 --> Language Class Initialized
ERROR - 2022-03-14 10:06:25 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:25 --> Config Class Initialized
INFO - 2022-03-14 10:06:25 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:25 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:25 --> URI Class Initialized
INFO - 2022-03-14 10:06:25 --> Router Class Initialized
INFO - 2022-03-14 10:06:25 --> Output Class Initialized
INFO - 2022-03-14 10:06:25 --> Security Class Initialized
INFO - 2022-03-14 10:06:25 --> Input Class Initialized
INFO - 2022-03-14 10:06:25 --> Language Class Initialized
ERROR - 2022-03-14 10:06:25 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:25 --> Config Class Initialized
INFO - 2022-03-14 10:06:25 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:25 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:25 --> URI Class Initialized
INFO - 2022-03-14 10:06:25 --> Router Class Initialized
INFO - 2022-03-14 10:06:25 --> Output Class Initialized
INFO - 2022-03-14 10:06:25 --> Security Class Initialized
INFO - 2022-03-14 10:06:25 --> Input Class Initialized
INFO - 2022-03-14 10:06:25 --> Language Class Initialized
ERROR - 2022-03-14 10:06:25 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:25 --> Config Class Initialized
INFO - 2022-03-14 10:06:25 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:25 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:25 --> URI Class Initialized
INFO - 2022-03-14 10:06:25 --> Router Class Initialized
INFO - 2022-03-14 10:06:25 --> Output Class Initialized
INFO - 2022-03-14 10:06:25 --> Security Class Initialized
INFO - 2022-03-14 10:06:25 --> Input Class Initialized
INFO - 2022-03-14 10:06:25 --> Language Class Initialized
ERROR - 2022-03-14 10:06:25 --> 404 Page Not Found: Plugins/jquery-ricksaw-chart
INFO - 2022-03-14 10:06:26 --> Config Class Initialized
INFO - 2022-03-14 10:06:26 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:26 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:26 --> URI Class Initialized
INFO - 2022-03-14 10:06:26 --> Router Class Initialized
INFO - 2022-03-14 10:06:26 --> Output Class Initialized
INFO - 2022-03-14 10:06:26 --> Security Class Initialized
INFO - 2022-03-14 10:06:26 --> Input Class Initialized
INFO - 2022-03-14 10:06:26 --> Language Class Initialized
ERROR - 2022-03-14 10:06:26 --> 404 Page Not Found: Plugins/summernote
INFO - 2022-03-14 10:06:26 --> Config Class Initialized
INFO - 2022-03-14 10:06:26 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:26 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:26 --> URI Class Initialized
INFO - 2022-03-14 10:06:26 --> Router Class Initialized
INFO - 2022-03-14 10:06:26 --> Output Class Initialized
INFO - 2022-03-14 10:06:26 --> Security Class Initialized
INFO - 2022-03-14 10:06:26 --> Input Class Initialized
INFO - 2022-03-14 10:06:26 --> Language Class Initialized
ERROR - 2022-03-14 10:06:26 --> 404 Page Not Found: Plugins/screenfull
INFO - 2022-03-14 10:06:27 --> Config Class Initialized
INFO - 2022-03-14 10:06:27 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:27 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:27 --> URI Class Initialized
INFO - 2022-03-14 10:06:27 --> Router Class Initialized
INFO - 2022-03-14 10:06:27 --> Output Class Initialized
INFO - 2022-03-14 10:06:27 --> Security Class Initialized
INFO - 2022-03-14 10:06:27 --> Input Class Initialized
INFO - 2022-03-14 10:06:27 --> Language Class Initialized
ERROR - 2022-03-14 10:06:27 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:27 --> Config Class Initialized
INFO - 2022-03-14 10:06:27 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:27 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:27 --> URI Class Initialized
INFO - 2022-03-14 10:06:27 --> Router Class Initialized
INFO - 2022-03-14 10:06:27 --> Output Class Initialized
INFO - 2022-03-14 10:06:27 --> Security Class Initialized
INFO - 2022-03-14 10:06:27 --> Input Class Initialized
INFO - 2022-03-14 10:06:27 --> Language Class Initialized
ERROR - 2022-03-14 10:06:27 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:06:27 --> Config Class Initialized
INFO - 2022-03-14 10:06:27 --> Hooks Class Initialized
INFO - 2022-03-14 10:06:27 --> Utf8 Class Initialized
INFO - 2022-03-14 10:06:27 --> URI Class Initialized
INFO - 2022-03-14 10:06:27 --> Router Class Initialized
INFO - 2022-03-14 10:06:27 --> Output Class Initialized
INFO - 2022-03-14 10:06:27 --> Security Class Initialized
INFO - 2022-03-14 10:06:27 --> Input Class Initialized
INFO - 2022-03-14 10:06:27 --> Language Class Initialized
ERROR - 2022-03-14 10:06:27 --> 404 Page Not Found: Js/demo
INFO - 2022-03-14 10:09:06 --> Config Class Initialized
INFO - 2022-03-14 10:09:06 --> Hooks Class Initialized
INFO - 2022-03-14 10:09:06 --> Utf8 Class Initialized
INFO - 2022-03-14 10:09:06 --> URI Class Initialized
INFO - 2022-03-14 10:09:06 --> Router Class Initialized
INFO - 2022-03-14 10:09:06 --> Output Class Initialized
INFO - 2022-03-14 10:09:06 --> Security Class Initialized
INFO - 2022-03-14 10:09:06 --> Input Class Initialized
INFO - 2022-03-14 10:09:06 --> Language Class Initialized
INFO - 2022-03-14 10:09:06 --> Loader Class Initialized
INFO - 2022-03-14 10:09:06 --> Helper loaded: url_helper
INFO - 2022-03-14 10:09:06 --> Helper loaded: form_helper
INFO - 2022-03-14 10:09:06 --> Database Driver Class Initialized
INFO - 2022-03-14 10:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 10:09:06 --> Controller Class Initialized
INFO - 2022-03-14 10:09:06 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 10:09:06 --> Final output sent to browser
INFO - 2022-03-14 10:09:24 --> Config Class Initialized
INFO - 2022-03-14 10:09:24 --> Hooks Class Initialized
INFO - 2022-03-14 10:09:24 --> Utf8 Class Initialized
INFO - 2022-03-14 10:09:24 --> URI Class Initialized
INFO - 2022-03-14 10:09:24 --> Router Class Initialized
INFO - 2022-03-14 10:09:24 --> Output Class Initialized
INFO - 2022-03-14 10:09:24 --> Security Class Initialized
INFO - 2022-03-14 10:09:24 --> Input Class Initialized
INFO - 2022-03-14 10:09:24 --> Language Class Initialized
INFO - 2022-03-14 10:09:24 --> Loader Class Initialized
INFO - 2022-03-14 10:09:24 --> Helper loaded: url_helper
INFO - 2022-03-14 10:09:24 --> Helper loaded: form_helper
INFO - 2022-03-14 10:09:24 --> Database Driver Class Initialized
INFO - 2022-03-14 10:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 10:09:24 --> Controller Class Initialized
INFO - 2022-03-14 10:09:24 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/overview.php
INFO - 2022-03-14 10:09:24 --> Final output sent to browser
INFO - 2022-03-14 22:35:20 --> Config Class Initialized
INFO - 2022-03-14 22:35:20 --> Hooks Class Initialized
INFO - 2022-03-14 22:35:20 --> Utf8 Class Initialized
INFO - 2022-03-14 22:35:20 --> URI Class Initialized
INFO - 2022-03-14 22:35:20 --> Router Class Initialized
INFO - 2022-03-14 22:35:20 --> Output Class Initialized
INFO - 2022-03-14 22:35:20 --> Security Class Initialized
INFO - 2022-03-14 22:35:20 --> Input Class Initialized
INFO - 2022-03-14 22:35:20 --> Language Class Initialized
INFO - 2022-03-14 22:35:20 --> Loader Class Initialized
INFO - 2022-03-14 22:35:20 --> Helper loaded: url_helper
INFO - 2022-03-14 22:35:21 --> Helper loaded: form_helper
INFO - 2022-03-14 22:35:21 --> Database Driver Class Initialized
INFO - 2022-03-14 22:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 22:35:21 --> Controller Class Initialized
INFO - 2022-03-14 22:35:21 --> File loaded: /mnt/LISA/htdocs/lisa_todo/application/views/welcome_message.php
INFO - 2022-03-14 22:35:21 --> Final output sent to browser
