<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-09 11:25:07 --> Config Class Initialized
INFO - 2023-06-09 11:25:07 --> Hooks Class Initialized
INFO - 2023-06-09 11:25:07 --> Utf8 Class Initialized
INFO - 2023-06-09 11:25:07 --> URI Class Initialized
INFO - 2023-06-09 11:25:07 --> Router Class Initialized
INFO - 2023-06-09 11:25:07 --> Output Class Initialized
INFO - 2023-06-09 11:25:07 --> Security Class Initialized
INFO - 2023-06-09 11:25:07 --> Input Class Initialized
INFO - 2023-06-09 11:25:07 --> Language Class Initialized
INFO - 2023-06-09 11:25:07 --> Loader Class Initialized
INFO - 2023-06-09 11:25:07 --> Helper loaded: url_helper
INFO - 2023-06-09 11:25:07 --> Helper loaded: form_helper
INFO - 2023-06-09 11:25:08 --> Database Driver Class Initialized
INFO - 2023-06-09 11:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:25:08 --> Form Validation Class Initialized
INFO - 2023-06-09 11:25:08 --> Controller Class Initialized
INFO - 2023-06-09 11:25:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-09 11:25:08 --> Final output sent to browser
INFO - 2023-06-09 11:25:34 --> Config Class Initialized
INFO - 2023-06-09 11:25:34 --> Hooks Class Initialized
INFO - 2023-06-09 11:25:34 --> Utf8 Class Initialized
INFO - 2023-06-09 11:25:34 --> URI Class Initialized
INFO - 2023-06-09 11:25:34 --> Router Class Initialized
INFO - 2023-06-09 11:25:34 --> Output Class Initialized
INFO - 2023-06-09 11:25:34 --> Security Class Initialized
INFO - 2023-06-09 11:25:34 --> Input Class Initialized
INFO - 2023-06-09 11:25:34 --> Language Class Initialized
INFO - 2023-06-09 11:25:34 --> Loader Class Initialized
INFO - 2023-06-09 11:25:34 --> Helper loaded: url_helper
INFO - 2023-06-09 11:25:34 --> Helper loaded: form_helper
INFO - 2023-06-09 11:25:34 --> Database Driver Class Initialized
INFO - 2023-06-09 11:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:25:34 --> Form Validation Class Initialized
INFO - 2023-06-09 11:25:34 --> Controller Class Initialized
INFO - 2023-06-09 11:25:34 --> Model "m_user" initialized
INFO - 2023-06-09 11:25:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-09 11:25:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-09 11:25:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-09 11:25:34 --> Final output sent to browser
INFO - 2023-06-09 11:36:53 --> Config Class Initialized
INFO - 2023-06-09 11:36:53 --> Hooks Class Initialized
INFO - 2023-06-09 11:36:53 --> Utf8 Class Initialized
INFO - 2023-06-09 11:36:53 --> URI Class Initialized
INFO - 2023-06-09 11:36:53 --> Router Class Initialized
INFO - 2023-06-09 11:36:53 --> Output Class Initialized
INFO - 2023-06-09 11:36:53 --> Security Class Initialized
INFO - 2023-06-09 11:36:53 --> Input Class Initialized
INFO - 2023-06-09 11:36:53 --> Language Class Initialized
INFO - 2023-06-09 11:36:53 --> Loader Class Initialized
INFO - 2023-06-09 11:36:53 --> Helper loaded: url_helper
INFO - 2023-06-09 11:36:53 --> Helper loaded: form_helper
INFO - 2023-06-09 11:36:53 --> Database Driver Class Initialized
INFO - 2023-06-09 11:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:36:53 --> Form Validation Class Initialized
INFO - 2023-06-09 11:36:53 --> Controller Class Initialized
INFO - 2023-06-09 11:36:53 --> Model "m_user" initialized
INFO - 2023-06-09 11:36:53 --> Config Class Initialized
INFO - 2023-06-09 11:36:53 --> Hooks Class Initialized
INFO - 2023-06-09 11:36:53 --> Utf8 Class Initialized
INFO - 2023-06-09 11:36:53 --> URI Class Initialized
INFO - 2023-06-09 11:36:53 --> Router Class Initialized
INFO - 2023-06-09 11:36:53 --> Output Class Initialized
INFO - 2023-06-09 11:36:53 --> Security Class Initialized
INFO - 2023-06-09 11:36:53 --> Input Class Initialized
INFO - 2023-06-09 11:36:53 --> Language Class Initialized
INFO - 2023-06-09 11:36:53 --> Loader Class Initialized
INFO - 2023-06-09 11:36:53 --> Helper loaded: url_helper
INFO - 2023-06-09 11:36:53 --> Helper loaded: form_helper
INFO - 2023-06-09 11:36:53 --> Database Driver Class Initialized
INFO - 2023-06-09 11:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:36:53 --> Form Validation Class Initialized
INFO - 2023-06-09 11:36:53 --> Controller Class Initialized
INFO - 2023-06-09 11:36:53 --> Model "m_user" initialized
INFO - 2023-06-09 11:36:53 --> Model "m_datatrain" initialized
INFO - 2023-06-09 11:36:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:36:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:36:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:36:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:36:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:36:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-09 11:36:53 --> Final output sent to browser
INFO - 2023-06-09 11:36:55 --> Config Class Initialized
INFO - 2023-06-09 11:36:55 --> Hooks Class Initialized
INFO - 2023-06-09 11:36:55 --> Utf8 Class Initialized
INFO - 2023-06-09 11:36:55 --> URI Class Initialized
INFO - 2023-06-09 11:36:55 --> Router Class Initialized
INFO - 2023-06-09 11:36:55 --> Output Class Initialized
INFO - 2023-06-09 11:36:55 --> Security Class Initialized
INFO - 2023-06-09 11:36:55 --> Input Class Initialized
INFO - 2023-06-09 11:36:55 --> Language Class Initialized
INFO - 2023-06-09 11:36:55 --> Loader Class Initialized
INFO - 2023-06-09 11:36:55 --> Helper loaded: url_helper
INFO - 2023-06-09 11:36:55 --> Helper loaded: form_helper
INFO - 2023-06-09 11:36:55 --> Database Driver Class Initialized
INFO - 2023-06-09 11:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:36:55 --> Form Validation Class Initialized
INFO - 2023-06-09 11:36:55 --> Controller Class Initialized
INFO - 2023-06-09 11:36:55 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:36:55 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 11:36:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:36:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:36:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 11:36:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:36:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:36:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:36:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:36:55 --> Final output sent to browser
INFO - 2023-06-09 11:36:58 --> Config Class Initialized
INFO - 2023-06-09 11:36:58 --> Hooks Class Initialized
INFO - 2023-06-09 11:36:58 --> Utf8 Class Initialized
INFO - 2023-06-09 11:36:58 --> URI Class Initialized
INFO - 2023-06-09 11:36:58 --> Router Class Initialized
INFO - 2023-06-09 11:36:58 --> Output Class Initialized
INFO - 2023-06-09 11:36:58 --> Security Class Initialized
INFO - 2023-06-09 11:36:58 --> Input Class Initialized
INFO - 2023-06-09 11:36:58 --> Language Class Initialized
INFO - 2023-06-09 11:36:58 --> Loader Class Initialized
INFO - 2023-06-09 11:36:58 --> Helper loaded: url_helper
INFO - 2023-06-09 11:36:58 --> Helper loaded: form_helper
INFO - 2023-06-09 11:36:58 --> Database Driver Class Initialized
INFO - 2023-06-09 11:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:36:58 --> Form Validation Class Initialized
INFO - 2023-06-09 11:36:58 --> Controller Class Initialized
INFO - 2023-06-09 11:36:58 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:36:58 --> Model "m_penghitungan" initialized
ERROR - 2023-06-09 11:36:58 --> Severity: Notice --> Undefined index: P_A1GangguanMood C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 576
ERROR - 2023-06-09 11:36:58 --> Severity: Notice --> Undefined index: P_A1Ringan C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 577
ERROR - 2023-06-09 11:36:58 --> Severity: Notice --> Undefined index: P_A1Sedang C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 578
ERROR - 2023-06-09 11:36:58 --> Severity: Notice --> Undefined index: P_A1Berat C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 579
INFO - 2023-06-09 11:36:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:36:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-09 11:36:58 --> Severity: Notice --> Undefined variable: P_A1GangguanMood C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 825
ERROR - 2023-06-09 11:36:58 --> Severity: Notice --> Undefined variable: P_A1Ringan C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-09 11:36:58 --> Severity: Notice --> Undefined variable: P_A1Sedang C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 827
ERROR - 2023-06-09 11:36:58 --> Severity: Notice --> Undefined variable: P_A1Berat C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 828
INFO - 2023-06-09 11:36:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-09 11:36:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:36:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:36:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:36:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:36:58 --> Final output sent to browser
INFO - 2023-06-09 11:37:17 --> Config Class Initialized
INFO - 2023-06-09 11:37:17 --> Hooks Class Initialized
INFO - 2023-06-09 11:37:17 --> Utf8 Class Initialized
INFO - 2023-06-09 11:37:17 --> URI Class Initialized
INFO - 2023-06-09 11:37:17 --> Router Class Initialized
INFO - 2023-06-09 11:37:17 --> Output Class Initialized
INFO - 2023-06-09 11:37:17 --> Security Class Initialized
INFO - 2023-06-09 11:37:17 --> Input Class Initialized
INFO - 2023-06-09 11:37:17 --> Language Class Initialized
INFO - 2023-06-09 11:37:17 --> Loader Class Initialized
INFO - 2023-06-09 11:37:17 --> Helper loaded: url_helper
INFO - 2023-06-09 11:37:17 --> Helper loaded: form_helper
INFO - 2023-06-09 11:37:17 --> Database Driver Class Initialized
INFO - 2023-06-09 11:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:37:17 --> Form Validation Class Initialized
INFO - 2023-06-09 11:37:17 --> Controller Class Initialized
INFO - 2023-06-09 11:37:17 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:37:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 11:37:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:37:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:37:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 11:37:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:37:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:37:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:37:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:37:17 --> Final output sent to browser
INFO - 2023-06-09 11:37:19 --> Config Class Initialized
INFO - 2023-06-09 11:37:19 --> Hooks Class Initialized
INFO - 2023-06-09 11:37:19 --> Utf8 Class Initialized
INFO - 2023-06-09 11:37:19 --> URI Class Initialized
INFO - 2023-06-09 11:37:19 --> Router Class Initialized
INFO - 2023-06-09 11:37:19 --> Output Class Initialized
INFO - 2023-06-09 11:37:19 --> Security Class Initialized
INFO - 2023-06-09 11:37:19 --> Input Class Initialized
INFO - 2023-06-09 11:37:19 --> Language Class Initialized
INFO - 2023-06-09 11:37:19 --> Loader Class Initialized
INFO - 2023-06-09 11:37:19 --> Helper loaded: url_helper
INFO - 2023-06-09 11:37:19 --> Helper loaded: form_helper
INFO - 2023-06-09 11:37:19 --> Database Driver Class Initialized
INFO - 2023-06-09 11:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:37:19 --> Form Validation Class Initialized
INFO - 2023-06-09 11:37:19 --> Controller Class Initialized
INFO - 2023-06-09 11:37:19 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:37:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 11:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-09 11:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:37:20 --> Final output sent to browser
INFO - 2023-06-09 11:37:25 --> Config Class Initialized
INFO - 2023-06-09 11:37:25 --> Hooks Class Initialized
INFO - 2023-06-09 11:37:25 --> Utf8 Class Initialized
INFO - 2023-06-09 11:37:25 --> URI Class Initialized
INFO - 2023-06-09 11:37:25 --> Router Class Initialized
INFO - 2023-06-09 11:37:25 --> Output Class Initialized
INFO - 2023-06-09 11:37:25 --> Security Class Initialized
INFO - 2023-06-09 11:37:25 --> Input Class Initialized
INFO - 2023-06-09 11:37:25 --> Language Class Initialized
INFO - 2023-06-09 11:37:25 --> Loader Class Initialized
INFO - 2023-06-09 11:37:25 --> Helper loaded: url_helper
INFO - 2023-06-09 11:37:25 --> Helper loaded: form_helper
INFO - 2023-06-09 11:37:25 --> Database Driver Class Initialized
INFO - 2023-06-09 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:37:25 --> Form Validation Class Initialized
INFO - 2023-06-09 11:37:25 --> Controller Class Initialized
INFO - 2023-06-09 11:37:25 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:37:25 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 11:37:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:37:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:37:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 11:37:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:37:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:37:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:37:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:37:25 --> Final output sent to browser
INFO - 2023-06-09 11:37:27 --> Config Class Initialized
INFO - 2023-06-09 11:37:27 --> Hooks Class Initialized
INFO - 2023-06-09 11:37:27 --> Utf8 Class Initialized
INFO - 2023-06-09 11:37:27 --> URI Class Initialized
INFO - 2023-06-09 11:37:27 --> Router Class Initialized
INFO - 2023-06-09 11:37:27 --> Output Class Initialized
INFO - 2023-06-09 11:37:27 --> Security Class Initialized
INFO - 2023-06-09 11:37:27 --> Input Class Initialized
INFO - 2023-06-09 11:37:27 --> Language Class Initialized
INFO - 2023-06-09 11:37:27 --> Loader Class Initialized
INFO - 2023-06-09 11:37:27 --> Helper loaded: url_helper
INFO - 2023-06-09 11:37:27 --> Helper loaded: form_helper
INFO - 2023-06-09 11:37:27 --> Database Driver Class Initialized
INFO - 2023-06-09 11:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:37:27 --> Form Validation Class Initialized
INFO - 2023-06-09 11:37:27 --> Controller Class Initialized
INFO - 2023-06-09 11:37:27 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:37:27 --> Model "m_penghitungan" initialized
ERROR - 2023-06-09 11:37:27 --> Severity: Notice --> Undefined index: P_A1GangguanMood C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 576
ERROR - 2023-06-09 11:37:27 --> Severity: Notice --> Undefined index: P_A1Ringan C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 577
ERROR - 2023-06-09 11:37:27 --> Severity: Notice --> Undefined index: P_A1Sedang C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 578
ERROR - 2023-06-09 11:37:27 --> Severity: Notice --> Undefined index: P_A1Berat C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 579
INFO - 2023-06-09 11:37:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:37:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-09 11:37:27 --> Severity: Notice --> Undefined variable: P_A1GangguanMood C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 825
ERROR - 2023-06-09 11:37:27 --> Severity: Notice --> Undefined variable: P_A1Ringan C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-09 11:37:27 --> Severity: Notice --> Undefined variable: P_A1Sedang C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 827
ERROR - 2023-06-09 11:37:27 --> Severity: Notice --> Undefined variable: P_A1Berat C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 828
INFO - 2023-06-09 11:37:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-09 11:37:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:37:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:37:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:37:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:37:27 --> Final output sent to browser
INFO - 2023-06-09 11:40:02 --> Config Class Initialized
INFO - 2023-06-09 11:40:02 --> Hooks Class Initialized
INFO - 2023-06-09 11:40:02 --> Utf8 Class Initialized
INFO - 2023-06-09 11:40:02 --> URI Class Initialized
INFO - 2023-06-09 11:40:02 --> Router Class Initialized
INFO - 2023-06-09 11:40:02 --> Output Class Initialized
INFO - 2023-06-09 11:40:02 --> Security Class Initialized
INFO - 2023-06-09 11:40:02 --> Input Class Initialized
INFO - 2023-06-09 11:40:02 --> Language Class Initialized
INFO - 2023-06-09 11:40:02 --> Loader Class Initialized
INFO - 2023-06-09 11:40:02 --> Helper loaded: url_helper
INFO - 2023-06-09 11:40:02 --> Helper loaded: form_helper
INFO - 2023-06-09 11:40:02 --> Database Driver Class Initialized
INFO - 2023-06-09 11:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:40:02 --> Form Validation Class Initialized
INFO - 2023-06-09 11:40:02 --> Controller Class Initialized
INFO - 2023-06-09 11:40:02 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:40:02 --> Model "m_penghitungan" initialized
ERROR - 2023-06-09 11:40:02 --> Severity: Notice --> Undefined index: P_A1GangguanMood C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 576
ERROR - 2023-06-09 11:40:02 --> Severity: Notice --> Undefined index: P_A1Ringan C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 577
ERROR - 2023-06-09 11:40:02 --> Severity: Notice --> Undefined index: P_A1Sedang C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 578
ERROR - 2023-06-09 11:40:02 --> Severity: Notice --> Undefined index: P_A1Berat C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 579
INFO - 2023-06-09 11:40:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:40:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-09 11:40:02 --> Severity: Notice --> Undefined variable: P_A1GangguanMood C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 825
ERROR - 2023-06-09 11:40:02 --> Severity: Notice --> Undefined variable: P_A1Ringan C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 826
ERROR - 2023-06-09 11:40:02 --> Severity: Notice --> Undefined variable: P_A1Sedang C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 827
ERROR - 2023-06-09 11:40:02 --> Severity: Notice --> Undefined variable: P_A1Berat C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 828
INFO - 2023-06-09 11:40:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-09 11:40:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:40:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:40:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:40:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:40:02 --> Final output sent to browser
INFO - 2023-06-09 11:40:32 --> Config Class Initialized
INFO - 2023-06-09 11:40:32 --> Hooks Class Initialized
INFO - 2023-06-09 11:40:32 --> Utf8 Class Initialized
INFO - 2023-06-09 11:40:32 --> URI Class Initialized
INFO - 2023-06-09 11:40:32 --> Router Class Initialized
INFO - 2023-06-09 11:40:32 --> Output Class Initialized
INFO - 2023-06-09 11:40:32 --> Security Class Initialized
INFO - 2023-06-09 11:40:32 --> Input Class Initialized
INFO - 2023-06-09 11:40:32 --> Language Class Initialized
INFO - 2023-06-09 11:40:32 --> Loader Class Initialized
INFO - 2023-06-09 11:40:32 --> Helper loaded: url_helper
INFO - 2023-06-09 11:40:32 --> Helper loaded: form_helper
INFO - 2023-06-09 11:40:32 --> Database Driver Class Initialized
INFO - 2023-06-09 11:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:40:32 --> Form Validation Class Initialized
INFO - 2023-06-09 11:40:32 --> Controller Class Initialized
INFO - 2023-06-09 11:40:32 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:40:32 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 11:40:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:40:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:40:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 11:40:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:40:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:40:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:40:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:40:32 --> Final output sent to browser
INFO - 2023-06-09 11:40:34 --> Config Class Initialized
INFO - 2023-06-09 11:40:34 --> Hooks Class Initialized
INFO - 2023-06-09 11:40:34 --> Utf8 Class Initialized
INFO - 2023-06-09 11:40:34 --> URI Class Initialized
INFO - 2023-06-09 11:40:34 --> Router Class Initialized
INFO - 2023-06-09 11:40:34 --> Output Class Initialized
INFO - 2023-06-09 11:40:34 --> Security Class Initialized
INFO - 2023-06-09 11:40:34 --> Input Class Initialized
INFO - 2023-06-09 11:40:34 --> Language Class Initialized
INFO - 2023-06-09 11:40:34 --> Loader Class Initialized
INFO - 2023-06-09 11:40:34 --> Helper loaded: url_helper
INFO - 2023-06-09 11:40:34 --> Helper loaded: form_helper
INFO - 2023-06-09 11:40:34 --> Database Driver Class Initialized
INFO - 2023-06-09 11:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:40:34 --> Form Validation Class Initialized
INFO - 2023-06-09 11:40:34 --> Controller Class Initialized
INFO - 2023-06-09 11:40:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:40:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:40:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-09 11:40:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:40:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:40:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:40:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:40:34 --> Final output sent to browser
INFO - 2023-06-09 11:40:37 --> Config Class Initialized
INFO - 2023-06-09 11:40:37 --> Hooks Class Initialized
INFO - 2023-06-09 11:40:37 --> Utf8 Class Initialized
INFO - 2023-06-09 11:40:37 --> URI Class Initialized
INFO - 2023-06-09 11:40:37 --> Router Class Initialized
INFO - 2023-06-09 11:40:37 --> Output Class Initialized
INFO - 2023-06-09 11:40:37 --> Security Class Initialized
INFO - 2023-06-09 11:40:37 --> Input Class Initialized
INFO - 2023-06-09 11:40:37 --> Language Class Initialized
INFO - 2023-06-09 11:40:37 --> Loader Class Initialized
INFO - 2023-06-09 11:40:37 --> Helper loaded: url_helper
INFO - 2023-06-09 11:40:37 --> Helper loaded: form_helper
INFO - 2023-06-09 11:40:37 --> Database Driver Class Initialized
INFO - 2023-06-09 11:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:40:37 --> Form Validation Class Initialized
INFO - 2023-06-09 11:40:37 --> Controller Class Initialized
INFO - 2023-06-09 11:40:37 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:40:37 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 11:40:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:40:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:40:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 11:40:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:40:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:40:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:40:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:40:37 --> Final output sent to browser
INFO - 2023-06-09 11:43:00 --> Config Class Initialized
INFO - 2023-06-09 11:43:00 --> Hooks Class Initialized
INFO - 2023-06-09 11:43:00 --> Utf8 Class Initialized
INFO - 2023-06-09 11:43:00 --> URI Class Initialized
INFO - 2023-06-09 11:43:00 --> Router Class Initialized
INFO - 2023-06-09 11:43:00 --> Output Class Initialized
INFO - 2023-06-09 11:43:00 --> Security Class Initialized
INFO - 2023-06-09 11:43:00 --> Input Class Initialized
INFO - 2023-06-09 11:43:00 --> Language Class Initialized
INFO - 2023-06-09 11:43:01 --> Loader Class Initialized
INFO - 2023-06-09 11:43:01 --> Helper loaded: url_helper
INFO - 2023-06-09 11:43:01 --> Helper loaded: form_helper
INFO - 2023-06-09 11:43:01 --> Database Driver Class Initialized
INFO - 2023-06-09 11:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:43:01 --> Form Validation Class Initialized
INFO - 2023-06-09 11:43:01 --> Controller Class Initialized
INFO - 2023-06-09 11:43:01 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:43:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 11:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 11:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:43:01 --> Final output sent to browser
INFO - 2023-06-09 11:43:02 --> Config Class Initialized
INFO - 2023-06-09 11:43:02 --> Hooks Class Initialized
INFO - 2023-06-09 11:43:02 --> Utf8 Class Initialized
INFO - 2023-06-09 11:43:02 --> URI Class Initialized
INFO - 2023-06-09 11:43:03 --> Router Class Initialized
INFO - 2023-06-09 11:43:03 --> Output Class Initialized
INFO - 2023-06-09 11:43:03 --> Security Class Initialized
INFO - 2023-06-09 11:43:03 --> Input Class Initialized
INFO - 2023-06-09 11:43:03 --> Language Class Initialized
INFO - 2023-06-09 11:43:03 --> Loader Class Initialized
INFO - 2023-06-09 11:43:03 --> Helper loaded: url_helper
INFO - 2023-06-09 11:43:03 --> Helper loaded: form_helper
INFO - 2023-06-09 11:43:03 --> Database Driver Class Initialized
INFO - 2023-06-09 11:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:43:03 --> Form Validation Class Initialized
INFO - 2023-06-09 11:43:03 --> Controller Class Initialized
INFO - 2023-06-09 11:43:03 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:43:03 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 11:43:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:43:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:43:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-09 11:43:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:43:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:43:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:43:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:43:03 --> Final output sent to browser
INFO - 2023-06-09 11:58:41 --> Config Class Initialized
INFO - 2023-06-09 11:58:41 --> Hooks Class Initialized
INFO - 2023-06-09 11:58:41 --> Utf8 Class Initialized
INFO - 2023-06-09 11:58:41 --> URI Class Initialized
INFO - 2023-06-09 11:58:41 --> Router Class Initialized
INFO - 2023-06-09 11:58:41 --> Output Class Initialized
INFO - 2023-06-09 11:58:41 --> Security Class Initialized
INFO - 2023-06-09 11:58:41 --> Input Class Initialized
INFO - 2023-06-09 11:58:41 --> Language Class Initialized
INFO - 2023-06-09 11:58:41 --> Loader Class Initialized
INFO - 2023-06-09 11:58:41 --> Helper loaded: url_helper
INFO - 2023-06-09 11:58:41 --> Helper loaded: form_helper
INFO - 2023-06-09 11:58:41 --> Database Driver Class Initialized
INFO - 2023-06-09 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:58:41 --> Form Validation Class Initialized
INFO - 2023-06-09 11:58:41 --> Controller Class Initialized
INFO - 2023-06-09 11:58:41 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:58:41 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 11:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 11:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 11:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 11:58:41 --> Final output sent to browser
INFO - 2023-06-09 11:58:55 --> Config Class Initialized
INFO - 2023-06-09 11:58:55 --> Hooks Class Initialized
INFO - 2023-06-09 11:58:55 --> Utf8 Class Initialized
INFO - 2023-06-09 11:58:55 --> URI Class Initialized
INFO - 2023-06-09 11:58:55 --> Router Class Initialized
INFO - 2023-06-09 11:58:55 --> Output Class Initialized
INFO - 2023-06-09 11:58:55 --> Security Class Initialized
INFO - 2023-06-09 11:58:55 --> Input Class Initialized
INFO - 2023-06-09 11:58:55 --> Language Class Initialized
INFO - 2023-06-09 11:58:55 --> Loader Class Initialized
INFO - 2023-06-09 11:58:55 --> Helper loaded: url_helper
INFO - 2023-06-09 11:58:55 --> Helper loaded: form_helper
INFO - 2023-06-09 11:58:55 --> Database Driver Class Initialized
INFO - 2023-06-09 11:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 11:58:55 --> Form Validation Class Initialized
INFO - 2023-06-09 11:58:55 --> Controller Class Initialized
INFO - 2023-06-09 11:58:56 --> Model "m_datatest" initialized
INFO - 2023-06-09 11:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 11:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 11:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 11:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 11:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 11:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 11:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 11:58:56 --> Final output sent to browser
INFO - 2023-06-09 12:12:22 --> Config Class Initialized
INFO - 2023-06-09 12:12:22 --> Hooks Class Initialized
INFO - 2023-06-09 12:12:22 --> Utf8 Class Initialized
INFO - 2023-06-09 12:12:22 --> URI Class Initialized
INFO - 2023-06-09 12:12:22 --> Router Class Initialized
INFO - 2023-06-09 12:12:22 --> Output Class Initialized
INFO - 2023-06-09 12:12:22 --> Security Class Initialized
INFO - 2023-06-09 12:12:22 --> Input Class Initialized
INFO - 2023-06-09 12:12:22 --> Language Class Initialized
INFO - 2023-06-09 12:12:22 --> Loader Class Initialized
INFO - 2023-06-09 12:12:22 --> Helper loaded: url_helper
INFO - 2023-06-09 12:12:22 --> Helper loaded: form_helper
INFO - 2023-06-09 12:12:22 --> Database Driver Class Initialized
INFO - 2023-06-09 12:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:12:22 --> Form Validation Class Initialized
INFO - 2023-06-09 12:12:22 --> Controller Class Initialized
INFO - 2023-06-09 12:12:22 --> Model "m_datatest" initialized
ERROR - 2023-06-09 12:12:22 --> Severity: Notice --> Undefined variable: countAll C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 35
INFO - 2023-06-09 12:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 12:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 12:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 12:12:22 --> Final output sent to browser
INFO - 2023-06-09 12:13:03 --> Config Class Initialized
INFO - 2023-06-09 12:13:03 --> Hooks Class Initialized
INFO - 2023-06-09 12:13:03 --> Utf8 Class Initialized
INFO - 2023-06-09 12:13:03 --> URI Class Initialized
INFO - 2023-06-09 12:13:03 --> Router Class Initialized
INFO - 2023-06-09 12:13:03 --> Output Class Initialized
INFO - 2023-06-09 12:13:03 --> Security Class Initialized
INFO - 2023-06-09 12:13:03 --> Input Class Initialized
INFO - 2023-06-09 12:13:03 --> Language Class Initialized
INFO - 2023-06-09 12:13:03 --> Loader Class Initialized
INFO - 2023-06-09 12:13:03 --> Helper loaded: url_helper
INFO - 2023-06-09 12:13:03 --> Helper loaded: form_helper
INFO - 2023-06-09 12:13:03 --> Database Driver Class Initialized
INFO - 2023-06-09 12:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:13:03 --> Form Validation Class Initialized
INFO - 2023-06-09 12:13:03 --> Controller Class Initialized
INFO - 2023-06-09 12:13:03 --> Model "m_datatest" initialized
ERROR - 2023-06-09 12:13:03 --> Severity: Notice --> Undefined variable: countAll C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 35
INFO - 2023-06-09 12:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 12:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 12:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:13:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 12:13:03 --> Final output sent to browser
INFO - 2023-06-09 12:13:31 --> Config Class Initialized
INFO - 2023-06-09 12:13:31 --> Hooks Class Initialized
INFO - 2023-06-09 12:13:31 --> Utf8 Class Initialized
INFO - 2023-06-09 12:13:31 --> URI Class Initialized
INFO - 2023-06-09 12:13:31 --> Router Class Initialized
INFO - 2023-06-09 12:13:31 --> Output Class Initialized
INFO - 2023-06-09 12:13:31 --> Security Class Initialized
INFO - 2023-06-09 12:13:31 --> Input Class Initialized
INFO - 2023-06-09 12:13:31 --> Language Class Initialized
INFO - 2023-06-09 12:13:31 --> Loader Class Initialized
INFO - 2023-06-09 12:13:31 --> Helper loaded: url_helper
INFO - 2023-06-09 12:13:31 --> Helper loaded: form_helper
INFO - 2023-06-09 12:13:31 --> Database Driver Class Initialized
INFO - 2023-06-09 12:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:13:31 --> Form Validation Class Initialized
INFO - 2023-06-09 12:13:31 --> Controller Class Initialized
INFO - 2023-06-09 12:13:31 --> Model "m_datatest" initialized
INFO - 2023-06-09 12:13:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:13:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:13:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 12:13:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 12:13:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:13:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:13:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 12:13:31 --> Final output sent to browser
INFO - 2023-06-09 12:15:41 --> Config Class Initialized
INFO - 2023-06-09 12:15:41 --> Hooks Class Initialized
INFO - 2023-06-09 12:15:41 --> Utf8 Class Initialized
INFO - 2023-06-09 12:15:41 --> URI Class Initialized
INFO - 2023-06-09 12:15:41 --> Router Class Initialized
INFO - 2023-06-09 12:15:41 --> Output Class Initialized
INFO - 2023-06-09 12:15:41 --> Security Class Initialized
INFO - 2023-06-09 12:15:41 --> Input Class Initialized
INFO - 2023-06-09 12:15:41 --> Language Class Initialized
INFO - 2023-06-09 12:15:41 --> Loader Class Initialized
INFO - 2023-06-09 12:15:41 --> Helper loaded: url_helper
INFO - 2023-06-09 12:15:41 --> Helper loaded: form_helper
INFO - 2023-06-09 12:15:41 --> Database Driver Class Initialized
INFO - 2023-06-09 12:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:15:41 --> Form Validation Class Initialized
INFO - 2023-06-09 12:15:41 --> Controller Class Initialized
INFO - 2023-06-09 12:15:41 --> Model "m_datatest" initialized
INFO - 2023-06-09 12:15:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:15:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:15:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 12:15:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 12:15:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:15:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:15:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 12:15:41 --> Final output sent to browser
INFO - 2023-06-09 12:22:15 --> Config Class Initialized
INFO - 2023-06-09 12:22:15 --> Hooks Class Initialized
INFO - 2023-06-09 12:22:15 --> Utf8 Class Initialized
INFO - 2023-06-09 12:22:15 --> URI Class Initialized
INFO - 2023-06-09 12:22:15 --> Router Class Initialized
INFO - 2023-06-09 12:22:15 --> Output Class Initialized
INFO - 2023-06-09 12:22:15 --> Security Class Initialized
INFO - 2023-06-09 12:22:15 --> Input Class Initialized
INFO - 2023-06-09 12:22:15 --> Language Class Initialized
INFO - 2023-06-09 12:22:15 --> Loader Class Initialized
INFO - 2023-06-09 12:22:15 --> Helper loaded: url_helper
INFO - 2023-06-09 12:22:15 --> Helper loaded: form_helper
INFO - 2023-06-09 12:22:15 --> Database Driver Class Initialized
INFO - 2023-06-09 12:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:22:15 --> Form Validation Class Initialized
INFO - 2023-06-09 12:22:15 --> Controller Class Initialized
INFO - 2023-06-09 12:22:15 --> Model "m_datatest" initialized
INFO - 2023-06-09 12:22:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:22:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:22:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 12:22:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 12:22:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:22:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:22:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 12:22:15 --> Final output sent to browser
INFO - 2023-06-09 12:22:40 --> Config Class Initialized
INFO - 2023-06-09 12:22:40 --> Hooks Class Initialized
INFO - 2023-06-09 12:22:40 --> Utf8 Class Initialized
INFO - 2023-06-09 12:22:40 --> URI Class Initialized
INFO - 2023-06-09 12:22:40 --> Router Class Initialized
INFO - 2023-06-09 12:22:40 --> Output Class Initialized
INFO - 2023-06-09 12:22:40 --> Security Class Initialized
INFO - 2023-06-09 12:22:40 --> Input Class Initialized
INFO - 2023-06-09 12:22:40 --> Language Class Initialized
INFO - 2023-06-09 12:22:40 --> Loader Class Initialized
INFO - 2023-06-09 12:22:40 --> Helper loaded: url_helper
INFO - 2023-06-09 12:22:40 --> Helper loaded: form_helper
INFO - 2023-06-09 12:22:40 --> Database Driver Class Initialized
INFO - 2023-06-09 12:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:22:40 --> Form Validation Class Initialized
INFO - 2023-06-09 12:22:40 --> Controller Class Initialized
INFO - 2023-06-09 12:22:40 --> Model "m_datatest" initialized
INFO - 2023-06-09 12:22:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:22:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:22:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 12:22:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 12:22:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:22:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:22:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 12:22:40 --> Final output sent to browser
INFO - 2023-06-09 12:33:22 --> Config Class Initialized
INFO - 2023-06-09 12:33:22 --> Hooks Class Initialized
INFO - 2023-06-09 12:33:22 --> Utf8 Class Initialized
INFO - 2023-06-09 12:33:22 --> URI Class Initialized
INFO - 2023-06-09 12:33:22 --> Router Class Initialized
INFO - 2023-06-09 12:33:22 --> Output Class Initialized
INFO - 2023-06-09 12:33:22 --> Security Class Initialized
INFO - 2023-06-09 12:33:22 --> Input Class Initialized
INFO - 2023-06-09 12:33:22 --> Language Class Initialized
INFO - 2023-06-09 12:33:22 --> Loader Class Initialized
INFO - 2023-06-09 12:33:22 --> Helper loaded: url_helper
INFO - 2023-06-09 12:33:22 --> Helper loaded: form_helper
INFO - 2023-06-09 12:33:22 --> Database Driver Class Initialized
INFO - 2023-06-09 12:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:33:22 --> Form Validation Class Initialized
INFO - 2023-06-09 12:33:22 --> Controller Class Initialized
INFO - 2023-06-09 12:33:22 --> Model "m_datatest" initialized
INFO - 2023-06-09 12:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 12:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 12:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 12:33:22 --> Final output sent to browser
INFO - 2023-06-09 12:34:14 --> Config Class Initialized
INFO - 2023-06-09 12:34:14 --> Hooks Class Initialized
INFO - 2023-06-09 12:34:14 --> Utf8 Class Initialized
INFO - 2023-06-09 12:34:14 --> URI Class Initialized
INFO - 2023-06-09 12:34:14 --> Router Class Initialized
INFO - 2023-06-09 12:34:14 --> Output Class Initialized
INFO - 2023-06-09 12:34:14 --> Security Class Initialized
INFO - 2023-06-09 12:34:14 --> Input Class Initialized
INFO - 2023-06-09 12:34:14 --> Language Class Initialized
INFO - 2023-06-09 12:34:14 --> Loader Class Initialized
INFO - 2023-06-09 12:34:14 --> Helper loaded: url_helper
INFO - 2023-06-09 12:34:14 --> Helper loaded: form_helper
INFO - 2023-06-09 12:34:14 --> Database Driver Class Initialized
INFO - 2023-06-09 12:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:34:14 --> Form Validation Class Initialized
INFO - 2023-06-09 12:34:14 --> Controller Class Initialized
INFO - 2023-06-09 12:34:14 --> Model "m_datatest" initialized
INFO - 2023-06-09 12:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 12:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 12:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 12:34:14 --> Final output sent to browser
INFO - 2023-06-09 12:37:57 --> Config Class Initialized
INFO - 2023-06-09 12:37:57 --> Hooks Class Initialized
INFO - 2023-06-09 12:37:57 --> Utf8 Class Initialized
INFO - 2023-06-09 12:37:57 --> URI Class Initialized
INFO - 2023-06-09 12:37:57 --> Router Class Initialized
INFO - 2023-06-09 12:37:57 --> Output Class Initialized
INFO - 2023-06-09 12:37:57 --> Security Class Initialized
INFO - 2023-06-09 12:37:57 --> Input Class Initialized
INFO - 2023-06-09 12:37:57 --> Language Class Initialized
INFO - 2023-06-09 12:37:57 --> Loader Class Initialized
INFO - 2023-06-09 12:37:57 --> Helper loaded: url_helper
INFO - 2023-06-09 12:37:57 --> Helper loaded: form_helper
INFO - 2023-06-09 12:37:57 --> Database Driver Class Initialized
INFO - 2023-06-09 12:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:37:57 --> Form Validation Class Initialized
INFO - 2023-06-09 12:37:57 --> Controller Class Initialized
INFO - 2023-06-09 12:37:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-09 12:37:57 --> Final output sent to browser
INFO - 2023-06-09 12:38:08 --> Config Class Initialized
INFO - 2023-06-09 12:38:08 --> Hooks Class Initialized
INFO - 2023-06-09 12:38:08 --> Utf8 Class Initialized
INFO - 2023-06-09 12:38:08 --> URI Class Initialized
INFO - 2023-06-09 12:38:08 --> Router Class Initialized
INFO - 2023-06-09 12:38:08 --> Output Class Initialized
INFO - 2023-06-09 12:38:08 --> Security Class Initialized
INFO - 2023-06-09 12:38:08 --> Input Class Initialized
INFO - 2023-06-09 12:38:08 --> Language Class Initialized
INFO - 2023-06-09 12:38:08 --> Loader Class Initialized
INFO - 2023-06-09 12:38:08 --> Helper loaded: url_helper
INFO - 2023-06-09 12:38:08 --> Helper loaded: form_helper
INFO - 2023-06-09 12:38:08 --> Database Driver Class Initialized
INFO - 2023-06-09 12:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:38:08 --> Form Validation Class Initialized
INFO - 2023-06-09 12:38:09 --> Controller Class Initialized
INFO - 2023-06-09 12:38:09 --> Model "m_user" initialized
INFO - 2023-06-09 12:38:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-09 12:38:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-09 12:38:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-09 12:38:09 --> Final output sent to browser
INFO - 2023-06-09 12:38:12 --> Config Class Initialized
INFO - 2023-06-09 12:38:12 --> Hooks Class Initialized
INFO - 2023-06-09 12:38:12 --> Utf8 Class Initialized
INFO - 2023-06-09 12:38:12 --> URI Class Initialized
INFO - 2023-06-09 12:38:12 --> Router Class Initialized
INFO - 2023-06-09 12:38:12 --> Output Class Initialized
INFO - 2023-06-09 12:38:12 --> Security Class Initialized
INFO - 2023-06-09 12:38:12 --> Input Class Initialized
INFO - 2023-06-09 12:38:12 --> Language Class Initialized
INFO - 2023-06-09 12:38:12 --> Loader Class Initialized
INFO - 2023-06-09 12:38:12 --> Helper loaded: url_helper
INFO - 2023-06-09 12:38:12 --> Helper loaded: form_helper
INFO - 2023-06-09 12:38:12 --> Database Driver Class Initialized
INFO - 2023-06-09 12:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:38:12 --> Form Validation Class Initialized
INFO - 2023-06-09 12:38:12 --> Controller Class Initialized
INFO - 2023-06-09 12:38:12 --> Model "m_user" initialized
INFO - 2023-06-09 12:38:12 --> Config Class Initialized
INFO - 2023-06-09 12:38:12 --> Hooks Class Initialized
INFO - 2023-06-09 12:38:12 --> Utf8 Class Initialized
INFO - 2023-06-09 12:38:12 --> URI Class Initialized
INFO - 2023-06-09 12:38:12 --> Router Class Initialized
INFO - 2023-06-09 12:38:12 --> Output Class Initialized
INFO - 2023-06-09 12:38:12 --> Security Class Initialized
INFO - 2023-06-09 12:38:12 --> Input Class Initialized
INFO - 2023-06-09 12:38:12 --> Language Class Initialized
INFO - 2023-06-09 12:38:12 --> Loader Class Initialized
INFO - 2023-06-09 12:38:12 --> Helper loaded: url_helper
INFO - 2023-06-09 12:38:12 --> Helper loaded: form_helper
INFO - 2023-06-09 12:38:12 --> Database Driver Class Initialized
INFO - 2023-06-09 12:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:38:12 --> Form Validation Class Initialized
INFO - 2023-06-09 12:38:12 --> Controller Class Initialized
INFO - 2023-06-09 12:38:12 --> Model "m_user" initialized
INFO - 2023-06-09 12:38:12 --> Model "m_datatrain" initialized
INFO - 2023-06-09 12:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 12:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:38:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-09 12:38:12 --> Final output sent to browser
INFO - 2023-06-09 12:38:15 --> Config Class Initialized
INFO - 2023-06-09 12:38:15 --> Hooks Class Initialized
INFO - 2023-06-09 12:38:15 --> Utf8 Class Initialized
INFO - 2023-06-09 12:38:15 --> URI Class Initialized
INFO - 2023-06-09 12:38:15 --> Router Class Initialized
INFO - 2023-06-09 12:38:15 --> Output Class Initialized
INFO - 2023-06-09 12:38:15 --> Security Class Initialized
INFO - 2023-06-09 12:38:15 --> Input Class Initialized
INFO - 2023-06-09 12:38:15 --> Language Class Initialized
INFO - 2023-06-09 12:38:15 --> Loader Class Initialized
INFO - 2023-06-09 12:38:15 --> Helper loaded: url_helper
INFO - 2023-06-09 12:38:15 --> Helper loaded: form_helper
INFO - 2023-06-09 12:38:15 --> Database Driver Class Initialized
INFO - 2023-06-09 12:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:38:15 --> Form Validation Class Initialized
INFO - 2023-06-09 12:38:15 --> Controller Class Initialized
INFO - 2023-06-09 12:38:15 --> Model "m_datatest" initialized
INFO - 2023-06-09 12:38:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 12:38:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:38:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:38:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 12:38:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 12:38:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:38:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:38:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 12:38:15 --> Final output sent to browser
INFO - 2023-06-09 12:38:18 --> Config Class Initialized
INFO - 2023-06-09 12:38:18 --> Hooks Class Initialized
INFO - 2023-06-09 12:38:18 --> Utf8 Class Initialized
INFO - 2023-06-09 12:38:18 --> URI Class Initialized
INFO - 2023-06-09 12:38:18 --> Router Class Initialized
INFO - 2023-06-09 12:38:18 --> Output Class Initialized
INFO - 2023-06-09 12:38:18 --> Security Class Initialized
INFO - 2023-06-09 12:38:18 --> Input Class Initialized
INFO - 2023-06-09 12:38:18 --> Language Class Initialized
INFO - 2023-06-09 12:38:18 --> Loader Class Initialized
INFO - 2023-06-09 12:38:18 --> Helper loaded: url_helper
INFO - 2023-06-09 12:38:18 --> Helper loaded: form_helper
INFO - 2023-06-09 12:38:18 --> Database Driver Class Initialized
INFO - 2023-06-09 12:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:38:18 --> Form Validation Class Initialized
INFO - 2023-06-09 12:38:18 --> Controller Class Initialized
INFO - 2023-06-09 12:38:18 --> Model "m_datatest" initialized
INFO - 2023-06-09 12:38:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 12:38:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:38:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:38:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-09 12:38:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 12:38:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:38:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:38:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 12:38:18 --> Final output sent to browser
INFO - 2023-06-09 12:45:13 --> Config Class Initialized
INFO - 2023-06-09 12:45:13 --> Hooks Class Initialized
INFO - 2023-06-09 12:45:13 --> Utf8 Class Initialized
INFO - 2023-06-09 12:45:13 --> URI Class Initialized
INFO - 2023-06-09 12:45:13 --> Router Class Initialized
INFO - 2023-06-09 12:45:13 --> Output Class Initialized
INFO - 2023-06-09 12:45:13 --> Security Class Initialized
INFO - 2023-06-09 12:45:13 --> Input Class Initialized
INFO - 2023-06-09 12:45:13 --> Language Class Initialized
INFO - 2023-06-09 12:45:13 --> Loader Class Initialized
INFO - 2023-06-09 12:45:13 --> Helper loaded: url_helper
INFO - 2023-06-09 12:45:13 --> Helper loaded: form_helper
INFO - 2023-06-09 12:45:13 --> Database Driver Class Initialized
INFO - 2023-06-09 12:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:45:13 --> Form Validation Class Initialized
INFO - 2023-06-09 12:45:13 --> Controller Class Initialized
INFO - 2023-06-09 12:45:13 --> Model "m_datatest" initialized
INFO - 2023-06-09 12:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 12:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 12:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 12:45:13 --> Final output sent to browser
INFO - 2023-06-09 12:49:59 --> Config Class Initialized
INFO - 2023-06-09 12:49:59 --> Hooks Class Initialized
INFO - 2023-06-09 12:49:59 --> Utf8 Class Initialized
INFO - 2023-06-09 12:49:59 --> URI Class Initialized
INFO - 2023-06-09 12:49:59 --> Router Class Initialized
INFO - 2023-06-09 12:49:59 --> Output Class Initialized
INFO - 2023-06-09 12:49:59 --> Security Class Initialized
INFO - 2023-06-09 12:49:59 --> Input Class Initialized
INFO - 2023-06-09 12:49:59 --> Language Class Initialized
INFO - 2023-06-09 12:49:59 --> Loader Class Initialized
INFO - 2023-06-09 12:49:59 --> Helper loaded: url_helper
INFO - 2023-06-09 12:49:59 --> Helper loaded: form_helper
INFO - 2023-06-09 12:49:59 --> Database Driver Class Initialized
INFO - 2023-06-09 12:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:49:59 --> Form Validation Class Initialized
INFO - 2023-06-09 12:49:59 --> Controller Class Initialized
INFO - 2023-06-09 12:49:59 --> Model "m_datatest" initialized
ERROR - 2023-06-09 12:49:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 82
ERROR - 2023-06-09 12:49:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
INFO - 2023-06-09 12:49:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:49:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:49:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 12:49:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 12:49:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:49:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:49:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 12:49:59 --> Final output sent to browser
INFO - 2023-06-09 12:50:15 --> Config Class Initialized
INFO - 2023-06-09 12:50:15 --> Hooks Class Initialized
INFO - 2023-06-09 12:50:15 --> Utf8 Class Initialized
INFO - 2023-06-09 12:50:15 --> URI Class Initialized
INFO - 2023-06-09 12:50:15 --> Router Class Initialized
INFO - 2023-06-09 12:50:15 --> Output Class Initialized
INFO - 2023-06-09 12:50:15 --> Security Class Initialized
INFO - 2023-06-09 12:50:15 --> Input Class Initialized
INFO - 2023-06-09 12:50:15 --> Language Class Initialized
INFO - 2023-06-09 12:50:15 --> Loader Class Initialized
INFO - 2023-06-09 12:50:15 --> Helper loaded: url_helper
INFO - 2023-06-09 12:50:15 --> Helper loaded: form_helper
INFO - 2023-06-09 12:50:15 --> Database Driver Class Initialized
INFO - 2023-06-09 12:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 12:50:15 --> Form Validation Class Initialized
INFO - 2023-06-09 12:50:15 --> Controller Class Initialized
INFO - 2023-06-09 12:50:15 --> Model "m_datatest" initialized
ERROR - 2023-06-09 12:50:15 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 82
ERROR - 2023-06-09 12:50:15 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
INFO - 2023-06-09 12:50:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 12:50:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 12:50:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 12:50:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 12:50:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 12:50:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 12:50:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 12:50:15 --> Final output sent to browser
INFO - 2023-06-09 13:08:36 --> Config Class Initialized
INFO - 2023-06-09 13:08:36 --> Hooks Class Initialized
INFO - 2023-06-09 13:08:36 --> Utf8 Class Initialized
INFO - 2023-06-09 13:08:36 --> URI Class Initialized
INFO - 2023-06-09 13:08:36 --> Router Class Initialized
INFO - 2023-06-09 13:08:36 --> Output Class Initialized
INFO - 2023-06-09 13:08:36 --> Security Class Initialized
INFO - 2023-06-09 13:08:36 --> Input Class Initialized
INFO - 2023-06-09 13:08:36 --> Language Class Initialized
INFO - 2023-06-09 13:08:36 --> Loader Class Initialized
INFO - 2023-06-09 13:08:36 --> Helper loaded: url_helper
INFO - 2023-06-09 13:08:36 --> Helper loaded: form_helper
INFO - 2023-06-09 13:08:36 --> Database Driver Class Initialized
INFO - 2023-06-09 13:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:08:36 --> Form Validation Class Initialized
INFO - 2023-06-09 13:08:36 --> Controller Class Initialized
INFO - 2023-06-09 13:08:36 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:08:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:08:36 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:08:36 --> Model "M_solusi" initialized
INFO - 2023-06-09 13:08:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:08:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:08:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-09 13:08:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:08:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:08:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:08:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:08:36 --> Final output sent to browser
INFO - 2023-06-09 13:10:07 --> Config Class Initialized
INFO - 2023-06-09 13:10:07 --> Hooks Class Initialized
INFO - 2023-06-09 13:10:07 --> Utf8 Class Initialized
INFO - 2023-06-09 13:10:07 --> URI Class Initialized
INFO - 2023-06-09 13:10:07 --> Router Class Initialized
INFO - 2023-06-09 13:10:07 --> Output Class Initialized
INFO - 2023-06-09 13:10:07 --> Security Class Initialized
INFO - 2023-06-09 13:10:07 --> Input Class Initialized
INFO - 2023-06-09 13:10:07 --> Language Class Initialized
INFO - 2023-06-09 13:10:07 --> Loader Class Initialized
INFO - 2023-06-09 13:10:07 --> Helper loaded: url_helper
INFO - 2023-06-09 13:10:07 --> Helper loaded: form_helper
INFO - 2023-06-09 13:10:07 --> Database Driver Class Initialized
INFO - 2023-06-09 13:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:10:07 --> Form Validation Class Initialized
INFO - 2023-06-09 13:10:07 --> Controller Class Initialized
INFO - 2023-06-09 13:10:07 --> Model "m_user" initialized
INFO - 2023-06-09 13:10:07 --> Config Class Initialized
INFO - 2023-06-09 13:10:07 --> Hooks Class Initialized
INFO - 2023-06-09 13:10:07 --> Utf8 Class Initialized
INFO - 2023-06-09 13:10:07 --> URI Class Initialized
INFO - 2023-06-09 13:10:07 --> Router Class Initialized
INFO - 2023-06-09 13:10:07 --> Output Class Initialized
INFO - 2023-06-09 13:10:07 --> Security Class Initialized
INFO - 2023-06-09 13:10:07 --> Input Class Initialized
INFO - 2023-06-09 13:10:07 --> Language Class Initialized
INFO - 2023-06-09 13:10:07 --> Loader Class Initialized
INFO - 2023-06-09 13:10:07 --> Helper loaded: url_helper
INFO - 2023-06-09 13:10:07 --> Helper loaded: form_helper
INFO - 2023-06-09 13:10:07 --> Database Driver Class Initialized
INFO - 2023-06-09 13:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:10:07 --> Form Validation Class Initialized
INFO - 2023-06-09 13:10:07 --> Controller Class Initialized
INFO - 2023-06-09 13:10:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-09 13:10:07 --> Final output sent to browser
INFO - 2023-06-09 13:10:09 --> Config Class Initialized
INFO - 2023-06-09 13:10:09 --> Hooks Class Initialized
INFO - 2023-06-09 13:10:09 --> Utf8 Class Initialized
INFO - 2023-06-09 13:10:09 --> URI Class Initialized
INFO - 2023-06-09 13:10:09 --> Router Class Initialized
INFO - 2023-06-09 13:10:09 --> Output Class Initialized
INFO - 2023-06-09 13:10:09 --> Security Class Initialized
INFO - 2023-06-09 13:10:09 --> Input Class Initialized
INFO - 2023-06-09 13:10:09 --> Language Class Initialized
INFO - 2023-06-09 13:10:09 --> Loader Class Initialized
INFO - 2023-06-09 13:10:09 --> Helper loaded: url_helper
INFO - 2023-06-09 13:10:09 --> Helper loaded: form_helper
INFO - 2023-06-09 13:10:09 --> Database Driver Class Initialized
INFO - 2023-06-09 13:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:10:09 --> Form Validation Class Initialized
INFO - 2023-06-09 13:10:09 --> Controller Class Initialized
INFO - 2023-06-09 13:10:09 --> Model "m_user" initialized
INFO - 2023-06-09 13:10:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-09 13:10:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-09 13:10:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-09 13:10:09 --> Final output sent to browser
INFO - 2023-06-09 13:10:13 --> Config Class Initialized
INFO - 2023-06-09 13:10:13 --> Hooks Class Initialized
INFO - 2023-06-09 13:10:13 --> Utf8 Class Initialized
INFO - 2023-06-09 13:10:13 --> URI Class Initialized
INFO - 2023-06-09 13:10:13 --> Router Class Initialized
INFO - 2023-06-09 13:10:13 --> Output Class Initialized
INFO - 2023-06-09 13:10:13 --> Security Class Initialized
INFO - 2023-06-09 13:10:13 --> Input Class Initialized
INFO - 2023-06-09 13:10:13 --> Language Class Initialized
INFO - 2023-06-09 13:10:13 --> Loader Class Initialized
INFO - 2023-06-09 13:10:13 --> Helper loaded: url_helper
INFO - 2023-06-09 13:10:13 --> Helper loaded: form_helper
INFO - 2023-06-09 13:10:13 --> Database Driver Class Initialized
INFO - 2023-06-09 13:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:10:13 --> Form Validation Class Initialized
INFO - 2023-06-09 13:10:13 --> Controller Class Initialized
INFO - 2023-06-09 13:10:13 --> Model "m_user" initialized
INFO - 2023-06-09 13:10:13 --> Config Class Initialized
INFO - 2023-06-09 13:10:13 --> Hooks Class Initialized
INFO - 2023-06-09 13:10:14 --> Utf8 Class Initialized
INFO - 2023-06-09 13:10:14 --> URI Class Initialized
INFO - 2023-06-09 13:10:14 --> Router Class Initialized
INFO - 2023-06-09 13:10:14 --> Output Class Initialized
INFO - 2023-06-09 13:10:14 --> Security Class Initialized
INFO - 2023-06-09 13:10:14 --> Input Class Initialized
INFO - 2023-06-09 13:10:14 --> Language Class Initialized
INFO - 2023-06-09 13:10:14 --> Loader Class Initialized
INFO - 2023-06-09 13:10:14 --> Helper loaded: url_helper
INFO - 2023-06-09 13:10:14 --> Helper loaded: form_helper
INFO - 2023-06-09 13:10:14 --> Database Driver Class Initialized
INFO - 2023-06-09 13:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:10:14 --> Form Validation Class Initialized
INFO - 2023-06-09 13:10:14 --> Controller Class Initialized
INFO - 2023-06-09 13:10:14 --> Model "m_user" initialized
INFO - 2023-06-09 13:10:14 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:10:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:10:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:10:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:10:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:10:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:10:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-09 13:10:14 --> Final output sent to browser
INFO - 2023-06-09 13:10:16 --> Config Class Initialized
INFO - 2023-06-09 13:10:16 --> Hooks Class Initialized
INFO - 2023-06-09 13:10:16 --> Utf8 Class Initialized
INFO - 2023-06-09 13:10:16 --> URI Class Initialized
INFO - 2023-06-09 13:10:16 --> Router Class Initialized
INFO - 2023-06-09 13:10:16 --> Output Class Initialized
INFO - 2023-06-09 13:10:16 --> Security Class Initialized
INFO - 2023-06-09 13:10:16 --> Input Class Initialized
INFO - 2023-06-09 13:10:16 --> Language Class Initialized
INFO - 2023-06-09 13:10:16 --> Loader Class Initialized
INFO - 2023-06-09 13:10:16 --> Helper loaded: url_helper
INFO - 2023-06-09 13:10:16 --> Helper loaded: form_helper
INFO - 2023-06-09 13:10:16 --> Database Driver Class Initialized
INFO - 2023-06-09 13:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:10:16 --> Form Validation Class Initialized
INFO - 2023-06-09 13:10:16 --> Controller Class Initialized
INFO - 2023-06-09 13:10:16 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:10:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:10:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:10:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:10:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 13:10:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:10:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:10:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:10:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:10:16 --> Final output sent to browser
INFO - 2023-06-09 13:16:40 --> Config Class Initialized
INFO - 2023-06-09 13:16:40 --> Hooks Class Initialized
INFO - 2023-06-09 13:16:40 --> Utf8 Class Initialized
INFO - 2023-06-09 13:16:40 --> URI Class Initialized
INFO - 2023-06-09 13:16:40 --> Router Class Initialized
INFO - 2023-06-09 13:16:40 --> Output Class Initialized
INFO - 2023-06-09 13:16:40 --> Security Class Initialized
INFO - 2023-06-09 13:16:40 --> Input Class Initialized
INFO - 2023-06-09 13:16:40 --> Language Class Initialized
INFO - 2023-06-09 13:16:40 --> Loader Class Initialized
INFO - 2023-06-09 13:16:40 --> Helper loaded: url_helper
INFO - 2023-06-09 13:16:40 --> Helper loaded: form_helper
INFO - 2023-06-09 13:16:40 --> Database Driver Class Initialized
INFO - 2023-06-09 13:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:16:40 --> Form Validation Class Initialized
INFO - 2023-06-09 13:16:40 --> Controller Class Initialized
INFO - 2023-06-09 13:16:40 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:16:40 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:16:40 --> Config Class Initialized
INFO - 2023-06-09 13:16:40 --> Hooks Class Initialized
INFO - 2023-06-09 13:16:40 --> Utf8 Class Initialized
INFO - 2023-06-09 13:16:40 --> URI Class Initialized
INFO - 2023-06-09 13:16:40 --> Router Class Initialized
INFO - 2023-06-09 13:16:40 --> Output Class Initialized
INFO - 2023-06-09 13:16:40 --> Security Class Initialized
INFO - 2023-06-09 13:16:40 --> Input Class Initialized
INFO - 2023-06-09 13:16:40 --> Language Class Initialized
INFO - 2023-06-09 13:16:40 --> Loader Class Initialized
INFO - 2023-06-09 13:16:40 --> Helper loaded: url_helper
INFO - 2023-06-09 13:16:40 --> Helper loaded: form_helper
INFO - 2023-06-09 13:16:40 --> Database Driver Class Initialized
INFO - 2023-06-09 13:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:16:40 --> Form Validation Class Initialized
INFO - 2023-06-09 13:16:40 --> Controller Class Initialized
INFO - 2023-06-09 13:16:40 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:16:40 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 13:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:16:40 --> Final output sent to browser
INFO - 2023-06-09 13:16:42 --> Config Class Initialized
INFO - 2023-06-09 13:16:42 --> Hooks Class Initialized
INFO - 2023-06-09 13:16:42 --> Utf8 Class Initialized
INFO - 2023-06-09 13:16:42 --> URI Class Initialized
INFO - 2023-06-09 13:16:42 --> Router Class Initialized
INFO - 2023-06-09 13:16:42 --> Output Class Initialized
INFO - 2023-06-09 13:16:42 --> Security Class Initialized
INFO - 2023-06-09 13:16:42 --> Input Class Initialized
INFO - 2023-06-09 13:16:42 --> Language Class Initialized
INFO - 2023-06-09 13:16:42 --> Loader Class Initialized
INFO - 2023-06-09 13:16:42 --> Helper loaded: url_helper
INFO - 2023-06-09 13:16:42 --> Helper loaded: form_helper
INFO - 2023-06-09 13:16:42 --> Database Driver Class Initialized
INFO - 2023-06-09 13:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:16:42 --> Form Validation Class Initialized
INFO - 2023-06-09 13:16:42 --> Controller Class Initialized
INFO - 2023-06-09 13:16:42 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:16:42 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:16:42 --> Config Class Initialized
INFO - 2023-06-09 13:16:42 --> Hooks Class Initialized
INFO - 2023-06-09 13:16:42 --> Utf8 Class Initialized
INFO - 2023-06-09 13:16:42 --> URI Class Initialized
INFO - 2023-06-09 13:16:42 --> Router Class Initialized
INFO - 2023-06-09 13:16:42 --> Output Class Initialized
INFO - 2023-06-09 13:16:42 --> Security Class Initialized
INFO - 2023-06-09 13:16:42 --> Input Class Initialized
INFO - 2023-06-09 13:16:42 --> Language Class Initialized
INFO - 2023-06-09 13:16:42 --> Loader Class Initialized
INFO - 2023-06-09 13:16:42 --> Helper loaded: url_helper
INFO - 2023-06-09 13:16:42 --> Helper loaded: form_helper
INFO - 2023-06-09 13:16:42 --> Database Driver Class Initialized
INFO - 2023-06-09 13:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:16:42 --> Form Validation Class Initialized
INFO - 2023-06-09 13:16:42 --> Controller Class Initialized
INFO - 2023-06-09 13:16:42 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:16:42 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 13:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:16:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:16:42 --> Final output sent to browser
INFO - 2023-06-09 13:16:44 --> Config Class Initialized
INFO - 2023-06-09 13:16:44 --> Hooks Class Initialized
INFO - 2023-06-09 13:16:44 --> Utf8 Class Initialized
INFO - 2023-06-09 13:16:44 --> URI Class Initialized
INFO - 2023-06-09 13:16:44 --> Router Class Initialized
INFO - 2023-06-09 13:16:44 --> Output Class Initialized
INFO - 2023-06-09 13:16:44 --> Security Class Initialized
INFO - 2023-06-09 13:16:44 --> Input Class Initialized
INFO - 2023-06-09 13:16:44 --> Language Class Initialized
INFO - 2023-06-09 13:16:44 --> Loader Class Initialized
INFO - 2023-06-09 13:16:44 --> Helper loaded: url_helper
INFO - 2023-06-09 13:16:44 --> Helper loaded: form_helper
INFO - 2023-06-09 13:16:44 --> Database Driver Class Initialized
INFO - 2023-06-09 13:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:16:44 --> Form Validation Class Initialized
INFO - 2023-06-09 13:16:44 --> Controller Class Initialized
INFO - 2023-06-09 13:16:44 --> Model "m_user" initialized
INFO - 2023-06-09 13:16:44 --> Config Class Initialized
INFO - 2023-06-09 13:16:44 --> Hooks Class Initialized
INFO - 2023-06-09 13:16:44 --> Utf8 Class Initialized
INFO - 2023-06-09 13:16:44 --> URI Class Initialized
INFO - 2023-06-09 13:16:44 --> Router Class Initialized
INFO - 2023-06-09 13:16:44 --> Output Class Initialized
INFO - 2023-06-09 13:16:44 --> Security Class Initialized
INFO - 2023-06-09 13:16:44 --> Input Class Initialized
INFO - 2023-06-09 13:16:44 --> Language Class Initialized
INFO - 2023-06-09 13:16:44 --> Loader Class Initialized
INFO - 2023-06-09 13:16:45 --> Helper loaded: url_helper
INFO - 2023-06-09 13:16:45 --> Helper loaded: form_helper
INFO - 2023-06-09 13:16:45 --> Database Driver Class Initialized
INFO - 2023-06-09 13:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:16:45 --> Form Validation Class Initialized
INFO - 2023-06-09 13:16:45 --> Controller Class Initialized
INFO - 2023-06-09 13:16:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-09 13:16:45 --> Final output sent to browser
INFO - 2023-06-09 13:16:46 --> Config Class Initialized
INFO - 2023-06-09 13:16:46 --> Hooks Class Initialized
INFO - 2023-06-09 13:16:46 --> Utf8 Class Initialized
INFO - 2023-06-09 13:16:46 --> URI Class Initialized
INFO - 2023-06-09 13:16:46 --> Router Class Initialized
INFO - 2023-06-09 13:16:46 --> Output Class Initialized
INFO - 2023-06-09 13:16:46 --> Security Class Initialized
INFO - 2023-06-09 13:16:46 --> Input Class Initialized
INFO - 2023-06-09 13:16:46 --> Language Class Initialized
INFO - 2023-06-09 13:16:46 --> Loader Class Initialized
INFO - 2023-06-09 13:16:46 --> Helper loaded: url_helper
INFO - 2023-06-09 13:16:46 --> Helper loaded: form_helper
INFO - 2023-06-09 13:16:46 --> Database Driver Class Initialized
INFO - 2023-06-09 13:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:16:46 --> Form Validation Class Initialized
INFO - 2023-06-09 13:16:46 --> Controller Class Initialized
INFO - 2023-06-09 13:16:46 --> Model "m_user" initialized
INFO - 2023-06-09 13:16:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:16:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:16:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:16:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:16:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:16:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-09 13:16:46 --> Final output sent to browser
INFO - 2023-06-09 13:16:48 --> Config Class Initialized
INFO - 2023-06-09 13:16:48 --> Hooks Class Initialized
INFO - 2023-06-09 13:16:48 --> Utf8 Class Initialized
INFO - 2023-06-09 13:16:48 --> URI Class Initialized
INFO - 2023-06-09 13:16:48 --> Router Class Initialized
INFO - 2023-06-09 13:16:48 --> Output Class Initialized
INFO - 2023-06-09 13:16:48 --> Security Class Initialized
INFO - 2023-06-09 13:16:48 --> Input Class Initialized
INFO - 2023-06-09 13:16:48 --> Language Class Initialized
INFO - 2023-06-09 13:16:48 --> Loader Class Initialized
INFO - 2023-06-09 13:16:49 --> Helper loaded: url_helper
INFO - 2023-06-09 13:16:49 --> Helper loaded: form_helper
INFO - 2023-06-09 13:16:49 --> Database Driver Class Initialized
INFO - 2023-06-09 13:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:16:49 --> Form Validation Class Initialized
INFO - 2023-06-09 13:16:49 --> Controller Class Initialized
INFO - 2023-06-09 13:16:49 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:16:49 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:16:49 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:16:49 --> Model "M_solusi" initialized
INFO - 2023-06-09 13:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-09 13:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:16:49 --> Final output sent to browser
INFO - 2023-06-09 13:22:08 --> Config Class Initialized
INFO - 2023-06-09 13:22:08 --> Hooks Class Initialized
INFO - 2023-06-09 13:22:08 --> Utf8 Class Initialized
INFO - 2023-06-09 13:22:08 --> URI Class Initialized
INFO - 2023-06-09 13:22:08 --> Router Class Initialized
INFO - 2023-06-09 13:22:08 --> Output Class Initialized
INFO - 2023-06-09 13:22:08 --> Security Class Initialized
INFO - 2023-06-09 13:22:08 --> Input Class Initialized
INFO - 2023-06-09 13:22:08 --> Language Class Initialized
INFO - 2023-06-09 13:22:08 --> Loader Class Initialized
INFO - 2023-06-09 13:22:09 --> Helper loaded: url_helper
INFO - 2023-06-09 13:22:09 --> Helper loaded: form_helper
INFO - 2023-06-09 13:22:09 --> Database Driver Class Initialized
INFO - 2023-06-09 13:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:22:09 --> Form Validation Class Initialized
INFO - 2023-06-09 13:22:09 --> Controller Class Initialized
INFO - 2023-06-09 13:22:09 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:22:09 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:22:09 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:22:09 --> Model "M_solusi" initialized
ERROR - 2023-06-09 13:22:09 --> Severity: Notice --> Undefined variable: bobot3 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 811
INFO - 2023-06-09 13:22:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:22:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:22:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-09 13:22:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:22:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:22:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:22:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:22:09 --> Final output sent to browser
INFO - 2023-06-09 13:25:56 --> Config Class Initialized
INFO - 2023-06-09 13:25:56 --> Hooks Class Initialized
INFO - 2023-06-09 13:25:56 --> Utf8 Class Initialized
INFO - 2023-06-09 13:25:56 --> URI Class Initialized
INFO - 2023-06-09 13:25:56 --> Router Class Initialized
INFO - 2023-06-09 13:25:56 --> Output Class Initialized
INFO - 2023-06-09 13:25:56 --> Security Class Initialized
INFO - 2023-06-09 13:25:56 --> Input Class Initialized
INFO - 2023-06-09 13:25:56 --> Language Class Initialized
INFO - 2023-06-09 13:25:56 --> Loader Class Initialized
INFO - 2023-06-09 13:25:56 --> Helper loaded: url_helper
INFO - 2023-06-09 13:25:56 --> Helper loaded: form_helper
INFO - 2023-06-09 13:25:56 --> Database Driver Class Initialized
INFO - 2023-06-09 13:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:25:56 --> Form Validation Class Initialized
INFO - 2023-06-09 13:25:56 --> Controller Class Initialized
INFO - 2023-06-09 13:25:56 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:25:56 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:25:56 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:25:56 --> Model "M_solusi" initialized
INFO - 2023-06-09 13:25:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:25:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:25:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-09 13:25:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:25:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:25:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:25:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:25:56 --> Final output sent to browser
INFO - 2023-06-09 13:26:06 --> Config Class Initialized
INFO - 2023-06-09 13:26:06 --> Hooks Class Initialized
INFO - 2023-06-09 13:26:06 --> Utf8 Class Initialized
INFO - 2023-06-09 13:26:06 --> URI Class Initialized
INFO - 2023-06-09 13:26:06 --> Router Class Initialized
INFO - 2023-06-09 13:26:06 --> Output Class Initialized
INFO - 2023-06-09 13:26:06 --> Security Class Initialized
INFO - 2023-06-09 13:26:06 --> Input Class Initialized
INFO - 2023-06-09 13:26:06 --> Language Class Initialized
INFO - 2023-06-09 13:26:06 --> Loader Class Initialized
INFO - 2023-06-09 13:26:06 --> Helper loaded: url_helper
INFO - 2023-06-09 13:26:06 --> Helper loaded: form_helper
INFO - 2023-06-09 13:26:06 --> Database Driver Class Initialized
INFO - 2023-06-09 13:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:26:06 --> Form Validation Class Initialized
INFO - 2023-06-09 13:26:06 --> Controller Class Initialized
INFO - 2023-06-09 13:26:06 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:26:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:26:06 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:26:06 --> Model "M_solusi" initialized
ERROR - 2023-06-09 13:26:07 --> Severity: Notice --> Undefined variable: bobot3 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 811
INFO - 2023-06-09 13:26:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:26:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:26:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-09 13:26:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:26:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:26:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:26:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:26:07 --> Final output sent to browser
INFO - 2023-06-09 13:29:16 --> Config Class Initialized
INFO - 2023-06-09 13:29:16 --> Hooks Class Initialized
INFO - 2023-06-09 13:29:16 --> Utf8 Class Initialized
INFO - 2023-06-09 13:29:16 --> URI Class Initialized
INFO - 2023-06-09 13:29:16 --> Router Class Initialized
INFO - 2023-06-09 13:29:16 --> Output Class Initialized
INFO - 2023-06-09 13:29:16 --> Security Class Initialized
INFO - 2023-06-09 13:29:16 --> Input Class Initialized
INFO - 2023-06-09 13:29:16 --> Language Class Initialized
INFO - 2023-06-09 13:29:16 --> Loader Class Initialized
INFO - 2023-06-09 13:29:16 --> Helper loaded: url_helper
INFO - 2023-06-09 13:29:16 --> Helper loaded: form_helper
INFO - 2023-06-09 13:29:16 --> Database Driver Class Initialized
INFO - 2023-06-09 13:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:29:16 --> Form Validation Class Initialized
INFO - 2023-06-09 13:29:16 --> Controller Class Initialized
INFO - 2023-06-09 13:29:16 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:29:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:29:16 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:29:16 --> Model "M_solusi" initialized
ERROR - 2023-06-09 13:29:16 --> Severity: Notice --> Undefined variable: bobot3 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 811
ERROR - 2023-06-09 13:29:16 --> Severity: Notice --> Undefined variable: bobot3 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 883
INFO - 2023-06-09 13:29:16 --> Final output sent to browser
INFO - 2023-06-09 13:29:34 --> Config Class Initialized
INFO - 2023-06-09 13:29:34 --> Hooks Class Initialized
INFO - 2023-06-09 13:29:34 --> Utf8 Class Initialized
INFO - 2023-06-09 13:29:34 --> URI Class Initialized
INFO - 2023-06-09 13:29:34 --> Router Class Initialized
INFO - 2023-06-09 13:29:34 --> Output Class Initialized
INFO - 2023-06-09 13:29:34 --> Security Class Initialized
INFO - 2023-06-09 13:29:34 --> Input Class Initialized
INFO - 2023-06-09 13:29:34 --> Language Class Initialized
INFO - 2023-06-09 13:29:34 --> Loader Class Initialized
INFO - 2023-06-09 13:29:34 --> Helper loaded: url_helper
INFO - 2023-06-09 13:29:34 --> Helper loaded: form_helper
INFO - 2023-06-09 13:29:34 --> Database Driver Class Initialized
INFO - 2023-06-09 13:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:29:34 --> Form Validation Class Initialized
INFO - 2023-06-09 13:29:34 --> Controller Class Initialized
INFO - 2023-06-09 13:29:34 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:29:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:29:34 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:29:34 --> Model "M_solusi" initialized
ERROR - 2023-06-09 13:29:34 --> Severity: Notice --> Undefined variable: bobot3 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 811
INFO - 2023-06-09 13:29:34 --> Final output sent to browser
INFO - 2023-06-09 13:29:48 --> Config Class Initialized
INFO - 2023-06-09 13:29:48 --> Hooks Class Initialized
INFO - 2023-06-09 13:29:48 --> Utf8 Class Initialized
INFO - 2023-06-09 13:29:48 --> URI Class Initialized
INFO - 2023-06-09 13:29:48 --> Router Class Initialized
INFO - 2023-06-09 13:29:48 --> Output Class Initialized
INFO - 2023-06-09 13:29:48 --> Security Class Initialized
INFO - 2023-06-09 13:29:48 --> Input Class Initialized
INFO - 2023-06-09 13:29:48 --> Language Class Initialized
INFO - 2023-06-09 13:29:48 --> Loader Class Initialized
INFO - 2023-06-09 13:29:48 --> Helper loaded: url_helper
INFO - 2023-06-09 13:29:48 --> Helper loaded: form_helper
INFO - 2023-06-09 13:29:48 --> Database Driver Class Initialized
INFO - 2023-06-09 13:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:29:48 --> Form Validation Class Initialized
INFO - 2023-06-09 13:29:48 --> Controller Class Initialized
INFO - 2023-06-09 13:29:48 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:29:48 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:29:48 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:29:48 --> Model "M_solusi" initialized
ERROR - 2023-06-09 13:29:49 --> Severity: Notice --> Undefined variable: bobot3 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 811
ERROR - 2023-06-09 13:29:49 --> Severity: Notice --> Undefined variable: bobot3 C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 883
INFO - 2023-06-09 13:29:49 --> Final output sent to browser
INFO - 2023-06-09 13:30:58 --> Config Class Initialized
INFO - 2023-06-09 13:30:58 --> Hooks Class Initialized
INFO - 2023-06-09 13:30:58 --> Utf8 Class Initialized
INFO - 2023-06-09 13:30:58 --> URI Class Initialized
INFO - 2023-06-09 13:30:58 --> Router Class Initialized
INFO - 2023-06-09 13:30:58 --> Output Class Initialized
INFO - 2023-06-09 13:30:58 --> Security Class Initialized
INFO - 2023-06-09 13:30:58 --> Input Class Initialized
INFO - 2023-06-09 13:30:58 --> Language Class Initialized
INFO - 2023-06-09 13:30:58 --> Loader Class Initialized
INFO - 2023-06-09 13:30:58 --> Helper loaded: url_helper
INFO - 2023-06-09 13:30:58 --> Helper loaded: form_helper
INFO - 2023-06-09 13:30:58 --> Database Driver Class Initialized
INFO - 2023-06-09 13:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:30:58 --> Form Validation Class Initialized
INFO - 2023-06-09 13:30:58 --> Controller Class Initialized
INFO - 2023-06-09 13:30:58 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:30:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:30:58 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:30:58 --> Model "M_solusi" initialized
INFO - 2023-06-09 13:30:58 --> Final output sent to browser
INFO - 2023-06-09 13:34:51 --> Config Class Initialized
INFO - 2023-06-09 13:34:51 --> Hooks Class Initialized
INFO - 2023-06-09 13:34:51 --> Utf8 Class Initialized
INFO - 2023-06-09 13:34:51 --> URI Class Initialized
INFO - 2023-06-09 13:34:51 --> Router Class Initialized
INFO - 2023-06-09 13:34:51 --> Output Class Initialized
INFO - 2023-06-09 13:34:51 --> Security Class Initialized
INFO - 2023-06-09 13:34:51 --> Input Class Initialized
INFO - 2023-06-09 13:34:51 --> Language Class Initialized
INFO - 2023-06-09 13:34:51 --> Loader Class Initialized
INFO - 2023-06-09 13:34:51 --> Helper loaded: url_helper
INFO - 2023-06-09 13:34:51 --> Helper loaded: form_helper
INFO - 2023-06-09 13:34:51 --> Database Driver Class Initialized
INFO - 2023-06-09 13:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:34:51 --> Form Validation Class Initialized
INFO - 2023-06-09 13:34:51 --> Controller Class Initialized
INFO - 2023-06-09 13:34:51 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:34:51 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:34:51 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:34:51 --> Model "M_solusi" initialized
INFO - 2023-06-09 13:34:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:34:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:34:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-09 13:34:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:34:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:34:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:34:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:34:51 --> Final output sent to browser
INFO - 2023-06-09 13:36:47 --> Config Class Initialized
INFO - 2023-06-09 13:36:47 --> Hooks Class Initialized
INFO - 2023-06-09 13:36:47 --> Utf8 Class Initialized
INFO - 2023-06-09 13:36:47 --> URI Class Initialized
INFO - 2023-06-09 13:36:47 --> Router Class Initialized
INFO - 2023-06-09 13:36:47 --> Output Class Initialized
INFO - 2023-06-09 13:36:47 --> Security Class Initialized
INFO - 2023-06-09 13:36:47 --> Input Class Initialized
INFO - 2023-06-09 13:36:47 --> Language Class Initialized
INFO - 2023-06-09 13:36:47 --> Loader Class Initialized
INFO - 2023-06-09 13:36:47 --> Helper loaded: url_helper
INFO - 2023-06-09 13:36:47 --> Helper loaded: form_helper
INFO - 2023-06-09 13:36:47 --> Database Driver Class Initialized
INFO - 2023-06-09 13:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:36:47 --> Form Validation Class Initialized
INFO - 2023-06-09 13:36:47 --> Controller Class Initialized
INFO - 2023-06-09 13:36:47 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:36:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:36:47 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:36:47 --> Model "M_solusi" initialized
INFO - 2023-06-09 13:36:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:36:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:36:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-09 13:36:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:36:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:36:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:36:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:36:48 --> Final output sent to browser
INFO - 2023-06-09 13:36:58 --> Config Class Initialized
INFO - 2023-06-09 13:36:58 --> Hooks Class Initialized
INFO - 2023-06-09 13:36:58 --> Utf8 Class Initialized
INFO - 2023-06-09 13:36:58 --> URI Class Initialized
INFO - 2023-06-09 13:36:58 --> Router Class Initialized
INFO - 2023-06-09 13:36:58 --> Output Class Initialized
INFO - 2023-06-09 13:36:58 --> Security Class Initialized
INFO - 2023-06-09 13:36:58 --> Input Class Initialized
INFO - 2023-06-09 13:36:58 --> Language Class Initialized
INFO - 2023-06-09 13:36:58 --> Loader Class Initialized
INFO - 2023-06-09 13:36:58 --> Helper loaded: url_helper
INFO - 2023-06-09 13:36:58 --> Helper loaded: form_helper
INFO - 2023-06-09 13:36:58 --> Database Driver Class Initialized
INFO - 2023-06-09 13:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:36:58 --> Form Validation Class Initialized
INFO - 2023-06-09 13:36:58 --> Controller Class Initialized
INFO - 2023-06-09 13:36:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-09 13:36:58 --> Final output sent to browser
INFO - 2023-06-09 13:37:01 --> Config Class Initialized
INFO - 2023-06-09 13:37:01 --> Hooks Class Initialized
INFO - 2023-06-09 13:37:01 --> Utf8 Class Initialized
INFO - 2023-06-09 13:37:01 --> URI Class Initialized
INFO - 2023-06-09 13:37:01 --> Router Class Initialized
INFO - 2023-06-09 13:37:01 --> Output Class Initialized
INFO - 2023-06-09 13:37:01 --> Security Class Initialized
INFO - 2023-06-09 13:37:01 --> Input Class Initialized
INFO - 2023-06-09 13:37:01 --> Language Class Initialized
INFO - 2023-06-09 13:37:01 --> Loader Class Initialized
INFO - 2023-06-09 13:37:01 --> Helper loaded: url_helper
INFO - 2023-06-09 13:37:01 --> Helper loaded: form_helper
INFO - 2023-06-09 13:37:01 --> Database Driver Class Initialized
INFO - 2023-06-09 13:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:37:01 --> Form Validation Class Initialized
INFO - 2023-06-09 13:37:01 --> Controller Class Initialized
INFO - 2023-06-09 13:37:01 --> Model "m_user" initialized
INFO - 2023-06-09 13:37:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-09 13:37:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-09 13:37:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-09 13:37:01 --> Final output sent to browser
INFO - 2023-06-09 13:37:05 --> Config Class Initialized
INFO - 2023-06-09 13:37:05 --> Hooks Class Initialized
INFO - 2023-06-09 13:37:05 --> Utf8 Class Initialized
INFO - 2023-06-09 13:37:05 --> URI Class Initialized
INFO - 2023-06-09 13:37:05 --> Router Class Initialized
INFO - 2023-06-09 13:37:05 --> Output Class Initialized
INFO - 2023-06-09 13:37:05 --> Security Class Initialized
INFO - 2023-06-09 13:37:05 --> Input Class Initialized
INFO - 2023-06-09 13:37:05 --> Language Class Initialized
INFO - 2023-06-09 13:37:05 --> Loader Class Initialized
INFO - 2023-06-09 13:37:05 --> Helper loaded: url_helper
INFO - 2023-06-09 13:37:05 --> Helper loaded: form_helper
INFO - 2023-06-09 13:37:05 --> Database Driver Class Initialized
INFO - 2023-06-09 13:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:37:05 --> Form Validation Class Initialized
INFO - 2023-06-09 13:37:05 --> Controller Class Initialized
INFO - 2023-06-09 13:37:05 --> Model "m_user" initialized
INFO - 2023-06-09 13:37:06 --> Config Class Initialized
INFO - 2023-06-09 13:37:06 --> Hooks Class Initialized
INFO - 2023-06-09 13:37:06 --> Utf8 Class Initialized
INFO - 2023-06-09 13:37:06 --> URI Class Initialized
INFO - 2023-06-09 13:37:06 --> Router Class Initialized
INFO - 2023-06-09 13:37:06 --> Output Class Initialized
INFO - 2023-06-09 13:37:06 --> Security Class Initialized
INFO - 2023-06-09 13:37:06 --> Input Class Initialized
INFO - 2023-06-09 13:37:06 --> Language Class Initialized
INFO - 2023-06-09 13:37:06 --> Loader Class Initialized
INFO - 2023-06-09 13:37:06 --> Helper loaded: url_helper
INFO - 2023-06-09 13:37:06 --> Helper loaded: form_helper
INFO - 2023-06-09 13:37:06 --> Database Driver Class Initialized
INFO - 2023-06-09 13:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:37:06 --> Form Validation Class Initialized
INFO - 2023-06-09 13:37:06 --> Controller Class Initialized
INFO - 2023-06-09 13:37:06 --> Model "m_user" initialized
INFO - 2023-06-09 13:37:06 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:37:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:37:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:37:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:37:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:37:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:37:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-09 13:37:06 --> Final output sent to browser
INFO - 2023-06-09 13:37:07 --> Config Class Initialized
INFO - 2023-06-09 13:37:07 --> Hooks Class Initialized
INFO - 2023-06-09 13:37:08 --> Utf8 Class Initialized
INFO - 2023-06-09 13:37:08 --> URI Class Initialized
INFO - 2023-06-09 13:37:08 --> Router Class Initialized
INFO - 2023-06-09 13:37:08 --> Output Class Initialized
INFO - 2023-06-09 13:37:08 --> Security Class Initialized
INFO - 2023-06-09 13:37:08 --> Input Class Initialized
INFO - 2023-06-09 13:37:08 --> Language Class Initialized
INFO - 2023-06-09 13:37:08 --> Loader Class Initialized
INFO - 2023-06-09 13:37:08 --> Helper loaded: url_helper
INFO - 2023-06-09 13:37:08 --> Helper loaded: form_helper
INFO - 2023-06-09 13:37:08 --> Database Driver Class Initialized
INFO - 2023-06-09 13:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:37:08 --> Form Validation Class Initialized
INFO - 2023-06-09 13:37:08 --> Controller Class Initialized
INFO - 2023-06-09 13:37:08 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:37:08 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:37:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:37:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:37:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 13:37:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:37:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:37:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:37:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:37:08 --> Final output sent to browser
INFO - 2023-06-09 13:40:44 --> Config Class Initialized
INFO - 2023-06-09 13:40:44 --> Hooks Class Initialized
INFO - 2023-06-09 13:40:44 --> Utf8 Class Initialized
INFO - 2023-06-09 13:40:44 --> URI Class Initialized
INFO - 2023-06-09 13:40:44 --> Router Class Initialized
INFO - 2023-06-09 13:40:44 --> Output Class Initialized
INFO - 2023-06-09 13:40:44 --> Security Class Initialized
INFO - 2023-06-09 13:40:44 --> Input Class Initialized
INFO - 2023-06-09 13:40:44 --> Language Class Initialized
INFO - 2023-06-09 13:40:44 --> Loader Class Initialized
INFO - 2023-06-09 13:40:44 --> Helper loaded: url_helper
INFO - 2023-06-09 13:40:44 --> Helper loaded: form_helper
INFO - 2023-06-09 13:40:44 --> Database Driver Class Initialized
INFO - 2023-06-09 13:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:40:44 --> Form Validation Class Initialized
INFO - 2023-06-09 13:40:44 --> Controller Class Initialized
INFO - 2023-06-09 13:40:44 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:40:44 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:40:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:40:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:40:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-09 13:40:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:40:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:40:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:40:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:40:45 --> Final output sent to browser
INFO - 2023-06-09 13:41:02 --> Config Class Initialized
INFO - 2023-06-09 13:41:02 --> Hooks Class Initialized
INFO - 2023-06-09 13:41:02 --> Utf8 Class Initialized
INFO - 2023-06-09 13:41:02 --> URI Class Initialized
INFO - 2023-06-09 13:41:02 --> Router Class Initialized
INFO - 2023-06-09 13:41:02 --> Output Class Initialized
INFO - 2023-06-09 13:41:02 --> Security Class Initialized
INFO - 2023-06-09 13:41:02 --> Input Class Initialized
INFO - 2023-06-09 13:41:02 --> Language Class Initialized
INFO - 2023-06-09 13:41:02 --> Loader Class Initialized
INFO - 2023-06-09 13:41:02 --> Helper loaded: url_helper
INFO - 2023-06-09 13:41:02 --> Helper loaded: form_helper
INFO - 2023-06-09 13:41:02 --> Database Driver Class Initialized
INFO - 2023-06-09 13:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:41:02 --> Form Validation Class Initialized
INFO - 2023-06-09 13:41:02 --> Controller Class Initialized
INFO - 2023-06-09 13:41:02 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:41:02 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:41:02 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:41:02 --> Model "M_solusi" initialized
INFO - 2023-06-09 13:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-09 13:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:41:02 --> Final output sent to browser
INFO - 2023-06-09 13:43:50 --> Config Class Initialized
INFO - 2023-06-09 13:43:50 --> Hooks Class Initialized
INFO - 2023-06-09 13:43:50 --> Utf8 Class Initialized
INFO - 2023-06-09 13:43:50 --> URI Class Initialized
INFO - 2023-06-09 13:43:50 --> Router Class Initialized
INFO - 2023-06-09 13:43:50 --> Output Class Initialized
INFO - 2023-06-09 13:43:50 --> Security Class Initialized
INFO - 2023-06-09 13:43:50 --> Input Class Initialized
INFO - 2023-06-09 13:43:50 --> Language Class Initialized
INFO - 2023-06-09 13:43:50 --> Loader Class Initialized
INFO - 2023-06-09 13:43:50 --> Helper loaded: url_helper
INFO - 2023-06-09 13:43:50 --> Helper loaded: form_helper
INFO - 2023-06-09 13:43:50 --> Database Driver Class Initialized
INFO - 2023-06-09 13:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:43:50 --> Form Validation Class Initialized
INFO - 2023-06-09 13:43:50 --> Controller Class Initialized
INFO - 2023-06-09 13:43:50 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:43:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:43:50 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:43:50 --> Model "M_solusi" initialized
INFO - 2023-06-09 13:43:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:43:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:43:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-09 13:43:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:43:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:43:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:43:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:43:50 --> Final output sent to browser
INFO - 2023-06-09 13:44:00 --> Config Class Initialized
INFO - 2023-06-09 13:44:00 --> Hooks Class Initialized
INFO - 2023-06-09 13:44:00 --> Utf8 Class Initialized
INFO - 2023-06-09 13:44:00 --> URI Class Initialized
INFO - 2023-06-09 13:44:00 --> Router Class Initialized
INFO - 2023-06-09 13:44:00 --> Output Class Initialized
INFO - 2023-06-09 13:44:00 --> Security Class Initialized
INFO - 2023-06-09 13:44:00 --> Input Class Initialized
INFO - 2023-06-09 13:44:00 --> Language Class Initialized
INFO - 2023-06-09 13:44:00 --> Loader Class Initialized
INFO - 2023-06-09 13:44:00 --> Helper loaded: url_helper
INFO - 2023-06-09 13:44:00 --> Helper loaded: form_helper
INFO - 2023-06-09 13:44:00 --> Database Driver Class Initialized
INFO - 2023-06-09 13:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:44:00 --> Form Validation Class Initialized
INFO - 2023-06-09 13:44:00 --> Controller Class Initialized
INFO - 2023-06-09 13:44:00 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:44:00 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:44:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:44:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:44:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-09 13:44:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:44:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:44:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:44:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:44:00 --> Final output sent to browser
INFO - 2023-06-09 13:44:07 --> Config Class Initialized
INFO - 2023-06-09 13:44:07 --> Hooks Class Initialized
INFO - 2023-06-09 13:44:07 --> Utf8 Class Initialized
INFO - 2023-06-09 13:44:07 --> URI Class Initialized
INFO - 2023-06-09 13:44:07 --> Router Class Initialized
INFO - 2023-06-09 13:44:07 --> Output Class Initialized
INFO - 2023-06-09 13:44:07 --> Security Class Initialized
INFO - 2023-06-09 13:44:07 --> Input Class Initialized
INFO - 2023-06-09 13:44:07 --> Language Class Initialized
INFO - 2023-06-09 13:44:07 --> Loader Class Initialized
INFO - 2023-06-09 13:44:07 --> Helper loaded: url_helper
INFO - 2023-06-09 13:44:07 --> Helper loaded: form_helper
INFO - 2023-06-09 13:44:07 --> Database Driver Class Initialized
INFO - 2023-06-09 13:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:44:07 --> Form Validation Class Initialized
INFO - 2023-06-09 13:44:07 --> Controller Class Initialized
INFO - 2023-06-09 13:44:07 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:44:07 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:44:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:44:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:44:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 13:44:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:44:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:44:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:44:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:44:07 --> Final output sent to browser
INFO - 2023-06-09 13:44:15 --> Config Class Initialized
INFO - 2023-06-09 13:44:15 --> Hooks Class Initialized
INFO - 2023-06-09 13:44:15 --> Utf8 Class Initialized
INFO - 2023-06-09 13:44:15 --> URI Class Initialized
INFO - 2023-06-09 13:44:15 --> Router Class Initialized
INFO - 2023-06-09 13:44:15 --> Output Class Initialized
INFO - 2023-06-09 13:44:15 --> Security Class Initialized
INFO - 2023-06-09 13:44:15 --> Input Class Initialized
INFO - 2023-06-09 13:44:15 --> Language Class Initialized
INFO - 2023-06-09 13:44:15 --> Loader Class Initialized
INFO - 2023-06-09 13:44:15 --> Helper loaded: url_helper
INFO - 2023-06-09 13:44:15 --> Helper loaded: form_helper
INFO - 2023-06-09 13:44:15 --> Database Driver Class Initialized
INFO - 2023-06-09 13:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:44:15 --> Form Validation Class Initialized
INFO - 2023-06-09 13:44:15 --> Controller Class Initialized
INFO - 2023-06-09 13:44:15 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:44:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:44:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:44:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-09 13:44:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:44:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:44:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:44:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:44:15 --> Final output sent to browser
INFO - 2023-06-09 13:44:16 --> Config Class Initialized
INFO - 2023-06-09 13:44:16 --> Hooks Class Initialized
INFO - 2023-06-09 13:44:16 --> Utf8 Class Initialized
INFO - 2023-06-09 13:44:16 --> URI Class Initialized
INFO - 2023-06-09 13:44:16 --> Router Class Initialized
INFO - 2023-06-09 13:44:16 --> Output Class Initialized
INFO - 2023-06-09 13:44:16 --> Security Class Initialized
INFO - 2023-06-09 13:44:16 --> Input Class Initialized
INFO - 2023-06-09 13:44:16 --> Language Class Initialized
INFO - 2023-06-09 13:44:16 --> Loader Class Initialized
INFO - 2023-06-09 13:44:16 --> Helper loaded: url_helper
INFO - 2023-06-09 13:44:16 --> Helper loaded: form_helper
INFO - 2023-06-09 13:44:16 --> Database Driver Class Initialized
INFO - 2023-06-09 13:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:44:16 --> Form Validation Class Initialized
INFO - 2023-06-09 13:44:16 --> Controller Class Initialized
INFO - 2023-06-09 13:44:16 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:44:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 13:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:44:16 --> Final output sent to browser
INFO - 2023-06-09 13:50:12 --> Config Class Initialized
INFO - 2023-06-09 13:50:12 --> Hooks Class Initialized
INFO - 2023-06-09 13:50:12 --> Utf8 Class Initialized
INFO - 2023-06-09 13:50:12 --> URI Class Initialized
INFO - 2023-06-09 13:50:12 --> Router Class Initialized
INFO - 2023-06-09 13:50:12 --> Output Class Initialized
INFO - 2023-06-09 13:50:12 --> Security Class Initialized
INFO - 2023-06-09 13:50:12 --> Input Class Initialized
INFO - 2023-06-09 13:50:12 --> Language Class Initialized
INFO - 2023-06-09 13:50:12 --> Loader Class Initialized
INFO - 2023-06-09 13:50:12 --> Helper loaded: url_helper
INFO - 2023-06-09 13:50:12 --> Helper loaded: form_helper
INFO - 2023-06-09 13:50:12 --> Database Driver Class Initialized
INFO - 2023-06-09 13:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:50:12 --> Form Validation Class Initialized
INFO - 2023-06-09 13:50:12 --> Controller Class Initialized
INFO - 2023-06-09 13:50:12 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:50:12 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:50:12 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:50:12 --> Model "M_solusi" initialized
INFO - 2023-06-09 13:50:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:50:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:50:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-09 13:50:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:50:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:50:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:50:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:50:12 --> Final output sent to browser
INFO - 2023-06-09 13:51:02 --> Config Class Initialized
INFO - 2023-06-09 13:51:02 --> Hooks Class Initialized
INFO - 2023-06-09 13:51:02 --> Utf8 Class Initialized
INFO - 2023-06-09 13:51:02 --> URI Class Initialized
INFO - 2023-06-09 13:51:02 --> Router Class Initialized
INFO - 2023-06-09 13:51:02 --> Output Class Initialized
INFO - 2023-06-09 13:51:02 --> Security Class Initialized
INFO - 2023-06-09 13:51:02 --> Input Class Initialized
INFO - 2023-06-09 13:51:02 --> Language Class Initialized
INFO - 2023-06-09 13:51:02 --> Loader Class Initialized
INFO - 2023-06-09 13:51:02 --> Helper loaded: url_helper
INFO - 2023-06-09 13:51:02 --> Helper loaded: form_helper
INFO - 2023-06-09 13:51:02 --> Database Driver Class Initialized
INFO - 2023-06-09 13:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:51:02 --> Form Validation Class Initialized
INFO - 2023-06-09 13:51:02 --> Controller Class Initialized
INFO - 2023-06-09 13:51:02 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:51:02 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:51:02 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:51:02 --> Model "M_solusi" initialized
INFO - 2023-06-09 13:51:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:51:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:51:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-09 13:51:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:51:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:51:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:51:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:51:02 --> Final output sent to browser
INFO - 2023-06-09 13:52:15 --> Config Class Initialized
INFO - 2023-06-09 13:52:15 --> Hooks Class Initialized
INFO - 2023-06-09 13:52:15 --> Utf8 Class Initialized
INFO - 2023-06-09 13:52:15 --> URI Class Initialized
INFO - 2023-06-09 13:52:15 --> Router Class Initialized
INFO - 2023-06-09 13:52:15 --> Output Class Initialized
INFO - 2023-06-09 13:52:15 --> Security Class Initialized
INFO - 2023-06-09 13:52:15 --> Input Class Initialized
INFO - 2023-06-09 13:52:15 --> Language Class Initialized
INFO - 2023-06-09 13:52:15 --> Loader Class Initialized
INFO - 2023-06-09 13:52:15 --> Helper loaded: url_helper
INFO - 2023-06-09 13:52:15 --> Helper loaded: form_helper
INFO - 2023-06-09 13:52:15 --> Database Driver Class Initialized
INFO - 2023-06-09 13:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:52:15 --> Form Validation Class Initialized
INFO - 2023-06-09 13:52:15 --> Controller Class Initialized
INFO - 2023-06-09 13:52:15 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:52:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 13:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:52:15 --> Final output sent to browser
INFO - 2023-06-09 13:58:21 --> Config Class Initialized
INFO - 2023-06-09 13:58:21 --> Hooks Class Initialized
INFO - 2023-06-09 13:58:21 --> Utf8 Class Initialized
INFO - 2023-06-09 13:58:21 --> URI Class Initialized
INFO - 2023-06-09 13:58:21 --> Router Class Initialized
INFO - 2023-06-09 13:58:21 --> Output Class Initialized
INFO - 2023-06-09 13:58:21 --> Security Class Initialized
INFO - 2023-06-09 13:58:21 --> Input Class Initialized
INFO - 2023-06-09 13:58:21 --> Language Class Initialized
INFO - 2023-06-09 13:58:21 --> Loader Class Initialized
INFO - 2023-06-09 13:58:21 --> Helper loaded: url_helper
INFO - 2023-06-09 13:58:21 --> Helper loaded: form_helper
INFO - 2023-06-09 13:58:21 --> Database Driver Class Initialized
INFO - 2023-06-09 13:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:58:21 --> Form Validation Class Initialized
INFO - 2023-06-09 13:58:21 --> Controller Class Initialized
INFO - 2023-06-09 13:58:21 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:58:21 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:58:21 --> Config Class Initialized
INFO - 2023-06-09 13:58:21 --> Hooks Class Initialized
INFO - 2023-06-09 13:58:21 --> Utf8 Class Initialized
INFO - 2023-06-09 13:58:21 --> URI Class Initialized
INFO - 2023-06-09 13:58:21 --> Router Class Initialized
INFO - 2023-06-09 13:58:21 --> Output Class Initialized
INFO - 2023-06-09 13:58:21 --> Security Class Initialized
INFO - 2023-06-09 13:58:21 --> Input Class Initialized
INFO - 2023-06-09 13:58:21 --> Language Class Initialized
INFO - 2023-06-09 13:58:21 --> Loader Class Initialized
INFO - 2023-06-09 13:58:21 --> Helper loaded: url_helper
INFO - 2023-06-09 13:58:21 --> Helper loaded: form_helper
INFO - 2023-06-09 13:58:21 --> Database Driver Class Initialized
INFO - 2023-06-09 13:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:58:21 --> Form Validation Class Initialized
INFO - 2023-06-09 13:58:21 --> Controller Class Initialized
INFO - 2023-06-09 13:58:21 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:58:21 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:58:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:58:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:58:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 13:58:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:58:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:58:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:58:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:58:21 --> Final output sent to browser
INFO - 2023-06-09 13:58:26 --> Config Class Initialized
INFO - 2023-06-09 13:58:26 --> Hooks Class Initialized
INFO - 2023-06-09 13:58:26 --> Utf8 Class Initialized
INFO - 2023-06-09 13:58:26 --> URI Class Initialized
INFO - 2023-06-09 13:58:26 --> Router Class Initialized
INFO - 2023-06-09 13:58:26 --> Output Class Initialized
INFO - 2023-06-09 13:58:26 --> Security Class Initialized
INFO - 2023-06-09 13:58:26 --> Input Class Initialized
INFO - 2023-06-09 13:58:26 --> Language Class Initialized
INFO - 2023-06-09 13:58:26 --> Loader Class Initialized
INFO - 2023-06-09 13:58:26 --> Helper loaded: url_helper
INFO - 2023-06-09 13:58:26 --> Helper loaded: form_helper
INFO - 2023-06-09 13:58:26 --> Database Driver Class Initialized
INFO - 2023-06-09 13:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:58:26 --> Form Validation Class Initialized
INFO - 2023-06-09 13:58:26 --> Controller Class Initialized
INFO - 2023-06-09 13:58:26 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:58:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:58:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:58:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:58:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 13:58:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 13:58:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:58:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:58:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 13:58:26 --> Final output sent to browser
INFO - 2023-06-09 13:58:30 --> Config Class Initialized
INFO - 2023-06-09 13:58:30 --> Hooks Class Initialized
INFO - 2023-06-09 13:58:30 --> Utf8 Class Initialized
INFO - 2023-06-09 13:58:30 --> URI Class Initialized
INFO - 2023-06-09 13:58:30 --> Router Class Initialized
INFO - 2023-06-09 13:58:30 --> Output Class Initialized
INFO - 2023-06-09 13:58:30 --> Security Class Initialized
INFO - 2023-06-09 13:58:30 --> Input Class Initialized
INFO - 2023-06-09 13:58:30 --> Language Class Initialized
INFO - 2023-06-09 13:58:30 --> Loader Class Initialized
INFO - 2023-06-09 13:58:30 --> Helper loaded: url_helper
INFO - 2023-06-09 13:58:30 --> Helper loaded: form_helper
INFO - 2023-06-09 13:58:30 --> Database Driver Class Initialized
INFO - 2023-06-09 13:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 13:58:30 --> Form Validation Class Initialized
INFO - 2023-06-09 13:58:30 --> Controller Class Initialized
INFO - 2023-06-09 13:58:30 --> Model "m_datatrain" initialized
INFO - 2023-06-09 13:58:30 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 13:58:30 --> Model "m_datatest" initialized
INFO - 2023-06-09 13:58:30 --> Model "M_solusi" initialized
INFO - 2023-06-09 13:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 13:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 13:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-09 13:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 13:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 13:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 13:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 13:58:30 --> Final output sent to browser
INFO - 2023-06-09 14:02:57 --> Config Class Initialized
INFO - 2023-06-09 14:02:57 --> Hooks Class Initialized
INFO - 2023-06-09 14:02:57 --> Utf8 Class Initialized
INFO - 2023-06-09 14:02:57 --> URI Class Initialized
INFO - 2023-06-09 14:02:57 --> Router Class Initialized
INFO - 2023-06-09 14:02:57 --> Output Class Initialized
INFO - 2023-06-09 14:02:57 --> Security Class Initialized
INFO - 2023-06-09 14:02:57 --> Input Class Initialized
INFO - 2023-06-09 14:02:57 --> Language Class Initialized
INFO - 2023-06-09 14:02:57 --> Loader Class Initialized
INFO - 2023-06-09 14:02:57 --> Helper loaded: url_helper
INFO - 2023-06-09 14:02:57 --> Helper loaded: form_helper
INFO - 2023-06-09 14:02:57 --> Database Driver Class Initialized
INFO - 2023-06-09 14:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:02:58 --> Form Validation Class Initialized
INFO - 2023-06-09 14:02:58 --> Controller Class Initialized
INFO - 2023-06-09 14:02:58 --> Model "m_datatrain" initialized
INFO - 2023-06-09 14:02:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 14:02:58 --> Model "m_datatest" initialized
INFO - 2023-06-09 14:02:58 --> Model "M_solusi" initialized
INFO - 2023-06-09 14:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-09 14:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:02:58 --> Final output sent to browser
INFO - 2023-06-09 14:03:36 --> Config Class Initialized
INFO - 2023-06-09 14:03:36 --> Hooks Class Initialized
INFO - 2023-06-09 14:03:36 --> Utf8 Class Initialized
INFO - 2023-06-09 14:03:36 --> URI Class Initialized
INFO - 2023-06-09 14:03:36 --> Router Class Initialized
INFO - 2023-06-09 14:03:36 --> Output Class Initialized
INFO - 2023-06-09 14:03:36 --> Security Class Initialized
INFO - 2023-06-09 14:03:36 --> Input Class Initialized
INFO - 2023-06-09 14:03:36 --> Language Class Initialized
INFO - 2023-06-09 14:03:36 --> Loader Class Initialized
INFO - 2023-06-09 14:03:36 --> Helper loaded: url_helper
INFO - 2023-06-09 14:03:36 --> Helper loaded: form_helper
INFO - 2023-06-09 14:03:36 --> Database Driver Class Initialized
INFO - 2023-06-09 14:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:03:36 --> Form Validation Class Initialized
INFO - 2023-06-09 14:03:36 --> Controller Class Initialized
INFO - 2023-06-09 14:03:36 --> Model "m_datatest" initialized
INFO - 2023-06-09 14:03:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 14:03:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:03:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:03:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 14:03:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 14:03:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:03:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:03:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 14:03:36 --> Final output sent to browser
INFO - 2023-06-09 14:03:42 --> Config Class Initialized
INFO - 2023-06-09 14:03:42 --> Hooks Class Initialized
INFO - 2023-06-09 14:03:42 --> Utf8 Class Initialized
INFO - 2023-06-09 14:03:42 --> URI Class Initialized
INFO - 2023-06-09 14:03:42 --> Router Class Initialized
INFO - 2023-06-09 14:03:42 --> Output Class Initialized
INFO - 2023-06-09 14:03:42 --> Security Class Initialized
INFO - 2023-06-09 14:03:42 --> Input Class Initialized
INFO - 2023-06-09 14:03:42 --> Language Class Initialized
INFO - 2023-06-09 14:03:42 --> Loader Class Initialized
INFO - 2023-06-09 14:03:42 --> Helper loaded: url_helper
INFO - 2023-06-09 14:03:42 --> Helper loaded: form_helper
INFO - 2023-06-09 14:03:42 --> Database Driver Class Initialized
INFO - 2023-06-09 14:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:03:42 --> Form Validation Class Initialized
INFO - 2023-06-09 14:03:42 --> Controller Class Initialized
INFO - 2023-06-09 14:03:42 --> Model "m_datatest" initialized
INFO - 2023-06-09 14:03:42 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 14:03:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:03:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:03:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-09 14:03:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-09 14:03:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:03:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:03:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-09 14:03:42 --> Final output sent to browser
INFO - 2023-06-09 14:05:06 --> Config Class Initialized
INFO - 2023-06-09 14:05:06 --> Hooks Class Initialized
INFO - 2023-06-09 14:05:06 --> Utf8 Class Initialized
INFO - 2023-06-09 14:05:06 --> URI Class Initialized
INFO - 2023-06-09 14:05:06 --> Router Class Initialized
INFO - 2023-06-09 14:05:06 --> Output Class Initialized
INFO - 2023-06-09 14:05:06 --> Security Class Initialized
INFO - 2023-06-09 14:05:06 --> Input Class Initialized
INFO - 2023-06-09 14:05:06 --> Language Class Initialized
INFO - 2023-06-09 14:05:06 --> Loader Class Initialized
INFO - 2023-06-09 14:05:06 --> Helper loaded: url_helper
INFO - 2023-06-09 14:05:06 --> Helper loaded: form_helper
INFO - 2023-06-09 14:05:06 --> Database Driver Class Initialized
INFO - 2023-06-09 14:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:05:06 --> Form Validation Class Initialized
INFO - 2023-06-09 14:05:06 --> Controller Class Initialized
INFO - 2023-06-09 14:05:06 --> Model "m_datatest" initialized
ERROR - 2023-06-09 14:05:06 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 81
ERROR - 2023-06-09 14:05:06 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 82
ERROR - 2023-06-09 14:05:06 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
INFO - 2023-06-09 14:05:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:05:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:05:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 14:05:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:05:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:05:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:05:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:05:06 --> Final output sent to browser
INFO - 2023-06-09 14:05:26 --> Config Class Initialized
INFO - 2023-06-09 14:05:26 --> Hooks Class Initialized
INFO - 2023-06-09 14:05:26 --> Utf8 Class Initialized
INFO - 2023-06-09 14:05:26 --> URI Class Initialized
INFO - 2023-06-09 14:05:26 --> Router Class Initialized
INFO - 2023-06-09 14:05:26 --> Output Class Initialized
INFO - 2023-06-09 14:05:26 --> Security Class Initialized
INFO - 2023-06-09 14:05:26 --> Input Class Initialized
INFO - 2023-06-09 14:05:26 --> Language Class Initialized
INFO - 2023-06-09 14:05:26 --> Loader Class Initialized
INFO - 2023-06-09 14:05:26 --> Helper loaded: url_helper
INFO - 2023-06-09 14:05:26 --> Helper loaded: form_helper
INFO - 2023-06-09 14:05:26 --> Database Driver Class Initialized
INFO - 2023-06-09 14:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:05:26 --> Form Validation Class Initialized
INFO - 2023-06-09 14:05:26 --> Controller Class Initialized
INFO - 2023-06-09 14:05:26 --> Model "m_datatrain" initialized
INFO - 2023-06-09 14:05:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 14:05:26 --> Model "m_datatest" initialized
INFO - 2023-06-09 14:05:26 --> Model "M_solusi" initialized
INFO - 2023-06-09 14:05:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:05:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:05:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-09 14:05:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:05:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:05:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:05:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:05:26 --> Final output sent to browser
INFO - 2023-06-09 14:05:29 --> Config Class Initialized
INFO - 2023-06-09 14:05:29 --> Hooks Class Initialized
INFO - 2023-06-09 14:05:29 --> Utf8 Class Initialized
INFO - 2023-06-09 14:05:29 --> URI Class Initialized
INFO - 2023-06-09 14:05:29 --> Router Class Initialized
INFO - 2023-06-09 14:05:29 --> Output Class Initialized
INFO - 2023-06-09 14:05:29 --> Security Class Initialized
INFO - 2023-06-09 14:05:29 --> Input Class Initialized
INFO - 2023-06-09 14:05:29 --> Language Class Initialized
INFO - 2023-06-09 14:05:29 --> Loader Class Initialized
INFO - 2023-06-09 14:05:29 --> Helper loaded: url_helper
INFO - 2023-06-09 14:05:29 --> Helper loaded: form_helper
INFO - 2023-06-09 14:05:29 --> Database Driver Class Initialized
INFO - 2023-06-09 14:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:05:29 --> Form Validation Class Initialized
INFO - 2023-06-09 14:05:29 --> Controller Class Initialized
INFO - 2023-06-09 14:05:29 --> Model "m_datatrain" initialized
INFO - 2023-06-09 14:05:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-09 14:05:29 --> Model "m_datatest" initialized
INFO - 2023-06-09 14:05:29 --> Model "M_solusi" initialized
INFO - 2023-06-09 14:05:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:05:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:05:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-09 14:05:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:05:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:05:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:05:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:05:29 --> Final output sent to browser
INFO - 2023-06-09 14:06:18 --> Config Class Initialized
INFO - 2023-06-09 14:06:18 --> Hooks Class Initialized
INFO - 2023-06-09 14:06:18 --> Utf8 Class Initialized
INFO - 2023-06-09 14:06:18 --> URI Class Initialized
INFO - 2023-06-09 14:06:18 --> Router Class Initialized
INFO - 2023-06-09 14:06:18 --> Output Class Initialized
INFO - 2023-06-09 14:06:18 --> Security Class Initialized
INFO - 2023-06-09 14:06:18 --> Input Class Initialized
INFO - 2023-06-09 14:06:18 --> Language Class Initialized
INFO - 2023-06-09 14:06:18 --> Loader Class Initialized
INFO - 2023-06-09 14:06:18 --> Helper loaded: url_helper
INFO - 2023-06-09 14:06:18 --> Helper loaded: form_helper
INFO - 2023-06-09 14:06:18 --> Database Driver Class Initialized
INFO - 2023-06-09 14:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:06:18 --> Form Validation Class Initialized
INFO - 2023-06-09 14:06:18 --> Controller Class Initialized
INFO - 2023-06-09 14:06:18 --> Model "m_datatest" initialized
ERROR - 2023-06-09 14:06:18 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 81
ERROR - 2023-06-09 14:06:18 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 82
ERROR - 2023-06-09 14:06:18 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
INFO - 2023-06-09 14:06:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:06:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:06:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 14:06:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:06:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:06:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:06:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:06:18 --> Final output sent to browser
INFO - 2023-06-09 14:10:22 --> Config Class Initialized
INFO - 2023-06-09 14:10:22 --> Hooks Class Initialized
INFO - 2023-06-09 14:10:22 --> Utf8 Class Initialized
INFO - 2023-06-09 14:10:22 --> URI Class Initialized
INFO - 2023-06-09 14:10:22 --> Router Class Initialized
INFO - 2023-06-09 14:10:22 --> Output Class Initialized
INFO - 2023-06-09 14:10:22 --> Security Class Initialized
INFO - 2023-06-09 14:10:22 --> Input Class Initialized
INFO - 2023-06-09 14:10:22 --> Language Class Initialized
INFO - 2023-06-09 14:10:22 --> Loader Class Initialized
INFO - 2023-06-09 14:10:22 --> Helper loaded: url_helper
INFO - 2023-06-09 14:10:22 --> Helper loaded: form_helper
INFO - 2023-06-09 14:10:22 --> Database Driver Class Initialized
INFO - 2023-06-09 14:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:10:22 --> Form Validation Class Initialized
INFO - 2023-06-09 14:10:22 --> Controller Class Initialized
INFO - 2023-06-09 14:10:22 --> Model "m_datatest" initialized
ERROR - 2023-06-09 14:10:22 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 82
ERROR - 2023-06-09 14:10:22 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
ERROR - 2023-06-09 14:10:22 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 84
INFO - 2023-06-09 14:10:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:10:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:10:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 14:10:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:10:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:10:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:10:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:10:22 --> Final output sent to browser
INFO - 2023-06-09 14:11:53 --> Config Class Initialized
INFO - 2023-06-09 14:11:53 --> Hooks Class Initialized
INFO - 2023-06-09 14:11:53 --> Utf8 Class Initialized
INFO - 2023-06-09 14:11:53 --> URI Class Initialized
INFO - 2023-06-09 14:11:53 --> Router Class Initialized
INFO - 2023-06-09 14:11:53 --> Output Class Initialized
INFO - 2023-06-09 14:11:53 --> Security Class Initialized
INFO - 2023-06-09 14:11:53 --> Input Class Initialized
INFO - 2023-06-09 14:11:53 --> Language Class Initialized
INFO - 2023-06-09 14:11:53 --> Loader Class Initialized
INFO - 2023-06-09 14:11:53 --> Helper loaded: url_helper
INFO - 2023-06-09 14:11:53 --> Helper loaded: form_helper
INFO - 2023-06-09 14:11:53 --> Database Driver Class Initialized
INFO - 2023-06-09 14:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:11:53 --> Form Validation Class Initialized
INFO - 2023-06-09 14:11:53 --> Controller Class Initialized
INFO - 2023-06-09 14:11:53 --> Model "m_datatest" initialized
ERROR - 2023-06-09 14:11:53 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 82
ERROR - 2023-06-09 14:11:53 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
ERROR - 2023-06-09 14:11:53 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 84
INFO - 2023-06-09 14:11:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:11:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:11:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 14:11:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:11:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:11:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:11:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:11:53 --> Final output sent to browser
INFO - 2023-06-09 14:12:18 --> Config Class Initialized
INFO - 2023-06-09 14:12:18 --> Hooks Class Initialized
INFO - 2023-06-09 14:12:18 --> Utf8 Class Initialized
INFO - 2023-06-09 14:12:18 --> URI Class Initialized
INFO - 2023-06-09 14:12:18 --> Router Class Initialized
INFO - 2023-06-09 14:12:18 --> Output Class Initialized
INFO - 2023-06-09 14:12:19 --> Security Class Initialized
INFO - 2023-06-09 14:12:19 --> Input Class Initialized
INFO - 2023-06-09 14:12:19 --> Language Class Initialized
INFO - 2023-06-09 14:12:19 --> Loader Class Initialized
INFO - 2023-06-09 14:12:19 --> Helper loaded: url_helper
INFO - 2023-06-09 14:12:19 --> Helper loaded: form_helper
INFO - 2023-06-09 14:12:19 --> Database Driver Class Initialized
INFO - 2023-06-09 14:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:12:19 --> Form Validation Class Initialized
INFO - 2023-06-09 14:12:19 --> Controller Class Initialized
INFO - 2023-06-09 14:12:19 --> Model "m_datatest" initialized
ERROR - 2023-06-09 14:12:19 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 82
ERROR - 2023-06-09 14:12:19 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
ERROR - 2023-06-09 14:12:19 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 84
INFO - 2023-06-09 14:12:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:12:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:12:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 14:12:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:12:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:12:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:12:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:12:19 --> Final output sent to browser
INFO - 2023-06-09 14:13:32 --> Config Class Initialized
INFO - 2023-06-09 14:13:32 --> Hooks Class Initialized
INFO - 2023-06-09 14:13:32 --> Utf8 Class Initialized
INFO - 2023-06-09 14:13:32 --> URI Class Initialized
INFO - 2023-06-09 14:13:32 --> Router Class Initialized
INFO - 2023-06-09 14:13:32 --> Output Class Initialized
INFO - 2023-06-09 14:13:32 --> Security Class Initialized
INFO - 2023-06-09 14:13:32 --> Input Class Initialized
INFO - 2023-06-09 14:13:32 --> Language Class Initialized
INFO - 2023-06-09 14:13:32 --> Loader Class Initialized
INFO - 2023-06-09 14:13:32 --> Helper loaded: url_helper
INFO - 2023-06-09 14:13:32 --> Helper loaded: form_helper
INFO - 2023-06-09 14:13:32 --> Database Driver Class Initialized
INFO - 2023-06-09 14:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:13:32 --> Form Validation Class Initialized
INFO - 2023-06-09 14:13:32 --> Controller Class Initialized
INFO - 2023-06-09 14:13:32 --> Model "m_datatest" initialized
ERROR - 2023-06-09 14:13:32 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 82
ERROR - 2023-06-09 14:13:32 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
ERROR - 2023-06-09 14:13:32 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 84
INFO - 2023-06-09 14:13:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:13:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:13:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 14:13:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:13:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:13:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:13:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:13:32 --> Final output sent to browser
INFO - 2023-06-09 14:13:49 --> Config Class Initialized
INFO - 2023-06-09 14:13:49 --> Hooks Class Initialized
INFO - 2023-06-09 14:13:49 --> Utf8 Class Initialized
INFO - 2023-06-09 14:13:49 --> URI Class Initialized
INFO - 2023-06-09 14:13:49 --> Router Class Initialized
INFO - 2023-06-09 14:13:49 --> Output Class Initialized
INFO - 2023-06-09 14:13:49 --> Security Class Initialized
INFO - 2023-06-09 14:13:49 --> Input Class Initialized
INFO - 2023-06-09 14:13:49 --> Language Class Initialized
INFO - 2023-06-09 14:13:49 --> Loader Class Initialized
INFO - 2023-06-09 14:13:49 --> Helper loaded: url_helper
INFO - 2023-06-09 14:13:49 --> Helper loaded: form_helper
INFO - 2023-06-09 14:13:49 --> Database Driver Class Initialized
INFO - 2023-06-09 14:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:13:49 --> Form Validation Class Initialized
INFO - 2023-06-09 14:13:49 --> Controller Class Initialized
INFO - 2023-06-09 14:13:49 --> Model "m_datatest" initialized
ERROR - 2023-06-09 14:13:49 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 82
ERROR - 2023-06-09 14:13:49 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
ERROR - 2023-06-09 14:13:49 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 84
INFO - 2023-06-09 14:13:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:13:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:13:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 14:13:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:13:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:13:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:13:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:13:49 --> Final output sent to browser
INFO - 2023-06-09 14:14:13 --> Config Class Initialized
INFO - 2023-06-09 14:14:13 --> Hooks Class Initialized
INFO - 2023-06-09 14:14:13 --> Utf8 Class Initialized
INFO - 2023-06-09 14:14:13 --> URI Class Initialized
INFO - 2023-06-09 14:14:13 --> Router Class Initialized
INFO - 2023-06-09 14:14:13 --> Output Class Initialized
INFO - 2023-06-09 14:14:13 --> Security Class Initialized
INFO - 2023-06-09 14:14:13 --> Input Class Initialized
INFO - 2023-06-09 14:14:13 --> Language Class Initialized
INFO - 2023-06-09 14:14:13 --> Loader Class Initialized
INFO - 2023-06-09 14:14:13 --> Helper loaded: url_helper
INFO - 2023-06-09 14:14:13 --> Helper loaded: form_helper
INFO - 2023-06-09 14:14:13 --> Database Driver Class Initialized
INFO - 2023-06-09 14:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:14:13 --> Form Validation Class Initialized
INFO - 2023-06-09 14:14:13 --> Controller Class Initialized
INFO - 2023-06-09 14:14:13 --> Model "m_datatest" initialized
ERROR - 2023-06-09 14:14:13 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 82
ERROR - 2023-06-09 14:14:13 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
ERROR - 2023-06-09 14:14:13 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 84
INFO - 2023-06-09 14:14:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:14:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:14:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 14:14:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:14:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:14:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:14:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:14:13 --> Final output sent to browser
INFO - 2023-06-09 14:14:50 --> Config Class Initialized
INFO - 2023-06-09 14:14:50 --> Hooks Class Initialized
INFO - 2023-06-09 14:14:50 --> Utf8 Class Initialized
INFO - 2023-06-09 14:14:50 --> URI Class Initialized
INFO - 2023-06-09 14:14:50 --> Router Class Initialized
INFO - 2023-06-09 14:14:50 --> Output Class Initialized
INFO - 2023-06-09 14:14:50 --> Security Class Initialized
INFO - 2023-06-09 14:14:50 --> Input Class Initialized
INFO - 2023-06-09 14:14:50 --> Language Class Initialized
INFO - 2023-06-09 14:14:50 --> Loader Class Initialized
INFO - 2023-06-09 14:14:50 --> Helper loaded: url_helper
INFO - 2023-06-09 14:14:50 --> Helper loaded: form_helper
INFO - 2023-06-09 14:14:50 --> Database Driver Class Initialized
INFO - 2023-06-09 14:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 14:14:50 --> Form Validation Class Initialized
INFO - 2023-06-09 14:14:50 --> Controller Class Initialized
INFO - 2023-06-09 14:14:50 --> Model "m_datatest" initialized
ERROR - 2023-06-09 14:14:50 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 82
ERROR - 2023-06-09 14:14:50 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
ERROR - 2023-06-09 14:14:50 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 84
INFO - 2023-06-09 14:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 14:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 14:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 14:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 14:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 14:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 14:14:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 14:14:50 --> Final output sent to browser
INFO - 2023-06-09 15:55:36 --> Config Class Initialized
INFO - 2023-06-09 15:55:36 --> Hooks Class Initialized
INFO - 2023-06-09 15:55:36 --> Utf8 Class Initialized
INFO - 2023-06-09 15:55:36 --> URI Class Initialized
INFO - 2023-06-09 15:55:36 --> Router Class Initialized
INFO - 2023-06-09 15:55:36 --> Output Class Initialized
INFO - 2023-06-09 15:55:36 --> Security Class Initialized
INFO - 2023-06-09 15:55:36 --> Input Class Initialized
INFO - 2023-06-09 15:55:36 --> Language Class Initialized
INFO - 2023-06-09 15:55:36 --> Loader Class Initialized
INFO - 2023-06-09 15:55:36 --> Helper loaded: url_helper
INFO - 2023-06-09 15:55:36 --> Helper loaded: form_helper
INFO - 2023-06-09 15:55:36 --> Database Driver Class Initialized
INFO - 2023-06-09 15:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 15:55:36 --> Form Validation Class Initialized
INFO - 2023-06-09 15:55:36 --> Controller Class Initialized
INFO - 2023-06-09 15:55:36 --> Model "m_datatest" initialized
ERROR - 2023-06-09 15:55:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
ERROR - 2023-06-09 15:55:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 84
ERROR - 2023-06-09 15:55:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 85
ERROR - 2023-06-09 15:55:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 90
ERROR - 2023-06-09 15:55:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 91
ERROR - 2023-06-09 15:55:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 93
INFO - 2023-06-09 15:55:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 15:55:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 15:55:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 15:55:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 15:55:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 15:55:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 15:55:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 15:55:36 --> Final output sent to browser
INFO - 2023-06-09 16:08:43 --> Config Class Initialized
INFO - 2023-06-09 16:08:43 --> Hooks Class Initialized
INFO - 2023-06-09 16:08:43 --> Utf8 Class Initialized
INFO - 2023-06-09 16:08:43 --> URI Class Initialized
INFO - 2023-06-09 16:08:43 --> Router Class Initialized
INFO - 2023-06-09 16:08:43 --> Output Class Initialized
INFO - 2023-06-09 16:08:43 --> Security Class Initialized
INFO - 2023-06-09 16:08:43 --> Input Class Initialized
INFO - 2023-06-09 16:08:43 --> Language Class Initialized
INFO - 2023-06-09 16:08:43 --> Loader Class Initialized
INFO - 2023-06-09 16:08:43 --> Helper loaded: url_helper
INFO - 2023-06-09 16:08:43 --> Helper loaded: form_helper
INFO - 2023-06-09 16:08:43 --> Database Driver Class Initialized
INFO - 2023-06-09 16:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 16:08:43 --> Form Validation Class Initialized
INFO - 2023-06-09 16:08:43 --> Controller Class Initialized
INFO - 2023-06-09 16:08:43 --> Model "m_datatest" initialized
ERROR - 2023-06-09 16:08:43 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
ERROR - 2023-06-09 16:08:43 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 84
ERROR - 2023-06-09 16:08:43 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 85
ERROR - 2023-06-09 16:08:43 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 90
ERROR - 2023-06-09 16:08:43 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 91
ERROR - 2023-06-09 16:08:43 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 93
INFO - 2023-06-09 16:08:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 16:08:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 16:08:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 16:08:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 16:08:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 16:08:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 16:08:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 16:08:43 --> Final output sent to browser
INFO - 2023-06-09 16:11:36 --> Config Class Initialized
INFO - 2023-06-09 16:11:36 --> Hooks Class Initialized
INFO - 2023-06-09 16:11:36 --> Utf8 Class Initialized
INFO - 2023-06-09 16:11:36 --> URI Class Initialized
INFO - 2023-06-09 16:11:36 --> Router Class Initialized
INFO - 2023-06-09 16:11:36 --> Output Class Initialized
INFO - 2023-06-09 16:11:36 --> Security Class Initialized
INFO - 2023-06-09 16:11:36 --> Input Class Initialized
INFO - 2023-06-09 16:11:36 --> Language Class Initialized
INFO - 2023-06-09 16:11:36 --> Loader Class Initialized
INFO - 2023-06-09 16:11:36 --> Helper loaded: url_helper
INFO - 2023-06-09 16:11:36 --> Helper loaded: form_helper
INFO - 2023-06-09 16:11:36 --> Database Driver Class Initialized
INFO - 2023-06-09 16:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-09 16:11:36 --> Form Validation Class Initialized
INFO - 2023-06-09 16:11:36 --> Controller Class Initialized
INFO - 2023-06-09 16:11:36 --> Model "m_datatest" initialized
ERROR - 2023-06-09 16:11:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 83
ERROR - 2023-06-09 16:11:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 84
ERROR - 2023-06-09 16:11:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 85
ERROR - 2023-06-09 16:11:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 90
ERROR - 2023-06-09 16:11:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 91
ERROR - 2023-06-09 16:11:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 93
INFO - 2023-06-09 16:11:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-09 16:11:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-09 16:11:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-09 16:11:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-09 16:11:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-09 16:11:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-09 16:11:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-09 16:11:36 --> Final output sent to browser
