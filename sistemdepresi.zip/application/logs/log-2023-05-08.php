<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-08 16:16:35 --> Config Class Initialized
INFO - 2023-05-08 16:16:35 --> Hooks Class Initialized
INFO - 2023-05-08 16:16:36 --> Utf8 Class Initialized
INFO - 2023-05-08 16:16:36 --> URI Class Initialized
INFO - 2023-05-08 16:16:36 --> Router Class Initialized
INFO - 2023-05-08 16:16:36 --> Output Class Initialized
INFO - 2023-05-08 16:16:36 --> Security Class Initialized
INFO - 2023-05-08 16:16:36 --> Input Class Initialized
INFO - 2023-05-08 16:16:36 --> Language Class Initialized
INFO - 2023-05-08 16:16:36 --> Loader Class Initialized
INFO - 2023-05-08 16:16:36 --> Helper loaded: url_helper
INFO - 2023-05-08 16:16:36 --> Helper loaded: form_helper
INFO - 2023-05-08 16:16:36 --> Database Driver Class Initialized
INFO - 2023-05-08 16:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:16:37 --> Form Validation Class Initialized
INFO - 2023-05-08 16:16:37 --> Controller Class Initialized
INFO - 2023-05-08 16:16:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 16:16:37 --> Final output sent to browser
INFO - 2023-05-08 16:16:38 --> Config Class Initialized
INFO - 2023-05-08 16:16:38 --> Hooks Class Initialized
INFO - 2023-05-08 16:16:39 --> Utf8 Class Initialized
INFO - 2023-05-08 16:16:39 --> URI Class Initialized
INFO - 2023-05-08 16:16:39 --> Router Class Initialized
INFO - 2023-05-08 16:16:39 --> Output Class Initialized
INFO - 2023-05-08 16:16:39 --> Security Class Initialized
INFO - 2023-05-08 16:16:39 --> Input Class Initialized
INFO - 2023-05-08 16:16:39 --> Language Class Initialized
INFO - 2023-05-08 16:16:39 --> Loader Class Initialized
INFO - 2023-05-08 16:16:39 --> Helper loaded: url_helper
INFO - 2023-05-08 16:16:39 --> Helper loaded: form_helper
INFO - 2023-05-08 16:16:39 --> Database Driver Class Initialized
INFO - 2023-05-08 16:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:16:39 --> Form Validation Class Initialized
INFO - 2023-05-08 16:16:39 --> Controller Class Initialized
INFO - 2023-05-08 16:16:39 --> Model "m_user" initialized
INFO - 2023-05-08 16:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-08 16:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-08 16:16:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-08 16:16:39 --> Final output sent to browser
INFO - 2023-05-08 16:16:49 --> Config Class Initialized
INFO - 2023-05-08 16:16:49 --> Hooks Class Initialized
INFO - 2023-05-08 16:16:49 --> Utf8 Class Initialized
INFO - 2023-05-08 16:16:49 --> URI Class Initialized
INFO - 2023-05-08 16:16:49 --> Router Class Initialized
INFO - 2023-05-08 16:16:49 --> Output Class Initialized
INFO - 2023-05-08 16:16:49 --> Security Class Initialized
INFO - 2023-05-08 16:16:49 --> Input Class Initialized
INFO - 2023-05-08 16:16:49 --> Language Class Initialized
INFO - 2023-05-08 16:16:49 --> Loader Class Initialized
INFO - 2023-05-08 16:16:49 --> Helper loaded: url_helper
INFO - 2023-05-08 16:16:49 --> Helper loaded: form_helper
INFO - 2023-05-08 16:16:49 --> Database Driver Class Initialized
INFO - 2023-05-08 16:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:16:49 --> Form Validation Class Initialized
INFO - 2023-05-08 16:16:49 --> Controller Class Initialized
INFO - 2023-05-08 16:16:49 --> Model "m_user" initialized
INFO - 2023-05-08 16:16:49 --> Config Class Initialized
INFO - 2023-05-08 16:16:49 --> Hooks Class Initialized
INFO - 2023-05-08 16:16:49 --> Utf8 Class Initialized
INFO - 2023-05-08 16:16:49 --> URI Class Initialized
INFO - 2023-05-08 16:16:49 --> Router Class Initialized
INFO - 2023-05-08 16:16:49 --> Output Class Initialized
INFO - 2023-05-08 16:16:49 --> Security Class Initialized
INFO - 2023-05-08 16:16:49 --> Input Class Initialized
INFO - 2023-05-08 16:16:49 --> Language Class Initialized
INFO - 2023-05-08 16:16:49 --> Loader Class Initialized
INFO - 2023-05-08 16:16:49 --> Helper loaded: url_helper
INFO - 2023-05-08 16:16:49 --> Helper loaded: form_helper
INFO - 2023-05-08 16:16:49 --> Database Driver Class Initialized
INFO - 2023-05-08 16:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:16:49 --> Form Validation Class Initialized
INFO - 2023-05-08 16:16:49 --> Controller Class Initialized
INFO - 2023-05-08 16:16:49 --> Model "m_user" initialized
INFO - 2023-05-08 16:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 16:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 16:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 16:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 16:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 16:16:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-08 16:16:49 --> Final output sent to browser
INFO - 2023-05-08 16:16:52 --> Config Class Initialized
INFO - 2023-05-08 16:16:52 --> Hooks Class Initialized
INFO - 2023-05-08 16:16:52 --> Utf8 Class Initialized
INFO - 2023-05-08 16:16:52 --> URI Class Initialized
INFO - 2023-05-08 16:16:52 --> Router Class Initialized
INFO - 2023-05-08 16:16:52 --> Output Class Initialized
INFO - 2023-05-08 16:16:52 --> Security Class Initialized
INFO - 2023-05-08 16:16:52 --> Input Class Initialized
INFO - 2023-05-08 16:16:52 --> Language Class Initialized
INFO - 2023-05-08 16:16:52 --> Loader Class Initialized
INFO - 2023-05-08 16:16:52 --> Helper loaded: url_helper
INFO - 2023-05-08 16:16:52 --> Helper loaded: form_helper
INFO - 2023-05-08 16:16:52 --> Database Driver Class Initialized
INFO - 2023-05-08 16:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:16:52 --> Form Validation Class Initialized
INFO - 2023-05-08 16:16:52 --> Controller Class Initialized
INFO - 2023-05-08 16:16:52 --> Model "m_datatrain" initialized
INFO - 2023-05-08 16:16:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 16:16:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 16:16:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 16:16:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 16:16:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 16:16:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 16:16:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 16:16:52 --> Final output sent to browser
INFO - 2023-05-08 16:17:47 --> Config Class Initialized
INFO - 2023-05-08 16:17:47 --> Hooks Class Initialized
INFO - 2023-05-08 16:17:47 --> Utf8 Class Initialized
INFO - 2023-05-08 16:17:47 --> URI Class Initialized
INFO - 2023-05-08 16:17:47 --> Router Class Initialized
INFO - 2023-05-08 16:17:47 --> Output Class Initialized
INFO - 2023-05-08 16:17:47 --> Security Class Initialized
INFO - 2023-05-08 16:17:47 --> Input Class Initialized
INFO - 2023-05-08 16:17:47 --> Language Class Initialized
INFO - 2023-05-08 16:17:47 --> Loader Class Initialized
INFO - 2023-05-08 16:17:47 --> Helper loaded: url_helper
INFO - 2023-05-08 16:17:47 --> Helper loaded: form_helper
INFO - 2023-05-08 16:17:47 --> Database Driver Class Initialized
INFO - 2023-05-08 16:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:17:47 --> Form Validation Class Initialized
INFO - 2023-05-08 16:17:47 --> Controller Class Initialized
INFO - 2023-05-08 16:17:47 --> Model "m_datatrain" initialized
INFO - 2023-05-08 16:17:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 16:17:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 16:17:56 --> Config Class Initialized
INFO - 2023-05-08 16:17:56 --> Hooks Class Initialized
INFO - 2023-05-08 16:17:56 --> Utf8 Class Initialized
INFO - 2023-05-08 16:17:56 --> URI Class Initialized
INFO - 2023-05-08 16:17:56 --> Router Class Initialized
INFO - 2023-05-08 16:17:56 --> Output Class Initialized
INFO - 2023-05-08 16:17:56 --> Security Class Initialized
INFO - 2023-05-08 16:17:56 --> Input Class Initialized
INFO - 2023-05-08 16:17:56 --> Language Class Initialized
INFO - 2023-05-08 16:17:56 --> Loader Class Initialized
INFO - 2023-05-08 16:17:56 --> Helper loaded: url_helper
INFO - 2023-05-08 16:17:56 --> Helper loaded: form_helper
INFO - 2023-05-08 16:17:56 --> Database Driver Class Initialized
INFO - 2023-05-08 16:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:17:56 --> Form Validation Class Initialized
INFO - 2023-05-08 16:17:56 --> Controller Class Initialized
INFO - 2023-05-08 16:17:56 --> Model "m_datatrain" initialized
INFO - 2023-05-08 16:17:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 16:17:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 16:17:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 16:17:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 16:17:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 16:17:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 16:17:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 16:17:57 --> Final output sent to browser
INFO - 2023-05-08 16:18:03 --> Config Class Initialized
INFO - 2023-05-08 16:18:03 --> Hooks Class Initialized
INFO - 2023-05-08 16:18:03 --> Utf8 Class Initialized
INFO - 2023-05-08 16:18:03 --> URI Class Initialized
INFO - 2023-05-08 16:18:03 --> Router Class Initialized
INFO - 2023-05-08 16:18:03 --> Output Class Initialized
INFO - 2023-05-08 16:18:03 --> Security Class Initialized
INFO - 2023-05-08 16:18:03 --> Input Class Initialized
INFO - 2023-05-08 16:18:03 --> Language Class Initialized
INFO - 2023-05-08 16:18:03 --> Loader Class Initialized
INFO - 2023-05-08 16:18:03 --> Helper loaded: url_helper
INFO - 2023-05-08 16:18:03 --> Helper loaded: form_helper
INFO - 2023-05-08 16:18:03 --> Database Driver Class Initialized
INFO - 2023-05-08 16:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:18:03 --> Form Validation Class Initialized
INFO - 2023-05-08 16:18:03 --> Controller Class Initialized
INFO - 2023-05-08 16:18:03 --> Model "m_user" initialized
INFO - 2023-05-08 16:18:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 16:18:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 16:18:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 16:18:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 16:18:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 16:18:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-08 16:18:03 --> Final output sent to browser
INFO - 2023-05-08 16:21:28 --> Config Class Initialized
INFO - 2023-05-08 16:21:28 --> Hooks Class Initialized
INFO - 2023-05-08 16:21:28 --> Utf8 Class Initialized
INFO - 2023-05-08 16:21:28 --> URI Class Initialized
INFO - 2023-05-08 16:21:28 --> Router Class Initialized
INFO - 2023-05-08 16:21:28 --> Output Class Initialized
INFO - 2023-05-08 16:21:28 --> Security Class Initialized
INFO - 2023-05-08 16:21:28 --> Input Class Initialized
INFO - 2023-05-08 16:21:28 --> Language Class Initialized
INFO - 2023-05-08 16:21:28 --> Loader Class Initialized
INFO - 2023-05-08 16:21:28 --> Helper loaded: url_helper
INFO - 2023-05-08 16:21:28 --> Helper loaded: form_helper
INFO - 2023-05-08 16:21:28 --> Database Driver Class Initialized
INFO - 2023-05-08 16:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:21:28 --> Form Validation Class Initialized
INFO - 2023-05-08 16:21:28 --> Controller Class Initialized
INFO - 2023-05-08 16:21:28 --> Model "m_user" initialized
INFO - 2023-05-08 16:21:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 16:21:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 16:21:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 16:21:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 16:21:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 16:21:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 16:21:28 --> Final output sent to browser
INFO - 2023-05-08 16:21:31 --> Config Class Initialized
INFO - 2023-05-08 16:21:31 --> Hooks Class Initialized
INFO - 2023-05-08 16:21:31 --> Utf8 Class Initialized
INFO - 2023-05-08 16:21:31 --> URI Class Initialized
INFO - 2023-05-08 16:21:31 --> Router Class Initialized
INFO - 2023-05-08 16:21:31 --> Output Class Initialized
INFO - 2023-05-08 16:21:31 --> Security Class Initialized
INFO - 2023-05-08 16:21:31 --> Input Class Initialized
INFO - 2023-05-08 16:21:31 --> Language Class Initialized
INFO - 2023-05-08 16:21:31 --> Loader Class Initialized
INFO - 2023-05-08 16:21:31 --> Helper loaded: url_helper
INFO - 2023-05-08 16:21:31 --> Helper loaded: form_helper
INFO - 2023-05-08 16:21:31 --> Database Driver Class Initialized
INFO - 2023-05-08 16:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:21:32 --> Form Validation Class Initialized
INFO - 2023-05-08 16:21:32 --> Controller Class Initialized
INFO - 2023-05-08 16:21:32 --> Model "m_user" initialized
INFO - 2023-05-08 16:21:32 --> Config Class Initialized
INFO - 2023-05-08 16:21:32 --> Hooks Class Initialized
INFO - 2023-05-08 16:21:32 --> Utf8 Class Initialized
INFO - 2023-05-08 16:21:32 --> URI Class Initialized
INFO - 2023-05-08 16:21:32 --> Router Class Initialized
INFO - 2023-05-08 16:21:32 --> Output Class Initialized
INFO - 2023-05-08 16:21:32 --> Security Class Initialized
INFO - 2023-05-08 16:21:32 --> Input Class Initialized
INFO - 2023-05-08 16:21:32 --> Language Class Initialized
INFO - 2023-05-08 16:21:32 --> Loader Class Initialized
INFO - 2023-05-08 16:21:32 --> Helper loaded: url_helper
INFO - 2023-05-08 16:21:32 --> Helper loaded: form_helper
INFO - 2023-05-08 16:21:32 --> Database Driver Class Initialized
INFO - 2023-05-08 16:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:21:32 --> Form Validation Class Initialized
INFO - 2023-05-08 16:21:32 --> Controller Class Initialized
INFO - 2023-05-08 16:21:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 16:21:32 --> Final output sent to browser
INFO - 2023-05-08 16:21:33 --> Config Class Initialized
INFO - 2023-05-08 16:21:33 --> Hooks Class Initialized
INFO - 2023-05-08 16:21:33 --> Utf8 Class Initialized
INFO - 2023-05-08 16:21:33 --> URI Class Initialized
INFO - 2023-05-08 16:21:33 --> Router Class Initialized
INFO - 2023-05-08 16:21:33 --> Output Class Initialized
INFO - 2023-05-08 16:21:33 --> Security Class Initialized
INFO - 2023-05-08 16:21:33 --> Input Class Initialized
INFO - 2023-05-08 16:21:33 --> Language Class Initialized
INFO - 2023-05-08 16:21:33 --> Loader Class Initialized
INFO - 2023-05-08 16:21:33 --> Helper loaded: url_helper
INFO - 2023-05-08 16:21:33 --> Helper loaded: form_helper
INFO - 2023-05-08 16:21:33 --> Database Driver Class Initialized
INFO - 2023-05-08 16:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:21:33 --> Form Validation Class Initialized
INFO - 2023-05-08 16:21:33 --> Controller Class Initialized
INFO - 2023-05-08 16:21:33 --> Model "m_user" initialized
INFO - 2023-05-08 16:21:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 16:21:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 16:21:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-08 16:21:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 16:21:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 16:21:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-08 16:21:33 --> Final output sent to browser
INFO - 2023-05-08 16:21:39 --> Config Class Initialized
INFO - 2023-05-08 16:21:39 --> Hooks Class Initialized
INFO - 2023-05-08 16:21:39 --> Utf8 Class Initialized
INFO - 2023-05-08 16:21:39 --> URI Class Initialized
INFO - 2023-05-08 16:21:40 --> Router Class Initialized
INFO - 2023-05-08 16:21:40 --> Output Class Initialized
INFO - 2023-05-08 16:21:40 --> Security Class Initialized
INFO - 2023-05-08 16:21:40 --> Input Class Initialized
INFO - 2023-05-08 16:21:40 --> Language Class Initialized
INFO - 2023-05-08 16:21:40 --> Loader Class Initialized
INFO - 2023-05-08 16:21:40 --> Helper loaded: url_helper
INFO - 2023-05-08 16:21:40 --> Helper loaded: form_helper
INFO - 2023-05-08 16:21:40 --> Database Driver Class Initialized
INFO - 2023-05-08 16:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:21:40 --> Form Validation Class Initialized
INFO - 2023-05-08 16:21:40 --> Controller Class Initialized
INFO - 2023-05-08 16:21:40 --> Model "m_user" initialized
INFO - 2023-05-08 16:21:40 --> Config Class Initialized
INFO - 2023-05-08 16:21:40 --> Hooks Class Initialized
INFO - 2023-05-08 16:21:40 --> Utf8 Class Initialized
INFO - 2023-05-08 16:21:40 --> URI Class Initialized
INFO - 2023-05-08 16:21:40 --> Router Class Initialized
INFO - 2023-05-08 16:21:40 --> Output Class Initialized
INFO - 2023-05-08 16:21:40 --> Security Class Initialized
INFO - 2023-05-08 16:21:40 --> Input Class Initialized
INFO - 2023-05-08 16:21:40 --> Language Class Initialized
INFO - 2023-05-08 16:21:40 --> Loader Class Initialized
INFO - 2023-05-08 16:21:40 --> Helper loaded: url_helper
INFO - 2023-05-08 16:21:40 --> Helper loaded: form_helper
INFO - 2023-05-08 16:21:40 --> Database Driver Class Initialized
INFO - 2023-05-08 16:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:21:40 --> Form Validation Class Initialized
INFO - 2023-05-08 16:21:40 --> Controller Class Initialized
INFO - 2023-05-08 16:21:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 16:21:40 --> Final output sent to browser
INFO - 2023-05-08 16:21:41 --> Config Class Initialized
INFO - 2023-05-08 16:21:41 --> Hooks Class Initialized
INFO - 2023-05-08 16:21:41 --> Utf8 Class Initialized
INFO - 2023-05-08 16:21:41 --> URI Class Initialized
INFO - 2023-05-08 16:21:41 --> Router Class Initialized
INFO - 2023-05-08 16:21:41 --> Output Class Initialized
INFO - 2023-05-08 16:21:41 --> Security Class Initialized
INFO - 2023-05-08 16:21:41 --> Input Class Initialized
INFO - 2023-05-08 16:21:41 --> Language Class Initialized
INFO - 2023-05-08 16:21:41 --> Loader Class Initialized
INFO - 2023-05-08 16:21:41 --> Helper loaded: url_helper
INFO - 2023-05-08 16:21:41 --> Helper loaded: form_helper
INFO - 2023-05-08 16:21:41 --> Database Driver Class Initialized
INFO - 2023-05-08 16:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:21:41 --> Form Validation Class Initialized
INFO - 2023-05-08 16:21:41 --> Controller Class Initialized
INFO - 2023-05-08 16:21:41 --> Model "m_user" initialized
INFO - 2023-05-08 16:21:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-08 16:21:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-08 16:21:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-08 16:21:41 --> Final output sent to browser
INFO - 2023-05-08 16:21:44 --> Config Class Initialized
INFO - 2023-05-08 16:21:44 --> Hooks Class Initialized
INFO - 2023-05-08 16:21:44 --> Utf8 Class Initialized
INFO - 2023-05-08 16:21:44 --> URI Class Initialized
INFO - 2023-05-08 16:21:44 --> Router Class Initialized
INFO - 2023-05-08 16:21:44 --> Output Class Initialized
INFO - 2023-05-08 16:21:44 --> Security Class Initialized
INFO - 2023-05-08 16:21:44 --> Input Class Initialized
INFO - 2023-05-08 16:21:44 --> Language Class Initialized
INFO - 2023-05-08 16:21:44 --> Loader Class Initialized
INFO - 2023-05-08 16:21:44 --> Helper loaded: url_helper
INFO - 2023-05-08 16:21:44 --> Helper loaded: form_helper
INFO - 2023-05-08 16:21:44 --> Database Driver Class Initialized
INFO - 2023-05-08 16:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:21:44 --> Form Validation Class Initialized
INFO - 2023-05-08 16:21:44 --> Controller Class Initialized
INFO - 2023-05-08 16:21:44 --> Model "m_user" initialized
INFO - 2023-05-08 16:21:44 --> Config Class Initialized
INFO - 2023-05-08 16:21:44 --> Hooks Class Initialized
INFO - 2023-05-08 16:21:44 --> Utf8 Class Initialized
INFO - 2023-05-08 16:21:44 --> URI Class Initialized
INFO - 2023-05-08 16:21:44 --> Router Class Initialized
INFO - 2023-05-08 16:21:44 --> Output Class Initialized
INFO - 2023-05-08 16:21:44 --> Security Class Initialized
INFO - 2023-05-08 16:21:44 --> Input Class Initialized
INFO - 2023-05-08 16:21:44 --> Language Class Initialized
INFO - 2023-05-08 16:21:44 --> Loader Class Initialized
INFO - 2023-05-08 16:21:44 --> Helper loaded: url_helper
INFO - 2023-05-08 16:21:44 --> Helper loaded: form_helper
INFO - 2023-05-08 16:21:44 --> Database Driver Class Initialized
INFO - 2023-05-08 16:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:21:44 --> Form Validation Class Initialized
INFO - 2023-05-08 16:21:44 --> Controller Class Initialized
INFO - 2023-05-08 16:21:44 --> Model "m_user" initialized
INFO - 2023-05-08 16:21:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 16:21:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 16:21:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 16:21:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 16:21:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 16:21:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 16:21:44 --> Final output sent to browser
INFO - 2023-05-08 16:21:51 --> Config Class Initialized
INFO - 2023-05-08 16:21:51 --> Hooks Class Initialized
INFO - 2023-05-08 16:21:51 --> Utf8 Class Initialized
INFO - 2023-05-08 16:21:51 --> URI Class Initialized
INFO - 2023-05-08 16:21:51 --> Router Class Initialized
INFO - 2023-05-08 16:21:51 --> Output Class Initialized
INFO - 2023-05-08 16:21:51 --> Security Class Initialized
INFO - 2023-05-08 16:21:51 --> Input Class Initialized
INFO - 2023-05-08 16:21:51 --> Language Class Initialized
INFO - 2023-05-08 16:21:51 --> Loader Class Initialized
INFO - 2023-05-08 16:21:51 --> Helper loaded: url_helper
INFO - 2023-05-08 16:21:51 --> Helper loaded: form_helper
INFO - 2023-05-08 16:21:51 --> Database Driver Class Initialized
INFO - 2023-05-08 16:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:21:51 --> Form Validation Class Initialized
INFO - 2023-05-08 16:21:51 --> Controller Class Initialized
INFO - 2023-05-08 16:21:51 --> Model "m_datatrain" initialized
INFO - 2023-05-08 16:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 16:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 16:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 16:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 16:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 16:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 16:21:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 16:21:51 --> Final output sent to browser
INFO - 2023-05-08 16:47:01 --> Config Class Initialized
INFO - 2023-05-08 16:47:01 --> Hooks Class Initialized
INFO - 2023-05-08 16:47:01 --> Utf8 Class Initialized
INFO - 2023-05-08 16:47:01 --> URI Class Initialized
INFO - 2023-05-08 16:47:01 --> Router Class Initialized
INFO - 2023-05-08 16:47:01 --> Output Class Initialized
INFO - 2023-05-08 16:47:01 --> Security Class Initialized
INFO - 2023-05-08 16:47:01 --> Input Class Initialized
INFO - 2023-05-08 16:47:01 --> Language Class Initialized
INFO - 2023-05-08 16:47:01 --> Loader Class Initialized
INFO - 2023-05-08 16:47:01 --> Helper loaded: url_helper
INFO - 2023-05-08 16:47:01 --> Helper loaded: form_helper
INFO - 2023-05-08 16:47:01 --> Database Driver Class Initialized
INFO - 2023-05-08 16:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:47:01 --> Form Validation Class Initialized
INFO - 2023-05-08 16:47:01 --> Controller Class Initialized
INFO - 2023-05-08 16:47:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 16:47:01 --> Final output sent to browser
INFO - 2023-05-08 17:35:25 --> Config Class Initialized
INFO - 2023-05-08 17:35:25 --> Hooks Class Initialized
INFO - 2023-05-08 17:35:25 --> Utf8 Class Initialized
INFO - 2023-05-08 17:35:25 --> URI Class Initialized
INFO - 2023-05-08 17:35:25 --> Router Class Initialized
INFO - 2023-05-08 17:35:25 --> Output Class Initialized
INFO - 2023-05-08 17:35:25 --> Security Class Initialized
INFO - 2023-05-08 17:35:25 --> Input Class Initialized
INFO - 2023-05-08 17:35:25 --> Language Class Initialized
INFO - 2023-05-08 17:35:25 --> Loader Class Initialized
INFO - 2023-05-08 17:35:25 --> Helper loaded: url_helper
INFO - 2023-05-08 17:35:25 --> Helper loaded: form_helper
INFO - 2023-05-08 17:35:25 --> Database Driver Class Initialized
INFO - 2023-05-08 17:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:35:25 --> Form Validation Class Initialized
INFO - 2023-05-08 17:35:25 --> Controller Class Initialized
INFO - 2023-05-08 17:35:25 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:35:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:35:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:35:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 17:35:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:35:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:35:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:35:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:35:25 --> Final output sent to browser
INFO - 2023-05-08 17:35:26 --> Config Class Initialized
INFO - 2023-05-08 17:35:26 --> Hooks Class Initialized
INFO - 2023-05-08 17:35:26 --> Utf8 Class Initialized
INFO - 2023-05-08 17:35:26 --> URI Class Initialized
INFO - 2023-05-08 17:35:26 --> Router Class Initialized
INFO - 2023-05-08 17:35:26 --> Output Class Initialized
INFO - 2023-05-08 17:35:26 --> Security Class Initialized
INFO - 2023-05-08 17:35:26 --> Input Class Initialized
INFO - 2023-05-08 17:35:26 --> Language Class Initialized
INFO - 2023-05-08 17:35:26 --> Loader Class Initialized
INFO - 2023-05-08 17:35:26 --> Helper loaded: url_helper
INFO - 2023-05-08 17:35:26 --> Helper loaded: form_helper
INFO - 2023-05-08 17:35:26 --> Database Driver Class Initialized
INFO - 2023-05-08 17:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:35:27 --> Form Validation Class Initialized
INFO - 2023-05-08 17:35:27 --> Controller Class Initialized
INFO - 2023-05-08 17:35:27 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:35:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:35:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:35:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:35:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:35:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:35:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:35:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:35:27 --> Final output sent to browser
INFO - 2023-05-08 17:35:45 --> Config Class Initialized
INFO - 2023-05-08 17:35:45 --> Hooks Class Initialized
INFO - 2023-05-08 17:35:45 --> Utf8 Class Initialized
INFO - 2023-05-08 17:35:45 --> URI Class Initialized
INFO - 2023-05-08 17:35:45 --> Router Class Initialized
INFO - 2023-05-08 17:35:45 --> Output Class Initialized
INFO - 2023-05-08 17:35:45 --> Security Class Initialized
INFO - 2023-05-08 17:35:45 --> Input Class Initialized
INFO - 2023-05-08 17:35:45 --> Language Class Initialized
INFO - 2023-05-08 17:35:45 --> Loader Class Initialized
INFO - 2023-05-08 17:35:45 --> Helper loaded: url_helper
INFO - 2023-05-08 17:35:45 --> Helper loaded: form_helper
INFO - 2023-05-08 17:35:45 --> Database Driver Class Initialized
INFO - 2023-05-08 17:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:35:45 --> Form Validation Class Initialized
INFO - 2023-05-08 17:35:45 --> Controller Class Initialized
INFO - 2023-05-08 17:35:45 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:35:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:35:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:35:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:35:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:35:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:35:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:35:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:35:45 --> Final output sent to browser
INFO - 2023-05-08 17:35:52 --> Config Class Initialized
INFO - 2023-05-08 17:35:52 --> Hooks Class Initialized
INFO - 2023-05-08 17:35:52 --> Utf8 Class Initialized
INFO - 2023-05-08 17:35:52 --> URI Class Initialized
INFO - 2023-05-08 17:35:52 --> Router Class Initialized
INFO - 2023-05-08 17:35:52 --> Output Class Initialized
INFO - 2023-05-08 17:35:52 --> Security Class Initialized
INFO - 2023-05-08 17:35:52 --> Input Class Initialized
INFO - 2023-05-08 17:35:52 --> Language Class Initialized
INFO - 2023-05-08 17:35:52 --> Loader Class Initialized
INFO - 2023-05-08 17:35:52 --> Helper loaded: url_helper
INFO - 2023-05-08 17:35:52 --> Helper loaded: form_helper
INFO - 2023-05-08 17:35:52 --> Database Driver Class Initialized
INFO - 2023-05-08 17:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:35:52 --> Form Validation Class Initialized
INFO - 2023-05-08 17:35:52 --> Controller Class Initialized
INFO - 2023-05-08 17:35:52 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:35:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:35:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:35:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 17:35:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:35:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:35:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:35:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:35:52 --> Final output sent to browser
INFO - 2023-05-08 17:35:57 --> Config Class Initialized
INFO - 2023-05-08 17:35:57 --> Hooks Class Initialized
INFO - 2023-05-08 17:35:57 --> Utf8 Class Initialized
INFO - 2023-05-08 17:35:57 --> URI Class Initialized
INFO - 2023-05-08 17:35:57 --> Router Class Initialized
INFO - 2023-05-08 17:35:57 --> Output Class Initialized
INFO - 2023-05-08 17:35:57 --> Security Class Initialized
INFO - 2023-05-08 17:35:57 --> Input Class Initialized
INFO - 2023-05-08 17:35:57 --> Language Class Initialized
INFO - 2023-05-08 17:35:57 --> Loader Class Initialized
INFO - 2023-05-08 17:35:57 --> Helper loaded: url_helper
INFO - 2023-05-08 17:35:57 --> Helper loaded: form_helper
INFO - 2023-05-08 17:35:57 --> Database Driver Class Initialized
INFO - 2023-05-08 17:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:35:57 --> Form Validation Class Initialized
INFO - 2023-05-08 17:35:57 --> Controller Class Initialized
INFO - 2023-05-08 17:35:57 --> Model "m_user" initialized
INFO - 2023-05-08 17:35:57 --> Config Class Initialized
INFO - 2023-05-08 17:35:57 --> Hooks Class Initialized
INFO - 2023-05-08 17:35:57 --> Utf8 Class Initialized
INFO - 2023-05-08 17:35:57 --> URI Class Initialized
INFO - 2023-05-08 17:35:57 --> Router Class Initialized
INFO - 2023-05-08 17:35:57 --> Output Class Initialized
INFO - 2023-05-08 17:35:57 --> Security Class Initialized
INFO - 2023-05-08 17:35:57 --> Input Class Initialized
INFO - 2023-05-08 17:35:57 --> Language Class Initialized
INFO - 2023-05-08 17:35:57 --> Loader Class Initialized
INFO - 2023-05-08 17:35:57 --> Helper loaded: url_helper
INFO - 2023-05-08 17:35:57 --> Helper loaded: form_helper
INFO - 2023-05-08 17:35:57 --> Database Driver Class Initialized
INFO - 2023-05-08 17:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:35:57 --> Form Validation Class Initialized
INFO - 2023-05-08 17:35:57 --> Controller Class Initialized
INFO - 2023-05-08 17:35:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 17:35:57 --> Final output sent to browser
INFO - 2023-05-08 17:35:59 --> Config Class Initialized
INFO - 2023-05-08 17:35:59 --> Hooks Class Initialized
INFO - 2023-05-08 17:35:59 --> Utf8 Class Initialized
INFO - 2023-05-08 17:35:59 --> URI Class Initialized
INFO - 2023-05-08 17:35:59 --> Router Class Initialized
INFO - 2023-05-08 17:35:59 --> Output Class Initialized
INFO - 2023-05-08 17:35:59 --> Security Class Initialized
INFO - 2023-05-08 17:35:59 --> Input Class Initialized
INFO - 2023-05-08 17:35:59 --> Language Class Initialized
INFO - 2023-05-08 17:35:59 --> Loader Class Initialized
INFO - 2023-05-08 17:35:59 --> Helper loaded: url_helper
INFO - 2023-05-08 17:35:59 --> Helper loaded: form_helper
INFO - 2023-05-08 17:35:59 --> Database Driver Class Initialized
INFO - 2023-05-08 17:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:35:59 --> Form Validation Class Initialized
INFO - 2023-05-08 17:35:59 --> Controller Class Initialized
INFO - 2023-05-08 17:35:59 --> Model "m_user" initialized
INFO - 2023-05-08 17:35:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-08 17:35:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-08 17:35:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-08 17:35:59 --> Final output sent to browser
INFO - 2023-05-08 17:36:03 --> Config Class Initialized
INFO - 2023-05-08 17:36:03 --> Hooks Class Initialized
INFO - 2023-05-08 17:36:03 --> Utf8 Class Initialized
INFO - 2023-05-08 17:36:03 --> URI Class Initialized
INFO - 2023-05-08 17:36:03 --> Router Class Initialized
INFO - 2023-05-08 17:36:03 --> Output Class Initialized
INFO - 2023-05-08 17:36:03 --> Security Class Initialized
INFO - 2023-05-08 17:36:03 --> Input Class Initialized
INFO - 2023-05-08 17:36:03 --> Language Class Initialized
INFO - 2023-05-08 17:36:03 --> Loader Class Initialized
INFO - 2023-05-08 17:36:03 --> Helper loaded: url_helper
INFO - 2023-05-08 17:36:03 --> Helper loaded: form_helper
INFO - 2023-05-08 17:36:03 --> Database Driver Class Initialized
INFO - 2023-05-08 17:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:36:03 --> Form Validation Class Initialized
INFO - 2023-05-08 17:36:03 --> Controller Class Initialized
INFO - 2023-05-08 17:36:03 --> Model "m_user" initialized
INFO - 2023-05-08 17:36:03 --> Config Class Initialized
INFO - 2023-05-08 17:36:03 --> Hooks Class Initialized
INFO - 2023-05-08 17:36:03 --> Utf8 Class Initialized
INFO - 2023-05-08 17:36:03 --> URI Class Initialized
INFO - 2023-05-08 17:36:03 --> Router Class Initialized
INFO - 2023-05-08 17:36:03 --> Output Class Initialized
INFO - 2023-05-08 17:36:03 --> Security Class Initialized
INFO - 2023-05-08 17:36:03 --> Input Class Initialized
INFO - 2023-05-08 17:36:03 --> Language Class Initialized
INFO - 2023-05-08 17:36:03 --> Loader Class Initialized
INFO - 2023-05-08 17:36:03 --> Helper loaded: url_helper
INFO - 2023-05-08 17:36:03 --> Helper loaded: form_helper
INFO - 2023-05-08 17:36:03 --> Database Driver Class Initialized
INFO - 2023-05-08 17:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:36:03 --> Form Validation Class Initialized
INFO - 2023-05-08 17:36:03 --> Controller Class Initialized
INFO - 2023-05-08 17:36:03 --> Model "m_user" initialized
INFO - 2023-05-08 17:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:36:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 17:36:03 --> Final output sent to browser
INFO - 2023-05-08 17:36:05 --> Config Class Initialized
INFO - 2023-05-08 17:36:05 --> Hooks Class Initialized
INFO - 2023-05-08 17:36:05 --> Utf8 Class Initialized
INFO - 2023-05-08 17:36:05 --> URI Class Initialized
INFO - 2023-05-08 17:36:05 --> Router Class Initialized
INFO - 2023-05-08 17:36:05 --> Output Class Initialized
INFO - 2023-05-08 17:36:05 --> Security Class Initialized
INFO - 2023-05-08 17:36:05 --> Input Class Initialized
INFO - 2023-05-08 17:36:05 --> Language Class Initialized
INFO - 2023-05-08 17:36:05 --> Loader Class Initialized
INFO - 2023-05-08 17:36:05 --> Helper loaded: url_helper
INFO - 2023-05-08 17:36:05 --> Helper loaded: form_helper
INFO - 2023-05-08 17:36:05 --> Database Driver Class Initialized
INFO - 2023-05-08 17:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:36:05 --> Form Validation Class Initialized
INFO - 2023-05-08 17:36:05 --> Controller Class Initialized
INFO - 2023-05-08 17:36:05 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:36:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 17:36:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:36:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:36:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:36:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:36:05 --> Final output sent to browser
INFO - 2023-05-08 17:36:07 --> Config Class Initialized
INFO - 2023-05-08 17:36:07 --> Hooks Class Initialized
INFO - 2023-05-08 17:36:07 --> Utf8 Class Initialized
INFO - 2023-05-08 17:36:07 --> URI Class Initialized
INFO - 2023-05-08 17:36:07 --> Router Class Initialized
INFO - 2023-05-08 17:36:07 --> Output Class Initialized
INFO - 2023-05-08 17:36:07 --> Security Class Initialized
INFO - 2023-05-08 17:36:07 --> Input Class Initialized
INFO - 2023-05-08 17:36:07 --> Language Class Initialized
INFO - 2023-05-08 17:36:07 --> Loader Class Initialized
INFO - 2023-05-08 17:36:07 --> Helper loaded: url_helper
INFO - 2023-05-08 17:36:07 --> Helper loaded: form_helper
INFO - 2023-05-08 17:36:07 --> Database Driver Class Initialized
INFO - 2023-05-08 17:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:36:07 --> Form Validation Class Initialized
INFO - 2023-05-08 17:36:07 --> Controller Class Initialized
INFO - 2023-05-08 17:36:07 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:36:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:36:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:36:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:36:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:36:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:36:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:36:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:36:07 --> Final output sent to browser
INFO - 2023-05-08 17:37:23 --> Config Class Initialized
INFO - 2023-05-08 17:37:23 --> Hooks Class Initialized
INFO - 2023-05-08 17:37:23 --> Utf8 Class Initialized
INFO - 2023-05-08 17:37:23 --> URI Class Initialized
INFO - 2023-05-08 17:37:23 --> Router Class Initialized
INFO - 2023-05-08 17:37:23 --> Output Class Initialized
INFO - 2023-05-08 17:37:23 --> Security Class Initialized
INFO - 2023-05-08 17:37:23 --> Input Class Initialized
INFO - 2023-05-08 17:37:23 --> Language Class Initialized
INFO - 2023-05-08 17:37:23 --> Loader Class Initialized
INFO - 2023-05-08 17:37:23 --> Helper loaded: url_helper
INFO - 2023-05-08 17:37:23 --> Helper loaded: form_helper
INFO - 2023-05-08 17:37:23 --> Database Driver Class Initialized
INFO - 2023-05-08 17:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:37:23 --> Form Validation Class Initialized
INFO - 2023-05-08 17:37:23 --> Controller Class Initialized
INFO - 2023-05-08 17:37:23 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:37:23 --> Final output sent to browser
INFO - 2023-05-08 17:38:23 --> Config Class Initialized
INFO - 2023-05-08 17:38:23 --> Hooks Class Initialized
INFO - 2023-05-08 17:38:23 --> Utf8 Class Initialized
INFO - 2023-05-08 17:38:23 --> URI Class Initialized
INFO - 2023-05-08 17:38:23 --> Router Class Initialized
INFO - 2023-05-08 17:38:23 --> Output Class Initialized
INFO - 2023-05-08 17:38:23 --> Security Class Initialized
INFO - 2023-05-08 17:38:23 --> Input Class Initialized
INFO - 2023-05-08 17:38:23 --> Language Class Initialized
INFO - 2023-05-08 17:38:23 --> Loader Class Initialized
INFO - 2023-05-08 17:38:23 --> Helper loaded: url_helper
INFO - 2023-05-08 17:38:23 --> Helper loaded: form_helper
INFO - 2023-05-08 17:38:23 --> Database Driver Class Initialized
INFO - 2023-05-08 17:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:38:23 --> Form Validation Class Initialized
INFO - 2023-05-08 17:38:23 --> Controller Class Initialized
INFO - 2023-05-08 17:38:23 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:38:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:38:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:38:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:38:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:38:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:38:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:38:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:38:23 --> Final output sent to browser
INFO - 2023-05-08 17:41:35 --> Config Class Initialized
INFO - 2023-05-08 17:41:35 --> Hooks Class Initialized
INFO - 2023-05-08 17:41:35 --> Utf8 Class Initialized
INFO - 2023-05-08 17:41:35 --> URI Class Initialized
INFO - 2023-05-08 17:41:35 --> Router Class Initialized
INFO - 2023-05-08 17:41:35 --> Output Class Initialized
INFO - 2023-05-08 17:41:35 --> Security Class Initialized
INFO - 2023-05-08 17:41:35 --> Input Class Initialized
INFO - 2023-05-08 17:41:35 --> Language Class Initialized
INFO - 2023-05-08 17:41:35 --> Loader Class Initialized
INFO - 2023-05-08 17:41:35 --> Helper loaded: url_helper
INFO - 2023-05-08 17:41:35 --> Helper loaded: form_helper
INFO - 2023-05-08 17:41:35 --> Database Driver Class Initialized
INFO - 2023-05-08 17:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:41:35 --> Form Validation Class Initialized
INFO - 2023-05-08 17:41:35 --> Controller Class Initialized
INFO - 2023-05-08 17:41:35 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:41:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:41:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:41:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:41:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:41:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:41:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:41:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:41:35 --> Final output sent to browser
INFO - 2023-05-08 17:41:40 --> Config Class Initialized
INFO - 2023-05-08 17:41:40 --> Hooks Class Initialized
INFO - 2023-05-08 17:41:40 --> Utf8 Class Initialized
INFO - 2023-05-08 17:41:40 --> URI Class Initialized
INFO - 2023-05-08 17:41:40 --> Router Class Initialized
INFO - 2023-05-08 17:41:40 --> Output Class Initialized
INFO - 2023-05-08 17:41:40 --> Security Class Initialized
INFO - 2023-05-08 17:41:40 --> Input Class Initialized
INFO - 2023-05-08 17:41:40 --> Language Class Initialized
INFO - 2023-05-08 17:41:40 --> Loader Class Initialized
INFO - 2023-05-08 17:41:40 --> Helper loaded: url_helper
INFO - 2023-05-08 17:41:40 --> Helper loaded: form_helper
INFO - 2023-05-08 17:41:40 --> Database Driver Class Initialized
INFO - 2023-05-08 17:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:41:40 --> Form Validation Class Initialized
INFO - 2023-05-08 17:41:40 --> Controller Class Initialized
INFO - 2023-05-08 17:41:40 --> Model "m_user" initialized
INFO - 2023-05-08 17:41:40 --> Config Class Initialized
INFO - 2023-05-08 17:41:40 --> Hooks Class Initialized
INFO - 2023-05-08 17:41:40 --> Utf8 Class Initialized
INFO - 2023-05-08 17:41:40 --> URI Class Initialized
INFO - 2023-05-08 17:41:40 --> Router Class Initialized
INFO - 2023-05-08 17:41:40 --> Output Class Initialized
INFO - 2023-05-08 17:41:40 --> Security Class Initialized
INFO - 2023-05-08 17:41:40 --> Input Class Initialized
INFO - 2023-05-08 17:41:40 --> Language Class Initialized
INFO - 2023-05-08 17:41:40 --> Loader Class Initialized
INFO - 2023-05-08 17:41:40 --> Helper loaded: url_helper
INFO - 2023-05-08 17:41:40 --> Helper loaded: form_helper
INFO - 2023-05-08 17:41:40 --> Database Driver Class Initialized
INFO - 2023-05-08 17:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:41:40 --> Form Validation Class Initialized
INFO - 2023-05-08 17:41:40 --> Controller Class Initialized
INFO - 2023-05-08 17:41:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 17:41:40 --> Final output sent to browser
INFO - 2023-05-08 17:41:42 --> Config Class Initialized
INFO - 2023-05-08 17:41:42 --> Hooks Class Initialized
INFO - 2023-05-08 17:41:42 --> Utf8 Class Initialized
INFO - 2023-05-08 17:41:42 --> URI Class Initialized
INFO - 2023-05-08 17:41:42 --> Router Class Initialized
INFO - 2023-05-08 17:41:42 --> Output Class Initialized
INFO - 2023-05-08 17:41:42 --> Security Class Initialized
INFO - 2023-05-08 17:41:42 --> Input Class Initialized
INFO - 2023-05-08 17:41:42 --> Language Class Initialized
INFO - 2023-05-08 17:41:42 --> Loader Class Initialized
INFO - 2023-05-08 17:41:42 --> Helper loaded: url_helper
INFO - 2023-05-08 17:41:42 --> Helper loaded: form_helper
INFO - 2023-05-08 17:41:42 --> Database Driver Class Initialized
INFO - 2023-05-08 17:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:41:42 --> Form Validation Class Initialized
INFO - 2023-05-08 17:41:42 --> Controller Class Initialized
INFO - 2023-05-08 17:41:42 --> Model "m_user" initialized
INFO - 2023-05-08 17:41:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-08 17:41:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-08 17:41:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-08 17:41:42 --> Final output sent to browser
INFO - 2023-05-08 17:41:47 --> Config Class Initialized
INFO - 2023-05-08 17:41:47 --> Hooks Class Initialized
INFO - 2023-05-08 17:41:47 --> Utf8 Class Initialized
INFO - 2023-05-08 17:41:47 --> URI Class Initialized
INFO - 2023-05-08 17:41:47 --> Router Class Initialized
INFO - 2023-05-08 17:41:47 --> Output Class Initialized
INFO - 2023-05-08 17:41:47 --> Security Class Initialized
INFO - 2023-05-08 17:41:47 --> Input Class Initialized
INFO - 2023-05-08 17:41:47 --> Language Class Initialized
INFO - 2023-05-08 17:41:47 --> Loader Class Initialized
INFO - 2023-05-08 17:41:47 --> Helper loaded: url_helper
INFO - 2023-05-08 17:41:47 --> Helper loaded: form_helper
INFO - 2023-05-08 17:41:47 --> Database Driver Class Initialized
INFO - 2023-05-08 17:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:41:47 --> Form Validation Class Initialized
INFO - 2023-05-08 17:41:47 --> Controller Class Initialized
INFO - 2023-05-08 17:41:47 --> Model "m_user" initialized
INFO - 2023-05-08 17:41:47 --> Config Class Initialized
INFO - 2023-05-08 17:41:47 --> Hooks Class Initialized
INFO - 2023-05-08 17:41:47 --> Utf8 Class Initialized
INFO - 2023-05-08 17:41:47 --> URI Class Initialized
INFO - 2023-05-08 17:41:47 --> Router Class Initialized
INFO - 2023-05-08 17:41:47 --> Output Class Initialized
INFO - 2023-05-08 17:41:47 --> Security Class Initialized
INFO - 2023-05-08 17:41:47 --> Input Class Initialized
INFO - 2023-05-08 17:41:47 --> Language Class Initialized
INFO - 2023-05-08 17:41:47 --> Loader Class Initialized
INFO - 2023-05-08 17:41:47 --> Helper loaded: url_helper
INFO - 2023-05-08 17:41:47 --> Helper loaded: form_helper
INFO - 2023-05-08 17:41:47 --> Database Driver Class Initialized
INFO - 2023-05-08 17:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:41:47 --> Form Validation Class Initialized
INFO - 2023-05-08 17:41:47 --> Controller Class Initialized
INFO - 2023-05-08 17:41:47 --> Model "m_user" initialized
INFO - 2023-05-08 17:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 17:41:47 --> Final output sent to browser
INFO - 2023-05-08 17:41:51 --> Config Class Initialized
INFO - 2023-05-08 17:41:51 --> Hooks Class Initialized
INFO - 2023-05-08 17:41:51 --> Utf8 Class Initialized
INFO - 2023-05-08 17:41:51 --> URI Class Initialized
INFO - 2023-05-08 17:41:51 --> Router Class Initialized
INFO - 2023-05-08 17:41:51 --> Output Class Initialized
INFO - 2023-05-08 17:41:51 --> Security Class Initialized
INFO - 2023-05-08 17:41:51 --> Input Class Initialized
INFO - 2023-05-08 17:41:51 --> Language Class Initialized
INFO - 2023-05-08 17:41:51 --> Loader Class Initialized
INFO - 2023-05-08 17:41:51 --> Helper loaded: url_helper
INFO - 2023-05-08 17:41:52 --> Helper loaded: form_helper
INFO - 2023-05-08 17:41:52 --> Database Driver Class Initialized
INFO - 2023-05-08 17:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:41:52 --> Form Validation Class Initialized
INFO - 2023-05-08 17:41:52 --> Controller Class Initialized
INFO - 2023-05-08 17:41:52 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:41:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:41:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:41:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 17:41:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:41:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:41:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:41:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:41:52 --> Final output sent to browser
INFO - 2023-05-08 17:41:53 --> Config Class Initialized
INFO - 2023-05-08 17:41:53 --> Hooks Class Initialized
INFO - 2023-05-08 17:41:53 --> Utf8 Class Initialized
INFO - 2023-05-08 17:41:53 --> URI Class Initialized
INFO - 2023-05-08 17:41:53 --> Router Class Initialized
INFO - 2023-05-08 17:41:53 --> Output Class Initialized
INFO - 2023-05-08 17:41:53 --> Security Class Initialized
INFO - 2023-05-08 17:41:53 --> Input Class Initialized
INFO - 2023-05-08 17:41:53 --> Language Class Initialized
INFO - 2023-05-08 17:41:53 --> Loader Class Initialized
INFO - 2023-05-08 17:41:53 --> Helper loaded: url_helper
INFO - 2023-05-08 17:41:53 --> Helper loaded: form_helper
INFO - 2023-05-08 17:41:53 --> Database Driver Class Initialized
INFO - 2023-05-08 17:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:41:53 --> Form Validation Class Initialized
INFO - 2023-05-08 17:41:53 --> Controller Class Initialized
INFO - 2023-05-08 17:41:53 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:41:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:41:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:41:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:41:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:41:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:41:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:41:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:41:53 --> Final output sent to browser
INFO - 2023-05-08 17:42:43 --> Config Class Initialized
INFO - 2023-05-08 17:42:43 --> Hooks Class Initialized
INFO - 2023-05-08 17:42:43 --> Utf8 Class Initialized
INFO - 2023-05-08 17:42:43 --> URI Class Initialized
INFO - 2023-05-08 17:42:43 --> Router Class Initialized
INFO - 2023-05-08 17:42:43 --> Output Class Initialized
INFO - 2023-05-08 17:42:43 --> Security Class Initialized
INFO - 2023-05-08 17:42:43 --> Input Class Initialized
INFO - 2023-05-08 17:42:43 --> Language Class Initialized
INFO - 2023-05-08 17:42:43 --> Loader Class Initialized
INFO - 2023-05-08 17:42:43 --> Helper loaded: url_helper
INFO - 2023-05-08 17:42:43 --> Helper loaded: form_helper
INFO - 2023-05-08 17:42:43 --> Database Driver Class Initialized
INFO - 2023-05-08 17:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:42:43 --> Form Validation Class Initialized
INFO - 2023-05-08 17:42:43 --> Controller Class Initialized
INFO - 2023-05-08 17:42:43 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:42:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:42:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:42:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:42:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:42:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:42:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:42:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:42:43 --> Final output sent to browser
INFO - 2023-05-08 17:47:38 --> Config Class Initialized
INFO - 2023-05-08 17:47:38 --> Hooks Class Initialized
INFO - 2023-05-08 17:47:38 --> Utf8 Class Initialized
INFO - 2023-05-08 17:47:38 --> URI Class Initialized
INFO - 2023-05-08 17:47:38 --> Router Class Initialized
INFO - 2023-05-08 17:47:38 --> Output Class Initialized
INFO - 2023-05-08 17:47:38 --> Security Class Initialized
INFO - 2023-05-08 17:47:38 --> Input Class Initialized
INFO - 2023-05-08 17:47:38 --> Language Class Initialized
INFO - 2023-05-08 17:47:38 --> Loader Class Initialized
INFO - 2023-05-08 17:47:38 --> Helper loaded: url_helper
INFO - 2023-05-08 17:47:38 --> Helper loaded: form_helper
INFO - 2023-05-08 17:47:38 --> Database Driver Class Initialized
INFO - 2023-05-08 17:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:47:38 --> Form Validation Class Initialized
INFO - 2023-05-08 17:47:38 --> Controller Class Initialized
INFO - 2023-05-08 17:47:38 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:47:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:47:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:47:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:47:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:47:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:47:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:47:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:47:38 --> Final output sent to browser
INFO - 2023-05-08 17:48:05 --> Config Class Initialized
INFO - 2023-05-08 17:48:05 --> Hooks Class Initialized
INFO - 2023-05-08 17:48:05 --> Utf8 Class Initialized
INFO - 2023-05-08 17:48:05 --> URI Class Initialized
INFO - 2023-05-08 17:48:05 --> Router Class Initialized
INFO - 2023-05-08 17:48:05 --> Output Class Initialized
INFO - 2023-05-08 17:48:05 --> Security Class Initialized
INFO - 2023-05-08 17:48:05 --> Input Class Initialized
INFO - 2023-05-08 17:48:05 --> Language Class Initialized
INFO - 2023-05-08 17:48:05 --> Loader Class Initialized
INFO - 2023-05-08 17:48:05 --> Helper loaded: url_helper
INFO - 2023-05-08 17:48:05 --> Helper loaded: form_helper
INFO - 2023-05-08 17:48:05 --> Database Driver Class Initialized
INFO - 2023-05-08 17:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:48:05 --> Form Validation Class Initialized
INFO - 2023-05-08 17:48:05 --> Controller Class Initialized
INFO - 2023-05-08 17:48:05 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:48:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:48:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:48:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:48:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:48:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:48:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:48:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:48:05 --> Final output sent to browser
INFO - 2023-05-08 17:48:07 --> Config Class Initialized
INFO - 2023-05-08 17:48:07 --> Hooks Class Initialized
INFO - 2023-05-08 17:48:07 --> Utf8 Class Initialized
INFO - 2023-05-08 17:48:07 --> URI Class Initialized
INFO - 2023-05-08 17:48:07 --> Router Class Initialized
INFO - 2023-05-08 17:48:07 --> Output Class Initialized
INFO - 2023-05-08 17:48:07 --> Security Class Initialized
INFO - 2023-05-08 17:48:07 --> Input Class Initialized
INFO - 2023-05-08 17:48:07 --> Language Class Initialized
INFO - 2023-05-08 17:48:07 --> Loader Class Initialized
INFO - 2023-05-08 17:48:07 --> Helper loaded: url_helper
INFO - 2023-05-08 17:48:07 --> Helper loaded: form_helper
INFO - 2023-05-08 17:48:07 --> Database Driver Class Initialized
INFO - 2023-05-08 17:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:48:07 --> Form Validation Class Initialized
INFO - 2023-05-08 17:48:07 --> Controller Class Initialized
INFO - 2023-05-08 17:48:07 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:48:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:48:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:48:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:48:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:48:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:48:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:48:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:48:07 --> Final output sent to browser
INFO - 2023-05-08 17:49:30 --> Config Class Initialized
INFO - 2023-05-08 17:49:30 --> Hooks Class Initialized
INFO - 2023-05-08 17:49:30 --> Utf8 Class Initialized
INFO - 2023-05-08 17:49:30 --> URI Class Initialized
INFO - 2023-05-08 17:49:30 --> Router Class Initialized
INFO - 2023-05-08 17:49:30 --> Output Class Initialized
INFO - 2023-05-08 17:49:30 --> Security Class Initialized
INFO - 2023-05-08 17:49:30 --> Input Class Initialized
INFO - 2023-05-08 17:49:30 --> Language Class Initialized
INFO - 2023-05-08 17:49:30 --> Loader Class Initialized
INFO - 2023-05-08 17:49:30 --> Helper loaded: url_helper
INFO - 2023-05-08 17:49:30 --> Helper loaded: form_helper
INFO - 2023-05-08 17:49:30 --> Database Driver Class Initialized
INFO - 2023-05-08 17:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:49:30 --> Form Validation Class Initialized
INFO - 2023-05-08 17:49:30 --> Controller Class Initialized
INFO - 2023-05-08 17:49:30 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:49:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:49:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:49:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:49:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:49:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:49:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:49:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:49:30 --> Final output sent to browser
INFO - 2023-05-08 17:49:55 --> Config Class Initialized
INFO - 2023-05-08 17:49:55 --> Hooks Class Initialized
INFO - 2023-05-08 17:49:55 --> Utf8 Class Initialized
INFO - 2023-05-08 17:49:55 --> URI Class Initialized
INFO - 2023-05-08 17:49:55 --> Router Class Initialized
INFO - 2023-05-08 17:49:55 --> Output Class Initialized
INFO - 2023-05-08 17:49:55 --> Security Class Initialized
INFO - 2023-05-08 17:49:55 --> Input Class Initialized
INFO - 2023-05-08 17:49:55 --> Language Class Initialized
INFO - 2023-05-08 17:49:55 --> Loader Class Initialized
INFO - 2023-05-08 17:49:55 --> Helper loaded: url_helper
INFO - 2023-05-08 17:49:55 --> Helper loaded: form_helper
INFO - 2023-05-08 17:49:55 --> Database Driver Class Initialized
INFO - 2023-05-08 17:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:49:55 --> Form Validation Class Initialized
INFO - 2023-05-08 17:49:55 --> Controller Class Initialized
INFO - 2023-05-08 17:49:55 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:49:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:49:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:49:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:49:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:49:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:49:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:49:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:49:55 --> Final output sent to browser
INFO - 2023-05-08 17:50:16 --> Config Class Initialized
INFO - 2023-05-08 17:50:16 --> Hooks Class Initialized
INFO - 2023-05-08 17:50:16 --> Utf8 Class Initialized
INFO - 2023-05-08 17:50:16 --> URI Class Initialized
INFO - 2023-05-08 17:50:16 --> Router Class Initialized
INFO - 2023-05-08 17:50:16 --> Output Class Initialized
INFO - 2023-05-08 17:50:16 --> Security Class Initialized
INFO - 2023-05-08 17:50:16 --> Input Class Initialized
INFO - 2023-05-08 17:50:16 --> Language Class Initialized
INFO - 2023-05-08 17:50:16 --> Loader Class Initialized
INFO - 2023-05-08 17:50:16 --> Helper loaded: url_helper
INFO - 2023-05-08 17:50:16 --> Helper loaded: form_helper
INFO - 2023-05-08 17:50:16 --> Database Driver Class Initialized
INFO - 2023-05-08 17:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:50:16 --> Form Validation Class Initialized
INFO - 2023-05-08 17:50:16 --> Controller Class Initialized
INFO - 2023-05-08 17:50:16 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:50:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:50:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:50:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:50:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:50:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:50:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:50:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:50:16 --> Final output sent to browser
INFO - 2023-05-08 17:55:31 --> Config Class Initialized
INFO - 2023-05-08 17:55:31 --> Hooks Class Initialized
INFO - 2023-05-08 17:55:31 --> Utf8 Class Initialized
INFO - 2023-05-08 17:55:31 --> URI Class Initialized
INFO - 2023-05-08 17:55:31 --> Router Class Initialized
INFO - 2023-05-08 17:55:31 --> Output Class Initialized
INFO - 2023-05-08 17:55:31 --> Security Class Initialized
INFO - 2023-05-08 17:55:31 --> Input Class Initialized
INFO - 2023-05-08 17:55:31 --> Language Class Initialized
INFO - 2023-05-08 17:55:31 --> Loader Class Initialized
INFO - 2023-05-08 17:55:31 --> Helper loaded: url_helper
INFO - 2023-05-08 17:55:31 --> Helper loaded: form_helper
INFO - 2023-05-08 17:55:31 --> Database Driver Class Initialized
INFO - 2023-05-08 17:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:55:31 --> Form Validation Class Initialized
INFO - 2023-05-08 17:55:31 --> Controller Class Initialized
INFO - 2023-05-08 17:55:31 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:55:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:55:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:55:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:55:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:55:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:55:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:55:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:55:31 --> Final output sent to browser
INFO - 2023-05-08 17:55:50 --> Config Class Initialized
INFO - 2023-05-08 17:55:50 --> Hooks Class Initialized
INFO - 2023-05-08 17:55:50 --> Utf8 Class Initialized
INFO - 2023-05-08 17:55:50 --> URI Class Initialized
INFO - 2023-05-08 17:55:50 --> Router Class Initialized
INFO - 2023-05-08 17:55:50 --> Output Class Initialized
INFO - 2023-05-08 17:55:50 --> Security Class Initialized
INFO - 2023-05-08 17:55:50 --> Input Class Initialized
INFO - 2023-05-08 17:55:50 --> Language Class Initialized
INFO - 2023-05-08 17:55:50 --> Loader Class Initialized
INFO - 2023-05-08 17:55:50 --> Helper loaded: url_helper
INFO - 2023-05-08 17:55:50 --> Helper loaded: form_helper
INFO - 2023-05-08 17:55:50 --> Database Driver Class Initialized
INFO - 2023-05-08 17:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:55:50 --> Form Validation Class Initialized
INFO - 2023-05-08 17:55:50 --> Controller Class Initialized
INFO - 2023-05-08 17:55:50 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:55:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:55:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:55:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:55:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:55:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:55:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:55:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:55:50 --> Final output sent to browser
INFO - 2023-05-08 17:56:03 --> Config Class Initialized
INFO - 2023-05-08 17:56:03 --> Hooks Class Initialized
INFO - 2023-05-08 17:56:03 --> Utf8 Class Initialized
INFO - 2023-05-08 17:56:03 --> URI Class Initialized
INFO - 2023-05-08 17:56:03 --> Router Class Initialized
INFO - 2023-05-08 17:56:03 --> Output Class Initialized
INFO - 2023-05-08 17:56:03 --> Security Class Initialized
INFO - 2023-05-08 17:56:03 --> Input Class Initialized
INFO - 2023-05-08 17:56:03 --> Language Class Initialized
INFO - 2023-05-08 17:56:03 --> Loader Class Initialized
INFO - 2023-05-08 17:56:03 --> Helper loaded: url_helper
INFO - 2023-05-08 17:56:03 --> Helper loaded: form_helper
INFO - 2023-05-08 17:56:03 --> Database Driver Class Initialized
INFO - 2023-05-08 17:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:56:03 --> Form Validation Class Initialized
INFO - 2023-05-08 17:56:03 --> Controller Class Initialized
INFO - 2023-05-08 17:56:03 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:56:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:56:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:56:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:56:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:56:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:56:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:56:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:56:03 --> Final output sent to browser
INFO - 2023-05-08 17:56:44 --> Config Class Initialized
INFO - 2023-05-08 17:56:44 --> Hooks Class Initialized
INFO - 2023-05-08 17:56:44 --> Utf8 Class Initialized
INFO - 2023-05-08 17:56:44 --> URI Class Initialized
INFO - 2023-05-08 17:56:44 --> Router Class Initialized
INFO - 2023-05-08 17:56:44 --> Output Class Initialized
INFO - 2023-05-08 17:56:44 --> Security Class Initialized
INFO - 2023-05-08 17:56:44 --> Input Class Initialized
INFO - 2023-05-08 17:56:44 --> Language Class Initialized
INFO - 2023-05-08 17:56:44 --> Loader Class Initialized
INFO - 2023-05-08 17:56:44 --> Helper loaded: url_helper
INFO - 2023-05-08 17:56:44 --> Helper loaded: form_helper
INFO - 2023-05-08 17:56:44 --> Database Driver Class Initialized
INFO - 2023-05-08 17:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:56:44 --> Form Validation Class Initialized
INFO - 2023-05-08 17:56:44 --> Controller Class Initialized
INFO - 2023-05-08 17:56:44 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:56:44 --> Final output sent to browser
INFO - 2023-05-08 17:56:55 --> Config Class Initialized
INFO - 2023-05-08 17:56:55 --> Hooks Class Initialized
INFO - 2023-05-08 17:56:55 --> Utf8 Class Initialized
INFO - 2023-05-08 17:56:55 --> URI Class Initialized
INFO - 2023-05-08 17:56:55 --> Router Class Initialized
INFO - 2023-05-08 17:56:55 --> Output Class Initialized
INFO - 2023-05-08 17:56:55 --> Security Class Initialized
INFO - 2023-05-08 17:56:55 --> Input Class Initialized
INFO - 2023-05-08 17:56:55 --> Language Class Initialized
INFO - 2023-05-08 17:56:55 --> Loader Class Initialized
INFO - 2023-05-08 17:56:55 --> Helper loaded: url_helper
INFO - 2023-05-08 17:56:55 --> Helper loaded: form_helper
INFO - 2023-05-08 17:56:55 --> Database Driver Class Initialized
INFO - 2023-05-08 17:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:56:55 --> Form Validation Class Initialized
INFO - 2023-05-08 17:56:55 --> Controller Class Initialized
INFO - 2023-05-08 17:56:55 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:56:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:56:55 --> Final output sent to browser
INFO - 2023-05-08 17:57:59 --> Config Class Initialized
INFO - 2023-05-08 17:57:59 --> Hooks Class Initialized
INFO - 2023-05-08 17:57:59 --> Utf8 Class Initialized
INFO - 2023-05-08 17:57:59 --> URI Class Initialized
INFO - 2023-05-08 17:57:59 --> Router Class Initialized
INFO - 2023-05-08 17:57:59 --> Output Class Initialized
INFO - 2023-05-08 17:57:59 --> Security Class Initialized
INFO - 2023-05-08 17:57:59 --> Input Class Initialized
INFO - 2023-05-08 17:57:59 --> Language Class Initialized
INFO - 2023-05-08 17:57:59 --> Loader Class Initialized
INFO - 2023-05-08 17:57:59 --> Helper loaded: url_helper
INFO - 2023-05-08 17:57:59 --> Helper loaded: form_helper
INFO - 2023-05-08 17:57:59 --> Database Driver Class Initialized
INFO - 2023-05-08 17:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:57:59 --> Form Validation Class Initialized
INFO - 2023-05-08 17:57:59 --> Controller Class Initialized
INFO - 2023-05-08 17:57:59 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:57:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:57:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:57:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:57:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:57:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:57:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:57:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:57:59 --> Final output sent to browser
INFO - 2023-05-08 17:59:00 --> Config Class Initialized
INFO - 2023-05-08 17:59:00 --> Hooks Class Initialized
INFO - 2023-05-08 17:59:00 --> Utf8 Class Initialized
INFO - 2023-05-08 17:59:00 --> URI Class Initialized
INFO - 2023-05-08 17:59:00 --> Router Class Initialized
INFO - 2023-05-08 17:59:00 --> Output Class Initialized
INFO - 2023-05-08 17:59:00 --> Security Class Initialized
INFO - 2023-05-08 17:59:00 --> Input Class Initialized
INFO - 2023-05-08 17:59:00 --> Language Class Initialized
INFO - 2023-05-08 17:59:00 --> Loader Class Initialized
INFO - 2023-05-08 17:59:00 --> Helper loaded: url_helper
INFO - 2023-05-08 17:59:00 --> Helper loaded: form_helper
INFO - 2023-05-08 17:59:00 --> Database Driver Class Initialized
INFO - 2023-05-08 17:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:59:00 --> Form Validation Class Initialized
INFO - 2023-05-08 17:59:00 --> Controller Class Initialized
INFO - 2023-05-08 17:59:00 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:59:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:59:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:59:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:59:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:59:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:59:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:59:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:59:00 --> Final output sent to browser
INFO - 2023-05-08 17:59:02 --> Config Class Initialized
INFO - 2023-05-08 17:59:02 --> Hooks Class Initialized
INFO - 2023-05-08 17:59:02 --> Utf8 Class Initialized
INFO - 2023-05-08 17:59:02 --> URI Class Initialized
INFO - 2023-05-08 17:59:02 --> Router Class Initialized
INFO - 2023-05-08 17:59:02 --> Output Class Initialized
INFO - 2023-05-08 17:59:02 --> Security Class Initialized
INFO - 2023-05-08 17:59:02 --> Input Class Initialized
INFO - 2023-05-08 17:59:02 --> Language Class Initialized
INFO - 2023-05-08 17:59:02 --> Loader Class Initialized
INFO - 2023-05-08 17:59:02 --> Helper loaded: url_helper
INFO - 2023-05-08 17:59:02 --> Helper loaded: form_helper
INFO - 2023-05-08 17:59:02 --> Database Driver Class Initialized
INFO - 2023-05-08 17:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 17:59:02 --> Form Validation Class Initialized
INFO - 2023-05-08 17:59:02 --> Controller Class Initialized
INFO - 2023-05-08 17:59:02 --> Model "m_datatrain" initialized
INFO - 2023-05-08 17:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 17:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 17:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 17:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 17:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 17:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 17:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 17:59:02 --> Final output sent to browser
INFO - 2023-05-08 18:00:08 --> Config Class Initialized
INFO - 2023-05-08 18:00:08 --> Hooks Class Initialized
INFO - 2023-05-08 18:00:08 --> Utf8 Class Initialized
INFO - 2023-05-08 18:00:08 --> URI Class Initialized
INFO - 2023-05-08 18:00:08 --> Router Class Initialized
INFO - 2023-05-08 18:00:08 --> Output Class Initialized
INFO - 2023-05-08 18:00:08 --> Security Class Initialized
INFO - 2023-05-08 18:00:08 --> Input Class Initialized
INFO - 2023-05-08 18:00:08 --> Language Class Initialized
INFO - 2023-05-08 18:00:08 --> Loader Class Initialized
INFO - 2023-05-08 18:00:08 --> Helper loaded: url_helper
INFO - 2023-05-08 18:00:08 --> Helper loaded: form_helper
INFO - 2023-05-08 18:00:08 --> Database Driver Class Initialized
INFO - 2023-05-08 18:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:00:08 --> Form Validation Class Initialized
INFO - 2023-05-08 18:00:08 --> Controller Class Initialized
INFO - 2023-05-08 18:00:08 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:00:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:00:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:00:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:00:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:00:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:00:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:00:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:00:08 --> Final output sent to browser
INFO - 2023-05-08 18:02:18 --> Config Class Initialized
INFO - 2023-05-08 18:02:18 --> Hooks Class Initialized
INFO - 2023-05-08 18:02:18 --> Utf8 Class Initialized
INFO - 2023-05-08 18:02:18 --> URI Class Initialized
INFO - 2023-05-08 18:02:18 --> Router Class Initialized
INFO - 2023-05-08 18:02:18 --> Output Class Initialized
INFO - 2023-05-08 18:02:18 --> Security Class Initialized
INFO - 2023-05-08 18:02:18 --> Input Class Initialized
INFO - 2023-05-08 18:02:18 --> Language Class Initialized
INFO - 2023-05-08 18:02:18 --> Loader Class Initialized
INFO - 2023-05-08 18:02:18 --> Helper loaded: url_helper
INFO - 2023-05-08 18:02:18 --> Helper loaded: form_helper
INFO - 2023-05-08 18:02:18 --> Database Driver Class Initialized
INFO - 2023-05-08 18:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:02:18 --> Form Validation Class Initialized
INFO - 2023-05-08 18:02:18 --> Controller Class Initialized
INFO - 2023-05-08 18:02:18 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:02:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:02:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:02:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:02:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:02:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:02:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:02:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:02:18 --> Final output sent to browser
INFO - 2023-05-08 18:02:59 --> Config Class Initialized
INFO - 2023-05-08 18:02:59 --> Hooks Class Initialized
INFO - 2023-05-08 18:02:59 --> Utf8 Class Initialized
INFO - 2023-05-08 18:02:59 --> URI Class Initialized
INFO - 2023-05-08 18:02:59 --> Router Class Initialized
INFO - 2023-05-08 18:02:59 --> Output Class Initialized
INFO - 2023-05-08 18:02:59 --> Security Class Initialized
INFO - 2023-05-08 18:02:59 --> Input Class Initialized
INFO - 2023-05-08 18:02:59 --> Language Class Initialized
INFO - 2023-05-08 18:02:59 --> Loader Class Initialized
INFO - 2023-05-08 18:02:59 --> Helper loaded: url_helper
INFO - 2023-05-08 18:02:59 --> Helper loaded: form_helper
INFO - 2023-05-08 18:02:59 --> Database Driver Class Initialized
INFO - 2023-05-08 18:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:02:59 --> Form Validation Class Initialized
INFO - 2023-05-08 18:02:59 --> Controller Class Initialized
INFO - 2023-05-08 18:02:59 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:02:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:02:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:02:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:02:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:02:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:02:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:02:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:02:59 --> Final output sent to browser
INFO - 2023-05-08 18:03:56 --> Config Class Initialized
INFO - 2023-05-08 18:03:56 --> Hooks Class Initialized
INFO - 2023-05-08 18:03:56 --> Utf8 Class Initialized
INFO - 2023-05-08 18:03:56 --> URI Class Initialized
INFO - 2023-05-08 18:03:56 --> Router Class Initialized
INFO - 2023-05-08 18:03:56 --> Output Class Initialized
INFO - 2023-05-08 18:03:56 --> Security Class Initialized
INFO - 2023-05-08 18:03:56 --> Input Class Initialized
INFO - 2023-05-08 18:03:56 --> Language Class Initialized
INFO - 2023-05-08 18:03:56 --> Loader Class Initialized
INFO - 2023-05-08 18:03:56 --> Helper loaded: url_helper
INFO - 2023-05-08 18:03:56 --> Helper loaded: form_helper
INFO - 2023-05-08 18:03:56 --> Database Driver Class Initialized
INFO - 2023-05-08 18:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:03:56 --> Form Validation Class Initialized
INFO - 2023-05-08 18:03:56 --> Controller Class Initialized
INFO - 2023-05-08 18:03:56 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:03:56 --> Final output sent to browser
INFO - 2023-05-08 18:04:49 --> Config Class Initialized
INFO - 2023-05-08 18:04:49 --> Hooks Class Initialized
INFO - 2023-05-08 18:04:49 --> Utf8 Class Initialized
INFO - 2023-05-08 18:04:49 --> URI Class Initialized
INFO - 2023-05-08 18:04:49 --> Router Class Initialized
INFO - 2023-05-08 18:04:49 --> Output Class Initialized
INFO - 2023-05-08 18:04:49 --> Security Class Initialized
INFO - 2023-05-08 18:04:49 --> Input Class Initialized
INFO - 2023-05-08 18:04:49 --> Language Class Initialized
INFO - 2023-05-08 18:04:49 --> Loader Class Initialized
INFO - 2023-05-08 18:04:49 --> Helper loaded: url_helper
INFO - 2023-05-08 18:04:49 --> Helper loaded: form_helper
INFO - 2023-05-08 18:04:49 --> Database Driver Class Initialized
INFO - 2023-05-08 18:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:04:49 --> Form Validation Class Initialized
INFO - 2023-05-08 18:04:49 --> Controller Class Initialized
INFO - 2023-05-08 18:04:49 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:04:49 --> Final output sent to browser
INFO - 2023-05-08 18:05:16 --> Config Class Initialized
INFO - 2023-05-08 18:05:16 --> Hooks Class Initialized
INFO - 2023-05-08 18:05:16 --> Utf8 Class Initialized
INFO - 2023-05-08 18:05:16 --> URI Class Initialized
INFO - 2023-05-08 18:05:16 --> Router Class Initialized
INFO - 2023-05-08 18:05:16 --> Output Class Initialized
INFO - 2023-05-08 18:05:16 --> Security Class Initialized
INFO - 2023-05-08 18:05:16 --> Input Class Initialized
INFO - 2023-05-08 18:05:16 --> Language Class Initialized
INFO - 2023-05-08 18:05:16 --> Loader Class Initialized
INFO - 2023-05-08 18:05:16 --> Helper loaded: url_helper
INFO - 2023-05-08 18:05:16 --> Helper loaded: form_helper
INFO - 2023-05-08 18:05:16 --> Database Driver Class Initialized
INFO - 2023-05-08 18:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:05:16 --> Form Validation Class Initialized
INFO - 2023-05-08 18:05:16 --> Controller Class Initialized
INFO - 2023-05-08 18:05:16 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:05:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:05:16 --> Final output sent to browser
INFO - 2023-05-08 18:05:44 --> Config Class Initialized
INFO - 2023-05-08 18:05:44 --> Hooks Class Initialized
INFO - 2023-05-08 18:05:44 --> Utf8 Class Initialized
INFO - 2023-05-08 18:05:44 --> URI Class Initialized
INFO - 2023-05-08 18:05:44 --> Router Class Initialized
INFO - 2023-05-08 18:05:44 --> Output Class Initialized
INFO - 2023-05-08 18:05:44 --> Security Class Initialized
INFO - 2023-05-08 18:05:44 --> Input Class Initialized
INFO - 2023-05-08 18:05:44 --> Language Class Initialized
INFO - 2023-05-08 18:05:44 --> Loader Class Initialized
INFO - 2023-05-08 18:05:44 --> Helper loaded: url_helper
INFO - 2023-05-08 18:05:44 --> Helper loaded: form_helper
INFO - 2023-05-08 18:05:44 --> Database Driver Class Initialized
INFO - 2023-05-08 18:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:05:44 --> Form Validation Class Initialized
INFO - 2023-05-08 18:05:44 --> Controller Class Initialized
INFO - 2023-05-08 18:05:44 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:05:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:05:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:05:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:05:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:05:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:05:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:05:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:05:44 --> Final output sent to browser
INFO - 2023-05-08 18:06:03 --> Config Class Initialized
INFO - 2023-05-08 18:06:03 --> Hooks Class Initialized
INFO - 2023-05-08 18:06:03 --> Utf8 Class Initialized
INFO - 2023-05-08 18:06:03 --> URI Class Initialized
INFO - 2023-05-08 18:06:03 --> Router Class Initialized
INFO - 2023-05-08 18:06:03 --> Output Class Initialized
INFO - 2023-05-08 18:06:03 --> Security Class Initialized
INFO - 2023-05-08 18:06:03 --> Input Class Initialized
INFO - 2023-05-08 18:06:03 --> Language Class Initialized
INFO - 2023-05-08 18:06:03 --> Loader Class Initialized
INFO - 2023-05-08 18:06:03 --> Helper loaded: url_helper
INFO - 2023-05-08 18:06:03 --> Helper loaded: form_helper
INFO - 2023-05-08 18:06:03 --> Database Driver Class Initialized
INFO - 2023-05-08 18:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:06:03 --> Form Validation Class Initialized
INFO - 2023-05-08 18:06:03 --> Controller Class Initialized
INFO - 2023-05-08 18:06:03 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:06:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:06:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:06:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:06:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:06:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:06:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:06:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:06:03 --> Final output sent to browser
INFO - 2023-05-08 18:06:21 --> Config Class Initialized
INFO - 2023-05-08 18:06:21 --> Hooks Class Initialized
INFO - 2023-05-08 18:06:21 --> Utf8 Class Initialized
INFO - 2023-05-08 18:06:21 --> URI Class Initialized
INFO - 2023-05-08 18:06:21 --> Router Class Initialized
INFO - 2023-05-08 18:06:21 --> Output Class Initialized
INFO - 2023-05-08 18:06:21 --> Security Class Initialized
INFO - 2023-05-08 18:06:21 --> Input Class Initialized
INFO - 2023-05-08 18:06:21 --> Language Class Initialized
INFO - 2023-05-08 18:06:21 --> Loader Class Initialized
INFO - 2023-05-08 18:06:21 --> Helper loaded: url_helper
INFO - 2023-05-08 18:06:21 --> Helper loaded: form_helper
INFO - 2023-05-08 18:06:21 --> Database Driver Class Initialized
INFO - 2023-05-08 18:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:06:21 --> Form Validation Class Initialized
INFO - 2023-05-08 18:06:21 --> Controller Class Initialized
INFO - 2023-05-08 18:06:21 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:06:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:06:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:06:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:06:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:06:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:06:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:06:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:06:21 --> Final output sent to browser
INFO - 2023-05-08 18:06:31 --> Config Class Initialized
INFO - 2023-05-08 18:06:31 --> Hooks Class Initialized
INFO - 2023-05-08 18:06:31 --> Utf8 Class Initialized
INFO - 2023-05-08 18:06:31 --> URI Class Initialized
INFO - 2023-05-08 18:06:31 --> Router Class Initialized
INFO - 2023-05-08 18:06:31 --> Output Class Initialized
INFO - 2023-05-08 18:06:31 --> Security Class Initialized
INFO - 2023-05-08 18:06:31 --> Input Class Initialized
INFO - 2023-05-08 18:06:31 --> Language Class Initialized
INFO - 2023-05-08 18:06:31 --> Loader Class Initialized
INFO - 2023-05-08 18:06:31 --> Helper loaded: url_helper
INFO - 2023-05-08 18:06:31 --> Helper loaded: form_helper
INFO - 2023-05-08 18:06:31 --> Database Driver Class Initialized
INFO - 2023-05-08 18:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:06:31 --> Form Validation Class Initialized
INFO - 2023-05-08 18:06:31 --> Controller Class Initialized
INFO - 2023-05-08 18:06:31 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:06:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:06:31 --> Final output sent to browser
INFO - 2023-05-08 18:07:47 --> Config Class Initialized
INFO - 2023-05-08 18:07:47 --> Hooks Class Initialized
INFO - 2023-05-08 18:07:47 --> Utf8 Class Initialized
INFO - 2023-05-08 18:07:47 --> URI Class Initialized
INFO - 2023-05-08 18:07:47 --> Router Class Initialized
INFO - 2023-05-08 18:07:47 --> Output Class Initialized
INFO - 2023-05-08 18:07:47 --> Security Class Initialized
INFO - 2023-05-08 18:07:47 --> Input Class Initialized
INFO - 2023-05-08 18:07:47 --> Language Class Initialized
INFO - 2023-05-08 18:07:47 --> Loader Class Initialized
INFO - 2023-05-08 18:07:47 --> Helper loaded: url_helper
INFO - 2023-05-08 18:07:47 --> Helper loaded: form_helper
INFO - 2023-05-08 18:07:47 --> Database Driver Class Initialized
INFO - 2023-05-08 18:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:07:47 --> Form Validation Class Initialized
INFO - 2023-05-08 18:07:47 --> Controller Class Initialized
INFO - 2023-05-08 18:07:47 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:07:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:07:47 --> Final output sent to browser
INFO - 2023-05-08 18:08:15 --> Config Class Initialized
INFO - 2023-05-08 18:08:15 --> Hooks Class Initialized
INFO - 2023-05-08 18:08:15 --> Utf8 Class Initialized
INFO - 2023-05-08 18:08:15 --> URI Class Initialized
INFO - 2023-05-08 18:08:15 --> Router Class Initialized
INFO - 2023-05-08 18:08:15 --> Output Class Initialized
INFO - 2023-05-08 18:08:15 --> Security Class Initialized
INFO - 2023-05-08 18:08:15 --> Input Class Initialized
INFO - 2023-05-08 18:08:15 --> Language Class Initialized
INFO - 2023-05-08 18:08:15 --> Loader Class Initialized
INFO - 2023-05-08 18:08:15 --> Helper loaded: url_helper
INFO - 2023-05-08 18:08:15 --> Helper loaded: form_helper
INFO - 2023-05-08 18:08:15 --> Database Driver Class Initialized
INFO - 2023-05-08 18:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:08:15 --> Form Validation Class Initialized
INFO - 2023-05-08 18:08:15 --> Controller Class Initialized
INFO - 2023-05-08 18:08:15 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:08:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:08:15 --> Final output sent to browser
INFO - 2023-05-08 18:21:07 --> Config Class Initialized
INFO - 2023-05-08 18:21:07 --> Hooks Class Initialized
INFO - 2023-05-08 18:21:07 --> Utf8 Class Initialized
INFO - 2023-05-08 18:21:07 --> URI Class Initialized
INFO - 2023-05-08 18:21:07 --> Router Class Initialized
INFO - 2023-05-08 18:21:07 --> Output Class Initialized
INFO - 2023-05-08 18:21:07 --> Security Class Initialized
INFO - 2023-05-08 18:21:07 --> Input Class Initialized
INFO - 2023-05-08 18:21:07 --> Language Class Initialized
INFO - 2023-05-08 18:21:07 --> Loader Class Initialized
INFO - 2023-05-08 18:21:07 --> Helper loaded: url_helper
INFO - 2023-05-08 18:21:07 --> Helper loaded: form_helper
INFO - 2023-05-08 18:21:07 --> Database Driver Class Initialized
INFO - 2023-05-08 18:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:21:07 --> Form Validation Class Initialized
INFO - 2023-05-08 18:21:07 --> Controller Class Initialized
INFO - 2023-05-08 18:21:07 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:21:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:21:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:21:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:21:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:21:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:21:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:21:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:21:07 --> Final output sent to browser
INFO - 2023-05-08 18:21:22 --> Config Class Initialized
INFO - 2023-05-08 18:21:22 --> Hooks Class Initialized
INFO - 2023-05-08 18:21:22 --> Utf8 Class Initialized
INFO - 2023-05-08 18:21:22 --> URI Class Initialized
INFO - 2023-05-08 18:21:22 --> Router Class Initialized
INFO - 2023-05-08 18:21:22 --> Output Class Initialized
INFO - 2023-05-08 18:21:22 --> Security Class Initialized
INFO - 2023-05-08 18:21:22 --> Input Class Initialized
INFO - 2023-05-08 18:21:22 --> Language Class Initialized
INFO - 2023-05-08 18:21:22 --> Loader Class Initialized
INFO - 2023-05-08 18:21:22 --> Helper loaded: url_helper
INFO - 2023-05-08 18:21:22 --> Helper loaded: form_helper
INFO - 2023-05-08 18:21:22 --> Database Driver Class Initialized
INFO - 2023-05-08 18:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:21:22 --> Form Validation Class Initialized
INFO - 2023-05-08 18:21:22 --> Controller Class Initialized
INFO - 2023-05-08 18:21:22 --> Model "m_datatrain" initialized
ERROR - 2023-05-08 18:21:22 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `datatraining` (`nama`, `semester`, `a1`, `a2`, `a3`, `a4`, `a5`, `a6`) VALUES ('asu', '8', 'Rumah Sendiri', 'Sangat Buruk', 'Sangat Buruk', 'Sangat Buruk', 'Sangat Buruk', 'Sangat Buruk')
INFO - 2023-05-08 18:21:22 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-08 18:22:07 --> Config Class Initialized
INFO - 2023-05-08 18:22:07 --> Hooks Class Initialized
INFO - 2023-05-08 18:22:07 --> Utf8 Class Initialized
INFO - 2023-05-08 18:22:07 --> URI Class Initialized
INFO - 2023-05-08 18:22:07 --> Router Class Initialized
INFO - 2023-05-08 18:22:07 --> Output Class Initialized
INFO - 2023-05-08 18:22:07 --> Security Class Initialized
INFO - 2023-05-08 18:22:07 --> Input Class Initialized
INFO - 2023-05-08 18:22:07 --> Language Class Initialized
INFO - 2023-05-08 18:22:07 --> Loader Class Initialized
INFO - 2023-05-08 18:22:07 --> Helper loaded: url_helper
INFO - 2023-05-08 18:22:07 --> Helper loaded: form_helper
INFO - 2023-05-08 18:22:07 --> Database Driver Class Initialized
INFO - 2023-05-08 18:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:22:07 --> Form Validation Class Initialized
INFO - 2023-05-08 18:22:07 --> Controller Class Initialized
INFO - 2023-05-08 18:22:07 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:22:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:22:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:22:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:22:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:22:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:22:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:22:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:22:07 --> Final output sent to browser
INFO - 2023-05-08 18:23:39 --> Config Class Initialized
INFO - 2023-05-08 18:23:39 --> Hooks Class Initialized
INFO - 2023-05-08 18:23:39 --> Utf8 Class Initialized
INFO - 2023-05-08 18:23:39 --> URI Class Initialized
INFO - 2023-05-08 18:23:39 --> Router Class Initialized
INFO - 2023-05-08 18:23:39 --> Output Class Initialized
INFO - 2023-05-08 18:23:39 --> Security Class Initialized
INFO - 2023-05-08 18:23:39 --> Input Class Initialized
INFO - 2023-05-08 18:23:39 --> Language Class Initialized
INFO - 2023-05-08 18:23:39 --> Loader Class Initialized
INFO - 2023-05-08 18:23:39 --> Helper loaded: url_helper
INFO - 2023-05-08 18:23:39 --> Helper loaded: form_helper
INFO - 2023-05-08 18:23:39 --> Database Driver Class Initialized
INFO - 2023-05-08 18:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:23:39 --> Form Validation Class Initialized
INFO - 2023-05-08 18:23:39 --> Controller Class Initialized
INFO - 2023-05-08 18:23:39 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:23:39 --> Final output sent to browser
INFO - 2023-05-08 18:23:54 --> Config Class Initialized
INFO - 2023-05-08 18:23:54 --> Hooks Class Initialized
INFO - 2023-05-08 18:23:54 --> Utf8 Class Initialized
INFO - 2023-05-08 18:23:54 --> URI Class Initialized
INFO - 2023-05-08 18:23:54 --> Router Class Initialized
INFO - 2023-05-08 18:23:54 --> Output Class Initialized
INFO - 2023-05-08 18:23:54 --> Security Class Initialized
INFO - 2023-05-08 18:23:54 --> Input Class Initialized
INFO - 2023-05-08 18:23:54 --> Language Class Initialized
INFO - 2023-05-08 18:23:54 --> Loader Class Initialized
INFO - 2023-05-08 18:23:54 --> Helper loaded: url_helper
INFO - 2023-05-08 18:23:54 --> Helper loaded: form_helper
INFO - 2023-05-08 18:23:54 --> Database Driver Class Initialized
INFO - 2023-05-08 18:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:23:54 --> Form Validation Class Initialized
INFO - 2023-05-08 18:23:54 --> Controller Class Initialized
INFO - 2023-05-08 18:23:54 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:23:54 --> Config Class Initialized
INFO - 2023-05-08 18:23:54 --> Hooks Class Initialized
INFO - 2023-05-08 18:23:54 --> Utf8 Class Initialized
INFO - 2023-05-08 18:23:54 --> URI Class Initialized
INFO - 2023-05-08 18:23:54 --> Router Class Initialized
INFO - 2023-05-08 18:23:54 --> Output Class Initialized
INFO - 2023-05-08 18:23:54 --> Security Class Initialized
INFO - 2023-05-08 18:23:54 --> Input Class Initialized
INFO - 2023-05-08 18:23:54 --> Language Class Initialized
INFO - 2023-05-08 18:23:54 --> Loader Class Initialized
INFO - 2023-05-08 18:23:54 --> Helper loaded: url_helper
INFO - 2023-05-08 18:23:54 --> Helper loaded: form_helper
INFO - 2023-05-08 18:23:54 --> Database Driver Class Initialized
INFO - 2023-05-08 18:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:23:54 --> Form Validation Class Initialized
INFO - 2023-05-08 18:23:54 --> Controller Class Initialized
INFO - 2023-05-08 18:23:54 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:23:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:23:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:23:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 18:23:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:23:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:23:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:23:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:23:54 --> Final output sent to browser
INFO - 2023-05-08 18:28:58 --> Config Class Initialized
INFO - 2023-05-08 18:28:58 --> Hooks Class Initialized
INFO - 2023-05-08 18:28:58 --> Utf8 Class Initialized
INFO - 2023-05-08 18:28:58 --> URI Class Initialized
INFO - 2023-05-08 18:28:58 --> Router Class Initialized
INFO - 2023-05-08 18:28:58 --> Output Class Initialized
INFO - 2023-05-08 18:28:58 --> Security Class Initialized
INFO - 2023-05-08 18:28:58 --> Input Class Initialized
INFO - 2023-05-08 18:28:58 --> Language Class Initialized
ERROR - 2023-05-08 18:28:58 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatrain.php 33
INFO - 2023-05-08 18:28:59 --> Config Class Initialized
INFO - 2023-05-08 18:28:59 --> Hooks Class Initialized
INFO - 2023-05-08 18:28:59 --> Utf8 Class Initialized
INFO - 2023-05-08 18:28:59 --> URI Class Initialized
INFO - 2023-05-08 18:29:00 --> Router Class Initialized
INFO - 2023-05-08 18:29:00 --> Output Class Initialized
INFO - 2023-05-08 18:29:00 --> Security Class Initialized
INFO - 2023-05-08 18:29:00 --> Input Class Initialized
INFO - 2023-05-08 18:29:00 --> Language Class Initialized
ERROR - 2023-05-08 18:29:00 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatrain.php 33
INFO - 2023-05-08 18:29:06 --> Config Class Initialized
INFO - 2023-05-08 18:29:06 --> Hooks Class Initialized
INFO - 2023-05-08 18:29:06 --> Utf8 Class Initialized
INFO - 2023-05-08 18:29:06 --> URI Class Initialized
INFO - 2023-05-08 18:29:06 --> Router Class Initialized
INFO - 2023-05-08 18:29:06 --> Output Class Initialized
INFO - 2023-05-08 18:29:06 --> Security Class Initialized
INFO - 2023-05-08 18:29:06 --> Input Class Initialized
INFO - 2023-05-08 18:29:06 --> Language Class Initialized
ERROR - 2023-05-08 18:29:06 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatrain.php 33
INFO - 2023-05-08 18:29:11 --> Config Class Initialized
INFO - 2023-05-08 18:29:11 --> Hooks Class Initialized
INFO - 2023-05-08 18:29:11 --> Utf8 Class Initialized
INFO - 2023-05-08 18:29:11 --> URI Class Initialized
INFO - 2023-05-08 18:29:11 --> Router Class Initialized
INFO - 2023-05-08 18:29:11 --> Output Class Initialized
INFO - 2023-05-08 18:29:11 --> Security Class Initialized
INFO - 2023-05-08 18:29:11 --> Input Class Initialized
INFO - 2023-05-08 18:29:11 --> Language Class Initialized
INFO - 2023-05-08 18:29:11 --> Loader Class Initialized
INFO - 2023-05-08 18:29:11 --> Helper loaded: url_helper
INFO - 2023-05-08 18:29:11 --> Helper loaded: form_helper
INFO - 2023-05-08 18:29:11 --> Database Driver Class Initialized
INFO - 2023-05-08 18:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:29:11 --> Form Validation Class Initialized
INFO - 2023-05-08 18:29:11 --> Controller Class Initialized
INFO - 2023-05-08 18:29:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 18:29:11 --> Final output sent to browser
INFO - 2023-05-08 18:29:12 --> Config Class Initialized
INFO - 2023-05-08 18:29:12 --> Hooks Class Initialized
INFO - 2023-05-08 18:29:12 --> Utf8 Class Initialized
INFO - 2023-05-08 18:29:12 --> URI Class Initialized
INFO - 2023-05-08 18:29:12 --> Router Class Initialized
INFO - 2023-05-08 18:29:12 --> Output Class Initialized
INFO - 2023-05-08 18:29:12 --> Security Class Initialized
INFO - 2023-05-08 18:29:12 --> Input Class Initialized
INFO - 2023-05-08 18:29:12 --> Language Class Initialized
INFO - 2023-05-08 18:29:12 --> Loader Class Initialized
INFO - 2023-05-08 18:29:12 --> Helper loaded: url_helper
INFO - 2023-05-08 18:29:12 --> Helper loaded: form_helper
INFO - 2023-05-08 18:29:12 --> Database Driver Class Initialized
INFO - 2023-05-08 18:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:29:12 --> Form Validation Class Initialized
INFO - 2023-05-08 18:29:12 --> Controller Class Initialized
INFO - 2023-05-08 18:29:12 --> Model "m_user" initialized
INFO - 2023-05-08 18:29:12 --> Config Class Initialized
INFO - 2023-05-08 18:29:12 --> Hooks Class Initialized
INFO - 2023-05-08 18:29:12 --> Utf8 Class Initialized
INFO - 2023-05-08 18:29:12 --> URI Class Initialized
INFO - 2023-05-08 18:29:12 --> Router Class Initialized
INFO - 2023-05-08 18:29:12 --> Output Class Initialized
INFO - 2023-05-08 18:29:12 --> Security Class Initialized
INFO - 2023-05-08 18:29:12 --> Input Class Initialized
INFO - 2023-05-08 18:29:12 --> Language Class Initialized
INFO - 2023-05-08 18:29:12 --> Loader Class Initialized
INFO - 2023-05-08 18:29:12 --> Helper loaded: url_helper
INFO - 2023-05-08 18:29:12 --> Helper loaded: form_helper
INFO - 2023-05-08 18:29:12 --> Database Driver Class Initialized
INFO - 2023-05-08 18:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:29:12 --> Form Validation Class Initialized
INFO - 2023-05-08 18:29:12 --> Controller Class Initialized
INFO - 2023-05-08 18:29:12 --> Model "m_user" initialized
INFO - 2023-05-08 18:29:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:29:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:29:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:29:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:29:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:29:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 18:29:12 --> Final output sent to browser
INFO - 2023-05-08 18:29:15 --> Config Class Initialized
INFO - 2023-05-08 18:29:15 --> Hooks Class Initialized
INFO - 2023-05-08 18:29:15 --> Utf8 Class Initialized
INFO - 2023-05-08 18:29:15 --> URI Class Initialized
INFO - 2023-05-08 18:29:15 --> Router Class Initialized
INFO - 2023-05-08 18:29:15 --> Output Class Initialized
INFO - 2023-05-08 18:29:15 --> Security Class Initialized
INFO - 2023-05-08 18:29:15 --> Input Class Initialized
INFO - 2023-05-08 18:29:15 --> Language Class Initialized
ERROR - 2023-05-08 18:29:15 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatrain.php 33
INFO - 2023-05-08 18:29:51 --> Config Class Initialized
INFO - 2023-05-08 18:29:51 --> Hooks Class Initialized
INFO - 2023-05-08 18:29:51 --> Utf8 Class Initialized
INFO - 2023-05-08 18:29:51 --> URI Class Initialized
INFO - 2023-05-08 18:29:51 --> Router Class Initialized
INFO - 2023-05-08 18:29:51 --> Output Class Initialized
INFO - 2023-05-08 18:29:51 --> Security Class Initialized
INFO - 2023-05-08 18:29:51 --> Input Class Initialized
INFO - 2023-05-08 18:29:51 --> Language Class Initialized
INFO - 2023-05-08 18:29:51 --> Loader Class Initialized
INFO - 2023-05-08 18:29:51 --> Helper loaded: url_helper
INFO - 2023-05-08 18:29:51 --> Helper loaded: form_helper
INFO - 2023-05-08 18:29:51 --> Database Driver Class Initialized
INFO - 2023-05-08 18:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:29:51 --> Form Validation Class Initialized
INFO - 2023-05-08 18:29:51 --> Controller Class Initialized
INFO - 2023-05-08 18:29:51 --> Model "m_user" initialized
INFO - 2023-05-08 18:29:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:29:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:29:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:29:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:29:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:29:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 18:29:51 --> Final output sent to browser
INFO - 2023-05-08 18:29:53 --> Config Class Initialized
INFO - 2023-05-08 18:29:53 --> Hooks Class Initialized
INFO - 2023-05-08 18:29:53 --> Utf8 Class Initialized
INFO - 2023-05-08 18:29:53 --> URI Class Initialized
INFO - 2023-05-08 18:29:53 --> Router Class Initialized
INFO - 2023-05-08 18:29:53 --> Output Class Initialized
INFO - 2023-05-08 18:29:53 --> Security Class Initialized
INFO - 2023-05-08 18:29:53 --> Input Class Initialized
INFO - 2023-05-08 18:29:53 --> Language Class Initialized
INFO - 2023-05-08 18:29:53 --> Loader Class Initialized
INFO - 2023-05-08 18:29:53 --> Helper loaded: url_helper
INFO - 2023-05-08 18:29:53 --> Helper loaded: form_helper
INFO - 2023-05-08 18:29:53 --> Database Driver Class Initialized
INFO - 2023-05-08 18:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:29:53 --> Form Validation Class Initialized
INFO - 2023-05-08 18:29:53 --> Controller Class Initialized
INFO - 2023-05-08 18:29:53 --> Model "m_user" initialized
INFO - 2023-05-08 18:29:53 --> Config Class Initialized
INFO - 2023-05-08 18:29:53 --> Hooks Class Initialized
INFO - 2023-05-08 18:29:53 --> Utf8 Class Initialized
INFO - 2023-05-08 18:29:53 --> URI Class Initialized
INFO - 2023-05-08 18:29:53 --> Router Class Initialized
INFO - 2023-05-08 18:29:53 --> Output Class Initialized
INFO - 2023-05-08 18:29:53 --> Security Class Initialized
INFO - 2023-05-08 18:29:53 --> Input Class Initialized
INFO - 2023-05-08 18:29:53 --> Language Class Initialized
INFO - 2023-05-08 18:29:53 --> Loader Class Initialized
INFO - 2023-05-08 18:29:53 --> Helper loaded: url_helper
INFO - 2023-05-08 18:29:53 --> Helper loaded: form_helper
INFO - 2023-05-08 18:29:53 --> Database Driver Class Initialized
INFO - 2023-05-08 18:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:29:53 --> Form Validation Class Initialized
INFO - 2023-05-08 18:29:53 --> Controller Class Initialized
INFO - 2023-05-08 18:29:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 18:29:53 --> Final output sent to browser
INFO - 2023-05-08 18:29:54 --> Config Class Initialized
INFO - 2023-05-08 18:29:54 --> Hooks Class Initialized
INFO - 2023-05-08 18:29:54 --> Utf8 Class Initialized
INFO - 2023-05-08 18:29:54 --> URI Class Initialized
INFO - 2023-05-08 18:29:54 --> Router Class Initialized
INFO - 2023-05-08 18:29:54 --> Output Class Initialized
INFO - 2023-05-08 18:29:54 --> Security Class Initialized
INFO - 2023-05-08 18:29:54 --> Input Class Initialized
INFO - 2023-05-08 18:29:54 --> Language Class Initialized
INFO - 2023-05-08 18:29:54 --> Loader Class Initialized
INFO - 2023-05-08 18:29:54 --> Helper loaded: url_helper
INFO - 2023-05-08 18:29:54 --> Helper loaded: form_helper
INFO - 2023-05-08 18:29:54 --> Database Driver Class Initialized
INFO - 2023-05-08 18:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:29:54 --> Form Validation Class Initialized
INFO - 2023-05-08 18:29:54 --> Controller Class Initialized
INFO - 2023-05-08 18:29:54 --> Model "m_user" initialized
INFO - 2023-05-08 18:29:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-08 18:29:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-08 18:29:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-08 18:29:54 --> Final output sent to browser
INFO - 2023-05-08 18:29:58 --> Config Class Initialized
INFO - 2023-05-08 18:29:58 --> Hooks Class Initialized
INFO - 2023-05-08 18:29:58 --> Utf8 Class Initialized
INFO - 2023-05-08 18:29:58 --> URI Class Initialized
INFO - 2023-05-08 18:29:58 --> Router Class Initialized
INFO - 2023-05-08 18:29:58 --> Output Class Initialized
INFO - 2023-05-08 18:29:58 --> Security Class Initialized
INFO - 2023-05-08 18:29:58 --> Input Class Initialized
INFO - 2023-05-08 18:29:58 --> Language Class Initialized
INFO - 2023-05-08 18:29:58 --> Loader Class Initialized
INFO - 2023-05-08 18:29:58 --> Helper loaded: url_helper
INFO - 2023-05-08 18:29:58 --> Helper loaded: form_helper
INFO - 2023-05-08 18:29:58 --> Database Driver Class Initialized
INFO - 2023-05-08 18:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:29:58 --> Form Validation Class Initialized
INFO - 2023-05-08 18:29:58 --> Controller Class Initialized
INFO - 2023-05-08 18:29:58 --> Model "m_user" initialized
INFO - 2023-05-08 18:29:58 --> Config Class Initialized
INFO - 2023-05-08 18:29:58 --> Hooks Class Initialized
INFO - 2023-05-08 18:29:58 --> Utf8 Class Initialized
INFO - 2023-05-08 18:29:58 --> URI Class Initialized
INFO - 2023-05-08 18:29:58 --> Router Class Initialized
INFO - 2023-05-08 18:29:58 --> Output Class Initialized
INFO - 2023-05-08 18:29:58 --> Security Class Initialized
INFO - 2023-05-08 18:29:58 --> Input Class Initialized
INFO - 2023-05-08 18:29:58 --> Language Class Initialized
INFO - 2023-05-08 18:29:58 --> Loader Class Initialized
INFO - 2023-05-08 18:29:58 --> Helper loaded: url_helper
INFO - 2023-05-08 18:29:58 --> Helper loaded: form_helper
INFO - 2023-05-08 18:29:58 --> Database Driver Class Initialized
INFO - 2023-05-08 18:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:29:58 --> Form Validation Class Initialized
INFO - 2023-05-08 18:29:58 --> Controller Class Initialized
INFO - 2023-05-08 18:29:58 --> Model "m_user" initialized
INFO - 2023-05-08 18:29:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:29:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:29:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:29:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:29:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:29:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 18:29:58 --> Final output sent to browser
INFO - 2023-05-08 18:30:02 --> Config Class Initialized
INFO - 2023-05-08 18:30:02 --> Hooks Class Initialized
INFO - 2023-05-08 18:30:02 --> Utf8 Class Initialized
INFO - 2023-05-08 18:30:02 --> URI Class Initialized
INFO - 2023-05-08 18:30:02 --> Router Class Initialized
INFO - 2023-05-08 18:30:02 --> Output Class Initialized
INFO - 2023-05-08 18:30:02 --> Security Class Initialized
INFO - 2023-05-08 18:30:02 --> Input Class Initialized
INFO - 2023-05-08 18:30:02 --> Language Class Initialized
ERROR - 2023-05-08 18:30:02 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatrain.php 33
INFO - 2023-05-08 18:32:15 --> Config Class Initialized
INFO - 2023-05-08 18:32:15 --> Hooks Class Initialized
INFO - 2023-05-08 18:32:15 --> Utf8 Class Initialized
INFO - 2023-05-08 18:32:15 --> URI Class Initialized
INFO - 2023-05-08 18:32:15 --> Router Class Initialized
INFO - 2023-05-08 18:32:15 --> Output Class Initialized
INFO - 2023-05-08 18:32:16 --> Security Class Initialized
INFO - 2023-05-08 18:32:16 --> Input Class Initialized
INFO - 2023-05-08 18:32:16 --> Language Class Initialized
ERROR - 2023-05-08 18:32:16 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatrain.php 33
INFO - 2023-05-08 18:32:17 --> Config Class Initialized
INFO - 2023-05-08 18:32:17 --> Hooks Class Initialized
INFO - 2023-05-08 18:32:17 --> Utf8 Class Initialized
INFO - 2023-05-08 18:32:17 --> URI Class Initialized
INFO - 2023-05-08 18:32:17 --> Router Class Initialized
INFO - 2023-05-08 18:32:17 --> Output Class Initialized
INFO - 2023-05-08 18:32:17 --> Security Class Initialized
INFO - 2023-05-08 18:32:17 --> Input Class Initialized
INFO - 2023-05-08 18:32:17 --> Language Class Initialized
INFO - 2023-05-08 18:32:17 --> Loader Class Initialized
INFO - 2023-05-08 18:32:17 --> Helper loaded: url_helper
INFO - 2023-05-08 18:32:17 --> Helper loaded: form_helper
INFO - 2023-05-08 18:32:17 --> Database Driver Class Initialized
INFO - 2023-05-08 18:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:32:17 --> Form Validation Class Initialized
INFO - 2023-05-08 18:32:17 --> Controller Class Initialized
INFO - 2023-05-08 18:32:17 --> Model "m_user" initialized
INFO - 2023-05-08 18:32:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:32:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:32:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:32:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:32:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:32:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 18:32:17 --> Final output sent to browser
INFO - 2023-05-08 18:32:18 --> Config Class Initialized
INFO - 2023-05-08 18:32:18 --> Hooks Class Initialized
INFO - 2023-05-08 18:32:18 --> Utf8 Class Initialized
INFO - 2023-05-08 18:32:18 --> URI Class Initialized
INFO - 2023-05-08 18:32:18 --> Router Class Initialized
INFO - 2023-05-08 18:32:18 --> Output Class Initialized
INFO - 2023-05-08 18:32:19 --> Security Class Initialized
INFO - 2023-05-08 18:32:19 --> Input Class Initialized
INFO - 2023-05-08 18:32:19 --> Language Class Initialized
ERROR - 2023-05-08 18:32:19 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatrain.php 33
INFO - 2023-05-08 18:32:39 --> Config Class Initialized
INFO - 2023-05-08 18:32:39 --> Hooks Class Initialized
INFO - 2023-05-08 18:32:39 --> Utf8 Class Initialized
INFO - 2023-05-08 18:32:39 --> URI Class Initialized
INFO - 2023-05-08 18:32:39 --> Router Class Initialized
INFO - 2023-05-08 18:32:39 --> Output Class Initialized
INFO - 2023-05-08 18:32:39 --> Security Class Initialized
INFO - 2023-05-08 18:32:39 --> Input Class Initialized
INFO - 2023-05-08 18:32:39 --> Language Class Initialized
INFO - 2023-05-08 18:32:39 --> Loader Class Initialized
INFO - 2023-05-08 18:32:39 --> Helper loaded: url_helper
INFO - 2023-05-08 18:32:39 --> Helper loaded: form_helper
INFO - 2023-05-08 18:32:39 --> Database Driver Class Initialized
INFO - 2023-05-08 18:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:32:39 --> Form Validation Class Initialized
INFO - 2023-05-08 18:32:39 --> Controller Class Initialized
INFO - 2023-05-08 18:32:39 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 18:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:32:39 --> Final output sent to browser
INFO - 2023-05-08 18:33:00 --> Config Class Initialized
INFO - 2023-05-08 18:33:00 --> Hooks Class Initialized
INFO - 2023-05-08 18:33:00 --> Utf8 Class Initialized
INFO - 2023-05-08 18:33:00 --> URI Class Initialized
INFO - 2023-05-08 18:33:00 --> Router Class Initialized
INFO - 2023-05-08 18:33:00 --> Output Class Initialized
INFO - 2023-05-08 18:33:00 --> Security Class Initialized
INFO - 2023-05-08 18:33:00 --> Input Class Initialized
INFO - 2023-05-08 18:33:00 --> Language Class Initialized
INFO - 2023-05-08 18:33:00 --> Loader Class Initialized
INFO - 2023-05-08 18:33:00 --> Helper loaded: url_helper
INFO - 2023-05-08 18:33:00 --> Helper loaded: form_helper
INFO - 2023-05-08 18:33:00 --> Database Driver Class Initialized
INFO - 2023-05-08 18:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:33:00 --> Form Validation Class Initialized
INFO - 2023-05-08 18:33:00 --> Controller Class Initialized
INFO - 2023-05-08 18:33:00 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:33:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:33:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:33:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 18:33:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:33:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:33:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:33:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:33:00 --> Final output sent to browser
INFO - 2023-05-08 18:33:05 --> Config Class Initialized
INFO - 2023-05-08 18:33:05 --> Hooks Class Initialized
INFO - 2023-05-08 18:33:05 --> Utf8 Class Initialized
INFO - 2023-05-08 18:33:05 --> URI Class Initialized
INFO - 2023-05-08 18:33:05 --> Router Class Initialized
INFO - 2023-05-08 18:33:05 --> Output Class Initialized
INFO - 2023-05-08 18:33:05 --> Security Class Initialized
INFO - 2023-05-08 18:33:05 --> Input Class Initialized
INFO - 2023-05-08 18:33:05 --> Language Class Initialized
INFO - 2023-05-08 18:33:05 --> Loader Class Initialized
INFO - 2023-05-08 18:33:05 --> Helper loaded: url_helper
INFO - 2023-05-08 18:33:05 --> Helper loaded: form_helper
INFO - 2023-05-08 18:33:05 --> Database Driver Class Initialized
INFO - 2023-05-08 18:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:33:05 --> Form Validation Class Initialized
INFO - 2023-05-08 18:33:05 --> Controller Class Initialized
INFO - 2023-05-08 18:33:05 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:33:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:33:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:33:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:33:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:33:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:33:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:33:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:33:05 --> Final output sent to browser
INFO - 2023-05-08 18:33:22 --> Config Class Initialized
INFO - 2023-05-08 18:33:22 --> Hooks Class Initialized
INFO - 2023-05-08 18:33:22 --> Utf8 Class Initialized
INFO - 2023-05-08 18:33:22 --> URI Class Initialized
INFO - 2023-05-08 18:33:22 --> Router Class Initialized
INFO - 2023-05-08 18:33:22 --> Output Class Initialized
INFO - 2023-05-08 18:33:22 --> Security Class Initialized
INFO - 2023-05-08 18:33:22 --> Input Class Initialized
INFO - 2023-05-08 18:33:22 --> Language Class Initialized
INFO - 2023-05-08 18:33:22 --> Loader Class Initialized
INFO - 2023-05-08 18:33:22 --> Helper loaded: url_helper
INFO - 2023-05-08 18:33:22 --> Helper loaded: form_helper
INFO - 2023-05-08 18:33:22 --> Database Driver Class Initialized
INFO - 2023-05-08 18:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:33:22 --> Form Validation Class Initialized
INFO - 2023-05-08 18:33:22 --> Controller Class Initialized
INFO - 2023-05-08 18:33:22 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:33:22 --> Config Class Initialized
INFO - 2023-05-08 18:33:22 --> Hooks Class Initialized
INFO - 2023-05-08 18:33:22 --> Utf8 Class Initialized
INFO - 2023-05-08 18:33:22 --> URI Class Initialized
INFO - 2023-05-08 18:33:22 --> Router Class Initialized
INFO - 2023-05-08 18:33:22 --> Output Class Initialized
INFO - 2023-05-08 18:33:22 --> Security Class Initialized
INFO - 2023-05-08 18:33:22 --> Input Class Initialized
INFO - 2023-05-08 18:33:22 --> Language Class Initialized
INFO - 2023-05-08 18:33:22 --> Loader Class Initialized
INFO - 2023-05-08 18:33:22 --> Helper loaded: url_helper
INFO - 2023-05-08 18:33:22 --> Helper loaded: form_helper
INFO - 2023-05-08 18:33:22 --> Database Driver Class Initialized
INFO - 2023-05-08 18:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:33:22 --> Form Validation Class Initialized
INFO - 2023-05-08 18:33:22 --> Controller Class Initialized
INFO - 2023-05-08 18:33:22 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 18:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:33:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:33:22 --> Final output sent to browser
INFO - 2023-05-08 18:54:06 --> Config Class Initialized
INFO - 2023-05-08 18:54:06 --> Hooks Class Initialized
INFO - 2023-05-08 18:54:06 --> Utf8 Class Initialized
INFO - 2023-05-08 18:54:06 --> URI Class Initialized
INFO - 2023-05-08 18:54:06 --> Router Class Initialized
INFO - 2023-05-08 18:54:06 --> Output Class Initialized
INFO - 2023-05-08 18:54:06 --> Security Class Initialized
INFO - 2023-05-08 18:54:06 --> Input Class Initialized
INFO - 2023-05-08 18:54:06 --> Language Class Initialized
INFO - 2023-05-08 18:54:06 --> Loader Class Initialized
INFO - 2023-05-08 18:54:06 --> Helper loaded: url_helper
INFO - 2023-05-08 18:54:06 --> Helper loaded: form_helper
INFO - 2023-05-08 18:54:06 --> Database Driver Class Initialized
INFO - 2023-05-08 18:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:54:06 --> Form Validation Class Initialized
INFO - 2023-05-08 18:54:06 --> Controller Class Initialized
INFO - 2023-05-08 18:54:06 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:54:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:54:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:54:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 18:54:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:54:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:54:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:54:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:54:06 --> Final output sent to browser
INFO - 2023-05-08 18:54:08 --> Config Class Initialized
INFO - 2023-05-08 18:54:08 --> Hooks Class Initialized
INFO - 2023-05-08 18:54:08 --> Utf8 Class Initialized
INFO - 2023-05-08 18:54:08 --> URI Class Initialized
INFO - 2023-05-08 18:54:08 --> Router Class Initialized
INFO - 2023-05-08 18:54:08 --> Output Class Initialized
INFO - 2023-05-08 18:54:08 --> Security Class Initialized
INFO - 2023-05-08 18:54:08 --> Input Class Initialized
INFO - 2023-05-08 18:54:08 --> Language Class Initialized
INFO - 2023-05-08 18:54:08 --> Loader Class Initialized
INFO - 2023-05-08 18:54:08 --> Helper loaded: url_helper
INFO - 2023-05-08 18:54:08 --> Helper loaded: form_helper
INFO - 2023-05-08 18:54:08 --> Database Driver Class Initialized
INFO - 2023-05-08 18:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:54:08 --> Form Validation Class Initialized
INFO - 2023-05-08 18:54:08 --> Controller Class Initialized
INFO - 2023-05-08 18:54:08 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:54:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:54:08 --> Final output sent to browser
INFO - 2023-05-08 18:54:27 --> Config Class Initialized
INFO - 2023-05-08 18:54:27 --> Hooks Class Initialized
INFO - 2023-05-08 18:54:27 --> Utf8 Class Initialized
INFO - 2023-05-08 18:54:27 --> URI Class Initialized
INFO - 2023-05-08 18:54:27 --> Router Class Initialized
INFO - 2023-05-08 18:54:27 --> Output Class Initialized
INFO - 2023-05-08 18:54:27 --> Security Class Initialized
INFO - 2023-05-08 18:54:27 --> Input Class Initialized
INFO - 2023-05-08 18:54:27 --> Language Class Initialized
INFO - 2023-05-08 18:54:27 --> Loader Class Initialized
INFO - 2023-05-08 18:54:27 --> Helper loaded: url_helper
INFO - 2023-05-08 18:54:27 --> Helper loaded: form_helper
INFO - 2023-05-08 18:54:27 --> Database Driver Class Initialized
INFO - 2023-05-08 18:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:54:27 --> Form Validation Class Initialized
INFO - 2023-05-08 18:54:27 --> Controller Class Initialized
INFO - 2023-05-08 18:54:27 --> Model "m_datatrain" initialized
ERROR - 2023-05-08 18:54:27 --> Query error: Out of range value for column 'id' at row 1 - Invalid query: INSERT INTO `datatraining` (`nama`, `semester`, `a1`, `a2`, `a3`, `a4`, `a5`, `a6`, `hasil`) VALUES ('asu', '8', 'Kos', 'Sangat Baik', 'Sangat Baik', 'Sangat Baik', 'Sangat Buruk', 'Baik', 'Ringan')
INFO - 2023-05-08 18:54:27 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-08 18:54:50 --> Config Class Initialized
INFO - 2023-05-08 18:54:50 --> Hooks Class Initialized
INFO - 2023-05-08 18:54:50 --> Utf8 Class Initialized
INFO - 2023-05-08 18:54:50 --> URI Class Initialized
INFO - 2023-05-08 18:54:50 --> Router Class Initialized
INFO - 2023-05-08 18:54:50 --> Output Class Initialized
INFO - 2023-05-08 18:54:50 --> Security Class Initialized
INFO - 2023-05-08 18:54:50 --> Input Class Initialized
INFO - 2023-05-08 18:54:50 --> Language Class Initialized
INFO - 2023-05-08 18:54:50 --> Loader Class Initialized
INFO - 2023-05-08 18:54:50 --> Helper loaded: url_helper
INFO - 2023-05-08 18:54:50 --> Helper loaded: form_helper
INFO - 2023-05-08 18:54:50 --> Database Driver Class Initialized
INFO - 2023-05-08 18:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:54:50 --> Form Validation Class Initialized
INFO - 2023-05-08 18:54:50 --> Controller Class Initialized
INFO - 2023-05-08 18:54:50 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:54:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:54:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:54:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:54:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:54:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:54:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:54:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:54:50 --> Final output sent to browser
INFO - 2023-05-08 18:55:25 --> Config Class Initialized
INFO - 2023-05-08 18:55:25 --> Hooks Class Initialized
INFO - 2023-05-08 18:55:25 --> Utf8 Class Initialized
INFO - 2023-05-08 18:55:25 --> URI Class Initialized
INFO - 2023-05-08 18:55:25 --> Router Class Initialized
INFO - 2023-05-08 18:55:25 --> Output Class Initialized
INFO - 2023-05-08 18:55:25 --> Security Class Initialized
INFO - 2023-05-08 18:55:25 --> Input Class Initialized
INFO - 2023-05-08 18:55:25 --> Language Class Initialized
INFO - 2023-05-08 18:55:25 --> Loader Class Initialized
INFO - 2023-05-08 18:55:25 --> Helper loaded: url_helper
INFO - 2023-05-08 18:55:25 --> Helper loaded: form_helper
INFO - 2023-05-08 18:55:25 --> Database Driver Class Initialized
INFO - 2023-05-08 18:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:55:25 --> Form Validation Class Initialized
INFO - 2023-05-08 18:55:25 --> Controller Class Initialized
INFO - 2023-05-08 18:55:25 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:55:25 --> Config Class Initialized
INFO - 2023-05-08 18:55:25 --> Hooks Class Initialized
INFO - 2023-05-08 18:55:25 --> Utf8 Class Initialized
INFO - 2023-05-08 18:55:25 --> URI Class Initialized
INFO - 2023-05-08 18:55:25 --> Router Class Initialized
INFO - 2023-05-08 18:55:25 --> Output Class Initialized
INFO - 2023-05-08 18:55:25 --> Security Class Initialized
INFO - 2023-05-08 18:55:25 --> Input Class Initialized
INFO - 2023-05-08 18:55:25 --> Language Class Initialized
INFO - 2023-05-08 18:55:25 --> Loader Class Initialized
INFO - 2023-05-08 18:55:25 --> Helper loaded: url_helper
INFO - 2023-05-08 18:55:25 --> Helper loaded: form_helper
INFO - 2023-05-08 18:55:25 --> Database Driver Class Initialized
INFO - 2023-05-08 18:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:55:25 --> Form Validation Class Initialized
INFO - 2023-05-08 18:55:25 --> Controller Class Initialized
INFO - 2023-05-08 18:55:25 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 18:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:55:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:55:25 --> Final output sent to browser
INFO - 2023-05-08 18:55:41 --> Config Class Initialized
INFO - 2023-05-08 18:55:41 --> Hooks Class Initialized
INFO - 2023-05-08 18:55:41 --> Utf8 Class Initialized
INFO - 2023-05-08 18:55:41 --> URI Class Initialized
INFO - 2023-05-08 18:55:41 --> Router Class Initialized
INFO - 2023-05-08 18:55:41 --> Output Class Initialized
INFO - 2023-05-08 18:55:41 --> Security Class Initialized
INFO - 2023-05-08 18:55:41 --> Input Class Initialized
INFO - 2023-05-08 18:55:41 --> Language Class Initialized
INFO - 2023-05-08 18:55:41 --> Loader Class Initialized
INFO - 2023-05-08 18:55:41 --> Helper loaded: url_helper
INFO - 2023-05-08 18:55:41 --> Helper loaded: form_helper
INFO - 2023-05-08 18:55:41 --> Database Driver Class Initialized
INFO - 2023-05-08 18:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:55:41 --> Form Validation Class Initialized
INFO - 2023-05-08 18:55:41 --> Controller Class Initialized
INFO - 2023-05-08 18:55:41 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:55:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:55:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:55:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:55:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:55:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:55:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:55:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:55:41 --> Final output sent to browser
INFO - 2023-05-08 18:55:54 --> Config Class Initialized
INFO - 2023-05-08 18:55:54 --> Hooks Class Initialized
INFO - 2023-05-08 18:55:54 --> Utf8 Class Initialized
INFO - 2023-05-08 18:55:54 --> URI Class Initialized
INFO - 2023-05-08 18:55:54 --> Router Class Initialized
INFO - 2023-05-08 18:55:54 --> Output Class Initialized
INFO - 2023-05-08 18:55:54 --> Security Class Initialized
INFO - 2023-05-08 18:55:54 --> Input Class Initialized
INFO - 2023-05-08 18:55:54 --> Language Class Initialized
INFO - 2023-05-08 18:55:54 --> Loader Class Initialized
INFO - 2023-05-08 18:55:54 --> Helper loaded: url_helper
INFO - 2023-05-08 18:55:54 --> Helper loaded: form_helper
INFO - 2023-05-08 18:55:54 --> Database Driver Class Initialized
INFO - 2023-05-08 18:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:55:54 --> Form Validation Class Initialized
INFO - 2023-05-08 18:55:54 --> Controller Class Initialized
INFO - 2023-05-08 18:55:54 --> Model "m_datatrain" initialized
ERROR - 2023-05-08 18:55:54 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `datatraining` (`nama`, `semester`, `a1`, `a2`, `a3`, `a4`, `a5`, `a6`, `hasil`) VALUES ('asdasad', '6', 'Rumah Sendiri', 'Sangat Baik', 'Buruk', 'Buruk', 'Sangat Buruk', 'Sangat Buruk', 'Gangguan Mood')
INFO - 2023-05-08 18:55:54 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-08 18:55:59 --> Config Class Initialized
INFO - 2023-05-08 18:55:59 --> Hooks Class Initialized
INFO - 2023-05-08 18:55:59 --> Utf8 Class Initialized
INFO - 2023-05-08 18:55:59 --> URI Class Initialized
INFO - 2023-05-08 18:55:59 --> Router Class Initialized
INFO - 2023-05-08 18:55:59 --> Output Class Initialized
INFO - 2023-05-08 18:55:59 --> Security Class Initialized
INFO - 2023-05-08 18:55:59 --> Input Class Initialized
INFO - 2023-05-08 18:55:59 --> Language Class Initialized
INFO - 2023-05-08 18:55:59 --> Loader Class Initialized
INFO - 2023-05-08 18:55:59 --> Helper loaded: url_helper
INFO - 2023-05-08 18:55:59 --> Helper loaded: form_helper
INFO - 2023-05-08 18:55:59 --> Database Driver Class Initialized
INFO - 2023-05-08 18:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:55:59 --> Form Validation Class Initialized
INFO - 2023-05-08 18:55:59 --> Controller Class Initialized
INFO - 2023-05-08 18:55:59 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:55:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:55:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:55:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:55:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:55:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:55:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:55:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:55:59 --> Final output sent to browser
INFO - 2023-05-08 18:57:07 --> Config Class Initialized
INFO - 2023-05-08 18:57:07 --> Hooks Class Initialized
INFO - 2023-05-08 18:57:07 --> Utf8 Class Initialized
INFO - 2023-05-08 18:57:07 --> URI Class Initialized
INFO - 2023-05-08 18:57:07 --> Router Class Initialized
INFO - 2023-05-08 18:57:07 --> Output Class Initialized
INFO - 2023-05-08 18:57:07 --> Security Class Initialized
INFO - 2023-05-08 18:57:07 --> Input Class Initialized
INFO - 2023-05-08 18:57:07 --> Language Class Initialized
INFO - 2023-05-08 18:57:07 --> Loader Class Initialized
INFO - 2023-05-08 18:57:07 --> Helper loaded: url_helper
INFO - 2023-05-08 18:57:07 --> Helper loaded: form_helper
INFO - 2023-05-08 18:57:07 --> Database Driver Class Initialized
INFO - 2023-05-08 18:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:57:07 --> Form Validation Class Initialized
INFO - 2023-05-08 18:57:07 --> Controller Class Initialized
INFO - 2023-05-08 18:57:07 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:57:07 --> Config Class Initialized
INFO - 2023-05-08 18:57:07 --> Hooks Class Initialized
INFO - 2023-05-08 18:57:07 --> Utf8 Class Initialized
INFO - 2023-05-08 18:57:07 --> URI Class Initialized
INFO - 2023-05-08 18:57:07 --> Router Class Initialized
INFO - 2023-05-08 18:57:07 --> Output Class Initialized
INFO - 2023-05-08 18:57:07 --> Security Class Initialized
INFO - 2023-05-08 18:57:07 --> Input Class Initialized
INFO - 2023-05-08 18:57:07 --> Language Class Initialized
INFO - 2023-05-08 18:57:07 --> Loader Class Initialized
INFO - 2023-05-08 18:57:07 --> Helper loaded: url_helper
INFO - 2023-05-08 18:57:07 --> Helper loaded: form_helper
INFO - 2023-05-08 18:57:07 --> Database Driver Class Initialized
INFO - 2023-05-08 18:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:57:07 --> Form Validation Class Initialized
INFO - 2023-05-08 18:57:07 --> Controller Class Initialized
INFO - 2023-05-08 18:57:07 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:57:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:57:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:57:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 18:57:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:57:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:57:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:57:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:57:07 --> Final output sent to browser
INFO - 2023-05-08 18:57:11 --> Config Class Initialized
INFO - 2023-05-08 18:57:11 --> Hooks Class Initialized
INFO - 2023-05-08 18:57:11 --> Utf8 Class Initialized
INFO - 2023-05-08 18:57:11 --> URI Class Initialized
INFO - 2023-05-08 18:57:11 --> Router Class Initialized
INFO - 2023-05-08 18:57:11 --> Output Class Initialized
INFO - 2023-05-08 18:57:11 --> Security Class Initialized
INFO - 2023-05-08 18:57:11 --> Input Class Initialized
INFO - 2023-05-08 18:57:11 --> Language Class Initialized
INFO - 2023-05-08 18:57:11 --> Loader Class Initialized
INFO - 2023-05-08 18:57:11 --> Helper loaded: url_helper
INFO - 2023-05-08 18:57:11 --> Helper loaded: form_helper
INFO - 2023-05-08 18:57:11 --> Database Driver Class Initialized
INFO - 2023-05-08 18:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:57:11 --> Form Validation Class Initialized
INFO - 2023-05-08 18:57:11 --> Controller Class Initialized
INFO - 2023-05-08 18:57:11 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:57:11 --> Final output sent to browser
INFO - 2023-05-08 18:57:39 --> Config Class Initialized
INFO - 2023-05-08 18:57:39 --> Hooks Class Initialized
INFO - 2023-05-08 18:57:39 --> Utf8 Class Initialized
INFO - 2023-05-08 18:57:39 --> URI Class Initialized
INFO - 2023-05-08 18:57:39 --> Router Class Initialized
INFO - 2023-05-08 18:57:39 --> Output Class Initialized
INFO - 2023-05-08 18:57:39 --> Security Class Initialized
INFO - 2023-05-08 18:57:39 --> Input Class Initialized
INFO - 2023-05-08 18:57:39 --> Language Class Initialized
INFO - 2023-05-08 18:57:39 --> Loader Class Initialized
INFO - 2023-05-08 18:57:39 --> Helper loaded: url_helper
INFO - 2023-05-08 18:57:39 --> Helper loaded: form_helper
INFO - 2023-05-08 18:57:39 --> Database Driver Class Initialized
INFO - 2023-05-08 18:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:57:39 --> Form Validation Class Initialized
INFO - 2023-05-08 18:57:39 --> Controller Class Initialized
INFO - 2023-05-08 18:57:39 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:57:39 --> Config Class Initialized
INFO - 2023-05-08 18:57:39 --> Hooks Class Initialized
INFO - 2023-05-08 18:57:39 --> Utf8 Class Initialized
INFO - 2023-05-08 18:57:39 --> URI Class Initialized
INFO - 2023-05-08 18:57:39 --> Router Class Initialized
INFO - 2023-05-08 18:57:39 --> Output Class Initialized
INFO - 2023-05-08 18:57:39 --> Security Class Initialized
INFO - 2023-05-08 18:57:39 --> Input Class Initialized
INFO - 2023-05-08 18:57:39 --> Language Class Initialized
INFO - 2023-05-08 18:57:39 --> Loader Class Initialized
INFO - 2023-05-08 18:57:39 --> Helper loaded: url_helper
INFO - 2023-05-08 18:57:39 --> Helper loaded: form_helper
INFO - 2023-05-08 18:57:39 --> Database Driver Class Initialized
INFO - 2023-05-08 18:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:57:39 --> Form Validation Class Initialized
INFO - 2023-05-08 18:57:39 --> Controller Class Initialized
INFO - 2023-05-08 18:57:39 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:57:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:57:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:57:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 18:57:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:57:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:57:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:57:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:57:39 --> Final output sent to browser
INFO - 2023-05-08 18:58:40 --> Config Class Initialized
INFO - 2023-05-08 18:58:40 --> Hooks Class Initialized
INFO - 2023-05-08 18:58:40 --> Utf8 Class Initialized
INFO - 2023-05-08 18:58:40 --> URI Class Initialized
INFO - 2023-05-08 18:58:40 --> Router Class Initialized
INFO - 2023-05-08 18:58:40 --> Output Class Initialized
INFO - 2023-05-08 18:58:40 --> Security Class Initialized
INFO - 2023-05-08 18:58:40 --> Input Class Initialized
INFO - 2023-05-08 18:58:40 --> Language Class Initialized
INFO - 2023-05-08 18:58:40 --> Loader Class Initialized
INFO - 2023-05-08 18:58:40 --> Helper loaded: url_helper
INFO - 2023-05-08 18:58:40 --> Helper loaded: form_helper
INFO - 2023-05-08 18:58:41 --> Database Driver Class Initialized
INFO - 2023-05-08 18:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:58:41 --> Form Validation Class Initialized
INFO - 2023-05-08 18:58:41 --> Controller Class Initialized
INFO - 2023-05-08 18:58:41 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 18:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:58:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:58:41 --> Final output sent to browser
INFO - 2023-05-08 18:58:43 --> Config Class Initialized
INFO - 2023-05-08 18:58:43 --> Hooks Class Initialized
INFO - 2023-05-08 18:58:43 --> Utf8 Class Initialized
INFO - 2023-05-08 18:58:43 --> URI Class Initialized
INFO - 2023-05-08 18:58:43 --> Router Class Initialized
INFO - 2023-05-08 18:58:43 --> Output Class Initialized
INFO - 2023-05-08 18:58:43 --> Security Class Initialized
INFO - 2023-05-08 18:58:43 --> Input Class Initialized
INFO - 2023-05-08 18:58:43 --> Language Class Initialized
INFO - 2023-05-08 18:58:43 --> Loader Class Initialized
INFO - 2023-05-08 18:58:43 --> Helper loaded: url_helper
INFO - 2023-05-08 18:58:43 --> Helper loaded: form_helper
INFO - 2023-05-08 18:58:43 --> Database Driver Class Initialized
INFO - 2023-05-08 18:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:58:43 --> Form Validation Class Initialized
INFO - 2023-05-08 18:58:43 --> Controller Class Initialized
INFO - 2023-05-08 18:58:43 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:58:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:58:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:58:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 18:58:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:58:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:58:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:58:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:58:43 --> Final output sent to browser
INFO - 2023-05-08 18:58:59 --> Config Class Initialized
INFO - 2023-05-08 18:58:59 --> Hooks Class Initialized
INFO - 2023-05-08 18:58:59 --> Utf8 Class Initialized
INFO - 2023-05-08 18:58:59 --> URI Class Initialized
INFO - 2023-05-08 18:58:59 --> Router Class Initialized
INFO - 2023-05-08 18:58:59 --> Output Class Initialized
INFO - 2023-05-08 18:58:59 --> Security Class Initialized
INFO - 2023-05-08 18:58:59 --> Input Class Initialized
INFO - 2023-05-08 18:58:59 --> Language Class Initialized
INFO - 2023-05-08 18:58:59 --> Loader Class Initialized
INFO - 2023-05-08 18:58:59 --> Helper loaded: url_helper
INFO - 2023-05-08 18:58:59 --> Helper loaded: form_helper
INFO - 2023-05-08 18:58:59 --> Database Driver Class Initialized
INFO - 2023-05-08 18:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:58:59 --> Form Validation Class Initialized
INFO - 2023-05-08 18:58:59 --> Controller Class Initialized
INFO - 2023-05-08 18:58:59 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:58:59 --> Config Class Initialized
INFO - 2023-05-08 18:58:59 --> Hooks Class Initialized
INFO - 2023-05-08 18:58:59 --> Utf8 Class Initialized
INFO - 2023-05-08 18:58:59 --> URI Class Initialized
INFO - 2023-05-08 18:58:59 --> Router Class Initialized
INFO - 2023-05-08 18:58:59 --> Output Class Initialized
INFO - 2023-05-08 18:58:59 --> Security Class Initialized
INFO - 2023-05-08 18:58:59 --> Input Class Initialized
INFO - 2023-05-08 18:58:59 --> Language Class Initialized
INFO - 2023-05-08 18:58:59 --> Loader Class Initialized
INFO - 2023-05-08 18:58:59 --> Helper loaded: url_helper
INFO - 2023-05-08 18:58:59 --> Helper loaded: form_helper
INFO - 2023-05-08 18:58:59 --> Database Driver Class Initialized
INFO - 2023-05-08 18:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 18:58:59 --> Form Validation Class Initialized
INFO - 2023-05-08 18:58:59 --> Controller Class Initialized
INFO - 2023-05-08 18:58:59 --> Model "m_datatrain" initialized
INFO - 2023-05-08 18:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 18:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 18:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 18:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 18:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 18:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 18:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 18:58:59 --> Final output sent to browser
INFO - 2023-05-08 19:02:53 --> Config Class Initialized
INFO - 2023-05-08 19:02:53 --> Hooks Class Initialized
INFO - 2023-05-08 19:02:53 --> Utf8 Class Initialized
INFO - 2023-05-08 19:02:53 --> URI Class Initialized
INFO - 2023-05-08 19:02:53 --> Router Class Initialized
INFO - 2023-05-08 19:02:53 --> Output Class Initialized
INFO - 2023-05-08 19:02:53 --> Security Class Initialized
INFO - 2023-05-08 19:02:53 --> Input Class Initialized
INFO - 2023-05-08 19:02:53 --> Language Class Initialized
INFO - 2023-05-08 19:02:53 --> Loader Class Initialized
INFO - 2023-05-08 19:02:53 --> Helper loaded: url_helper
INFO - 2023-05-08 19:02:53 --> Helper loaded: form_helper
INFO - 2023-05-08 19:02:53 --> Database Driver Class Initialized
INFO - 2023-05-08 19:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:02:53 --> Form Validation Class Initialized
INFO - 2023-05-08 19:02:53 --> Controller Class Initialized
INFO - 2023-05-08 19:02:53 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 19:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:02:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:02:53 --> Final output sent to browser
INFO - 2023-05-08 19:02:58 --> Config Class Initialized
INFO - 2023-05-08 19:02:58 --> Hooks Class Initialized
INFO - 2023-05-08 19:02:58 --> Utf8 Class Initialized
INFO - 2023-05-08 19:02:58 --> URI Class Initialized
INFO - 2023-05-08 19:02:58 --> Router Class Initialized
INFO - 2023-05-08 19:02:58 --> Output Class Initialized
INFO - 2023-05-08 19:02:58 --> Security Class Initialized
INFO - 2023-05-08 19:02:58 --> Input Class Initialized
INFO - 2023-05-08 19:02:58 --> Language Class Initialized
INFO - 2023-05-08 19:02:58 --> Loader Class Initialized
INFO - 2023-05-08 19:02:58 --> Helper loaded: url_helper
INFO - 2023-05-08 19:02:58 --> Helper loaded: form_helper
INFO - 2023-05-08 19:02:58 --> Database Driver Class Initialized
INFO - 2023-05-08 19:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:02:58 --> Form Validation Class Initialized
INFO - 2023-05-08 19:02:58 --> Controller Class Initialized
INFO - 2023-05-08 19:02:58 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 19:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:02:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:02:58 --> Final output sent to browser
INFO - 2023-05-08 19:03:39 --> Config Class Initialized
INFO - 2023-05-08 19:03:39 --> Hooks Class Initialized
INFO - 2023-05-08 19:03:39 --> Utf8 Class Initialized
INFO - 2023-05-08 19:03:39 --> URI Class Initialized
INFO - 2023-05-08 19:03:39 --> Router Class Initialized
INFO - 2023-05-08 19:03:39 --> Output Class Initialized
INFO - 2023-05-08 19:03:39 --> Security Class Initialized
INFO - 2023-05-08 19:03:39 --> Input Class Initialized
INFO - 2023-05-08 19:03:39 --> Language Class Initialized
INFO - 2023-05-08 19:03:39 --> Loader Class Initialized
INFO - 2023-05-08 19:03:39 --> Helper loaded: url_helper
INFO - 2023-05-08 19:03:39 --> Helper loaded: form_helper
INFO - 2023-05-08 19:03:39 --> Database Driver Class Initialized
INFO - 2023-05-08 19:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:03:39 --> Form Validation Class Initialized
INFO - 2023-05-08 19:03:39 --> Controller Class Initialized
INFO - 2023-05-08 19:03:39 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:03:39 --> Config Class Initialized
INFO - 2023-05-08 19:03:39 --> Hooks Class Initialized
INFO - 2023-05-08 19:03:39 --> Utf8 Class Initialized
INFO - 2023-05-08 19:03:39 --> URI Class Initialized
INFO - 2023-05-08 19:03:39 --> Router Class Initialized
INFO - 2023-05-08 19:03:39 --> Output Class Initialized
INFO - 2023-05-08 19:03:39 --> Security Class Initialized
INFO - 2023-05-08 19:03:39 --> Input Class Initialized
INFO - 2023-05-08 19:03:39 --> Language Class Initialized
INFO - 2023-05-08 19:03:39 --> Loader Class Initialized
INFO - 2023-05-08 19:03:39 --> Helper loaded: url_helper
INFO - 2023-05-08 19:03:39 --> Helper loaded: form_helper
INFO - 2023-05-08 19:03:39 --> Database Driver Class Initialized
INFO - 2023-05-08 19:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:03:39 --> Form Validation Class Initialized
INFO - 2023-05-08 19:03:39 --> Controller Class Initialized
INFO - 2023-05-08 19:03:39 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:03:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:03:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:03:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 19:03:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:03:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:03:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:03:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:03:39 --> Final output sent to browser
INFO - 2023-05-08 19:03:55 --> Config Class Initialized
INFO - 2023-05-08 19:03:55 --> Hooks Class Initialized
INFO - 2023-05-08 19:03:55 --> Utf8 Class Initialized
INFO - 2023-05-08 19:03:55 --> URI Class Initialized
INFO - 2023-05-08 19:03:55 --> Router Class Initialized
INFO - 2023-05-08 19:03:55 --> Output Class Initialized
INFO - 2023-05-08 19:03:55 --> Security Class Initialized
INFO - 2023-05-08 19:03:55 --> Input Class Initialized
INFO - 2023-05-08 19:03:55 --> Language Class Initialized
INFO - 2023-05-08 19:03:55 --> Loader Class Initialized
INFO - 2023-05-08 19:03:55 --> Helper loaded: url_helper
INFO - 2023-05-08 19:03:55 --> Helper loaded: form_helper
INFO - 2023-05-08 19:03:55 --> Database Driver Class Initialized
INFO - 2023-05-08 19:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:03:55 --> Form Validation Class Initialized
INFO - 2023-05-08 19:03:55 --> Controller Class Initialized
INFO - 2023-05-08 19:03:55 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:03:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:03:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:03:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 19:03:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:03:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:03:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:03:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:03:55 --> Final output sent to browser
INFO - 2023-05-08 19:04:41 --> Config Class Initialized
INFO - 2023-05-08 19:04:41 --> Hooks Class Initialized
INFO - 2023-05-08 19:04:41 --> Utf8 Class Initialized
INFO - 2023-05-08 19:04:41 --> URI Class Initialized
INFO - 2023-05-08 19:04:41 --> Router Class Initialized
INFO - 2023-05-08 19:04:41 --> Output Class Initialized
INFO - 2023-05-08 19:04:41 --> Security Class Initialized
INFO - 2023-05-08 19:04:41 --> Input Class Initialized
INFO - 2023-05-08 19:04:41 --> Language Class Initialized
INFO - 2023-05-08 19:04:41 --> Loader Class Initialized
INFO - 2023-05-08 19:04:41 --> Helper loaded: url_helper
INFO - 2023-05-08 19:04:41 --> Helper loaded: form_helper
INFO - 2023-05-08 19:04:41 --> Database Driver Class Initialized
INFO - 2023-05-08 19:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:04:41 --> Form Validation Class Initialized
INFO - 2023-05-08 19:04:41 --> Controller Class Initialized
INFO - 2023-05-08 19:04:41 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:04:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:04:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:04:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 19:04:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:04:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:04:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:04:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:04:41 --> Final output sent to browser
INFO - 2023-05-08 19:06:08 --> Config Class Initialized
INFO - 2023-05-08 19:06:08 --> Hooks Class Initialized
INFO - 2023-05-08 19:06:08 --> Utf8 Class Initialized
INFO - 2023-05-08 19:06:08 --> URI Class Initialized
INFO - 2023-05-08 19:06:08 --> Router Class Initialized
INFO - 2023-05-08 19:06:08 --> Output Class Initialized
INFO - 2023-05-08 19:06:08 --> Security Class Initialized
INFO - 2023-05-08 19:06:08 --> Input Class Initialized
INFO - 2023-05-08 19:06:08 --> Language Class Initialized
INFO - 2023-05-08 19:06:08 --> Loader Class Initialized
INFO - 2023-05-08 19:06:08 --> Helper loaded: url_helper
INFO - 2023-05-08 19:06:08 --> Helper loaded: form_helper
INFO - 2023-05-08 19:06:08 --> Database Driver Class Initialized
INFO - 2023-05-08 19:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:06:08 --> Form Validation Class Initialized
INFO - 2023-05-08 19:06:08 --> Controller Class Initialized
INFO - 2023-05-08 19:06:08 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:06:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:06:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:06:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 19:06:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:06:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:06:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:06:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:06:08 --> Final output sent to browser
INFO - 2023-05-08 19:06:19 --> Config Class Initialized
INFO - 2023-05-08 19:06:19 --> Hooks Class Initialized
INFO - 2023-05-08 19:06:19 --> Utf8 Class Initialized
INFO - 2023-05-08 19:06:19 --> URI Class Initialized
INFO - 2023-05-08 19:06:19 --> Router Class Initialized
INFO - 2023-05-08 19:06:19 --> Output Class Initialized
INFO - 2023-05-08 19:06:19 --> Security Class Initialized
INFO - 2023-05-08 19:06:19 --> Input Class Initialized
INFO - 2023-05-08 19:06:19 --> Language Class Initialized
INFO - 2023-05-08 19:06:19 --> Loader Class Initialized
INFO - 2023-05-08 19:06:19 --> Helper loaded: url_helper
INFO - 2023-05-08 19:06:19 --> Helper loaded: form_helper
INFO - 2023-05-08 19:06:19 --> Database Driver Class Initialized
INFO - 2023-05-08 19:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:06:19 --> Form Validation Class Initialized
INFO - 2023-05-08 19:06:19 --> Controller Class Initialized
INFO - 2023-05-08 19:06:19 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:06:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:06:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:06:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 19:06:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:06:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:06:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:06:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:06:19 --> Final output sent to browser
INFO - 2023-05-08 19:06:35 --> Config Class Initialized
INFO - 2023-05-08 19:06:35 --> Hooks Class Initialized
INFO - 2023-05-08 19:06:35 --> Utf8 Class Initialized
INFO - 2023-05-08 19:06:35 --> URI Class Initialized
INFO - 2023-05-08 19:06:35 --> Router Class Initialized
INFO - 2023-05-08 19:06:35 --> Output Class Initialized
INFO - 2023-05-08 19:06:35 --> Security Class Initialized
INFO - 2023-05-08 19:06:35 --> Input Class Initialized
INFO - 2023-05-08 19:06:35 --> Language Class Initialized
INFO - 2023-05-08 19:06:35 --> Loader Class Initialized
INFO - 2023-05-08 19:06:35 --> Helper loaded: url_helper
INFO - 2023-05-08 19:06:35 --> Helper loaded: form_helper
INFO - 2023-05-08 19:06:35 --> Database Driver Class Initialized
INFO - 2023-05-08 19:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:06:35 --> Form Validation Class Initialized
INFO - 2023-05-08 19:06:35 --> Controller Class Initialized
INFO - 2023-05-08 19:06:35 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:06:35 --> Config Class Initialized
INFO - 2023-05-08 19:06:35 --> Hooks Class Initialized
INFO - 2023-05-08 19:06:35 --> Utf8 Class Initialized
INFO - 2023-05-08 19:06:35 --> URI Class Initialized
INFO - 2023-05-08 19:06:35 --> Router Class Initialized
INFO - 2023-05-08 19:06:35 --> Output Class Initialized
INFO - 2023-05-08 19:06:35 --> Security Class Initialized
INFO - 2023-05-08 19:06:35 --> Input Class Initialized
INFO - 2023-05-08 19:06:35 --> Language Class Initialized
INFO - 2023-05-08 19:06:35 --> Loader Class Initialized
INFO - 2023-05-08 19:06:35 --> Helper loaded: url_helper
INFO - 2023-05-08 19:06:35 --> Helper loaded: form_helper
INFO - 2023-05-08 19:06:35 --> Database Driver Class Initialized
INFO - 2023-05-08 19:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:06:35 --> Form Validation Class Initialized
INFO - 2023-05-08 19:06:35 --> Controller Class Initialized
INFO - 2023-05-08 19:06:35 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:06:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:06:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:06:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 19:06:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:06:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:06:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:06:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:06:35 --> Final output sent to browser
INFO - 2023-05-08 19:14:08 --> Config Class Initialized
INFO - 2023-05-08 19:14:08 --> Hooks Class Initialized
INFO - 2023-05-08 19:14:08 --> Utf8 Class Initialized
INFO - 2023-05-08 19:14:08 --> URI Class Initialized
INFO - 2023-05-08 19:14:08 --> Router Class Initialized
INFO - 2023-05-08 19:14:08 --> Output Class Initialized
INFO - 2023-05-08 19:14:08 --> Security Class Initialized
INFO - 2023-05-08 19:14:08 --> Input Class Initialized
INFO - 2023-05-08 19:14:08 --> Language Class Initialized
INFO - 2023-05-08 19:14:08 --> Loader Class Initialized
INFO - 2023-05-08 19:14:08 --> Helper loaded: url_helper
INFO - 2023-05-08 19:14:08 --> Helper loaded: form_helper
INFO - 2023-05-08 19:14:08 --> Database Driver Class Initialized
INFO - 2023-05-08 19:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:14:08 --> Form Validation Class Initialized
INFO - 2023-05-08 19:14:08 --> Controller Class Initialized
INFO - 2023-05-08 19:14:08 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:14:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:14:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:14:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 19:14:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:14:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:14:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:14:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:14:08 --> Final output sent to browser
INFO - 2023-05-08 19:16:27 --> Config Class Initialized
INFO - 2023-05-08 19:16:27 --> Hooks Class Initialized
INFO - 2023-05-08 19:16:27 --> Utf8 Class Initialized
INFO - 2023-05-08 19:16:27 --> URI Class Initialized
INFO - 2023-05-08 19:16:27 --> Router Class Initialized
INFO - 2023-05-08 19:16:27 --> Output Class Initialized
INFO - 2023-05-08 19:16:27 --> Security Class Initialized
INFO - 2023-05-08 19:16:27 --> Input Class Initialized
INFO - 2023-05-08 19:16:27 --> Language Class Initialized
INFO - 2023-05-08 19:16:27 --> Loader Class Initialized
INFO - 2023-05-08 19:16:27 --> Helper loaded: url_helper
INFO - 2023-05-08 19:16:27 --> Helper loaded: form_helper
INFO - 2023-05-08 19:16:27 --> Database Driver Class Initialized
INFO - 2023-05-08 19:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:16:27 --> Form Validation Class Initialized
INFO - 2023-05-08 19:16:27 --> Controller Class Initialized
INFO - 2023-05-08 19:16:27 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 19:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:16:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:16:27 --> Final output sent to browser
INFO - 2023-05-08 19:29:59 --> Config Class Initialized
INFO - 2023-05-08 19:29:59 --> Hooks Class Initialized
INFO - 2023-05-08 19:29:59 --> Utf8 Class Initialized
INFO - 2023-05-08 19:29:59 --> URI Class Initialized
INFO - 2023-05-08 19:29:59 --> Router Class Initialized
INFO - 2023-05-08 19:29:59 --> Output Class Initialized
INFO - 2023-05-08 19:29:59 --> Security Class Initialized
INFO - 2023-05-08 19:29:59 --> Input Class Initialized
INFO - 2023-05-08 19:29:59 --> Language Class Initialized
INFO - 2023-05-08 19:29:59 --> Loader Class Initialized
INFO - 2023-05-08 19:29:59 --> Helper loaded: url_helper
INFO - 2023-05-08 19:29:59 --> Helper loaded: form_helper
INFO - 2023-05-08 19:29:59 --> Database Driver Class Initialized
INFO - 2023-05-08 19:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:29:59 --> Form Validation Class Initialized
INFO - 2023-05-08 19:29:59 --> Controller Class Initialized
INFO - 2023-05-08 19:29:59 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 19:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:29:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:29:59 --> Final output sent to browser
INFO - 2023-05-08 19:30:59 --> Config Class Initialized
INFO - 2023-05-08 19:30:59 --> Hooks Class Initialized
INFO - 2023-05-08 19:30:59 --> Utf8 Class Initialized
INFO - 2023-05-08 19:30:59 --> URI Class Initialized
INFO - 2023-05-08 19:30:59 --> Router Class Initialized
INFO - 2023-05-08 19:30:59 --> Output Class Initialized
INFO - 2023-05-08 19:30:59 --> Security Class Initialized
INFO - 2023-05-08 19:30:59 --> Input Class Initialized
INFO - 2023-05-08 19:30:59 --> Language Class Initialized
INFO - 2023-05-08 19:30:59 --> Loader Class Initialized
INFO - 2023-05-08 19:30:59 --> Helper loaded: url_helper
INFO - 2023-05-08 19:30:59 --> Helper loaded: form_helper
INFO - 2023-05-08 19:30:59 --> Database Driver Class Initialized
INFO - 2023-05-08 19:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:30:59 --> Form Validation Class Initialized
INFO - 2023-05-08 19:30:59 --> Controller Class Initialized
INFO - 2023-05-08 19:30:59 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:30:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:30:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:30:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-08 19:30:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:30:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:30:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:30:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:30:59 --> Final output sent to browser
INFO - 2023-05-08 19:31:08 --> Config Class Initialized
INFO - 2023-05-08 19:31:08 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:08 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:08 --> URI Class Initialized
INFO - 2023-05-08 19:31:08 --> Router Class Initialized
INFO - 2023-05-08 19:31:08 --> Output Class Initialized
INFO - 2023-05-08 19:31:08 --> Security Class Initialized
INFO - 2023-05-08 19:31:08 --> Input Class Initialized
INFO - 2023-05-08 19:31:08 --> Language Class Initialized
INFO - 2023-05-08 19:31:08 --> Loader Class Initialized
INFO - 2023-05-08 19:31:08 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:08 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:08 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:08 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:08 --> Controller Class Initialized
INFO - 2023-05-08 19:31:08 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:31:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:31:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:31:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 19:31:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:31:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:31:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:31:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:31:08 --> Final output sent to browser
INFO - 2023-05-08 19:31:11 --> Config Class Initialized
INFO - 2023-05-08 19:31:11 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:11 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:11 --> URI Class Initialized
INFO - 2023-05-08 19:31:11 --> Router Class Initialized
INFO - 2023-05-08 19:31:11 --> Output Class Initialized
INFO - 2023-05-08 19:31:11 --> Security Class Initialized
INFO - 2023-05-08 19:31:11 --> Input Class Initialized
INFO - 2023-05-08 19:31:11 --> Language Class Initialized
ERROR - 2023-05-08 19:31:11 --> 404 Page Not Found: Tutor/index
INFO - 2023-05-08 19:31:13 --> Config Class Initialized
INFO - 2023-05-08 19:31:13 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:13 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:13 --> URI Class Initialized
INFO - 2023-05-08 19:31:13 --> Router Class Initialized
INFO - 2023-05-08 19:31:13 --> Output Class Initialized
INFO - 2023-05-08 19:31:13 --> Security Class Initialized
INFO - 2023-05-08 19:31:13 --> Input Class Initialized
INFO - 2023-05-08 19:31:13 --> Language Class Initialized
INFO - 2023-05-08 19:31:13 --> Loader Class Initialized
INFO - 2023-05-08 19:31:13 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:13 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:13 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:13 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:13 --> Controller Class Initialized
INFO - 2023-05-08 19:31:13 --> Model "m_datatrain" initialized
INFO - 2023-05-08 19:31:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:31:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:31:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-08 19:31:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:31:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:31:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:31:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-08 19:31:13 --> Final output sent to browser
INFO - 2023-05-08 19:31:14 --> Config Class Initialized
INFO - 2023-05-08 19:31:14 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:14 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:14 --> URI Class Initialized
INFO - 2023-05-08 19:31:14 --> Router Class Initialized
INFO - 2023-05-08 19:31:14 --> Output Class Initialized
INFO - 2023-05-08 19:31:14 --> Security Class Initialized
INFO - 2023-05-08 19:31:14 --> Input Class Initialized
INFO - 2023-05-08 19:31:14 --> Language Class Initialized
INFO - 2023-05-08 19:31:14 --> Loader Class Initialized
INFO - 2023-05-08 19:31:14 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:14 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:14 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:14 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:14 --> Controller Class Initialized
INFO - 2023-05-08 19:31:14 --> Model "m_user" initialized
INFO - 2023-05-08 19:31:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:31:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:31:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:31:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:31:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:31:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 19:31:14 --> Final output sent to browser
INFO - 2023-05-08 19:31:15 --> Config Class Initialized
INFO - 2023-05-08 19:31:15 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:15 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:15 --> URI Class Initialized
INFO - 2023-05-08 19:31:15 --> Router Class Initialized
INFO - 2023-05-08 19:31:15 --> Output Class Initialized
INFO - 2023-05-08 19:31:15 --> Security Class Initialized
INFO - 2023-05-08 19:31:15 --> Input Class Initialized
INFO - 2023-05-08 19:31:15 --> Language Class Initialized
ERROR - 2023-05-08 19:31:15 --> 404 Page Not Found: C_todo_list/index
INFO - 2023-05-08 19:31:17 --> Config Class Initialized
INFO - 2023-05-08 19:31:17 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:17 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:17 --> URI Class Initialized
INFO - 2023-05-08 19:31:17 --> Router Class Initialized
INFO - 2023-05-08 19:31:17 --> Output Class Initialized
INFO - 2023-05-08 19:31:17 --> Security Class Initialized
INFO - 2023-05-08 19:31:17 --> Input Class Initialized
INFO - 2023-05-08 19:31:17 --> Language Class Initialized
INFO - 2023-05-08 19:31:17 --> Loader Class Initialized
INFO - 2023-05-08 19:31:17 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:17 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:17 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:17 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:17 --> Controller Class Initialized
INFO - 2023-05-08 19:31:17 --> Model "m_user" initialized
INFO - 2023-05-08 19:31:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:31:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:31:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:31:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:31:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:31:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 19:31:17 --> Final output sent to browser
INFO - 2023-05-08 19:31:21 --> Config Class Initialized
INFO - 2023-05-08 19:31:21 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:21 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:21 --> URI Class Initialized
INFO - 2023-05-08 19:31:21 --> Router Class Initialized
INFO - 2023-05-08 19:31:21 --> Output Class Initialized
INFO - 2023-05-08 19:31:21 --> Security Class Initialized
INFO - 2023-05-08 19:31:21 --> Input Class Initialized
INFO - 2023-05-08 19:31:21 --> Language Class Initialized
INFO - 2023-05-08 19:31:21 --> Loader Class Initialized
INFO - 2023-05-08 19:31:21 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:21 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:21 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:21 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:21 --> Controller Class Initialized
INFO - 2023-05-08 19:31:21 --> Model "m_user" initialized
INFO - 2023-05-08 19:31:21 --> Config Class Initialized
INFO - 2023-05-08 19:31:21 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:21 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:21 --> URI Class Initialized
INFO - 2023-05-08 19:31:21 --> Router Class Initialized
INFO - 2023-05-08 19:31:21 --> Output Class Initialized
INFO - 2023-05-08 19:31:21 --> Security Class Initialized
INFO - 2023-05-08 19:31:21 --> Input Class Initialized
INFO - 2023-05-08 19:31:21 --> Language Class Initialized
INFO - 2023-05-08 19:31:21 --> Loader Class Initialized
INFO - 2023-05-08 19:31:21 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:21 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:21 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:21 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:21 --> Controller Class Initialized
INFO - 2023-05-08 19:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 19:31:21 --> Final output sent to browser
INFO - 2023-05-08 19:31:22 --> Config Class Initialized
INFO - 2023-05-08 19:31:22 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:22 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:22 --> URI Class Initialized
INFO - 2023-05-08 19:31:22 --> Router Class Initialized
INFO - 2023-05-08 19:31:22 --> Output Class Initialized
INFO - 2023-05-08 19:31:22 --> Security Class Initialized
INFO - 2023-05-08 19:31:22 --> Input Class Initialized
INFO - 2023-05-08 19:31:22 --> Language Class Initialized
INFO - 2023-05-08 19:31:22 --> Loader Class Initialized
INFO - 2023-05-08 19:31:22 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:22 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:22 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:22 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:22 --> Controller Class Initialized
INFO - 2023-05-08 19:31:22 --> Model "m_user" initialized
INFO - 2023-05-08 19:31:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:31:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:31:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-08 19:31:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:31:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:31:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-08 19:31:22 --> Final output sent to browser
INFO - 2023-05-08 19:31:32 --> Config Class Initialized
INFO - 2023-05-08 19:31:32 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:32 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:32 --> URI Class Initialized
INFO - 2023-05-08 19:31:32 --> Router Class Initialized
INFO - 2023-05-08 19:31:32 --> Output Class Initialized
INFO - 2023-05-08 19:31:32 --> Security Class Initialized
INFO - 2023-05-08 19:31:32 --> Input Class Initialized
INFO - 2023-05-08 19:31:32 --> Language Class Initialized
ERROR - 2023-05-08 19:31:32 --> 404 Page Not Found: C_tutor/form_ubah
INFO - 2023-05-08 19:31:40 --> Config Class Initialized
INFO - 2023-05-08 19:31:40 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:40 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:40 --> URI Class Initialized
INFO - 2023-05-08 19:31:40 --> Router Class Initialized
INFO - 2023-05-08 19:31:40 --> Output Class Initialized
INFO - 2023-05-08 19:31:40 --> Security Class Initialized
INFO - 2023-05-08 19:31:40 --> Input Class Initialized
INFO - 2023-05-08 19:31:40 --> Language Class Initialized
INFO - 2023-05-08 19:31:40 --> Loader Class Initialized
INFO - 2023-05-08 19:31:40 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:40 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:40 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:40 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:40 --> Controller Class Initialized
INFO - 2023-05-08 19:31:40 --> Model "m_user" initialized
INFO - 2023-05-08 19:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-08 19:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:31:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-08 19:31:40 --> Final output sent to browser
INFO - 2023-05-08 19:31:45 --> Config Class Initialized
INFO - 2023-05-08 19:31:45 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:45 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:45 --> URI Class Initialized
INFO - 2023-05-08 19:31:45 --> Router Class Initialized
INFO - 2023-05-08 19:31:45 --> Output Class Initialized
INFO - 2023-05-08 19:31:45 --> Security Class Initialized
INFO - 2023-05-08 19:31:45 --> Input Class Initialized
INFO - 2023-05-08 19:31:45 --> Language Class Initialized
INFO - 2023-05-08 19:31:45 --> Loader Class Initialized
INFO - 2023-05-08 19:31:45 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:45 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:45 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:45 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:45 --> Controller Class Initialized
INFO - 2023-05-08 19:31:45 --> Model "m_user" initialized
INFO - 2023-05-08 19:31:45 --> Config Class Initialized
INFO - 2023-05-08 19:31:45 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:45 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:45 --> URI Class Initialized
INFO - 2023-05-08 19:31:45 --> Router Class Initialized
INFO - 2023-05-08 19:31:45 --> Output Class Initialized
INFO - 2023-05-08 19:31:45 --> Security Class Initialized
INFO - 2023-05-08 19:31:45 --> Input Class Initialized
INFO - 2023-05-08 19:31:45 --> Language Class Initialized
INFO - 2023-05-08 19:31:45 --> Loader Class Initialized
INFO - 2023-05-08 19:31:45 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:45 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:45 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:45 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:45 --> Controller Class Initialized
INFO - 2023-05-08 19:31:45 --> Model "m_user" initialized
INFO - 2023-05-08 19:31:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-08 19:31:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-08 19:31:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-08 19:31:45 --> Final output sent to browser
INFO - 2023-05-08 19:31:52 --> Config Class Initialized
INFO - 2023-05-08 19:31:52 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:52 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:52 --> URI Class Initialized
INFO - 2023-05-08 19:31:52 --> Router Class Initialized
INFO - 2023-05-08 19:31:52 --> Output Class Initialized
INFO - 2023-05-08 19:31:52 --> Security Class Initialized
INFO - 2023-05-08 19:31:52 --> Input Class Initialized
INFO - 2023-05-08 19:31:52 --> Language Class Initialized
INFO - 2023-05-08 19:31:52 --> Loader Class Initialized
INFO - 2023-05-08 19:31:52 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:52 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:52 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:52 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:52 --> Controller Class Initialized
INFO - 2023-05-08 19:31:52 --> Model "m_user" initialized
INFO - 2023-05-08 19:31:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:31:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:31:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-08 19:31:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:31:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:31:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-08 19:31:52 --> Final output sent to browser
INFO - 2023-05-08 19:31:54 --> Config Class Initialized
INFO - 2023-05-08 19:31:54 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:54 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:54 --> URI Class Initialized
INFO - 2023-05-08 19:31:54 --> Router Class Initialized
INFO - 2023-05-08 19:31:54 --> Output Class Initialized
INFO - 2023-05-08 19:31:54 --> Security Class Initialized
INFO - 2023-05-08 19:31:54 --> Input Class Initialized
INFO - 2023-05-08 19:31:54 --> Language Class Initialized
INFO - 2023-05-08 19:31:54 --> Loader Class Initialized
INFO - 2023-05-08 19:31:54 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:54 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:54 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:54 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:54 --> Controller Class Initialized
INFO - 2023-05-08 19:31:54 --> Model "m_user" initialized
INFO - 2023-05-08 19:31:54 --> Config Class Initialized
INFO - 2023-05-08 19:31:54 --> Hooks Class Initialized
INFO - 2023-05-08 19:31:54 --> Utf8 Class Initialized
INFO - 2023-05-08 19:31:54 --> URI Class Initialized
INFO - 2023-05-08 19:31:54 --> Router Class Initialized
INFO - 2023-05-08 19:31:54 --> Output Class Initialized
INFO - 2023-05-08 19:31:54 --> Security Class Initialized
INFO - 2023-05-08 19:31:54 --> Input Class Initialized
INFO - 2023-05-08 19:31:54 --> Language Class Initialized
INFO - 2023-05-08 19:31:54 --> Loader Class Initialized
INFO - 2023-05-08 19:31:54 --> Helper loaded: url_helper
INFO - 2023-05-08 19:31:54 --> Helper loaded: form_helper
INFO - 2023-05-08 19:31:54 --> Database Driver Class Initialized
INFO - 2023-05-08 19:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:31:54 --> Form Validation Class Initialized
INFO - 2023-05-08 19:31:54 --> Controller Class Initialized
INFO - 2023-05-08 19:31:54 --> Model "m_user" initialized
INFO - 2023-05-08 19:31:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-08 19:31:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-08 19:31:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-08 19:31:54 --> Final output sent to browser
INFO - 2023-05-08 19:32:01 --> Config Class Initialized
INFO - 2023-05-08 19:32:01 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:01 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:01 --> URI Class Initialized
INFO - 2023-05-08 19:32:01 --> Router Class Initialized
INFO - 2023-05-08 19:32:01 --> Output Class Initialized
INFO - 2023-05-08 19:32:01 --> Security Class Initialized
INFO - 2023-05-08 19:32:01 --> Input Class Initialized
INFO - 2023-05-08 19:32:01 --> Language Class Initialized
INFO - 2023-05-08 19:32:01 --> Loader Class Initialized
INFO - 2023-05-08 19:32:01 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:01 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:01 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:01 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:01 --> Controller Class Initialized
INFO - 2023-05-08 19:32:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 19:32:01 --> Final output sent to browser
INFO - 2023-05-08 19:32:02 --> Config Class Initialized
INFO - 2023-05-08 19:32:02 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:02 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:02 --> URI Class Initialized
INFO - 2023-05-08 19:32:02 --> Router Class Initialized
INFO - 2023-05-08 19:32:02 --> Output Class Initialized
INFO - 2023-05-08 19:32:02 --> Security Class Initialized
INFO - 2023-05-08 19:32:02 --> Input Class Initialized
INFO - 2023-05-08 19:32:02 --> Language Class Initialized
INFO - 2023-05-08 19:32:02 --> Loader Class Initialized
INFO - 2023-05-08 19:32:02 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:02 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:02 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:02 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:02 --> Controller Class Initialized
INFO - 2023-05-08 19:32:02 --> Model "m_user" initialized
INFO - 2023-05-08 19:32:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:32:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:32:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-08 19:32:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:32:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:32:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-08 19:32:02 --> Final output sent to browser
INFO - 2023-05-08 19:32:06 --> Config Class Initialized
INFO - 2023-05-08 19:32:06 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:06 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:06 --> URI Class Initialized
INFO - 2023-05-08 19:32:06 --> Router Class Initialized
INFO - 2023-05-08 19:32:06 --> Output Class Initialized
INFO - 2023-05-08 19:32:06 --> Security Class Initialized
INFO - 2023-05-08 19:32:06 --> Input Class Initialized
INFO - 2023-05-08 19:32:06 --> Language Class Initialized
INFO - 2023-05-08 19:32:06 --> Loader Class Initialized
INFO - 2023-05-08 19:32:06 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:06 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:06 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:06 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:06 --> Controller Class Initialized
INFO - 2023-05-08 19:32:06 --> Model "m_user" initialized
INFO - 2023-05-08 19:32:06 --> Config Class Initialized
INFO - 2023-05-08 19:32:06 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:06 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:06 --> URI Class Initialized
INFO - 2023-05-08 19:32:06 --> Router Class Initialized
INFO - 2023-05-08 19:32:06 --> Output Class Initialized
INFO - 2023-05-08 19:32:06 --> Security Class Initialized
INFO - 2023-05-08 19:32:06 --> Input Class Initialized
INFO - 2023-05-08 19:32:06 --> Language Class Initialized
INFO - 2023-05-08 19:32:06 --> Loader Class Initialized
INFO - 2023-05-08 19:32:06 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:06 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:06 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:06 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:06 --> Controller Class Initialized
INFO - 2023-05-08 19:32:06 --> Model "m_user" initialized
INFO - 2023-05-08 19:32:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-08 19:32:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-08 19:32:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-08 19:32:06 --> Final output sent to browser
INFO - 2023-05-08 19:32:22 --> Config Class Initialized
INFO - 2023-05-08 19:32:22 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:22 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:22 --> URI Class Initialized
INFO - 2023-05-08 19:32:22 --> Router Class Initialized
INFO - 2023-05-08 19:32:22 --> Output Class Initialized
INFO - 2023-05-08 19:32:22 --> Security Class Initialized
INFO - 2023-05-08 19:32:22 --> Input Class Initialized
INFO - 2023-05-08 19:32:22 --> Language Class Initialized
INFO - 2023-05-08 19:32:22 --> Loader Class Initialized
INFO - 2023-05-08 19:32:22 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:22 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:22 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:22 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:22 --> Controller Class Initialized
INFO - 2023-05-08 19:32:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 19:32:22 --> Final output sent to browser
INFO - 2023-05-08 19:32:23 --> Config Class Initialized
INFO - 2023-05-08 19:32:23 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:23 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:23 --> URI Class Initialized
INFO - 2023-05-08 19:32:23 --> Router Class Initialized
INFO - 2023-05-08 19:32:23 --> Output Class Initialized
INFO - 2023-05-08 19:32:23 --> Security Class Initialized
INFO - 2023-05-08 19:32:23 --> Input Class Initialized
INFO - 2023-05-08 19:32:23 --> Language Class Initialized
INFO - 2023-05-08 19:32:23 --> Loader Class Initialized
INFO - 2023-05-08 19:32:23 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:23 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:23 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:23 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:23 --> Controller Class Initialized
INFO - 2023-05-08 19:32:23 --> Model "m_user" initialized
INFO - 2023-05-08 19:32:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:32:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:32:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-08 19:32:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:32:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:32:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-08 19:32:23 --> Final output sent to browser
INFO - 2023-05-08 19:32:27 --> Config Class Initialized
INFO - 2023-05-08 19:32:27 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:27 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:27 --> URI Class Initialized
INFO - 2023-05-08 19:32:27 --> Router Class Initialized
INFO - 2023-05-08 19:32:27 --> Output Class Initialized
INFO - 2023-05-08 19:32:27 --> Security Class Initialized
INFO - 2023-05-08 19:32:27 --> Input Class Initialized
INFO - 2023-05-08 19:32:27 --> Language Class Initialized
INFO - 2023-05-08 19:32:27 --> Loader Class Initialized
INFO - 2023-05-08 19:32:27 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:27 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:27 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:27 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:27 --> Controller Class Initialized
INFO - 2023-05-08 19:32:27 --> Model "m_user" initialized
INFO - 2023-05-08 19:32:27 --> Config Class Initialized
INFO - 2023-05-08 19:32:27 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:27 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:27 --> URI Class Initialized
INFO - 2023-05-08 19:32:27 --> Router Class Initialized
INFO - 2023-05-08 19:32:27 --> Output Class Initialized
INFO - 2023-05-08 19:32:27 --> Security Class Initialized
INFO - 2023-05-08 19:32:27 --> Input Class Initialized
INFO - 2023-05-08 19:32:27 --> Language Class Initialized
INFO - 2023-05-08 19:32:27 --> Loader Class Initialized
INFO - 2023-05-08 19:32:27 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:27 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:27 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:27 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:27 --> Controller Class Initialized
INFO - 2023-05-08 19:32:27 --> Model "m_user" initialized
INFO - 2023-05-08 19:32:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-08 19:32:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-08 19:32:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-08 19:32:27 --> Final output sent to browser
INFO - 2023-05-08 19:32:35 --> Config Class Initialized
INFO - 2023-05-08 19:32:35 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:35 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:35 --> URI Class Initialized
INFO - 2023-05-08 19:32:35 --> Router Class Initialized
INFO - 2023-05-08 19:32:35 --> Output Class Initialized
INFO - 2023-05-08 19:32:35 --> Security Class Initialized
INFO - 2023-05-08 19:32:35 --> Input Class Initialized
INFO - 2023-05-08 19:32:35 --> Language Class Initialized
INFO - 2023-05-08 19:32:35 --> Loader Class Initialized
INFO - 2023-05-08 19:32:35 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:35 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:35 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:35 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:35 --> Controller Class Initialized
INFO - 2023-05-08 19:32:35 --> Model "m_user" initialized
INFO - 2023-05-08 19:32:36 --> Config Class Initialized
INFO - 2023-05-08 19:32:36 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:36 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:36 --> URI Class Initialized
INFO - 2023-05-08 19:32:36 --> Router Class Initialized
INFO - 2023-05-08 19:32:36 --> Output Class Initialized
INFO - 2023-05-08 19:32:36 --> Security Class Initialized
INFO - 2023-05-08 19:32:36 --> Input Class Initialized
INFO - 2023-05-08 19:32:36 --> Language Class Initialized
INFO - 2023-05-08 19:32:36 --> Loader Class Initialized
INFO - 2023-05-08 19:32:36 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:36 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:36 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:36 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:36 --> Controller Class Initialized
INFO - 2023-05-08 19:32:36 --> Model "m_user" initialized
INFO - 2023-05-08 19:32:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:32:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:32:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:32:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:32:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:32:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 19:32:36 --> Final output sent to browser
INFO - 2023-05-08 19:32:38 --> Config Class Initialized
INFO - 2023-05-08 19:32:38 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:38 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:38 --> URI Class Initialized
INFO - 2023-05-08 19:32:38 --> Router Class Initialized
INFO - 2023-05-08 19:32:38 --> Output Class Initialized
INFO - 2023-05-08 19:32:38 --> Security Class Initialized
INFO - 2023-05-08 19:32:38 --> Input Class Initialized
INFO - 2023-05-08 19:32:38 --> Language Class Initialized
ERROR - 2023-05-08 19:32:38 --> 404 Page Not Found: Tutor/index
INFO - 2023-05-08 19:32:39 --> Config Class Initialized
INFO - 2023-05-08 19:32:39 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:39 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:39 --> URI Class Initialized
INFO - 2023-05-08 19:32:39 --> Router Class Initialized
INFO - 2023-05-08 19:32:39 --> Output Class Initialized
INFO - 2023-05-08 19:32:39 --> Security Class Initialized
INFO - 2023-05-08 19:32:39 --> Input Class Initialized
INFO - 2023-05-08 19:32:39 --> Language Class Initialized
INFO - 2023-05-08 19:32:39 --> Loader Class Initialized
INFO - 2023-05-08 19:32:39 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:39 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:39 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:39 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:39 --> Controller Class Initialized
INFO - 2023-05-08 19:32:39 --> Model "m_user" initialized
INFO - 2023-05-08 19:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-08 19:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:32:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-08 19:32:39 --> Final output sent to browser
INFO - 2023-05-08 19:32:42 --> Config Class Initialized
INFO - 2023-05-08 19:32:42 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:42 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:42 --> URI Class Initialized
INFO - 2023-05-08 19:32:42 --> Router Class Initialized
INFO - 2023-05-08 19:32:42 --> Output Class Initialized
INFO - 2023-05-08 19:32:42 --> Security Class Initialized
INFO - 2023-05-08 19:32:42 --> Input Class Initialized
INFO - 2023-05-08 19:32:42 --> Language Class Initialized
INFO - 2023-05-08 19:32:42 --> Loader Class Initialized
INFO - 2023-05-08 19:32:42 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:42 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:42 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:42 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:42 --> Controller Class Initialized
INFO - 2023-05-08 19:32:42 --> Model "m_user" initialized
INFO - 2023-05-08 19:32:42 --> Config Class Initialized
INFO - 2023-05-08 19:32:42 --> Hooks Class Initialized
INFO - 2023-05-08 19:32:42 --> Utf8 Class Initialized
INFO - 2023-05-08 19:32:42 --> URI Class Initialized
INFO - 2023-05-08 19:32:42 --> Router Class Initialized
INFO - 2023-05-08 19:32:42 --> Output Class Initialized
INFO - 2023-05-08 19:32:42 --> Security Class Initialized
INFO - 2023-05-08 19:32:42 --> Input Class Initialized
INFO - 2023-05-08 19:32:42 --> Language Class Initialized
INFO - 2023-05-08 19:32:42 --> Loader Class Initialized
INFO - 2023-05-08 19:32:42 --> Helper loaded: url_helper
INFO - 2023-05-08 19:32:42 --> Helper loaded: form_helper
INFO - 2023-05-08 19:32:42 --> Database Driver Class Initialized
INFO - 2023-05-08 19:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:32:42 --> Form Validation Class Initialized
INFO - 2023-05-08 19:32:42 --> Controller Class Initialized
INFO - 2023-05-08 19:32:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 19:32:42 --> Final output sent to browser
INFO - 2023-05-08 19:34:35 --> Config Class Initialized
INFO - 2023-05-08 19:34:35 --> Hooks Class Initialized
INFO - 2023-05-08 19:34:35 --> Utf8 Class Initialized
INFO - 2023-05-08 19:34:35 --> URI Class Initialized
INFO - 2023-05-08 19:34:35 --> Router Class Initialized
INFO - 2023-05-08 19:34:35 --> Output Class Initialized
INFO - 2023-05-08 19:34:35 --> Security Class Initialized
INFO - 2023-05-08 19:34:35 --> Input Class Initialized
INFO - 2023-05-08 19:34:35 --> Language Class Initialized
INFO - 2023-05-08 19:34:35 --> Loader Class Initialized
INFO - 2023-05-08 19:34:35 --> Helper loaded: url_helper
INFO - 2023-05-08 19:34:35 --> Helper loaded: form_helper
INFO - 2023-05-08 19:34:35 --> Database Driver Class Initialized
INFO - 2023-05-08 19:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:34:35 --> Form Validation Class Initialized
INFO - 2023-05-08 19:34:35 --> Controller Class Initialized
INFO - 2023-05-08 19:34:35 --> Model "m_user" initialized
INFO - 2023-05-08 19:34:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:34:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:34:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-08 19:34:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:34:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:34:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-08 19:34:35 --> Final output sent to browser
INFO - 2023-05-08 19:35:35 --> Config Class Initialized
INFO - 2023-05-08 19:35:35 --> Hooks Class Initialized
INFO - 2023-05-08 19:35:35 --> Utf8 Class Initialized
INFO - 2023-05-08 19:35:35 --> URI Class Initialized
INFO - 2023-05-08 19:35:35 --> Router Class Initialized
INFO - 2023-05-08 19:35:35 --> Output Class Initialized
INFO - 2023-05-08 19:35:35 --> Security Class Initialized
INFO - 2023-05-08 19:35:35 --> Input Class Initialized
INFO - 2023-05-08 19:35:35 --> Language Class Initialized
INFO - 2023-05-08 19:35:35 --> Loader Class Initialized
INFO - 2023-05-08 19:35:35 --> Helper loaded: url_helper
INFO - 2023-05-08 19:35:35 --> Helper loaded: form_helper
INFO - 2023-05-08 19:35:35 --> Database Driver Class Initialized
INFO - 2023-05-08 19:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:35:35 --> Form Validation Class Initialized
INFO - 2023-05-08 19:35:35 --> Controller Class Initialized
INFO - 2023-05-08 19:35:35 --> Model "m_user" initialized
INFO - 2023-05-08 19:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-08 19:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:35:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-08 19:35:35 --> Final output sent to browser
INFO - 2023-05-08 19:35:37 --> Config Class Initialized
INFO - 2023-05-08 19:35:37 --> Hooks Class Initialized
INFO - 2023-05-08 19:35:37 --> Utf8 Class Initialized
INFO - 2023-05-08 19:35:37 --> URI Class Initialized
INFO - 2023-05-08 19:35:37 --> Router Class Initialized
INFO - 2023-05-08 19:35:37 --> Output Class Initialized
INFO - 2023-05-08 19:35:37 --> Security Class Initialized
INFO - 2023-05-08 19:35:37 --> Input Class Initialized
INFO - 2023-05-08 19:35:37 --> Language Class Initialized
INFO - 2023-05-08 19:35:37 --> Loader Class Initialized
INFO - 2023-05-08 19:35:37 --> Helper loaded: url_helper
INFO - 2023-05-08 19:35:37 --> Helper loaded: form_helper
INFO - 2023-05-08 19:35:37 --> Database Driver Class Initialized
INFO - 2023-05-08 19:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:35:37 --> Form Validation Class Initialized
INFO - 2023-05-08 19:35:37 --> Controller Class Initialized
INFO - 2023-05-08 19:35:37 --> Model "m_user" initialized
INFO - 2023-05-08 19:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-08 19:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:35:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-08 19:35:37 --> Final output sent to browser
INFO - 2023-05-08 19:35:38 --> Config Class Initialized
INFO - 2023-05-08 19:35:38 --> Hooks Class Initialized
INFO - 2023-05-08 19:35:38 --> Utf8 Class Initialized
INFO - 2023-05-08 19:35:38 --> URI Class Initialized
INFO - 2023-05-08 19:35:38 --> Router Class Initialized
INFO - 2023-05-08 19:35:38 --> Output Class Initialized
INFO - 2023-05-08 19:35:38 --> Security Class Initialized
INFO - 2023-05-08 19:35:38 --> Input Class Initialized
INFO - 2023-05-08 19:35:38 --> Language Class Initialized
INFO - 2023-05-08 19:35:38 --> Loader Class Initialized
INFO - 2023-05-08 19:35:38 --> Helper loaded: url_helper
INFO - 2023-05-08 19:35:38 --> Helper loaded: form_helper
INFO - 2023-05-08 19:35:38 --> Database Driver Class Initialized
INFO - 2023-05-08 19:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:35:38 --> Form Validation Class Initialized
INFO - 2023-05-08 19:35:38 --> Controller Class Initialized
INFO - 2023-05-08 19:35:38 --> Model "m_user" initialized
INFO - 2023-05-08 19:35:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:35:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:35:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-08 19:35:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:35:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:35:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-08 19:35:38 --> Final output sent to browser
INFO - 2023-05-08 19:35:40 --> Config Class Initialized
INFO - 2023-05-08 19:35:40 --> Hooks Class Initialized
INFO - 2023-05-08 19:35:40 --> Utf8 Class Initialized
INFO - 2023-05-08 19:35:40 --> URI Class Initialized
INFO - 2023-05-08 19:35:40 --> Router Class Initialized
INFO - 2023-05-08 19:35:40 --> Output Class Initialized
INFO - 2023-05-08 19:35:40 --> Security Class Initialized
INFO - 2023-05-08 19:35:40 --> Input Class Initialized
INFO - 2023-05-08 19:35:40 --> Language Class Initialized
INFO - 2023-05-08 19:35:40 --> Loader Class Initialized
INFO - 2023-05-08 19:35:40 --> Helper loaded: url_helper
INFO - 2023-05-08 19:35:40 --> Helper loaded: form_helper
INFO - 2023-05-08 19:35:40 --> Database Driver Class Initialized
INFO - 2023-05-08 19:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:35:40 --> Form Validation Class Initialized
INFO - 2023-05-08 19:35:40 --> Controller Class Initialized
INFO - 2023-05-08 19:35:40 --> Model "m_user" initialized
INFO - 2023-05-08 19:35:40 --> Config Class Initialized
INFO - 2023-05-08 19:35:40 --> Hooks Class Initialized
INFO - 2023-05-08 19:35:40 --> Utf8 Class Initialized
INFO - 2023-05-08 19:35:40 --> URI Class Initialized
INFO - 2023-05-08 19:35:40 --> Router Class Initialized
INFO - 2023-05-08 19:35:40 --> Output Class Initialized
INFO - 2023-05-08 19:35:40 --> Security Class Initialized
INFO - 2023-05-08 19:35:40 --> Input Class Initialized
INFO - 2023-05-08 19:35:40 --> Language Class Initialized
INFO - 2023-05-08 19:35:40 --> Loader Class Initialized
INFO - 2023-05-08 19:35:40 --> Helper loaded: url_helper
INFO - 2023-05-08 19:35:40 --> Helper loaded: form_helper
INFO - 2023-05-08 19:35:40 --> Database Driver Class Initialized
INFO - 2023-05-08 19:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:35:40 --> Form Validation Class Initialized
INFO - 2023-05-08 19:35:40 --> Controller Class Initialized
INFO - 2023-05-08 19:35:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-08 19:35:40 --> Final output sent to browser
INFO - 2023-05-08 19:38:49 --> Config Class Initialized
INFO - 2023-05-08 19:38:49 --> Hooks Class Initialized
INFO - 2023-05-08 19:38:49 --> Utf8 Class Initialized
INFO - 2023-05-08 19:38:49 --> URI Class Initialized
INFO - 2023-05-08 19:38:49 --> Router Class Initialized
INFO - 2023-05-08 19:38:49 --> Output Class Initialized
INFO - 2023-05-08 19:38:49 --> Security Class Initialized
INFO - 2023-05-08 19:38:49 --> Input Class Initialized
INFO - 2023-05-08 19:38:49 --> Language Class Initialized
INFO - 2023-05-08 19:38:49 --> Loader Class Initialized
INFO - 2023-05-08 19:38:49 --> Helper loaded: url_helper
INFO - 2023-05-08 19:38:49 --> Helper loaded: form_helper
INFO - 2023-05-08 19:38:49 --> Database Driver Class Initialized
INFO - 2023-05-08 19:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 19:38:49 --> Form Validation Class Initialized
INFO - 2023-05-08 19:38:49 --> Controller Class Initialized
INFO - 2023-05-08 19:38:49 --> Model "m_user" initialized
INFO - 2023-05-08 19:38:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-08 19:38:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-08 19:38:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-08 19:38:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-08 19:38:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-08 19:38:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-08 19:38:49 --> Final output sent to browser
