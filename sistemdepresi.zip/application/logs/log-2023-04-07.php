<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-07 08:50:30 --> Config Class Initialized
INFO - 2023-04-07 08:50:30 --> Hooks Class Initialized
INFO - 2023-04-07 08:50:30 --> Utf8 Class Initialized
INFO - 2023-04-07 08:50:30 --> URI Class Initialized
INFO - 2023-04-07 08:50:30 --> Router Class Initialized
INFO - 2023-04-07 08:50:30 --> Output Class Initialized
INFO - 2023-04-07 08:50:30 --> Security Class Initialized
INFO - 2023-04-07 08:50:30 --> Input Class Initialized
INFO - 2023-04-07 08:50:30 --> Language Class Initialized
INFO - 2023-04-07 08:50:30 --> Loader Class Initialized
INFO - 2023-04-07 08:50:30 --> Helper loaded: url_helper
INFO - 2023-04-07 08:50:30 --> Helper loaded: form_helper
INFO - 2023-04-07 08:50:30 --> Database Driver Class Initialized
INFO - 2023-04-07 08:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-07 08:50:30 --> Form Validation Class Initialized
INFO - 2023-04-07 08:50:30 --> Controller Class Initialized
INFO - 2023-04-07 08:50:30 --> Model "M_tutor" initialized
INFO - 2023-04-07 08:50:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-04-07 08:50:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-04-07 08:50:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-04-07 08:50:30 --> Final output sent to browser
