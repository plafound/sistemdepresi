<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-17 13:48:25 --> Config Class Initialized
INFO - 2023-05-17 13:48:25 --> Hooks Class Initialized
INFO - 2023-05-17 13:48:25 --> Utf8 Class Initialized
INFO - 2023-05-17 13:48:25 --> URI Class Initialized
INFO - 2023-05-17 13:48:25 --> Router Class Initialized
INFO - 2023-05-17 13:48:25 --> Output Class Initialized
INFO - 2023-05-17 13:48:25 --> Security Class Initialized
INFO - 2023-05-17 13:48:25 --> Input Class Initialized
INFO - 2023-05-17 13:48:25 --> Language Class Initialized
INFO - 2023-05-17 13:48:25 --> Loader Class Initialized
INFO - 2023-05-17 13:48:25 --> Helper loaded: url_helper
INFO - 2023-05-17 13:48:25 --> Helper loaded: form_helper
INFO - 2023-05-17 13:48:25 --> Database Driver Class Initialized
INFO - 2023-05-17 13:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 13:48:25 --> Form Validation Class Initialized
INFO - 2023-05-17 13:48:25 --> Controller Class Initialized
INFO - 2023-05-17 13:48:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-17 13:48:25 --> Final output sent to browser
INFO - 2023-05-17 13:48:54 --> Config Class Initialized
INFO - 2023-05-17 13:48:54 --> Hooks Class Initialized
INFO - 2023-05-17 13:48:54 --> Utf8 Class Initialized
INFO - 2023-05-17 13:48:54 --> URI Class Initialized
INFO - 2023-05-17 13:48:54 --> Router Class Initialized
INFO - 2023-05-17 13:48:54 --> Output Class Initialized
INFO - 2023-05-17 13:48:54 --> Security Class Initialized
INFO - 2023-05-17 13:48:54 --> Input Class Initialized
INFO - 2023-05-17 13:48:54 --> Language Class Initialized
INFO - 2023-05-17 13:48:54 --> Loader Class Initialized
INFO - 2023-05-17 13:48:54 --> Helper loaded: url_helper
INFO - 2023-05-17 13:48:54 --> Helper loaded: form_helper
INFO - 2023-05-17 13:48:54 --> Database Driver Class Initialized
INFO - 2023-05-17 13:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 13:48:55 --> Form Validation Class Initialized
INFO - 2023-05-17 13:48:55 --> Controller Class Initialized
INFO - 2023-05-17 13:48:55 --> Model "m_user" initialized
INFO - 2023-05-17 13:48:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-17 13:48:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-17 13:48:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-17 13:48:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-17 13:48:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-17 13:48:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-17 13:48:55 --> Final output sent to browser
INFO - 2023-05-17 13:49:04 --> Config Class Initialized
INFO - 2023-05-17 13:49:04 --> Hooks Class Initialized
INFO - 2023-05-17 13:49:04 --> Utf8 Class Initialized
INFO - 2023-05-17 13:49:04 --> URI Class Initialized
INFO - 2023-05-17 13:49:04 --> Router Class Initialized
INFO - 2023-05-17 13:49:04 --> Output Class Initialized
INFO - 2023-05-17 13:49:04 --> Security Class Initialized
INFO - 2023-05-17 13:49:04 --> Input Class Initialized
INFO - 2023-05-17 13:49:04 --> Language Class Initialized
INFO - 2023-05-17 13:49:04 --> Loader Class Initialized
INFO - 2023-05-17 13:49:04 --> Helper loaded: url_helper
INFO - 2023-05-17 13:49:04 --> Helper loaded: form_helper
INFO - 2023-05-17 13:49:04 --> Database Driver Class Initialized
INFO - 2023-05-17 13:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 13:49:04 --> Form Validation Class Initialized
INFO - 2023-05-17 13:49:04 --> Controller Class Initialized
INFO - 2023-05-17 13:49:04 --> Model "m_user" initialized
INFO - 2023-05-17 13:49:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-17 13:49:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-17 13:49:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-17 13:49:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-17 13:49:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-17 13:49:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-17 13:49:04 --> Final output sent to browser
INFO - 2023-05-17 13:49:16 --> Config Class Initialized
INFO - 2023-05-17 13:49:16 --> Hooks Class Initialized
INFO - 2023-05-17 13:49:16 --> Utf8 Class Initialized
INFO - 2023-05-17 13:49:16 --> URI Class Initialized
INFO - 2023-05-17 13:49:16 --> Router Class Initialized
INFO - 2023-05-17 13:49:16 --> Output Class Initialized
INFO - 2023-05-17 13:49:16 --> Security Class Initialized
INFO - 2023-05-17 13:49:16 --> Input Class Initialized
INFO - 2023-05-17 13:49:16 --> Language Class Initialized
INFO - 2023-05-17 13:49:16 --> Loader Class Initialized
INFO - 2023-05-17 13:49:16 --> Helper loaded: url_helper
INFO - 2023-05-17 13:49:16 --> Helper loaded: form_helper
INFO - 2023-05-17 13:49:16 --> Database Driver Class Initialized
INFO - 2023-05-17 13:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 13:49:16 --> Form Validation Class Initialized
INFO - 2023-05-17 13:49:16 --> Controller Class Initialized
INFO - 2023-05-17 13:49:16 --> Model "m_user" initialized
INFO - 2023-05-17 13:49:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-17 13:49:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-17 13:49:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-17 13:49:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-17 13:49:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-17 13:49:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-17 13:49:16 --> Final output sent to browser
INFO - 2023-05-17 13:53:28 --> Config Class Initialized
INFO - 2023-05-17 13:53:28 --> Hooks Class Initialized
INFO - 2023-05-17 13:53:28 --> Utf8 Class Initialized
INFO - 2023-05-17 13:53:28 --> URI Class Initialized
INFO - 2023-05-17 13:53:28 --> Router Class Initialized
INFO - 2023-05-17 13:53:28 --> Output Class Initialized
INFO - 2023-05-17 13:53:28 --> Security Class Initialized
INFO - 2023-05-17 13:53:28 --> Input Class Initialized
INFO - 2023-05-17 13:53:28 --> Language Class Initialized
ERROR - 2023-05-17 13:53:28 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 347
INFO - 2023-05-17 13:53:47 --> Config Class Initialized
INFO - 2023-05-17 13:53:47 --> Hooks Class Initialized
INFO - 2023-05-17 13:53:47 --> Utf8 Class Initialized
INFO - 2023-05-17 13:53:47 --> URI Class Initialized
INFO - 2023-05-17 13:53:47 --> Router Class Initialized
INFO - 2023-05-17 13:53:47 --> Output Class Initialized
INFO - 2023-05-17 13:53:47 --> Security Class Initialized
INFO - 2023-05-17 13:53:47 --> Input Class Initialized
INFO - 2023-05-17 13:53:47 --> Language Class Initialized
ERROR - 2023-05-17 13:53:47 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 347
INFO - 2023-05-17 13:55:35 --> Config Class Initialized
INFO - 2023-05-17 13:55:35 --> Hooks Class Initialized
INFO - 2023-05-17 13:55:35 --> Utf8 Class Initialized
INFO - 2023-05-17 13:55:35 --> URI Class Initialized
INFO - 2023-05-17 13:55:35 --> Router Class Initialized
INFO - 2023-05-17 13:55:35 --> Output Class Initialized
INFO - 2023-05-17 13:55:35 --> Security Class Initialized
INFO - 2023-05-17 13:55:35 --> Input Class Initialized
INFO - 2023-05-17 13:55:35 --> Language Class Initialized
INFO - 2023-05-17 13:55:35 --> Loader Class Initialized
INFO - 2023-05-17 13:55:35 --> Helper loaded: url_helper
INFO - 2023-05-17 13:55:35 --> Helper loaded: form_helper
INFO - 2023-05-17 13:55:35 --> Database Driver Class Initialized
INFO - 2023-05-17 13:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 13:55:35 --> Form Validation Class Initialized
INFO - 2023-05-17 13:55:35 --> Controller Class Initialized
INFO - 2023-05-17 13:55:35 --> Model "m_datatrain" initialized
INFO - 2023-05-17 13:55:35 --> Model "m_datatest" initialized
INFO - 2023-05-17 13:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-17 13:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-17 13:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-17 13:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-17 13:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-17 13:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-17 13:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-17 13:55:35 --> Final output sent to browser
INFO - 2023-05-17 13:55:41 --> Config Class Initialized
INFO - 2023-05-17 13:55:41 --> Hooks Class Initialized
INFO - 2023-05-17 13:55:41 --> Utf8 Class Initialized
INFO - 2023-05-17 13:55:41 --> URI Class Initialized
INFO - 2023-05-17 13:55:41 --> Router Class Initialized
INFO - 2023-05-17 13:55:41 --> Output Class Initialized
INFO - 2023-05-17 13:55:41 --> Security Class Initialized
INFO - 2023-05-17 13:55:41 --> Input Class Initialized
INFO - 2023-05-17 13:55:41 --> Language Class Initialized
INFO - 2023-05-17 13:55:41 --> Loader Class Initialized
INFO - 2023-05-17 13:55:41 --> Helper loaded: url_helper
INFO - 2023-05-17 13:55:41 --> Helper loaded: form_helper
INFO - 2023-05-17 13:55:41 --> Database Driver Class Initialized
INFO - 2023-05-17 13:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 13:55:41 --> Form Validation Class Initialized
INFO - 2023-05-17 13:55:41 --> Controller Class Initialized
INFO - 2023-05-17 13:55:41 --> Model "m_datatrain" initialized
INFO - 2023-05-17 13:55:41 --> Model "m_datatest" initialized
INFO - 2023-05-17 13:55:41 --> Final output sent to browser
INFO - 2023-05-17 13:56:50 --> Config Class Initialized
INFO - 2023-05-17 13:56:50 --> Hooks Class Initialized
INFO - 2023-05-17 13:56:50 --> Utf8 Class Initialized
INFO - 2023-05-17 13:56:50 --> URI Class Initialized
INFO - 2023-05-17 13:56:50 --> Router Class Initialized
INFO - 2023-05-17 13:56:50 --> Output Class Initialized
INFO - 2023-05-17 13:56:50 --> Security Class Initialized
INFO - 2023-05-17 13:56:50 --> Input Class Initialized
INFO - 2023-05-17 13:56:50 --> Language Class Initialized
ERROR - 2023-05-17 13:56:50 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 347
INFO - 2023-05-17 13:57:21 --> Config Class Initialized
INFO - 2023-05-17 13:57:21 --> Hooks Class Initialized
INFO - 2023-05-17 13:57:21 --> Utf8 Class Initialized
INFO - 2023-05-17 13:57:21 --> URI Class Initialized
INFO - 2023-05-17 13:57:21 --> Router Class Initialized
INFO - 2023-05-17 13:57:21 --> Output Class Initialized
INFO - 2023-05-17 13:57:21 --> Security Class Initialized
INFO - 2023-05-17 13:57:21 --> Input Class Initialized
INFO - 2023-05-17 13:57:21 --> Language Class Initialized
INFO - 2023-05-17 13:57:21 --> Loader Class Initialized
INFO - 2023-05-17 13:57:21 --> Helper loaded: url_helper
INFO - 2023-05-17 13:57:21 --> Helper loaded: form_helper
INFO - 2023-05-17 13:57:21 --> Database Driver Class Initialized
INFO - 2023-05-17 13:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 13:57:21 --> Form Validation Class Initialized
INFO - 2023-05-17 13:57:21 --> Controller Class Initialized
INFO - 2023-05-17 13:57:21 --> Model "m_datatrain" initialized
INFO - 2023-05-17 13:57:21 --> Model "m_datatest" initialized
INFO - 2023-05-17 13:57:21 --> Final output sent to browser
INFO - 2023-05-17 13:58:16 --> Config Class Initialized
INFO - 2023-05-17 13:58:16 --> Hooks Class Initialized
INFO - 2023-05-17 13:58:16 --> Utf8 Class Initialized
INFO - 2023-05-17 13:58:16 --> URI Class Initialized
INFO - 2023-05-17 13:58:16 --> Router Class Initialized
INFO - 2023-05-17 13:58:16 --> Output Class Initialized
INFO - 2023-05-17 13:58:16 --> Security Class Initialized
INFO - 2023-05-17 13:58:16 --> Input Class Initialized
INFO - 2023-05-17 13:58:16 --> Language Class Initialized
INFO - 2023-05-17 13:58:16 --> Loader Class Initialized
INFO - 2023-05-17 13:58:16 --> Helper loaded: url_helper
INFO - 2023-05-17 13:58:16 --> Helper loaded: form_helper
INFO - 2023-05-17 13:58:16 --> Database Driver Class Initialized
INFO - 2023-05-17 13:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 13:58:16 --> Form Validation Class Initialized
INFO - 2023-05-17 13:58:16 --> Controller Class Initialized
INFO - 2023-05-17 13:58:16 --> Model "m_datatrain" initialized
INFO - 2023-05-17 13:58:16 --> Model "m_datatest" initialized
INFO - 2023-05-17 13:58:16 --> Final output sent to browser
INFO - 2023-05-17 14:01:35 --> Config Class Initialized
INFO - 2023-05-17 14:01:35 --> Hooks Class Initialized
INFO - 2023-05-17 14:01:35 --> Utf8 Class Initialized
INFO - 2023-05-17 14:01:35 --> URI Class Initialized
INFO - 2023-05-17 14:01:35 --> Router Class Initialized
INFO - 2023-05-17 14:01:35 --> Output Class Initialized
INFO - 2023-05-17 14:01:35 --> Security Class Initialized
INFO - 2023-05-17 14:01:35 --> Input Class Initialized
INFO - 2023-05-17 14:01:35 --> Language Class Initialized
INFO - 2023-05-17 14:01:35 --> Loader Class Initialized
INFO - 2023-05-17 14:01:35 --> Helper loaded: url_helper
INFO - 2023-05-17 14:01:35 --> Helper loaded: form_helper
INFO - 2023-05-17 14:01:35 --> Database Driver Class Initialized
INFO - 2023-05-17 14:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 14:01:35 --> Form Validation Class Initialized
INFO - 2023-05-17 14:01:35 --> Controller Class Initialized
INFO - 2023-05-17 14:01:35 --> Model "m_datatrain" initialized
INFO - 2023-05-17 14:01:35 --> Model "m_datatest" initialized
INFO - 2023-05-17 14:01:35 --> Final output sent to browser
INFO - 2023-05-17 14:03:54 --> Config Class Initialized
INFO - 2023-05-17 14:03:54 --> Hooks Class Initialized
INFO - 2023-05-17 14:03:54 --> Utf8 Class Initialized
INFO - 2023-05-17 14:03:54 --> URI Class Initialized
INFO - 2023-05-17 14:03:54 --> Router Class Initialized
INFO - 2023-05-17 14:03:54 --> Output Class Initialized
INFO - 2023-05-17 14:03:54 --> Security Class Initialized
INFO - 2023-05-17 14:03:54 --> Input Class Initialized
INFO - 2023-05-17 14:03:54 --> Language Class Initialized
INFO - 2023-05-17 14:03:54 --> Loader Class Initialized
INFO - 2023-05-17 14:03:54 --> Helper loaded: url_helper
INFO - 2023-05-17 14:03:54 --> Helper loaded: form_helper
INFO - 2023-05-17 14:03:54 --> Database Driver Class Initialized
INFO - 2023-05-17 14:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 14:03:54 --> Form Validation Class Initialized
INFO - 2023-05-17 14:03:54 --> Controller Class Initialized
INFO - 2023-05-17 14:03:54 --> Model "m_datatrain" initialized
INFO - 2023-05-17 14:03:54 --> Model "m_datatest" initialized
INFO - 2023-05-17 14:03:54 --> Final output sent to browser
INFO - 2023-05-17 15:01:38 --> Config Class Initialized
INFO - 2023-05-17 15:01:38 --> Hooks Class Initialized
INFO - 2023-05-17 15:01:38 --> Utf8 Class Initialized
INFO - 2023-05-17 15:01:38 --> URI Class Initialized
INFO - 2023-05-17 15:01:38 --> Router Class Initialized
INFO - 2023-05-17 15:01:38 --> Output Class Initialized
INFO - 2023-05-17 15:01:38 --> Security Class Initialized
INFO - 2023-05-17 15:01:38 --> Input Class Initialized
INFO - 2023-05-17 15:01:38 --> Language Class Initialized
INFO - 2023-05-17 15:01:38 --> Loader Class Initialized
INFO - 2023-05-17 15:01:38 --> Helper loaded: url_helper
INFO - 2023-05-17 15:01:38 --> Helper loaded: form_helper
INFO - 2023-05-17 15:01:38 --> Database Driver Class Initialized
INFO - 2023-05-17 15:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:01:38 --> Form Validation Class Initialized
INFO - 2023-05-17 15:01:38 --> Controller Class Initialized
INFO - 2023-05-17 15:01:38 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:01:38 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:01:38 --> Final output sent to browser
INFO - 2023-05-17 15:01:53 --> Config Class Initialized
INFO - 2023-05-17 15:01:53 --> Hooks Class Initialized
INFO - 2023-05-17 15:01:53 --> Utf8 Class Initialized
INFO - 2023-05-17 15:01:53 --> URI Class Initialized
INFO - 2023-05-17 15:01:53 --> Router Class Initialized
INFO - 2023-05-17 15:01:53 --> Output Class Initialized
INFO - 2023-05-17 15:01:53 --> Security Class Initialized
INFO - 2023-05-17 15:01:53 --> Input Class Initialized
INFO - 2023-05-17 15:01:53 --> Language Class Initialized
ERROR - 2023-05-17 15:01:53 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 347
INFO - 2023-05-17 15:02:26 --> Config Class Initialized
INFO - 2023-05-17 15:02:26 --> Hooks Class Initialized
INFO - 2023-05-17 15:02:26 --> Utf8 Class Initialized
INFO - 2023-05-17 15:02:26 --> URI Class Initialized
INFO - 2023-05-17 15:02:26 --> Router Class Initialized
INFO - 2023-05-17 15:02:26 --> Output Class Initialized
INFO - 2023-05-17 15:02:26 --> Security Class Initialized
INFO - 2023-05-17 15:02:26 --> Input Class Initialized
INFO - 2023-05-17 15:02:26 --> Language Class Initialized
INFO - 2023-05-17 15:02:26 --> Loader Class Initialized
INFO - 2023-05-17 15:02:26 --> Helper loaded: url_helper
INFO - 2023-05-17 15:02:26 --> Helper loaded: form_helper
INFO - 2023-05-17 15:02:26 --> Database Driver Class Initialized
INFO - 2023-05-17 15:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:02:26 --> Form Validation Class Initialized
INFO - 2023-05-17 15:02:26 --> Controller Class Initialized
INFO - 2023-05-17 15:02:26 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:02:26 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:02:26 --> Final output sent to browser
INFO - 2023-05-17 15:03:35 --> Config Class Initialized
INFO - 2023-05-17 15:03:35 --> Hooks Class Initialized
INFO - 2023-05-17 15:03:35 --> Utf8 Class Initialized
INFO - 2023-05-17 15:03:35 --> URI Class Initialized
INFO - 2023-05-17 15:03:35 --> Router Class Initialized
INFO - 2023-05-17 15:03:35 --> Output Class Initialized
INFO - 2023-05-17 15:03:35 --> Security Class Initialized
INFO - 2023-05-17 15:03:35 --> Input Class Initialized
INFO - 2023-05-17 15:03:35 --> Language Class Initialized
INFO - 2023-05-17 15:03:35 --> Loader Class Initialized
INFO - 2023-05-17 15:03:35 --> Helper loaded: url_helper
INFO - 2023-05-17 15:03:35 --> Helper loaded: form_helper
INFO - 2023-05-17 15:03:35 --> Database Driver Class Initialized
INFO - 2023-05-17 15:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:03:35 --> Form Validation Class Initialized
INFO - 2023-05-17 15:03:35 --> Controller Class Initialized
INFO - 2023-05-17 15:03:35 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:03:35 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:03:35 --> Final output sent to browser
INFO - 2023-05-17 15:03:45 --> Config Class Initialized
INFO - 2023-05-17 15:03:45 --> Hooks Class Initialized
INFO - 2023-05-17 15:03:45 --> Utf8 Class Initialized
INFO - 2023-05-17 15:03:45 --> URI Class Initialized
INFO - 2023-05-17 15:03:45 --> Router Class Initialized
INFO - 2023-05-17 15:03:45 --> Output Class Initialized
INFO - 2023-05-17 15:03:45 --> Security Class Initialized
INFO - 2023-05-17 15:03:45 --> Input Class Initialized
INFO - 2023-05-17 15:03:45 --> Language Class Initialized
INFO - 2023-05-17 15:03:45 --> Loader Class Initialized
INFO - 2023-05-17 15:03:45 --> Helper loaded: url_helper
INFO - 2023-05-17 15:03:45 --> Helper loaded: form_helper
INFO - 2023-05-17 15:03:45 --> Database Driver Class Initialized
INFO - 2023-05-17 15:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:03:45 --> Form Validation Class Initialized
INFO - 2023-05-17 15:03:45 --> Controller Class Initialized
INFO - 2023-05-17 15:03:45 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:03:45 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:03:45 --> Final output sent to browser
INFO - 2023-05-17 15:05:11 --> Config Class Initialized
INFO - 2023-05-17 15:05:11 --> Hooks Class Initialized
INFO - 2023-05-17 15:05:11 --> Utf8 Class Initialized
INFO - 2023-05-17 15:05:11 --> URI Class Initialized
INFO - 2023-05-17 15:05:11 --> Router Class Initialized
INFO - 2023-05-17 15:05:11 --> Output Class Initialized
INFO - 2023-05-17 15:05:11 --> Security Class Initialized
INFO - 2023-05-17 15:05:11 --> Input Class Initialized
INFO - 2023-05-17 15:05:11 --> Language Class Initialized
INFO - 2023-05-17 15:05:11 --> Loader Class Initialized
INFO - 2023-05-17 15:05:11 --> Helper loaded: url_helper
INFO - 2023-05-17 15:05:11 --> Helper loaded: form_helper
INFO - 2023-05-17 15:05:11 --> Database Driver Class Initialized
INFO - 2023-05-17 15:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:05:11 --> Form Validation Class Initialized
INFO - 2023-05-17 15:05:11 --> Controller Class Initialized
INFO - 2023-05-17 15:05:11 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:05:11 --> Model "m_datatest" initialized
ERROR - 2023-05-17 15:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 359
INFO - 2023-05-17 15:05:11 --> Final output sent to browser
INFO - 2023-05-17 15:05:24 --> Config Class Initialized
INFO - 2023-05-17 15:05:24 --> Hooks Class Initialized
INFO - 2023-05-17 15:05:24 --> Utf8 Class Initialized
INFO - 2023-05-17 15:05:24 --> URI Class Initialized
INFO - 2023-05-17 15:05:24 --> Router Class Initialized
INFO - 2023-05-17 15:05:24 --> Output Class Initialized
INFO - 2023-05-17 15:05:24 --> Security Class Initialized
INFO - 2023-05-17 15:05:24 --> Input Class Initialized
INFO - 2023-05-17 15:05:24 --> Language Class Initialized
INFO - 2023-05-17 15:05:24 --> Loader Class Initialized
INFO - 2023-05-17 15:05:24 --> Helper loaded: url_helper
INFO - 2023-05-17 15:05:24 --> Helper loaded: form_helper
INFO - 2023-05-17 15:05:24 --> Database Driver Class Initialized
INFO - 2023-05-17 15:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:05:24 --> Form Validation Class Initialized
INFO - 2023-05-17 15:05:24 --> Controller Class Initialized
INFO - 2023-05-17 15:05:24 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:05:24 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:05:24 --> Final output sent to browser
INFO - 2023-05-17 15:05:41 --> Config Class Initialized
INFO - 2023-05-17 15:05:41 --> Hooks Class Initialized
INFO - 2023-05-17 15:05:41 --> Utf8 Class Initialized
INFO - 2023-05-17 15:05:41 --> URI Class Initialized
INFO - 2023-05-17 15:05:41 --> Router Class Initialized
INFO - 2023-05-17 15:05:41 --> Output Class Initialized
INFO - 2023-05-17 15:05:41 --> Security Class Initialized
INFO - 2023-05-17 15:05:41 --> Input Class Initialized
INFO - 2023-05-17 15:05:41 --> Language Class Initialized
INFO - 2023-05-17 15:05:41 --> Loader Class Initialized
INFO - 2023-05-17 15:05:41 --> Helper loaded: url_helper
INFO - 2023-05-17 15:05:41 --> Helper loaded: form_helper
INFO - 2023-05-17 15:05:41 --> Database Driver Class Initialized
INFO - 2023-05-17 15:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:05:41 --> Form Validation Class Initialized
INFO - 2023-05-17 15:05:41 --> Controller Class Initialized
INFO - 2023-05-17 15:05:41 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:05:41 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:05:41 --> Final output sent to browser
INFO - 2023-05-17 15:06:02 --> Config Class Initialized
INFO - 2023-05-17 15:06:02 --> Hooks Class Initialized
INFO - 2023-05-17 15:06:02 --> Utf8 Class Initialized
INFO - 2023-05-17 15:06:02 --> URI Class Initialized
INFO - 2023-05-17 15:06:02 --> Router Class Initialized
INFO - 2023-05-17 15:06:02 --> Output Class Initialized
INFO - 2023-05-17 15:06:02 --> Security Class Initialized
INFO - 2023-05-17 15:06:02 --> Input Class Initialized
INFO - 2023-05-17 15:06:02 --> Language Class Initialized
INFO - 2023-05-17 15:06:02 --> Loader Class Initialized
INFO - 2023-05-17 15:06:02 --> Helper loaded: url_helper
INFO - 2023-05-17 15:06:02 --> Helper loaded: form_helper
INFO - 2023-05-17 15:06:02 --> Database Driver Class Initialized
INFO - 2023-05-17 15:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:06:02 --> Form Validation Class Initialized
INFO - 2023-05-17 15:06:02 --> Controller Class Initialized
INFO - 2023-05-17 15:06:02 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:06:02 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:06:02 --> Final output sent to browser
INFO - 2023-05-17 15:36:51 --> Config Class Initialized
INFO - 2023-05-17 15:36:51 --> Hooks Class Initialized
INFO - 2023-05-17 15:36:51 --> Utf8 Class Initialized
INFO - 2023-05-17 15:36:51 --> URI Class Initialized
INFO - 2023-05-17 15:36:51 --> Router Class Initialized
INFO - 2023-05-17 15:36:51 --> Output Class Initialized
INFO - 2023-05-17 15:36:51 --> Security Class Initialized
INFO - 2023-05-17 15:36:51 --> Input Class Initialized
INFO - 2023-05-17 15:36:51 --> Language Class Initialized
INFO - 2023-05-17 15:36:51 --> Loader Class Initialized
INFO - 2023-05-17 15:36:51 --> Helper loaded: url_helper
INFO - 2023-05-17 15:36:51 --> Helper loaded: form_helper
INFO - 2023-05-17 15:36:51 --> Database Driver Class Initialized
INFO - 2023-05-17 15:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:36:51 --> Form Validation Class Initialized
INFO - 2023-05-17 15:36:51 --> Controller Class Initialized
INFO - 2023-05-17 15:36:51 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:36:51 --> Model "m_datatest" initialized
ERROR - 2023-05-17 15:36:51 --> Severity: Notice --> Undefined property: stdClass::$asu C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 359
INFO - 2023-05-17 15:36:51 --> Final output sent to browser
INFO - 2023-05-17 15:37:12 --> Config Class Initialized
INFO - 2023-05-17 15:37:12 --> Hooks Class Initialized
INFO - 2023-05-17 15:37:12 --> Utf8 Class Initialized
INFO - 2023-05-17 15:37:12 --> URI Class Initialized
INFO - 2023-05-17 15:37:12 --> Router Class Initialized
INFO - 2023-05-17 15:37:12 --> Output Class Initialized
INFO - 2023-05-17 15:37:12 --> Security Class Initialized
INFO - 2023-05-17 15:37:12 --> Input Class Initialized
INFO - 2023-05-17 15:37:12 --> Language Class Initialized
INFO - 2023-05-17 15:37:12 --> Loader Class Initialized
INFO - 2023-05-17 15:37:12 --> Helper loaded: url_helper
INFO - 2023-05-17 15:37:12 --> Helper loaded: form_helper
INFO - 2023-05-17 15:37:12 --> Database Driver Class Initialized
INFO - 2023-05-17 15:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:37:12 --> Form Validation Class Initialized
INFO - 2023-05-17 15:37:12 --> Controller Class Initialized
INFO - 2023-05-17 15:37:12 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:37:12 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:37:12 --> Final output sent to browser
INFO - 2023-05-17 15:38:03 --> Config Class Initialized
INFO - 2023-05-17 15:38:03 --> Hooks Class Initialized
INFO - 2023-05-17 15:38:03 --> Utf8 Class Initialized
INFO - 2023-05-17 15:38:03 --> URI Class Initialized
INFO - 2023-05-17 15:38:03 --> Router Class Initialized
INFO - 2023-05-17 15:38:03 --> Output Class Initialized
INFO - 2023-05-17 15:38:03 --> Security Class Initialized
INFO - 2023-05-17 15:38:03 --> Input Class Initialized
INFO - 2023-05-17 15:38:03 --> Language Class Initialized
INFO - 2023-05-17 15:38:03 --> Loader Class Initialized
INFO - 2023-05-17 15:38:03 --> Helper loaded: url_helper
INFO - 2023-05-17 15:38:03 --> Helper loaded: form_helper
INFO - 2023-05-17 15:38:03 --> Database Driver Class Initialized
INFO - 2023-05-17 15:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:38:03 --> Form Validation Class Initialized
INFO - 2023-05-17 15:38:03 --> Controller Class Initialized
INFO - 2023-05-17 15:38:03 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:38:03 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:38:03 --> Final output sent to browser
INFO - 2023-05-17 15:42:13 --> Config Class Initialized
INFO - 2023-05-17 15:42:13 --> Hooks Class Initialized
INFO - 2023-05-17 15:42:13 --> Utf8 Class Initialized
INFO - 2023-05-17 15:42:13 --> URI Class Initialized
INFO - 2023-05-17 15:42:13 --> Router Class Initialized
INFO - 2023-05-17 15:42:13 --> Output Class Initialized
INFO - 2023-05-17 15:42:13 --> Security Class Initialized
INFO - 2023-05-17 15:42:13 --> Input Class Initialized
INFO - 2023-05-17 15:42:13 --> Language Class Initialized
INFO - 2023-05-17 15:42:13 --> Loader Class Initialized
INFO - 2023-05-17 15:42:13 --> Helper loaded: url_helper
INFO - 2023-05-17 15:42:13 --> Helper loaded: form_helper
INFO - 2023-05-17 15:42:13 --> Database Driver Class Initialized
INFO - 2023-05-17 15:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:42:13 --> Form Validation Class Initialized
INFO - 2023-05-17 15:42:13 --> Controller Class Initialized
INFO - 2023-05-17 15:42:13 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:42:13 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:42:13 --> Final output sent to browser
INFO - 2023-05-17 15:42:18 --> Config Class Initialized
INFO - 2023-05-17 15:42:18 --> Hooks Class Initialized
INFO - 2023-05-17 15:42:18 --> Utf8 Class Initialized
INFO - 2023-05-17 15:42:18 --> URI Class Initialized
INFO - 2023-05-17 15:42:18 --> Router Class Initialized
INFO - 2023-05-17 15:42:18 --> Output Class Initialized
INFO - 2023-05-17 15:42:18 --> Security Class Initialized
INFO - 2023-05-17 15:42:18 --> Input Class Initialized
INFO - 2023-05-17 15:42:18 --> Language Class Initialized
INFO - 2023-05-17 15:42:18 --> Loader Class Initialized
INFO - 2023-05-17 15:42:18 --> Helper loaded: url_helper
INFO - 2023-05-17 15:42:18 --> Helper loaded: form_helper
INFO - 2023-05-17 15:42:18 --> Database Driver Class Initialized
INFO - 2023-05-17 15:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:42:19 --> Form Validation Class Initialized
INFO - 2023-05-17 15:42:19 --> Controller Class Initialized
INFO - 2023-05-17 15:42:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-17 15:42:19 --> Final output sent to browser
INFO - 2023-05-17 15:43:35 --> Config Class Initialized
INFO - 2023-05-17 15:43:35 --> Hooks Class Initialized
INFO - 2023-05-17 15:43:35 --> Utf8 Class Initialized
INFO - 2023-05-17 15:43:35 --> URI Class Initialized
INFO - 2023-05-17 15:43:35 --> Router Class Initialized
INFO - 2023-05-17 15:43:35 --> Output Class Initialized
INFO - 2023-05-17 15:43:35 --> Security Class Initialized
INFO - 2023-05-17 15:43:35 --> Input Class Initialized
INFO - 2023-05-17 15:43:35 --> Language Class Initialized
INFO - 2023-05-17 15:43:35 --> Loader Class Initialized
INFO - 2023-05-17 15:43:35 --> Helper loaded: url_helper
INFO - 2023-05-17 15:43:35 --> Helper loaded: form_helper
INFO - 2023-05-17 15:43:35 --> Database Driver Class Initialized
INFO - 2023-05-17 15:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:43:35 --> Form Validation Class Initialized
INFO - 2023-05-17 15:43:35 --> Controller Class Initialized
INFO - 2023-05-17 15:43:35 --> Model "m_user" initialized
INFO - 2023-05-17 15:43:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-17 15:43:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-17 15:43:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-17 15:43:35 --> Final output sent to browser
INFO - 2023-05-17 15:43:40 --> Config Class Initialized
INFO - 2023-05-17 15:43:40 --> Hooks Class Initialized
INFO - 2023-05-17 15:43:40 --> Utf8 Class Initialized
INFO - 2023-05-17 15:43:40 --> URI Class Initialized
INFO - 2023-05-17 15:43:40 --> Router Class Initialized
INFO - 2023-05-17 15:43:40 --> Output Class Initialized
INFO - 2023-05-17 15:43:40 --> Security Class Initialized
INFO - 2023-05-17 15:43:40 --> Input Class Initialized
INFO - 2023-05-17 15:43:40 --> Language Class Initialized
INFO - 2023-05-17 15:43:40 --> Loader Class Initialized
INFO - 2023-05-17 15:43:40 --> Helper loaded: url_helper
INFO - 2023-05-17 15:43:40 --> Helper loaded: form_helper
INFO - 2023-05-17 15:43:40 --> Database Driver Class Initialized
INFO - 2023-05-17 15:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:43:40 --> Form Validation Class Initialized
INFO - 2023-05-17 15:43:40 --> Controller Class Initialized
INFO - 2023-05-17 15:43:40 --> Model "m_user" initialized
INFO - 2023-05-17 15:43:41 --> Config Class Initialized
INFO - 2023-05-17 15:43:41 --> Hooks Class Initialized
INFO - 2023-05-17 15:43:41 --> Utf8 Class Initialized
INFO - 2023-05-17 15:43:41 --> URI Class Initialized
INFO - 2023-05-17 15:43:41 --> Router Class Initialized
INFO - 2023-05-17 15:43:41 --> Output Class Initialized
INFO - 2023-05-17 15:43:41 --> Security Class Initialized
INFO - 2023-05-17 15:43:41 --> Input Class Initialized
INFO - 2023-05-17 15:43:41 --> Language Class Initialized
INFO - 2023-05-17 15:43:41 --> Loader Class Initialized
INFO - 2023-05-17 15:43:41 --> Helper loaded: url_helper
INFO - 2023-05-17 15:43:41 --> Helper loaded: form_helper
INFO - 2023-05-17 15:43:41 --> Database Driver Class Initialized
INFO - 2023-05-17 15:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:43:41 --> Form Validation Class Initialized
INFO - 2023-05-17 15:43:41 --> Controller Class Initialized
INFO - 2023-05-17 15:43:41 --> Model "m_user" initialized
INFO - 2023-05-17 15:43:41 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:43:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-17 15:43:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-17 15:43:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-17 15:43:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-17 15:43:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-17 15:43:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-17 15:43:41 --> Final output sent to browser
INFO - 2023-05-17 15:43:43 --> Config Class Initialized
INFO - 2023-05-17 15:43:43 --> Hooks Class Initialized
INFO - 2023-05-17 15:43:43 --> Utf8 Class Initialized
INFO - 2023-05-17 15:43:43 --> URI Class Initialized
INFO - 2023-05-17 15:43:43 --> Router Class Initialized
INFO - 2023-05-17 15:43:43 --> Output Class Initialized
INFO - 2023-05-17 15:43:43 --> Security Class Initialized
INFO - 2023-05-17 15:43:43 --> Input Class Initialized
INFO - 2023-05-17 15:43:43 --> Language Class Initialized
INFO - 2023-05-17 15:43:43 --> Loader Class Initialized
INFO - 2023-05-17 15:43:43 --> Helper loaded: url_helper
INFO - 2023-05-17 15:43:43 --> Helper loaded: form_helper
INFO - 2023-05-17 15:43:43 --> Database Driver Class Initialized
INFO - 2023-05-17 15:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:43:43 --> Form Validation Class Initialized
INFO - 2023-05-17 15:43:43 --> Controller Class Initialized
INFO - 2023-05-17 15:43:43 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:43:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-17 15:43:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-17 15:43:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-17 15:43:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-17 15:43:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-17 15:43:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-17 15:43:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-17 15:43:43 --> Final output sent to browser
INFO - 2023-05-17 15:43:47 --> Config Class Initialized
INFO - 2023-05-17 15:43:47 --> Hooks Class Initialized
INFO - 2023-05-17 15:43:47 --> Utf8 Class Initialized
INFO - 2023-05-17 15:43:47 --> URI Class Initialized
INFO - 2023-05-17 15:43:47 --> Router Class Initialized
INFO - 2023-05-17 15:43:47 --> Output Class Initialized
INFO - 2023-05-17 15:43:47 --> Security Class Initialized
INFO - 2023-05-17 15:43:47 --> Input Class Initialized
INFO - 2023-05-17 15:43:47 --> Language Class Initialized
INFO - 2023-05-17 15:43:47 --> Loader Class Initialized
INFO - 2023-05-17 15:43:47 --> Helper loaded: url_helper
INFO - 2023-05-17 15:43:47 --> Helper loaded: form_helper
INFO - 2023-05-17 15:43:47 --> Database Driver Class Initialized
INFO - 2023-05-17 15:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:43:47 --> Form Validation Class Initialized
INFO - 2023-05-17 15:43:47 --> Controller Class Initialized
INFO - 2023-05-17 15:43:47 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:43:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-17 15:43:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-17 15:43:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-17 15:43:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-17 15:43:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-17 15:43:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-17 15:43:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-17 15:43:47 --> Final output sent to browser
INFO - 2023-05-17 15:45:30 --> Config Class Initialized
INFO - 2023-05-17 15:45:30 --> Hooks Class Initialized
INFO - 2023-05-17 15:45:30 --> Utf8 Class Initialized
INFO - 2023-05-17 15:45:30 --> URI Class Initialized
INFO - 2023-05-17 15:45:30 --> Router Class Initialized
INFO - 2023-05-17 15:45:30 --> Output Class Initialized
INFO - 2023-05-17 15:45:30 --> Security Class Initialized
INFO - 2023-05-17 15:45:30 --> Input Class Initialized
INFO - 2023-05-17 15:45:30 --> Language Class Initialized
INFO - 2023-05-17 15:45:30 --> Loader Class Initialized
INFO - 2023-05-17 15:45:30 --> Helper loaded: url_helper
INFO - 2023-05-17 15:45:30 --> Helper loaded: form_helper
INFO - 2023-05-17 15:45:30 --> Database Driver Class Initialized
INFO - 2023-05-17 15:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:45:30 --> Form Validation Class Initialized
INFO - 2023-05-17 15:45:30 --> Controller Class Initialized
INFO - 2023-05-17 15:45:30 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:45:30 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:45:30 --> Final output sent to browser
INFO - 2023-05-17 15:46:18 --> Config Class Initialized
INFO - 2023-05-17 15:46:18 --> Hooks Class Initialized
INFO - 2023-05-17 15:46:18 --> Utf8 Class Initialized
INFO - 2023-05-17 15:46:18 --> URI Class Initialized
INFO - 2023-05-17 15:46:18 --> Router Class Initialized
INFO - 2023-05-17 15:46:18 --> Output Class Initialized
INFO - 2023-05-17 15:46:18 --> Security Class Initialized
INFO - 2023-05-17 15:46:18 --> Input Class Initialized
INFO - 2023-05-17 15:46:18 --> Language Class Initialized
INFO - 2023-05-17 15:46:18 --> Loader Class Initialized
INFO - 2023-05-17 15:46:18 --> Helper loaded: url_helper
INFO - 2023-05-17 15:46:18 --> Helper loaded: form_helper
INFO - 2023-05-17 15:46:18 --> Database Driver Class Initialized
INFO - 2023-05-17 15:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:46:18 --> Form Validation Class Initialized
INFO - 2023-05-17 15:46:18 --> Controller Class Initialized
INFO - 2023-05-17 15:46:18 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:46:18 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:46:18 --> Final output sent to browser
INFO - 2023-05-17 15:57:35 --> Config Class Initialized
INFO - 2023-05-17 15:57:35 --> Hooks Class Initialized
INFO - 2023-05-17 15:57:35 --> Utf8 Class Initialized
INFO - 2023-05-17 15:57:35 --> URI Class Initialized
INFO - 2023-05-17 15:57:35 --> Router Class Initialized
INFO - 2023-05-17 15:57:35 --> Output Class Initialized
INFO - 2023-05-17 15:57:35 --> Security Class Initialized
INFO - 2023-05-17 15:57:35 --> Input Class Initialized
INFO - 2023-05-17 15:57:35 --> Language Class Initialized
INFO - 2023-05-17 15:57:35 --> Loader Class Initialized
INFO - 2023-05-17 15:57:35 --> Helper loaded: url_helper
INFO - 2023-05-17 15:57:35 --> Helper loaded: form_helper
INFO - 2023-05-17 15:57:35 --> Database Driver Class Initialized
INFO - 2023-05-17 15:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:57:35 --> Form Validation Class Initialized
INFO - 2023-05-17 15:57:35 --> Controller Class Initialized
INFO - 2023-05-17 15:57:35 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:57:35 --> Model "m_datatest" initialized
ERROR - 2023-05-17 15:57:35 --> Severity: Error --> Call to undefined method m_datatrain::getHasilGangguanMood() C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 350
INFO - 2023-05-17 15:59:53 --> Config Class Initialized
INFO - 2023-05-17 15:59:53 --> Hooks Class Initialized
INFO - 2023-05-17 15:59:53 --> Utf8 Class Initialized
INFO - 2023-05-17 15:59:53 --> URI Class Initialized
INFO - 2023-05-17 15:59:53 --> Router Class Initialized
INFO - 2023-05-17 15:59:53 --> Output Class Initialized
INFO - 2023-05-17 15:59:53 --> Security Class Initialized
INFO - 2023-05-17 15:59:53 --> Input Class Initialized
INFO - 2023-05-17 15:59:53 --> Language Class Initialized
INFO - 2023-05-17 15:59:53 --> Loader Class Initialized
INFO - 2023-05-17 15:59:53 --> Helper loaded: url_helper
INFO - 2023-05-17 15:59:53 --> Helper loaded: form_helper
INFO - 2023-05-17 15:59:53 --> Database Driver Class Initialized
INFO - 2023-05-17 15:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-17 15:59:53 --> Form Validation Class Initialized
INFO - 2023-05-17 15:59:53 --> Controller Class Initialized
INFO - 2023-05-17 15:59:53 --> Model "m_datatrain" initialized
INFO - 2023-05-17 15:59:53 --> Model "m_penghitungan" initialized
INFO - 2023-05-17 15:59:53 --> Model "m_datatest" initialized
INFO - 2023-05-17 15:59:53 --> Final output sent to browser
