<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-19 05:33:44 --> Config Class Initialized
INFO - 2022-03-19 05:33:44 --> Hooks Class Initialized
INFO - 2022-03-19 05:33:44 --> Utf8 Class Initialized
INFO - 2022-03-19 05:33:44 --> URI Class Initialized
INFO - 2022-03-19 05:33:44 --> Router Class Initialized
INFO - 2022-03-19 05:33:44 --> Output Class Initialized
INFO - 2022-03-19 05:33:44 --> Security Class Initialized
INFO - 2022-03-19 05:33:44 --> Input Class Initialized
INFO - 2022-03-19 05:33:44 --> Language Class Initialized
INFO - 2022-03-19 05:33:44 --> Loader Class Initialized
INFO - 2022-03-19 05:33:44 --> Helper loaded: url_helper
INFO - 2022-03-19 05:33:44 --> Helper loaded: form_helper
INFO - 2022-03-19 05:33:44 --> Database Driver Class Initialized
INFO - 2022-03-19 05:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:33:44 --> Form Validation Class Initialized
INFO - 2022-03-19 05:33:44 --> Controller Class Initialized
INFO - 2022-03-19 05:33:44 --> Model "M_todo_list" initialized
INFO - 2022-03-19 05:33:44 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:33:44 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:33:44 --> Model "M_todo_task" initialized
INFO - 2022-03-19 05:33:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:33:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:33:44 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-19 05:33:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:33:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:33:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:33:44 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:33:44 --> Final output sent to browser
INFO - 2022-03-19 05:34:16 --> Config Class Initialized
INFO - 2022-03-19 05:34:16 --> Hooks Class Initialized
INFO - 2022-03-19 05:34:16 --> Utf8 Class Initialized
INFO - 2022-03-19 05:34:16 --> URI Class Initialized
INFO - 2022-03-19 05:34:16 --> Router Class Initialized
INFO - 2022-03-19 05:34:16 --> Output Class Initialized
INFO - 2022-03-19 05:34:16 --> Security Class Initialized
INFO - 2022-03-19 05:34:16 --> Input Class Initialized
INFO - 2022-03-19 05:34:16 --> Language Class Initialized
INFO - 2022-03-19 05:34:16 --> Loader Class Initialized
INFO - 2022-03-19 05:34:16 --> Helper loaded: url_helper
INFO - 2022-03-19 05:34:16 --> Helper loaded: form_helper
INFO - 2022-03-19 05:34:16 --> Database Driver Class Initialized
INFO - 2022-03-19 05:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:34:16 --> Form Validation Class Initialized
INFO - 2022-03-19 05:34:16 --> Controller Class Initialized
INFO - 2022-03-19 05:34:16 --> Model "M_todo_list" initialized
INFO - 2022-03-19 05:34:16 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:34:16 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:34:16 --> Model "M_todo_task" initialized
INFO - 2022-03-19 05:34:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:34:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:34:16 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-19 05:34:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:34:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:34:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:34:16 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:34:16 --> Final output sent to browser
INFO - 2022-03-19 05:34:33 --> Config Class Initialized
INFO - 2022-03-19 05:34:33 --> Hooks Class Initialized
INFO - 2022-03-19 05:34:33 --> Utf8 Class Initialized
INFO - 2022-03-19 05:34:33 --> URI Class Initialized
INFO - 2022-03-19 05:34:33 --> Router Class Initialized
INFO - 2022-03-19 05:34:33 --> Output Class Initialized
INFO - 2022-03-19 05:34:33 --> Security Class Initialized
INFO - 2022-03-19 05:34:33 --> Input Class Initialized
INFO - 2022-03-19 05:34:33 --> Language Class Initialized
INFO - 2022-03-19 05:34:33 --> Loader Class Initialized
INFO - 2022-03-19 05:34:33 --> Helper loaded: url_helper
INFO - 2022-03-19 05:34:33 --> Helper loaded: form_helper
INFO - 2022-03-19 05:34:33 --> Database Driver Class Initialized
INFO - 2022-03-19 05:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:34:33 --> Form Validation Class Initialized
INFO - 2022-03-19 05:34:33 --> Controller Class Initialized
INFO - 2022-03-19 05:34:33 --> Model "M_todo_list" initialized
INFO - 2022-03-19 05:34:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:34:33 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:34:33 --> Model "M_todo_task" initialized
INFO - 2022-03-19 05:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-19 05:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:34:33 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:34:33 --> Final output sent to browser
INFO - 2022-03-19 05:34:44 --> Config Class Initialized
INFO - 2022-03-19 05:34:44 --> Hooks Class Initialized
INFO - 2022-03-19 05:34:44 --> Utf8 Class Initialized
INFO - 2022-03-19 05:34:44 --> URI Class Initialized
INFO - 2022-03-19 05:34:44 --> Router Class Initialized
INFO - 2022-03-19 05:34:44 --> Output Class Initialized
INFO - 2022-03-19 05:34:44 --> Security Class Initialized
INFO - 2022-03-19 05:34:44 --> Input Class Initialized
INFO - 2022-03-19 05:34:44 --> Language Class Initialized
INFO - 2022-03-19 05:34:44 --> Loader Class Initialized
INFO - 2022-03-19 05:34:44 --> Helper loaded: url_helper
INFO - 2022-03-19 05:34:44 --> Helper loaded: form_helper
INFO - 2022-03-19 05:34:44 --> Database Driver Class Initialized
INFO - 2022-03-19 05:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:34:45 --> Form Validation Class Initialized
INFO - 2022-03-19 05:34:45 --> Controller Class Initialized
INFO - 2022-03-19 05:34:45 --> Model "M_todo_list" initialized
INFO - 2022-03-19 05:34:45 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:34:45 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:34:45 --> Model "M_todo_task" initialized
INFO - 2022-03-19 05:34:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:34:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:34:45 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-19 05:34:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:34:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:34:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:34:45 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:34:45 --> Final output sent to browser
INFO - 2022-03-19 05:35:44 --> Config Class Initialized
INFO - 2022-03-19 05:35:44 --> Hooks Class Initialized
INFO - 2022-03-19 05:35:44 --> Utf8 Class Initialized
INFO - 2022-03-19 05:35:44 --> URI Class Initialized
INFO - 2022-03-19 05:35:44 --> Router Class Initialized
INFO - 2022-03-19 05:35:44 --> Output Class Initialized
INFO - 2022-03-19 05:35:44 --> Security Class Initialized
INFO - 2022-03-19 05:35:44 --> Input Class Initialized
INFO - 2022-03-19 05:35:44 --> Language Class Initialized
INFO - 2022-03-19 05:35:44 --> Loader Class Initialized
INFO - 2022-03-19 05:35:44 --> Helper loaded: url_helper
INFO - 2022-03-19 05:35:44 --> Helper loaded: form_helper
INFO - 2022-03-19 05:35:44 --> Database Driver Class Initialized
INFO - 2022-03-19 05:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:35:44 --> Form Validation Class Initialized
INFO - 2022-03-19 05:35:44 --> Controller Class Initialized
INFO - 2022-03-19 05:35:44 --> Model "M_todo_list" initialized
INFO - 2022-03-19 05:35:44 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:35:44 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:35:44 --> Model "M_todo_task" initialized
INFO - 2022-03-19 05:35:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:35:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:35:44 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-19 05:35:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:35:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:35:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:35:44 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:35:44 --> Final output sent to browser
INFO - 2022-03-19 05:35:58 --> Config Class Initialized
INFO - 2022-03-19 05:35:58 --> Hooks Class Initialized
INFO - 2022-03-19 05:35:58 --> Utf8 Class Initialized
INFO - 2022-03-19 05:35:58 --> URI Class Initialized
INFO - 2022-03-19 05:35:58 --> Router Class Initialized
INFO - 2022-03-19 05:35:58 --> Output Class Initialized
INFO - 2022-03-19 05:35:58 --> Security Class Initialized
INFO - 2022-03-19 05:35:58 --> Input Class Initialized
INFO - 2022-03-19 05:35:58 --> Language Class Initialized
INFO - 2022-03-19 05:35:58 --> Loader Class Initialized
INFO - 2022-03-19 05:35:58 --> Helper loaded: url_helper
INFO - 2022-03-19 05:35:58 --> Helper loaded: form_helper
INFO - 2022-03-19 05:35:58 --> Database Driver Class Initialized
INFO - 2022-03-19 05:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:35:58 --> Form Validation Class Initialized
INFO - 2022-03-19 05:35:58 --> Controller Class Initialized
INFO - 2022-03-19 05:35:58 --> Model "M_todo_list" initialized
INFO - 2022-03-19 05:35:58 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:35:58 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:35:58 --> Model "M_todo_task" initialized
INFO - 2022-03-19 05:35:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:35:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:35:58 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-19 05:35:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:35:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:35:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:35:58 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:35:58 --> Final output sent to browser
INFO - 2022-03-19 05:36:23 --> Config Class Initialized
INFO - 2022-03-19 05:36:23 --> Hooks Class Initialized
INFO - 2022-03-19 05:36:23 --> Utf8 Class Initialized
INFO - 2022-03-19 05:36:23 --> URI Class Initialized
INFO - 2022-03-19 05:36:23 --> Router Class Initialized
INFO - 2022-03-19 05:36:23 --> Output Class Initialized
INFO - 2022-03-19 05:36:23 --> Security Class Initialized
INFO - 2022-03-19 05:36:23 --> Input Class Initialized
INFO - 2022-03-19 05:36:23 --> Language Class Initialized
INFO - 2022-03-19 05:36:23 --> Loader Class Initialized
INFO - 2022-03-19 05:36:23 --> Helper loaded: url_helper
INFO - 2022-03-19 05:36:23 --> Helper loaded: form_helper
INFO - 2022-03-19 05:36:23 --> Database Driver Class Initialized
INFO - 2022-03-19 05:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:36:23 --> Form Validation Class Initialized
INFO - 2022-03-19 05:36:23 --> Controller Class Initialized
INFO - 2022-03-19 05:36:23 --> Model "M_todo_list" initialized
INFO - 2022-03-19 05:36:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:36:23 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:36:23 --> Model "M_todo_task" initialized
INFO - 2022-03-19 05:36:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:36:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:36:23 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-19 05:36:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:36:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:36:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:36:23 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:36:23 --> Final output sent to browser
INFO - 2022-03-19 05:38:42 --> Config Class Initialized
INFO - 2022-03-19 05:38:42 --> Hooks Class Initialized
INFO - 2022-03-19 05:38:42 --> Utf8 Class Initialized
INFO - 2022-03-19 05:38:42 --> URI Class Initialized
INFO - 2022-03-19 05:38:42 --> Router Class Initialized
INFO - 2022-03-19 05:38:42 --> Output Class Initialized
INFO - 2022-03-19 05:38:42 --> Security Class Initialized
INFO - 2022-03-19 05:38:42 --> Input Class Initialized
INFO - 2022-03-19 05:38:42 --> Language Class Initialized
INFO - 2022-03-19 05:38:42 --> Loader Class Initialized
INFO - 2022-03-19 05:38:42 --> Helper loaded: url_helper
INFO - 2022-03-19 05:38:42 --> Helper loaded: form_helper
INFO - 2022-03-19 05:38:42 --> Database Driver Class Initialized
INFO - 2022-03-19 05:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:38:42 --> Form Validation Class Initialized
INFO - 2022-03-19 05:38:42 --> Controller Class Initialized
INFO - 2022-03-19 05:38:42 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:38:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:38:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:38:42 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-19 05:38:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:38:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:38:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:38:42 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:38:42 --> Final output sent to browser
INFO - 2022-03-19 05:38:59 --> Config Class Initialized
INFO - 2022-03-19 05:38:59 --> Hooks Class Initialized
INFO - 2022-03-19 05:38:59 --> Utf8 Class Initialized
INFO - 2022-03-19 05:38:59 --> URI Class Initialized
INFO - 2022-03-19 05:38:59 --> Router Class Initialized
INFO - 2022-03-19 05:38:59 --> Output Class Initialized
INFO - 2022-03-19 05:38:59 --> Security Class Initialized
INFO - 2022-03-19 05:38:59 --> Input Class Initialized
INFO - 2022-03-19 05:38:59 --> Language Class Initialized
INFO - 2022-03-19 05:38:59 --> Loader Class Initialized
INFO - 2022-03-19 05:38:59 --> Helper loaded: url_helper
INFO - 2022-03-19 05:38:59 --> Helper loaded: form_helper
INFO - 2022-03-19 05:38:59 --> Database Driver Class Initialized
INFO - 2022-03-19 05:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:38:59 --> Form Validation Class Initialized
INFO - 2022-03-19 05:38:59 --> Controller Class Initialized
INFO - 2022-03-19 05:38:59 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:38:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:38:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:38:59 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_tambah.php
INFO - 2022-03-19 05:38:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:38:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:38:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:38:59 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:38:59 --> Final output sent to browser
INFO - 2022-03-19 05:39:10 --> Config Class Initialized
INFO - 2022-03-19 05:39:10 --> Hooks Class Initialized
INFO - 2022-03-19 05:39:10 --> Utf8 Class Initialized
INFO - 2022-03-19 05:39:10 --> URI Class Initialized
INFO - 2022-03-19 05:39:10 --> Router Class Initialized
INFO - 2022-03-19 05:39:10 --> Output Class Initialized
INFO - 2022-03-19 05:39:10 --> Security Class Initialized
INFO - 2022-03-19 05:39:10 --> Input Class Initialized
INFO - 2022-03-19 05:39:10 --> Language Class Initialized
INFO - 2022-03-19 05:39:10 --> Loader Class Initialized
INFO - 2022-03-19 05:39:10 --> Helper loaded: url_helper
INFO - 2022-03-19 05:39:10 --> Helper loaded: form_helper
INFO - 2022-03-19 05:39:10 --> Database Driver Class Initialized
INFO - 2022-03-19 05:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:39:10 --> Form Validation Class Initialized
INFO - 2022-03-19 05:39:10 --> Controller Class Initialized
INFO - 2022-03-19 05:39:10 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:39:10 --> Config Class Initialized
INFO - 2022-03-19 05:39:10 --> Hooks Class Initialized
INFO - 2022-03-19 05:39:10 --> Utf8 Class Initialized
INFO - 2022-03-19 05:39:10 --> URI Class Initialized
INFO - 2022-03-19 05:39:10 --> Router Class Initialized
INFO - 2022-03-19 05:39:10 --> Output Class Initialized
INFO - 2022-03-19 05:39:10 --> Security Class Initialized
INFO - 2022-03-19 05:39:10 --> Input Class Initialized
INFO - 2022-03-19 05:39:10 --> Language Class Initialized
INFO - 2022-03-19 05:39:10 --> Loader Class Initialized
INFO - 2022-03-19 05:39:10 --> Helper loaded: url_helper
INFO - 2022-03-19 05:39:10 --> Helper loaded: form_helper
INFO - 2022-03-19 05:39:10 --> Database Driver Class Initialized
INFO - 2022-03-19 05:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:39:10 --> Form Validation Class Initialized
INFO - 2022-03-19 05:39:10 --> Controller Class Initialized
INFO - 2022-03-19 05:39:10 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:39:10 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:39:10 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:39:10 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-19 05:39:10 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:39:10 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:39:10 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:39:10 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:39:10 --> Final output sent to browser
INFO - 2022-03-19 05:39:36 --> Config Class Initialized
INFO - 2022-03-19 05:39:36 --> Hooks Class Initialized
INFO - 2022-03-19 05:39:36 --> Utf8 Class Initialized
INFO - 2022-03-19 05:39:36 --> URI Class Initialized
INFO - 2022-03-19 05:39:36 --> Router Class Initialized
INFO - 2022-03-19 05:39:36 --> Output Class Initialized
INFO - 2022-03-19 05:39:36 --> Security Class Initialized
INFO - 2022-03-19 05:39:36 --> Input Class Initialized
INFO - 2022-03-19 05:39:36 --> Language Class Initialized
ERROR - 2022-03-19 05:39:36 --> 404 Page Not Found: Login/index
INFO - 2022-03-19 05:39:41 --> Config Class Initialized
INFO - 2022-03-19 05:39:41 --> Hooks Class Initialized
INFO - 2022-03-19 05:39:41 --> Utf8 Class Initialized
INFO - 2022-03-19 05:39:41 --> URI Class Initialized
INFO - 2022-03-19 05:39:41 --> Router Class Initialized
INFO - 2022-03-19 05:39:41 --> Output Class Initialized
INFO - 2022-03-19 05:39:41 --> Security Class Initialized
INFO - 2022-03-19 05:39:41 --> Input Class Initialized
INFO - 2022-03-19 05:39:41 --> Language Class Initialized
INFO - 2022-03-19 05:39:41 --> Loader Class Initialized
INFO - 2022-03-19 05:39:41 --> Helper loaded: url_helper
INFO - 2022-03-19 05:39:41 --> Helper loaded: form_helper
INFO - 2022-03-19 05:39:41 --> Database Driver Class Initialized
INFO - 2022-03-19 05:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:39:41 --> Form Validation Class Initialized
INFO - 2022-03-19 05:39:41 --> Controller Class Initialized
INFO - 2022-03-19 05:39:41 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:39:41 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-19 05:39:41 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-19 05:39:41 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-19 05:39:41 --> Final output sent to browser
INFO - 2022-03-19 05:39:46 --> Config Class Initialized
INFO - 2022-03-19 05:39:46 --> Hooks Class Initialized
INFO - 2022-03-19 05:39:46 --> Utf8 Class Initialized
INFO - 2022-03-19 05:39:46 --> URI Class Initialized
INFO - 2022-03-19 05:39:46 --> Router Class Initialized
INFO - 2022-03-19 05:39:46 --> Output Class Initialized
INFO - 2022-03-19 05:39:46 --> Security Class Initialized
INFO - 2022-03-19 05:39:46 --> Input Class Initialized
INFO - 2022-03-19 05:39:46 --> Language Class Initialized
INFO - 2022-03-19 05:39:46 --> Loader Class Initialized
INFO - 2022-03-19 05:39:46 --> Helper loaded: url_helper
INFO - 2022-03-19 05:39:46 --> Helper loaded: form_helper
INFO - 2022-03-19 05:39:46 --> Database Driver Class Initialized
INFO - 2022-03-19 05:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:39:46 --> Form Validation Class Initialized
INFO - 2022-03-19 05:39:46 --> Controller Class Initialized
INFO - 2022-03-19 05:39:46 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:39:46 --> Config Class Initialized
INFO - 2022-03-19 05:39:47 --> Hooks Class Initialized
INFO - 2022-03-19 05:39:47 --> Utf8 Class Initialized
INFO - 2022-03-19 05:39:47 --> URI Class Initialized
INFO - 2022-03-19 05:39:47 --> Router Class Initialized
INFO - 2022-03-19 05:39:47 --> Output Class Initialized
INFO - 2022-03-19 05:39:47 --> Security Class Initialized
INFO - 2022-03-19 05:39:47 --> Input Class Initialized
INFO - 2022-03-19 05:39:47 --> Language Class Initialized
INFO - 2022-03-19 05:39:47 --> Loader Class Initialized
INFO - 2022-03-19 05:39:47 --> Helper loaded: url_helper
INFO - 2022-03-19 05:39:47 --> Helper loaded: form_helper
INFO - 2022-03-19 05:39:47 --> Database Driver Class Initialized
INFO - 2022-03-19 05:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:39:47 --> Form Validation Class Initialized
INFO - 2022-03-19 05:39:47 --> Controller Class Initialized
INFO - 2022-03-19 05:39:47 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:39:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:39:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:39:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:39:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:39:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:39:47 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-19 05:39:47 --> Final output sent to browser
INFO - 2022-03-19 05:39:48 --> Config Class Initialized
INFO - 2022-03-19 05:39:48 --> Hooks Class Initialized
INFO - 2022-03-19 05:39:48 --> Config Class Initialized
INFO - 2022-03-19 05:39:48 --> Hooks Class Initialized
INFO - 2022-03-19 05:39:48 --> Utf8 Class Initialized
INFO - 2022-03-19 05:39:48 --> URI Class Initialized
INFO - 2022-03-19 05:39:48 --> Router Class Initialized
INFO - 2022-03-19 05:39:48 --> Output Class Initialized
INFO - 2022-03-19 05:39:48 --> Utf8 Class Initialized
INFO - 2022-03-19 05:39:48 --> Security Class Initialized
INFO - 2022-03-19 05:39:48 --> URI Class Initialized
INFO - 2022-03-19 05:39:48 --> Input Class Initialized
INFO - 2022-03-19 05:39:48 --> Router Class Initialized
INFO - 2022-03-19 05:39:48 --> Language Class Initialized
INFO - 2022-03-19 05:39:48 --> Output Class Initialized
ERROR - 2022-03-19 05:39:48 --> 404 Page Not Found: Img/av1.png
INFO - 2022-03-19 05:39:48 --> Security Class Initialized
INFO - 2022-03-19 05:39:48 --> Input Class Initialized
INFO - 2022-03-19 05:39:48 --> Language Class Initialized
ERROR - 2022-03-19 05:39:48 --> 404 Page Not Found: Img/av4.png
INFO - 2022-03-19 05:40:05 --> Config Class Initialized
INFO - 2022-03-19 05:40:05 --> Hooks Class Initialized
INFO - 2022-03-19 05:40:05 --> Utf8 Class Initialized
INFO - 2022-03-19 05:40:05 --> URI Class Initialized
INFO - 2022-03-19 05:40:05 --> Router Class Initialized
INFO - 2022-03-19 05:40:05 --> Output Class Initialized
INFO - 2022-03-19 05:40:05 --> Security Class Initialized
INFO - 2022-03-19 05:40:05 --> Input Class Initialized
INFO - 2022-03-19 05:40:05 --> Language Class Initialized
INFO - 2022-03-19 05:40:05 --> Loader Class Initialized
INFO - 2022-03-19 05:40:05 --> Helper loaded: url_helper
INFO - 2022-03-19 05:40:05 --> Helper loaded: form_helper
INFO - 2022-03-19 05:40:05 --> Database Driver Class Initialized
INFO - 2022-03-19 05:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:40:05 --> Form Validation Class Initialized
INFO - 2022-03-19 05:40:05 --> Controller Class Initialized
INFO - 2022-03-19 05:40:05 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:40:06 --> Config Class Initialized
INFO - 2022-03-19 05:40:06 --> Hooks Class Initialized
INFO - 2022-03-19 05:40:06 --> Utf8 Class Initialized
INFO - 2022-03-19 05:40:06 --> URI Class Initialized
INFO - 2022-03-19 05:40:06 --> Router Class Initialized
INFO - 2022-03-19 05:40:06 --> Output Class Initialized
INFO - 2022-03-19 05:40:06 --> Security Class Initialized
INFO - 2022-03-19 05:40:06 --> Input Class Initialized
INFO - 2022-03-19 05:40:06 --> Language Class Initialized
INFO - 2022-03-19 05:40:06 --> Loader Class Initialized
INFO - 2022-03-19 05:40:06 --> Helper loaded: url_helper
INFO - 2022-03-19 05:40:06 --> Helper loaded: form_helper
INFO - 2022-03-19 05:40:06 --> Database Driver Class Initialized
INFO - 2022-03-19 05:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:40:06 --> Form Validation Class Initialized
INFO - 2022-03-19 05:40:06 --> Controller Class Initialized
INFO - 2022-03-19 05:40:06 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:40:06 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-19 05:40:06 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-19 05:40:06 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-19 05:40:06 --> Final output sent to browser
INFO - 2022-03-19 05:40:13 --> Config Class Initialized
INFO - 2022-03-19 05:40:13 --> Hooks Class Initialized
INFO - 2022-03-19 05:40:13 --> Utf8 Class Initialized
INFO - 2022-03-19 05:40:13 --> URI Class Initialized
INFO - 2022-03-19 05:40:13 --> Router Class Initialized
INFO - 2022-03-19 05:40:13 --> Output Class Initialized
INFO - 2022-03-19 05:40:13 --> Security Class Initialized
INFO - 2022-03-19 05:40:13 --> Input Class Initialized
INFO - 2022-03-19 05:40:13 --> Language Class Initialized
INFO - 2022-03-19 05:40:13 --> Loader Class Initialized
INFO - 2022-03-19 05:40:13 --> Helper loaded: url_helper
INFO - 2022-03-19 05:40:13 --> Helper loaded: form_helper
INFO - 2022-03-19 05:40:13 --> Database Driver Class Initialized
INFO - 2022-03-19 05:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:40:13 --> Form Validation Class Initialized
INFO - 2022-03-19 05:40:13 --> Controller Class Initialized
INFO - 2022-03-19 05:40:13 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:40:13 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:40:13 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:40:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:40:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:40:13 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-19 05:40:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:40:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:40:13 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:40:13 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:40:13 --> Final output sent to browser
INFO - 2022-03-19 05:40:18 --> Config Class Initialized
INFO - 2022-03-19 05:40:18 --> Hooks Class Initialized
INFO - 2022-03-19 05:40:18 --> Utf8 Class Initialized
INFO - 2022-03-19 05:40:18 --> URI Class Initialized
INFO - 2022-03-19 05:40:18 --> Router Class Initialized
INFO - 2022-03-19 05:40:18 --> Output Class Initialized
INFO - 2022-03-19 05:40:18 --> Security Class Initialized
INFO - 2022-03-19 05:40:18 --> Input Class Initialized
INFO - 2022-03-19 05:40:18 --> Language Class Initialized
INFO - 2022-03-19 05:40:18 --> Loader Class Initialized
INFO - 2022-03-19 05:40:18 --> Helper loaded: url_helper
INFO - 2022-03-19 05:40:18 --> Helper loaded: form_helper
INFO - 2022-03-19 05:40:18 --> Database Driver Class Initialized
INFO - 2022-03-19 05:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:40:18 --> Form Validation Class Initialized
INFO - 2022-03-19 05:40:18 --> Controller Class Initialized
INFO - 2022-03-19 05:40:18 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:40:18 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:40:18 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:40:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:40:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:40:18 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_tambah.php
INFO - 2022-03-19 05:40:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:40:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:40:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:40:18 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:40:18 --> Final output sent to browser
INFO - 2022-03-19 05:40:27 --> Config Class Initialized
INFO - 2022-03-19 05:40:27 --> Hooks Class Initialized
INFO - 2022-03-19 05:40:27 --> Utf8 Class Initialized
INFO - 2022-03-19 05:40:27 --> URI Class Initialized
INFO - 2022-03-19 05:40:27 --> Router Class Initialized
INFO - 2022-03-19 05:40:27 --> Output Class Initialized
INFO - 2022-03-19 05:40:27 --> Security Class Initialized
INFO - 2022-03-19 05:40:27 --> Input Class Initialized
INFO - 2022-03-19 05:40:27 --> Language Class Initialized
INFO - 2022-03-19 05:40:27 --> Loader Class Initialized
INFO - 2022-03-19 05:40:27 --> Helper loaded: url_helper
INFO - 2022-03-19 05:40:27 --> Helper loaded: form_helper
INFO - 2022-03-19 05:40:27 --> Database Driver Class Initialized
INFO - 2022-03-19 05:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:40:27 --> Form Validation Class Initialized
INFO - 2022-03-19 05:40:27 --> Controller Class Initialized
INFO - 2022-03-19 05:40:27 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:40:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:40:27 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:40:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-19 05:40:27 --> Config Class Initialized
INFO - 2022-03-19 05:40:27 --> Hooks Class Initialized
INFO - 2022-03-19 05:40:27 --> Utf8 Class Initialized
INFO - 2022-03-19 05:40:27 --> URI Class Initialized
INFO - 2022-03-19 05:40:27 --> Router Class Initialized
INFO - 2022-03-19 05:40:27 --> Output Class Initialized
INFO - 2022-03-19 05:40:27 --> Security Class Initialized
INFO - 2022-03-19 05:40:27 --> Input Class Initialized
INFO - 2022-03-19 05:40:27 --> Language Class Initialized
INFO - 2022-03-19 05:40:27 --> Loader Class Initialized
INFO - 2022-03-19 05:40:27 --> Helper loaded: url_helper
INFO - 2022-03-19 05:40:27 --> Helper loaded: form_helper
INFO - 2022-03-19 05:40:28 --> Database Driver Class Initialized
INFO - 2022-03-19 05:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:40:28 --> Form Validation Class Initialized
INFO - 2022-03-19 05:40:28 --> Controller Class Initialized
INFO - 2022-03-19 05:40:28 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:40:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:40:28 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:40:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:40:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:40:28 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-19 05:40:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:40:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:40:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:40:28 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:40:28 --> Final output sent to browser
INFO - 2022-03-19 05:40:33 --> Config Class Initialized
INFO - 2022-03-19 05:40:33 --> Hooks Class Initialized
INFO - 2022-03-19 05:40:33 --> Utf8 Class Initialized
INFO - 2022-03-19 05:40:33 --> URI Class Initialized
INFO - 2022-03-19 05:40:33 --> Router Class Initialized
INFO - 2022-03-19 05:40:33 --> Output Class Initialized
INFO - 2022-03-19 05:40:33 --> Security Class Initialized
INFO - 2022-03-19 05:40:33 --> Input Class Initialized
INFO - 2022-03-19 05:40:33 --> Language Class Initialized
INFO - 2022-03-19 05:40:33 --> Loader Class Initialized
INFO - 2022-03-19 05:40:33 --> Helper loaded: url_helper
INFO - 2022-03-19 05:40:33 --> Helper loaded: form_helper
INFO - 2022-03-19 05:40:33 --> Database Driver Class Initialized
INFO - 2022-03-19 05:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:40:33 --> Form Validation Class Initialized
INFO - 2022-03-19 05:40:33 --> Controller Class Initialized
INFO - 2022-03-19 05:40:33 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:40:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:40:33 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:40:33 --> Final output sent to browser
INFO - 2022-03-19 05:44:43 --> Config Class Initialized
INFO - 2022-03-19 05:44:43 --> Hooks Class Initialized
INFO - 2022-03-19 05:44:43 --> Utf8 Class Initialized
INFO - 2022-03-19 05:44:43 --> URI Class Initialized
INFO - 2022-03-19 05:44:43 --> Router Class Initialized
INFO - 2022-03-19 05:44:43 --> Output Class Initialized
INFO - 2022-03-19 05:44:43 --> Security Class Initialized
INFO - 2022-03-19 05:44:43 --> Input Class Initialized
INFO - 2022-03-19 05:44:43 --> Language Class Initialized
INFO - 2022-03-19 05:44:43 --> Loader Class Initialized
INFO - 2022-03-19 05:44:43 --> Helper loaded: url_helper
INFO - 2022-03-19 05:44:43 --> Helper loaded: form_helper
INFO - 2022-03-19 05:44:44 --> Database Driver Class Initialized
INFO - 2022-03-19 05:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:44:44 --> Form Validation Class Initialized
INFO - 2022-03-19 05:44:44 --> Controller Class Initialized
INFO - 2022-03-19 05:44:44 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:44:44 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:44:44 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:44:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:44:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:44:44 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:44:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:44:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:44:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:44:44 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:44:44 --> Final output sent to browser
INFO - 2022-03-19 05:45:21 --> Config Class Initialized
INFO - 2022-03-19 05:45:21 --> Hooks Class Initialized
INFO - 2022-03-19 05:45:21 --> Utf8 Class Initialized
INFO - 2022-03-19 05:45:21 --> URI Class Initialized
INFO - 2022-03-19 05:45:21 --> Router Class Initialized
INFO - 2022-03-19 05:45:21 --> Output Class Initialized
INFO - 2022-03-19 05:45:21 --> Security Class Initialized
INFO - 2022-03-19 05:45:21 --> Input Class Initialized
INFO - 2022-03-19 05:45:21 --> Language Class Initialized
INFO - 2022-03-19 05:45:21 --> Loader Class Initialized
INFO - 2022-03-19 05:45:21 --> Helper loaded: url_helper
INFO - 2022-03-19 05:45:21 --> Helper loaded: form_helper
INFO - 2022-03-19 05:45:21 --> Database Driver Class Initialized
INFO - 2022-03-19 05:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:45:21 --> Form Validation Class Initialized
INFO - 2022-03-19 05:45:21 --> Controller Class Initialized
INFO - 2022-03-19 05:45:21 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:45:21 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:45:21 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:45:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:45:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:45:21 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:45:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:45:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:45:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:45:21 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:45:21 --> Final output sent to browser
INFO - 2022-03-19 05:45:37 --> Config Class Initialized
INFO - 2022-03-19 05:45:37 --> Hooks Class Initialized
INFO - 2022-03-19 05:45:37 --> Utf8 Class Initialized
INFO - 2022-03-19 05:45:37 --> URI Class Initialized
INFO - 2022-03-19 05:45:37 --> Router Class Initialized
INFO - 2022-03-19 05:45:37 --> Output Class Initialized
INFO - 2022-03-19 05:45:37 --> Security Class Initialized
INFO - 2022-03-19 05:45:37 --> Input Class Initialized
INFO - 2022-03-19 05:45:37 --> Language Class Initialized
INFO - 2022-03-19 05:45:37 --> Loader Class Initialized
INFO - 2022-03-19 05:45:37 --> Helper loaded: url_helper
INFO - 2022-03-19 05:45:37 --> Helper loaded: form_helper
INFO - 2022-03-19 05:45:37 --> Database Driver Class Initialized
INFO - 2022-03-19 05:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:45:37 --> Form Validation Class Initialized
INFO - 2022-03-19 05:45:37 --> Controller Class Initialized
INFO - 2022-03-19 05:45:37 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:45:37 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:45:37 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:45:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:45:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:45:37 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:45:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:45:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:45:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:45:37 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:45:37 --> Final output sent to browser
INFO - 2022-03-19 05:45:56 --> Config Class Initialized
INFO - 2022-03-19 05:45:56 --> Hooks Class Initialized
INFO - 2022-03-19 05:45:56 --> Utf8 Class Initialized
INFO - 2022-03-19 05:45:56 --> URI Class Initialized
INFO - 2022-03-19 05:45:56 --> Router Class Initialized
INFO - 2022-03-19 05:45:56 --> Output Class Initialized
INFO - 2022-03-19 05:45:56 --> Security Class Initialized
INFO - 2022-03-19 05:45:56 --> Input Class Initialized
INFO - 2022-03-19 05:45:56 --> Language Class Initialized
INFO - 2022-03-19 05:45:56 --> Loader Class Initialized
INFO - 2022-03-19 05:45:56 --> Helper loaded: url_helper
INFO - 2022-03-19 05:45:56 --> Helper loaded: form_helper
INFO - 2022-03-19 05:45:56 --> Database Driver Class Initialized
INFO - 2022-03-19 05:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:45:56 --> Form Validation Class Initialized
INFO - 2022-03-19 05:45:56 --> Controller Class Initialized
INFO - 2022-03-19 05:45:56 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:45:56 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:45:56 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:45:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:45:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:45:57 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:45:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:45:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:45:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:45:57 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:45:57 --> Final output sent to browser
INFO - 2022-03-19 05:47:30 --> Config Class Initialized
INFO - 2022-03-19 05:47:31 --> Hooks Class Initialized
INFO - 2022-03-19 05:47:31 --> Utf8 Class Initialized
INFO - 2022-03-19 05:47:31 --> URI Class Initialized
INFO - 2022-03-19 05:47:31 --> Router Class Initialized
INFO - 2022-03-19 05:47:31 --> Output Class Initialized
INFO - 2022-03-19 05:47:31 --> Security Class Initialized
INFO - 2022-03-19 05:47:31 --> Input Class Initialized
INFO - 2022-03-19 05:47:31 --> Language Class Initialized
INFO - 2022-03-19 05:47:31 --> Loader Class Initialized
INFO - 2022-03-19 05:47:31 --> Helper loaded: url_helper
INFO - 2022-03-19 05:47:31 --> Helper loaded: form_helper
INFO - 2022-03-19 05:47:31 --> Database Driver Class Initialized
INFO - 2022-03-19 05:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:47:31 --> Form Validation Class Initialized
INFO - 2022-03-19 05:47:31 --> Controller Class Initialized
INFO - 2022-03-19 05:47:31 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:47:31 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:47:31 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:47:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:47:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:47:31 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:47:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:47:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:47:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:47:31 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:47:31 --> Final output sent to browser
INFO - 2022-03-19 05:47:43 --> Config Class Initialized
INFO - 2022-03-19 05:47:43 --> Hooks Class Initialized
INFO - 2022-03-19 05:47:43 --> Utf8 Class Initialized
INFO - 2022-03-19 05:47:43 --> URI Class Initialized
INFO - 2022-03-19 05:47:43 --> Router Class Initialized
INFO - 2022-03-19 05:47:43 --> Output Class Initialized
INFO - 2022-03-19 05:47:43 --> Security Class Initialized
INFO - 2022-03-19 05:47:43 --> Input Class Initialized
INFO - 2022-03-19 05:47:43 --> Language Class Initialized
INFO - 2022-03-19 05:47:43 --> Loader Class Initialized
INFO - 2022-03-19 05:47:43 --> Helper loaded: url_helper
INFO - 2022-03-19 05:47:43 --> Helper loaded: form_helper
INFO - 2022-03-19 05:47:43 --> Database Driver Class Initialized
INFO - 2022-03-19 05:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:47:43 --> Form Validation Class Initialized
INFO - 2022-03-19 05:47:43 --> Controller Class Initialized
INFO - 2022-03-19 05:47:43 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:47:43 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:47:43 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:47:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:47:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:47:43 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:47:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:47:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:47:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:47:43 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:47:43 --> Final output sent to browser
INFO - 2022-03-19 05:48:48 --> Config Class Initialized
INFO - 2022-03-19 05:48:48 --> Hooks Class Initialized
INFO - 2022-03-19 05:48:48 --> Utf8 Class Initialized
INFO - 2022-03-19 05:48:48 --> URI Class Initialized
INFO - 2022-03-19 05:48:48 --> Router Class Initialized
INFO - 2022-03-19 05:48:48 --> Output Class Initialized
INFO - 2022-03-19 05:48:48 --> Security Class Initialized
INFO - 2022-03-19 05:48:48 --> Input Class Initialized
INFO - 2022-03-19 05:48:48 --> Language Class Initialized
INFO - 2022-03-19 05:48:48 --> Loader Class Initialized
INFO - 2022-03-19 05:48:48 --> Helper loaded: url_helper
INFO - 2022-03-19 05:48:48 --> Helper loaded: form_helper
INFO - 2022-03-19 05:48:48 --> Database Driver Class Initialized
INFO - 2022-03-19 05:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:48:48 --> Form Validation Class Initialized
INFO - 2022-03-19 05:48:48 --> Controller Class Initialized
INFO - 2022-03-19 05:48:48 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:48:48 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:48:48 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:48:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:48:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:48:48 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:48:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:48:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:48:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:48:48 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:48:48 --> Final output sent to browser
INFO - 2022-03-19 05:52:05 --> Config Class Initialized
INFO - 2022-03-19 05:52:05 --> Hooks Class Initialized
INFO - 2022-03-19 05:52:05 --> Utf8 Class Initialized
INFO - 2022-03-19 05:52:05 --> URI Class Initialized
INFO - 2022-03-19 05:52:05 --> Router Class Initialized
INFO - 2022-03-19 05:52:05 --> Output Class Initialized
INFO - 2022-03-19 05:52:05 --> Security Class Initialized
INFO - 2022-03-19 05:52:05 --> Input Class Initialized
INFO - 2022-03-19 05:52:05 --> Language Class Initialized
INFO - 2022-03-19 05:52:05 --> Loader Class Initialized
INFO - 2022-03-19 05:52:05 --> Helper loaded: url_helper
INFO - 2022-03-19 05:52:05 --> Helper loaded: form_helper
INFO - 2022-03-19 05:52:05 --> Database Driver Class Initialized
INFO - 2022-03-19 05:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:52:05 --> Form Validation Class Initialized
INFO - 2022-03-19 05:52:05 --> Controller Class Initialized
INFO - 2022-03-19 05:52:05 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:52:05 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:52:05 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:52:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:52:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:52:05 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:52:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:52:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:52:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:52:05 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:52:05 --> Final output sent to browser
INFO - 2022-03-19 05:54:24 --> Config Class Initialized
INFO - 2022-03-19 05:54:24 --> Hooks Class Initialized
INFO - 2022-03-19 05:54:24 --> Utf8 Class Initialized
INFO - 2022-03-19 05:54:24 --> URI Class Initialized
INFO - 2022-03-19 05:54:24 --> Router Class Initialized
INFO - 2022-03-19 05:54:24 --> Output Class Initialized
INFO - 2022-03-19 05:54:24 --> Security Class Initialized
INFO - 2022-03-19 05:54:24 --> Input Class Initialized
INFO - 2022-03-19 05:54:24 --> Language Class Initialized
INFO - 2022-03-19 05:54:24 --> Loader Class Initialized
INFO - 2022-03-19 05:54:24 --> Helper loaded: url_helper
INFO - 2022-03-19 05:54:24 --> Helper loaded: form_helper
INFO - 2022-03-19 05:54:24 --> Database Driver Class Initialized
INFO - 2022-03-19 05:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:54:24 --> Form Validation Class Initialized
INFO - 2022-03-19 05:54:24 --> Controller Class Initialized
INFO - 2022-03-19 05:54:24 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:54:24 --> Final output sent to browser
INFO - 2022-03-19 05:54:26 --> Config Class Initialized
INFO - 2022-03-19 05:54:26 --> Hooks Class Initialized
INFO - 2022-03-19 05:54:26 --> Utf8 Class Initialized
INFO - 2022-03-19 05:54:26 --> URI Class Initialized
INFO - 2022-03-19 05:54:26 --> Router Class Initialized
INFO - 2022-03-19 05:54:26 --> Output Class Initialized
INFO - 2022-03-19 05:54:26 --> Security Class Initialized
INFO - 2022-03-19 05:54:26 --> Input Class Initialized
INFO - 2022-03-19 05:54:26 --> Language Class Initialized
INFO - 2022-03-19 05:54:26 --> Loader Class Initialized
INFO - 2022-03-19 05:54:26 --> Helper loaded: url_helper
INFO - 2022-03-19 05:54:26 --> Helper loaded: form_helper
INFO - 2022-03-19 05:54:26 --> Database Driver Class Initialized
INFO - 2022-03-19 05:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:54:26 --> Form Validation Class Initialized
INFO - 2022-03-19 05:54:26 --> Controller Class Initialized
INFO - 2022-03-19 05:54:26 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:54:26 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:54:26 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:54:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-19 05:54:26 --> Config Class Initialized
INFO - 2022-03-19 05:54:26 --> Hooks Class Initialized
INFO - 2022-03-19 05:54:26 --> Utf8 Class Initialized
INFO - 2022-03-19 05:54:26 --> URI Class Initialized
INFO - 2022-03-19 05:54:26 --> Router Class Initialized
INFO - 2022-03-19 05:54:26 --> Output Class Initialized
INFO - 2022-03-19 05:54:27 --> Security Class Initialized
INFO - 2022-03-19 05:54:27 --> Input Class Initialized
INFO - 2022-03-19 05:54:27 --> Language Class Initialized
INFO - 2022-03-19 05:54:27 --> Loader Class Initialized
INFO - 2022-03-19 05:54:27 --> Helper loaded: url_helper
INFO - 2022-03-19 05:54:27 --> Helper loaded: form_helper
INFO - 2022-03-19 05:54:27 --> Database Driver Class Initialized
INFO - 2022-03-19 05:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:54:27 --> Form Validation Class Initialized
INFO - 2022-03-19 05:54:27 --> Controller Class Initialized
INFO - 2022-03-19 05:54:27 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:54:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:54:27 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:54:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:54:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:54:27 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:54:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:54:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:54:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:54:27 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:54:27 --> Final output sent to browser
INFO - 2022-03-19 05:55:14 --> Config Class Initialized
INFO - 2022-03-19 05:55:14 --> Hooks Class Initialized
INFO - 2022-03-19 05:55:14 --> Utf8 Class Initialized
INFO - 2022-03-19 05:55:14 --> URI Class Initialized
INFO - 2022-03-19 05:55:14 --> Router Class Initialized
INFO - 2022-03-19 05:55:14 --> Output Class Initialized
INFO - 2022-03-19 05:55:14 --> Security Class Initialized
INFO - 2022-03-19 05:55:14 --> Input Class Initialized
INFO - 2022-03-19 05:55:14 --> Language Class Initialized
INFO - 2022-03-19 05:55:14 --> Loader Class Initialized
INFO - 2022-03-19 05:55:14 --> Helper loaded: url_helper
INFO - 2022-03-19 05:55:14 --> Helper loaded: form_helper
INFO - 2022-03-19 05:55:14 --> Database Driver Class Initialized
INFO - 2022-03-19 05:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:55:14 --> Form Validation Class Initialized
INFO - 2022-03-19 05:55:14 --> Controller Class Initialized
INFO - 2022-03-19 05:55:14 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:55:14 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:55:14 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:55:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:55:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:55:14 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:55:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:55:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:55:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:55:14 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:55:14 --> Final output sent to browser
INFO - 2022-03-19 05:55:46 --> Config Class Initialized
INFO - 2022-03-19 05:55:46 --> Hooks Class Initialized
INFO - 2022-03-19 05:55:46 --> Utf8 Class Initialized
INFO - 2022-03-19 05:55:46 --> URI Class Initialized
INFO - 2022-03-19 05:55:46 --> Router Class Initialized
INFO - 2022-03-19 05:55:46 --> Output Class Initialized
INFO - 2022-03-19 05:55:46 --> Security Class Initialized
INFO - 2022-03-19 05:55:46 --> Input Class Initialized
INFO - 2022-03-19 05:55:46 --> Language Class Initialized
INFO - 2022-03-19 05:55:46 --> Loader Class Initialized
INFO - 2022-03-19 05:55:46 --> Helper loaded: url_helper
INFO - 2022-03-19 05:55:46 --> Helper loaded: form_helper
INFO - 2022-03-19 05:55:46 --> Database Driver Class Initialized
INFO - 2022-03-19 05:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:55:46 --> Form Validation Class Initialized
INFO - 2022-03-19 05:55:46 --> Controller Class Initialized
INFO - 2022-03-19 05:55:46 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:55:46 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:55:46 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:55:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:55:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:55:46 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:55:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:55:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:55:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:55:46 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:55:46 --> Final output sent to browser
INFO - 2022-03-19 05:56:09 --> Config Class Initialized
INFO - 2022-03-19 05:56:09 --> Hooks Class Initialized
INFO - 2022-03-19 05:56:09 --> Utf8 Class Initialized
INFO - 2022-03-19 05:56:09 --> URI Class Initialized
INFO - 2022-03-19 05:56:09 --> Router Class Initialized
INFO - 2022-03-19 05:56:09 --> Output Class Initialized
INFO - 2022-03-19 05:56:09 --> Security Class Initialized
INFO - 2022-03-19 05:56:09 --> Input Class Initialized
INFO - 2022-03-19 05:56:09 --> Language Class Initialized
INFO - 2022-03-19 05:56:09 --> Loader Class Initialized
INFO - 2022-03-19 05:56:09 --> Helper loaded: url_helper
INFO - 2022-03-19 05:56:09 --> Helper loaded: form_helper
INFO - 2022-03-19 05:56:09 --> Database Driver Class Initialized
INFO - 2022-03-19 05:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:56:09 --> Form Validation Class Initialized
INFO - 2022-03-19 05:56:09 --> Controller Class Initialized
INFO - 2022-03-19 05:56:09 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:56:09 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:56:09 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:56:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:56:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:56:09 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:56:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:56:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:56:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:56:09 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:56:09 --> Final output sent to browser
INFO - 2022-03-19 05:56:25 --> Config Class Initialized
INFO - 2022-03-19 05:56:25 --> Hooks Class Initialized
INFO - 2022-03-19 05:56:25 --> Utf8 Class Initialized
INFO - 2022-03-19 05:56:25 --> URI Class Initialized
INFO - 2022-03-19 05:56:25 --> Router Class Initialized
INFO - 2022-03-19 05:56:25 --> Output Class Initialized
INFO - 2022-03-19 05:56:25 --> Security Class Initialized
INFO - 2022-03-19 05:56:25 --> Input Class Initialized
INFO - 2022-03-19 05:56:25 --> Language Class Initialized
INFO - 2022-03-19 05:56:25 --> Loader Class Initialized
INFO - 2022-03-19 05:56:25 --> Helper loaded: url_helper
INFO - 2022-03-19 05:56:25 --> Helper loaded: form_helper
INFO - 2022-03-19 05:56:25 --> Database Driver Class Initialized
INFO - 2022-03-19 05:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:56:25 --> Form Validation Class Initialized
INFO - 2022-03-19 05:56:25 --> Controller Class Initialized
INFO - 2022-03-19 05:56:25 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:56:25 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:56:25 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:56:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:56:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:56:25 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:56:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:56:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:56:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:56:25 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:56:25 --> Final output sent to browser
INFO - 2022-03-19 05:56:43 --> Config Class Initialized
INFO - 2022-03-19 05:56:43 --> Hooks Class Initialized
INFO - 2022-03-19 05:56:43 --> Utf8 Class Initialized
INFO - 2022-03-19 05:56:43 --> URI Class Initialized
INFO - 2022-03-19 05:56:43 --> Router Class Initialized
INFO - 2022-03-19 05:56:43 --> Output Class Initialized
INFO - 2022-03-19 05:56:43 --> Security Class Initialized
INFO - 2022-03-19 05:56:43 --> Input Class Initialized
INFO - 2022-03-19 05:56:43 --> Language Class Initialized
INFO - 2022-03-19 05:56:43 --> Loader Class Initialized
INFO - 2022-03-19 05:56:43 --> Helper loaded: url_helper
INFO - 2022-03-19 05:56:43 --> Helper loaded: form_helper
INFO - 2022-03-19 05:56:43 --> Database Driver Class Initialized
INFO - 2022-03-19 05:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:56:43 --> Form Validation Class Initialized
INFO - 2022-03-19 05:56:43 --> Controller Class Initialized
INFO - 2022-03-19 05:56:43 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:56:43 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:56:44 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:56:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:56:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:56:44 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:56:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:56:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:56:44 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:56:44 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:56:44 --> Final output sent to browser
INFO - 2022-03-19 05:58:35 --> Config Class Initialized
INFO - 2022-03-19 05:58:35 --> Hooks Class Initialized
INFO - 2022-03-19 05:58:35 --> Utf8 Class Initialized
INFO - 2022-03-19 05:58:35 --> URI Class Initialized
INFO - 2022-03-19 05:58:35 --> Router Class Initialized
INFO - 2022-03-19 05:58:35 --> Output Class Initialized
INFO - 2022-03-19 05:58:35 --> Security Class Initialized
INFO - 2022-03-19 05:58:35 --> Input Class Initialized
INFO - 2022-03-19 05:58:35 --> Language Class Initialized
INFO - 2022-03-19 05:58:35 --> Loader Class Initialized
INFO - 2022-03-19 05:58:35 --> Helper loaded: url_helper
INFO - 2022-03-19 05:58:35 --> Helper loaded: form_helper
INFO - 2022-03-19 05:58:35 --> Database Driver Class Initialized
INFO - 2022-03-19 05:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:58:35 --> Form Validation Class Initialized
INFO - 2022-03-19 05:58:35 --> Controller Class Initialized
INFO - 2022-03-19 05:58:35 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:58:35 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:58:35 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:58:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:58:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:58:35 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:58:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:58:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:58:35 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:58:35 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:58:35 --> Final output sent to browser
INFO - 2022-03-19 05:58:54 --> Config Class Initialized
INFO - 2022-03-19 05:58:54 --> Hooks Class Initialized
INFO - 2022-03-19 05:58:54 --> Utf8 Class Initialized
INFO - 2022-03-19 05:58:54 --> URI Class Initialized
INFO - 2022-03-19 05:58:54 --> Router Class Initialized
INFO - 2022-03-19 05:58:54 --> Output Class Initialized
INFO - 2022-03-19 05:58:54 --> Security Class Initialized
INFO - 2022-03-19 05:58:54 --> Input Class Initialized
INFO - 2022-03-19 05:58:54 --> Language Class Initialized
INFO - 2022-03-19 05:58:54 --> Loader Class Initialized
INFO - 2022-03-19 05:58:54 --> Helper loaded: url_helper
INFO - 2022-03-19 05:58:54 --> Helper loaded: form_helper
INFO - 2022-03-19 05:58:54 --> Database Driver Class Initialized
INFO - 2022-03-19 05:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:58:54 --> Form Validation Class Initialized
INFO - 2022-03-19 05:58:54 --> Controller Class Initialized
INFO - 2022-03-19 05:58:54 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:58:54 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:58:54 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:58:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:58:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:58:54 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:58:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:58:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:58:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:58:54 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:58:54 --> Final output sent to browser
INFO - 2022-03-19 05:59:05 --> Config Class Initialized
INFO - 2022-03-19 05:59:05 --> Hooks Class Initialized
INFO - 2022-03-19 05:59:05 --> Utf8 Class Initialized
INFO - 2022-03-19 05:59:05 --> URI Class Initialized
INFO - 2022-03-19 05:59:05 --> Router Class Initialized
INFO - 2022-03-19 05:59:05 --> Output Class Initialized
INFO - 2022-03-19 05:59:05 --> Security Class Initialized
INFO - 2022-03-19 05:59:05 --> Input Class Initialized
INFO - 2022-03-19 05:59:05 --> Language Class Initialized
INFO - 2022-03-19 05:59:05 --> Loader Class Initialized
INFO - 2022-03-19 05:59:05 --> Helper loaded: url_helper
INFO - 2022-03-19 05:59:05 --> Helper loaded: form_helper
INFO - 2022-03-19 05:59:05 --> Database Driver Class Initialized
INFO - 2022-03-19 05:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:59:05 --> Form Validation Class Initialized
INFO - 2022-03-19 05:59:05 --> Controller Class Initialized
INFO - 2022-03-19 05:59:05 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:59:05 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:59:05 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:59:05 --> Config Class Initialized
INFO - 2022-03-19 05:59:05 --> Hooks Class Initialized
INFO - 2022-03-19 05:59:05 --> Utf8 Class Initialized
INFO - 2022-03-19 05:59:05 --> URI Class Initialized
INFO - 2022-03-19 05:59:05 --> Router Class Initialized
INFO - 2022-03-19 05:59:05 --> Output Class Initialized
INFO - 2022-03-19 05:59:05 --> Security Class Initialized
INFO - 2022-03-19 05:59:05 --> Input Class Initialized
INFO - 2022-03-19 05:59:05 --> Language Class Initialized
INFO - 2022-03-19 05:59:05 --> Loader Class Initialized
INFO - 2022-03-19 05:59:05 --> Helper loaded: url_helper
INFO - 2022-03-19 05:59:05 --> Helper loaded: form_helper
INFO - 2022-03-19 05:59:05 --> Database Driver Class Initialized
INFO - 2022-03-19 05:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 05:59:05 --> Form Validation Class Initialized
INFO - 2022-03-19 05:59:05 --> Controller Class Initialized
INFO - 2022-03-19 05:59:05 --> Model "M_todo_group" initialized
INFO - 2022-03-19 05:59:05 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 05:59:05 --> Model "M_tutor" initialized
INFO - 2022-03-19 05:59:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 05:59:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 05:59:05 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 05:59:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 05:59:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 05:59:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 05:59:05 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 05:59:05 --> Final output sent to browser
INFO - 2022-03-19 06:00:06 --> Config Class Initialized
INFO - 2022-03-19 06:00:06 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:06 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:06 --> URI Class Initialized
INFO - 2022-03-19 06:00:06 --> Router Class Initialized
INFO - 2022-03-19 06:00:06 --> Output Class Initialized
INFO - 2022-03-19 06:00:06 --> Security Class Initialized
INFO - 2022-03-19 06:00:06 --> Input Class Initialized
INFO - 2022-03-19 06:00:06 --> Language Class Initialized
INFO - 2022-03-19 06:00:06 --> Loader Class Initialized
INFO - 2022-03-19 06:00:06 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:06 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:06 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:06 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:06 --> Controller Class Initialized
INFO - 2022-03-19 06:00:06 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:06 --> Final output sent to browser
INFO - 2022-03-19 06:00:08 --> Config Class Initialized
INFO - 2022-03-19 06:00:08 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:08 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:08 --> URI Class Initialized
INFO - 2022-03-19 06:00:08 --> Router Class Initialized
INFO - 2022-03-19 06:00:08 --> Output Class Initialized
INFO - 2022-03-19 06:00:08 --> Security Class Initialized
INFO - 2022-03-19 06:00:08 --> Input Class Initialized
INFO - 2022-03-19 06:00:08 --> Language Class Initialized
INFO - 2022-03-19 06:00:08 --> Loader Class Initialized
INFO - 2022-03-19 06:00:08 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:08 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:08 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:08 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:08 --> Controller Class Initialized
INFO - 2022-03-19 06:00:08 --> Model "M_todo_group" initialized
INFO - 2022-03-19 06:00:08 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 06:00:08 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-19 06:00:08 --> Config Class Initialized
INFO - 2022-03-19 06:00:08 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:08 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:08 --> URI Class Initialized
INFO - 2022-03-19 06:00:08 --> Router Class Initialized
INFO - 2022-03-19 06:00:08 --> Output Class Initialized
INFO - 2022-03-19 06:00:08 --> Security Class Initialized
INFO - 2022-03-19 06:00:08 --> Input Class Initialized
INFO - 2022-03-19 06:00:08 --> Language Class Initialized
INFO - 2022-03-19 06:00:08 --> Loader Class Initialized
INFO - 2022-03-19 06:00:08 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:08 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:08 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:08 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:08 --> Controller Class Initialized
INFO - 2022-03-19 06:00:08 --> Model "M_todo_group" initialized
INFO - 2022-03-19 06:00:08 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 06:00:08 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 06:00:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 06:00:08 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 06:00:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 06:00:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 06:00:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 06:00:08 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 06:00:08 --> Final output sent to browser
INFO - 2022-03-19 06:00:11 --> Config Class Initialized
INFO - 2022-03-19 06:00:11 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:11 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:11 --> URI Class Initialized
INFO - 2022-03-19 06:00:11 --> Router Class Initialized
INFO - 2022-03-19 06:00:11 --> Output Class Initialized
INFO - 2022-03-19 06:00:11 --> Security Class Initialized
INFO - 2022-03-19 06:00:11 --> Input Class Initialized
INFO - 2022-03-19 06:00:11 --> Language Class Initialized
INFO - 2022-03-19 06:00:11 --> Loader Class Initialized
INFO - 2022-03-19 06:00:11 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:11 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:11 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:11 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:11 --> Controller Class Initialized
INFO - 2022-03-19 06:00:11 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:11 --> Final output sent to browser
INFO - 2022-03-19 06:00:15 --> Config Class Initialized
INFO - 2022-03-19 06:00:15 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:15 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:15 --> URI Class Initialized
INFO - 2022-03-19 06:00:15 --> Router Class Initialized
INFO - 2022-03-19 06:00:15 --> Output Class Initialized
INFO - 2022-03-19 06:00:15 --> Security Class Initialized
INFO - 2022-03-19 06:00:15 --> Input Class Initialized
INFO - 2022-03-19 06:00:15 --> Language Class Initialized
INFO - 2022-03-19 06:00:15 --> Loader Class Initialized
INFO - 2022-03-19 06:00:15 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:15 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:15 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:15 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:15 --> Controller Class Initialized
INFO - 2022-03-19 06:00:15 --> Model "M_todo_group" initialized
INFO - 2022-03-19 06:00:15 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 06:00:15 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:15 --> Config Class Initialized
INFO - 2022-03-19 06:00:15 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:15 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:15 --> URI Class Initialized
INFO - 2022-03-19 06:00:15 --> Router Class Initialized
INFO - 2022-03-19 06:00:15 --> Output Class Initialized
INFO - 2022-03-19 06:00:15 --> Security Class Initialized
INFO - 2022-03-19 06:00:15 --> Input Class Initialized
INFO - 2022-03-19 06:00:15 --> Language Class Initialized
INFO - 2022-03-19 06:00:15 --> Loader Class Initialized
INFO - 2022-03-19 06:00:15 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:15 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:15 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:15 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:15 --> Controller Class Initialized
INFO - 2022-03-19 06:00:15 --> Model "M_todo_group" initialized
INFO - 2022-03-19 06:00:15 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 06:00:15 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 06:00:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 06:00:15 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 06:00:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 06:00:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 06:00:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 06:00:15 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 06:00:15 --> Final output sent to browser
INFO - 2022-03-19 06:00:21 --> Config Class Initialized
INFO - 2022-03-19 06:00:21 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:21 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:21 --> URI Class Initialized
INFO - 2022-03-19 06:00:21 --> Router Class Initialized
INFO - 2022-03-19 06:00:21 --> Output Class Initialized
INFO - 2022-03-19 06:00:21 --> Security Class Initialized
INFO - 2022-03-19 06:00:21 --> Input Class Initialized
INFO - 2022-03-19 06:00:21 --> Language Class Initialized
INFO - 2022-03-19 06:00:21 --> Loader Class Initialized
INFO - 2022-03-19 06:00:21 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:21 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:21 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:21 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:21 --> Controller Class Initialized
INFO - 2022-03-19 06:00:21 --> Model "M_todo_group" initialized
INFO - 2022-03-19 06:00:21 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 06:00:21 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 06:00:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 06:00:21 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-19 06:00:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 06:00:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 06:00:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 06:00:21 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 06:00:21 --> Final output sent to browser
INFO - 2022-03-19 06:00:28 --> Config Class Initialized
INFO - 2022-03-19 06:00:28 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:28 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:28 --> URI Class Initialized
INFO - 2022-03-19 06:00:28 --> Router Class Initialized
INFO - 2022-03-19 06:00:28 --> Output Class Initialized
INFO - 2022-03-19 06:00:28 --> Security Class Initialized
INFO - 2022-03-19 06:00:28 --> Input Class Initialized
INFO - 2022-03-19 06:00:28 --> Language Class Initialized
INFO - 2022-03-19 06:00:28 --> Loader Class Initialized
INFO - 2022-03-19 06:00:28 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:28 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:28 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:28 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:28 --> Controller Class Initialized
INFO - 2022-03-19 06:00:28 --> Model "M_todo_group" initialized
INFO - 2022-03-19 06:00:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 06:00:28 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 06:00:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 06:00:28 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 06:00:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 06:00:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 06:00:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 06:00:28 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 06:00:28 --> Final output sent to browser
INFO - 2022-03-19 06:00:35 --> Config Class Initialized
INFO - 2022-03-19 06:00:35 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:35 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:35 --> URI Class Initialized
INFO - 2022-03-19 06:00:35 --> Router Class Initialized
INFO - 2022-03-19 06:00:35 --> Output Class Initialized
INFO - 2022-03-19 06:00:35 --> Security Class Initialized
INFO - 2022-03-19 06:00:35 --> Input Class Initialized
INFO - 2022-03-19 06:00:35 --> Language Class Initialized
INFO - 2022-03-19 06:00:35 --> Loader Class Initialized
INFO - 2022-03-19 06:00:35 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:35 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:35 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:35 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:35 --> Controller Class Initialized
INFO - 2022-03-19 06:00:35 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:35 --> Final output sent to browser
INFO - 2022-03-19 06:00:36 --> Config Class Initialized
INFO - 2022-03-19 06:00:36 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:36 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:36 --> URI Class Initialized
INFO - 2022-03-19 06:00:36 --> Router Class Initialized
INFO - 2022-03-19 06:00:36 --> Output Class Initialized
INFO - 2022-03-19 06:00:36 --> Security Class Initialized
INFO - 2022-03-19 06:00:36 --> Input Class Initialized
INFO - 2022-03-19 06:00:36 --> Language Class Initialized
INFO - 2022-03-19 06:00:36 --> Loader Class Initialized
INFO - 2022-03-19 06:00:36 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:36 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:36 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:36 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:36 --> Controller Class Initialized
INFO - 2022-03-19 06:00:36 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:36 --> Final output sent to browser
INFO - 2022-03-19 06:00:41 --> Config Class Initialized
INFO - 2022-03-19 06:00:41 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:41 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:41 --> URI Class Initialized
INFO - 2022-03-19 06:00:41 --> Router Class Initialized
INFO - 2022-03-19 06:00:41 --> Output Class Initialized
INFO - 2022-03-19 06:00:41 --> Security Class Initialized
INFO - 2022-03-19 06:00:41 --> Input Class Initialized
INFO - 2022-03-19 06:00:41 --> Language Class Initialized
INFO - 2022-03-19 06:00:41 --> Loader Class Initialized
INFO - 2022-03-19 06:00:41 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:41 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:41 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:41 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:41 --> Controller Class Initialized
INFO - 2022-03-19 06:00:41 --> Model "M_todo_group" initialized
INFO - 2022-03-19 06:00:41 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 06:00:41 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-19 06:00:41 --> Config Class Initialized
INFO - 2022-03-19 06:00:41 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:41 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:41 --> URI Class Initialized
INFO - 2022-03-19 06:00:41 --> Router Class Initialized
INFO - 2022-03-19 06:00:41 --> Output Class Initialized
INFO - 2022-03-19 06:00:41 --> Security Class Initialized
INFO - 2022-03-19 06:00:41 --> Input Class Initialized
INFO - 2022-03-19 06:00:41 --> Language Class Initialized
INFO - 2022-03-19 06:00:41 --> Loader Class Initialized
INFO - 2022-03-19 06:00:41 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:41 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:41 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:41 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:41 --> Controller Class Initialized
INFO - 2022-03-19 06:00:41 --> Model "M_todo_group" initialized
INFO - 2022-03-19 06:00:41 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 06:00:41 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 06:00:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 06:00:41 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-19 06:00:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 06:00:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 06:00:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 06:00:41 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 06:00:41 --> Final output sent to browser
INFO - 2022-03-19 06:00:58 --> Config Class Initialized
INFO - 2022-03-19 06:00:58 --> Hooks Class Initialized
INFO - 2022-03-19 06:00:58 --> Utf8 Class Initialized
INFO - 2022-03-19 06:00:58 --> URI Class Initialized
INFO - 2022-03-19 06:00:58 --> Router Class Initialized
INFO - 2022-03-19 06:00:59 --> Output Class Initialized
INFO - 2022-03-19 06:00:59 --> Security Class Initialized
INFO - 2022-03-19 06:00:59 --> Input Class Initialized
INFO - 2022-03-19 06:00:59 --> Language Class Initialized
INFO - 2022-03-19 06:00:59 --> Loader Class Initialized
INFO - 2022-03-19 06:00:59 --> Helper loaded: url_helper
INFO - 2022-03-19 06:00:59 --> Helper loaded: form_helper
INFO - 2022-03-19 06:00:59 --> Database Driver Class Initialized
INFO - 2022-03-19 06:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:00:59 --> Form Validation Class Initialized
INFO - 2022-03-19 06:00:59 --> Controller Class Initialized
INFO - 2022-03-19 06:00:59 --> Model "M_todo_group" initialized
INFO - 2022-03-19 06:00:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 06:00:59 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:00:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 06:00:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 06:00:59 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-19 06:00:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 06:00:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 06:00:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 06:00:59 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 06:00:59 --> Final output sent to browser
INFO - 2022-03-19 06:01:05 --> Config Class Initialized
INFO - 2022-03-19 06:01:05 --> Hooks Class Initialized
INFO - 2022-03-19 06:01:05 --> Utf8 Class Initialized
INFO - 2022-03-19 06:01:05 --> URI Class Initialized
INFO - 2022-03-19 06:01:05 --> Router Class Initialized
INFO - 2022-03-19 06:01:05 --> Output Class Initialized
INFO - 2022-03-19 06:01:05 --> Security Class Initialized
INFO - 2022-03-19 06:01:05 --> Input Class Initialized
INFO - 2022-03-19 06:01:05 --> Language Class Initialized
INFO - 2022-03-19 06:01:05 --> Loader Class Initialized
INFO - 2022-03-19 06:01:05 --> Helper loaded: url_helper
INFO - 2022-03-19 06:01:05 --> Helper loaded: form_helper
INFO - 2022-03-19 06:01:05 --> Database Driver Class Initialized
INFO - 2022-03-19 06:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:01:05 --> Form Validation Class Initialized
INFO - 2022-03-19 06:01:05 --> Controller Class Initialized
INFO - 2022-03-19 06:01:05 --> Model "M_todo_group" initialized
INFO - 2022-03-19 06:01:05 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 06:01:05 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:01:05 --> Config Class Initialized
INFO - 2022-03-19 06:01:05 --> Hooks Class Initialized
INFO - 2022-03-19 06:01:05 --> Utf8 Class Initialized
INFO - 2022-03-19 06:01:05 --> URI Class Initialized
INFO - 2022-03-19 06:01:05 --> Router Class Initialized
INFO - 2022-03-19 06:01:05 --> Output Class Initialized
INFO - 2022-03-19 06:01:05 --> Security Class Initialized
INFO - 2022-03-19 06:01:05 --> Input Class Initialized
INFO - 2022-03-19 06:01:05 --> Language Class Initialized
INFO - 2022-03-19 06:01:05 --> Loader Class Initialized
INFO - 2022-03-19 06:01:05 --> Helper loaded: url_helper
INFO - 2022-03-19 06:01:05 --> Helper loaded: form_helper
INFO - 2022-03-19 06:01:05 --> Database Driver Class Initialized
INFO - 2022-03-19 06:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:01:05 --> Form Validation Class Initialized
INFO - 2022-03-19 06:01:05 --> Controller Class Initialized
INFO - 2022-03-19 06:01:05 --> Model "M_todo_group" initialized
INFO - 2022-03-19 06:01:05 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-19 06:01:05 --> Model "M_tutor" initialized
INFO - 2022-03-19 06:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-19 06:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-19 06:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-19 06:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-19 06:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-19 06:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-19 06:01:05 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-19 06:01:05 --> Final output sent to browser
