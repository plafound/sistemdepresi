<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-01 14:44:35 --> Config Class Initialized
INFO - 2023-06-01 14:44:35 --> Hooks Class Initialized
INFO - 2023-06-01 14:44:35 --> Utf8 Class Initialized
INFO - 2023-06-01 14:44:35 --> URI Class Initialized
INFO - 2023-06-01 14:44:35 --> Router Class Initialized
INFO - 2023-06-01 14:44:35 --> Output Class Initialized
INFO - 2023-06-01 14:44:35 --> Security Class Initialized
INFO - 2023-06-01 14:44:35 --> Input Class Initialized
INFO - 2023-06-01 14:44:35 --> Language Class Initialized
INFO - 2023-06-01 14:44:35 --> Loader Class Initialized
INFO - 2023-06-01 14:44:35 --> Helper loaded: url_helper
INFO - 2023-06-01 14:44:35 --> Helper loaded: form_helper
INFO - 2023-06-01 14:44:35 --> Database Driver Class Initialized
INFO - 2023-06-01 14:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 14:44:35 --> Form Validation Class Initialized
INFO - 2023-06-01 14:44:35 --> Controller Class Initialized
INFO - 2023-06-01 14:44:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-01 14:44:35 --> Final output sent to browser
INFO - 2023-06-01 14:44:38 --> Config Class Initialized
INFO - 2023-06-01 14:44:38 --> Hooks Class Initialized
INFO - 2023-06-01 14:44:38 --> Utf8 Class Initialized
INFO - 2023-06-01 14:44:38 --> URI Class Initialized
INFO - 2023-06-01 14:44:38 --> Router Class Initialized
INFO - 2023-06-01 14:44:38 --> Output Class Initialized
INFO - 2023-06-01 14:44:38 --> Security Class Initialized
INFO - 2023-06-01 14:44:38 --> Input Class Initialized
INFO - 2023-06-01 14:44:38 --> Language Class Initialized
INFO - 2023-06-01 14:44:38 --> Loader Class Initialized
INFO - 2023-06-01 14:44:38 --> Helper loaded: url_helper
INFO - 2023-06-01 14:44:38 --> Helper loaded: form_helper
INFO - 2023-06-01 14:44:38 --> Database Driver Class Initialized
INFO - 2023-06-01 14:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 14:44:38 --> Form Validation Class Initialized
INFO - 2023-06-01 14:44:38 --> Controller Class Initialized
INFO - 2023-06-01 14:44:38 --> Model "m_user" initialized
INFO - 2023-06-01 14:44:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 14:44:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 14:44:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 14:44:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 14:44:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 14:44:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-01 14:44:38 --> Final output sent to browser
INFO - 2023-06-01 14:44:40 --> Config Class Initialized
INFO - 2023-06-01 14:44:40 --> Hooks Class Initialized
INFO - 2023-06-01 14:44:40 --> Utf8 Class Initialized
INFO - 2023-06-01 14:44:40 --> URI Class Initialized
INFO - 2023-06-01 14:44:40 --> Router Class Initialized
INFO - 2023-06-01 14:44:40 --> Output Class Initialized
INFO - 2023-06-01 14:44:40 --> Security Class Initialized
INFO - 2023-06-01 14:44:40 --> Input Class Initialized
INFO - 2023-06-01 14:44:40 --> Language Class Initialized
INFO - 2023-06-01 14:44:40 --> Loader Class Initialized
INFO - 2023-06-01 14:44:40 --> Helper loaded: url_helper
INFO - 2023-06-01 14:44:40 --> Helper loaded: form_helper
INFO - 2023-06-01 14:44:40 --> Database Driver Class Initialized
INFO - 2023-06-01 14:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 14:44:40 --> Form Validation Class Initialized
INFO - 2023-06-01 14:44:40 --> Controller Class Initialized
INFO - 2023-06-01 14:44:40 --> Model "m_datatrain" initialized
INFO - 2023-06-01 14:44:40 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 14:44:40 --> Model "m_datatest" initialized
INFO - 2023-06-01 14:44:40 --> Model "M_solusi" initialized
INFO - 2023-06-01 14:44:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 14:44:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 14:44:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-01 14:44:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 14:44:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 14:44:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 14:44:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 14:44:40 --> Final output sent to browser
INFO - 2023-06-01 14:44:44 --> Config Class Initialized
INFO - 2023-06-01 14:44:44 --> Hooks Class Initialized
INFO - 2023-06-01 14:44:44 --> Utf8 Class Initialized
INFO - 2023-06-01 14:44:44 --> URI Class Initialized
INFO - 2023-06-01 14:44:44 --> Router Class Initialized
INFO - 2023-06-01 14:44:44 --> Output Class Initialized
INFO - 2023-06-01 14:44:44 --> Security Class Initialized
INFO - 2023-06-01 14:44:44 --> Input Class Initialized
INFO - 2023-06-01 14:44:44 --> Language Class Initialized
INFO - 2023-06-01 14:44:44 --> Loader Class Initialized
INFO - 2023-06-01 14:44:44 --> Helper loaded: url_helper
INFO - 2023-06-01 14:44:44 --> Helper loaded: form_helper
INFO - 2023-06-01 14:44:44 --> Database Driver Class Initialized
INFO - 2023-06-01 14:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 14:44:44 --> Form Validation Class Initialized
INFO - 2023-06-01 14:44:44 --> Controller Class Initialized
INFO - 2023-06-01 14:44:44 --> Model "m_datatrain" initialized
INFO - 2023-06-01 14:44:44 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 14:44:44 --> Model "m_datatest" initialized
INFO - 2023-06-01 14:44:44 --> Model "M_solusi" initialized
INFO - 2023-06-01 14:44:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 14:44:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 14:44:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 14:44:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 14:44:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 14:44:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 14:44:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 14:44:44 --> Final output sent to browser
INFO - 2023-06-01 14:58:10 --> Config Class Initialized
INFO - 2023-06-01 14:58:10 --> Hooks Class Initialized
INFO - 2023-06-01 14:58:10 --> Utf8 Class Initialized
INFO - 2023-06-01 14:58:10 --> URI Class Initialized
INFO - 2023-06-01 14:58:10 --> Router Class Initialized
INFO - 2023-06-01 14:58:10 --> Output Class Initialized
INFO - 2023-06-01 14:58:10 --> Security Class Initialized
INFO - 2023-06-01 14:58:10 --> Input Class Initialized
INFO - 2023-06-01 14:58:10 --> Language Class Initialized
INFO - 2023-06-01 14:58:10 --> Loader Class Initialized
INFO - 2023-06-01 14:58:10 --> Helper loaded: url_helper
INFO - 2023-06-01 14:58:10 --> Helper loaded: form_helper
INFO - 2023-06-01 14:58:10 --> Database Driver Class Initialized
INFO - 2023-06-01 14:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 14:58:10 --> Form Validation Class Initialized
INFO - 2023-06-01 14:58:10 --> Controller Class Initialized
INFO - 2023-06-01 14:58:10 --> Model "m_datatrain" initialized
INFO - 2023-06-01 14:58:10 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 14:58:10 --> Model "m_datatest" initialized
INFO - 2023-06-01 14:58:10 --> Model "M_solusi" initialized
INFO - 2023-06-01 14:58:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 14:58:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 14:58:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 14:58:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 14:58:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 14:58:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 14:58:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 14:58:10 --> Final output sent to browser
INFO - 2023-06-01 14:58:59 --> Config Class Initialized
INFO - 2023-06-01 14:58:59 --> Hooks Class Initialized
INFO - 2023-06-01 14:58:59 --> Utf8 Class Initialized
INFO - 2023-06-01 14:58:59 --> URI Class Initialized
INFO - 2023-06-01 14:58:59 --> Router Class Initialized
INFO - 2023-06-01 14:58:59 --> Output Class Initialized
INFO - 2023-06-01 14:58:59 --> Security Class Initialized
INFO - 2023-06-01 14:58:59 --> Input Class Initialized
INFO - 2023-06-01 14:58:59 --> Language Class Initialized
INFO - 2023-06-01 14:58:59 --> Loader Class Initialized
INFO - 2023-06-01 14:58:59 --> Helper loaded: url_helper
INFO - 2023-06-01 14:58:59 --> Helper loaded: form_helper
INFO - 2023-06-01 14:58:59 --> Database Driver Class Initialized
INFO - 2023-06-01 14:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 14:58:59 --> Form Validation Class Initialized
INFO - 2023-06-01 14:58:59 --> Controller Class Initialized
INFO - 2023-06-01 14:58:59 --> Model "m_datatrain" initialized
INFO - 2023-06-01 14:58:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 14:58:59 --> Model "m_datatest" initialized
INFO - 2023-06-01 14:58:59 --> Model "M_solusi" initialized
INFO - 2023-06-01 14:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 14:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 14:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 14:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 14:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 14:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 14:58:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 14:58:59 --> Final output sent to browser
INFO - 2023-06-01 15:00:37 --> Config Class Initialized
INFO - 2023-06-01 15:00:37 --> Hooks Class Initialized
INFO - 2023-06-01 15:00:37 --> Utf8 Class Initialized
INFO - 2023-06-01 15:00:37 --> URI Class Initialized
INFO - 2023-06-01 15:00:37 --> Router Class Initialized
INFO - 2023-06-01 15:00:37 --> Output Class Initialized
INFO - 2023-06-01 15:00:37 --> Security Class Initialized
INFO - 2023-06-01 15:00:37 --> Input Class Initialized
INFO - 2023-06-01 15:00:37 --> Language Class Initialized
INFO - 2023-06-01 15:00:37 --> Loader Class Initialized
INFO - 2023-06-01 15:00:37 --> Helper loaded: url_helper
INFO - 2023-06-01 15:00:37 --> Helper loaded: form_helper
INFO - 2023-06-01 15:00:37 --> Database Driver Class Initialized
INFO - 2023-06-01 15:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:00:37 --> Form Validation Class Initialized
INFO - 2023-06-01 15:00:37 --> Controller Class Initialized
INFO - 2023-06-01 15:00:37 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:00:37 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:00:37 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:00:37 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:00:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:00:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:00:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 15:00:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:00:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:00:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:00:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:00:37 --> Final output sent to browser
INFO - 2023-06-01 15:01:36 --> Config Class Initialized
INFO - 2023-06-01 15:01:36 --> Hooks Class Initialized
INFO - 2023-06-01 15:01:36 --> Utf8 Class Initialized
INFO - 2023-06-01 15:01:36 --> URI Class Initialized
INFO - 2023-06-01 15:01:36 --> Router Class Initialized
INFO - 2023-06-01 15:01:36 --> Output Class Initialized
INFO - 2023-06-01 15:01:36 --> Security Class Initialized
INFO - 2023-06-01 15:01:36 --> Input Class Initialized
INFO - 2023-06-01 15:01:36 --> Language Class Initialized
INFO - 2023-06-01 15:01:36 --> Loader Class Initialized
INFO - 2023-06-01 15:01:36 --> Helper loaded: url_helper
INFO - 2023-06-01 15:01:36 --> Helper loaded: form_helper
INFO - 2023-06-01 15:01:36 --> Database Driver Class Initialized
INFO - 2023-06-01 15:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:01:36 --> Form Validation Class Initialized
INFO - 2023-06-01 15:01:36 --> Controller Class Initialized
INFO - 2023-06-01 15:01:36 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:01:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:01:36 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:01:36 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:01:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:01:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:01:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 15:01:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:01:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:01:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:01:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:01:36 --> Final output sent to browser
INFO - 2023-06-01 15:02:08 --> Config Class Initialized
INFO - 2023-06-01 15:02:08 --> Hooks Class Initialized
INFO - 2023-06-01 15:02:08 --> Utf8 Class Initialized
INFO - 2023-06-01 15:02:08 --> URI Class Initialized
INFO - 2023-06-01 15:02:08 --> Router Class Initialized
INFO - 2023-06-01 15:02:08 --> Output Class Initialized
INFO - 2023-06-01 15:02:08 --> Security Class Initialized
INFO - 2023-06-01 15:02:08 --> Input Class Initialized
INFO - 2023-06-01 15:02:08 --> Language Class Initialized
INFO - 2023-06-01 15:02:08 --> Loader Class Initialized
INFO - 2023-06-01 15:02:08 --> Helper loaded: url_helper
INFO - 2023-06-01 15:02:08 --> Helper loaded: form_helper
INFO - 2023-06-01 15:02:08 --> Database Driver Class Initialized
INFO - 2023-06-01 15:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:02:08 --> Form Validation Class Initialized
INFO - 2023-06-01 15:02:08 --> Controller Class Initialized
INFO - 2023-06-01 15:02:08 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:02:08 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:02:08 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:02:08 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:02:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:02:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:02:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 15:02:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:02:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:02:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:02:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:02:08 --> Final output sent to browser
INFO - 2023-06-01 15:02:31 --> Config Class Initialized
INFO - 2023-06-01 15:02:31 --> Hooks Class Initialized
INFO - 2023-06-01 15:02:31 --> Utf8 Class Initialized
INFO - 2023-06-01 15:02:31 --> URI Class Initialized
INFO - 2023-06-01 15:02:31 --> Router Class Initialized
INFO - 2023-06-01 15:02:31 --> Output Class Initialized
INFO - 2023-06-01 15:02:31 --> Security Class Initialized
INFO - 2023-06-01 15:02:31 --> Input Class Initialized
INFO - 2023-06-01 15:02:31 --> Language Class Initialized
INFO - 2023-06-01 15:02:31 --> Loader Class Initialized
INFO - 2023-06-01 15:02:31 --> Helper loaded: url_helper
INFO - 2023-06-01 15:02:31 --> Helper loaded: form_helper
INFO - 2023-06-01 15:02:31 --> Database Driver Class Initialized
INFO - 2023-06-01 15:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:02:31 --> Form Validation Class Initialized
INFO - 2023-06-01 15:02:31 --> Controller Class Initialized
INFO - 2023-06-01 15:02:31 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:02:31 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:02:31 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:02:31 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:02:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:02:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:02:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 15:02:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:02:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:02:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:02:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:02:31 --> Final output sent to browser
INFO - 2023-06-01 15:03:47 --> Config Class Initialized
INFO - 2023-06-01 15:03:47 --> Hooks Class Initialized
INFO - 2023-06-01 15:03:47 --> Utf8 Class Initialized
INFO - 2023-06-01 15:03:47 --> URI Class Initialized
INFO - 2023-06-01 15:03:47 --> Router Class Initialized
INFO - 2023-06-01 15:03:47 --> Output Class Initialized
INFO - 2023-06-01 15:03:47 --> Security Class Initialized
INFO - 2023-06-01 15:03:47 --> Input Class Initialized
INFO - 2023-06-01 15:03:47 --> Language Class Initialized
INFO - 2023-06-01 15:03:47 --> Loader Class Initialized
INFO - 2023-06-01 15:03:47 --> Helper loaded: url_helper
INFO - 2023-06-01 15:03:47 --> Helper loaded: form_helper
INFO - 2023-06-01 15:03:47 --> Database Driver Class Initialized
INFO - 2023-06-01 15:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:03:48 --> Form Validation Class Initialized
INFO - 2023-06-01 15:03:48 --> Controller Class Initialized
INFO - 2023-06-01 15:03:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-01 15:03:48 --> Final output sent to browser
INFO - 2023-06-01 15:03:49 --> Config Class Initialized
INFO - 2023-06-01 15:03:49 --> Hooks Class Initialized
INFO - 2023-06-01 15:03:49 --> Utf8 Class Initialized
INFO - 2023-06-01 15:03:49 --> URI Class Initialized
INFO - 2023-06-01 15:03:49 --> Router Class Initialized
INFO - 2023-06-01 15:03:49 --> Output Class Initialized
INFO - 2023-06-01 15:03:49 --> Security Class Initialized
INFO - 2023-06-01 15:03:49 --> Input Class Initialized
INFO - 2023-06-01 15:03:49 --> Language Class Initialized
INFO - 2023-06-01 15:03:49 --> Loader Class Initialized
INFO - 2023-06-01 15:03:49 --> Helper loaded: url_helper
INFO - 2023-06-01 15:03:49 --> Helper loaded: form_helper
INFO - 2023-06-01 15:03:49 --> Database Driver Class Initialized
INFO - 2023-06-01 15:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:03:49 --> Form Validation Class Initialized
INFO - 2023-06-01 15:03:49 --> Controller Class Initialized
INFO - 2023-06-01 15:03:49 --> Model "m_user" initialized
INFO - 2023-06-01 15:03:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-01 15:03:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-01 15:03:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-01 15:03:49 --> Final output sent to browser
INFO - 2023-06-01 15:03:55 --> Config Class Initialized
INFO - 2023-06-01 15:03:55 --> Hooks Class Initialized
INFO - 2023-06-01 15:03:56 --> Utf8 Class Initialized
INFO - 2023-06-01 15:03:56 --> URI Class Initialized
INFO - 2023-06-01 15:03:56 --> Router Class Initialized
INFO - 2023-06-01 15:03:56 --> Output Class Initialized
INFO - 2023-06-01 15:03:56 --> Security Class Initialized
INFO - 2023-06-01 15:03:56 --> Input Class Initialized
INFO - 2023-06-01 15:03:56 --> Language Class Initialized
INFO - 2023-06-01 15:03:56 --> Loader Class Initialized
INFO - 2023-06-01 15:03:56 --> Helper loaded: url_helper
INFO - 2023-06-01 15:03:56 --> Helper loaded: form_helper
INFO - 2023-06-01 15:03:56 --> Database Driver Class Initialized
INFO - 2023-06-01 15:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:03:56 --> Form Validation Class Initialized
INFO - 2023-06-01 15:03:56 --> Controller Class Initialized
INFO - 2023-06-01 15:03:56 --> Model "m_user" initialized
INFO - 2023-06-01 15:03:56 --> Config Class Initialized
INFO - 2023-06-01 15:03:56 --> Hooks Class Initialized
INFO - 2023-06-01 15:03:56 --> Utf8 Class Initialized
INFO - 2023-06-01 15:03:56 --> URI Class Initialized
INFO - 2023-06-01 15:03:56 --> Router Class Initialized
INFO - 2023-06-01 15:03:56 --> Output Class Initialized
INFO - 2023-06-01 15:03:56 --> Security Class Initialized
INFO - 2023-06-01 15:03:56 --> Input Class Initialized
INFO - 2023-06-01 15:03:56 --> Language Class Initialized
INFO - 2023-06-01 15:03:56 --> Loader Class Initialized
INFO - 2023-06-01 15:03:56 --> Helper loaded: url_helper
INFO - 2023-06-01 15:03:56 --> Helper loaded: form_helper
INFO - 2023-06-01 15:03:56 --> Database Driver Class Initialized
INFO - 2023-06-01 15:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:03:56 --> Form Validation Class Initialized
INFO - 2023-06-01 15:03:56 --> Controller Class Initialized
INFO - 2023-06-01 15:03:56 --> Model "m_user" initialized
INFO - 2023-06-01 15:03:56 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-01 15:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:03:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-01 15:03:56 --> Final output sent to browser
INFO - 2023-06-01 15:03:58 --> Config Class Initialized
INFO - 2023-06-01 15:03:58 --> Hooks Class Initialized
INFO - 2023-06-01 15:03:58 --> Utf8 Class Initialized
INFO - 2023-06-01 15:03:58 --> URI Class Initialized
INFO - 2023-06-01 15:03:58 --> Router Class Initialized
INFO - 2023-06-01 15:03:58 --> Output Class Initialized
INFO - 2023-06-01 15:03:58 --> Security Class Initialized
INFO - 2023-06-01 15:03:58 --> Input Class Initialized
INFO - 2023-06-01 15:03:58 --> Language Class Initialized
INFO - 2023-06-01 15:03:58 --> Loader Class Initialized
INFO - 2023-06-01 15:03:58 --> Helper loaded: url_helper
INFO - 2023-06-01 15:03:58 --> Helper loaded: form_helper
INFO - 2023-06-01 15:03:58 --> Database Driver Class Initialized
INFO - 2023-06-01 15:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:03:58 --> Form Validation Class Initialized
INFO - 2023-06-01 15:03:58 --> Controller Class Initialized
INFO - 2023-06-01 15:03:58 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:03:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:03:58 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:03:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:03:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:03:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-06-01 15:03:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-01 15:03:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:03:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:03:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-01 15:03:58 --> Final output sent to browser
INFO - 2023-06-01 15:08:21 --> Config Class Initialized
INFO - 2023-06-01 15:08:21 --> Hooks Class Initialized
INFO - 2023-06-01 15:08:21 --> Utf8 Class Initialized
INFO - 2023-06-01 15:08:21 --> URI Class Initialized
INFO - 2023-06-01 15:08:21 --> Router Class Initialized
INFO - 2023-06-01 15:08:21 --> Output Class Initialized
INFO - 2023-06-01 15:08:21 --> Security Class Initialized
INFO - 2023-06-01 15:08:21 --> Input Class Initialized
INFO - 2023-06-01 15:08:21 --> Language Class Initialized
INFO - 2023-06-01 15:08:21 --> Loader Class Initialized
INFO - 2023-06-01 15:08:21 --> Helper loaded: url_helper
INFO - 2023-06-01 15:08:21 --> Helper loaded: form_helper
INFO - 2023-06-01 15:08:21 --> Database Driver Class Initialized
INFO - 2023-06-01 15:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:08:21 --> Form Validation Class Initialized
INFO - 2023-06-01 15:08:21 --> Controller Class Initialized
INFO - 2023-06-01 15:08:21 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:08:21 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:08:21 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:08:21 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:08:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:08:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:08:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 15:08:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:08:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:08:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:08:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:08:21 --> Final output sent to browser
INFO - 2023-06-01 15:23:17 --> Config Class Initialized
INFO - 2023-06-01 15:23:17 --> Hooks Class Initialized
INFO - 2023-06-01 15:23:17 --> Utf8 Class Initialized
INFO - 2023-06-01 15:23:17 --> URI Class Initialized
INFO - 2023-06-01 15:23:17 --> Router Class Initialized
INFO - 2023-06-01 15:23:17 --> Output Class Initialized
INFO - 2023-06-01 15:23:17 --> Security Class Initialized
INFO - 2023-06-01 15:23:17 --> Input Class Initialized
INFO - 2023-06-01 15:23:17 --> Language Class Initialized
INFO - 2023-06-01 15:23:17 --> Loader Class Initialized
INFO - 2023-06-01 15:23:17 --> Helper loaded: url_helper
INFO - 2023-06-01 15:23:17 --> Helper loaded: form_helper
INFO - 2023-06-01 15:23:17 --> Database Driver Class Initialized
INFO - 2023-06-01 15:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:23:17 --> Form Validation Class Initialized
INFO - 2023-06-01 15:23:17 --> Controller Class Initialized
INFO - 2023-06-01 15:23:17 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:23:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:23:17 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:23:17 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:23:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:23:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:23:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-01 15:23:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:23:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:23:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:23:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:23:17 --> Final output sent to browser
INFO - 2023-06-01 15:23:58 --> Config Class Initialized
INFO - 2023-06-01 15:23:58 --> Hooks Class Initialized
INFO - 2023-06-01 15:23:58 --> Utf8 Class Initialized
INFO - 2023-06-01 15:23:58 --> URI Class Initialized
INFO - 2023-06-01 15:23:58 --> Router Class Initialized
INFO - 2023-06-01 15:23:58 --> Output Class Initialized
INFO - 2023-06-01 15:23:58 --> Security Class Initialized
INFO - 2023-06-01 15:23:58 --> Input Class Initialized
INFO - 2023-06-01 15:23:58 --> Language Class Initialized
INFO - 2023-06-01 15:23:58 --> Loader Class Initialized
INFO - 2023-06-01 15:23:58 --> Helper loaded: url_helper
INFO - 2023-06-01 15:23:58 --> Helper loaded: form_helper
INFO - 2023-06-01 15:23:58 --> Database Driver Class Initialized
INFO - 2023-06-01 15:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:23:59 --> Form Validation Class Initialized
INFO - 2023-06-01 15:23:59 --> Controller Class Initialized
INFO - 2023-06-01 15:23:59 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:23:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:23:59 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:23:59 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:23:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:23:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-01 15:23:59 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 46
INFO - 2023-06-01 15:24:48 --> Config Class Initialized
INFO - 2023-06-01 15:24:48 --> Hooks Class Initialized
INFO - 2023-06-01 15:24:48 --> Utf8 Class Initialized
INFO - 2023-06-01 15:24:48 --> URI Class Initialized
INFO - 2023-06-01 15:24:48 --> Router Class Initialized
INFO - 2023-06-01 15:24:48 --> Output Class Initialized
INFO - 2023-06-01 15:24:48 --> Security Class Initialized
INFO - 2023-06-01 15:24:48 --> Input Class Initialized
INFO - 2023-06-01 15:24:48 --> Language Class Initialized
INFO - 2023-06-01 15:24:48 --> Loader Class Initialized
INFO - 2023-06-01 15:24:48 --> Helper loaded: url_helper
INFO - 2023-06-01 15:24:48 --> Helper loaded: form_helper
INFO - 2023-06-01 15:24:48 --> Database Driver Class Initialized
INFO - 2023-06-01 15:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:24:48 --> Form Validation Class Initialized
INFO - 2023-06-01 15:24:48 --> Controller Class Initialized
INFO - 2023-06-01 15:24:48 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:24:48 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:24:48 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:24:48 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:24:48 --> Final output sent to browser
INFO - 2023-06-01 15:38:10 --> Config Class Initialized
INFO - 2023-06-01 15:38:10 --> Hooks Class Initialized
INFO - 2023-06-01 15:38:10 --> Utf8 Class Initialized
INFO - 2023-06-01 15:38:10 --> URI Class Initialized
INFO - 2023-06-01 15:38:10 --> Router Class Initialized
INFO - 2023-06-01 15:38:10 --> Output Class Initialized
INFO - 2023-06-01 15:38:10 --> Security Class Initialized
INFO - 2023-06-01 15:38:10 --> Input Class Initialized
INFO - 2023-06-01 15:38:10 --> Language Class Initialized
INFO - 2023-06-01 15:38:10 --> Loader Class Initialized
INFO - 2023-06-01 15:38:10 --> Helper loaded: url_helper
INFO - 2023-06-01 15:38:10 --> Helper loaded: form_helper
INFO - 2023-06-01 15:38:10 --> Database Driver Class Initialized
INFO - 2023-06-01 15:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:38:10 --> Form Validation Class Initialized
INFO - 2023-06-01 15:38:10 --> Controller Class Initialized
INFO - 2023-06-01 15:38:10 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:38:10 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:38:10 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:38:10 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:38:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:38:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-01 15:38:11 --> Severity: Parsing Error --> syntax error, unexpected '$prob_GangguanMood' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 23
INFO - 2023-06-01 15:38:58 --> Config Class Initialized
INFO - 2023-06-01 15:38:58 --> Hooks Class Initialized
INFO - 2023-06-01 15:38:58 --> Utf8 Class Initialized
INFO - 2023-06-01 15:38:58 --> URI Class Initialized
INFO - 2023-06-01 15:38:58 --> Router Class Initialized
INFO - 2023-06-01 15:38:58 --> Output Class Initialized
INFO - 2023-06-01 15:38:58 --> Security Class Initialized
INFO - 2023-06-01 15:38:58 --> Input Class Initialized
INFO - 2023-06-01 15:38:58 --> Language Class Initialized
INFO - 2023-06-01 15:38:58 --> Loader Class Initialized
INFO - 2023-06-01 15:38:58 --> Helper loaded: url_helper
INFO - 2023-06-01 15:38:58 --> Helper loaded: form_helper
INFO - 2023-06-01 15:38:58 --> Database Driver Class Initialized
INFO - 2023-06-01 15:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:38:58 --> Form Validation Class Initialized
INFO - 2023-06-01 15:38:58 --> Controller Class Initialized
INFO - 2023-06-01 15:38:58 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:38:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:38:58 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:38:58 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:38:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:38:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:38:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:38:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:38:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:38:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:38:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:38:58 --> Final output sent to browser
INFO - 2023-06-01 15:42:41 --> Config Class Initialized
INFO - 2023-06-01 15:42:41 --> Hooks Class Initialized
INFO - 2023-06-01 15:42:41 --> Utf8 Class Initialized
INFO - 2023-06-01 15:42:41 --> URI Class Initialized
INFO - 2023-06-01 15:42:41 --> Router Class Initialized
INFO - 2023-06-01 15:42:41 --> Output Class Initialized
INFO - 2023-06-01 15:42:41 --> Security Class Initialized
INFO - 2023-06-01 15:42:41 --> Input Class Initialized
INFO - 2023-06-01 15:42:41 --> Language Class Initialized
INFO - 2023-06-01 15:42:41 --> Loader Class Initialized
INFO - 2023-06-01 15:42:41 --> Helper loaded: url_helper
INFO - 2023-06-01 15:42:41 --> Helper loaded: form_helper
INFO - 2023-06-01 15:42:41 --> Database Driver Class Initialized
INFO - 2023-06-01 15:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:42:41 --> Form Validation Class Initialized
INFO - 2023-06-01 15:42:41 --> Controller Class Initialized
INFO - 2023-06-01 15:42:41 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:42:41 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:42:41 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:42:41 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:42:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:42:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:42:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:42:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:42:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:42:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:42:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:42:41 --> Final output sent to browser
INFO - 2023-06-01 15:43:01 --> Config Class Initialized
INFO - 2023-06-01 15:43:01 --> Hooks Class Initialized
INFO - 2023-06-01 15:43:01 --> Utf8 Class Initialized
INFO - 2023-06-01 15:43:01 --> URI Class Initialized
INFO - 2023-06-01 15:43:01 --> Router Class Initialized
INFO - 2023-06-01 15:43:01 --> Output Class Initialized
INFO - 2023-06-01 15:43:01 --> Security Class Initialized
INFO - 2023-06-01 15:43:01 --> Input Class Initialized
INFO - 2023-06-01 15:43:01 --> Language Class Initialized
INFO - 2023-06-01 15:43:01 --> Loader Class Initialized
INFO - 2023-06-01 15:43:01 --> Helper loaded: url_helper
INFO - 2023-06-01 15:43:01 --> Helper loaded: form_helper
INFO - 2023-06-01 15:43:01 --> Database Driver Class Initialized
INFO - 2023-06-01 15:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:43:01 --> Form Validation Class Initialized
INFO - 2023-06-01 15:43:01 --> Controller Class Initialized
INFO - 2023-06-01 15:43:01 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:43:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:43:01 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:43:01 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:43:01 --> Final output sent to browser
INFO - 2023-06-01 15:43:27 --> Config Class Initialized
INFO - 2023-06-01 15:43:27 --> Hooks Class Initialized
INFO - 2023-06-01 15:43:27 --> Utf8 Class Initialized
INFO - 2023-06-01 15:43:27 --> URI Class Initialized
INFO - 2023-06-01 15:43:27 --> Router Class Initialized
INFO - 2023-06-01 15:43:27 --> Output Class Initialized
INFO - 2023-06-01 15:43:27 --> Security Class Initialized
INFO - 2023-06-01 15:43:27 --> Input Class Initialized
INFO - 2023-06-01 15:43:27 --> Language Class Initialized
INFO - 2023-06-01 15:43:27 --> Loader Class Initialized
INFO - 2023-06-01 15:43:27 --> Helper loaded: url_helper
INFO - 2023-06-01 15:43:27 --> Helper loaded: form_helper
INFO - 2023-06-01 15:43:27 --> Database Driver Class Initialized
INFO - 2023-06-01 15:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:43:27 --> Form Validation Class Initialized
INFO - 2023-06-01 15:43:27 --> Controller Class Initialized
INFO - 2023-06-01 15:43:27 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:43:27 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:43:27 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:43:27 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:43:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:43:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:43:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:43:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:43:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:43:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:43:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:43:27 --> Final output sent to browser
INFO - 2023-06-01 15:45:36 --> Config Class Initialized
INFO - 2023-06-01 15:45:36 --> Hooks Class Initialized
INFO - 2023-06-01 15:45:36 --> Utf8 Class Initialized
INFO - 2023-06-01 15:45:36 --> URI Class Initialized
INFO - 2023-06-01 15:45:36 --> Router Class Initialized
INFO - 2023-06-01 15:45:36 --> Output Class Initialized
INFO - 2023-06-01 15:45:36 --> Security Class Initialized
INFO - 2023-06-01 15:45:36 --> Input Class Initialized
INFO - 2023-06-01 15:45:36 --> Language Class Initialized
INFO - 2023-06-01 15:45:36 --> Loader Class Initialized
INFO - 2023-06-01 15:45:36 --> Helper loaded: url_helper
INFO - 2023-06-01 15:45:36 --> Helper loaded: form_helper
INFO - 2023-06-01 15:45:36 --> Database Driver Class Initialized
INFO - 2023-06-01 15:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:45:36 --> Form Validation Class Initialized
INFO - 2023-06-01 15:45:36 --> Controller Class Initialized
INFO - 2023-06-01 15:45:36 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:45:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:45:36 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:45:36 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:45:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:45:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:45:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:45:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:45:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:45:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:45:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:45:36 --> Final output sent to browser
INFO - 2023-06-01 15:45:53 --> Config Class Initialized
INFO - 2023-06-01 15:45:53 --> Hooks Class Initialized
INFO - 2023-06-01 15:45:53 --> Utf8 Class Initialized
INFO - 2023-06-01 15:45:53 --> URI Class Initialized
INFO - 2023-06-01 15:45:53 --> Router Class Initialized
INFO - 2023-06-01 15:45:53 --> Output Class Initialized
INFO - 2023-06-01 15:45:53 --> Security Class Initialized
INFO - 2023-06-01 15:45:53 --> Input Class Initialized
INFO - 2023-06-01 15:45:53 --> Language Class Initialized
INFO - 2023-06-01 15:45:53 --> Loader Class Initialized
INFO - 2023-06-01 15:45:53 --> Helper loaded: url_helper
INFO - 2023-06-01 15:45:53 --> Helper loaded: form_helper
INFO - 2023-06-01 15:45:53 --> Database Driver Class Initialized
INFO - 2023-06-01 15:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:45:53 --> Form Validation Class Initialized
INFO - 2023-06-01 15:45:53 --> Controller Class Initialized
INFO - 2023-06-01 15:45:53 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:45:53 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:45:53 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:45:53 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:45:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:45:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:45:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:45:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:45:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:45:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:45:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:45:53 --> Final output sent to browser
INFO - 2023-06-01 15:55:04 --> Config Class Initialized
INFO - 2023-06-01 15:55:04 --> Hooks Class Initialized
INFO - 2023-06-01 15:55:05 --> Utf8 Class Initialized
INFO - 2023-06-01 15:55:05 --> URI Class Initialized
INFO - 2023-06-01 15:55:05 --> Router Class Initialized
INFO - 2023-06-01 15:55:05 --> Output Class Initialized
INFO - 2023-06-01 15:55:05 --> Security Class Initialized
INFO - 2023-06-01 15:55:05 --> Input Class Initialized
INFO - 2023-06-01 15:55:05 --> Language Class Initialized
INFO - 2023-06-01 15:55:05 --> Loader Class Initialized
INFO - 2023-06-01 15:55:05 --> Helper loaded: url_helper
INFO - 2023-06-01 15:55:05 --> Helper loaded: form_helper
INFO - 2023-06-01 15:55:05 --> Database Driver Class Initialized
INFO - 2023-06-01 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:55:05 --> Form Validation Class Initialized
INFO - 2023-06-01 15:55:05 --> Controller Class Initialized
INFO - 2023-06-01 15:55:05 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:55:05 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:55:05 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:55:05 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:55:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:55:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:55:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:55:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:55:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:55:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:55:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:55:05 --> Final output sent to browser
INFO - 2023-06-01 15:56:30 --> Config Class Initialized
INFO - 2023-06-01 15:56:30 --> Hooks Class Initialized
INFO - 2023-06-01 15:56:30 --> Utf8 Class Initialized
INFO - 2023-06-01 15:56:30 --> URI Class Initialized
INFO - 2023-06-01 15:56:30 --> Router Class Initialized
INFO - 2023-06-01 15:56:30 --> Output Class Initialized
INFO - 2023-06-01 15:56:30 --> Security Class Initialized
INFO - 2023-06-01 15:56:30 --> Input Class Initialized
INFO - 2023-06-01 15:56:30 --> Language Class Initialized
INFO - 2023-06-01 15:56:30 --> Loader Class Initialized
INFO - 2023-06-01 15:56:30 --> Helper loaded: url_helper
INFO - 2023-06-01 15:56:30 --> Helper loaded: form_helper
INFO - 2023-06-01 15:56:30 --> Database Driver Class Initialized
INFO - 2023-06-01 15:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:56:30 --> Form Validation Class Initialized
INFO - 2023-06-01 15:56:30 --> Controller Class Initialized
INFO - 2023-06-01 15:56:30 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:56:30 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:56:30 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:56:30 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:56:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:56:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:56:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:56:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:56:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:56:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:56:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:56:30 --> Final output sent to browser
INFO - 2023-06-01 15:57:02 --> Config Class Initialized
INFO - 2023-06-01 15:57:02 --> Hooks Class Initialized
INFO - 2023-06-01 15:57:02 --> Utf8 Class Initialized
INFO - 2023-06-01 15:57:02 --> URI Class Initialized
INFO - 2023-06-01 15:57:02 --> Router Class Initialized
INFO - 2023-06-01 15:57:02 --> Output Class Initialized
INFO - 2023-06-01 15:57:02 --> Security Class Initialized
INFO - 2023-06-01 15:57:02 --> Input Class Initialized
INFO - 2023-06-01 15:57:02 --> Language Class Initialized
INFO - 2023-06-01 15:57:02 --> Loader Class Initialized
INFO - 2023-06-01 15:57:02 --> Helper loaded: url_helper
INFO - 2023-06-01 15:57:02 --> Helper loaded: form_helper
INFO - 2023-06-01 15:57:02 --> Database Driver Class Initialized
INFO - 2023-06-01 15:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:57:03 --> Form Validation Class Initialized
INFO - 2023-06-01 15:57:03 --> Controller Class Initialized
INFO - 2023-06-01 15:57:03 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:57:03 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:57:03 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:57:03 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:57:03 --> Final output sent to browser
INFO - 2023-06-01 15:58:28 --> Config Class Initialized
INFO - 2023-06-01 15:58:28 --> Hooks Class Initialized
INFO - 2023-06-01 15:58:28 --> Utf8 Class Initialized
INFO - 2023-06-01 15:58:28 --> URI Class Initialized
INFO - 2023-06-01 15:58:28 --> Router Class Initialized
INFO - 2023-06-01 15:58:28 --> Output Class Initialized
INFO - 2023-06-01 15:58:28 --> Security Class Initialized
INFO - 2023-06-01 15:58:28 --> Input Class Initialized
INFO - 2023-06-01 15:58:28 --> Language Class Initialized
INFO - 2023-06-01 15:58:29 --> Loader Class Initialized
INFO - 2023-06-01 15:58:29 --> Helper loaded: url_helper
INFO - 2023-06-01 15:58:29 --> Helper loaded: form_helper
INFO - 2023-06-01 15:58:29 --> Database Driver Class Initialized
INFO - 2023-06-01 15:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:58:29 --> Form Validation Class Initialized
INFO - 2023-06-01 15:58:29 --> Controller Class Initialized
INFO - 2023-06-01 15:58:29 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:58:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:58:29 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:58:29 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:58:29 --> Final output sent to browser
INFO - 2023-06-01 15:59:13 --> Config Class Initialized
INFO - 2023-06-01 15:59:13 --> Hooks Class Initialized
INFO - 2023-06-01 15:59:13 --> Utf8 Class Initialized
INFO - 2023-06-01 15:59:13 --> URI Class Initialized
INFO - 2023-06-01 15:59:13 --> Router Class Initialized
INFO - 2023-06-01 15:59:13 --> Output Class Initialized
INFO - 2023-06-01 15:59:13 --> Security Class Initialized
INFO - 2023-06-01 15:59:13 --> Input Class Initialized
INFO - 2023-06-01 15:59:13 --> Language Class Initialized
INFO - 2023-06-01 15:59:13 --> Loader Class Initialized
INFO - 2023-06-01 15:59:13 --> Helper loaded: url_helper
INFO - 2023-06-01 15:59:13 --> Helper loaded: form_helper
INFO - 2023-06-01 15:59:13 --> Database Driver Class Initialized
INFO - 2023-06-01 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:59:13 --> Form Validation Class Initialized
INFO - 2023-06-01 15:59:13 --> Controller Class Initialized
INFO - 2023-06-01 15:59:13 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:59:13 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:59:13 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:59:13 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:59:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:59:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:59:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:59:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:59:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:59:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:59:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:59:13 --> Final output sent to browser
INFO - 2023-06-01 15:59:34 --> Config Class Initialized
INFO - 2023-06-01 15:59:34 --> Hooks Class Initialized
INFO - 2023-06-01 15:59:34 --> Utf8 Class Initialized
INFO - 2023-06-01 15:59:34 --> URI Class Initialized
INFO - 2023-06-01 15:59:34 --> Router Class Initialized
INFO - 2023-06-01 15:59:34 --> Output Class Initialized
INFO - 2023-06-01 15:59:34 --> Security Class Initialized
INFO - 2023-06-01 15:59:34 --> Input Class Initialized
INFO - 2023-06-01 15:59:34 --> Language Class Initialized
INFO - 2023-06-01 15:59:34 --> Loader Class Initialized
INFO - 2023-06-01 15:59:34 --> Helper loaded: url_helper
INFO - 2023-06-01 15:59:34 --> Helper loaded: form_helper
INFO - 2023-06-01 15:59:34 --> Database Driver Class Initialized
INFO - 2023-06-01 15:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 15:59:34 --> Form Validation Class Initialized
INFO - 2023-06-01 15:59:34 --> Controller Class Initialized
INFO - 2023-06-01 15:59:34 --> Model "m_datatrain" initialized
INFO - 2023-06-01 15:59:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 15:59:34 --> Model "m_datatest" initialized
INFO - 2023-06-01 15:59:34 --> Model "M_solusi" initialized
INFO - 2023-06-01 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 15:59:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 15:59:34 --> Final output sent to browser
INFO - 2023-06-01 16:00:21 --> Config Class Initialized
INFO - 2023-06-01 16:00:21 --> Hooks Class Initialized
INFO - 2023-06-01 16:00:21 --> Utf8 Class Initialized
INFO - 2023-06-01 16:00:21 --> URI Class Initialized
INFO - 2023-06-01 16:00:21 --> Router Class Initialized
INFO - 2023-06-01 16:00:21 --> Output Class Initialized
INFO - 2023-06-01 16:00:21 --> Security Class Initialized
INFO - 2023-06-01 16:00:21 --> Input Class Initialized
INFO - 2023-06-01 16:00:21 --> Language Class Initialized
INFO - 2023-06-01 16:00:21 --> Loader Class Initialized
INFO - 2023-06-01 16:00:21 --> Helper loaded: url_helper
INFO - 2023-06-01 16:00:21 --> Helper loaded: form_helper
INFO - 2023-06-01 16:00:21 --> Database Driver Class Initialized
INFO - 2023-06-01 16:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 16:00:21 --> Form Validation Class Initialized
INFO - 2023-06-01 16:00:21 --> Controller Class Initialized
INFO - 2023-06-01 16:00:21 --> Model "m_datatrain" initialized
INFO - 2023-06-01 16:00:21 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 16:00:21 --> Model "m_datatest" initialized
INFO - 2023-06-01 16:00:21 --> Model "M_solusi" initialized
INFO - 2023-06-01 16:00:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 16:00:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 16:00:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 16:00:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 16:00:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 16:00:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 16:00:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 16:00:21 --> Final output sent to browser
INFO - 2023-06-01 16:01:50 --> Config Class Initialized
INFO - 2023-06-01 16:01:50 --> Hooks Class Initialized
INFO - 2023-06-01 16:01:50 --> Utf8 Class Initialized
INFO - 2023-06-01 16:01:50 --> URI Class Initialized
INFO - 2023-06-01 16:01:50 --> Router Class Initialized
INFO - 2023-06-01 16:01:50 --> Output Class Initialized
INFO - 2023-06-01 16:01:50 --> Security Class Initialized
INFO - 2023-06-01 16:01:50 --> Input Class Initialized
INFO - 2023-06-01 16:01:50 --> Language Class Initialized
INFO - 2023-06-01 16:01:50 --> Loader Class Initialized
INFO - 2023-06-01 16:01:50 --> Helper loaded: url_helper
INFO - 2023-06-01 16:01:50 --> Helper loaded: form_helper
INFO - 2023-06-01 16:01:50 --> Database Driver Class Initialized
INFO - 2023-06-01 16:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 16:01:50 --> Form Validation Class Initialized
INFO - 2023-06-01 16:01:50 --> Controller Class Initialized
INFO - 2023-06-01 16:01:50 --> Model "m_datatrain" initialized
INFO - 2023-06-01 16:01:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 16:01:50 --> Model "m_datatest" initialized
INFO - 2023-06-01 16:01:50 --> Model "M_solusi" initialized
INFO - 2023-06-01 16:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 16:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 16:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 16:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 16:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 16:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 16:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 16:01:50 --> Final output sent to browser
INFO - 2023-06-01 16:02:09 --> Config Class Initialized
INFO - 2023-06-01 16:02:09 --> Hooks Class Initialized
INFO - 2023-06-01 16:02:09 --> Utf8 Class Initialized
INFO - 2023-06-01 16:02:09 --> URI Class Initialized
INFO - 2023-06-01 16:02:09 --> Router Class Initialized
INFO - 2023-06-01 16:02:09 --> Output Class Initialized
INFO - 2023-06-01 16:02:09 --> Security Class Initialized
INFO - 2023-06-01 16:02:09 --> Input Class Initialized
INFO - 2023-06-01 16:02:09 --> Language Class Initialized
INFO - 2023-06-01 16:02:09 --> Loader Class Initialized
INFO - 2023-06-01 16:02:09 --> Helper loaded: url_helper
INFO - 2023-06-01 16:02:09 --> Helper loaded: form_helper
INFO - 2023-06-01 16:02:09 --> Database Driver Class Initialized
INFO - 2023-06-01 16:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 16:02:09 --> Form Validation Class Initialized
INFO - 2023-06-01 16:02:09 --> Controller Class Initialized
INFO - 2023-06-01 16:02:09 --> Model "m_datatrain" initialized
INFO - 2023-06-01 16:02:09 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 16:02:09 --> Model "m_datatest" initialized
INFO - 2023-06-01 16:02:09 --> Model "M_solusi" initialized
INFO - 2023-06-01 16:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 16:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 16:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 16:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 16:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 16:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 16:02:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 16:02:09 --> Final output sent to browser
INFO - 2023-06-01 16:02:33 --> Config Class Initialized
INFO - 2023-06-01 16:02:33 --> Hooks Class Initialized
INFO - 2023-06-01 16:02:33 --> Utf8 Class Initialized
INFO - 2023-06-01 16:02:33 --> URI Class Initialized
INFO - 2023-06-01 16:02:33 --> Router Class Initialized
INFO - 2023-06-01 16:02:33 --> Output Class Initialized
INFO - 2023-06-01 16:02:33 --> Security Class Initialized
INFO - 2023-06-01 16:02:33 --> Input Class Initialized
INFO - 2023-06-01 16:02:33 --> Language Class Initialized
INFO - 2023-06-01 16:02:33 --> Loader Class Initialized
INFO - 2023-06-01 16:02:33 --> Helper loaded: url_helper
INFO - 2023-06-01 16:02:33 --> Helper loaded: form_helper
INFO - 2023-06-01 16:02:33 --> Database Driver Class Initialized
INFO - 2023-06-01 16:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 16:02:33 --> Form Validation Class Initialized
INFO - 2023-06-01 16:02:33 --> Controller Class Initialized
INFO - 2023-06-01 16:02:33 --> Model "m_datatrain" initialized
INFO - 2023-06-01 16:02:33 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 16:02:33 --> Model "m_datatest" initialized
INFO - 2023-06-01 16:02:33 --> Model "M_solusi" initialized
INFO - 2023-06-01 16:02:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 16:02:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 16:02:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 16:02:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 16:02:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 16:02:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 16:02:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 16:02:34 --> Final output sent to browser
INFO - 2023-06-01 16:17:32 --> Config Class Initialized
INFO - 2023-06-01 16:17:32 --> Hooks Class Initialized
INFO - 2023-06-01 16:17:32 --> Utf8 Class Initialized
INFO - 2023-06-01 16:17:32 --> URI Class Initialized
INFO - 2023-06-01 16:17:32 --> Router Class Initialized
INFO - 2023-06-01 16:17:32 --> Output Class Initialized
INFO - 2023-06-01 16:17:32 --> Security Class Initialized
INFO - 2023-06-01 16:17:32 --> Input Class Initialized
INFO - 2023-06-01 16:17:32 --> Language Class Initialized
INFO - 2023-06-01 16:17:32 --> Loader Class Initialized
INFO - 2023-06-01 16:17:32 --> Helper loaded: url_helper
INFO - 2023-06-01 16:17:32 --> Helper loaded: form_helper
INFO - 2023-06-01 16:17:32 --> Database Driver Class Initialized
INFO - 2023-06-01 16:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 16:17:32 --> Form Validation Class Initialized
INFO - 2023-06-01 16:17:32 --> Controller Class Initialized
INFO - 2023-06-01 16:17:32 --> Model "m_user" initialized
INFO - 2023-06-01 16:17:32 --> Config Class Initialized
INFO - 2023-06-01 16:17:32 --> Hooks Class Initialized
INFO - 2023-06-01 16:17:32 --> Utf8 Class Initialized
INFO - 2023-06-01 16:17:32 --> URI Class Initialized
INFO - 2023-06-01 16:17:32 --> Router Class Initialized
INFO - 2023-06-01 16:17:32 --> Output Class Initialized
INFO - 2023-06-01 16:17:32 --> Security Class Initialized
INFO - 2023-06-01 16:17:32 --> Input Class Initialized
INFO - 2023-06-01 16:17:32 --> Language Class Initialized
INFO - 2023-06-01 16:17:32 --> Loader Class Initialized
INFO - 2023-06-01 16:17:32 --> Helper loaded: url_helper
INFO - 2023-06-01 16:17:32 --> Helper loaded: form_helper
INFO - 2023-06-01 16:17:32 --> Database Driver Class Initialized
INFO - 2023-06-01 16:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 16:17:32 --> Form Validation Class Initialized
INFO - 2023-06-01 16:17:32 --> Controller Class Initialized
INFO - 2023-06-01 16:17:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-01 16:17:32 --> Final output sent to browser
INFO - 2023-06-01 16:17:34 --> Config Class Initialized
INFO - 2023-06-01 16:17:34 --> Hooks Class Initialized
INFO - 2023-06-01 16:17:34 --> Utf8 Class Initialized
INFO - 2023-06-01 16:17:34 --> URI Class Initialized
INFO - 2023-06-01 16:17:34 --> Router Class Initialized
INFO - 2023-06-01 16:17:34 --> Output Class Initialized
INFO - 2023-06-01 16:17:34 --> Security Class Initialized
INFO - 2023-06-01 16:17:34 --> Input Class Initialized
INFO - 2023-06-01 16:17:34 --> Language Class Initialized
INFO - 2023-06-01 16:17:34 --> Loader Class Initialized
INFO - 2023-06-01 16:17:34 --> Helper loaded: url_helper
INFO - 2023-06-01 16:17:34 --> Helper loaded: form_helper
INFO - 2023-06-01 16:17:34 --> Database Driver Class Initialized
INFO - 2023-06-01 16:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 16:17:34 --> Form Validation Class Initialized
INFO - 2023-06-01 16:17:34 --> Controller Class Initialized
INFO - 2023-06-01 16:17:34 --> Model "m_user" initialized
INFO - 2023-06-01 16:17:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-01 16:17:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-01 16:17:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-01 16:17:34 --> Final output sent to browser
INFO - 2023-06-01 16:17:37 --> Config Class Initialized
INFO - 2023-06-01 16:17:37 --> Hooks Class Initialized
INFO - 2023-06-01 16:17:37 --> Utf8 Class Initialized
INFO - 2023-06-01 16:17:37 --> URI Class Initialized
INFO - 2023-06-01 16:17:37 --> Router Class Initialized
INFO - 2023-06-01 16:17:37 --> Output Class Initialized
INFO - 2023-06-01 16:17:37 --> Security Class Initialized
INFO - 2023-06-01 16:17:37 --> Input Class Initialized
INFO - 2023-06-01 16:17:37 --> Language Class Initialized
INFO - 2023-06-01 16:17:37 --> Loader Class Initialized
INFO - 2023-06-01 16:17:37 --> Helper loaded: url_helper
INFO - 2023-06-01 16:17:37 --> Helper loaded: form_helper
INFO - 2023-06-01 16:17:37 --> Database Driver Class Initialized
INFO - 2023-06-01 16:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 16:17:37 --> Form Validation Class Initialized
INFO - 2023-06-01 16:17:37 --> Controller Class Initialized
INFO - 2023-06-01 16:17:37 --> Model "m_user" initialized
INFO - 2023-06-01 16:17:37 --> Config Class Initialized
INFO - 2023-06-01 16:17:37 --> Hooks Class Initialized
INFO - 2023-06-01 16:17:37 --> Utf8 Class Initialized
INFO - 2023-06-01 16:17:37 --> URI Class Initialized
INFO - 2023-06-01 16:17:37 --> Router Class Initialized
INFO - 2023-06-01 16:17:37 --> Output Class Initialized
INFO - 2023-06-01 16:17:37 --> Security Class Initialized
INFO - 2023-06-01 16:17:37 --> Input Class Initialized
INFO - 2023-06-01 16:17:37 --> Language Class Initialized
INFO - 2023-06-01 16:17:37 --> Loader Class Initialized
INFO - 2023-06-01 16:17:37 --> Helper loaded: url_helper
INFO - 2023-06-01 16:17:37 --> Helper loaded: form_helper
INFO - 2023-06-01 16:17:37 --> Database Driver Class Initialized
INFO - 2023-06-01 16:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 16:17:37 --> Form Validation Class Initialized
INFO - 2023-06-01 16:17:37 --> Controller Class Initialized
INFO - 2023-06-01 16:17:37 --> Model "m_user" initialized
INFO - 2023-06-01 16:17:37 --> Model "m_datatrain" initialized
INFO - 2023-06-01 16:17:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 16:17:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 16:17:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-01 16:17:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 16:17:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 16:17:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-01 16:17:37 --> Final output sent to browser
INFO - 2023-06-01 16:17:40 --> Config Class Initialized
INFO - 2023-06-01 16:17:40 --> Hooks Class Initialized
INFO - 2023-06-01 16:17:40 --> Utf8 Class Initialized
INFO - 2023-06-01 16:17:40 --> URI Class Initialized
INFO - 2023-06-01 16:17:40 --> Router Class Initialized
INFO - 2023-06-01 16:17:40 --> Output Class Initialized
INFO - 2023-06-01 16:17:40 --> Security Class Initialized
INFO - 2023-06-01 16:17:40 --> Input Class Initialized
INFO - 2023-06-01 16:17:40 --> Language Class Initialized
INFO - 2023-06-01 16:17:40 --> Loader Class Initialized
INFO - 2023-06-01 16:17:40 --> Helper loaded: url_helper
INFO - 2023-06-01 16:17:40 --> Helper loaded: form_helper
INFO - 2023-06-01 16:17:40 --> Database Driver Class Initialized
INFO - 2023-06-01 16:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 16:17:40 --> Form Validation Class Initialized
INFO - 2023-06-01 16:17:40 --> Controller Class Initialized
INFO - 2023-06-01 16:17:40 --> Model "m_datatrain" initialized
INFO - 2023-06-01 16:17:40 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 16:17:40 --> Model "m_datatest" initialized
INFO - 2023-06-01 16:17:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 16:17:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 16:17:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-06-01 16:17:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-01 16:17:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 16:17:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 16:17:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-01 16:17:40 --> Final output sent to browser
INFO - 2023-06-01 16:17:42 --> Config Class Initialized
INFO - 2023-06-01 16:17:42 --> Hooks Class Initialized
INFO - 2023-06-01 16:17:42 --> Utf8 Class Initialized
INFO - 2023-06-01 16:17:42 --> URI Class Initialized
INFO - 2023-06-01 16:17:42 --> Router Class Initialized
INFO - 2023-06-01 16:17:42 --> Output Class Initialized
INFO - 2023-06-01 16:17:42 --> Security Class Initialized
INFO - 2023-06-01 16:17:42 --> Input Class Initialized
INFO - 2023-06-01 16:17:42 --> Language Class Initialized
INFO - 2023-06-01 16:17:42 --> Loader Class Initialized
INFO - 2023-06-01 16:17:42 --> Helper loaded: url_helper
INFO - 2023-06-01 16:17:42 --> Helper loaded: form_helper
INFO - 2023-06-01 16:17:42 --> Database Driver Class Initialized
INFO - 2023-06-01 16:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 16:17:42 --> Form Validation Class Initialized
INFO - 2023-06-01 16:17:42 --> Controller Class Initialized
INFO - 2023-06-01 16:17:42 --> Model "m_datatest" initialized
INFO - 2023-06-01 16:17:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 16:17:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 16:17:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-01 16:17:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-01 16:17:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 16:17:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 16:17:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-01 16:17:42 --> Final output sent to browser
INFO - 2023-06-01 18:34:06 --> Config Class Initialized
INFO - 2023-06-01 18:34:06 --> Hooks Class Initialized
INFO - 2023-06-01 18:34:06 --> Utf8 Class Initialized
INFO - 2023-06-01 18:34:06 --> URI Class Initialized
INFO - 2023-06-01 18:34:06 --> Router Class Initialized
INFO - 2023-06-01 18:34:06 --> Output Class Initialized
INFO - 2023-06-01 18:34:06 --> Security Class Initialized
INFO - 2023-06-01 18:34:06 --> Input Class Initialized
INFO - 2023-06-01 18:34:06 --> Language Class Initialized
INFO - 2023-06-01 18:34:06 --> Loader Class Initialized
INFO - 2023-06-01 18:34:06 --> Helper loaded: url_helper
INFO - 2023-06-01 18:34:06 --> Helper loaded: form_helper
INFO - 2023-06-01 18:34:06 --> Database Driver Class Initialized
INFO - 2023-06-01 18:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:34:06 --> Form Validation Class Initialized
INFO - 2023-06-01 18:34:06 --> Controller Class Initialized
INFO - 2023-06-01 18:34:06 --> Model "m_user" initialized
INFO - 2023-06-01 18:34:06 --> Config Class Initialized
INFO - 2023-06-01 18:34:06 --> Hooks Class Initialized
INFO - 2023-06-01 18:34:06 --> Utf8 Class Initialized
INFO - 2023-06-01 18:34:06 --> URI Class Initialized
INFO - 2023-06-01 18:34:06 --> Router Class Initialized
INFO - 2023-06-01 18:34:06 --> Output Class Initialized
INFO - 2023-06-01 18:34:06 --> Security Class Initialized
INFO - 2023-06-01 18:34:06 --> Input Class Initialized
INFO - 2023-06-01 18:34:06 --> Language Class Initialized
INFO - 2023-06-01 18:34:06 --> Loader Class Initialized
INFO - 2023-06-01 18:34:06 --> Helper loaded: url_helper
INFO - 2023-06-01 18:34:06 --> Helper loaded: form_helper
INFO - 2023-06-01 18:34:07 --> Database Driver Class Initialized
INFO - 2023-06-01 18:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:34:07 --> Form Validation Class Initialized
INFO - 2023-06-01 18:34:07 --> Controller Class Initialized
INFO - 2023-06-01 18:34:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-01 18:34:07 --> Final output sent to browser
INFO - 2023-06-01 18:34:08 --> Config Class Initialized
INFO - 2023-06-01 18:34:08 --> Hooks Class Initialized
INFO - 2023-06-01 18:34:08 --> Utf8 Class Initialized
INFO - 2023-06-01 18:34:08 --> URI Class Initialized
INFO - 2023-06-01 18:34:08 --> Router Class Initialized
INFO - 2023-06-01 18:34:08 --> Output Class Initialized
INFO - 2023-06-01 18:34:08 --> Security Class Initialized
INFO - 2023-06-01 18:34:08 --> Input Class Initialized
INFO - 2023-06-01 18:34:08 --> Language Class Initialized
INFO - 2023-06-01 18:34:08 --> Loader Class Initialized
INFO - 2023-06-01 18:34:08 --> Helper loaded: url_helper
INFO - 2023-06-01 18:34:08 --> Helper loaded: form_helper
INFO - 2023-06-01 18:34:08 --> Database Driver Class Initialized
INFO - 2023-06-01 18:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:34:08 --> Form Validation Class Initialized
INFO - 2023-06-01 18:34:08 --> Controller Class Initialized
INFO - 2023-06-01 18:34:08 --> Model "m_user" initialized
INFO - 2023-06-01 18:34:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 18:34:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 18:34:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 18:34:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 18:34:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 18:34:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-01 18:34:08 --> Final output sent to browser
INFO - 2023-06-01 18:34:10 --> Config Class Initialized
INFO - 2023-06-01 18:34:10 --> Hooks Class Initialized
INFO - 2023-06-01 18:34:10 --> Utf8 Class Initialized
INFO - 2023-06-01 18:34:10 --> URI Class Initialized
INFO - 2023-06-01 18:34:10 --> Router Class Initialized
INFO - 2023-06-01 18:34:10 --> Output Class Initialized
INFO - 2023-06-01 18:34:10 --> Security Class Initialized
INFO - 2023-06-01 18:34:10 --> Input Class Initialized
INFO - 2023-06-01 18:34:10 --> Language Class Initialized
INFO - 2023-06-01 18:34:10 --> Loader Class Initialized
INFO - 2023-06-01 18:34:10 --> Helper loaded: url_helper
INFO - 2023-06-01 18:34:10 --> Helper loaded: form_helper
INFO - 2023-06-01 18:34:10 --> Database Driver Class Initialized
INFO - 2023-06-01 18:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:34:10 --> Form Validation Class Initialized
INFO - 2023-06-01 18:34:10 --> Controller Class Initialized
INFO - 2023-06-01 18:34:10 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:34:10 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:34:10 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:34:10 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:34:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 18:34:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 18:34:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-01 18:34:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 18:34:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 18:34:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 18:34:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 18:34:10 --> Final output sent to browser
INFO - 2023-06-01 18:34:14 --> Config Class Initialized
INFO - 2023-06-01 18:34:14 --> Hooks Class Initialized
INFO - 2023-06-01 18:34:14 --> Utf8 Class Initialized
INFO - 2023-06-01 18:34:14 --> URI Class Initialized
INFO - 2023-06-01 18:34:14 --> Router Class Initialized
INFO - 2023-06-01 18:34:14 --> Output Class Initialized
INFO - 2023-06-01 18:34:14 --> Security Class Initialized
INFO - 2023-06-01 18:34:14 --> Input Class Initialized
INFO - 2023-06-01 18:34:14 --> Language Class Initialized
INFO - 2023-06-01 18:34:14 --> Loader Class Initialized
INFO - 2023-06-01 18:34:14 --> Helper loaded: url_helper
INFO - 2023-06-01 18:34:14 --> Helper loaded: form_helper
INFO - 2023-06-01 18:34:14 --> Database Driver Class Initialized
INFO - 2023-06-01 18:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:34:14 --> Form Validation Class Initialized
INFO - 2023-06-01 18:34:14 --> Controller Class Initialized
INFO - 2023-06-01 18:34:14 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:34:14 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:34:14 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:34:14 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 18:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 18:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 18:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 18:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 18:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 18:34:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 18:34:14 --> Final output sent to browser
INFO - 2023-06-01 18:34:32 --> Config Class Initialized
INFO - 2023-06-01 18:34:32 --> Hooks Class Initialized
INFO - 2023-06-01 18:34:32 --> Utf8 Class Initialized
INFO - 2023-06-01 18:34:32 --> URI Class Initialized
INFO - 2023-06-01 18:34:32 --> Router Class Initialized
INFO - 2023-06-01 18:34:32 --> Output Class Initialized
INFO - 2023-06-01 18:34:32 --> Security Class Initialized
INFO - 2023-06-01 18:34:32 --> Input Class Initialized
INFO - 2023-06-01 18:34:32 --> Language Class Initialized
INFO - 2023-06-01 18:34:32 --> Loader Class Initialized
INFO - 2023-06-01 18:34:32 --> Helper loaded: url_helper
INFO - 2023-06-01 18:34:32 --> Helper loaded: form_helper
INFO - 2023-06-01 18:34:32 --> Database Driver Class Initialized
INFO - 2023-06-01 18:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:34:32 --> Form Validation Class Initialized
INFO - 2023-06-01 18:34:32 --> Controller Class Initialized
INFO - 2023-06-01 18:34:32 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:34:32 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:34:32 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:34:32 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:34:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 18:34:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 18:34:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 18:34:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 18:34:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 18:34:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 18:34:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 18:34:32 --> Final output sent to browser
INFO - 2023-06-01 18:34:33 --> Config Class Initialized
INFO - 2023-06-01 18:34:33 --> Hooks Class Initialized
INFO - 2023-06-01 18:34:33 --> Utf8 Class Initialized
INFO - 2023-06-01 18:34:33 --> URI Class Initialized
INFO - 2023-06-01 18:34:33 --> Router Class Initialized
INFO - 2023-06-01 18:34:33 --> Output Class Initialized
INFO - 2023-06-01 18:34:33 --> Security Class Initialized
INFO - 2023-06-01 18:34:33 --> Input Class Initialized
INFO - 2023-06-01 18:34:33 --> Language Class Initialized
INFO - 2023-06-01 18:34:33 --> Loader Class Initialized
INFO - 2023-06-01 18:34:33 --> Helper loaded: url_helper
INFO - 2023-06-01 18:34:33 --> Helper loaded: form_helper
INFO - 2023-06-01 18:34:33 --> Database Driver Class Initialized
INFO - 2023-06-01 18:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:34:33 --> Form Validation Class Initialized
INFO - 2023-06-01 18:34:33 --> Controller Class Initialized
INFO - 2023-06-01 18:34:33 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:34:33 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:34:33 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:34:33 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 18:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 18:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 18:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 18:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 18:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 18:34:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 18:34:33 --> Final output sent to browser
INFO - 2023-06-01 18:34:45 --> Config Class Initialized
INFO - 2023-06-01 18:34:45 --> Hooks Class Initialized
INFO - 2023-06-01 18:34:45 --> Utf8 Class Initialized
INFO - 2023-06-01 18:34:45 --> URI Class Initialized
INFO - 2023-06-01 18:34:45 --> Router Class Initialized
INFO - 2023-06-01 18:34:45 --> Output Class Initialized
INFO - 2023-06-01 18:34:45 --> Security Class Initialized
INFO - 2023-06-01 18:34:45 --> Input Class Initialized
INFO - 2023-06-01 18:34:45 --> Language Class Initialized
INFO - 2023-06-01 18:34:45 --> Loader Class Initialized
INFO - 2023-06-01 18:34:45 --> Helper loaded: url_helper
INFO - 2023-06-01 18:34:45 --> Helper loaded: form_helper
INFO - 2023-06-01 18:34:45 --> Database Driver Class Initialized
INFO - 2023-06-01 18:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:34:45 --> Form Validation Class Initialized
INFO - 2023-06-01 18:34:45 --> Controller Class Initialized
INFO - 2023-06-01 18:34:45 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:34:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:34:45 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:34:45 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:34:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 18:34:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 18:34:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-06-01 18:34:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 18:34:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 18:34:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 18:34:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 18:34:45 --> Final output sent to browser
INFO - 2023-06-01 18:40:04 --> Config Class Initialized
INFO - 2023-06-01 18:40:04 --> Hooks Class Initialized
INFO - 2023-06-01 18:40:04 --> Utf8 Class Initialized
INFO - 2023-06-01 18:40:04 --> URI Class Initialized
INFO - 2023-06-01 18:40:04 --> Router Class Initialized
INFO - 2023-06-01 18:40:04 --> Output Class Initialized
INFO - 2023-06-01 18:40:04 --> Security Class Initialized
INFO - 2023-06-01 18:40:04 --> Input Class Initialized
INFO - 2023-06-01 18:40:04 --> Language Class Initialized
INFO - 2023-06-01 18:40:04 --> Loader Class Initialized
INFO - 2023-06-01 18:40:04 --> Helper loaded: url_helper
INFO - 2023-06-01 18:40:04 --> Helper loaded: form_helper
INFO - 2023-06-01 18:40:04 --> Database Driver Class Initialized
INFO - 2023-06-01 18:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:40:04 --> Form Validation Class Initialized
INFO - 2023-06-01 18:40:04 --> Controller Class Initialized
INFO - 2023-06-01 18:40:04 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:40:04 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:40:04 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:40:04 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:40:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 18:40:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 18:40:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-01 18:40:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 18:40:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 18:40:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 18:40:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 18:40:04 --> Final output sent to browser
INFO - 2023-06-01 18:41:07 --> Config Class Initialized
INFO - 2023-06-01 18:41:07 --> Hooks Class Initialized
INFO - 2023-06-01 18:41:07 --> Utf8 Class Initialized
INFO - 2023-06-01 18:41:07 --> URI Class Initialized
INFO - 2023-06-01 18:41:07 --> Router Class Initialized
INFO - 2023-06-01 18:41:07 --> Output Class Initialized
INFO - 2023-06-01 18:41:07 --> Security Class Initialized
INFO - 2023-06-01 18:41:07 --> Input Class Initialized
INFO - 2023-06-01 18:41:07 --> Language Class Initialized
INFO - 2023-06-01 18:41:07 --> Loader Class Initialized
INFO - 2023-06-01 18:41:07 --> Helper loaded: url_helper
INFO - 2023-06-01 18:41:07 --> Helper loaded: form_helper
INFO - 2023-06-01 18:41:07 --> Database Driver Class Initialized
INFO - 2023-06-01 18:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:41:07 --> Form Validation Class Initialized
INFO - 2023-06-01 18:41:07 --> Controller Class Initialized
INFO - 2023-06-01 18:41:07 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:41:07 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:41:07 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:41:07 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 18:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 18:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 18:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 18:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 18:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 18:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 18:41:07 --> Final output sent to browser
INFO - 2023-06-01 18:42:04 --> Config Class Initialized
INFO - 2023-06-01 18:42:04 --> Hooks Class Initialized
INFO - 2023-06-01 18:42:04 --> Utf8 Class Initialized
INFO - 2023-06-01 18:42:04 --> URI Class Initialized
INFO - 2023-06-01 18:42:04 --> Router Class Initialized
INFO - 2023-06-01 18:42:04 --> Output Class Initialized
INFO - 2023-06-01 18:42:04 --> Security Class Initialized
INFO - 2023-06-01 18:42:04 --> Input Class Initialized
INFO - 2023-06-01 18:42:04 --> Language Class Initialized
INFO - 2023-06-01 18:42:04 --> Loader Class Initialized
INFO - 2023-06-01 18:42:04 --> Helper loaded: url_helper
INFO - 2023-06-01 18:42:04 --> Helper loaded: form_helper
INFO - 2023-06-01 18:42:04 --> Database Driver Class Initialized
INFO - 2023-06-01 18:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:42:04 --> Form Validation Class Initialized
INFO - 2023-06-01 18:42:04 --> Controller Class Initialized
INFO - 2023-06-01 18:42:04 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:42:04 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:42:04 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:42:04 --> Model "M_solusi" initialized
ERROR - 2023-06-01 18:42:04 --> Severity: Notice --> Undefined index: Ringan C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 877
INFO - 2023-06-01 18:42:04 --> Final output sent to browser
INFO - 2023-06-01 18:42:26 --> Config Class Initialized
INFO - 2023-06-01 18:42:26 --> Hooks Class Initialized
INFO - 2023-06-01 18:42:26 --> Utf8 Class Initialized
INFO - 2023-06-01 18:42:26 --> URI Class Initialized
INFO - 2023-06-01 18:42:26 --> Router Class Initialized
INFO - 2023-06-01 18:42:26 --> Output Class Initialized
INFO - 2023-06-01 18:42:26 --> Security Class Initialized
INFO - 2023-06-01 18:42:26 --> Input Class Initialized
INFO - 2023-06-01 18:42:26 --> Language Class Initialized
INFO - 2023-06-01 18:42:26 --> Loader Class Initialized
INFO - 2023-06-01 18:42:26 --> Helper loaded: url_helper
INFO - 2023-06-01 18:42:26 --> Helper loaded: form_helper
INFO - 2023-06-01 18:42:26 --> Database Driver Class Initialized
INFO - 2023-06-01 18:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:42:26 --> Form Validation Class Initialized
INFO - 2023-06-01 18:42:26 --> Controller Class Initialized
INFO - 2023-06-01 18:42:26 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:42:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:42:26 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:42:26 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:42:26 --> Final output sent to browser
INFO - 2023-06-01 18:43:01 --> Config Class Initialized
INFO - 2023-06-01 18:43:01 --> Hooks Class Initialized
INFO - 2023-06-01 18:43:01 --> Utf8 Class Initialized
INFO - 2023-06-01 18:43:01 --> URI Class Initialized
INFO - 2023-06-01 18:43:01 --> Router Class Initialized
INFO - 2023-06-01 18:43:01 --> Output Class Initialized
INFO - 2023-06-01 18:43:01 --> Security Class Initialized
INFO - 2023-06-01 18:43:01 --> Input Class Initialized
INFO - 2023-06-01 18:43:01 --> Language Class Initialized
INFO - 2023-06-01 18:43:01 --> Loader Class Initialized
INFO - 2023-06-01 18:43:01 --> Helper loaded: url_helper
INFO - 2023-06-01 18:43:01 --> Helper loaded: form_helper
INFO - 2023-06-01 18:43:01 --> Database Driver Class Initialized
INFO - 2023-06-01 18:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:43:01 --> Form Validation Class Initialized
INFO - 2023-06-01 18:43:01 --> Controller Class Initialized
INFO - 2023-06-01 18:43:01 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:43:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:43:01 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:43:01 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:43:01 --> Final output sent to browser
INFO - 2023-06-01 18:43:51 --> Config Class Initialized
INFO - 2023-06-01 18:43:51 --> Hooks Class Initialized
INFO - 2023-06-01 18:43:51 --> Utf8 Class Initialized
INFO - 2023-06-01 18:43:51 --> URI Class Initialized
INFO - 2023-06-01 18:43:51 --> Router Class Initialized
INFO - 2023-06-01 18:43:51 --> Output Class Initialized
INFO - 2023-06-01 18:43:51 --> Security Class Initialized
INFO - 2023-06-01 18:43:51 --> Input Class Initialized
INFO - 2023-06-01 18:43:51 --> Language Class Initialized
INFO - 2023-06-01 18:43:51 --> Loader Class Initialized
INFO - 2023-06-01 18:43:51 --> Helper loaded: url_helper
INFO - 2023-06-01 18:43:51 --> Helper loaded: form_helper
INFO - 2023-06-01 18:43:51 --> Database Driver Class Initialized
INFO - 2023-06-01 18:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:43:51 --> Form Validation Class Initialized
INFO - 2023-06-01 18:43:51 --> Controller Class Initialized
INFO - 2023-06-01 18:43:51 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:43:51 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:43:51 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:43:51 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:43:51 --> Final output sent to browser
INFO - 2023-06-01 18:44:22 --> Config Class Initialized
INFO - 2023-06-01 18:44:22 --> Hooks Class Initialized
INFO - 2023-06-01 18:44:22 --> Utf8 Class Initialized
INFO - 2023-06-01 18:44:22 --> URI Class Initialized
INFO - 2023-06-01 18:44:22 --> Router Class Initialized
INFO - 2023-06-01 18:44:22 --> Output Class Initialized
INFO - 2023-06-01 18:44:22 --> Security Class Initialized
INFO - 2023-06-01 18:44:22 --> Input Class Initialized
INFO - 2023-06-01 18:44:22 --> Language Class Initialized
INFO - 2023-06-01 18:44:22 --> Loader Class Initialized
INFO - 2023-06-01 18:44:22 --> Helper loaded: url_helper
INFO - 2023-06-01 18:44:22 --> Helper loaded: form_helper
INFO - 2023-06-01 18:44:22 --> Database Driver Class Initialized
INFO - 2023-06-01 18:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:44:22 --> Form Validation Class Initialized
INFO - 2023-06-01 18:44:22 --> Controller Class Initialized
INFO - 2023-06-01 18:44:22 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:44:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:44:22 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:44:22 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:44:22 --> Final output sent to browser
INFO - 2023-06-01 18:45:12 --> Config Class Initialized
INFO - 2023-06-01 18:45:12 --> Hooks Class Initialized
INFO - 2023-06-01 18:45:12 --> Utf8 Class Initialized
INFO - 2023-06-01 18:45:12 --> URI Class Initialized
INFO - 2023-06-01 18:45:12 --> Router Class Initialized
INFO - 2023-06-01 18:45:12 --> Output Class Initialized
INFO - 2023-06-01 18:45:12 --> Security Class Initialized
INFO - 2023-06-01 18:45:12 --> Input Class Initialized
INFO - 2023-06-01 18:45:12 --> Language Class Initialized
INFO - 2023-06-01 18:45:12 --> Loader Class Initialized
INFO - 2023-06-01 18:45:12 --> Helper loaded: url_helper
INFO - 2023-06-01 18:45:12 --> Helper loaded: form_helper
INFO - 2023-06-01 18:45:12 --> Database Driver Class Initialized
INFO - 2023-06-01 18:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:45:12 --> Form Validation Class Initialized
INFO - 2023-06-01 18:45:12 --> Controller Class Initialized
INFO - 2023-06-01 18:45:12 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:45:12 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:45:12 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:45:12 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:45:12 --> Final output sent to browser
INFO - 2023-06-01 18:45:50 --> Config Class Initialized
INFO - 2023-06-01 18:45:50 --> Hooks Class Initialized
INFO - 2023-06-01 18:45:50 --> Utf8 Class Initialized
INFO - 2023-06-01 18:45:50 --> URI Class Initialized
INFO - 2023-06-01 18:45:50 --> Router Class Initialized
INFO - 2023-06-01 18:45:50 --> Output Class Initialized
INFO - 2023-06-01 18:45:50 --> Security Class Initialized
INFO - 2023-06-01 18:45:50 --> Input Class Initialized
INFO - 2023-06-01 18:45:50 --> Language Class Initialized
INFO - 2023-06-01 18:45:50 --> Loader Class Initialized
INFO - 2023-06-01 18:45:50 --> Helper loaded: url_helper
INFO - 2023-06-01 18:45:50 --> Helper loaded: form_helper
INFO - 2023-06-01 18:45:50 --> Database Driver Class Initialized
INFO - 2023-06-01 18:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:45:50 --> Form Validation Class Initialized
INFO - 2023-06-01 18:45:50 --> Controller Class Initialized
INFO - 2023-06-01 18:45:50 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:45:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:45:50 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:45:50 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:45:50 --> Final output sent to browser
INFO - 2023-06-01 18:54:58 --> Config Class Initialized
INFO - 2023-06-01 18:54:58 --> Hooks Class Initialized
INFO - 2023-06-01 18:54:59 --> Utf8 Class Initialized
INFO - 2023-06-01 18:54:59 --> URI Class Initialized
INFO - 2023-06-01 18:54:59 --> Router Class Initialized
INFO - 2023-06-01 18:54:59 --> Output Class Initialized
INFO - 2023-06-01 18:54:59 --> Security Class Initialized
INFO - 2023-06-01 18:54:59 --> Input Class Initialized
INFO - 2023-06-01 18:54:59 --> Language Class Initialized
INFO - 2023-06-01 18:54:59 --> Loader Class Initialized
INFO - 2023-06-01 18:54:59 --> Helper loaded: url_helper
INFO - 2023-06-01 18:54:59 --> Helper loaded: form_helper
INFO - 2023-06-01 18:54:59 --> Database Driver Class Initialized
INFO - 2023-06-01 18:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:54:59 --> Form Validation Class Initialized
INFO - 2023-06-01 18:54:59 --> Controller Class Initialized
INFO - 2023-06-01 18:54:59 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:54:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:54:59 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:54:59 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:54:59 --> Final output sent to browser
INFO - 2023-06-01 18:55:12 --> Config Class Initialized
INFO - 2023-06-01 18:55:12 --> Hooks Class Initialized
INFO - 2023-06-01 18:55:12 --> Utf8 Class Initialized
INFO - 2023-06-01 18:55:12 --> URI Class Initialized
INFO - 2023-06-01 18:55:12 --> Router Class Initialized
INFO - 2023-06-01 18:55:12 --> Output Class Initialized
INFO - 2023-06-01 18:55:12 --> Security Class Initialized
INFO - 2023-06-01 18:55:12 --> Input Class Initialized
INFO - 2023-06-01 18:55:12 --> Language Class Initialized
INFO - 2023-06-01 18:55:12 --> Loader Class Initialized
INFO - 2023-06-01 18:55:12 --> Helper loaded: url_helper
INFO - 2023-06-01 18:55:12 --> Helper loaded: form_helper
INFO - 2023-06-01 18:55:12 --> Database Driver Class Initialized
INFO - 2023-06-01 18:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:55:12 --> Form Validation Class Initialized
INFO - 2023-06-01 18:55:12 --> Controller Class Initialized
INFO - 2023-06-01 18:55:12 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:55:12 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:55:12 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:55:12 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:55:12 --> Final output sent to browser
INFO - 2023-06-01 18:55:13 --> Config Class Initialized
INFO - 2023-06-01 18:55:13 --> Hooks Class Initialized
INFO - 2023-06-01 18:55:13 --> Utf8 Class Initialized
INFO - 2023-06-01 18:55:13 --> URI Class Initialized
INFO - 2023-06-01 18:55:13 --> Router Class Initialized
INFO - 2023-06-01 18:55:13 --> Output Class Initialized
INFO - 2023-06-01 18:55:13 --> Security Class Initialized
INFO - 2023-06-01 18:55:13 --> Input Class Initialized
INFO - 2023-06-01 18:55:13 --> Language Class Initialized
INFO - 2023-06-01 18:55:13 --> Loader Class Initialized
INFO - 2023-06-01 18:55:13 --> Helper loaded: url_helper
INFO - 2023-06-01 18:55:13 --> Helper loaded: form_helper
INFO - 2023-06-01 18:55:13 --> Database Driver Class Initialized
INFO - 2023-06-01 18:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:55:13 --> Form Validation Class Initialized
INFO - 2023-06-01 18:55:13 --> Controller Class Initialized
INFO - 2023-06-01 18:55:13 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:55:13 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:55:13 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:55:13 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:55:13 --> Final output sent to browser
INFO - 2023-06-01 18:55:25 --> Config Class Initialized
INFO - 2023-06-01 18:55:25 --> Hooks Class Initialized
INFO - 2023-06-01 18:55:25 --> Utf8 Class Initialized
INFO - 2023-06-01 18:55:25 --> URI Class Initialized
INFO - 2023-06-01 18:55:25 --> Router Class Initialized
INFO - 2023-06-01 18:55:25 --> Output Class Initialized
INFO - 2023-06-01 18:55:25 --> Security Class Initialized
INFO - 2023-06-01 18:55:25 --> Input Class Initialized
INFO - 2023-06-01 18:55:25 --> Language Class Initialized
INFO - 2023-06-01 18:55:25 --> Loader Class Initialized
INFO - 2023-06-01 18:55:25 --> Helper loaded: url_helper
INFO - 2023-06-01 18:55:25 --> Helper loaded: form_helper
INFO - 2023-06-01 18:55:25 --> Database Driver Class Initialized
INFO - 2023-06-01 18:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:55:25 --> Form Validation Class Initialized
INFO - 2023-06-01 18:55:25 --> Controller Class Initialized
INFO - 2023-06-01 18:55:25 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:55:25 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:55:25 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:55:25 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:55:25 --> Final output sent to browser
INFO - 2023-06-01 18:55:50 --> Config Class Initialized
INFO - 2023-06-01 18:55:50 --> Hooks Class Initialized
INFO - 2023-06-01 18:55:50 --> Utf8 Class Initialized
INFO - 2023-06-01 18:55:50 --> URI Class Initialized
INFO - 2023-06-01 18:55:50 --> Router Class Initialized
INFO - 2023-06-01 18:55:50 --> Output Class Initialized
INFO - 2023-06-01 18:55:50 --> Security Class Initialized
INFO - 2023-06-01 18:55:50 --> Input Class Initialized
INFO - 2023-06-01 18:55:50 --> Language Class Initialized
INFO - 2023-06-01 18:55:50 --> Loader Class Initialized
INFO - 2023-06-01 18:55:50 --> Helper loaded: url_helper
INFO - 2023-06-01 18:55:50 --> Helper loaded: form_helper
INFO - 2023-06-01 18:55:50 --> Database Driver Class Initialized
INFO - 2023-06-01 18:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:55:50 --> Form Validation Class Initialized
INFO - 2023-06-01 18:55:50 --> Controller Class Initialized
INFO - 2023-06-01 18:55:50 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:55:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:55:50 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:55:50 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:55:50 --> Final output sent to browser
INFO - 2023-06-01 18:56:02 --> Config Class Initialized
INFO - 2023-06-01 18:56:02 --> Hooks Class Initialized
INFO - 2023-06-01 18:56:02 --> Utf8 Class Initialized
INFO - 2023-06-01 18:56:02 --> URI Class Initialized
INFO - 2023-06-01 18:56:02 --> Router Class Initialized
INFO - 2023-06-01 18:56:02 --> Output Class Initialized
INFO - 2023-06-01 18:56:02 --> Security Class Initialized
INFO - 2023-06-01 18:56:02 --> Input Class Initialized
INFO - 2023-06-01 18:56:02 --> Language Class Initialized
INFO - 2023-06-01 18:56:02 --> Loader Class Initialized
INFO - 2023-06-01 18:56:02 --> Helper loaded: url_helper
INFO - 2023-06-01 18:56:02 --> Helper loaded: form_helper
INFO - 2023-06-01 18:56:02 --> Database Driver Class Initialized
INFO - 2023-06-01 18:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:56:02 --> Form Validation Class Initialized
INFO - 2023-06-01 18:56:02 --> Controller Class Initialized
INFO - 2023-06-01 18:56:02 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:56:02 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:56:02 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:56:02 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:56:02 --> Final output sent to browser
INFO - 2023-06-01 18:57:05 --> Config Class Initialized
INFO - 2023-06-01 18:57:05 --> Hooks Class Initialized
INFO - 2023-06-01 18:57:05 --> Utf8 Class Initialized
INFO - 2023-06-01 18:57:05 --> URI Class Initialized
INFO - 2023-06-01 18:57:05 --> Router Class Initialized
INFO - 2023-06-01 18:57:05 --> Output Class Initialized
INFO - 2023-06-01 18:57:05 --> Security Class Initialized
INFO - 2023-06-01 18:57:05 --> Input Class Initialized
INFO - 2023-06-01 18:57:05 --> Language Class Initialized
INFO - 2023-06-01 18:57:05 --> Loader Class Initialized
INFO - 2023-06-01 18:57:05 --> Helper loaded: url_helper
INFO - 2023-06-01 18:57:05 --> Helper loaded: form_helper
INFO - 2023-06-01 18:57:05 --> Database Driver Class Initialized
INFO - 2023-06-01 18:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 18:57:05 --> Form Validation Class Initialized
INFO - 2023-06-01 18:57:05 --> Controller Class Initialized
INFO - 2023-06-01 18:57:05 --> Model "m_datatrain" initialized
INFO - 2023-06-01 18:57:05 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 18:57:05 --> Model "m_datatest" initialized
INFO - 2023-06-01 18:57:05 --> Model "M_solusi" initialized
INFO - 2023-06-01 18:57:05 --> Final output sent to browser
INFO - 2023-06-01 19:01:49 --> Config Class Initialized
INFO - 2023-06-01 19:01:49 --> Hooks Class Initialized
INFO - 2023-06-01 19:01:49 --> Utf8 Class Initialized
INFO - 2023-06-01 19:01:49 --> URI Class Initialized
INFO - 2023-06-01 19:01:49 --> Router Class Initialized
INFO - 2023-06-01 19:01:49 --> Output Class Initialized
INFO - 2023-06-01 19:01:49 --> Security Class Initialized
INFO - 2023-06-01 19:01:49 --> Input Class Initialized
INFO - 2023-06-01 19:01:49 --> Language Class Initialized
INFO - 2023-06-01 19:01:49 --> Loader Class Initialized
INFO - 2023-06-01 19:01:49 --> Helper loaded: url_helper
INFO - 2023-06-01 19:01:49 --> Helper loaded: form_helper
INFO - 2023-06-01 19:01:49 --> Database Driver Class Initialized
INFO - 2023-06-01 19:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:01:49 --> Form Validation Class Initialized
INFO - 2023-06-01 19:01:49 --> Controller Class Initialized
INFO - 2023-06-01 19:01:49 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:01:49 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:01:49 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:01:49 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:01:49 --> Final output sent to browser
INFO - 2023-06-01 19:02:10 --> Config Class Initialized
INFO - 2023-06-01 19:02:10 --> Hooks Class Initialized
INFO - 2023-06-01 19:02:10 --> Utf8 Class Initialized
INFO - 2023-06-01 19:02:10 --> URI Class Initialized
INFO - 2023-06-01 19:02:10 --> Router Class Initialized
INFO - 2023-06-01 19:02:10 --> Output Class Initialized
INFO - 2023-06-01 19:02:10 --> Security Class Initialized
INFO - 2023-06-01 19:02:10 --> Input Class Initialized
INFO - 2023-06-01 19:02:10 --> Language Class Initialized
INFO - 2023-06-01 19:02:10 --> Loader Class Initialized
INFO - 2023-06-01 19:02:10 --> Helper loaded: url_helper
INFO - 2023-06-01 19:02:10 --> Helper loaded: form_helper
INFO - 2023-06-01 19:02:10 --> Database Driver Class Initialized
INFO - 2023-06-01 19:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:02:10 --> Form Validation Class Initialized
INFO - 2023-06-01 19:02:10 --> Controller Class Initialized
INFO - 2023-06-01 19:02:10 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:02:10 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:02:10 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:02:10 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:02:10 --> Final output sent to browser
INFO - 2023-06-01 19:02:37 --> Config Class Initialized
INFO - 2023-06-01 19:02:37 --> Hooks Class Initialized
INFO - 2023-06-01 19:02:37 --> Utf8 Class Initialized
INFO - 2023-06-01 19:02:37 --> URI Class Initialized
INFO - 2023-06-01 19:02:37 --> Router Class Initialized
INFO - 2023-06-01 19:02:37 --> Output Class Initialized
INFO - 2023-06-01 19:02:37 --> Security Class Initialized
INFO - 2023-06-01 19:02:37 --> Input Class Initialized
INFO - 2023-06-01 19:02:37 --> Language Class Initialized
INFO - 2023-06-01 19:02:37 --> Loader Class Initialized
INFO - 2023-06-01 19:02:37 --> Helper loaded: url_helper
INFO - 2023-06-01 19:02:37 --> Helper loaded: form_helper
INFO - 2023-06-01 19:02:37 --> Database Driver Class Initialized
INFO - 2023-06-01 19:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:02:37 --> Form Validation Class Initialized
INFO - 2023-06-01 19:02:37 --> Controller Class Initialized
INFO - 2023-06-01 19:02:37 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:02:37 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:02:37 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:02:37 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:02:37 --> Final output sent to browser
INFO - 2023-06-01 19:11:56 --> Config Class Initialized
INFO - 2023-06-01 19:11:56 --> Hooks Class Initialized
INFO - 2023-06-01 19:11:56 --> Utf8 Class Initialized
INFO - 2023-06-01 19:11:56 --> URI Class Initialized
INFO - 2023-06-01 19:11:56 --> Router Class Initialized
INFO - 2023-06-01 19:11:56 --> Output Class Initialized
INFO - 2023-06-01 19:11:56 --> Security Class Initialized
INFO - 2023-06-01 19:11:56 --> Input Class Initialized
INFO - 2023-06-01 19:11:56 --> Language Class Initialized
INFO - 2023-06-01 19:11:56 --> Loader Class Initialized
INFO - 2023-06-01 19:11:56 --> Helper loaded: url_helper
INFO - 2023-06-01 19:11:56 --> Helper loaded: form_helper
INFO - 2023-06-01 19:11:56 --> Database Driver Class Initialized
INFO - 2023-06-01 19:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:11:56 --> Form Validation Class Initialized
INFO - 2023-06-01 19:11:56 --> Controller Class Initialized
INFO - 2023-06-01 19:11:56 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:11:56 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:11:56 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:11:56 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:11:56 --> Final output sent to browser
INFO - 2023-06-01 19:13:26 --> Config Class Initialized
INFO - 2023-06-01 19:13:26 --> Hooks Class Initialized
INFO - 2023-06-01 19:13:26 --> Utf8 Class Initialized
INFO - 2023-06-01 19:13:26 --> URI Class Initialized
INFO - 2023-06-01 19:13:26 --> Router Class Initialized
INFO - 2023-06-01 19:13:26 --> Output Class Initialized
INFO - 2023-06-01 19:13:26 --> Security Class Initialized
INFO - 2023-06-01 19:13:26 --> Input Class Initialized
INFO - 2023-06-01 19:13:26 --> Language Class Initialized
INFO - 2023-06-01 19:13:26 --> Loader Class Initialized
INFO - 2023-06-01 19:13:26 --> Helper loaded: url_helper
INFO - 2023-06-01 19:13:26 --> Helper loaded: form_helper
INFO - 2023-06-01 19:13:26 --> Database Driver Class Initialized
INFO - 2023-06-01 19:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:13:26 --> Form Validation Class Initialized
INFO - 2023-06-01 19:13:26 --> Controller Class Initialized
INFO - 2023-06-01 19:13:26 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:13:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:13:26 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:13:26 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:13:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:13:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-01 19:13:26 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 23
INFO - 2023-06-01 19:13:53 --> Config Class Initialized
INFO - 2023-06-01 19:13:53 --> Hooks Class Initialized
INFO - 2023-06-01 19:13:53 --> Utf8 Class Initialized
INFO - 2023-06-01 19:13:53 --> URI Class Initialized
INFO - 2023-06-01 19:13:53 --> Router Class Initialized
INFO - 2023-06-01 19:13:53 --> Output Class Initialized
INFO - 2023-06-01 19:13:53 --> Security Class Initialized
INFO - 2023-06-01 19:13:53 --> Input Class Initialized
INFO - 2023-06-01 19:13:53 --> Language Class Initialized
INFO - 2023-06-01 19:13:53 --> Loader Class Initialized
INFO - 2023-06-01 19:13:53 --> Helper loaded: url_helper
INFO - 2023-06-01 19:13:53 --> Helper loaded: form_helper
INFO - 2023-06-01 19:13:53 --> Database Driver Class Initialized
INFO - 2023-06-01 19:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:13:53 --> Form Validation Class Initialized
INFO - 2023-06-01 19:13:53 --> Controller Class Initialized
INFO - 2023-06-01 19:13:53 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:13:53 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:13:53 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:13:53 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:13:53 --> Config Class Initialized
INFO - 2023-06-01 19:13:53 --> Hooks Class Initialized
INFO - 2023-06-01 19:13:53 --> Utf8 Class Initialized
INFO - 2023-06-01 19:13:53 --> URI Class Initialized
INFO - 2023-06-01 19:13:53 --> Router Class Initialized
INFO - 2023-06-01 19:13:53 --> Output Class Initialized
INFO - 2023-06-01 19:13:53 --> Security Class Initialized
INFO - 2023-06-01 19:13:53 --> Input Class Initialized
INFO - 2023-06-01 19:13:53 --> Language Class Initialized
INFO - 2023-06-01 19:13:53 --> Loader Class Initialized
INFO - 2023-06-01 19:13:53 --> Helper loaded: url_helper
INFO - 2023-06-01 19:13:53 --> Helper loaded: form_helper
INFO - 2023-06-01 19:13:53 --> Database Driver Class Initialized
INFO - 2023-06-01 19:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:13:53 --> Form Validation Class Initialized
INFO - 2023-06-01 19:13:53 --> Controller Class Initialized
INFO - 2023-06-01 19:13:53 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:13:53 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:13:53 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:13:53 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:13:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:13:53 --> Final output sent to browser
INFO - 2023-06-01 19:14:43 --> Config Class Initialized
INFO - 2023-06-01 19:14:43 --> Hooks Class Initialized
INFO - 2023-06-01 19:14:43 --> Utf8 Class Initialized
INFO - 2023-06-01 19:14:43 --> URI Class Initialized
INFO - 2023-06-01 19:14:43 --> Router Class Initialized
INFO - 2023-06-01 19:14:43 --> Output Class Initialized
INFO - 2023-06-01 19:14:43 --> Security Class Initialized
INFO - 2023-06-01 19:14:43 --> Input Class Initialized
INFO - 2023-06-01 19:14:43 --> Language Class Initialized
INFO - 2023-06-01 19:14:43 --> Loader Class Initialized
INFO - 2023-06-01 19:14:43 --> Helper loaded: url_helper
INFO - 2023-06-01 19:14:43 --> Helper loaded: form_helper
INFO - 2023-06-01 19:14:43 --> Database Driver Class Initialized
INFO - 2023-06-01 19:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:14:43 --> Form Validation Class Initialized
INFO - 2023-06-01 19:14:43 --> Controller Class Initialized
INFO - 2023-06-01 19:14:43 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:14:43 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:14:43 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:14:43 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:14:43 --> Config Class Initialized
INFO - 2023-06-01 19:14:43 --> Hooks Class Initialized
INFO - 2023-06-01 19:14:43 --> Utf8 Class Initialized
INFO - 2023-06-01 19:14:43 --> URI Class Initialized
INFO - 2023-06-01 19:14:43 --> Router Class Initialized
INFO - 2023-06-01 19:14:43 --> Output Class Initialized
INFO - 2023-06-01 19:14:43 --> Security Class Initialized
INFO - 2023-06-01 19:14:43 --> Input Class Initialized
INFO - 2023-06-01 19:14:43 --> Language Class Initialized
INFO - 2023-06-01 19:14:43 --> Loader Class Initialized
INFO - 2023-06-01 19:14:43 --> Helper loaded: url_helper
INFO - 2023-06-01 19:14:43 --> Helper loaded: form_helper
INFO - 2023-06-01 19:14:43 --> Database Driver Class Initialized
INFO - 2023-06-01 19:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:14:43 --> Form Validation Class Initialized
INFO - 2023-06-01 19:14:43 --> Controller Class Initialized
INFO - 2023-06-01 19:14:43 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:14:43 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:14:43 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:14:43 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:14:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:14:43 --> Final output sent to browser
INFO - 2023-06-01 19:15:23 --> Config Class Initialized
INFO - 2023-06-01 19:15:23 --> Hooks Class Initialized
INFO - 2023-06-01 19:15:23 --> Utf8 Class Initialized
INFO - 2023-06-01 19:15:23 --> URI Class Initialized
INFO - 2023-06-01 19:15:23 --> Router Class Initialized
INFO - 2023-06-01 19:15:23 --> Output Class Initialized
INFO - 2023-06-01 19:15:23 --> Security Class Initialized
INFO - 2023-06-01 19:15:23 --> Input Class Initialized
INFO - 2023-06-01 19:15:23 --> Language Class Initialized
INFO - 2023-06-01 19:15:23 --> Loader Class Initialized
INFO - 2023-06-01 19:15:23 --> Helper loaded: url_helper
INFO - 2023-06-01 19:15:23 --> Helper loaded: form_helper
INFO - 2023-06-01 19:15:23 --> Database Driver Class Initialized
INFO - 2023-06-01 19:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:15:23 --> Form Validation Class Initialized
INFO - 2023-06-01 19:15:23 --> Controller Class Initialized
INFO - 2023-06-01 19:15:23 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:15:23 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:15:23 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:15:23 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:15:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:15:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:15:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-01 19:15:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:15:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:15:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:15:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:15:23 --> Final output sent to browser
INFO - 2023-06-01 19:15:26 --> Config Class Initialized
INFO - 2023-06-01 19:15:26 --> Hooks Class Initialized
INFO - 2023-06-01 19:15:26 --> Utf8 Class Initialized
INFO - 2023-06-01 19:15:26 --> URI Class Initialized
INFO - 2023-06-01 19:15:26 --> Router Class Initialized
INFO - 2023-06-01 19:15:26 --> Output Class Initialized
INFO - 2023-06-01 19:15:26 --> Security Class Initialized
INFO - 2023-06-01 19:15:26 --> Input Class Initialized
INFO - 2023-06-01 19:15:26 --> Language Class Initialized
INFO - 2023-06-01 19:15:26 --> Loader Class Initialized
INFO - 2023-06-01 19:15:26 --> Helper loaded: url_helper
INFO - 2023-06-01 19:15:26 --> Helper loaded: form_helper
INFO - 2023-06-01 19:15:26 --> Database Driver Class Initialized
INFO - 2023-06-01 19:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:15:26 --> Form Validation Class Initialized
INFO - 2023-06-01 19:15:26 --> Controller Class Initialized
INFO - 2023-06-01 19:15:26 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:15:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:15:26 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:15:26 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:15:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:15:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:15:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 19:15:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:15:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:15:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:15:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:15:26 --> Final output sent to browser
INFO - 2023-06-01 19:16:11 --> Config Class Initialized
INFO - 2023-06-01 19:16:11 --> Hooks Class Initialized
INFO - 2023-06-01 19:16:11 --> Utf8 Class Initialized
INFO - 2023-06-01 19:16:11 --> URI Class Initialized
INFO - 2023-06-01 19:16:11 --> Router Class Initialized
INFO - 2023-06-01 19:16:11 --> Output Class Initialized
INFO - 2023-06-01 19:16:11 --> Security Class Initialized
INFO - 2023-06-01 19:16:11 --> Input Class Initialized
INFO - 2023-06-01 19:16:11 --> Language Class Initialized
INFO - 2023-06-01 19:16:11 --> Loader Class Initialized
INFO - 2023-06-01 19:16:11 --> Helper loaded: url_helper
INFO - 2023-06-01 19:16:11 --> Helper loaded: form_helper
INFO - 2023-06-01 19:16:11 --> Database Driver Class Initialized
INFO - 2023-06-01 19:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:16:11 --> Form Validation Class Initialized
INFO - 2023-06-01 19:16:11 --> Controller Class Initialized
INFO - 2023-06-01 19:16:11 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:16:11 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:16:11 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:16:11 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:16:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:16:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:16:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 19:16:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:16:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:16:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:16:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:16:12 --> Final output sent to browser
INFO - 2023-06-01 19:18:22 --> Config Class Initialized
INFO - 2023-06-01 19:18:22 --> Hooks Class Initialized
INFO - 2023-06-01 19:18:22 --> Utf8 Class Initialized
INFO - 2023-06-01 19:18:22 --> URI Class Initialized
INFO - 2023-06-01 19:18:22 --> Router Class Initialized
INFO - 2023-06-01 19:18:22 --> Output Class Initialized
INFO - 2023-06-01 19:18:22 --> Security Class Initialized
INFO - 2023-06-01 19:18:22 --> Input Class Initialized
INFO - 2023-06-01 19:18:22 --> Language Class Initialized
INFO - 2023-06-01 19:18:22 --> Loader Class Initialized
INFO - 2023-06-01 19:18:22 --> Helper loaded: url_helper
INFO - 2023-06-01 19:18:22 --> Helper loaded: form_helper
INFO - 2023-06-01 19:18:22 --> Database Driver Class Initialized
INFO - 2023-06-01 19:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:18:22 --> Form Validation Class Initialized
INFO - 2023-06-01 19:18:22 --> Controller Class Initialized
INFO - 2023-06-01 19:18:22 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:18:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:18:22 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:18:22 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:18:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:18:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:18:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 19:18:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:18:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:18:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:18:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:18:22 --> Final output sent to browser
INFO - 2023-06-01 19:24:49 --> Config Class Initialized
INFO - 2023-06-01 19:24:49 --> Hooks Class Initialized
INFO - 2023-06-01 19:24:49 --> Utf8 Class Initialized
INFO - 2023-06-01 19:24:49 --> URI Class Initialized
INFO - 2023-06-01 19:24:49 --> Router Class Initialized
INFO - 2023-06-01 19:24:49 --> Output Class Initialized
INFO - 2023-06-01 19:24:49 --> Security Class Initialized
INFO - 2023-06-01 19:24:49 --> Input Class Initialized
INFO - 2023-06-01 19:24:49 --> Language Class Initialized
INFO - 2023-06-01 19:24:49 --> Loader Class Initialized
INFO - 2023-06-01 19:24:49 --> Helper loaded: url_helper
INFO - 2023-06-01 19:24:49 --> Helper loaded: form_helper
INFO - 2023-06-01 19:24:49 --> Database Driver Class Initialized
INFO - 2023-06-01 19:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:24:49 --> Form Validation Class Initialized
INFO - 2023-06-01 19:24:49 --> Controller Class Initialized
INFO - 2023-06-01 19:24:49 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:24:49 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:24:49 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:24:49 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:24:49 --> Final output sent to browser
INFO - 2023-06-01 19:24:52 --> Config Class Initialized
INFO - 2023-06-01 19:24:52 --> Hooks Class Initialized
INFO - 2023-06-01 19:24:52 --> Utf8 Class Initialized
INFO - 2023-06-01 19:24:52 --> URI Class Initialized
INFO - 2023-06-01 19:24:52 --> Router Class Initialized
INFO - 2023-06-01 19:24:52 --> Output Class Initialized
INFO - 2023-06-01 19:24:52 --> Security Class Initialized
INFO - 2023-06-01 19:24:52 --> Input Class Initialized
INFO - 2023-06-01 19:24:52 --> Language Class Initialized
INFO - 2023-06-01 19:24:52 --> Loader Class Initialized
INFO - 2023-06-01 19:24:52 --> Helper loaded: url_helper
INFO - 2023-06-01 19:24:52 --> Helper loaded: form_helper
INFO - 2023-06-01 19:24:52 --> Database Driver Class Initialized
INFO - 2023-06-01 19:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:24:52 --> Form Validation Class Initialized
INFO - 2023-06-01 19:24:52 --> Controller Class Initialized
INFO - 2023-06-01 19:24:52 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:24:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:24:52 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:24:52 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 19:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:24:52 --> Final output sent to browser
INFO - 2023-06-01 19:26:46 --> Config Class Initialized
INFO - 2023-06-01 19:26:46 --> Hooks Class Initialized
INFO - 2023-06-01 19:26:47 --> Utf8 Class Initialized
INFO - 2023-06-01 19:26:47 --> URI Class Initialized
INFO - 2023-06-01 19:26:47 --> Router Class Initialized
INFO - 2023-06-01 19:26:47 --> Output Class Initialized
INFO - 2023-06-01 19:26:47 --> Security Class Initialized
INFO - 2023-06-01 19:26:47 --> Input Class Initialized
INFO - 2023-06-01 19:26:47 --> Language Class Initialized
INFO - 2023-06-01 19:26:47 --> Loader Class Initialized
INFO - 2023-06-01 19:26:47 --> Helper loaded: url_helper
INFO - 2023-06-01 19:26:47 --> Helper loaded: form_helper
INFO - 2023-06-01 19:26:47 --> Database Driver Class Initialized
INFO - 2023-06-01 19:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:26:47 --> Form Validation Class Initialized
INFO - 2023-06-01 19:26:47 --> Controller Class Initialized
INFO - 2023-06-01 19:26:47 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:26:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:26:47 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:26:47 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:26:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:26:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:26:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 19:26:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:26:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:26:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:26:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:26:47 --> Final output sent to browser
INFO - 2023-06-01 19:31:26 --> Config Class Initialized
INFO - 2023-06-01 19:31:26 --> Hooks Class Initialized
INFO - 2023-06-01 19:31:26 --> Utf8 Class Initialized
INFO - 2023-06-01 19:31:26 --> URI Class Initialized
INFO - 2023-06-01 19:31:26 --> Router Class Initialized
INFO - 2023-06-01 19:31:26 --> Output Class Initialized
INFO - 2023-06-01 19:31:26 --> Security Class Initialized
INFO - 2023-06-01 19:31:26 --> Input Class Initialized
INFO - 2023-06-01 19:31:26 --> Language Class Initialized
INFO - 2023-06-01 19:31:26 --> Loader Class Initialized
INFO - 2023-06-01 19:31:26 --> Helper loaded: url_helper
INFO - 2023-06-01 19:31:26 --> Helper loaded: form_helper
INFO - 2023-06-01 19:31:26 --> Database Driver Class Initialized
INFO - 2023-06-01 19:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:31:26 --> Form Validation Class Initialized
INFO - 2023-06-01 19:31:26 --> Controller Class Initialized
INFO - 2023-06-01 19:31:26 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:31:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:31:26 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:31:26 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:31:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:31:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:31:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 19:31:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:31:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:31:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:31:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:31:27 --> Final output sent to browser
INFO - 2023-06-01 19:33:55 --> Config Class Initialized
INFO - 2023-06-01 19:33:55 --> Hooks Class Initialized
INFO - 2023-06-01 19:33:55 --> Utf8 Class Initialized
INFO - 2023-06-01 19:33:55 --> URI Class Initialized
INFO - 2023-06-01 19:33:55 --> Router Class Initialized
INFO - 2023-06-01 19:33:55 --> Output Class Initialized
INFO - 2023-06-01 19:33:55 --> Security Class Initialized
INFO - 2023-06-01 19:33:55 --> Input Class Initialized
INFO - 2023-06-01 19:33:55 --> Language Class Initialized
INFO - 2023-06-01 19:33:55 --> Loader Class Initialized
INFO - 2023-06-01 19:33:55 --> Helper loaded: url_helper
INFO - 2023-06-01 19:33:55 --> Helper loaded: form_helper
INFO - 2023-06-01 19:33:55 --> Database Driver Class Initialized
INFO - 2023-06-01 19:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-01 19:33:55 --> Form Validation Class Initialized
INFO - 2023-06-01 19:33:55 --> Controller Class Initialized
INFO - 2023-06-01 19:33:55 --> Model "m_datatrain" initialized
INFO - 2023-06-01 19:33:55 --> Model "m_penghitungan" initialized
INFO - 2023-06-01 19:33:55 --> Model "m_datatest" initialized
INFO - 2023-06-01 19:33:55 --> Model "M_solusi" initialized
INFO - 2023-06-01 19:33:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-01 19:33:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-01 19:33:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-01 19:33:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-01 19:33:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-01 19:33:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-01 19:33:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-01 19:33:55 --> Final output sent to browser
