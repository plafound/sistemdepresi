<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-15 06:58:51 --> Config Class Initialized
INFO - 2023-05-15 06:58:51 --> Hooks Class Initialized
INFO - 2023-05-15 06:58:51 --> Utf8 Class Initialized
INFO - 2023-05-15 06:58:51 --> URI Class Initialized
INFO - 2023-05-15 06:58:51 --> Router Class Initialized
INFO - 2023-05-15 06:58:51 --> Output Class Initialized
INFO - 2023-05-15 06:58:51 --> Security Class Initialized
INFO - 2023-05-15 06:58:51 --> Input Class Initialized
INFO - 2023-05-15 06:58:51 --> Language Class Initialized
INFO - 2023-05-15 06:58:51 --> Loader Class Initialized
INFO - 2023-05-15 06:58:51 --> Helper loaded: url_helper
INFO - 2023-05-15 06:58:51 --> Helper loaded: form_helper
INFO - 2023-05-15 06:58:51 --> Database Driver Class Initialized
INFO - 2023-05-15 06:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 06:58:51 --> Form Validation Class Initialized
INFO - 2023-05-15 06:58:51 --> Controller Class Initialized
INFO - 2023-05-15 06:58:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-15 06:58:51 --> Final output sent to browser
INFO - 2023-05-15 06:58:53 --> Config Class Initialized
INFO - 2023-05-15 06:58:53 --> Hooks Class Initialized
INFO - 2023-05-15 06:58:53 --> Utf8 Class Initialized
INFO - 2023-05-15 06:58:53 --> URI Class Initialized
INFO - 2023-05-15 06:58:53 --> Router Class Initialized
INFO - 2023-05-15 06:58:53 --> Output Class Initialized
INFO - 2023-05-15 06:58:53 --> Security Class Initialized
INFO - 2023-05-15 06:58:53 --> Input Class Initialized
INFO - 2023-05-15 06:58:53 --> Language Class Initialized
INFO - 2023-05-15 06:58:53 --> Loader Class Initialized
INFO - 2023-05-15 06:58:53 --> Helper loaded: url_helper
INFO - 2023-05-15 06:58:53 --> Helper loaded: form_helper
INFO - 2023-05-15 06:58:53 --> Database Driver Class Initialized
INFO - 2023-05-15 06:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 06:58:53 --> Form Validation Class Initialized
INFO - 2023-05-15 06:58:53 --> Controller Class Initialized
INFO - 2023-05-15 06:58:53 --> Model "m_user" initialized
INFO - 2023-05-15 06:58:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 06:58:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 06:58:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 06:58:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 06:58:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 06:58:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-15 06:58:53 --> Final output sent to browser
INFO - 2023-05-15 06:59:01 --> Config Class Initialized
INFO - 2023-05-15 06:59:01 --> Hooks Class Initialized
INFO - 2023-05-15 06:59:01 --> Utf8 Class Initialized
INFO - 2023-05-15 06:59:01 --> URI Class Initialized
INFO - 2023-05-15 06:59:01 --> Router Class Initialized
INFO - 2023-05-15 06:59:01 --> Output Class Initialized
INFO - 2023-05-15 06:59:01 --> Security Class Initialized
INFO - 2023-05-15 06:59:01 --> Input Class Initialized
INFO - 2023-05-15 06:59:01 --> Language Class Initialized
INFO - 2023-05-15 06:59:01 --> Loader Class Initialized
INFO - 2023-05-15 06:59:01 --> Helper loaded: url_helper
INFO - 2023-05-15 06:59:01 --> Helper loaded: form_helper
INFO - 2023-05-15 06:59:01 --> Database Driver Class Initialized
INFO - 2023-05-15 06:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 06:59:01 --> Form Validation Class Initialized
INFO - 2023-05-15 06:59:01 --> Controller Class Initialized
INFO - 2023-05-15 06:59:01 --> Model "m_user" initialized
INFO - 2023-05-15 06:59:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 06:59:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 06:59:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 06:59:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 06:59:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 06:59:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-15 06:59:01 --> Final output sent to browser
INFO - 2023-05-15 06:59:04 --> Config Class Initialized
INFO - 2023-05-15 06:59:04 --> Hooks Class Initialized
INFO - 2023-05-15 06:59:04 --> Utf8 Class Initialized
INFO - 2023-05-15 06:59:04 --> URI Class Initialized
INFO - 2023-05-15 06:59:04 --> Router Class Initialized
INFO - 2023-05-15 06:59:04 --> Output Class Initialized
INFO - 2023-05-15 06:59:04 --> Security Class Initialized
INFO - 2023-05-15 06:59:04 --> Input Class Initialized
INFO - 2023-05-15 06:59:04 --> Language Class Initialized
INFO - 2023-05-15 06:59:04 --> Loader Class Initialized
INFO - 2023-05-15 06:59:04 --> Helper loaded: url_helper
INFO - 2023-05-15 06:59:05 --> Helper loaded: form_helper
INFO - 2023-05-15 06:59:05 --> Database Driver Class Initialized
INFO - 2023-05-15 06:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 06:59:05 --> Form Validation Class Initialized
INFO - 2023-05-15 06:59:05 --> Controller Class Initialized
INFO - 2023-05-15 06:59:05 --> Model "m_user" initialized
INFO - 2023-05-15 06:59:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 06:59:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 06:59:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 06:59:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 06:59:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 06:59:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-15 06:59:05 --> Final output sent to browser
INFO - 2023-05-15 06:59:07 --> Config Class Initialized
INFO - 2023-05-15 06:59:07 --> Hooks Class Initialized
INFO - 2023-05-15 06:59:07 --> Utf8 Class Initialized
INFO - 2023-05-15 06:59:07 --> URI Class Initialized
INFO - 2023-05-15 06:59:07 --> Router Class Initialized
INFO - 2023-05-15 06:59:07 --> Output Class Initialized
INFO - 2023-05-15 06:59:07 --> Security Class Initialized
INFO - 2023-05-15 06:59:07 --> Input Class Initialized
INFO - 2023-05-15 06:59:07 --> Language Class Initialized
INFO - 2023-05-15 06:59:07 --> Loader Class Initialized
INFO - 2023-05-15 06:59:07 --> Helper loaded: url_helper
INFO - 2023-05-15 06:59:07 --> Helper loaded: form_helper
INFO - 2023-05-15 06:59:07 --> Database Driver Class Initialized
INFO - 2023-05-15 06:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 06:59:08 --> Form Validation Class Initialized
INFO - 2023-05-15 06:59:08 --> Controller Class Initialized
INFO - 2023-05-15 06:59:08 --> Model "m_user" initialized
INFO - 2023-05-15 06:59:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 06:59:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 06:59:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 06:59:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 06:59:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 06:59:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-15 06:59:08 --> Final output sent to browser
INFO - 2023-05-15 06:59:09 --> Config Class Initialized
INFO - 2023-05-15 06:59:09 --> Hooks Class Initialized
INFO - 2023-05-15 06:59:09 --> Utf8 Class Initialized
INFO - 2023-05-15 06:59:09 --> URI Class Initialized
INFO - 2023-05-15 06:59:09 --> Router Class Initialized
INFO - 2023-05-15 06:59:09 --> Output Class Initialized
INFO - 2023-05-15 06:59:09 --> Security Class Initialized
INFO - 2023-05-15 06:59:09 --> Input Class Initialized
INFO - 2023-05-15 06:59:09 --> Language Class Initialized
INFO - 2023-05-15 06:59:09 --> Loader Class Initialized
INFO - 2023-05-15 06:59:09 --> Helper loaded: url_helper
INFO - 2023-05-15 06:59:09 --> Helper loaded: form_helper
INFO - 2023-05-15 06:59:09 --> Database Driver Class Initialized
INFO - 2023-05-15 06:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 06:59:09 --> Form Validation Class Initialized
INFO - 2023-05-15 06:59:09 --> Controller Class Initialized
INFO - 2023-05-15 06:59:09 --> Model "m_datatrain" initialized
INFO - 2023-05-15 06:59:09 --> Model "m_datatest" initialized
INFO - 2023-05-15 06:59:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 06:59:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 06:59:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-15 06:59:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 06:59:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 06:59:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 06:59:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-15 06:59:09 --> Final output sent to browser
INFO - 2023-05-15 07:01:56 --> Config Class Initialized
INFO - 2023-05-15 07:01:56 --> Hooks Class Initialized
INFO - 2023-05-15 07:01:56 --> Utf8 Class Initialized
INFO - 2023-05-15 07:01:56 --> URI Class Initialized
INFO - 2023-05-15 07:01:56 --> Router Class Initialized
INFO - 2023-05-15 07:01:56 --> Output Class Initialized
INFO - 2023-05-15 07:01:56 --> Security Class Initialized
INFO - 2023-05-15 07:01:56 --> Input Class Initialized
INFO - 2023-05-15 07:01:56 --> Language Class Initialized
INFO - 2023-05-15 07:01:56 --> Loader Class Initialized
INFO - 2023-05-15 07:01:56 --> Helper loaded: url_helper
INFO - 2023-05-15 07:01:56 --> Helper loaded: form_helper
INFO - 2023-05-15 07:01:56 --> Database Driver Class Initialized
INFO - 2023-05-15 07:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 07:01:56 --> Form Validation Class Initialized
INFO - 2023-05-15 07:01:56 --> Controller Class Initialized
INFO - 2023-05-15 07:01:56 --> Model "m_user" initialized
INFO - 2023-05-15 07:01:56 --> Config Class Initialized
INFO - 2023-05-15 07:01:56 --> Hooks Class Initialized
INFO - 2023-05-15 07:01:56 --> Utf8 Class Initialized
INFO - 2023-05-15 07:01:56 --> URI Class Initialized
INFO - 2023-05-15 07:01:56 --> Router Class Initialized
INFO - 2023-05-15 07:01:56 --> Output Class Initialized
INFO - 2023-05-15 07:01:56 --> Security Class Initialized
INFO - 2023-05-15 07:01:56 --> Input Class Initialized
INFO - 2023-05-15 07:01:56 --> Language Class Initialized
INFO - 2023-05-15 07:01:56 --> Loader Class Initialized
INFO - 2023-05-15 07:01:56 --> Helper loaded: url_helper
INFO - 2023-05-15 07:01:56 --> Helper loaded: form_helper
INFO - 2023-05-15 07:01:56 --> Database Driver Class Initialized
INFO - 2023-05-15 07:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 07:01:56 --> Form Validation Class Initialized
INFO - 2023-05-15 07:01:56 --> Controller Class Initialized
INFO - 2023-05-15 07:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-15 07:01:56 --> Final output sent to browser
INFO - 2023-05-15 07:01:58 --> Config Class Initialized
INFO - 2023-05-15 07:01:58 --> Hooks Class Initialized
INFO - 2023-05-15 07:01:58 --> Utf8 Class Initialized
INFO - 2023-05-15 07:01:58 --> URI Class Initialized
INFO - 2023-05-15 07:01:58 --> Router Class Initialized
INFO - 2023-05-15 07:01:58 --> Output Class Initialized
INFO - 2023-05-15 07:01:58 --> Security Class Initialized
INFO - 2023-05-15 07:01:58 --> Input Class Initialized
INFO - 2023-05-15 07:01:58 --> Language Class Initialized
INFO - 2023-05-15 07:01:58 --> Loader Class Initialized
INFO - 2023-05-15 07:01:58 --> Helper loaded: url_helper
INFO - 2023-05-15 07:01:58 --> Helper loaded: form_helper
INFO - 2023-05-15 07:01:58 --> Database Driver Class Initialized
INFO - 2023-05-15 07:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 07:01:58 --> Form Validation Class Initialized
INFO - 2023-05-15 07:01:58 --> Controller Class Initialized
INFO - 2023-05-15 07:01:58 --> Model "m_user" initialized
INFO - 2023-05-15 07:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-15 07:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-15 07:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-15 07:01:58 --> Final output sent to browser
INFO - 2023-05-15 07:02:01 --> Config Class Initialized
INFO - 2023-05-15 07:02:01 --> Hooks Class Initialized
INFO - 2023-05-15 07:02:01 --> Utf8 Class Initialized
INFO - 2023-05-15 07:02:01 --> URI Class Initialized
INFO - 2023-05-15 07:02:01 --> Router Class Initialized
INFO - 2023-05-15 07:02:01 --> Output Class Initialized
INFO - 2023-05-15 07:02:01 --> Security Class Initialized
INFO - 2023-05-15 07:02:01 --> Input Class Initialized
INFO - 2023-05-15 07:02:01 --> Language Class Initialized
INFO - 2023-05-15 07:02:01 --> Loader Class Initialized
INFO - 2023-05-15 07:02:01 --> Helper loaded: url_helper
INFO - 2023-05-15 07:02:01 --> Helper loaded: form_helper
INFO - 2023-05-15 07:02:01 --> Database Driver Class Initialized
INFO - 2023-05-15 07:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 07:02:01 --> Form Validation Class Initialized
INFO - 2023-05-15 07:02:01 --> Controller Class Initialized
INFO - 2023-05-15 07:02:01 --> Model "m_user" initialized
INFO - 2023-05-15 07:02:01 --> Config Class Initialized
INFO - 2023-05-15 07:02:01 --> Hooks Class Initialized
INFO - 2023-05-15 07:02:01 --> Utf8 Class Initialized
INFO - 2023-05-15 07:02:01 --> URI Class Initialized
INFO - 2023-05-15 07:02:01 --> Router Class Initialized
INFO - 2023-05-15 07:02:01 --> Output Class Initialized
INFO - 2023-05-15 07:02:01 --> Security Class Initialized
INFO - 2023-05-15 07:02:01 --> Input Class Initialized
INFO - 2023-05-15 07:02:01 --> Language Class Initialized
INFO - 2023-05-15 07:02:01 --> Loader Class Initialized
INFO - 2023-05-15 07:02:01 --> Helper loaded: url_helper
INFO - 2023-05-15 07:02:01 --> Helper loaded: form_helper
INFO - 2023-05-15 07:02:01 --> Database Driver Class Initialized
INFO - 2023-05-15 07:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 07:02:01 --> Form Validation Class Initialized
INFO - 2023-05-15 07:02:01 --> Controller Class Initialized
INFO - 2023-05-15 07:02:01 --> Model "m_user" initialized
INFO - 2023-05-15 07:02:01 --> Model "m_datatrain" initialized
INFO - 2023-05-15 07:02:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 07:02:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 07:02:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 07:02:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 07:02:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 07:02:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-15 07:02:01 --> Final output sent to browser
INFO - 2023-05-15 07:02:04 --> Config Class Initialized
INFO - 2023-05-15 07:02:04 --> Hooks Class Initialized
INFO - 2023-05-15 07:02:04 --> Utf8 Class Initialized
INFO - 2023-05-15 07:02:04 --> URI Class Initialized
INFO - 2023-05-15 07:02:04 --> Router Class Initialized
INFO - 2023-05-15 07:02:04 --> Output Class Initialized
INFO - 2023-05-15 07:02:04 --> Security Class Initialized
INFO - 2023-05-15 07:02:04 --> Input Class Initialized
INFO - 2023-05-15 07:02:04 --> Language Class Initialized
INFO - 2023-05-15 07:02:04 --> Loader Class Initialized
INFO - 2023-05-15 07:02:04 --> Helper loaded: url_helper
INFO - 2023-05-15 07:02:04 --> Helper loaded: form_helper
INFO - 2023-05-15 07:02:04 --> Database Driver Class Initialized
INFO - 2023-05-15 07:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 07:02:04 --> Form Validation Class Initialized
INFO - 2023-05-15 07:02:04 --> Controller Class Initialized
INFO - 2023-05-15 07:02:04 --> Model "m_datatest" initialized
INFO - 2023-05-15 07:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 07:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 07:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-15 07:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 07:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 07:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 07:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-15 07:02:04 --> Final output sent to browser
INFO - 2023-05-15 07:02:06 --> Config Class Initialized
INFO - 2023-05-15 07:02:06 --> Hooks Class Initialized
INFO - 2023-05-15 07:02:06 --> Utf8 Class Initialized
INFO - 2023-05-15 07:02:06 --> URI Class Initialized
INFO - 2023-05-15 07:02:06 --> Router Class Initialized
INFO - 2023-05-15 07:02:06 --> Output Class Initialized
INFO - 2023-05-15 07:02:06 --> Security Class Initialized
INFO - 2023-05-15 07:02:06 --> Input Class Initialized
INFO - 2023-05-15 07:02:06 --> Language Class Initialized
INFO - 2023-05-15 07:02:06 --> Loader Class Initialized
INFO - 2023-05-15 07:02:06 --> Helper loaded: url_helper
INFO - 2023-05-15 07:02:06 --> Helper loaded: form_helper
INFO - 2023-05-15 07:02:06 --> Database Driver Class Initialized
INFO - 2023-05-15 07:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 07:02:06 --> Form Validation Class Initialized
INFO - 2023-05-15 07:02:06 --> Controller Class Initialized
INFO - 2023-05-15 07:02:06 --> Model "m_datatrain" initialized
INFO - 2023-05-15 07:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 07:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 07:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-15 07:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 07:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 07:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 07:02:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-15 07:02:06 --> Final output sent to browser
INFO - 2023-05-15 07:22:05 --> Config Class Initialized
INFO - 2023-05-15 07:22:05 --> Hooks Class Initialized
INFO - 2023-05-15 07:22:05 --> Utf8 Class Initialized
INFO - 2023-05-15 07:22:05 --> URI Class Initialized
INFO - 2023-05-15 07:22:05 --> Router Class Initialized
INFO - 2023-05-15 07:22:05 --> Output Class Initialized
INFO - 2023-05-15 07:22:05 --> Security Class Initialized
INFO - 2023-05-15 07:22:05 --> Input Class Initialized
INFO - 2023-05-15 07:22:05 --> Language Class Initialized
INFO - 2023-05-15 07:22:05 --> Loader Class Initialized
INFO - 2023-05-15 07:22:05 --> Helper loaded: url_helper
INFO - 2023-05-15 07:22:05 --> Helper loaded: form_helper
INFO - 2023-05-15 07:22:05 --> Database Driver Class Initialized
INFO - 2023-05-15 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 07:22:05 --> Form Validation Class Initialized
INFO - 2023-05-15 07:22:05 --> Controller Class Initialized
INFO - 2023-05-15 07:22:05 --> Model "m_datatrain" initialized
INFO - 2023-05-15 07:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 07:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 07:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-15 07:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 07:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 07:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 07:22:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-15 07:22:05 --> Final output sent to browser
INFO - 2023-05-15 09:44:48 --> Config Class Initialized
INFO - 2023-05-15 09:44:48 --> Hooks Class Initialized
INFO - 2023-05-15 09:44:48 --> Utf8 Class Initialized
INFO - 2023-05-15 09:44:48 --> URI Class Initialized
INFO - 2023-05-15 09:44:48 --> Router Class Initialized
INFO - 2023-05-15 09:44:48 --> Output Class Initialized
INFO - 2023-05-15 09:44:48 --> Security Class Initialized
INFO - 2023-05-15 09:44:48 --> Input Class Initialized
INFO - 2023-05-15 09:44:48 --> Language Class Initialized
INFO - 2023-05-15 09:44:48 --> Loader Class Initialized
INFO - 2023-05-15 09:44:48 --> Helper loaded: url_helper
INFO - 2023-05-15 09:44:48 --> Helper loaded: form_helper
INFO - 2023-05-15 09:44:48 --> Database Driver Class Initialized
INFO - 2023-05-15 09:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 09:44:48 --> Form Validation Class Initialized
INFO - 2023-05-15 09:44:48 --> Controller Class Initialized
INFO - 2023-05-15 09:44:48 --> Model "m_datatest" initialized
INFO - 2023-05-15 09:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 09:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 09:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-15 09:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 09:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 09:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 09:44:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-15 09:44:48 --> Final output sent to browser
INFO - 2023-05-15 09:44:57 --> Config Class Initialized
INFO - 2023-05-15 09:44:57 --> Hooks Class Initialized
INFO - 2023-05-15 09:44:57 --> Utf8 Class Initialized
INFO - 2023-05-15 09:44:57 --> URI Class Initialized
INFO - 2023-05-15 09:44:57 --> Router Class Initialized
INFO - 2023-05-15 09:44:57 --> Output Class Initialized
INFO - 2023-05-15 09:44:57 --> Security Class Initialized
INFO - 2023-05-15 09:44:57 --> Input Class Initialized
INFO - 2023-05-15 09:44:57 --> Language Class Initialized
INFO - 2023-05-15 09:44:57 --> Loader Class Initialized
INFO - 2023-05-15 09:44:57 --> Helper loaded: url_helper
INFO - 2023-05-15 09:44:57 --> Helper loaded: form_helper
INFO - 2023-05-15 09:44:57 --> Database Driver Class Initialized
INFO - 2023-05-15 09:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 09:44:57 --> Form Validation Class Initialized
INFO - 2023-05-15 09:44:57 --> Controller Class Initialized
INFO - 2023-05-15 09:44:57 --> Model "m_datatest" initialized
INFO - 2023-05-15 09:44:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 09:44:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 09:44:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-15 09:44:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 09:44:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 09:44:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 09:44:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-15 09:44:57 --> Final output sent to browser
INFO - 2023-05-15 09:45:09 --> Config Class Initialized
INFO - 2023-05-15 09:45:09 --> Hooks Class Initialized
INFO - 2023-05-15 09:45:09 --> Utf8 Class Initialized
INFO - 2023-05-15 09:45:09 --> URI Class Initialized
INFO - 2023-05-15 09:45:09 --> Router Class Initialized
INFO - 2023-05-15 09:45:09 --> Output Class Initialized
INFO - 2023-05-15 09:45:09 --> Security Class Initialized
INFO - 2023-05-15 09:45:09 --> Input Class Initialized
INFO - 2023-05-15 09:45:09 --> Language Class Initialized
INFO - 2023-05-15 09:45:09 --> Loader Class Initialized
INFO - 2023-05-15 09:45:09 --> Helper loaded: url_helper
INFO - 2023-05-15 09:45:09 --> Helper loaded: form_helper
INFO - 2023-05-15 09:45:09 --> Database Driver Class Initialized
INFO - 2023-05-15 09:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 09:45:09 --> Form Validation Class Initialized
INFO - 2023-05-15 09:45:09 --> Controller Class Initialized
INFO - 2023-05-15 09:45:09 --> Model "m_user" initialized
INFO - 2023-05-15 09:45:09 --> Model "m_datatrain" initialized
INFO - 2023-05-15 09:45:09 --> Config Class Initialized
INFO - 2023-05-15 09:45:09 --> Hooks Class Initialized
INFO - 2023-05-15 09:45:09 --> Utf8 Class Initialized
INFO - 2023-05-15 09:45:09 --> URI Class Initialized
INFO - 2023-05-15 09:45:09 --> Router Class Initialized
INFO - 2023-05-15 09:45:09 --> Output Class Initialized
INFO - 2023-05-15 09:45:09 --> Security Class Initialized
INFO - 2023-05-15 09:45:09 --> Input Class Initialized
INFO - 2023-05-15 09:45:09 --> Language Class Initialized
INFO - 2023-05-15 09:45:09 --> Loader Class Initialized
INFO - 2023-05-15 09:45:09 --> Helper loaded: url_helper
INFO - 2023-05-15 09:45:09 --> Helper loaded: form_helper
INFO - 2023-05-15 09:45:09 --> Database Driver Class Initialized
INFO - 2023-05-15 09:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 09:45:09 --> Form Validation Class Initialized
INFO - 2023-05-15 09:45:09 --> Controller Class Initialized
INFO - 2023-05-15 09:45:09 --> Model "m_user" initialized
INFO - 2023-05-15 09:45:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-15 09:45:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-15 09:45:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-15 09:45:09 --> Final output sent to browser
INFO - 2023-05-15 09:45:18 --> Config Class Initialized
INFO - 2023-05-15 09:45:18 --> Hooks Class Initialized
INFO - 2023-05-15 09:45:18 --> Utf8 Class Initialized
INFO - 2023-05-15 09:45:18 --> URI Class Initialized
INFO - 2023-05-15 09:45:18 --> Router Class Initialized
INFO - 2023-05-15 09:45:18 --> Output Class Initialized
INFO - 2023-05-15 09:45:18 --> Security Class Initialized
INFO - 2023-05-15 09:45:18 --> Input Class Initialized
INFO - 2023-05-15 09:45:18 --> Language Class Initialized
INFO - 2023-05-15 09:45:18 --> Loader Class Initialized
INFO - 2023-05-15 09:45:18 --> Helper loaded: url_helper
INFO - 2023-05-15 09:45:18 --> Helper loaded: form_helper
INFO - 2023-05-15 09:45:18 --> Database Driver Class Initialized
INFO - 2023-05-15 09:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 09:45:18 --> Form Validation Class Initialized
INFO - 2023-05-15 09:45:18 --> Controller Class Initialized
INFO - 2023-05-15 09:45:18 --> Model "m_user" initialized
INFO - 2023-05-15 09:45:18 --> Config Class Initialized
INFO - 2023-05-15 09:45:18 --> Hooks Class Initialized
INFO - 2023-05-15 09:45:18 --> Utf8 Class Initialized
INFO - 2023-05-15 09:45:18 --> URI Class Initialized
INFO - 2023-05-15 09:45:18 --> Router Class Initialized
INFO - 2023-05-15 09:45:18 --> Output Class Initialized
INFO - 2023-05-15 09:45:18 --> Security Class Initialized
INFO - 2023-05-15 09:45:18 --> Input Class Initialized
INFO - 2023-05-15 09:45:18 --> Language Class Initialized
INFO - 2023-05-15 09:45:18 --> Loader Class Initialized
INFO - 2023-05-15 09:45:18 --> Helper loaded: url_helper
INFO - 2023-05-15 09:45:18 --> Helper loaded: form_helper
INFO - 2023-05-15 09:45:18 --> Database Driver Class Initialized
INFO - 2023-05-15 09:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 09:45:18 --> Form Validation Class Initialized
INFO - 2023-05-15 09:45:18 --> Controller Class Initialized
INFO - 2023-05-15 09:45:18 --> Model "m_user" initialized
INFO - 2023-05-15 09:45:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-15 09:45:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-15 09:45:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-15 09:45:18 --> Final output sent to browser
INFO - 2023-05-15 09:45:23 --> Config Class Initialized
INFO - 2023-05-15 09:45:23 --> Hooks Class Initialized
INFO - 2023-05-15 09:45:23 --> Utf8 Class Initialized
INFO - 2023-05-15 09:45:23 --> URI Class Initialized
INFO - 2023-05-15 09:45:24 --> Router Class Initialized
INFO - 2023-05-15 09:45:24 --> Output Class Initialized
INFO - 2023-05-15 09:45:24 --> Security Class Initialized
INFO - 2023-05-15 09:45:24 --> Input Class Initialized
INFO - 2023-05-15 09:45:24 --> Language Class Initialized
INFO - 2023-05-15 09:45:24 --> Loader Class Initialized
INFO - 2023-05-15 09:45:24 --> Helper loaded: url_helper
INFO - 2023-05-15 09:45:24 --> Helper loaded: form_helper
INFO - 2023-05-15 09:45:24 --> Database Driver Class Initialized
INFO - 2023-05-15 09:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 09:45:24 --> Form Validation Class Initialized
INFO - 2023-05-15 09:45:24 --> Controller Class Initialized
INFO - 2023-05-15 09:45:24 --> Model "m_user" initialized
INFO - 2023-05-15 09:45:24 --> Config Class Initialized
INFO - 2023-05-15 09:45:24 --> Hooks Class Initialized
INFO - 2023-05-15 09:45:24 --> Utf8 Class Initialized
INFO - 2023-05-15 09:45:24 --> URI Class Initialized
INFO - 2023-05-15 09:45:24 --> Router Class Initialized
INFO - 2023-05-15 09:45:24 --> Output Class Initialized
INFO - 2023-05-15 09:45:24 --> Security Class Initialized
INFO - 2023-05-15 09:45:24 --> Input Class Initialized
INFO - 2023-05-15 09:45:24 --> Language Class Initialized
INFO - 2023-05-15 09:45:24 --> Loader Class Initialized
INFO - 2023-05-15 09:45:24 --> Helper loaded: url_helper
INFO - 2023-05-15 09:45:24 --> Helper loaded: form_helper
INFO - 2023-05-15 09:45:24 --> Database Driver Class Initialized
INFO - 2023-05-15 09:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 09:45:24 --> Form Validation Class Initialized
INFO - 2023-05-15 09:45:24 --> Controller Class Initialized
INFO - 2023-05-15 09:45:24 --> Model "m_user" initialized
INFO - 2023-05-15 09:45:24 --> Model "m_datatrain" initialized
INFO - 2023-05-15 09:45:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 09:45:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 09:45:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 09:45:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 09:45:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 09:45:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-15 09:45:24 --> Final output sent to browser
INFO - 2023-05-15 11:52:04 --> Config Class Initialized
INFO - 2023-05-15 11:52:04 --> Hooks Class Initialized
INFO - 2023-05-15 11:52:04 --> Utf8 Class Initialized
INFO - 2023-05-15 11:52:04 --> URI Class Initialized
INFO - 2023-05-15 11:52:04 --> Router Class Initialized
INFO - 2023-05-15 11:52:04 --> Output Class Initialized
INFO - 2023-05-15 11:52:04 --> Security Class Initialized
INFO - 2023-05-15 11:52:04 --> Input Class Initialized
INFO - 2023-05-15 11:52:04 --> Language Class Initialized
INFO - 2023-05-15 11:52:04 --> Loader Class Initialized
INFO - 2023-05-15 11:52:04 --> Helper loaded: url_helper
INFO - 2023-05-15 11:52:04 --> Helper loaded: form_helper
INFO - 2023-05-15 11:52:05 --> Database Driver Class Initialized
INFO - 2023-05-15 11:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:52:05 --> Form Validation Class Initialized
INFO - 2023-05-15 11:52:05 --> Controller Class Initialized
INFO - 2023-05-15 11:52:05 --> Model "m_user" initialized
INFO - 2023-05-15 11:52:05 --> Model "m_datatrain" initialized
INFO - 2023-05-15 11:52:05 --> Config Class Initialized
INFO - 2023-05-15 11:52:05 --> Hooks Class Initialized
INFO - 2023-05-15 11:52:05 --> Utf8 Class Initialized
INFO - 2023-05-15 11:52:05 --> URI Class Initialized
INFO - 2023-05-15 11:52:05 --> Router Class Initialized
INFO - 2023-05-15 11:52:05 --> Output Class Initialized
INFO - 2023-05-15 11:52:05 --> Security Class Initialized
INFO - 2023-05-15 11:52:05 --> Input Class Initialized
INFO - 2023-05-15 11:52:05 --> Language Class Initialized
INFO - 2023-05-15 11:52:05 --> Loader Class Initialized
INFO - 2023-05-15 11:52:05 --> Helper loaded: url_helper
INFO - 2023-05-15 11:52:05 --> Helper loaded: form_helper
INFO - 2023-05-15 11:52:05 --> Database Driver Class Initialized
INFO - 2023-05-15 11:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:52:05 --> Form Validation Class Initialized
INFO - 2023-05-15 11:52:05 --> Controller Class Initialized
INFO - 2023-05-15 11:52:05 --> Model "m_user" initialized
INFO - 2023-05-15 11:52:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-15 11:52:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-15 11:52:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-15 11:52:05 --> Final output sent to browser
INFO - 2023-05-15 11:52:12 --> Config Class Initialized
INFO - 2023-05-15 11:52:12 --> Hooks Class Initialized
INFO - 2023-05-15 11:52:12 --> Utf8 Class Initialized
INFO - 2023-05-15 11:52:12 --> URI Class Initialized
INFO - 2023-05-15 11:52:12 --> Router Class Initialized
INFO - 2023-05-15 11:52:12 --> Output Class Initialized
INFO - 2023-05-15 11:52:12 --> Security Class Initialized
INFO - 2023-05-15 11:52:12 --> Input Class Initialized
INFO - 2023-05-15 11:52:12 --> Language Class Initialized
INFO - 2023-05-15 11:52:12 --> Loader Class Initialized
INFO - 2023-05-15 11:52:12 --> Helper loaded: url_helper
INFO - 2023-05-15 11:52:12 --> Helper loaded: form_helper
INFO - 2023-05-15 11:52:12 --> Database Driver Class Initialized
INFO - 2023-05-15 11:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:52:12 --> Form Validation Class Initialized
INFO - 2023-05-15 11:52:12 --> Controller Class Initialized
INFO - 2023-05-15 11:52:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-15 11:52:12 --> Final output sent to browser
INFO - 2023-05-15 11:52:14 --> Config Class Initialized
INFO - 2023-05-15 11:52:14 --> Hooks Class Initialized
INFO - 2023-05-15 11:52:14 --> Utf8 Class Initialized
INFO - 2023-05-15 11:52:14 --> URI Class Initialized
INFO - 2023-05-15 11:52:14 --> Router Class Initialized
INFO - 2023-05-15 11:52:14 --> Output Class Initialized
INFO - 2023-05-15 11:52:14 --> Security Class Initialized
INFO - 2023-05-15 11:52:14 --> Input Class Initialized
INFO - 2023-05-15 11:52:14 --> Language Class Initialized
INFO - 2023-05-15 11:52:14 --> Loader Class Initialized
INFO - 2023-05-15 11:52:14 --> Helper loaded: url_helper
INFO - 2023-05-15 11:52:14 --> Helper loaded: form_helper
INFO - 2023-05-15 11:52:14 --> Database Driver Class Initialized
INFO - 2023-05-15 11:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:52:14 --> Form Validation Class Initialized
INFO - 2023-05-15 11:52:14 --> Controller Class Initialized
INFO - 2023-05-15 11:52:14 --> Model "m_user" initialized
INFO - 2023-05-15 11:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 11:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 11:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 11:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 11:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 11:52:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-15 11:52:14 --> Final output sent to browser
INFO - 2023-05-15 11:52:18 --> Config Class Initialized
INFO - 2023-05-15 11:52:18 --> Hooks Class Initialized
INFO - 2023-05-15 11:52:18 --> Utf8 Class Initialized
INFO - 2023-05-15 11:52:18 --> URI Class Initialized
INFO - 2023-05-15 11:52:18 --> Router Class Initialized
INFO - 2023-05-15 11:52:18 --> Output Class Initialized
INFO - 2023-05-15 11:52:18 --> Security Class Initialized
INFO - 2023-05-15 11:52:18 --> Input Class Initialized
INFO - 2023-05-15 11:52:18 --> Language Class Initialized
INFO - 2023-05-15 11:52:18 --> Loader Class Initialized
INFO - 2023-05-15 11:52:18 --> Helper loaded: url_helper
INFO - 2023-05-15 11:52:18 --> Helper loaded: form_helper
INFO - 2023-05-15 11:52:18 --> Database Driver Class Initialized
INFO - 2023-05-15 11:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:52:18 --> Form Validation Class Initialized
INFO - 2023-05-15 11:52:18 --> Controller Class Initialized
INFO - 2023-05-15 11:52:18 --> Model "m_user" initialized
INFO - 2023-05-15 11:52:18 --> Config Class Initialized
INFO - 2023-05-15 11:52:18 --> Hooks Class Initialized
INFO - 2023-05-15 11:52:18 --> Utf8 Class Initialized
INFO - 2023-05-15 11:52:18 --> URI Class Initialized
INFO - 2023-05-15 11:52:18 --> Router Class Initialized
INFO - 2023-05-15 11:52:18 --> Output Class Initialized
INFO - 2023-05-15 11:52:18 --> Security Class Initialized
INFO - 2023-05-15 11:52:18 --> Input Class Initialized
INFO - 2023-05-15 11:52:18 --> Language Class Initialized
INFO - 2023-05-15 11:52:18 --> Loader Class Initialized
INFO - 2023-05-15 11:52:18 --> Helper loaded: url_helper
INFO - 2023-05-15 11:52:18 --> Helper loaded: form_helper
INFO - 2023-05-15 11:52:18 --> Database Driver Class Initialized
INFO - 2023-05-15 11:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:52:18 --> Form Validation Class Initialized
INFO - 2023-05-15 11:52:18 --> Controller Class Initialized
INFO - 2023-05-15 11:52:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-15 11:52:18 --> Final output sent to browser
INFO - 2023-05-15 11:52:19 --> Config Class Initialized
INFO - 2023-05-15 11:52:19 --> Hooks Class Initialized
INFO - 2023-05-15 11:52:19 --> Utf8 Class Initialized
INFO - 2023-05-15 11:52:19 --> URI Class Initialized
INFO - 2023-05-15 11:52:19 --> Router Class Initialized
INFO - 2023-05-15 11:52:19 --> Output Class Initialized
INFO - 2023-05-15 11:52:19 --> Security Class Initialized
INFO - 2023-05-15 11:52:19 --> Input Class Initialized
INFO - 2023-05-15 11:52:19 --> Language Class Initialized
INFO - 2023-05-15 11:52:19 --> Loader Class Initialized
INFO - 2023-05-15 11:52:19 --> Helper loaded: url_helper
INFO - 2023-05-15 11:52:20 --> Helper loaded: form_helper
INFO - 2023-05-15 11:52:20 --> Database Driver Class Initialized
INFO - 2023-05-15 11:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:52:20 --> Form Validation Class Initialized
INFO - 2023-05-15 11:52:20 --> Controller Class Initialized
INFO - 2023-05-15 11:52:20 --> Model "m_user" initialized
INFO - 2023-05-15 11:52:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-15 11:52:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-15 11:52:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-15 11:52:20 --> Final output sent to browser
INFO - 2023-05-15 11:52:23 --> Config Class Initialized
INFO - 2023-05-15 11:52:23 --> Hooks Class Initialized
INFO - 2023-05-15 11:52:23 --> Utf8 Class Initialized
INFO - 2023-05-15 11:52:23 --> URI Class Initialized
INFO - 2023-05-15 11:52:23 --> Router Class Initialized
INFO - 2023-05-15 11:52:23 --> Output Class Initialized
INFO - 2023-05-15 11:52:23 --> Security Class Initialized
INFO - 2023-05-15 11:52:23 --> Input Class Initialized
INFO - 2023-05-15 11:52:23 --> Language Class Initialized
INFO - 2023-05-15 11:52:23 --> Loader Class Initialized
INFO - 2023-05-15 11:52:23 --> Helper loaded: url_helper
INFO - 2023-05-15 11:52:23 --> Helper loaded: form_helper
INFO - 2023-05-15 11:52:23 --> Database Driver Class Initialized
INFO - 2023-05-15 11:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:52:23 --> Form Validation Class Initialized
INFO - 2023-05-15 11:52:23 --> Controller Class Initialized
INFO - 2023-05-15 11:52:23 --> Model "m_user" initialized
INFO - 2023-05-15 11:52:23 --> Config Class Initialized
INFO - 2023-05-15 11:52:23 --> Hooks Class Initialized
INFO - 2023-05-15 11:52:23 --> Utf8 Class Initialized
INFO - 2023-05-15 11:52:23 --> URI Class Initialized
INFO - 2023-05-15 11:52:23 --> Router Class Initialized
INFO - 2023-05-15 11:52:23 --> Output Class Initialized
INFO - 2023-05-15 11:52:23 --> Security Class Initialized
INFO - 2023-05-15 11:52:23 --> Input Class Initialized
INFO - 2023-05-15 11:52:23 --> Language Class Initialized
INFO - 2023-05-15 11:52:23 --> Loader Class Initialized
INFO - 2023-05-15 11:52:23 --> Helper loaded: url_helper
INFO - 2023-05-15 11:52:23 --> Helper loaded: form_helper
INFO - 2023-05-15 11:52:23 --> Database Driver Class Initialized
INFO - 2023-05-15 11:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:52:23 --> Form Validation Class Initialized
INFO - 2023-05-15 11:52:23 --> Controller Class Initialized
INFO - 2023-05-15 11:52:23 --> Model "m_user" initialized
INFO - 2023-05-15 11:52:23 --> Model "m_datatrain" initialized
INFO - 2023-05-15 11:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 11:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 11:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 11:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 11:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 11:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-15 11:52:23 --> Final output sent to browser
INFO - 2023-05-15 11:52:27 --> Config Class Initialized
INFO - 2023-05-15 11:52:27 --> Hooks Class Initialized
INFO - 2023-05-15 11:52:27 --> Utf8 Class Initialized
INFO - 2023-05-15 11:52:27 --> URI Class Initialized
INFO - 2023-05-15 11:52:27 --> Router Class Initialized
INFO - 2023-05-15 11:52:27 --> Output Class Initialized
INFO - 2023-05-15 11:52:27 --> Security Class Initialized
INFO - 2023-05-15 11:52:27 --> Input Class Initialized
INFO - 2023-05-15 11:52:27 --> Language Class Initialized
INFO - 2023-05-15 11:52:27 --> Loader Class Initialized
INFO - 2023-05-15 11:52:27 --> Helper loaded: url_helper
INFO - 2023-05-15 11:52:27 --> Helper loaded: form_helper
INFO - 2023-05-15 11:52:27 --> Database Driver Class Initialized
INFO - 2023-05-15 11:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:52:27 --> Form Validation Class Initialized
INFO - 2023-05-15 11:52:27 --> Controller Class Initialized
INFO - 2023-05-15 11:52:27 --> Model "m_datatrain" initialized
INFO - 2023-05-15 11:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 11:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 11:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-15 11:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 11:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 11:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 11:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-15 11:52:27 --> Final output sent to browser
INFO - 2023-05-15 11:55:33 --> Config Class Initialized
INFO - 2023-05-15 11:55:33 --> Hooks Class Initialized
INFO - 2023-05-15 11:55:33 --> Utf8 Class Initialized
INFO - 2023-05-15 11:55:33 --> URI Class Initialized
INFO - 2023-05-15 11:55:33 --> Router Class Initialized
INFO - 2023-05-15 11:55:33 --> Output Class Initialized
INFO - 2023-05-15 11:55:33 --> Security Class Initialized
INFO - 2023-05-15 11:55:33 --> Input Class Initialized
INFO - 2023-05-15 11:55:33 --> Language Class Initialized
INFO - 2023-05-15 11:55:33 --> Loader Class Initialized
INFO - 2023-05-15 11:55:33 --> Helper loaded: url_helper
INFO - 2023-05-15 11:55:33 --> Helper loaded: form_helper
INFO - 2023-05-15 11:55:33 --> Database Driver Class Initialized
INFO - 2023-05-15 11:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:55:33 --> Form Validation Class Initialized
INFO - 2023-05-15 11:55:33 --> Controller Class Initialized
INFO - 2023-05-15 11:55:33 --> Model "m_user" initialized
INFO - 2023-05-15 11:55:33 --> Config Class Initialized
INFO - 2023-05-15 11:55:33 --> Hooks Class Initialized
INFO - 2023-05-15 11:55:33 --> Utf8 Class Initialized
INFO - 2023-05-15 11:55:33 --> URI Class Initialized
INFO - 2023-05-15 11:55:33 --> Router Class Initialized
INFO - 2023-05-15 11:55:33 --> Output Class Initialized
INFO - 2023-05-15 11:55:33 --> Security Class Initialized
INFO - 2023-05-15 11:55:33 --> Input Class Initialized
INFO - 2023-05-15 11:55:33 --> Language Class Initialized
INFO - 2023-05-15 11:55:33 --> Loader Class Initialized
INFO - 2023-05-15 11:55:33 --> Helper loaded: url_helper
INFO - 2023-05-15 11:55:33 --> Helper loaded: form_helper
INFO - 2023-05-15 11:55:33 --> Database Driver Class Initialized
INFO - 2023-05-15 11:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:55:33 --> Form Validation Class Initialized
INFO - 2023-05-15 11:55:33 --> Controller Class Initialized
INFO - 2023-05-15 11:55:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-15 11:55:33 --> Final output sent to browser
INFO - 2023-05-15 11:55:35 --> Config Class Initialized
INFO - 2023-05-15 11:55:35 --> Hooks Class Initialized
INFO - 2023-05-15 11:55:35 --> Utf8 Class Initialized
INFO - 2023-05-15 11:55:35 --> URI Class Initialized
INFO - 2023-05-15 11:55:35 --> Router Class Initialized
INFO - 2023-05-15 11:55:35 --> Output Class Initialized
INFO - 2023-05-15 11:55:35 --> Security Class Initialized
INFO - 2023-05-15 11:55:35 --> Input Class Initialized
INFO - 2023-05-15 11:55:35 --> Language Class Initialized
INFO - 2023-05-15 11:55:35 --> Loader Class Initialized
INFO - 2023-05-15 11:55:35 --> Helper loaded: url_helper
INFO - 2023-05-15 11:55:35 --> Helper loaded: form_helper
INFO - 2023-05-15 11:55:35 --> Database Driver Class Initialized
INFO - 2023-05-15 11:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:55:35 --> Form Validation Class Initialized
INFO - 2023-05-15 11:55:35 --> Controller Class Initialized
INFO - 2023-05-15 11:55:35 --> Model "m_user" initialized
INFO - 2023-05-15 11:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 11:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 11:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 11:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 11:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 11:55:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-15 11:55:35 --> Final output sent to browser
INFO - 2023-05-15 11:55:38 --> Config Class Initialized
INFO - 2023-05-15 11:55:38 --> Hooks Class Initialized
INFO - 2023-05-15 11:55:38 --> Utf8 Class Initialized
INFO - 2023-05-15 11:55:38 --> URI Class Initialized
INFO - 2023-05-15 11:55:38 --> Router Class Initialized
INFO - 2023-05-15 11:55:38 --> Output Class Initialized
INFO - 2023-05-15 11:55:38 --> Security Class Initialized
INFO - 2023-05-15 11:55:38 --> Input Class Initialized
INFO - 2023-05-15 11:55:38 --> Language Class Initialized
INFO - 2023-05-15 11:55:38 --> Loader Class Initialized
INFO - 2023-05-15 11:55:38 --> Helper loaded: url_helper
INFO - 2023-05-15 11:55:38 --> Helper loaded: form_helper
INFO - 2023-05-15 11:55:38 --> Database Driver Class Initialized
INFO - 2023-05-15 11:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:55:38 --> Form Validation Class Initialized
INFO - 2023-05-15 11:55:38 --> Controller Class Initialized
INFO - 2023-05-15 11:55:38 --> Model "m_datatrain" initialized
INFO - 2023-05-15 11:55:38 --> Model "m_datatest" initialized
INFO - 2023-05-15 11:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 11:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 11:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-15 11:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 11:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 11:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 11:55:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-15 11:55:38 --> Final output sent to browser
INFO - 2023-05-15 11:55:42 --> Config Class Initialized
INFO - 2023-05-15 11:55:42 --> Hooks Class Initialized
INFO - 2023-05-15 11:55:43 --> Utf8 Class Initialized
INFO - 2023-05-15 11:55:43 --> URI Class Initialized
INFO - 2023-05-15 11:55:43 --> Router Class Initialized
INFO - 2023-05-15 11:55:43 --> Output Class Initialized
INFO - 2023-05-15 11:55:43 --> Security Class Initialized
INFO - 2023-05-15 11:55:43 --> Input Class Initialized
INFO - 2023-05-15 11:55:43 --> Language Class Initialized
INFO - 2023-05-15 11:55:43 --> Loader Class Initialized
INFO - 2023-05-15 11:55:43 --> Helper loaded: url_helper
INFO - 2023-05-15 11:55:43 --> Helper loaded: form_helper
INFO - 2023-05-15 11:55:43 --> Database Driver Class Initialized
INFO - 2023-05-15 11:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 11:55:43 --> Form Validation Class Initialized
INFO - 2023-05-15 11:55:43 --> Controller Class Initialized
INFO - 2023-05-15 11:55:43 --> Model "m_datatrain" initialized
INFO - 2023-05-15 11:55:43 --> Model "m_datatest" initialized
INFO - 2023-05-15 11:55:43 --> Final output sent to browser
INFO - 2023-05-15 12:00:12 --> Config Class Initialized
INFO - 2023-05-15 12:00:12 --> Hooks Class Initialized
INFO - 2023-05-15 12:00:12 --> Utf8 Class Initialized
INFO - 2023-05-15 12:00:12 --> URI Class Initialized
INFO - 2023-05-15 12:00:12 --> Router Class Initialized
INFO - 2023-05-15 12:00:12 --> Output Class Initialized
INFO - 2023-05-15 12:00:12 --> Security Class Initialized
INFO - 2023-05-15 12:00:12 --> Input Class Initialized
INFO - 2023-05-15 12:00:12 --> Language Class Initialized
ERROR - 2023-05-15 12:00:12 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 354
INFO - 2023-05-15 12:00:29 --> Config Class Initialized
INFO - 2023-05-15 12:00:29 --> Hooks Class Initialized
INFO - 2023-05-15 12:00:29 --> Utf8 Class Initialized
INFO - 2023-05-15 12:00:29 --> URI Class Initialized
INFO - 2023-05-15 12:00:29 --> Router Class Initialized
INFO - 2023-05-15 12:00:29 --> Output Class Initialized
INFO - 2023-05-15 12:00:29 --> Security Class Initialized
INFO - 2023-05-15 12:00:29 --> Input Class Initialized
INFO - 2023-05-15 12:00:29 --> Language Class Initialized
ERROR - 2023-05-15 12:00:29 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 354
INFO - 2023-05-15 12:00:30 --> Config Class Initialized
INFO - 2023-05-15 12:00:30 --> Hooks Class Initialized
INFO - 2023-05-15 12:00:30 --> Utf8 Class Initialized
INFO - 2023-05-15 12:00:30 --> URI Class Initialized
INFO - 2023-05-15 12:00:30 --> Router Class Initialized
INFO - 2023-05-15 12:00:30 --> Output Class Initialized
INFO - 2023-05-15 12:00:30 --> Security Class Initialized
INFO - 2023-05-15 12:00:30 --> Input Class Initialized
INFO - 2023-05-15 12:00:30 --> Language Class Initialized
ERROR - 2023-05-15 12:00:30 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 354
INFO - 2023-05-15 12:00:48 --> Config Class Initialized
INFO - 2023-05-15 12:00:48 --> Hooks Class Initialized
INFO - 2023-05-15 12:00:48 --> Utf8 Class Initialized
INFO - 2023-05-15 12:00:48 --> URI Class Initialized
INFO - 2023-05-15 12:00:48 --> Router Class Initialized
INFO - 2023-05-15 12:00:48 --> Output Class Initialized
INFO - 2023-05-15 12:00:48 --> Security Class Initialized
INFO - 2023-05-15 12:00:48 --> Input Class Initialized
INFO - 2023-05-15 12:00:48 --> Language Class Initialized
ERROR - 2023-05-15 12:00:48 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 354
INFO - 2023-05-15 12:00:49 --> Config Class Initialized
INFO - 2023-05-15 12:00:49 --> Hooks Class Initialized
INFO - 2023-05-15 12:00:49 --> Utf8 Class Initialized
INFO - 2023-05-15 12:00:49 --> URI Class Initialized
INFO - 2023-05-15 12:00:49 --> Router Class Initialized
INFO - 2023-05-15 12:00:49 --> Output Class Initialized
INFO - 2023-05-15 12:00:49 --> Security Class Initialized
INFO - 2023-05-15 12:00:49 --> Input Class Initialized
INFO - 2023-05-15 12:00:49 --> Language Class Initialized
ERROR - 2023-05-15 12:00:49 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 354
INFO - 2023-05-15 12:01:08 --> Config Class Initialized
INFO - 2023-05-15 12:01:08 --> Hooks Class Initialized
INFO - 2023-05-15 12:01:08 --> Utf8 Class Initialized
INFO - 2023-05-15 12:01:08 --> URI Class Initialized
INFO - 2023-05-15 12:01:08 --> Router Class Initialized
INFO - 2023-05-15 12:01:08 --> Output Class Initialized
INFO - 2023-05-15 12:01:08 --> Security Class Initialized
INFO - 2023-05-15 12:01:08 --> Input Class Initialized
INFO - 2023-05-15 12:01:08 --> Language Class Initialized
INFO - 2023-05-15 12:01:08 --> Loader Class Initialized
INFO - 2023-05-15 12:01:08 --> Helper loaded: url_helper
INFO - 2023-05-15 12:01:08 --> Helper loaded: form_helper
INFO - 2023-05-15 12:01:08 --> Database Driver Class Initialized
INFO - 2023-05-15 12:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 12:01:08 --> Form Validation Class Initialized
INFO - 2023-05-15 12:01:08 --> Controller Class Initialized
INFO - 2023-05-15 12:01:08 --> Model "m_datatrain" initialized
INFO - 2023-05-15 12:01:08 --> Model "m_datatest" initialized
INFO - 2023-05-15 12:01:08 --> Final output sent to browser
INFO - 2023-05-15 12:01:28 --> Config Class Initialized
INFO - 2023-05-15 12:01:28 --> Hooks Class Initialized
INFO - 2023-05-15 12:01:28 --> Utf8 Class Initialized
INFO - 2023-05-15 12:01:28 --> URI Class Initialized
INFO - 2023-05-15 12:01:28 --> Router Class Initialized
INFO - 2023-05-15 12:01:28 --> Output Class Initialized
INFO - 2023-05-15 12:01:28 --> Security Class Initialized
INFO - 2023-05-15 12:01:28 --> Input Class Initialized
INFO - 2023-05-15 12:01:28 --> Language Class Initialized
INFO - 2023-05-15 12:01:28 --> Loader Class Initialized
INFO - 2023-05-15 12:01:28 --> Helper loaded: url_helper
INFO - 2023-05-15 12:01:28 --> Helper loaded: form_helper
INFO - 2023-05-15 12:01:28 --> Database Driver Class Initialized
INFO - 2023-05-15 12:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 12:01:28 --> Form Validation Class Initialized
INFO - 2023-05-15 12:01:28 --> Controller Class Initialized
INFO - 2023-05-15 12:01:28 --> Model "m_datatrain" initialized
INFO - 2023-05-15 12:01:28 --> Model "m_datatest" initialized
INFO - 2023-05-15 12:01:28 --> Final output sent to browser
INFO - 2023-05-15 14:32:23 --> Config Class Initialized
INFO - 2023-05-15 14:32:23 --> Hooks Class Initialized
INFO - 2023-05-15 14:32:23 --> Utf8 Class Initialized
INFO - 2023-05-15 14:32:23 --> URI Class Initialized
INFO - 2023-05-15 14:32:23 --> Router Class Initialized
INFO - 2023-05-15 14:32:23 --> Output Class Initialized
INFO - 2023-05-15 14:32:23 --> Security Class Initialized
INFO - 2023-05-15 14:32:23 --> Input Class Initialized
INFO - 2023-05-15 14:32:23 --> Language Class Initialized
INFO - 2023-05-15 14:32:23 --> Loader Class Initialized
INFO - 2023-05-15 14:32:23 --> Helper loaded: url_helper
INFO - 2023-05-15 14:32:23 --> Helper loaded: form_helper
INFO - 2023-05-15 14:32:23 --> Database Driver Class Initialized
INFO - 2023-05-15 14:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 14:32:23 --> Form Validation Class Initialized
INFO - 2023-05-15 14:32:23 --> Controller Class Initialized
INFO - 2023-05-15 14:32:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-15 14:32:23 --> Final output sent to browser
INFO - 2023-05-15 14:32:26 --> Config Class Initialized
INFO - 2023-05-15 14:32:26 --> Hooks Class Initialized
INFO - 2023-05-15 14:32:26 --> Utf8 Class Initialized
INFO - 2023-05-15 14:32:26 --> URI Class Initialized
INFO - 2023-05-15 14:32:26 --> Router Class Initialized
INFO - 2023-05-15 14:32:26 --> Output Class Initialized
INFO - 2023-05-15 14:32:26 --> Security Class Initialized
INFO - 2023-05-15 14:32:26 --> Input Class Initialized
INFO - 2023-05-15 14:32:26 --> Language Class Initialized
INFO - 2023-05-15 14:32:26 --> Loader Class Initialized
INFO - 2023-05-15 14:32:26 --> Helper loaded: url_helper
INFO - 2023-05-15 14:32:26 --> Helper loaded: form_helper
INFO - 2023-05-15 14:32:26 --> Database Driver Class Initialized
INFO - 2023-05-15 14:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 14:32:26 --> Form Validation Class Initialized
INFO - 2023-05-15 14:32:26 --> Controller Class Initialized
INFO - 2023-05-15 14:32:26 --> Model "m_user" initialized
INFO - 2023-05-15 14:32:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-15 14:32:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-15 14:32:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-15 14:32:26 --> Final output sent to browser
INFO - 2023-05-15 14:32:35 --> Config Class Initialized
INFO - 2023-05-15 14:32:35 --> Hooks Class Initialized
INFO - 2023-05-15 14:32:35 --> Utf8 Class Initialized
INFO - 2023-05-15 14:32:35 --> URI Class Initialized
INFO - 2023-05-15 14:32:35 --> Router Class Initialized
INFO - 2023-05-15 14:32:35 --> Output Class Initialized
INFO - 2023-05-15 14:32:35 --> Security Class Initialized
INFO - 2023-05-15 14:32:35 --> Input Class Initialized
INFO - 2023-05-15 14:32:35 --> Language Class Initialized
INFO - 2023-05-15 14:32:35 --> Loader Class Initialized
INFO - 2023-05-15 14:32:35 --> Helper loaded: url_helper
INFO - 2023-05-15 14:32:35 --> Helper loaded: form_helper
INFO - 2023-05-15 14:32:35 --> Database Driver Class Initialized
INFO - 2023-05-15 14:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 14:32:35 --> Form Validation Class Initialized
INFO - 2023-05-15 14:32:35 --> Controller Class Initialized
INFO - 2023-05-15 14:32:35 --> Model "m_user" initialized
INFO - 2023-05-15 14:32:35 --> Config Class Initialized
INFO - 2023-05-15 14:32:35 --> Hooks Class Initialized
INFO - 2023-05-15 14:32:35 --> Utf8 Class Initialized
INFO - 2023-05-15 14:32:35 --> URI Class Initialized
INFO - 2023-05-15 14:32:35 --> Router Class Initialized
INFO - 2023-05-15 14:32:35 --> Output Class Initialized
INFO - 2023-05-15 14:32:35 --> Security Class Initialized
INFO - 2023-05-15 14:32:35 --> Input Class Initialized
INFO - 2023-05-15 14:32:35 --> Language Class Initialized
INFO - 2023-05-15 14:32:35 --> Loader Class Initialized
INFO - 2023-05-15 14:32:35 --> Helper loaded: url_helper
INFO - 2023-05-15 14:32:35 --> Helper loaded: form_helper
INFO - 2023-05-15 14:32:35 --> Database Driver Class Initialized
INFO - 2023-05-15 14:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 14:32:35 --> Form Validation Class Initialized
INFO - 2023-05-15 14:32:35 --> Controller Class Initialized
INFO - 2023-05-15 14:32:35 --> Model "m_user" initialized
INFO - 2023-05-15 14:32:35 --> Model "m_datatrain" initialized
INFO - 2023-05-15 14:32:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 14:32:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 14:32:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 14:32:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 14:32:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 14:32:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-15 14:32:35 --> Final output sent to browser
INFO - 2023-05-15 14:32:38 --> Config Class Initialized
INFO - 2023-05-15 14:32:38 --> Hooks Class Initialized
INFO - 2023-05-15 14:32:38 --> Utf8 Class Initialized
INFO - 2023-05-15 14:32:38 --> URI Class Initialized
INFO - 2023-05-15 14:32:38 --> Router Class Initialized
INFO - 2023-05-15 14:32:38 --> Output Class Initialized
INFO - 2023-05-15 14:32:38 --> Security Class Initialized
INFO - 2023-05-15 14:32:38 --> Input Class Initialized
INFO - 2023-05-15 14:32:38 --> Language Class Initialized
INFO - 2023-05-15 14:32:38 --> Loader Class Initialized
INFO - 2023-05-15 14:32:38 --> Helper loaded: url_helper
INFO - 2023-05-15 14:32:38 --> Helper loaded: form_helper
INFO - 2023-05-15 14:32:38 --> Database Driver Class Initialized
INFO - 2023-05-15 14:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 14:32:38 --> Form Validation Class Initialized
INFO - 2023-05-15 14:32:38 --> Controller Class Initialized
INFO - 2023-05-15 14:32:38 --> Model "m_datatrain" initialized
INFO - 2023-05-15 14:32:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 14:32:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 14:32:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-15 14:32:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 14:32:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 14:32:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 14:32:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-15 14:32:38 --> Final output sent to browser
INFO - 2023-05-15 14:32:41 --> Config Class Initialized
INFO - 2023-05-15 14:32:41 --> Hooks Class Initialized
INFO - 2023-05-15 14:32:41 --> Utf8 Class Initialized
INFO - 2023-05-15 14:32:41 --> URI Class Initialized
INFO - 2023-05-15 14:32:41 --> Router Class Initialized
INFO - 2023-05-15 14:32:41 --> Output Class Initialized
INFO - 2023-05-15 14:32:41 --> Security Class Initialized
INFO - 2023-05-15 14:32:41 --> Input Class Initialized
INFO - 2023-05-15 14:32:41 --> Language Class Initialized
INFO - 2023-05-15 14:32:41 --> Loader Class Initialized
INFO - 2023-05-15 14:32:41 --> Helper loaded: url_helper
INFO - 2023-05-15 14:32:41 --> Helper loaded: form_helper
INFO - 2023-05-15 14:32:41 --> Database Driver Class Initialized
INFO - 2023-05-15 14:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 14:32:41 --> Form Validation Class Initialized
INFO - 2023-05-15 14:32:41 --> Controller Class Initialized
INFO - 2023-05-15 14:32:41 --> Model "m_datatest" initialized
INFO - 2023-05-15 14:32:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 14:32:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 14:32:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-15 14:32:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 14:32:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 14:32:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 14:32:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-15 14:32:41 --> Final output sent to browser
INFO - 2023-05-15 14:32:45 --> Config Class Initialized
INFO - 2023-05-15 14:32:45 --> Hooks Class Initialized
INFO - 2023-05-15 14:32:45 --> Utf8 Class Initialized
INFO - 2023-05-15 14:32:45 --> URI Class Initialized
INFO - 2023-05-15 14:32:45 --> Router Class Initialized
INFO - 2023-05-15 14:32:45 --> Output Class Initialized
INFO - 2023-05-15 14:32:45 --> Security Class Initialized
INFO - 2023-05-15 14:32:45 --> Input Class Initialized
INFO - 2023-05-15 14:32:45 --> Language Class Initialized
INFO - 2023-05-15 14:32:45 --> Loader Class Initialized
INFO - 2023-05-15 14:32:45 --> Helper loaded: url_helper
INFO - 2023-05-15 14:32:45 --> Helper loaded: form_helper
INFO - 2023-05-15 14:32:45 --> Database Driver Class Initialized
INFO - 2023-05-15 14:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 14:32:45 --> Form Validation Class Initialized
INFO - 2023-05-15 14:32:45 --> Controller Class Initialized
INFO - 2023-05-15 14:32:45 --> Model "m_user" initialized
INFO - 2023-05-15 14:32:46 --> Config Class Initialized
INFO - 2023-05-15 14:32:46 --> Hooks Class Initialized
INFO - 2023-05-15 14:32:46 --> Utf8 Class Initialized
INFO - 2023-05-15 14:32:46 --> URI Class Initialized
INFO - 2023-05-15 14:32:46 --> Router Class Initialized
INFO - 2023-05-15 14:32:46 --> Output Class Initialized
INFO - 2023-05-15 14:32:46 --> Security Class Initialized
INFO - 2023-05-15 14:32:46 --> Input Class Initialized
INFO - 2023-05-15 14:32:46 --> Language Class Initialized
INFO - 2023-05-15 14:32:46 --> Loader Class Initialized
INFO - 2023-05-15 14:32:46 --> Helper loaded: url_helper
INFO - 2023-05-15 14:32:46 --> Helper loaded: form_helper
INFO - 2023-05-15 14:32:46 --> Database Driver Class Initialized
INFO - 2023-05-15 14:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 14:32:46 --> Form Validation Class Initialized
INFO - 2023-05-15 14:32:46 --> Controller Class Initialized
INFO - 2023-05-15 14:32:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-15 14:32:46 --> Final output sent to browser
INFO - 2023-05-15 15:41:19 --> Config Class Initialized
INFO - 2023-05-15 15:41:19 --> Hooks Class Initialized
INFO - 2023-05-15 15:41:19 --> Utf8 Class Initialized
INFO - 2023-05-15 15:41:19 --> URI Class Initialized
INFO - 2023-05-15 15:41:19 --> Router Class Initialized
INFO - 2023-05-15 15:41:19 --> Output Class Initialized
INFO - 2023-05-15 15:41:19 --> Security Class Initialized
INFO - 2023-05-15 15:41:19 --> Input Class Initialized
INFO - 2023-05-15 15:41:19 --> Language Class Initialized
INFO - 2023-05-15 15:41:19 --> Loader Class Initialized
INFO - 2023-05-15 15:41:19 --> Helper loaded: url_helper
INFO - 2023-05-15 15:41:19 --> Helper loaded: form_helper
INFO - 2023-05-15 15:41:19 --> Database Driver Class Initialized
INFO - 2023-05-15 15:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 15:41:19 --> Form Validation Class Initialized
INFO - 2023-05-15 15:41:19 --> Controller Class Initialized
INFO - 2023-05-15 15:41:19 --> Model "m_user" initialized
INFO - 2023-05-15 15:41:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 15:41:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 15:41:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 15:41:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 15:41:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 15:41:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-15 15:41:20 --> Final output sent to browser
INFO - 2023-05-15 15:49:49 --> Config Class Initialized
INFO - 2023-05-15 15:49:49 --> Hooks Class Initialized
INFO - 2023-05-15 15:49:49 --> Utf8 Class Initialized
INFO - 2023-05-15 15:49:49 --> URI Class Initialized
INFO - 2023-05-15 15:49:49 --> Router Class Initialized
INFO - 2023-05-15 15:49:49 --> Output Class Initialized
INFO - 2023-05-15 15:49:49 --> Security Class Initialized
INFO - 2023-05-15 15:49:49 --> Input Class Initialized
INFO - 2023-05-15 15:49:49 --> Language Class Initialized
INFO - 2023-05-15 15:49:49 --> Loader Class Initialized
INFO - 2023-05-15 15:49:49 --> Helper loaded: url_helper
INFO - 2023-05-15 15:49:49 --> Helper loaded: form_helper
INFO - 2023-05-15 15:49:49 --> Database Driver Class Initialized
INFO - 2023-05-15 15:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 15:49:49 --> Form Validation Class Initialized
INFO - 2023-05-15 15:49:49 --> Controller Class Initialized
INFO - 2023-05-15 15:49:49 --> Model "m_datatrain" initialized
INFO - 2023-05-15 15:49:49 --> Model "m_datatest" initialized
INFO - 2023-05-15 15:49:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 15:49:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 15:49:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-15 15:49:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 15:49:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 15:49:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 15:49:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-15 15:49:49 --> Final output sent to browser
INFO - 2023-05-15 17:06:22 --> Config Class Initialized
INFO - 2023-05-15 17:06:22 --> Hooks Class Initialized
INFO - 2023-05-15 17:06:22 --> Utf8 Class Initialized
INFO - 2023-05-15 17:06:22 --> URI Class Initialized
INFO - 2023-05-15 17:06:22 --> Router Class Initialized
INFO - 2023-05-15 17:06:22 --> Output Class Initialized
INFO - 2023-05-15 17:06:22 --> Security Class Initialized
INFO - 2023-05-15 17:06:22 --> Input Class Initialized
INFO - 2023-05-15 17:06:22 --> Language Class Initialized
INFO - 2023-05-15 17:06:22 --> Loader Class Initialized
INFO - 2023-05-15 17:06:22 --> Helper loaded: url_helper
INFO - 2023-05-15 17:06:22 --> Helper loaded: form_helper
INFO - 2023-05-15 17:06:22 --> Database Driver Class Initialized
INFO - 2023-05-15 17:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:06:22 --> Form Validation Class Initialized
INFO - 2023-05-15 17:06:22 --> Controller Class Initialized
INFO - 2023-05-15 17:06:22 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:06:22 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:06:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 17:06:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 17:06:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-15 17:06:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 17:06:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 17:06:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 17:06:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-15 17:06:22 --> Final output sent to browser
INFO - 2023-05-15 17:06:27 --> Config Class Initialized
INFO - 2023-05-15 17:06:27 --> Hooks Class Initialized
INFO - 2023-05-15 17:06:27 --> Utf8 Class Initialized
INFO - 2023-05-15 17:06:27 --> URI Class Initialized
INFO - 2023-05-15 17:06:27 --> Router Class Initialized
INFO - 2023-05-15 17:06:27 --> Output Class Initialized
INFO - 2023-05-15 17:06:27 --> Security Class Initialized
INFO - 2023-05-15 17:06:27 --> Input Class Initialized
INFO - 2023-05-15 17:06:27 --> Language Class Initialized
INFO - 2023-05-15 17:06:27 --> Loader Class Initialized
INFO - 2023-05-15 17:06:27 --> Helper loaded: url_helper
INFO - 2023-05-15 17:06:27 --> Helper loaded: form_helper
INFO - 2023-05-15 17:06:27 --> Database Driver Class Initialized
INFO - 2023-05-15 17:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:06:27 --> Form Validation Class Initialized
INFO - 2023-05-15 17:06:27 --> Controller Class Initialized
INFO - 2023-05-15 17:06:27 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:06:27 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:06:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 17:06:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 17:06:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-15 17:06:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 17:06:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 17:06:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 17:06:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-15 17:06:27 --> Final output sent to browser
INFO - 2023-05-15 17:06:30 --> Config Class Initialized
INFO - 2023-05-15 17:06:30 --> Hooks Class Initialized
INFO - 2023-05-15 17:06:30 --> Utf8 Class Initialized
INFO - 2023-05-15 17:06:30 --> URI Class Initialized
INFO - 2023-05-15 17:06:30 --> Router Class Initialized
INFO - 2023-05-15 17:06:30 --> Output Class Initialized
INFO - 2023-05-15 17:06:30 --> Security Class Initialized
INFO - 2023-05-15 17:06:30 --> Input Class Initialized
INFO - 2023-05-15 17:06:30 --> Language Class Initialized
INFO - 2023-05-15 17:06:30 --> Loader Class Initialized
INFO - 2023-05-15 17:06:30 --> Helper loaded: url_helper
INFO - 2023-05-15 17:06:30 --> Helper loaded: form_helper
INFO - 2023-05-15 17:06:30 --> Database Driver Class Initialized
INFO - 2023-05-15 17:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:06:30 --> Form Validation Class Initialized
INFO - 2023-05-15 17:06:30 --> Controller Class Initialized
INFO - 2023-05-15 17:06:30 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:06:30 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:06:30 --> Final output sent to browser
INFO - 2023-05-15 17:07:05 --> Config Class Initialized
INFO - 2023-05-15 17:07:05 --> Hooks Class Initialized
INFO - 2023-05-15 17:07:05 --> Utf8 Class Initialized
INFO - 2023-05-15 17:07:05 --> URI Class Initialized
INFO - 2023-05-15 17:07:05 --> Router Class Initialized
INFO - 2023-05-15 17:07:05 --> Output Class Initialized
INFO - 2023-05-15 17:07:05 --> Security Class Initialized
INFO - 2023-05-15 17:07:05 --> Input Class Initialized
INFO - 2023-05-15 17:07:05 --> Language Class Initialized
INFO - 2023-05-15 17:07:05 --> Loader Class Initialized
INFO - 2023-05-15 17:07:05 --> Helper loaded: url_helper
INFO - 2023-05-15 17:07:05 --> Helper loaded: form_helper
INFO - 2023-05-15 17:07:05 --> Database Driver Class Initialized
INFO - 2023-05-15 17:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:07:05 --> Form Validation Class Initialized
INFO - 2023-05-15 17:07:05 --> Controller Class Initialized
INFO - 2023-05-15 17:07:05 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:07:05 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:07:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 354
INFO - 2023-05-15 17:07:05 --> Final output sent to browser
INFO - 2023-05-15 17:08:00 --> Config Class Initialized
INFO - 2023-05-15 17:08:00 --> Hooks Class Initialized
INFO - 2023-05-15 17:08:00 --> Utf8 Class Initialized
INFO - 2023-05-15 17:08:00 --> URI Class Initialized
INFO - 2023-05-15 17:08:00 --> Router Class Initialized
INFO - 2023-05-15 17:08:00 --> Output Class Initialized
INFO - 2023-05-15 17:08:00 --> Security Class Initialized
INFO - 2023-05-15 17:08:00 --> Input Class Initialized
INFO - 2023-05-15 17:08:00 --> Language Class Initialized
INFO - 2023-05-15 17:08:00 --> Loader Class Initialized
INFO - 2023-05-15 17:08:00 --> Helper loaded: url_helper
INFO - 2023-05-15 17:08:00 --> Helper loaded: form_helper
INFO - 2023-05-15 17:08:00 --> Database Driver Class Initialized
INFO - 2023-05-15 17:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:08:00 --> Form Validation Class Initialized
INFO - 2023-05-15 17:08:00 --> Controller Class Initialized
INFO - 2023-05-15 17:08:00 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:08:00 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:08:00 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 354
INFO - 2023-05-15 17:08:00 --> Final output sent to browser
INFO - 2023-05-15 17:08:01 --> Config Class Initialized
INFO - 2023-05-15 17:08:01 --> Hooks Class Initialized
INFO - 2023-05-15 17:08:01 --> Utf8 Class Initialized
INFO - 2023-05-15 17:08:01 --> URI Class Initialized
INFO - 2023-05-15 17:08:01 --> Router Class Initialized
INFO - 2023-05-15 17:08:01 --> Output Class Initialized
INFO - 2023-05-15 17:08:01 --> Security Class Initialized
INFO - 2023-05-15 17:08:01 --> Input Class Initialized
INFO - 2023-05-15 17:08:01 --> Language Class Initialized
INFO - 2023-05-15 17:08:01 --> Loader Class Initialized
INFO - 2023-05-15 17:08:01 --> Helper loaded: url_helper
INFO - 2023-05-15 17:08:01 --> Helper loaded: form_helper
INFO - 2023-05-15 17:08:01 --> Database Driver Class Initialized
INFO - 2023-05-15 17:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:08:01 --> Form Validation Class Initialized
INFO - 2023-05-15 17:08:01 --> Controller Class Initialized
INFO - 2023-05-15 17:08:01 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:08:01 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:08:01 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 354
INFO - 2023-05-15 17:08:01 --> Final output sent to browser
INFO - 2023-05-15 17:08:04 --> Config Class Initialized
INFO - 2023-05-15 17:08:04 --> Hooks Class Initialized
INFO - 2023-05-15 17:08:04 --> Utf8 Class Initialized
INFO - 2023-05-15 17:08:04 --> URI Class Initialized
INFO - 2023-05-15 17:08:04 --> Router Class Initialized
INFO - 2023-05-15 17:08:04 --> Output Class Initialized
INFO - 2023-05-15 17:08:04 --> Security Class Initialized
INFO - 2023-05-15 17:08:04 --> Input Class Initialized
INFO - 2023-05-15 17:08:04 --> Language Class Initialized
INFO - 2023-05-15 17:08:04 --> Loader Class Initialized
INFO - 2023-05-15 17:08:04 --> Helper loaded: url_helper
INFO - 2023-05-15 17:08:04 --> Helper loaded: form_helper
INFO - 2023-05-15 17:08:04 --> Database Driver Class Initialized
INFO - 2023-05-15 17:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:08:04 --> Form Validation Class Initialized
INFO - 2023-05-15 17:08:04 --> Controller Class Initialized
INFO - 2023-05-15 17:08:04 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:08:04 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:08:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 17:08:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 17:08:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-15 17:08:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-15 17:08:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 17:08:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 17:08:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-15 17:08:04 --> Final output sent to browser
INFO - 2023-05-15 17:08:18 --> Config Class Initialized
INFO - 2023-05-15 17:08:18 --> Hooks Class Initialized
INFO - 2023-05-15 17:08:18 --> Utf8 Class Initialized
INFO - 2023-05-15 17:08:18 --> URI Class Initialized
INFO - 2023-05-15 17:08:18 --> Router Class Initialized
INFO - 2023-05-15 17:08:18 --> Output Class Initialized
INFO - 2023-05-15 17:08:18 --> Security Class Initialized
INFO - 2023-05-15 17:08:18 --> Input Class Initialized
INFO - 2023-05-15 17:08:18 --> Language Class Initialized
INFO - 2023-05-15 17:08:18 --> Loader Class Initialized
INFO - 2023-05-15 17:08:18 --> Helper loaded: url_helper
INFO - 2023-05-15 17:08:18 --> Helper loaded: form_helper
INFO - 2023-05-15 17:08:18 --> Database Driver Class Initialized
INFO - 2023-05-15 17:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:08:18 --> Form Validation Class Initialized
INFO - 2023-05-15 17:08:18 --> Controller Class Initialized
INFO - 2023-05-15 17:08:18 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:08:18 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 354
INFO - 2023-05-15 17:08:18 --> Final output sent to browser
INFO - 2023-05-15 17:08:35 --> Config Class Initialized
INFO - 2023-05-15 17:08:35 --> Hooks Class Initialized
INFO - 2023-05-15 17:08:35 --> Utf8 Class Initialized
INFO - 2023-05-15 17:08:35 --> URI Class Initialized
INFO - 2023-05-15 17:08:35 --> Router Class Initialized
INFO - 2023-05-15 17:08:35 --> Output Class Initialized
INFO - 2023-05-15 17:08:35 --> Security Class Initialized
INFO - 2023-05-15 17:08:35 --> Input Class Initialized
INFO - 2023-05-15 17:08:35 --> Language Class Initialized
INFO - 2023-05-15 17:08:35 --> Loader Class Initialized
INFO - 2023-05-15 17:08:35 --> Helper loaded: url_helper
INFO - 2023-05-15 17:08:35 --> Helper loaded: form_helper
INFO - 2023-05-15 17:08:35 --> Database Driver Class Initialized
INFO - 2023-05-15 17:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:08:35 --> Form Validation Class Initialized
INFO - 2023-05-15 17:08:35 --> Controller Class Initialized
INFO - 2023-05-15 17:08:35 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:08:35 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:08:35 --> Final output sent to browser
INFO - 2023-05-15 17:09:58 --> Config Class Initialized
INFO - 2023-05-15 17:09:58 --> Hooks Class Initialized
INFO - 2023-05-15 17:09:58 --> Utf8 Class Initialized
INFO - 2023-05-15 17:09:58 --> URI Class Initialized
INFO - 2023-05-15 17:09:58 --> Router Class Initialized
INFO - 2023-05-15 17:09:58 --> Output Class Initialized
INFO - 2023-05-15 17:09:58 --> Security Class Initialized
INFO - 2023-05-15 17:09:58 --> Input Class Initialized
INFO - 2023-05-15 17:09:58 --> Language Class Initialized
INFO - 2023-05-15 17:09:58 --> Loader Class Initialized
INFO - 2023-05-15 17:09:58 --> Helper loaded: url_helper
INFO - 2023-05-15 17:09:58 --> Helper loaded: form_helper
INFO - 2023-05-15 17:09:58 --> Database Driver Class Initialized
INFO - 2023-05-15 17:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:09:58 --> Form Validation Class Initialized
INFO - 2023-05-15 17:09:58 --> Controller Class Initialized
INFO - 2023-05-15 17:09:58 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:09:58 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:09:58 --> Final output sent to browser
INFO - 2023-05-15 17:10:34 --> Config Class Initialized
INFO - 2023-05-15 17:10:34 --> Hooks Class Initialized
INFO - 2023-05-15 17:10:34 --> Utf8 Class Initialized
INFO - 2023-05-15 17:10:34 --> URI Class Initialized
INFO - 2023-05-15 17:10:34 --> Router Class Initialized
INFO - 2023-05-15 17:10:34 --> Output Class Initialized
INFO - 2023-05-15 17:10:34 --> Security Class Initialized
INFO - 2023-05-15 17:10:34 --> Input Class Initialized
INFO - 2023-05-15 17:10:34 --> Language Class Initialized
INFO - 2023-05-15 17:10:34 --> Loader Class Initialized
INFO - 2023-05-15 17:10:34 --> Helper loaded: url_helper
INFO - 2023-05-15 17:10:34 --> Helper loaded: form_helper
INFO - 2023-05-15 17:10:34 --> Database Driver Class Initialized
INFO - 2023-05-15 17:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:10:34 --> Form Validation Class Initialized
INFO - 2023-05-15 17:10:34 --> Controller Class Initialized
INFO - 2023-05-15 17:10:34 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:10:34 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:10:34 --> Query error: Not unique table/alias: 'datatraining' - Invalid query: SELECT count(*) as total, count(*) as totalitas
FROM `datatraining`, `datatraining`
WHERE `hasil` = 'berat'
AND `a1` = 'kos'
AND `hasil` = 'berat'
AND `a1` = 'kos'
INFO - 2023-05-15 17:10:34 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-15 17:13:20 --> Config Class Initialized
INFO - 2023-05-15 17:13:20 --> Hooks Class Initialized
INFO - 2023-05-15 17:13:20 --> Utf8 Class Initialized
INFO - 2023-05-15 17:13:20 --> URI Class Initialized
INFO - 2023-05-15 17:13:20 --> Router Class Initialized
INFO - 2023-05-15 17:13:20 --> Output Class Initialized
INFO - 2023-05-15 17:13:21 --> Security Class Initialized
INFO - 2023-05-15 17:13:21 --> Input Class Initialized
INFO - 2023-05-15 17:13:21 --> Language Class Initialized
INFO - 2023-05-15 17:13:21 --> Loader Class Initialized
INFO - 2023-05-15 17:13:21 --> Helper loaded: url_helper
INFO - 2023-05-15 17:13:21 --> Helper loaded: form_helper
INFO - 2023-05-15 17:13:21 --> Database Driver Class Initialized
INFO - 2023-05-15 17:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:13:21 --> Form Validation Class Initialized
INFO - 2023-05-15 17:13:21 --> Controller Class Initialized
INFO - 2023-05-15 17:13:21 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:13:21 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:13:21 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\sistemdiagnosa\application\models\m_datatrain.php 48
ERROR - 2023-05-15 17:13:21 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\sistemdiagnosa\application\models\m_datatrain.php 48
INFO - 2023-05-15 17:23:03 --> Config Class Initialized
INFO - 2023-05-15 17:23:03 --> Hooks Class Initialized
INFO - 2023-05-15 17:23:03 --> Utf8 Class Initialized
INFO - 2023-05-15 17:23:03 --> URI Class Initialized
INFO - 2023-05-15 17:23:03 --> Router Class Initialized
INFO - 2023-05-15 17:23:03 --> Output Class Initialized
INFO - 2023-05-15 17:23:03 --> Security Class Initialized
INFO - 2023-05-15 17:23:03 --> Input Class Initialized
INFO - 2023-05-15 17:23:03 --> Language Class Initialized
INFO - 2023-05-15 17:23:03 --> Loader Class Initialized
INFO - 2023-05-15 17:23:03 --> Helper loaded: url_helper
INFO - 2023-05-15 17:23:03 --> Helper loaded: form_helper
INFO - 2023-05-15 17:23:03 --> Database Driver Class Initialized
INFO - 2023-05-15 17:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:23:03 --> Form Validation Class Initialized
INFO - 2023-05-15 17:23:03 --> Controller Class Initialized
INFO - 2023-05-15 17:23:03 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:23:03 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:23:03 --> Final output sent to browser
INFO - 2023-05-15 17:24:49 --> Config Class Initialized
INFO - 2023-05-15 17:24:49 --> Hooks Class Initialized
INFO - 2023-05-15 17:24:49 --> Utf8 Class Initialized
INFO - 2023-05-15 17:24:49 --> URI Class Initialized
INFO - 2023-05-15 17:24:49 --> Router Class Initialized
INFO - 2023-05-15 17:24:49 --> Output Class Initialized
INFO - 2023-05-15 17:24:49 --> Security Class Initialized
INFO - 2023-05-15 17:24:49 --> Input Class Initialized
INFO - 2023-05-15 17:24:49 --> Language Class Initialized
INFO - 2023-05-15 17:24:49 --> Loader Class Initialized
INFO - 2023-05-15 17:24:49 --> Helper loaded: url_helper
INFO - 2023-05-15 17:24:49 --> Helper loaded: form_helper
INFO - 2023-05-15 17:24:49 --> Database Driver Class Initialized
INFO - 2023-05-15 17:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:24:49 --> Form Validation Class Initialized
INFO - 2023-05-15 17:24:49 --> Controller Class Initialized
INFO - 2023-05-15 17:24:49 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:24:49 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:24:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 348
INFO - 2023-05-15 17:24:49 --> Final output sent to browser
INFO - 2023-05-15 17:26:17 --> Config Class Initialized
INFO - 2023-05-15 17:26:17 --> Hooks Class Initialized
INFO - 2023-05-15 17:26:17 --> Utf8 Class Initialized
INFO - 2023-05-15 17:26:17 --> URI Class Initialized
INFO - 2023-05-15 17:26:17 --> Router Class Initialized
INFO - 2023-05-15 17:26:17 --> Output Class Initialized
INFO - 2023-05-15 17:26:17 --> Security Class Initialized
INFO - 2023-05-15 17:26:17 --> Input Class Initialized
INFO - 2023-05-15 17:26:17 --> Language Class Initialized
ERROR - 2023-05-15 17:26:17 --> Severity: Compile Error --> Cannot use [] for reading C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 348
INFO - 2023-05-15 17:26:28 --> Config Class Initialized
INFO - 2023-05-15 17:26:28 --> Hooks Class Initialized
INFO - 2023-05-15 17:26:28 --> Utf8 Class Initialized
INFO - 2023-05-15 17:26:28 --> URI Class Initialized
INFO - 2023-05-15 17:26:28 --> Router Class Initialized
INFO - 2023-05-15 17:26:28 --> Output Class Initialized
INFO - 2023-05-15 17:26:28 --> Security Class Initialized
INFO - 2023-05-15 17:26:28 --> Input Class Initialized
INFO - 2023-05-15 17:26:28 --> Language Class Initialized
INFO - 2023-05-15 17:26:28 --> Loader Class Initialized
INFO - 2023-05-15 17:26:28 --> Helper loaded: url_helper
INFO - 2023-05-15 17:26:28 --> Helper loaded: form_helper
INFO - 2023-05-15 17:26:28 --> Database Driver Class Initialized
INFO - 2023-05-15 17:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:26:28 --> Form Validation Class Initialized
INFO - 2023-05-15 17:26:28 --> Controller Class Initialized
INFO - 2023-05-15 17:26:28 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:26:28 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:26:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 348
INFO - 2023-05-15 17:26:28 --> Final output sent to browser
INFO - 2023-05-15 17:26:52 --> Config Class Initialized
INFO - 2023-05-15 17:26:52 --> Hooks Class Initialized
INFO - 2023-05-15 17:26:52 --> Utf8 Class Initialized
INFO - 2023-05-15 17:26:52 --> URI Class Initialized
INFO - 2023-05-15 17:26:52 --> Router Class Initialized
INFO - 2023-05-15 17:26:52 --> Output Class Initialized
INFO - 2023-05-15 17:26:52 --> Security Class Initialized
INFO - 2023-05-15 17:26:52 --> Input Class Initialized
INFO - 2023-05-15 17:26:52 --> Language Class Initialized
INFO - 2023-05-15 17:26:52 --> Loader Class Initialized
INFO - 2023-05-15 17:26:52 --> Helper loaded: url_helper
INFO - 2023-05-15 17:26:52 --> Helper loaded: form_helper
INFO - 2023-05-15 17:26:52 --> Database Driver Class Initialized
INFO - 2023-05-15 17:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:26:52 --> Form Validation Class Initialized
INFO - 2023-05-15 17:26:52 --> Controller Class Initialized
INFO - 2023-05-15 17:26:52 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:26:52 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:26:52 --> Final output sent to browser
INFO - 2023-05-15 17:28:09 --> Config Class Initialized
INFO - 2023-05-15 17:28:09 --> Hooks Class Initialized
INFO - 2023-05-15 17:28:09 --> Utf8 Class Initialized
INFO - 2023-05-15 17:28:09 --> URI Class Initialized
INFO - 2023-05-15 17:28:09 --> Router Class Initialized
INFO - 2023-05-15 17:28:09 --> Output Class Initialized
INFO - 2023-05-15 17:28:09 --> Security Class Initialized
INFO - 2023-05-15 17:28:09 --> Input Class Initialized
INFO - 2023-05-15 17:28:09 --> Language Class Initialized
INFO - 2023-05-15 17:28:09 --> Loader Class Initialized
INFO - 2023-05-15 17:28:09 --> Helper loaded: url_helper
INFO - 2023-05-15 17:28:09 --> Helper loaded: form_helper
INFO - 2023-05-15 17:28:09 --> Database Driver Class Initialized
INFO - 2023-05-15 17:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:28:09 --> Form Validation Class Initialized
INFO - 2023-05-15 17:28:09 --> Controller Class Initialized
INFO - 2023-05-15 17:28:09 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:28:09 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:28:09 --> Severity: Error --> Unsupported operand types C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 348
INFO - 2023-05-15 17:28:23 --> Config Class Initialized
INFO - 2023-05-15 17:28:23 --> Hooks Class Initialized
INFO - 2023-05-15 17:28:23 --> Utf8 Class Initialized
INFO - 2023-05-15 17:28:23 --> URI Class Initialized
INFO - 2023-05-15 17:28:23 --> Router Class Initialized
INFO - 2023-05-15 17:28:23 --> Output Class Initialized
INFO - 2023-05-15 17:28:23 --> Security Class Initialized
INFO - 2023-05-15 17:28:23 --> Input Class Initialized
INFO - 2023-05-15 17:28:23 --> Language Class Initialized
INFO - 2023-05-15 17:28:23 --> Loader Class Initialized
INFO - 2023-05-15 17:28:23 --> Helper loaded: url_helper
INFO - 2023-05-15 17:28:23 --> Helper loaded: form_helper
INFO - 2023-05-15 17:28:23 --> Database Driver Class Initialized
INFO - 2023-05-15 17:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:28:23 --> Form Validation Class Initialized
INFO - 2023-05-15 17:28:23 --> Controller Class Initialized
INFO - 2023-05-15 17:28:23 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:28:23 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:28:23 --> Severity: Error --> Unsupported operand types C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 348
INFO - 2023-05-15 17:28:35 --> Config Class Initialized
INFO - 2023-05-15 17:28:35 --> Hooks Class Initialized
INFO - 2023-05-15 17:28:35 --> Utf8 Class Initialized
INFO - 2023-05-15 17:28:35 --> URI Class Initialized
INFO - 2023-05-15 17:28:35 --> Router Class Initialized
INFO - 2023-05-15 17:28:35 --> Output Class Initialized
INFO - 2023-05-15 17:28:35 --> Security Class Initialized
INFO - 2023-05-15 17:28:35 --> Input Class Initialized
INFO - 2023-05-15 17:28:35 --> Language Class Initialized
INFO - 2023-05-15 17:28:35 --> Loader Class Initialized
INFO - 2023-05-15 17:28:35 --> Helper loaded: url_helper
INFO - 2023-05-15 17:28:35 --> Helper loaded: form_helper
INFO - 2023-05-15 17:28:35 --> Database Driver Class Initialized
INFO - 2023-05-15 17:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:28:35 --> Form Validation Class Initialized
INFO - 2023-05-15 17:28:35 --> Controller Class Initialized
INFO - 2023-05-15 17:28:35 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:28:35 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:28:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 348
INFO - 2023-05-15 17:28:35 --> Final output sent to browser
INFO - 2023-05-15 17:28:48 --> Config Class Initialized
INFO - 2023-05-15 17:28:48 --> Hooks Class Initialized
INFO - 2023-05-15 17:28:48 --> Utf8 Class Initialized
INFO - 2023-05-15 17:28:48 --> URI Class Initialized
INFO - 2023-05-15 17:28:48 --> Router Class Initialized
INFO - 2023-05-15 17:28:48 --> Output Class Initialized
INFO - 2023-05-15 17:28:48 --> Security Class Initialized
INFO - 2023-05-15 17:28:48 --> Input Class Initialized
INFO - 2023-05-15 17:28:48 --> Language Class Initialized
INFO - 2023-05-15 17:28:48 --> Loader Class Initialized
INFO - 2023-05-15 17:28:48 --> Helper loaded: url_helper
INFO - 2023-05-15 17:28:48 --> Helper loaded: form_helper
INFO - 2023-05-15 17:28:48 --> Database Driver Class Initialized
INFO - 2023-05-15 17:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:28:49 --> Form Validation Class Initialized
INFO - 2023-05-15 17:28:49 --> Controller Class Initialized
INFO - 2023-05-15 17:28:49 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:28:49 --> Model "m_datatest" initialized
ERROR - 2023-05-15 17:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 348
INFO - 2023-05-15 17:28:49 --> Final output sent to browser
INFO - 2023-05-15 17:29:53 --> Config Class Initialized
INFO - 2023-05-15 17:29:53 --> Hooks Class Initialized
INFO - 2023-05-15 17:29:53 --> Utf8 Class Initialized
INFO - 2023-05-15 17:29:53 --> URI Class Initialized
INFO - 2023-05-15 17:29:53 --> Router Class Initialized
INFO - 2023-05-15 17:29:53 --> Output Class Initialized
INFO - 2023-05-15 17:29:53 --> Security Class Initialized
INFO - 2023-05-15 17:29:53 --> Input Class Initialized
INFO - 2023-05-15 17:29:53 --> Language Class Initialized
INFO - 2023-05-15 17:29:53 --> Loader Class Initialized
INFO - 2023-05-15 17:29:53 --> Helper loaded: url_helper
INFO - 2023-05-15 17:29:53 --> Helper loaded: form_helper
INFO - 2023-05-15 17:29:53 --> Database Driver Class Initialized
INFO - 2023-05-15 17:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:29:53 --> Form Validation Class Initialized
INFO - 2023-05-15 17:29:53 --> Controller Class Initialized
ERROR - 2023-05-15 17:29:53 --> Severity: Parsing Error --> syntax error, unexpected '*' C:\xampp\htdocs\sistemdiagnosa\application\models\m_datatrain.php 44
INFO - 2023-05-15 17:30:16 --> Config Class Initialized
INFO - 2023-05-15 17:30:16 --> Hooks Class Initialized
INFO - 2023-05-15 17:30:16 --> Utf8 Class Initialized
INFO - 2023-05-15 17:30:16 --> URI Class Initialized
INFO - 2023-05-15 17:30:16 --> Router Class Initialized
INFO - 2023-05-15 17:30:16 --> Output Class Initialized
INFO - 2023-05-15 17:30:16 --> Security Class Initialized
INFO - 2023-05-15 17:30:16 --> Input Class Initialized
INFO - 2023-05-15 17:30:16 --> Language Class Initialized
INFO - 2023-05-15 17:30:16 --> Loader Class Initialized
INFO - 2023-05-15 17:30:16 --> Helper loaded: url_helper
INFO - 2023-05-15 17:30:16 --> Helper loaded: form_helper
INFO - 2023-05-15 17:30:16 --> Database Driver Class Initialized
INFO - 2023-05-15 17:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:30:16 --> Form Validation Class Initialized
INFO - 2023-05-15 17:30:16 --> Controller Class Initialized
INFO - 2023-05-15 17:30:16 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:30:16 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:30:16 --> Final output sent to browser
INFO - 2023-05-15 17:31:09 --> Config Class Initialized
INFO - 2023-05-15 17:31:09 --> Hooks Class Initialized
INFO - 2023-05-15 17:31:09 --> Utf8 Class Initialized
INFO - 2023-05-15 17:31:09 --> URI Class Initialized
INFO - 2023-05-15 17:31:09 --> Router Class Initialized
INFO - 2023-05-15 17:31:09 --> Output Class Initialized
INFO - 2023-05-15 17:31:09 --> Security Class Initialized
INFO - 2023-05-15 17:31:09 --> Input Class Initialized
INFO - 2023-05-15 17:31:09 --> Language Class Initialized
INFO - 2023-05-15 17:31:09 --> Loader Class Initialized
INFO - 2023-05-15 17:31:09 --> Helper loaded: url_helper
INFO - 2023-05-15 17:31:09 --> Helper loaded: form_helper
INFO - 2023-05-15 17:31:09 --> Database Driver Class Initialized
INFO - 2023-05-15 17:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:31:09 --> Form Validation Class Initialized
INFO - 2023-05-15 17:31:09 --> Controller Class Initialized
INFO - 2023-05-15 17:31:09 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:31:09 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:31:09 --> Final output sent to browser
INFO - 2023-05-15 17:34:23 --> Config Class Initialized
INFO - 2023-05-15 17:34:23 --> Hooks Class Initialized
INFO - 2023-05-15 17:34:23 --> Utf8 Class Initialized
INFO - 2023-05-15 17:34:23 --> URI Class Initialized
INFO - 2023-05-15 17:34:23 --> Router Class Initialized
INFO - 2023-05-15 17:34:23 --> Output Class Initialized
INFO - 2023-05-15 17:34:23 --> Security Class Initialized
INFO - 2023-05-15 17:34:23 --> Input Class Initialized
INFO - 2023-05-15 17:34:23 --> Language Class Initialized
INFO - 2023-05-15 17:34:23 --> Loader Class Initialized
INFO - 2023-05-15 17:34:23 --> Helper loaded: url_helper
INFO - 2023-05-15 17:34:23 --> Helper loaded: form_helper
INFO - 2023-05-15 17:34:23 --> Database Driver Class Initialized
INFO - 2023-05-15 17:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:34:23 --> Form Validation Class Initialized
INFO - 2023-05-15 17:34:23 --> Controller Class Initialized
INFO - 2023-05-15 17:34:23 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:34:23 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:34:23 --> Final output sent to browser
INFO - 2023-05-15 17:37:14 --> Config Class Initialized
INFO - 2023-05-15 17:37:14 --> Hooks Class Initialized
INFO - 2023-05-15 17:37:14 --> Utf8 Class Initialized
INFO - 2023-05-15 17:37:14 --> URI Class Initialized
INFO - 2023-05-15 17:37:14 --> Router Class Initialized
INFO - 2023-05-15 17:37:14 --> Output Class Initialized
INFO - 2023-05-15 17:37:14 --> Security Class Initialized
INFO - 2023-05-15 17:37:14 --> Input Class Initialized
INFO - 2023-05-15 17:37:14 --> Language Class Initialized
INFO - 2023-05-15 17:37:14 --> Loader Class Initialized
INFO - 2023-05-15 17:37:14 --> Helper loaded: url_helper
INFO - 2023-05-15 17:37:14 --> Helper loaded: form_helper
INFO - 2023-05-15 17:37:14 --> Database Driver Class Initialized
INFO - 2023-05-15 17:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:37:14 --> Form Validation Class Initialized
INFO - 2023-05-15 17:37:14 --> Controller Class Initialized
INFO - 2023-05-15 17:37:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-15 17:37:14 --> Final output sent to browser
INFO - 2023-05-15 17:37:16 --> Config Class Initialized
INFO - 2023-05-15 17:37:16 --> Hooks Class Initialized
INFO - 2023-05-15 17:37:16 --> Utf8 Class Initialized
INFO - 2023-05-15 17:37:16 --> URI Class Initialized
INFO - 2023-05-15 17:37:16 --> Router Class Initialized
INFO - 2023-05-15 17:37:16 --> Output Class Initialized
INFO - 2023-05-15 17:37:16 --> Security Class Initialized
INFO - 2023-05-15 17:37:16 --> Input Class Initialized
INFO - 2023-05-15 17:37:16 --> Language Class Initialized
INFO - 2023-05-15 17:37:16 --> Loader Class Initialized
INFO - 2023-05-15 17:37:16 --> Helper loaded: url_helper
INFO - 2023-05-15 17:37:16 --> Helper loaded: form_helper
INFO - 2023-05-15 17:37:16 --> Database Driver Class Initialized
INFO - 2023-05-15 17:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:37:16 --> Form Validation Class Initialized
INFO - 2023-05-15 17:37:16 --> Controller Class Initialized
INFO - 2023-05-15 17:37:16 --> Model "m_user" initialized
INFO - 2023-05-15 17:37:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-15 17:37:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-15 17:37:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-15 17:37:16 --> Final output sent to browser
INFO - 2023-05-15 17:37:20 --> Config Class Initialized
INFO - 2023-05-15 17:37:20 --> Hooks Class Initialized
INFO - 2023-05-15 17:37:20 --> Utf8 Class Initialized
INFO - 2023-05-15 17:37:20 --> URI Class Initialized
INFO - 2023-05-15 17:37:20 --> Router Class Initialized
INFO - 2023-05-15 17:37:20 --> Output Class Initialized
INFO - 2023-05-15 17:37:20 --> Security Class Initialized
INFO - 2023-05-15 17:37:20 --> Input Class Initialized
INFO - 2023-05-15 17:37:20 --> Language Class Initialized
INFO - 2023-05-15 17:37:20 --> Loader Class Initialized
INFO - 2023-05-15 17:37:20 --> Helper loaded: url_helper
INFO - 2023-05-15 17:37:20 --> Helper loaded: form_helper
INFO - 2023-05-15 17:37:20 --> Database Driver Class Initialized
INFO - 2023-05-15 17:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:37:20 --> Form Validation Class Initialized
INFO - 2023-05-15 17:37:20 --> Controller Class Initialized
INFO - 2023-05-15 17:37:20 --> Model "m_user" initialized
INFO - 2023-05-15 17:37:20 --> Config Class Initialized
INFO - 2023-05-15 17:37:20 --> Hooks Class Initialized
INFO - 2023-05-15 17:37:20 --> Utf8 Class Initialized
INFO - 2023-05-15 17:37:20 --> URI Class Initialized
INFO - 2023-05-15 17:37:20 --> Router Class Initialized
INFO - 2023-05-15 17:37:20 --> Output Class Initialized
INFO - 2023-05-15 17:37:20 --> Security Class Initialized
INFO - 2023-05-15 17:37:20 --> Input Class Initialized
INFO - 2023-05-15 17:37:20 --> Language Class Initialized
INFO - 2023-05-15 17:37:20 --> Loader Class Initialized
INFO - 2023-05-15 17:37:20 --> Helper loaded: url_helper
INFO - 2023-05-15 17:37:20 --> Helper loaded: form_helper
INFO - 2023-05-15 17:37:20 --> Database Driver Class Initialized
INFO - 2023-05-15 17:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:37:20 --> Form Validation Class Initialized
INFO - 2023-05-15 17:37:20 --> Controller Class Initialized
INFO - 2023-05-15 17:37:20 --> Model "m_user" initialized
INFO - 2023-05-15 17:37:20 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 17:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 17:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 17:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 17:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 17:37:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-15 17:37:20 --> Final output sent to browser
INFO - 2023-05-15 17:37:22 --> Config Class Initialized
INFO - 2023-05-15 17:37:22 --> Hooks Class Initialized
INFO - 2023-05-15 17:37:22 --> Utf8 Class Initialized
INFO - 2023-05-15 17:37:22 --> URI Class Initialized
INFO - 2023-05-15 17:37:22 --> Router Class Initialized
INFO - 2023-05-15 17:37:22 --> Output Class Initialized
INFO - 2023-05-15 17:37:22 --> Security Class Initialized
INFO - 2023-05-15 17:37:22 --> Input Class Initialized
INFO - 2023-05-15 17:37:22 --> Language Class Initialized
INFO - 2023-05-15 17:37:22 --> Loader Class Initialized
INFO - 2023-05-15 17:37:22 --> Helper loaded: url_helper
INFO - 2023-05-15 17:37:22 --> Helper loaded: form_helper
INFO - 2023-05-15 17:37:22 --> Database Driver Class Initialized
INFO - 2023-05-15 17:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:37:22 --> Form Validation Class Initialized
INFO - 2023-05-15 17:37:22 --> Controller Class Initialized
INFO - 2023-05-15 17:37:22 --> Model "m_datatest" initialized
INFO - 2023-05-15 17:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 17:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 17:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-15 17:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 17:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 17:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 17:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-15 17:37:22 --> Final output sent to browser
INFO - 2023-05-15 17:37:23 --> Config Class Initialized
INFO - 2023-05-15 17:37:23 --> Hooks Class Initialized
INFO - 2023-05-15 17:37:23 --> Utf8 Class Initialized
INFO - 2023-05-15 17:37:23 --> URI Class Initialized
INFO - 2023-05-15 17:37:23 --> Router Class Initialized
INFO - 2023-05-15 17:37:23 --> Output Class Initialized
INFO - 2023-05-15 17:37:23 --> Security Class Initialized
INFO - 2023-05-15 17:37:23 --> Input Class Initialized
INFO - 2023-05-15 17:37:23 --> Language Class Initialized
INFO - 2023-05-15 17:37:23 --> Loader Class Initialized
INFO - 2023-05-15 17:37:23 --> Helper loaded: url_helper
INFO - 2023-05-15 17:37:23 --> Helper loaded: form_helper
INFO - 2023-05-15 17:37:23 --> Database Driver Class Initialized
INFO - 2023-05-15 17:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-15 17:37:23 --> Form Validation Class Initialized
INFO - 2023-05-15 17:37:23 --> Controller Class Initialized
INFO - 2023-05-15 17:37:23 --> Model "m_datatrain" initialized
INFO - 2023-05-15 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-15 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-15 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-15 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-15 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-15 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-15 17:37:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-15 17:37:23 --> Final output sent to browser
