<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-17 06:40:02 --> Config Class Initialized
INFO - 2022-03-17 06:40:02 --> Hooks Class Initialized
INFO - 2022-03-17 06:40:03 --> Utf8 Class Initialized
INFO - 2022-03-17 06:40:03 --> URI Class Initialized
INFO - 2022-03-17 06:40:03 --> Router Class Initialized
INFO - 2022-03-17 06:40:03 --> Output Class Initialized
INFO - 2022-03-17 06:40:03 --> Security Class Initialized
INFO - 2022-03-17 06:40:03 --> Input Class Initialized
INFO - 2022-03-17 06:40:03 --> Language Class Initialized
INFO - 2022-03-17 06:40:03 --> Loader Class Initialized
INFO - 2022-03-17 06:40:03 --> Helper loaded: url_helper
INFO - 2022-03-17 06:40:03 --> Helper loaded: form_helper
INFO - 2022-03-17 06:40:03 --> Database Driver Class Initialized
INFO - 2022-03-17 06:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:40:03 --> Controller Class Initialized
INFO - 2022-03-17 06:40:04 --> Model "M_todo_group" initialized
INFO - 2022-03-17 06:40:04 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 06:40:04 --> Form Validation Class Initialized
INFO - 2022-03-17 06:40:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 06:40:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 06:40:04 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 06:40:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 06:40:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 06:40:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 06:40:04 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 06:40:04 --> Final output sent to browser
INFO - 2022-03-17 06:41:24 --> Config Class Initialized
INFO - 2022-03-17 06:41:24 --> Hooks Class Initialized
INFO - 2022-03-17 06:41:24 --> Utf8 Class Initialized
INFO - 2022-03-17 06:41:24 --> URI Class Initialized
INFO - 2022-03-17 06:41:24 --> Router Class Initialized
INFO - 2022-03-17 06:41:24 --> Output Class Initialized
INFO - 2022-03-17 06:41:24 --> Security Class Initialized
INFO - 2022-03-17 06:41:24 --> Input Class Initialized
INFO - 2022-03-17 06:41:24 --> Language Class Initialized
INFO - 2022-03-17 06:41:24 --> Loader Class Initialized
INFO - 2022-03-17 06:41:24 --> Helper loaded: url_helper
INFO - 2022-03-17 06:41:24 --> Helper loaded: form_helper
INFO - 2022-03-17 06:41:24 --> Database Driver Class Initialized
INFO - 2022-03-17 06:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:41:24 --> Controller Class Initialized
INFO - 2022-03-17 06:41:24 --> Model "M_todo_group" initialized
INFO - 2022-03-17 06:41:24 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 06:41:24 --> Form Validation Class Initialized
INFO - 2022-03-17 06:41:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 06:41:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 06:41:24 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 06:41:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 06:41:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 06:41:24 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 06:41:24 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 06:41:24 --> Final output sent to browser
INFO - 2022-03-17 06:41:43 --> Config Class Initialized
INFO - 2022-03-17 06:41:43 --> Hooks Class Initialized
INFO - 2022-03-17 06:41:43 --> Utf8 Class Initialized
INFO - 2022-03-17 06:41:43 --> URI Class Initialized
INFO - 2022-03-17 06:41:43 --> Router Class Initialized
INFO - 2022-03-17 06:41:43 --> Output Class Initialized
INFO - 2022-03-17 06:41:43 --> Security Class Initialized
INFO - 2022-03-17 06:41:43 --> Input Class Initialized
INFO - 2022-03-17 06:41:43 --> Language Class Initialized
INFO - 2022-03-17 06:41:43 --> Loader Class Initialized
INFO - 2022-03-17 06:41:43 --> Helper loaded: url_helper
INFO - 2022-03-17 06:41:43 --> Helper loaded: form_helper
INFO - 2022-03-17 06:41:43 --> Database Driver Class Initialized
INFO - 2022-03-17 06:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:41:43 --> Controller Class Initialized
INFO - 2022-03-17 06:41:43 --> Model "M_tutor" initialized
INFO - 2022-03-17 06:41:43 --> Final output sent to browser
INFO - 2022-03-17 06:42:53 --> Config Class Initialized
INFO - 2022-03-17 06:42:53 --> Hooks Class Initialized
INFO - 2022-03-17 06:42:53 --> Utf8 Class Initialized
INFO - 2022-03-17 06:42:53 --> URI Class Initialized
INFO - 2022-03-17 06:42:53 --> Router Class Initialized
INFO - 2022-03-17 06:42:53 --> Output Class Initialized
INFO - 2022-03-17 06:42:53 --> Security Class Initialized
INFO - 2022-03-17 06:42:53 --> Input Class Initialized
INFO - 2022-03-17 06:42:53 --> Language Class Initialized
INFO - 2022-03-17 06:42:53 --> Loader Class Initialized
INFO - 2022-03-17 06:42:53 --> Helper loaded: url_helper
INFO - 2022-03-17 06:42:53 --> Helper loaded: form_helper
INFO - 2022-03-17 06:42:53 --> Database Driver Class Initialized
INFO - 2022-03-17 06:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:42:53 --> Controller Class Initialized
INFO - 2022-03-17 06:42:53 --> Model "M_tutor" initialized
INFO - 2022-03-17 06:42:53 --> Final output sent to browser
INFO - 2022-03-17 06:43:02 --> Config Class Initialized
INFO - 2022-03-17 06:43:02 --> Hooks Class Initialized
INFO - 2022-03-17 06:43:02 --> Utf8 Class Initialized
INFO - 2022-03-17 06:43:02 --> URI Class Initialized
INFO - 2022-03-17 06:43:02 --> Router Class Initialized
INFO - 2022-03-17 06:43:02 --> Output Class Initialized
INFO - 2022-03-17 06:43:02 --> Security Class Initialized
INFO - 2022-03-17 06:43:02 --> Input Class Initialized
INFO - 2022-03-17 06:43:02 --> Language Class Initialized
INFO - 2022-03-17 06:43:02 --> Loader Class Initialized
INFO - 2022-03-17 06:43:02 --> Helper loaded: url_helper
INFO - 2022-03-17 06:43:02 --> Helper loaded: form_helper
INFO - 2022-03-17 06:43:02 --> Database Driver Class Initialized
INFO - 2022-03-17 06:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:43:02 --> Controller Class Initialized
INFO - 2022-03-17 06:43:02 --> Model "M_tutor" initialized
INFO - 2022-03-17 06:43:02 --> Final output sent to browser
INFO - 2022-03-17 06:43:05 --> Config Class Initialized
INFO - 2022-03-17 06:43:05 --> Hooks Class Initialized
INFO - 2022-03-17 06:43:05 --> Utf8 Class Initialized
INFO - 2022-03-17 06:43:05 --> URI Class Initialized
INFO - 2022-03-17 06:43:05 --> Router Class Initialized
INFO - 2022-03-17 06:43:05 --> Output Class Initialized
INFO - 2022-03-17 06:43:05 --> Security Class Initialized
INFO - 2022-03-17 06:43:05 --> Input Class Initialized
INFO - 2022-03-17 06:43:05 --> Language Class Initialized
INFO - 2022-03-17 06:43:05 --> Loader Class Initialized
INFO - 2022-03-17 06:43:05 --> Helper loaded: url_helper
INFO - 2022-03-17 06:43:05 --> Helper loaded: form_helper
INFO - 2022-03-17 06:43:05 --> Database Driver Class Initialized
INFO - 2022-03-17 06:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:43:05 --> Controller Class Initialized
INFO - 2022-03-17 06:43:05 --> Model "M_tutor" initialized
INFO - 2022-03-17 06:43:05 --> Final output sent to browser
INFO - 2022-03-17 06:43:07 --> Config Class Initialized
INFO - 2022-03-17 06:43:07 --> Hooks Class Initialized
INFO - 2022-03-17 06:43:07 --> Utf8 Class Initialized
INFO - 2022-03-17 06:43:07 --> URI Class Initialized
INFO - 2022-03-17 06:43:07 --> Router Class Initialized
INFO - 2022-03-17 06:43:07 --> Output Class Initialized
INFO - 2022-03-17 06:43:07 --> Security Class Initialized
INFO - 2022-03-17 06:43:07 --> Input Class Initialized
INFO - 2022-03-17 06:43:07 --> Language Class Initialized
INFO - 2022-03-17 06:43:07 --> Loader Class Initialized
INFO - 2022-03-17 06:43:07 --> Helper loaded: url_helper
INFO - 2022-03-17 06:43:07 --> Helper loaded: form_helper
INFO - 2022-03-17 06:43:07 --> Database Driver Class Initialized
INFO - 2022-03-17 06:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:43:07 --> Controller Class Initialized
INFO - 2022-03-17 06:43:07 --> Model "M_tutor" initialized
INFO - 2022-03-17 06:43:08 --> Final output sent to browser
INFO - 2022-03-17 06:43:18 --> Config Class Initialized
INFO - 2022-03-17 06:43:18 --> Hooks Class Initialized
INFO - 2022-03-17 06:43:18 --> Utf8 Class Initialized
INFO - 2022-03-17 06:43:18 --> URI Class Initialized
INFO - 2022-03-17 06:43:18 --> Router Class Initialized
INFO - 2022-03-17 06:43:18 --> Output Class Initialized
INFO - 2022-03-17 06:43:18 --> Security Class Initialized
INFO - 2022-03-17 06:43:18 --> Input Class Initialized
INFO - 2022-03-17 06:43:18 --> Language Class Initialized
INFO - 2022-03-17 06:43:18 --> Loader Class Initialized
INFO - 2022-03-17 06:43:18 --> Helper loaded: url_helper
INFO - 2022-03-17 06:43:18 --> Helper loaded: form_helper
INFO - 2022-03-17 06:43:18 --> Database Driver Class Initialized
INFO - 2022-03-17 06:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:43:18 --> Controller Class Initialized
INFO - 2022-03-17 06:43:18 --> Model "M_todo_group" initialized
INFO - 2022-03-17 06:43:18 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 06:43:18 --> Form Validation Class Initialized
INFO - 2022-03-17 06:43:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 06:43:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 06:43:18 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 06:43:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 06:43:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 06:43:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 06:43:19 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 06:43:19 --> Final output sent to browser
INFO - 2022-03-17 06:43:22 --> Config Class Initialized
INFO - 2022-03-17 06:43:22 --> Hooks Class Initialized
INFO - 2022-03-17 06:43:22 --> Utf8 Class Initialized
INFO - 2022-03-17 06:43:22 --> URI Class Initialized
INFO - 2022-03-17 06:43:22 --> Router Class Initialized
INFO - 2022-03-17 06:43:22 --> Output Class Initialized
INFO - 2022-03-17 06:43:22 --> Security Class Initialized
INFO - 2022-03-17 06:43:22 --> Input Class Initialized
INFO - 2022-03-17 06:43:22 --> Language Class Initialized
INFO - 2022-03-17 06:43:22 --> Loader Class Initialized
INFO - 2022-03-17 06:43:22 --> Helper loaded: url_helper
INFO - 2022-03-17 06:43:22 --> Helper loaded: form_helper
INFO - 2022-03-17 06:43:22 --> Database Driver Class Initialized
INFO - 2022-03-17 06:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:43:22 --> Controller Class Initialized
INFO - 2022-03-17 06:43:22 --> Model "M_tutor" initialized
INFO - 2022-03-17 06:43:22 --> Final output sent to browser
INFO - 2022-03-17 06:43:47 --> Config Class Initialized
INFO - 2022-03-17 06:43:47 --> Hooks Class Initialized
INFO - 2022-03-17 06:43:47 --> Utf8 Class Initialized
INFO - 2022-03-17 06:43:47 --> URI Class Initialized
INFO - 2022-03-17 06:43:47 --> Router Class Initialized
INFO - 2022-03-17 06:43:47 --> Output Class Initialized
INFO - 2022-03-17 06:43:47 --> Security Class Initialized
INFO - 2022-03-17 06:43:47 --> Input Class Initialized
INFO - 2022-03-17 06:43:47 --> Language Class Initialized
INFO - 2022-03-17 06:43:47 --> Loader Class Initialized
INFO - 2022-03-17 06:43:47 --> Helper loaded: url_helper
INFO - 2022-03-17 06:43:47 --> Helper loaded: form_helper
INFO - 2022-03-17 06:43:47 --> Database Driver Class Initialized
INFO - 2022-03-17 06:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:43:47 --> Controller Class Initialized
INFO - 2022-03-17 06:43:47 --> Model "M_tutor" initialized
INFO - 2022-03-17 06:43:47 --> Final output sent to browser
INFO - 2022-03-17 06:44:17 --> Config Class Initialized
INFO - 2022-03-17 06:44:17 --> Hooks Class Initialized
INFO - 2022-03-17 06:44:17 --> Utf8 Class Initialized
INFO - 2022-03-17 06:44:17 --> URI Class Initialized
INFO - 2022-03-17 06:44:17 --> Router Class Initialized
INFO - 2022-03-17 06:44:17 --> Output Class Initialized
INFO - 2022-03-17 06:44:17 --> Security Class Initialized
INFO - 2022-03-17 06:44:17 --> Input Class Initialized
INFO - 2022-03-17 06:44:17 --> Language Class Initialized
INFO - 2022-03-17 06:44:17 --> Loader Class Initialized
INFO - 2022-03-17 06:44:17 --> Helper loaded: url_helper
INFO - 2022-03-17 06:44:17 --> Helper loaded: form_helper
INFO - 2022-03-17 06:44:17 --> Database Driver Class Initialized
INFO - 2022-03-17 06:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:44:17 --> Controller Class Initialized
INFO - 2022-03-17 06:44:17 --> Model "M_todo_group" initialized
INFO - 2022-03-17 06:44:17 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 06:44:17 --> Form Validation Class Initialized
INFO - 2022-03-17 06:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 06:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 06:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 06:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 06:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 06:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 06:44:17 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 06:44:17 --> Final output sent to browser
INFO - 2022-03-17 06:44:24 --> Config Class Initialized
INFO - 2022-03-17 06:44:24 --> Hooks Class Initialized
INFO - 2022-03-17 06:44:24 --> Utf8 Class Initialized
INFO - 2022-03-17 06:44:24 --> URI Class Initialized
INFO - 2022-03-17 06:44:24 --> Router Class Initialized
INFO - 2022-03-17 06:44:24 --> Output Class Initialized
INFO - 2022-03-17 06:44:24 --> Security Class Initialized
INFO - 2022-03-17 06:44:24 --> Input Class Initialized
INFO - 2022-03-17 06:44:24 --> Language Class Initialized
INFO - 2022-03-17 06:44:24 --> Loader Class Initialized
INFO - 2022-03-17 06:44:24 --> Helper loaded: url_helper
INFO - 2022-03-17 06:44:24 --> Helper loaded: form_helper
INFO - 2022-03-17 06:44:24 --> Database Driver Class Initialized
INFO - 2022-03-17 06:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:44:24 --> Controller Class Initialized
INFO - 2022-03-17 06:44:24 --> Model "M_tutor" initialized
INFO - 2022-03-17 06:44:24 --> Final output sent to browser
INFO - 2022-03-17 06:44:27 --> Config Class Initialized
INFO - 2022-03-17 06:44:27 --> Hooks Class Initialized
INFO - 2022-03-17 06:44:27 --> Utf8 Class Initialized
INFO - 2022-03-17 06:44:27 --> URI Class Initialized
INFO - 2022-03-17 06:44:27 --> Router Class Initialized
INFO - 2022-03-17 06:44:27 --> Output Class Initialized
INFO - 2022-03-17 06:44:27 --> Security Class Initialized
INFO - 2022-03-17 06:44:27 --> Input Class Initialized
INFO - 2022-03-17 06:44:27 --> Language Class Initialized
INFO - 2022-03-17 06:44:27 --> Loader Class Initialized
INFO - 2022-03-17 06:44:27 --> Helper loaded: url_helper
INFO - 2022-03-17 06:44:27 --> Helper loaded: form_helper
INFO - 2022-03-17 06:44:27 --> Database Driver Class Initialized
INFO - 2022-03-17 06:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:44:27 --> Controller Class Initialized
INFO - 2022-03-17 06:44:27 --> Model "M_todo_group" initialized
INFO - 2022-03-17 06:44:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 06:44:27 --> Form Validation Class Initialized
INFO - 2022-03-17 06:44:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 06:44:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 06:44:27 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 06:44:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 06:44:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 06:44:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 06:44:27 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 06:44:27 --> Final output sent to browser
INFO - 2022-03-17 21:32:05 --> Config Class Initialized
INFO - 2022-03-17 21:32:05 --> Hooks Class Initialized
INFO - 2022-03-17 21:32:05 --> Utf8 Class Initialized
INFO - 2022-03-17 21:32:05 --> URI Class Initialized
INFO - 2022-03-17 21:32:05 --> Router Class Initialized
INFO - 2022-03-17 21:32:05 --> Output Class Initialized
INFO - 2022-03-17 21:32:05 --> Security Class Initialized
INFO - 2022-03-17 21:32:05 --> Input Class Initialized
INFO - 2022-03-17 21:32:05 --> Language Class Initialized
INFO - 2022-03-17 21:32:05 --> Loader Class Initialized
INFO - 2022-03-17 21:32:05 --> Helper loaded: url_helper
INFO - 2022-03-17 21:32:05 --> Helper loaded: form_helper
INFO - 2022-03-17 21:32:06 --> Database Driver Class Initialized
INFO - 2022-03-17 21:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:32:06 --> Controller Class Initialized
INFO - 2022-03-17 21:32:06 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:32:06 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:32:06 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:32:06 --> Form Validation Class Initialized
INFO - 2022-03-17 21:32:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:32:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:32:06 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 21:32:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:32:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:32:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:32:06 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:32:06 --> Final output sent to browser
INFO - 2022-03-17 21:32:15 --> Config Class Initialized
INFO - 2022-03-17 21:32:15 --> Hooks Class Initialized
INFO - 2022-03-17 21:32:15 --> Utf8 Class Initialized
INFO - 2022-03-17 21:32:15 --> URI Class Initialized
INFO - 2022-03-17 21:32:15 --> Router Class Initialized
INFO - 2022-03-17 21:32:15 --> Output Class Initialized
INFO - 2022-03-17 21:32:15 --> Security Class Initialized
INFO - 2022-03-17 21:32:15 --> Input Class Initialized
INFO - 2022-03-17 21:32:15 --> Language Class Initialized
INFO - 2022-03-17 21:32:15 --> Loader Class Initialized
INFO - 2022-03-17 21:32:15 --> Helper loaded: url_helper
INFO - 2022-03-17 21:32:15 --> Helper loaded: form_helper
INFO - 2022-03-17 21:32:15 --> Database Driver Class Initialized
INFO - 2022-03-17 21:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:32:15 --> Controller Class Initialized
INFO - 2022-03-17 21:32:15 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:32:15 --> Final output sent to browser
INFO - 2022-03-17 21:32:27 --> Config Class Initialized
INFO - 2022-03-17 21:32:27 --> Hooks Class Initialized
INFO - 2022-03-17 21:32:27 --> Utf8 Class Initialized
INFO - 2022-03-17 21:32:27 --> URI Class Initialized
INFO - 2022-03-17 21:32:27 --> Router Class Initialized
INFO - 2022-03-17 21:32:27 --> Output Class Initialized
INFO - 2022-03-17 21:32:27 --> Security Class Initialized
INFO - 2022-03-17 21:32:27 --> Input Class Initialized
INFO - 2022-03-17 21:32:27 --> Language Class Initialized
INFO - 2022-03-17 21:32:27 --> Loader Class Initialized
INFO - 2022-03-17 21:32:27 --> Helper loaded: url_helper
INFO - 2022-03-17 21:32:27 --> Helper loaded: form_helper
INFO - 2022-03-17 21:32:27 --> Database Driver Class Initialized
INFO - 2022-03-17 21:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:32:27 --> Controller Class Initialized
INFO - 2022-03-17 21:32:27 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:32:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:32:27 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:32:27 --> Form Validation Class Initialized
INFO - 2022-03-17 21:32:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:32:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:32:27 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 21:32:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:32:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:32:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:32:27 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:32:27 --> Final output sent to browser
INFO - 2022-03-17 21:32:38 --> Config Class Initialized
INFO - 2022-03-17 21:32:38 --> Hooks Class Initialized
INFO - 2022-03-17 21:32:38 --> Utf8 Class Initialized
INFO - 2022-03-17 21:32:38 --> URI Class Initialized
INFO - 2022-03-17 21:32:38 --> Router Class Initialized
INFO - 2022-03-17 21:32:38 --> Output Class Initialized
INFO - 2022-03-17 21:32:38 --> Security Class Initialized
INFO - 2022-03-17 21:32:38 --> Input Class Initialized
INFO - 2022-03-17 21:32:38 --> Language Class Initialized
INFO - 2022-03-17 21:32:38 --> Loader Class Initialized
INFO - 2022-03-17 21:32:38 --> Helper loaded: url_helper
INFO - 2022-03-17 21:32:38 --> Helper loaded: form_helper
INFO - 2022-03-17 21:32:38 --> Database Driver Class Initialized
INFO - 2022-03-17 21:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:32:38 --> Controller Class Initialized
INFO - 2022-03-17 21:32:38 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:32:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:32:38 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:32:38 --> Form Validation Class Initialized
INFO - 2022-03-17 21:32:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:32:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:32:38 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 21:32:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:32:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:32:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:32:38 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:32:38 --> Final output sent to browser
INFO - 2022-03-17 21:34:50 --> Config Class Initialized
INFO - 2022-03-17 21:34:50 --> Hooks Class Initialized
INFO - 2022-03-17 21:34:50 --> Utf8 Class Initialized
INFO - 2022-03-17 21:34:50 --> URI Class Initialized
INFO - 2022-03-17 21:34:50 --> Router Class Initialized
INFO - 2022-03-17 21:34:50 --> Output Class Initialized
INFO - 2022-03-17 21:34:50 --> Security Class Initialized
INFO - 2022-03-17 21:34:50 --> Input Class Initialized
INFO - 2022-03-17 21:34:50 --> Language Class Initialized
INFO - 2022-03-17 21:34:50 --> Loader Class Initialized
INFO - 2022-03-17 21:34:50 --> Helper loaded: url_helper
INFO - 2022-03-17 21:34:50 --> Helper loaded: form_helper
INFO - 2022-03-17 21:34:50 --> Database Driver Class Initialized
INFO - 2022-03-17 21:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:34:50 --> Controller Class Initialized
INFO - 2022-03-17 21:34:50 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:34:50 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:34:50 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:34:50 --> Form Validation Class Initialized
INFO - 2022-03-17 21:34:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:34:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:34:50 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 21:34:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:34:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:34:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:34:50 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:34:50 --> Final output sent to browser
INFO - 2022-03-17 21:34:54 --> Config Class Initialized
INFO - 2022-03-17 21:34:54 --> Hooks Class Initialized
INFO - 2022-03-17 21:34:54 --> Utf8 Class Initialized
INFO - 2022-03-17 21:34:54 --> URI Class Initialized
INFO - 2022-03-17 21:34:54 --> Router Class Initialized
INFO - 2022-03-17 21:34:54 --> Output Class Initialized
INFO - 2022-03-17 21:34:54 --> Security Class Initialized
INFO - 2022-03-17 21:34:54 --> Input Class Initialized
INFO - 2022-03-17 21:34:54 --> Language Class Initialized
INFO - 2022-03-17 21:34:54 --> Loader Class Initialized
INFO - 2022-03-17 21:34:54 --> Helper loaded: url_helper
INFO - 2022-03-17 21:34:54 --> Helper loaded: form_helper
INFO - 2022-03-17 21:34:54 --> Database Driver Class Initialized
INFO - 2022-03-17 21:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:34:54 --> Controller Class Initialized
INFO - 2022-03-17 21:34:54 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:34:54 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:34:54 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:34:54 --> Form Validation Class Initialized
INFO - 2022-03-17 21:34:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:34:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:34:54 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 21:34:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:34:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:34:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:34:54 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:34:54 --> Final output sent to browser
INFO - 2022-03-17 21:40:31 --> Config Class Initialized
INFO - 2022-03-17 21:40:31 --> Hooks Class Initialized
INFO - 2022-03-17 21:40:31 --> Utf8 Class Initialized
INFO - 2022-03-17 21:40:31 --> URI Class Initialized
INFO - 2022-03-17 21:40:31 --> Router Class Initialized
INFO - 2022-03-17 21:40:31 --> Output Class Initialized
INFO - 2022-03-17 21:40:32 --> Security Class Initialized
INFO - 2022-03-17 21:40:32 --> Input Class Initialized
INFO - 2022-03-17 21:40:32 --> Language Class Initialized
INFO - 2022-03-17 21:40:32 --> Loader Class Initialized
INFO - 2022-03-17 21:40:32 --> Helper loaded: url_helper
INFO - 2022-03-17 21:40:32 --> Helper loaded: form_helper
INFO - 2022-03-17 21:40:32 --> Database Driver Class Initialized
INFO - 2022-03-17 21:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:40:32 --> Controller Class Initialized
INFO - 2022-03-17 21:40:32 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:40:32 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:40:32 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:40:32 --> Form Validation Class Initialized
ERROR - 2022-03-17 21:40:32 --> Severity: Error --> Call to a member function num_rows() on null C:\laragon\www\list-todo\application\controllers\C_todo_group.php 60
INFO - 2022-03-17 21:41:11 --> Config Class Initialized
INFO - 2022-03-17 21:41:11 --> Hooks Class Initialized
INFO - 2022-03-17 21:41:11 --> Utf8 Class Initialized
INFO - 2022-03-17 21:41:11 --> URI Class Initialized
INFO - 2022-03-17 21:41:11 --> Router Class Initialized
INFO - 2022-03-17 21:41:11 --> Output Class Initialized
INFO - 2022-03-17 21:41:11 --> Security Class Initialized
INFO - 2022-03-17 21:41:11 --> Input Class Initialized
INFO - 2022-03-17 21:41:11 --> Language Class Initialized
INFO - 2022-03-17 21:41:11 --> Loader Class Initialized
INFO - 2022-03-17 21:41:11 --> Helper loaded: url_helper
INFO - 2022-03-17 21:41:11 --> Helper loaded: form_helper
INFO - 2022-03-17 21:41:11 --> Database Driver Class Initialized
INFO - 2022-03-17 21:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:41:11 --> Controller Class Initialized
INFO - 2022-03-17 21:41:11 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:41:11 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:41:11 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:41:11 --> Form Validation Class Initialized
ERROR - 2022-03-17 21:41:12 --> 404 Page Not Found: 
INFO - 2022-03-17 21:41:16 --> Config Class Initialized
INFO - 2022-03-17 21:41:16 --> Hooks Class Initialized
INFO - 2022-03-17 21:41:16 --> Utf8 Class Initialized
INFO - 2022-03-17 21:41:16 --> URI Class Initialized
INFO - 2022-03-17 21:41:16 --> Router Class Initialized
INFO - 2022-03-17 21:41:16 --> Output Class Initialized
INFO - 2022-03-17 21:41:16 --> Security Class Initialized
INFO - 2022-03-17 21:41:16 --> Input Class Initialized
INFO - 2022-03-17 21:41:16 --> Language Class Initialized
INFO - 2022-03-17 21:41:16 --> Loader Class Initialized
INFO - 2022-03-17 21:41:16 --> Helper loaded: url_helper
INFO - 2022-03-17 21:41:16 --> Helper loaded: form_helper
INFO - 2022-03-17 21:41:16 --> Database Driver Class Initialized
INFO - 2022-03-17 21:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:41:16 --> Controller Class Initialized
INFO - 2022-03-17 21:41:16 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:41:16 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:41:16 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:41:16 --> Form Validation Class Initialized
ERROR - 2022-03-17 21:41:16 --> 404 Page Not Found: 
INFO - 2022-03-17 21:41:37 --> Config Class Initialized
INFO - 2022-03-17 21:41:37 --> Hooks Class Initialized
INFO - 2022-03-17 21:41:37 --> Utf8 Class Initialized
INFO - 2022-03-17 21:41:37 --> URI Class Initialized
INFO - 2022-03-17 21:41:37 --> Router Class Initialized
INFO - 2022-03-17 21:41:37 --> Output Class Initialized
INFO - 2022-03-17 21:41:37 --> Security Class Initialized
INFO - 2022-03-17 21:41:37 --> Input Class Initialized
INFO - 2022-03-17 21:41:37 --> Language Class Initialized
INFO - 2022-03-17 21:41:37 --> Loader Class Initialized
INFO - 2022-03-17 21:41:37 --> Helper loaded: url_helper
INFO - 2022-03-17 21:41:37 --> Helper loaded: form_helper
INFO - 2022-03-17 21:41:37 --> Database Driver Class Initialized
INFO - 2022-03-17 21:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:41:37 --> Controller Class Initialized
INFO - 2022-03-17 21:41:37 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:41:37 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:41:37 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:41:37 --> Form Validation Class Initialized
INFO - 2022-03-17 21:41:37 --> Final output sent to browser
INFO - 2022-03-17 21:41:41 --> Config Class Initialized
INFO - 2022-03-17 21:41:41 --> Hooks Class Initialized
INFO - 2022-03-17 21:41:41 --> Utf8 Class Initialized
INFO - 2022-03-17 21:41:41 --> URI Class Initialized
INFO - 2022-03-17 21:41:41 --> Router Class Initialized
INFO - 2022-03-17 21:41:41 --> Output Class Initialized
INFO - 2022-03-17 21:41:41 --> Security Class Initialized
INFO - 2022-03-17 21:41:41 --> Input Class Initialized
INFO - 2022-03-17 21:41:41 --> Language Class Initialized
INFO - 2022-03-17 21:41:41 --> Loader Class Initialized
INFO - 2022-03-17 21:41:41 --> Helper loaded: url_helper
INFO - 2022-03-17 21:41:41 --> Helper loaded: form_helper
INFO - 2022-03-17 21:41:41 --> Database Driver Class Initialized
INFO - 2022-03-17 21:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:41:41 --> Controller Class Initialized
INFO - 2022-03-17 21:41:41 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:41:41 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:41:41 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:41:41 --> Form Validation Class Initialized
INFO - 2022-03-17 21:41:41 --> Final output sent to browser
INFO - 2022-03-17 21:41:45 --> Config Class Initialized
INFO - 2022-03-17 21:41:45 --> Hooks Class Initialized
INFO - 2022-03-17 21:41:45 --> Utf8 Class Initialized
INFO - 2022-03-17 21:41:45 --> URI Class Initialized
INFO - 2022-03-17 21:41:45 --> Router Class Initialized
INFO - 2022-03-17 21:41:45 --> Output Class Initialized
INFO - 2022-03-17 21:41:45 --> Security Class Initialized
INFO - 2022-03-17 21:41:45 --> Input Class Initialized
INFO - 2022-03-17 21:41:45 --> Language Class Initialized
INFO - 2022-03-17 21:41:45 --> Loader Class Initialized
INFO - 2022-03-17 21:41:45 --> Helper loaded: url_helper
INFO - 2022-03-17 21:41:45 --> Helper loaded: form_helper
INFO - 2022-03-17 21:41:45 --> Database Driver Class Initialized
INFO - 2022-03-17 21:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:41:45 --> Controller Class Initialized
INFO - 2022-03-17 21:41:45 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:41:45 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:41:45 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:41:45 --> Form Validation Class Initialized
INFO - 2022-03-17 21:41:45 --> Final output sent to browser
INFO - 2022-03-17 21:42:12 --> Config Class Initialized
INFO - 2022-03-17 21:42:12 --> Hooks Class Initialized
INFO - 2022-03-17 21:42:12 --> Utf8 Class Initialized
INFO - 2022-03-17 21:42:12 --> URI Class Initialized
INFO - 2022-03-17 21:42:12 --> Router Class Initialized
INFO - 2022-03-17 21:42:12 --> Output Class Initialized
INFO - 2022-03-17 21:42:12 --> Security Class Initialized
INFO - 2022-03-17 21:42:12 --> Input Class Initialized
INFO - 2022-03-17 21:42:12 --> Language Class Initialized
INFO - 2022-03-17 21:42:12 --> Loader Class Initialized
INFO - 2022-03-17 21:42:12 --> Helper loaded: url_helper
INFO - 2022-03-17 21:42:12 --> Helper loaded: form_helper
INFO - 2022-03-17 21:42:12 --> Database Driver Class Initialized
INFO - 2022-03-17 21:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:42:12 --> Controller Class Initialized
INFO - 2022-03-17 21:42:12 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:42:12 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:42:12 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:42:12 --> Form Validation Class Initialized
INFO - 2022-03-17 21:42:12 --> Final output sent to browser
INFO - 2022-03-17 21:42:38 --> Config Class Initialized
INFO - 2022-03-17 21:42:38 --> Hooks Class Initialized
INFO - 2022-03-17 21:42:38 --> Utf8 Class Initialized
INFO - 2022-03-17 21:42:38 --> URI Class Initialized
INFO - 2022-03-17 21:42:38 --> Router Class Initialized
INFO - 2022-03-17 21:42:38 --> Output Class Initialized
INFO - 2022-03-17 21:42:38 --> Security Class Initialized
INFO - 2022-03-17 21:42:38 --> Input Class Initialized
INFO - 2022-03-17 21:42:38 --> Language Class Initialized
INFO - 2022-03-17 21:42:38 --> Loader Class Initialized
INFO - 2022-03-17 21:42:38 --> Helper loaded: url_helper
INFO - 2022-03-17 21:42:38 --> Helper loaded: form_helper
INFO - 2022-03-17 21:42:38 --> Database Driver Class Initialized
INFO - 2022-03-17 21:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:42:38 --> Controller Class Initialized
INFO - 2022-03-17 21:42:38 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:42:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:42:38 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:42:38 --> Form Validation Class Initialized
INFO - 2022-03-17 21:42:38 --> Final output sent to browser
INFO - 2022-03-17 21:43:03 --> Config Class Initialized
INFO - 2022-03-17 21:43:03 --> Hooks Class Initialized
INFO - 2022-03-17 21:43:03 --> Utf8 Class Initialized
INFO - 2022-03-17 21:43:03 --> URI Class Initialized
INFO - 2022-03-17 21:43:03 --> Router Class Initialized
INFO - 2022-03-17 21:43:03 --> Output Class Initialized
INFO - 2022-03-17 21:43:03 --> Security Class Initialized
INFO - 2022-03-17 21:43:03 --> Input Class Initialized
INFO - 2022-03-17 21:43:03 --> Language Class Initialized
INFO - 2022-03-17 21:43:03 --> Loader Class Initialized
INFO - 2022-03-17 21:43:03 --> Helper loaded: url_helper
INFO - 2022-03-17 21:43:03 --> Helper loaded: form_helper
INFO - 2022-03-17 21:43:03 --> Database Driver Class Initialized
INFO - 2022-03-17 21:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:43:03 --> Controller Class Initialized
INFO - 2022-03-17 21:43:03 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:43:03 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:43:03 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:43:03 --> Form Validation Class Initialized
INFO - 2022-03-17 21:43:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:43:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:43:03 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 21:43:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:43:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:43:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:43:03 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:43:03 --> Final output sent to browser
INFO - 2022-03-17 21:43:09 --> Config Class Initialized
INFO - 2022-03-17 21:43:09 --> Hooks Class Initialized
INFO - 2022-03-17 21:43:09 --> Utf8 Class Initialized
INFO - 2022-03-17 21:43:09 --> URI Class Initialized
INFO - 2022-03-17 21:43:09 --> Router Class Initialized
INFO - 2022-03-17 21:43:09 --> Output Class Initialized
INFO - 2022-03-17 21:43:09 --> Security Class Initialized
INFO - 2022-03-17 21:43:09 --> Input Class Initialized
INFO - 2022-03-17 21:43:09 --> Language Class Initialized
INFO - 2022-03-17 21:43:09 --> Loader Class Initialized
INFO - 2022-03-17 21:43:09 --> Helper loaded: url_helper
INFO - 2022-03-17 21:43:09 --> Helper loaded: form_helper
INFO - 2022-03-17 21:43:09 --> Database Driver Class Initialized
INFO - 2022-03-17 21:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:43:10 --> Controller Class Initialized
INFO - 2022-03-17 21:43:10 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:43:10 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:43:10 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:43:10 --> Form Validation Class Initialized
INFO - 2022-03-17 21:43:10 --> Final output sent to browser
INFO - 2022-03-17 21:43:22 --> Config Class Initialized
INFO - 2022-03-17 21:43:22 --> Hooks Class Initialized
INFO - 2022-03-17 21:43:22 --> Utf8 Class Initialized
INFO - 2022-03-17 21:43:22 --> URI Class Initialized
INFO - 2022-03-17 21:43:22 --> Router Class Initialized
INFO - 2022-03-17 21:43:22 --> Output Class Initialized
INFO - 2022-03-17 21:43:22 --> Security Class Initialized
INFO - 2022-03-17 21:43:22 --> Input Class Initialized
INFO - 2022-03-17 21:43:22 --> Language Class Initialized
INFO - 2022-03-17 21:43:22 --> Loader Class Initialized
INFO - 2022-03-17 21:43:22 --> Helper loaded: url_helper
INFO - 2022-03-17 21:43:22 --> Helper loaded: form_helper
INFO - 2022-03-17 21:43:22 --> Database Driver Class Initialized
INFO - 2022-03-17 21:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:43:22 --> Controller Class Initialized
INFO - 2022-03-17 21:43:22 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:43:22 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:43:22 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:43:22 --> Form Validation Class Initialized
ERROR - 2022-03-17 21:43:22 --> 404 Page Not Found: 
INFO - 2022-03-17 21:43:26 --> Config Class Initialized
INFO - 2022-03-17 21:43:26 --> Hooks Class Initialized
INFO - 2022-03-17 21:43:26 --> Utf8 Class Initialized
INFO - 2022-03-17 21:43:26 --> URI Class Initialized
INFO - 2022-03-17 21:43:26 --> Router Class Initialized
INFO - 2022-03-17 21:43:26 --> Output Class Initialized
INFO - 2022-03-17 21:43:26 --> Security Class Initialized
INFO - 2022-03-17 21:43:26 --> Input Class Initialized
INFO - 2022-03-17 21:43:26 --> Language Class Initialized
INFO - 2022-03-17 21:43:26 --> Loader Class Initialized
INFO - 2022-03-17 21:43:26 --> Helper loaded: url_helper
INFO - 2022-03-17 21:43:26 --> Helper loaded: form_helper
INFO - 2022-03-17 21:43:26 --> Database Driver Class Initialized
INFO - 2022-03-17 21:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:43:26 --> Controller Class Initialized
INFO - 2022-03-17 21:43:26 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:43:26 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:43:26 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:43:26 --> Form Validation Class Initialized
INFO - 2022-03-17 21:43:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:43:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:43:26 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_list_tutor.php
INFO - 2022-03-17 21:43:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:43:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:43:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:43:26 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:43:26 --> Final output sent to browser
INFO - 2022-03-17 21:43:33 --> Config Class Initialized
INFO - 2022-03-17 21:43:33 --> Hooks Class Initialized
INFO - 2022-03-17 21:43:33 --> Utf8 Class Initialized
INFO - 2022-03-17 21:43:33 --> URI Class Initialized
INFO - 2022-03-17 21:43:33 --> Router Class Initialized
INFO - 2022-03-17 21:43:33 --> Output Class Initialized
INFO - 2022-03-17 21:43:33 --> Security Class Initialized
INFO - 2022-03-17 21:43:33 --> Input Class Initialized
INFO - 2022-03-17 21:43:33 --> Language Class Initialized
INFO - 2022-03-17 21:43:33 --> Loader Class Initialized
INFO - 2022-03-17 21:43:33 --> Helper loaded: url_helper
INFO - 2022-03-17 21:43:33 --> Helper loaded: form_helper
INFO - 2022-03-17 21:43:33 --> Database Driver Class Initialized
INFO - 2022-03-17 21:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:43:33 --> Controller Class Initialized
INFO - 2022-03-17 21:43:33 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:43:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:43:33 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:43:33 --> Form Validation Class Initialized
INFO - 2022-03-17 21:43:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:43:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:43:33 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-17 21:43:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:43:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:43:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:43:33 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:43:33 --> Final output sent to browser
INFO - 2022-03-17 21:43:39 --> Config Class Initialized
INFO - 2022-03-17 21:43:39 --> Hooks Class Initialized
INFO - 2022-03-17 21:43:39 --> Utf8 Class Initialized
INFO - 2022-03-17 21:43:39 --> URI Class Initialized
INFO - 2022-03-17 21:43:39 --> Router Class Initialized
INFO - 2022-03-17 21:43:39 --> Output Class Initialized
INFO - 2022-03-17 21:43:39 --> Security Class Initialized
INFO - 2022-03-17 21:43:39 --> Input Class Initialized
INFO - 2022-03-17 21:43:39 --> Language Class Initialized
INFO - 2022-03-17 21:43:39 --> Loader Class Initialized
INFO - 2022-03-17 21:43:39 --> Helper loaded: url_helper
INFO - 2022-03-17 21:43:39 --> Helper loaded: form_helper
INFO - 2022-03-17 21:43:39 --> Database Driver Class Initialized
INFO - 2022-03-17 21:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:43:39 --> Controller Class Initialized
INFO - 2022-03-17 21:43:39 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:43:39 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:43:39 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:43:39 --> Form Validation Class Initialized
INFO - 2022-03-17 21:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_ubah.php
INFO - 2022-03-17 21:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:43:39 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:43:39 --> Final output sent to browser
INFO - 2022-03-17 21:43:43 --> Config Class Initialized
INFO - 2022-03-17 21:43:43 --> Hooks Class Initialized
INFO - 2022-03-17 21:43:43 --> Utf8 Class Initialized
INFO - 2022-03-17 21:43:43 --> URI Class Initialized
INFO - 2022-03-17 21:43:43 --> Router Class Initialized
INFO - 2022-03-17 21:43:43 --> Output Class Initialized
INFO - 2022-03-17 21:43:43 --> Security Class Initialized
INFO - 2022-03-17 21:43:43 --> Input Class Initialized
INFO - 2022-03-17 21:43:43 --> Language Class Initialized
INFO - 2022-03-17 21:43:43 --> Loader Class Initialized
INFO - 2022-03-17 21:43:43 --> Helper loaded: url_helper
INFO - 2022-03-17 21:43:43 --> Helper loaded: form_helper
INFO - 2022-03-17 21:43:43 --> Database Driver Class Initialized
INFO - 2022-03-17 21:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:43:43 --> Controller Class Initialized
INFO - 2022-03-17 21:43:43 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:43:43 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:43:43 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:43:43 --> Form Validation Class Initialized
ERROR - 2022-03-17 21:43:43 --> Severity: Warning --> Missing argument 1 for C_todo_group::form_ubah() C:\laragon\www\list-todo\application\controllers\C_todo_group.php 38
ERROR - 2022-03-17 21:43:43 --> Severity: Notice --> Undefined variable: id C:\laragon\www\list-todo\application\controllers\C_todo_group.php 40
INFO - 2022-03-17 21:43:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:43:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:43:43 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_ubah.php
INFO - 2022-03-17 21:43:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:43:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:43:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:43:43 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:43:43 --> Final output sent to browser
INFO - 2022-03-17 21:45:40 --> Config Class Initialized
INFO - 2022-03-17 21:45:40 --> Hooks Class Initialized
INFO - 2022-03-17 21:45:40 --> Utf8 Class Initialized
INFO - 2022-03-17 21:45:40 --> URI Class Initialized
INFO - 2022-03-17 21:45:40 --> Router Class Initialized
INFO - 2022-03-17 21:45:40 --> Output Class Initialized
INFO - 2022-03-17 21:45:40 --> Security Class Initialized
INFO - 2022-03-17 21:45:40 --> Input Class Initialized
INFO - 2022-03-17 21:45:40 --> Language Class Initialized
INFO - 2022-03-17 21:45:40 --> Loader Class Initialized
INFO - 2022-03-17 21:45:40 --> Helper loaded: url_helper
INFO - 2022-03-17 21:45:40 --> Helper loaded: form_helper
INFO - 2022-03-17 21:45:40 --> Database Driver Class Initialized
INFO - 2022-03-17 21:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:45:40 --> Controller Class Initialized
INFO - 2022-03-17 21:45:40 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:45:40 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:45:40 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:45:40 --> Form Validation Class Initialized
ERROR - 2022-03-17 21:45:40 --> Severity: Warning --> Missing argument 1 for C_todo_group::form_ubah() C:\laragon\www\list-todo\application\controllers\C_todo_group.php 38
INFO - 2022-03-17 21:45:40 --> Config Class Initialized
INFO - 2022-03-17 21:45:40 --> Hooks Class Initialized
INFO - 2022-03-17 21:45:40 --> Utf8 Class Initialized
INFO - 2022-03-17 21:45:40 --> URI Class Initialized
INFO - 2022-03-17 21:45:40 --> Router Class Initialized
INFO - 2022-03-17 21:45:40 --> Output Class Initialized
INFO - 2022-03-17 21:45:40 --> Security Class Initialized
INFO - 2022-03-17 21:45:40 --> Input Class Initialized
INFO - 2022-03-17 21:45:40 --> Language Class Initialized
INFO - 2022-03-17 21:45:40 --> Loader Class Initialized
INFO - 2022-03-17 21:45:40 --> Helper loaded: url_helper
INFO - 2022-03-17 21:45:40 --> Helper loaded: form_helper
INFO - 2022-03-17 21:45:40 --> Database Driver Class Initialized
INFO - 2022-03-17 21:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:45:40 --> Controller Class Initialized
INFO - 2022-03-17 21:45:40 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:45:40 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:45:40 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:45:40 --> Form Validation Class Initialized
INFO - 2022-03-17 21:45:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:45:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:45:40 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-17 21:45:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:45:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:45:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:45:40 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:45:40 --> Final output sent to browser
INFO - 2022-03-17 21:45:47 --> Config Class Initialized
INFO - 2022-03-17 21:45:47 --> Hooks Class Initialized
INFO - 2022-03-17 21:45:47 --> Utf8 Class Initialized
INFO - 2022-03-17 21:45:47 --> URI Class Initialized
INFO - 2022-03-17 21:45:47 --> Router Class Initialized
INFO - 2022-03-17 21:45:47 --> Output Class Initialized
INFO - 2022-03-17 21:45:47 --> Security Class Initialized
INFO - 2022-03-17 21:45:47 --> Input Class Initialized
INFO - 2022-03-17 21:45:47 --> Language Class Initialized
INFO - 2022-03-17 21:45:47 --> Loader Class Initialized
INFO - 2022-03-17 21:45:47 --> Helper loaded: url_helper
INFO - 2022-03-17 21:45:47 --> Helper loaded: form_helper
INFO - 2022-03-17 21:45:47 --> Database Driver Class Initialized
INFO - 2022-03-17 21:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:45:47 --> Controller Class Initialized
INFO - 2022-03-17 21:45:47 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:45:47 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:45:47 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:45:47 --> Form Validation Class Initialized
INFO - 2022-03-17 21:45:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:45:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:45:47 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_ubah.php
INFO - 2022-03-17 21:45:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:45:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:45:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:45:47 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:45:47 --> Final output sent to browser
INFO - 2022-03-17 21:45:49 --> Config Class Initialized
INFO - 2022-03-17 21:45:49 --> Hooks Class Initialized
INFO - 2022-03-17 21:45:49 --> Utf8 Class Initialized
INFO - 2022-03-17 21:45:49 --> URI Class Initialized
INFO - 2022-03-17 21:45:49 --> Router Class Initialized
INFO - 2022-03-17 21:45:49 --> Output Class Initialized
INFO - 2022-03-17 21:45:49 --> Security Class Initialized
INFO - 2022-03-17 21:45:49 --> Input Class Initialized
INFO - 2022-03-17 21:45:49 --> Language Class Initialized
INFO - 2022-03-17 21:45:49 --> Loader Class Initialized
INFO - 2022-03-17 21:45:49 --> Helper loaded: url_helper
INFO - 2022-03-17 21:45:49 --> Helper loaded: form_helper
INFO - 2022-03-17 21:45:49 --> Database Driver Class Initialized
INFO - 2022-03-17 21:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:45:50 --> Controller Class Initialized
INFO - 2022-03-17 21:45:50 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:45:50 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:45:50 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:45:50 --> Form Validation Class Initialized
INFO - 2022-03-17 21:45:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:45:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:45:50 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-17 21:45:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:45:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:45:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:45:50 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:45:50 --> Final output sent to browser
INFO - 2022-03-17 21:46:53 --> Config Class Initialized
INFO - 2022-03-17 21:46:53 --> Hooks Class Initialized
INFO - 2022-03-17 21:46:53 --> Utf8 Class Initialized
INFO - 2022-03-17 21:46:53 --> URI Class Initialized
INFO - 2022-03-17 21:46:53 --> Router Class Initialized
INFO - 2022-03-17 21:46:53 --> Output Class Initialized
INFO - 2022-03-17 21:46:53 --> Security Class Initialized
INFO - 2022-03-17 21:46:53 --> Input Class Initialized
INFO - 2022-03-17 21:46:53 --> Language Class Initialized
INFO - 2022-03-17 21:46:53 --> Loader Class Initialized
INFO - 2022-03-17 21:46:53 --> Helper loaded: url_helper
INFO - 2022-03-17 21:46:53 --> Helper loaded: form_helper
INFO - 2022-03-17 21:46:53 --> Database Driver Class Initialized
INFO - 2022-03-17 21:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:46:53 --> Controller Class Initialized
INFO - 2022-03-17 21:46:53 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:46:53 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:46:53 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:46:53 --> Form Validation Class Initialized
INFO - 2022-03-17 21:46:53 --> Config Class Initialized
INFO - 2022-03-17 21:46:53 --> Hooks Class Initialized
INFO - 2022-03-17 21:46:53 --> Utf8 Class Initialized
INFO - 2022-03-17 21:46:53 --> URI Class Initialized
INFO - 2022-03-17 21:46:53 --> Router Class Initialized
INFO - 2022-03-17 21:46:53 --> Output Class Initialized
INFO - 2022-03-17 21:46:53 --> Security Class Initialized
INFO - 2022-03-17 21:46:53 --> Input Class Initialized
INFO - 2022-03-17 21:46:53 --> Language Class Initialized
INFO - 2022-03-17 21:46:53 --> Loader Class Initialized
INFO - 2022-03-17 21:46:53 --> Helper loaded: url_helper
INFO - 2022-03-17 21:46:53 --> Helper loaded: form_helper
INFO - 2022-03-17 21:46:53 --> Database Driver Class Initialized
INFO - 2022-03-17 21:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:46:53 --> Controller Class Initialized
INFO - 2022-03-17 21:46:53 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:46:53 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:46:53 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:46:53 --> Form Validation Class Initialized
INFO - 2022-03-17 21:46:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:46:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:46:53 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-17 21:46:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:46:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:46:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:46:53 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:46:53 --> Final output sent to browser
INFO - 2022-03-17 21:47:37 --> Config Class Initialized
INFO - 2022-03-17 21:47:37 --> Hooks Class Initialized
INFO - 2022-03-17 21:47:37 --> Utf8 Class Initialized
INFO - 2022-03-17 21:47:37 --> URI Class Initialized
INFO - 2022-03-17 21:47:37 --> Router Class Initialized
INFO - 2022-03-17 21:47:37 --> Output Class Initialized
INFO - 2022-03-17 21:47:37 --> Security Class Initialized
INFO - 2022-03-17 21:47:37 --> Input Class Initialized
INFO - 2022-03-17 21:47:37 --> Language Class Initialized
INFO - 2022-03-17 21:47:37 --> Loader Class Initialized
INFO - 2022-03-17 21:47:37 --> Helper loaded: url_helper
INFO - 2022-03-17 21:47:37 --> Helper loaded: form_helper
INFO - 2022-03-17 21:47:37 --> Database Driver Class Initialized
INFO - 2022-03-17 21:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:47:37 --> Controller Class Initialized
INFO - 2022-03-17 21:47:37 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:47:37 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:47:37 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:47:37 --> Form Validation Class Initialized
INFO - 2022-03-17 21:47:37 --> Config Class Initialized
INFO - 2022-03-17 21:47:37 --> Hooks Class Initialized
INFO - 2022-03-17 21:47:37 --> Utf8 Class Initialized
INFO - 2022-03-17 21:47:37 --> URI Class Initialized
INFO - 2022-03-17 21:47:37 --> Router Class Initialized
INFO - 2022-03-17 21:47:37 --> Output Class Initialized
INFO - 2022-03-17 21:47:37 --> Security Class Initialized
INFO - 2022-03-17 21:47:37 --> Input Class Initialized
INFO - 2022-03-17 21:47:37 --> Language Class Initialized
INFO - 2022-03-17 21:47:37 --> Loader Class Initialized
INFO - 2022-03-17 21:47:37 --> Helper loaded: url_helper
INFO - 2022-03-17 21:47:38 --> Helper loaded: form_helper
INFO - 2022-03-17 21:47:38 --> Database Driver Class Initialized
INFO - 2022-03-17 21:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:47:38 --> Controller Class Initialized
INFO - 2022-03-17 21:47:38 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:47:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:47:38 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:47:38 --> Form Validation Class Initialized
INFO - 2022-03-17 21:47:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:47:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:47:38 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-17 21:47:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:47:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:47:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:47:38 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:47:38 --> Final output sent to browser
INFO - 2022-03-17 21:47:51 --> Config Class Initialized
INFO - 2022-03-17 21:47:51 --> Hooks Class Initialized
INFO - 2022-03-17 21:47:51 --> Utf8 Class Initialized
INFO - 2022-03-17 21:47:51 --> URI Class Initialized
INFO - 2022-03-17 21:47:51 --> Router Class Initialized
INFO - 2022-03-17 21:47:51 --> Output Class Initialized
INFO - 2022-03-17 21:47:51 --> Security Class Initialized
INFO - 2022-03-17 21:47:51 --> Input Class Initialized
INFO - 2022-03-17 21:47:51 --> Language Class Initialized
INFO - 2022-03-17 21:47:51 --> Loader Class Initialized
INFO - 2022-03-17 21:47:51 --> Helper loaded: url_helper
INFO - 2022-03-17 21:47:51 --> Helper loaded: form_helper
INFO - 2022-03-17 21:47:51 --> Database Driver Class Initialized
INFO - 2022-03-17 21:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:47:51 --> Controller Class Initialized
INFO - 2022-03-17 21:47:51 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:47:51 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:47:51 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:47:51 --> Form Validation Class Initialized
INFO - 2022-03-17 21:47:51 --> Config Class Initialized
INFO - 2022-03-17 21:47:51 --> Hooks Class Initialized
INFO - 2022-03-17 21:47:51 --> Utf8 Class Initialized
INFO - 2022-03-17 21:47:51 --> URI Class Initialized
INFO - 2022-03-17 21:47:51 --> Router Class Initialized
INFO - 2022-03-17 21:47:51 --> Output Class Initialized
INFO - 2022-03-17 21:47:51 --> Security Class Initialized
INFO - 2022-03-17 21:47:51 --> Input Class Initialized
INFO - 2022-03-17 21:47:51 --> Language Class Initialized
INFO - 2022-03-17 21:47:51 --> Loader Class Initialized
INFO - 2022-03-17 21:47:51 --> Helper loaded: url_helper
INFO - 2022-03-17 21:47:51 --> Helper loaded: form_helper
INFO - 2022-03-17 21:47:51 --> Database Driver Class Initialized
INFO - 2022-03-17 21:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:47:51 --> Controller Class Initialized
INFO - 2022-03-17 21:47:51 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:47:51 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:47:51 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:47:51 --> Form Validation Class Initialized
INFO - 2022-03-17 21:47:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:47:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:47:51 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-17 21:47:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:47:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:47:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:47:51 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:47:51 --> Final output sent to browser
INFO - 2022-03-17 21:47:56 --> Config Class Initialized
INFO - 2022-03-17 21:47:56 --> Hooks Class Initialized
INFO - 2022-03-17 21:47:56 --> Utf8 Class Initialized
INFO - 2022-03-17 21:47:56 --> URI Class Initialized
INFO - 2022-03-17 21:47:56 --> Router Class Initialized
INFO - 2022-03-17 21:47:56 --> Output Class Initialized
INFO - 2022-03-17 21:47:56 --> Security Class Initialized
INFO - 2022-03-17 21:47:56 --> Input Class Initialized
INFO - 2022-03-17 21:47:56 --> Language Class Initialized
INFO - 2022-03-17 21:47:56 --> Loader Class Initialized
INFO - 2022-03-17 21:47:56 --> Helper loaded: url_helper
INFO - 2022-03-17 21:47:56 --> Helper loaded: form_helper
INFO - 2022-03-17 21:47:56 --> Database Driver Class Initialized
INFO - 2022-03-17 21:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:47:56 --> Controller Class Initialized
INFO - 2022-03-17 21:47:56 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:47:56 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:47:56 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:47:56 --> Form Validation Class Initialized
INFO - 2022-03-17 21:47:56 --> Config Class Initialized
INFO - 2022-03-17 21:47:56 --> Hooks Class Initialized
INFO - 2022-03-17 21:47:56 --> Utf8 Class Initialized
INFO - 2022-03-17 21:47:56 --> URI Class Initialized
INFO - 2022-03-17 21:47:56 --> Router Class Initialized
INFO - 2022-03-17 21:47:56 --> Output Class Initialized
INFO - 2022-03-17 21:47:56 --> Security Class Initialized
INFO - 2022-03-17 21:47:56 --> Input Class Initialized
INFO - 2022-03-17 21:47:56 --> Language Class Initialized
INFO - 2022-03-17 21:47:56 --> Loader Class Initialized
INFO - 2022-03-17 21:47:56 --> Helper loaded: url_helper
INFO - 2022-03-17 21:47:56 --> Helper loaded: form_helper
INFO - 2022-03-17 21:47:57 --> Database Driver Class Initialized
INFO - 2022-03-17 21:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:47:57 --> Controller Class Initialized
INFO - 2022-03-17 21:47:57 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:47:57 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:47:57 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:47:57 --> Form Validation Class Initialized
INFO - 2022-03-17 21:47:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:47:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:47:57 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-17 21:47:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:47:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:47:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:47:57 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:47:57 --> Final output sent to browser
INFO - 2022-03-17 21:49:02 --> Config Class Initialized
INFO - 2022-03-17 21:49:02 --> Hooks Class Initialized
INFO - 2022-03-17 21:49:02 --> Utf8 Class Initialized
INFO - 2022-03-17 21:49:02 --> URI Class Initialized
INFO - 2022-03-17 21:49:02 --> Router Class Initialized
INFO - 2022-03-17 21:49:02 --> Output Class Initialized
INFO - 2022-03-17 21:49:02 --> Security Class Initialized
INFO - 2022-03-17 21:49:02 --> Input Class Initialized
INFO - 2022-03-17 21:49:02 --> Language Class Initialized
INFO - 2022-03-17 21:49:02 --> Loader Class Initialized
INFO - 2022-03-17 21:49:02 --> Helper loaded: url_helper
INFO - 2022-03-17 21:49:02 --> Helper loaded: form_helper
INFO - 2022-03-17 21:49:02 --> Database Driver Class Initialized
INFO - 2022-03-17 21:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:49:02 --> Controller Class Initialized
INFO - 2022-03-17 21:49:02 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:49:02 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:49:02 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:49:02 --> Form Validation Class Initialized
INFO - 2022-03-17 21:49:02 --> Config Class Initialized
INFO - 2022-03-17 21:49:02 --> Hooks Class Initialized
INFO - 2022-03-17 21:49:02 --> Utf8 Class Initialized
INFO - 2022-03-17 21:49:02 --> URI Class Initialized
INFO - 2022-03-17 21:49:02 --> Router Class Initialized
INFO - 2022-03-17 21:49:02 --> Output Class Initialized
INFO - 2022-03-17 21:49:02 --> Security Class Initialized
INFO - 2022-03-17 21:49:02 --> Input Class Initialized
INFO - 2022-03-17 21:49:02 --> Language Class Initialized
INFO - 2022-03-17 21:49:02 --> Loader Class Initialized
INFO - 2022-03-17 21:49:02 --> Helper loaded: url_helper
INFO - 2022-03-17 21:49:02 --> Helper loaded: form_helper
INFO - 2022-03-17 21:49:02 --> Database Driver Class Initialized
INFO - 2022-03-17 21:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:49:02 --> Controller Class Initialized
INFO - 2022-03-17 21:49:02 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:49:02 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:49:02 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:49:02 --> Form Validation Class Initialized
INFO - 2022-03-17 21:49:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:49:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:49:02 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-17 21:49:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:49:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:49:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:49:02 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:49:02 --> Final output sent to browser
INFO - 2022-03-17 21:49:19 --> Config Class Initialized
INFO - 2022-03-17 21:49:19 --> Hooks Class Initialized
INFO - 2022-03-17 21:49:19 --> Utf8 Class Initialized
INFO - 2022-03-17 21:49:19 --> URI Class Initialized
INFO - 2022-03-17 21:49:19 --> Router Class Initialized
INFO - 2022-03-17 21:49:19 --> Output Class Initialized
INFO - 2022-03-17 21:49:19 --> Security Class Initialized
INFO - 2022-03-17 21:49:19 --> Input Class Initialized
INFO - 2022-03-17 21:49:19 --> Language Class Initialized
INFO - 2022-03-17 21:49:19 --> Loader Class Initialized
INFO - 2022-03-17 21:49:19 --> Helper loaded: url_helper
INFO - 2022-03-17 21:49:19 --> Helper loaded: form_helper
INFO - 2022-03-17 21:49:19 --> Database Driver Class Initialized
INFO - 2022-03-17 21:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 21:49:19 --> Controller Class Initialized
INFO - 2022-03-17 21:49:19 --> Model "M_todo_group" initialized
INFO - 2022-03-17 21:49:19 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-17 21:49:19 --> Model "M_tutor" initialized
INFO - 2022-03-17 21:49:19 --> Form Validation Class Initialized
INFO - 2022-03-17 21:49:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-17 21:49:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-17 21:49:19 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_tambah.php
INFO - 2022-03-17 21:49:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-17 21:49:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-17 21:49:19 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-17 21:49:19 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-17 21:49:19 --> Final output sent to browser
