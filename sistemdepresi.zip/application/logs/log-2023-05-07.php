<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-07 14:01:59 --> Config Class Initialized
INFO - 2023-05-07 14:01:59 --> Hooks Class Initialized
INFO - 2023-05-07 14:02:00 --> Utf8 Class Initialized
INFO - 2023-05-07 14:02:00 --> URI Class Initialized
INFO - 2023-05-07 14:02:00 --> Router Class Initialized
INFO - 2023-05-07 14:02:00 --> Output Class Initialized
INFO - 2023-05-07 14:02:00 --> Security Class Initialized
INFO - 2023-05-07 14:02:00 --> Input Class Initialized
INFO - 2023-05-07 14:02:00 --> Language Class Initialized
INFO - 2023-05-07 14:02:00 --> Loader Class Initialized
INFO - 2023-05-07 14:02:00 --> Helper loaded: url_helper
INFO - 2023-05-07 14:02:00 --> Helper loaded: form_helper
INFO - 2023-05-07 14:02:00 --> Database Driver Class Initialized
INFO - 2023-05-07 14:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:02:00 --> Form Validation Class Initialized
INFO - 2023-05-07 14:02:00 --> Controller Class Initialized
INFO - 2023-05-07 14:02:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:02:00 --> Final output sent to browser
INFO - 2023-05-07 14:02:00 --> Config Class Initialized
INFO - 2023-05-07 14:02:00 --> Hooks Class Initialized
INFO - 2023-05-07 14:02:00 --> Utf8 Class Initialized
INFO - 2023-05-07 14:02:00 --> URI Class Initialized
INFO - 2023-05-07 14:02:00 --> Router Class Initialized
INFO - 2023-05-07 14:02:00 --> Output Class Initialized
INFO - 2023-05-07 14:02:00 --> Security Class Initialized
INFO - 2023-05-07 14:02:00 --> Input Class Initialized
INFO - 2023-05-07 14:02:00 --> Language Class Initialized
INFO - 2023-05-07 14:02:00 --> Loader Class Initialized
INFO - 2023-05-07 14:02:00 --> Helper loaded: url_helper
INFO - 2023-05-07 14:02:00 --> Helper loaded: form_helper
INFO - 2023-05-07 14:02:00 --> Database Driver Class Initialized
INFO - 2023-05-07 14:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:02:00 --> Form Validation Class Initialized
INFO - 2023-05-07 14:02:00 --> Controller Class Initialized
INFO - 2023-05-07 14:02:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:02:00 --> Final output sent to browser
INFO - 2023-05-07 14:02:06 --> Config Class Initialized
INFO - 2023-05-07 14:02:06 --> Hooks Class Initialized
INFO - 2023-05-07 14:02:06 --> Utf8 Class Initialized
INFO - 2023-05-07 14:02:06 --> URI Class Initialized
INFO - 2023-05-07 14:02:06 --> Router Class Initialized
INFO - 2023-05-07 14:02:06 --> Output Class Initialized
INFO - 2023-05-07 14:02:06 --> Security Class Initialized
INFO - 2023-05-07 14:02:06 --> Input Class Initialized
INFO - 2023-05-07 14:02:06 --> Language Class Initialized
INFO - 2023-05-07 14:02:06 --> Loader Class Initialized
INFO - 2023-05-07 14:02:06 --> Helper loaded: url_helper
INFO - 2023-05-07 14:02:06 --> Helper loaded: form_helper
INFO - 2023-05-07 14:02:06 --> Database Driver Class Initialized
INFO - 2023-05-07 14:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:02:06 --> Form Validation Class Initialized
INFO - 2023-05-07 14:02:06 --> Controller Class Initialized
INFO - 2023-05-07 14:02:07 --> Model "m_user" initialized
INFO - 2023-05-07 14:02:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:02:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:02:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:02:07 --> Final output sent to browser
INFO - 2023-05-07 14:02:23 --> Config Class Initialized
INFO - 2023-05-07 14:02:23 --> Hooks Class Initialized
INFO - 2023-05-07 14:02:23 --> Utf8 Class Initialized
INFO - 2023-05-07 14:02:23 --> URI Class Initialized
INFO - 2023-05-07 14:02:23 --> Router Class Initialized
INFO - 2023-05-07 14:02:23 --> Output Class Initialized
INFO - 2023-05-07 14:02:23 --> Security Class Initialized
INFO - 2023-05-07 14:02:23 --> Input Class Initialized
INFO - 2023-05-07 14:02:23 --> Language Class Initialized
INFO - 2023-05-07 14:02:23 --> Loader Class Initialized
INFO - 2023-05-07 14:02:23 --> Helper loaded: url_helper
INFO - 2023-05-07 14:02:23 --> Helper loaded: form_helper
INFO - 2023-05-07 14:02:23 --> Database Driver Class Initialized
INFO - 2023-05-07 14:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:02:23 --> Form Validation Class Initialized
INFO - 2023-05-07 14:02:23 --> Controller Class Initialized
INFO - 2023-05-07 14:02:23 --> Model "m_user" initialized
INFO - 2023-05-07 14:02:23 --> Config Class Initialized
INFO - 2023-05-07 14:02:23 --> Hooks Class Initialized
INFO - 2023-05-07 14:02:23 --> Utf8 Class Initialized
INFO - 2023-05-07 14:02:23 --> URI Class Initialized
INFO - 2023-05-07 14:02:23 --> Router Class Initialized
INFO - 2023-05-07 14:02:23 --> Output Class Initialized
INFO - 2023-05-07 14:02:23 --> Security Class Initialized
INFO - 2023-05-07 14:02:23 --> Input Class Initialized
INFO - 2023-05-07 14:02:23 --> Language Class Initialized
INFO - 2023-05-07 14:02:23 --> Loader Class Initialized
INFO - 2023-05-07 14:02:23 --> Helper loaded: url_helper
INFO - 2023-05-07 14:02:23 --> Helper loaded: form_helper
INFO - 2023-05-07 14:02:23 --> Database Driver Class Initialized
INFO - 2023-05-07 14:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:02:23 --> Form Validation Class Initialized
INFO - 2023-05-07 14:02:23 --> Controller Class Initialized
INFO - 2023-05-07 14:02:23 --> Model "m_user" initialized
INFO - 2023-05-07 14:02:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:02:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:02:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:02:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:02:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:02:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-07 14:02:23 --> Final output sent to browser
INFO - 2023-05-07 14:02:37 --> Config Class Initialized
INFO - 2023-05-07 14:02:37 --> Hooks Class Initialized
INFO - 2023-05-07 14:02:37 --> Utf8 Class Initialized
INFO - 2023-05-07 14:02:37 --> URI Class Initialized
INFO - 2023-05-07 14:02:37 --> Router Class Initialized
INFO - 2023-05-07 14:02:37 --> Output Class Initialized
INFO - 2023-05-07 14:02:37 --> Security Class Initialized
INFO - 2023-05-07 14:02:37 --> Input Class Initialized
INFO - 2023-05-07 14:02:37 --> Language Class Initialized
INFO - 2023-05-07 14:02:37 --> Loader Class Initialized
INFO - 2023-05-07 14:02:37 --> Helper loaded: url_helper
INFO - 2023-05-07 14:02:37 --> Helper loaded: form_helper
INFO - 2023-05-07 14:02:37 --> Database Driver Class Initialized
INFO - 2023-05-07 14:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:02:37 --> Form Validation Class Initialized
INFO - 2023-05-07 14:02:37 --> Controller Class Initialized
INFO - 2023-05-07 14:02:37 --> Model "m_user" initialized
INFO - 2023-05-07 14:02:37 --> Config Class Initialized
INFO - 2023-05-07 14:02:37 --> Hooks Class Initialized
INFO - 2023-05-07 14:02:37 --> Utf8 Class Initialized
INFO - 2023-05-07 14:02:37 --> URI Class Initialized
INFO - 2023-05-07 14:02:37 --> Router Class Initialized
INFO - 2023-05-07 14:02:37 --> Output Class Initialized
INFO - 2023-05-07 14:02:37 --> Security Class Initialized
INFO - 2023-05-07 14:02:37 --> Input Class Initialized
INFO - 2023-05-07 14:02:37 --> Language Class Initialized
INFO - 2023-05-07 14:02:37 --> Loader Class Initialized
INFO - 2023-05-07 14:02:37 --> Helper loaded: url_helper
INFO - 2023-05-07 14:02:37 --> Helper loaded: form_helper
INFO - 2023-05-07 14:02:37 --> Database Driver Class Initialized
INFO - 2023-05-07 14:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:02:37 --> Form Validation Class Initialized
INFO - 2023-05-07 14:02:37 --> Controller Class Initialized
INFO - 2023-05-07 14:02:37 --> Model "m_user" initialized
INFO - 2023-05-07 14:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:02:37 --> Final output sent to browser
INFO - 2023-05-07 14:04:10 --> Config Class Initialized
INFO - 2023-05-07 14:04:10 --> Hooks Class Initialized
INFO - 2023-05-07 14:04:10 --> Utf8 Class Initialized
INFO - 2023-05-07 14:04:10 --> URI Class Initialized
INFO - 2023-05-07 14:04:11 --> Router Class Initialized
INFO - 2023-05-07 14:04:11 --> Output Class Initialized
INFO - 2023-05-07 14:04:11 --> Security Class Initialized
INFO - 2023-05-07 14:04:11 --> Input Class Initialized
INFO - 2023-05-07 14:04:11 --> Language Class Initialized
INFO - 2023-05-07 14:04:11 --> Loader Class Initialized
INFO - 2023-05-07 14:04:11 --> Helper loaded: url_helper
INFO - 2023-05-07 14:04:11 --> Helper loaded: form_helper
INFO - 2023-05-07 14:04:11 --> Database Driver Class Initialized
INFO - 2023-05-07 14:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:04:11 --> Form Validation Class Initialized
INFO - 2023-05-07 14:04:11 --> Controller Class Initialized
INFO - 2023-05-07 14:04:11 --> Model "m_user" initialized
INFO - 2023-05-07 14:04:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:04:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:04:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-07 14:04:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:04:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:04:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:04:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-07 14:04:11 --> Final output sent to browser
INFO - 2023-05-07 14:04:33 --> Config Class Initialized
INFO - 2023-05-07 14:04:33 --> Hooks Class Initialized
INFO - 2023-05-07 14:04:33 --> Utf8 Class Initialized
INFO - 2023-05-07 14:04:33 --> URI Class Initialized
INFO - 2023-05-07 14:04:33 --> Router Class Initialized
INFO - 2023-05-07 14:04:33 --> Output Class Initialized
INFO - 2023-05-07 14:04:33 --> Security Class Initialized
INFO - 2023-05-07 14:04:33 --> Input Class Initialized
INFO - 2023-05-07 14:04:33 --> Language Class Initialized
INFO - 2023-05-07 14:04:33 --> Loader Class Initialized
INFO - 2023-05-07 14:04:33 --> Helper loaded: url_helper
INFO - 2023-05-07 14:04:33 --> Helper loaded: form_helper
INFO - 2023-05-07 14:04:33 --> Database Driver Class Initialized
INFO - 2023-05-07 14:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:04:33 --> Form Validation Class Initialized
INFO - 2023-05-07 14:04:33 --> Controller Class Initialized
INFO - 2023-05-07 14:04:33 --> Model "m_user" initialized
INFO - 2023-05-07 14:04:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:04:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:04:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:04:33 --> Final output sent to browser
INFO - 2023-05-07 14:06:32 --> Config Class Initialized
INFO - 2023-05-07 14:06:32 --> Hooks Class Initialized
INFO - 2023-05-07 14:06:32 --> Utf8 Class Initialized
INFO - 2023-05-07 14:06:32 --> URI Class Initialized
INFO - 2023-05-07 14:06:32 --> Router Class Initialized
INFO - 2023-05-07 14:06:32 --> Output Class Initialized
INFO - 2023-05-07 14:06:32 --> Security Class Initialized
INFO - 2023-05-07 14:06:32 --> Input Class Initialized
INFO - 2023-05-07 14:06:32 --> Language Class Initialized
INFO - 2023-05-07 14:06:32 --> Loader Class Initialized
INFO - 2023-05-07 14:06:32 --> Helper loaded: url_helper
INFO - 2023-05-07 14:06:32 --> Helper loaded: form_helper
INFO - 2023-05-07 14:06:32 --> Database Driver Class Initialized
INFO - 2023-05-07 14:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:06:32 --> Form Validation Class Initialized
INFO - 2023-05-07 14:06:32 --> Controller Class Initialized
INFO - 2023-05-07 14:06:32 --> Model "m_user" initialized
INFO - 2023-05-07 14:06:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:06:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:06:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:06:32 --> Final output sent to browser
INFO - 2023-05-07 14:08:24 --> Config Class Initialized
INFO - 2023-05-07 14:08:24 --> Hooks Class Initialized
INFO - 2023-05-07 14:08:24 --> Utf8 Class Initialized
INFO - 2023-05-07 14:08:24 --> URI Class Initialized
INFO - 2023-05-07 14:08:24 --> Router Class Initialized
INFO - 2023-05-07 14:08:24 --> Output Class Initialized
INFO - 2023-05-07 14:08:24 --> Security Class Initialized
INFO - 2023-05-07 14:08:24 --> Input Class Initialized
INFO - 2023-05-07 14:08:24 --> Language Class Initialized
INFO - 2023-05-07 14:08:24 --> Loader Class Initialized
INFO - 2023-05-07 14:08:24 --> Helper loaded: url_helper
INFO - 2023-05-07 14:08:24 --> Helper loaded: form_helper
INFO - 2023-05-07 14:08:24 --> Database Driver Class Initialized
INFO - 2023-05-07 14:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:08:24 --> Form Validation Class Initialized
INFO - 2023-05-07 14:08:24 --> Controller Class Initialized
INFO - 2023-05-07 14:08:24 --> Model "m_user" initialized
INFO - 2023-05-07 14:08:24 --> Config Class Initialized
INFO - 2023-05-07 14:08:24 --> Hooks Class Initialized
INFO - 2023-05-07 14:08:24 --> Utf8 Class Initialized
INFO - 2023-05-07 14:08:24 --> URI Class Initialized
INFO - 2023-05-07 14:08:24 --> Router Class Initialized
INFO - 2023-05-07 14:08:24 --> Output Class Initialized
INFO - 2023-05-07 14:08:24 --> Security Class Initialized
INFO - 2023-05-07 14:08:24 --> Input Class Initialized
INFO - 2023-05-07 14:08:24 --> Language Class Initialized
INFO - 2023-05-07 14:08:24 --> Loader Class Initialized
INFO - 2023-05-07 14:08:24 --> Helper loaded: url_helper
INFO - 2023-05-07 14:08:24 --> Helper loaded: form_helper
INFO - 2023-05-07 14:08:24 --> Database Driver Class Initialized
INFO - 2023-05-07 14:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:08:24 --> Form Validation Class Initialized
INFO - 2023-05-07 14:08:24 --> Controller Class Initialized
INFO - 2023-05-07 14:08:24 --> Model "m_user" initialized
INFO - 2023-05-07 14:08:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:08:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:08:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:08:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:08:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:08:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-07 14:08:24 --> Final output sent to browser
INFO - 2023-05-07 14:25:01 --> Config Class Initialized
INFO - 2023-05-07 14:25:01 --> Hooks Class Initialized
INFO - 2023-05-07 14:25:01 --> Utf8 Class Initialized
INFO - 2023-05-07 14:25:01 --> URI Class Initialized
INFO - 2023-05-07 14:25:01 --> Router Class Initialized
INFO - 2023-05-07 14:25:01 --> Output Class Initialized
INFO - 2023-05-07 14:25:01 --> Security Class Initialized
INFO - 2023-05-07 14:25:01 --> Input Class Initialized
INFO - 2023-05-07 14:25:01 --> Language Class Initialized
INFO - 2023-05-07 14:25:01 --> Loader Class Initialized
INFO - 2023-05-07 14:25:01 --> Helper loaded: url_helper
INFO - 2023-05-07 14:25:01 --> Helper loaded: form_helper
INFO - 2023-05-07 14:25:01 --> Database Driver Class Initialized
INFO - 2023-05-07 14:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:25:01 --> Form Validation Class Initialized
INFO - 2023-05-07 14:25:01 --> Controller Class Initialized
INFO - 2023-05-07 14:25:01 --> Model "m_user" initialized
INFO - 2023-05-07 14:25:02 --> Config Class Initialized
INFO - 2023-05-07 14:25:02 --> Hooks Class Initialized
INFO - 2023-05-07 14:25:02 --> Utf8 Class Initialized
INFO - 2023-05-07 14:25:02 --> URI Class Initialized
INFO - 2023-05-07 14:25:02 --> Router Class Initialized
INFO - 2023-05-07 14:25:02 --> Output Class Initialized
INFO - 2023-05-07 14:25:02 --> Security Class Initialized
INFO - 2023-05-07 14:25:02 --> Input Class Initialized
INFO - 2023-05-07 14:25:02 --> Language Class Initialized
INFO - 2023-05-07 14:25:02 --> Loader Class Initialized
INFO - 2023-05-07 14:25:02 --> Helper loaded: url_helper
INFO - 2023-05-07 14:25:02 --> Helper loaded: form_helper
INFO - 2023-05-07 14:25:02 --> Database Driver Class Initialized
INFO - 2023-05-07 14:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:25:02 --> Form Validation Class Initialized
INFO - 2023-05-07 14:25:02 --> Controller Class Initialized
INFO - 2023-05-07 14:25:02 --> Model "m_user" initialized
INFO - 2023-05-07 14:25:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:25:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:25:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:25:02 --> Final output sent to browser
INFO - 2023-05-07 14:25:04 --> Config Class Initialized
INFO - 2023-05-07 14:25:04 --> Hooks Class Initialized
INFO - 2023-05-07 14:25:04 --> Utf8 Class Initialized
INFO - 2023-05-07 14:25:04 --> URI Class Initialized
INFO - 2023-05-07 14:25:04 --> Router Class Initialized
INFO - 2023-05-07 14:25:04 --> Output Class Initialized
INFO - 2023-05-07 14:25:04 --> Security Class Initialized
INFO - 2023-05-07 14:25:04 --> Input Class Initialized
INFO - 2023-05-07 14:25:04 --> Language Class Initialized
INFO - 2023-05-07 14:25:05 --> Loader Class Initialized
INFO - 2023-05-07 14:25:05 --> Helper loaded: url_helper
INFO - 2023-05-07 14:25:05 --> Helper loaded: form_helper
INFO - 2023-05-07 14:25:05 --> Database Driver Class Initialized
INFO - 2023-05-07 14:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:25:05 --> Form Validation Class Initialized
INFO - 2023-05-07 14:25:05 --> Controller Class Initialized
INFO - 2023-05-07 14:25:05 --> Model "m_user" initialized
INFO - 2023-05-07 14:25:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:25:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:25:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:25:05 --> Final output sent to browser
INFO - 2023-05-07 14:25:07 --> Config Class Initialized
INFO - 2023-05-07 14:25:07 --> Hooks Class Initialized
INFO - 2023-05-07 14:25:07 --> Utf8 Class Initialized
INFO - 2023-05-07 14:25:07 --> URI Class Initialized
INFO - 2023-05-07 14:25:07 --> Router Class Initialized
INFO - 2023-05-07 14:25:07 --> Output Class Initialized
INFO - 2023-05-07 14:25:07 --> Security Class Initialized
INFO - 2023-05-07 14:25:07 --> Input Class Initialized
INFO - 2023-05-07 14:25:07 --> Language Class Initialized
INFO - 2023-05-07 14:25:07 --> Loader Class Initialized
INFO - 2023-05-07 14:25:07 --> Helper loaded: url_helper
INFO - 2023-05-07 14:25:07 --> Helper loaded: form_helper
INFO - 2023-05-07 14:25:07 --> Database Driver Class Initialized
INFO - 2023-05-07 14:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:25:07 --> Form Validation Class Initialized
INFO - 2023-05-07 14:25:07 --> Controller Class Initialized
INFO - 2023-05-07 14:25:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:25:07 --> Final output sent to browser
INFO - 2023-05-07 14:25:08 --> Config Class Initialized
INFO - 2023-05-07 14:25:08 --> Hooks Class Initialized
INFO - 2023-05-07 14:25:08 --> Utf8 Class Initialized
INFO - 2023-05-07 14:25:08 --> URI Class Initialized
INFO - 2023-05-07 14:25:08 --> Router Class Initialized
INFO - 2023-05-07 14:25:08 --> Output Class Initialized
INFO - 2023-05-07 14:25:08 --> Security Class Initialized
INFO - 2023-05-07 14:25:08 --> Input Class Initialized
INFO - 2023-05-07 14:25:08 --> Language Class Initialized
INFO - 2023-05-07 14:25:08 --> Loader Class Initialized
INFO - 2023-05-07 14:25:08 --> Helper loaded: url_helper
INFO - 2023-05-07 14:25:08 --> Helper loaded: form_helper
INFO - 2023-05-07 14:25:08 --> Database Driver Class Initialized
INFO - 2023-05-07 14:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:25:08 --> Form Validation Class Initialized
INFO - 2023-05-07 14:25:08 --> Controller Class Initialized
INFO - 2023-05-07 14:25:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:25:08 --> Final output sent to browser
INFO - 2023-05-07 14:25:09 --> Config Class Initialized
INFO - 2023-05-07 14:25:09 --> Hooks Class Initialized
INFO - 2023-05-07 14:25:09 --> Utf8 Class Initialized
INFO - 2023-05-07 14:25:09 --> URI Class Initialized
INFO - 2023-05-07 14:25:09 --> Output Class Initialized
INFO - 2023-05-07 14:25:09 --> Security Class Initialized
INFO - 2023-05-07 14:25:09 --> Input Class Initialized
INFO - 2023-05-07 14:25:09 --> Language Class Initialized
INFO - 2023-05-07 14:25:09 --> Loader Class Initialized
INFO - 2023-05-07 14:25:10 --> Helper loaded: url_helper
INFO - 2023-05-07 14:25:10 --> Helper loaded: form_helper
INFO - 2023-05-07 14:25:10 --> Database Driver Class Initialized
INFO - 2023-05-07 14:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:25:10 --> Form Validation Class Initialized
INFO - 2023-05-07 14:25:10 --> Controller Class Initialized
INFO - 2023-05-07 14:25:10 --> Model "m_user" initialized
INFO - 2023-05-07 14:25:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:25:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-07 14:25:10 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\_partials\sidebar.php 89
INFO - 2023-05-07 14:25:53 --> Config Class Initialized
INFO - 2023-05-07 14:25:53 --> Hooks Class Initialized
INFO - 2023-05-07 14:25:53 --> Utf8 Class Initialized
INFO - 2023-05-07 14:25:53 --> URI Class Initialized
INFO - 2023-05-07 14:25:53 --> Router Class Initialized
INFO - 2023-05-07 14:25:53 --> Output Class Initialized
INFO - 2023-05-07 14:25:53 --> Security Class Initialized
INFO - 2023-05-07 14:25:53 --> Input Class Initialized
INFO - 2023-05-07 14:25:53 --> Language Class Initialized
INFO - 2023-05-07 14:25:53 --> Loader Class Initialized
INFO - 2023-05-07 14:25:53 --> Helper loaded: url_helper
INFO - 2023-05-07 14:25:53 --> Helper loaded: form_helper
INFO - 2023-05-07 14:25:53 --> Database Driver Class Initialized
INFO - 2023-05-07 14:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:25:53 --> Form Validation Class Initialized
INFO - 2023-05-07 14:25:53 --> Controller Class Initialized
INFO - 2023-05-07 14:25:53 --> Model "m_user" initialized
INFO - 2023-05-07 14:25:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:25:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:25:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-07 14:25:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:25:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:25:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home_user.php
INFO - 2023-05-07 14:25:53 --> Final output sent to browser
INFO - 2023-05-07 14:26:05 --> Config Class Initialized
INFO - 2023-05-07 14:26:05 --> Hooks Class Initialized
INFO - 2023-05-07 14:26:05 --> Utf8 Class Initialized
INFO - 2023-05-07 14:26:05 --> URI Class Initialized
INFO - 2023-05-07 14:26:05 --> Router Class Initialized
INFO - 2023-05-07 14:26:05 --> Output Class Initialized
INFO - 2023-05-07 14:26:05 --> Security Class Initialized
INFO - 2023-05-07 14:26:05 --> Input Class Initialized
INFO - 2023-05-07 14:26:05 --> Language Class Initialized
INFO - 2023-05-07 14:26:05 --> Loader Class Initialized
INFO - 2023-05-07 14:26:05 --> Helper loaded: url_helper
INFO - 2023-05-07 14:26:05 --> Helper loaded: form_helper
INFO - 2023-05-07 14:26:05 --> Database Driver Class Initialized
INFO - 2023-05-07 14:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:26:05 --> Form Validation Class Initialized
INFO - 2023-05-07 14:26:05 --> Controller Class Initialized
INFO - 2023-05-07 14:26:05 --> Model "m_user" initialized
INFO - 2023-05-07 14:26:05 --> Config Class Initialized
INFO - 2023-05-07 14:26:05 --> Hooks Class Initialized
INFO - 2023-05-07 14:26:05 --> Utf8 Class Initialized
INFO - 2023-05-07 14:26:05 --> URI Class Initialized
INFO - 2023-05-07 14:26:05 --> Router Class Initialized
INFO - 2023-05-07 14:26:05 --> Output Class Initialized
INFO - 2023-05-07 14:26:05 --> Security Class Initialized
INFO - 2023-05-07 14:26:05 --> Input Class Initialized
INFO - 2023-05-07 14:26:05 --> Language Class Initialized
INFO - 2023-05-07 14:26:05 --> Loader Class Initialized
INFO - 2023-05-07 14:26:05 --> Helper loaded: url_helper
INFO - 2023-05-07 14:26:05 --> Helper loaded: form_helper
INFO - 2023-05-07 14:26:05 --> Database Driver Class Initialized
INFO - 2023-05-07 14:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:26:05 --> Form Validation Class Initialized
INFO - 2023-05-07 14:26:05 --> Controller Class Initialized
INFO - 2023-05-07 14:26:05 --> Model "m_user" initialized
INFO - 2023-05-07 14:26:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:26:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:26:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:26:05 --> Final output sent to browser
INFO - 2023-05-07 14:26:13 --> Config Class Initialized
INFO - 2023-05-07 14:26:13 --> Hooks Class Initialized
INFO - 2023-05-07 14:26:13 --> Utf8 Class Initialized
INFO - 2023-05-07 14:26:13 --> URI Class Initialized
INFO - 2023-05-07 14:26:13 --> Router Class Initialized
INFO - 2023-05-07 14:26:13 --> Output Class Initialized
INFO - 2023-05-07 14:26:13 --> Security Class Initialized
INFO - 2023-05-07 14:26:13 --> Input Class Initialized
INFO - 2023-05-07 14:26:13 --> Language Class Initialized
INFO - 2023-05-07 14:26:13 --> Loader Class Initialized
INFO - 2023-05-07 14:26:13 --> Helper loaded: url_helper
INFO - 2023-05-07 14:26:13 --> Helper loaded: form_helper
INFO - 2023-05-07 14:26:13 --> Database Driver Class Initialized
INFO - 2023-05-07 14:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:26:13 --> Form Validation Class Initialized
INFO - 2023-05-07 14:26:13 --> Controller Class Initialized
INFO - 2023-05-07 14:26:13 --> Model "m_user" initialized
INFO - 2023-05-07 14:26:13 --> Config Class Initialized
INFO - 2023-05-07 14:26:13 --> Hooks Class Initialized
INFO - 2023-05-07 14:26:13 --> Utf8 Class Initialized
INFO - 2023-05-07 14:26:13 --> URI Class Initialized
INFO - 2023-05-07 14:26:13 --> Router Class Initialized
INFO - 2023-05-07 14:26:13 --> Output Class Initialized
INFO - 2023-05-07 14:26:13 --> Security Class Initialized
INFO - 2023-05-07 14:26:13 --> Input Class Initialized
INFO - 2023-05-07 14:26:13 --> Language Class Initialized
INFO - 2023-05-07 14:26:13 --> Loader Class Initialized
INFO - 2023-05-07 14:26:13 --> Helper loaded: url_helper
INFO - 2023-05-07 14:26:13 --> Helper loaded: form_helper
INFO - 2023-05-07 14:26:13 --> Database Driver Class Initialized
INFO - 2023-05-07 14:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:26:13 --> Form Validation Class Initialized
INFO - 2023-05-07 14:26:13 --> Controller Class Initialized
INFO - 2023-05-07 14:26:13 --> Model "m_user" initialized
INFO - 2023-05-07 14:26:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:26:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-07 14:26:13 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\_partials\sidebar.php 89
INFO - 2023-05-07 14:31:09 --> Config Class Initialized
INFO - 2023-05-07 14:31:09 --> Hooks Class Initialized
INFO - 2023-05-07 14:31:09 --> Utf8 Class Initialized
INFO - 2023-05-07 14:31:09 --> URI Class Initialized
INFO - 2023-05-07 14:31:09 --> Router Class Initialized
INFO - 2023-05-07 14:31:09 --> Output Class Initialized
INFO - 2023-05-07 14:31:09 --> Security Class Initialized
INFO - 2023-05-07 14:31:09 --> Input Class Initialized
INFO - 2023-05-07 14:31:09 --> Language Class Initialized
INFO - 2023-05-07 14:31:09 --> Loader Class Initialized
INFO - 2023-05-07 14:31:09 --> Helper loaded: url_helper
INFO - 2023-05-07 14:31:09 --> Helper loaded: form_helper
INFO - 2023-05-07 14:31:09 --> Database Driver Class Initialized
INFO - 2023-05-07 14:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:31:09 --> Form Validation Class Initialized
INFO - 2023-05-07 14:31:09 --> Controller Class Initialized
INFO - 2023-05-07 14:31:09 --> Model "m_user" initialized
INFO - 2023-05-07 14:31:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:31:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-07 14:31:09 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\_partials\sidebar.php 157
INFO - 2023-05-07 14:31:17 --> Config Class Initialized
INFO - 2023-05-07 14:31:17 --> Hooks Class Initialized
INFO - 2023-05-07 14:31:17 --> Utf8 Class Initialized
INFO - 2023-05-07 14:31:17 --> URI Class Initialized
INFO - 2023-05-07 14:31:17 --> Router Class Initialized
INFO - 2023-05-07 14:31:17 --> Output Class Initialized
INFO - 2023-05-07 14:31:17 --> Security Class Initialized
INFO - 2023-05-07 14:31:17 --> Input Class Initialized
INFO - 2023-05-07 14:31:17 --> Language Class Initialized
INFO - 2023-05-07 14:31:17 --> Loader Class Initialized
INFO - 2023-05-07 14:31:17 --> Helper loaded: url_helper
INFO - 2023-05-07 14:31:17 --> Helper loaded: form_helper
INFO - 2023-05-07 14:31:17 --> Database Driver Class Initialized
INFO - 2023-05-07 14:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:31:17 --> Form Validation Class Initialized
INFO - 2023-05-07 14:31:17 --> Controller Class Initialized
INFO - 2023-05-07 14:31:17 --> Model "m_user" initialized
INFO - 2023-05-07 14:31:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:31:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-07 14:31:17 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\_partials\sidebar.php 157
INFO - 2023-05-07 14:31:18 --> Config Class Initialized
INFO - 2023-05-07 14:31:18 --> Hooks Class Initialized
INFO - 2023-05-07 14:31:18 --> Utf8 Class Initialized
INFO - 2023-05-07 14:31:18 --> URI Class Initialized
INFO - 2023-05-07 14:31:18 --> Router Class Initialized
INFO - 2023-05-07 14:31:18 --> Output Class Initialized
INFO - 2023-05-07 14:31:18 --> Security Class Initialized
INFO - 2023-05-07 14:31:18 --> Input Class Initialized
INFO - 2023-05-07 14:31:18 --> Language Class Initialized
INFO - 2023-05-07 14:31:18 --> Loader Class Initialized
INFO - 2023-05-07 14:31:18 --> Helper loaded: url_helper
INFO - 2023-05-07 14:31:18 --> Helper loaded: form_helper
INFO - 2023-05-07 14:31:18 --> Database Driver Class Initialized
INFO - 2023-05-07 14:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:31:18 --> Form Validation Class Initialized
INFO - 2023-05-07 14:31:18 --> Controller Class Initialized
INFO - 2023-05-07 14:31:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:31:18 --> Final output sent to browser
INFO - 2023-05-07 14:31:19 --> Config Class Initialized
INFO - 2023-05-07 14:31:19 --> Hooks Class Initialized
INFO - 2023-05-07 14:31:19 --> Utf8 Class Initialized
INFO - 2023-05-07 14:31:19 --> URI Class Initialized
INFO - 2023-05-07 14:31:19 --> Router Class Initialized
INFO - 2023-05-07 14:31:19 --> Output Class Initialized
INFO - 2023-05-07 14:31:19 --> Security Class Initialized
INFO - 2023-05-07 14:31:19 --> Input Class Initialized
INFO - 2023-05-07 14:31:19 --> Language Class Initialized
INFO - 2023-05-07 14:31:19 --> Loader Class Initialized
INFO - 2023-05-07 14:31:19 --> Helper loaded: url_helper
INFO - 2023-05-07 14:31:19 --> Helper loaded: form_helper
INFO - 2023-05-07 14:31:19 --> Database Driver Class Initialized
INFO - 2023-05-07 14:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:31:19 --> Form Validation Class Initialized
INFO - 2023-05-07 14:31:19 --> Controller Class Initialized
INFO - 2023-05-07 14:31:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:31:19 --> Final output sent to browser
INFO - 2023-05-07 14:31:21 --> Config Class Initialized
INFO - 2023-05-07 14:31:21 --> Hooks Class Initialized
INFO - 2023-05-07 14:31:21 --> Utf8 Class Initialized
INFO - 2023-05-07 14:31:21 --> URI Class Initialized
INFO - 2023-05-07 14:31:21 --> Router Class Initialized
INFO - 2023-05-07 14:31:21 --> Output Class Initialized
INFO - 2023-05-07 14:31:21 --> Security Class Initialized
INFO - 2023-05-07 14:31:21 --> Input Class Initialized
INFO - 2023-05-07 14:31:21 --> Language Class Initialized
INFO - 2023-05-07 14:31:21 --> Loader Class Initialized
INFO - 2023-05-07 14:31:21 --> Helper loaded: url_helper
INFO - 2023-05-07 14:31:21 --> Helper loaded: form_helper
INFO - 2023-05-07 14:31:21 --> Database Driver Class Initialized
INFO - 2023-05-07 14:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:31:21 --> Form Validation Class Initialized
INFO - 2023-05-07 14:31:21 --> Controller Class Initialized
INFO - 2023-05-07 14:31:21 --> Model "m_user" initialized
INFO - 2023-05-07 14:31:21 --> Config Class Initialized
INFO - 2023-05-07 14:31:21 --> Hooks Class Initialized
INFO - 2023-05-07 14:31:21 --> Utf8 Class Initialized
INFO - 2023-05-07 14:31:21 --> URI Class Initialized
INFO - 2023-05-07 14:31:21 --> Router Class Initialized
INFO - 2023-05-07 14:31:21 --> Output Class Initialized
INFO - 2023-05-07 14:31:21 --> Security Class Initialized
INFO - 2023-05-07 14:31:21 --> Input Class Initialized
INFO - 2023-05-07 14:31:21 --> Language Class Initialized
INFO - 2023-05-07 14:31:21 --> Loader Class Initialized
INFO - 2023-05-07 14:31:21 --> Helper loaded: url_helper
INFO - 2023-05-07 14:31:21 --> Helper loaded: form_helper
INFO - 2023-05-07 14:31:21 --> Database Driver Class Initialized
INFO - 2023-05-07 14:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:31:21 --> Form Validation Class Initialized
INFO - 2023-05-07 14:31:21 --> Controller Class Initialized
INFO - 2023-05-07 14:31:21 --> Model "m_user" initialized
INFO - 2023-05-07 14:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-07 14:31:21 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\_partials\sidebar.php 157
INFO - 2023-05-07 14:32:16 --> Config Class Initialized
INFO - 2023-05-07 14:32:16 --> Hooks Class Initialized
INFO - 2023-05-07 14:32:16 --> Utf8 Class Initialized
INFO - 2023-05-07 14:32:16 --> URI Class Initialized
INFO - 2023-05-07 14:32:16 --> Router Class Initialized
INFO - 2023-05-07 14:32:16 --> Output Class Initialized
INFO - 2023-05-07 14:32:16 --> Security Class Initialized
INFO - 2023-05-07 14:32:16 --> Input Class Initialized
INFO - 2023-05-07 14:32:16 --> Language Class Initialized
INFO - 2023-05-07 14:32:16 --> Loader Class Initialized
INFO - 2023-05-07 14:32:16 --> Helper loaded: url_helper
INFO - 2023-05-07 14:32:16 --> Helper loaded: form_helper
INFO - 2023-05-07 14:32:16 --> Database Driver Class Initialized
INFO - 2023-05-07 14:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:32:16 --> Form Validation Class Initialized
INFO - 2023-05-07 14:32:16 --> Controller Class Initialized
INFO - 2023-05-07 14:32:16 --> Model "m_user" initialized
INFO - 2023-05-07 14:32:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:32:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-07 14:32:16 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\_partials\sidebar.php 156
INFO - 2023-05-07 14:32:53 --> Config Class Initialized
INFO - 2023-05-07 14:32:53 --> Hooks Class Initialized
INFO - 2023-05-07 14:32:53 --> Utf8 Class Initialized
INFO - 2023-05-07 14:32:53 --> URI Class Initialized
INFO - 2023-05-07 14:32:53 --> Router Class Initialized
INFO - 2023-05-07 14:32:53 --> Output Class Initialized
INFO - 2023-05-07 14:32:53 --> Security Class Initialized
INFO - 2023-05-07 14:32:53 --> Input Class Initialized
INFO - 2023-05-07 14:32:53 --> Language Class Initialized
INFO - 2023-05-07 14:32:53 --> Loader Class Initialized
INFO - 2023-05-07 14:32:53 --> Helper loaded: url_helper
INFO - 2023-05-07 14:32:53 --> Helper loaded: form_helper
INFO - 2023-05-07 14:32:53 --> Database Driver Class Initialized
INFO - 2023-05-07 14:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:32:53 --> Form Validation Class Initialized
INFO - 2023-05-07 14:32:53 --> Controller Class Initialized
INFO - 2023-05-07 14:32:53 --> Model "m_user" initialized
INFO - 2023-05-07 14:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 14:32:53 --> Final output sent to browser
INFO - 2023-05-07 14:33:25 --> Config Class Initialized
INFO - 2023-05-07 14:33:25 --> Hooks Class Initialized
INFO - 2023-05-07 14:33:25 --> Utf8 Class Initialized
INFO - 2023-05-07 14:33:25 --> URI Class Initialized
INFO - 2023-05-07 14:33:25 --> Router Class Initialized
INFO - 2023-05-07 14:33:25 --> Output Class Initialized
INFO - 2023-05-07 14:33:25 --> Security Class Initialized
INFO - 2023-05-07 14:33:25 --> Input Class Initialized
INFO - 2023-05-07 14:33:25 --> Language Class Initialized
INFO - 2023-05-07 14:33:25 --> Loader Class Initialized
INFO - 2023-05-07 14:33:25 --> Helper loaded: url_helper
INFO - 2023-05-07 14:33:25 --> Helper loaded: form_helper
INFO - 2023-05-07 14:33:25 --> Database Driver Class Initialized
INFO - 2023-05-07 14:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:33:25 --> Form Validation Class Initialized
INFO - 2023-05-07 14:33:25 --> Controller Class Initialized
INFO - 2023-05-07 14:33:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:33:25 --> Final output sent to browser
INFO - 2023-05-07 14:33:26 --> Config Class Initialized
INFO - 2023-05-07 14:33:26 --> Hooks Class Initialized
INFO - 2023-05-07 14:33:26 --> Utf8 Class Initialized
INFO - 2023-05-07 14:33:26 --> URI Class Initialized
INFO - 2023-05-07 14:33:26 --> Router Class Initialized
INFO - 2023-05-07 14:33:26 --> Output Class Initialized
INFO - 2023-05-07 14:33:26 --> Security Class Initialized
INFO - 2023-05-07 14:33:26 --> Input Class Initialized
INFO - 2023-05-07 14:33:26 --> Language Class Initialized
INFO - 2023-05-07 14:33:26 --> Loader Class Initialized
INFO - 2023-05-07 14:33:26 --> Helper loaded: url_helper
INFO - 2023-05-07 14:33:26 --> Helper loaded: form_helper
INFO - 2023-05-07 14:33:26 --> Database Driver Class Initialized
INFO - 2023-05-07 14:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:33:26 --> Form Validation Class Initialized
INFO - 2023-05-07 14:33:26 --> Controller Class Initialized
INFO - 2023-05-07 14:33:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:33:26 --> Final output sent to browser
INFO - 2023-05-07 14:33:31 --> Config Class Initialized
INFO - 2023-05-07 14:33:31 --> Hooks Class Initialized
INFO - 2023-05-07 14:33:31 --> Utf8 Class Initialized
INFO - 2023-05-07 14:33:31 --> URI Class Initialized
INFO - 2023-05-07 14:33:31 --> Router Class Initialized
INFO - 2023-05-07 14:33:31 --> Output Class Initialized
INFO - 2023-05-07 14:33:31 --> Security Class Initialized
INFO - 2023-05-07 14:33:31 --> Input Class Initialized
INFO - 2023-05-07 14:33:31 --> Language Class Initialized
INFO - 2023-05-07 14:33:31 --> Loader Class Initialized
INFO - 2023-05-07 14:33:31 --> Helper loaded: url_helper
INFO - 2023-05-07 14:33:31 --> Helper loaded: form_helper
INFO - 2023-05-07 14:33:31 --> Database Driver Class Initialized
INFO - 2023-05-07 14:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:33:31 --> Form Validation Class Initialized
INFO - 2023-05-07 14:33:31 --> Controller Class Initialized
INFO - 2023-05-07 14:33:31 --> Model "m_user" initialized
INFO - 2023-05-07 14:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:33:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:33:31 --> Final output sent to browser
INFO - 2023-05-07 14:33:34 --> Config Class Initialized
INFO - 2023-05-07 14:33:34 --> Hooks Class Initialized
INFO - 2023-05-07 14:33:34 --> Utf8 Class Initialized
INFO - 2023-05-07 14:33:34 --> URI Class Initialized
INFO - 2023-05-07 14:33:34 --> Router Class Initialized
INFO - 2023-05-07 14:33:34 --> Output Class Initialized
INFO - 2023-05-07 14:33:34 --> Security Class Initialized
INFO - 2023-05-07 14:33:34 --> Input Class Initialized
INFO - 2023-05-07 14:33:34 --> Language Class Initialized
INFO - 2023-05-07 14:33:34 --> Loader Class Initialized
INFO - 2023-05-07 14:33:34 --> Helper loaded: url_helper
INFO - 2023-05-07 14:33:34 --> Helper loaded: form_helper
INFO - 2023-05-07 14:33:34 --> Database Driver Class Initialized
INFO - 2023-05-07 14:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:33:34 --> Form Validation Class Initialized
INFO - 2023-05-07 14:33:34 --> Controller Class Initialized
INFO - 2023-05-07 14:33:34 --> Model "m_user" initialized
INFO - 2023-05-07 14:33:35 --> Config Class Initialized
INFO - 2023-05-07 14:33:35 --> Hooks Class Initialized
INFO - 2023-05-07 14:33:35 --> Utf8 Class Initialized
INFO - 2023-05-07 14:33:35 --> URI Class Initialized
INFO - 2023-05-07 14:33:35 --> Router Class Initialized
INFO - 2023-05-07 14:33:35 --> Output Class Initialized
INFO - 2023-05-07 14:33:35 --> Security Class Initialized
INFO - 2023-05-07 14:33:35 --> Input Class Initialized
INFO - 2023-05-07 14:33:35 --> Language Class Initialized
INFO - 2023-05-07 14:33:35 --> Loader Class Initialized
INFO - 2023-05-07 14:33:35 --> Helper loaded: url_helper
INFO - 2023-05-07 14:33:35 --> Helper loaded: form_helper
INFO - 2023-05-07 14:33:35 --> Database Driver Class Initialized
INFO - 2023-05-07 14:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:33:35 --> Form Validation Class Initialized
INFO - 2023-05-07 14:33:35 --> Controller Class Initialized
INFO - 2023-05-07 14:33:35 --> Model "m_user" initialized
INFO - 2023-05-07 14:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 14:33:35 --> Final output sent to browser
INFO - 2023-05-07 14:33:39 --> Config Class Initialized
INFO - 2023-05-07 14:33:39 --> Hooks Class Initialized
INFO - 2023-05-07 14:33:39 --> Utf8 Class Initialized
INFO - 2023-05-07 14:33:39 --> URI Class Initialized
INFO - 2023-05-07 14:33:39 --> Router Class Initialized
INFO - 2023-05-07 14:33:39 --> Output Class Initialized
INFO - 2023-05-07 14:33:39 --> Security Class Initialized
INFO - 2023-05-07 14:33:39 --> Input Class Initialized
INFO - 2023-05-07 14:33:39 --> Language Class Initialized
INFO - 2023-05-07 14:33:39 --> Loader Class Initialized
INFO - 2023-05-07 14:33:39 --> Helper loaded: url_helper
INFO - 2023-05-07 14:33:39 --> Helper loaded: form_helper
INFO - 2023-05-07 14:33:39 --> Database Driver Class Initialized
INFO - 2023-05-07 14:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:33:39 --> Form Validation Class Initialized
INFO - 2023-05-07 14:33:39 --> Controller Class Initialized
INFO - 2023-05-07 14:33:39 --> Model "m_user" initialized
INFO - 2023-05-07 14:33:39 --> Config Class Initialized
INFO - 2023-05-07 14:33:39 --> Hooks Class Initialized
INFO - 2023-05-07 14:33:39 --> Utf8 Class Initialized
INFO - 2023-05-07 14:33:39 --> URI Class Initialized
INFO - 2023-05-07 14:33:39 --> Router Class Initialized
INFO - 2023-05-07 14:33:39 --> Output Class Initialized
INFO - 2023-05-07 14:33:39 --> Security Class Initialized
INFO - 2023-05-07 14:33:39 --> Input Class Initialized
INFO - 2023-05-07 14:33:39 --> Language Class Initialized
INFO - 2023-05-07 14:33:39 --> Loader Class Initialized
INFO - 2023-05-07 14:33:39 --> Helper loaded: url_helper
INFO - 2023-05-07 14:33:39 --> Helper loaded: form_helper
INFO - 2023-05-07 14:33:39 --> Database Driver Class Initialized
INFO - 2023-05-07 14:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:33:39 --> Form Validation Class Initialized
INFO - 2023-05-07 14:33:39 --> Controller Class Initialized
INFO - 2023-05-07 14:33:39 --> Model "m_user" initialized
INFO - 2023-05-07 14:33:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:33:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:33:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:33:39 --> Final output sent to browser
INFO - 2023-05-07 14:33:45 --> Config Class Initialized
INFO - 2023-05-07 14:33:45 --> Hooks Class Initialized
INFO - 2023-05-07 14:33:45 --> Utf8 Class Initialized
INFO - 2023-05-07 14:33:45 --> URI Class Initialized
INFO - 2023-05-07 14:33:45 --> Router Class Initialized
INFO - 2023-05-07 14:33:45 --> Output Class Initialized
INFO - 2023-05-07 14:33:45 --> Security Class Initialized
INFO - 2023-05-07 14:33:45 --> Input Class Initialized
INFO - 2023-05-07 14:33:45 --> Language Class Initialized
INFO - 2023-05-07 14:33:45 --> Loader Class Initialized
INFO - 2023-05-07 14:33:45 --> Helper loaded: url_helper
INFO - 2023-05-07 14:33:45 --> Helper loaded: form_helper
INFO - 2023-05-07 14:33:45 --> Database Driver Class Initialized
INFO - 2023-05-07 14:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:33:45 --> Form Validation Class Initialized
INFO - 2023-05-07 14:33:45 --> Controller Class Initialized
INFO - 2023-05-07 14:33:45 --> Model "m_user" initialized
INFO - 2023-05-07 14:33:45 --> Config Class Initialized
INFO - 2023-05-07 14:33:45 --> Hooks Class Initialized
INFO - 2023-05-07 14:33:45 --> Utf8 Class Initialized
INFO - 2023-05-07 14:33:45 --> URI Class Initialized
INFO - 2023-05-07 14:33:45 --> Router Class Initialized
INFO - 2023-05-07 14:33:45 --> Output Class Initialized
INFO - 2023-05-07 14:33:45 --> Security Class Initialized
INFO - 2023-05-07 14:33:45 --> Input Class Initialized
INFO - 2023-05-07 14:33:45 --> Language Class Initialized
INFO - 2023-05-07 14:33:45 --> Loader Class Initialized
INFO - 2023-05-07 14:33:45 --> Helper loaded: url_helper
INFO - 2023-05-07 14:33:45 --> Helper loaded: form_helper
INFO - 2023-05-07 14:33:45 --> Database Driver Class Initialized
INFO - 2023-05-07 14:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:33:45 --> Form Validation Class Initialized
INFO - 2023-05-07 14:33:45 --> Controller Class Initialized
INFO - 2023-05-07 14:33:45 --> Model "m_user" initialized
INFO - 2023-05-07 14:33:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:33:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:33:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:33:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:33:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:33:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 14:33:45 --> Final output sent to browser
INFO - 2023-05-07 14:36:17 --> Config Class Initialized
INFO - 2023-05-07 14:36:17 --> Hooks Class Initialized
INFO - 2023-05-07 14:36:17 --> Utf8 Class Initialized
INFO - 2023-05-07 14:36:17 --> URI Class Initialized
INFO - 2023-05-07 14:36:17 --> Router Class Initialized
INFO - 2023-05-07 14:36:17 --> Output Class Initialized
INFO - 2023-05-07 14:36:17 --> Security Class Initialized
INFO - 2023-05-07 14:36:17 --> Input Class Initialized
INFO - 2023-05-07 14:36:17 --> Language Class Initialized
INFO - 2023-05-07 14:36:17 --> Loader Class Initialized
INFO - 2023-05-07 14:36:17 --> Helper loaded: url_helper
INFO - 2023-05-07 14:36:17 --> Helper loaded: form_helper
INFO - 2023-05-07 14:36:17 --> Database Driver Class Initialized
INFO - 2023-05-07 14:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:36:17 --> Form Validation Class Initialized
INFO - 2023-05-07 14:36:17 --> Controller Class Initialized
INFO - 2023-05-07 14:36:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:36:17 --> Final output sent to browser
INFO - 2023-05-07 14:36:20 --> Config Class Initialized
INFO - 2023-05-07 14:36:20 --> Hooks Class Initialized
INFO - 2023-05-07 14:36:20 --> Utf8 Class Initialized
INFO - 2023-05-07 14:36:20 --> URI Class Initialized
INFO - 2023-05-07 14:36:20 --> Router Class Initialized
INFO - 2023-05-07 14:36:20 --> Output Class Initialized
INFO - 2023-05-07 14:36:20 --> Security Class Initialized
INFO - 2023-05-07 14:36:20 --> Input Class Initialized
INFO - 2023-05-07 14:36:20 --> Language Class Initialized
INFO - 2023-05-07 14:36:20 --> Loader Class Initialized
INFO - 2023-05-07 14:36:20 --> Helper loaded: url_helper
INFO - 2023-05-07 14:36:20 --> Helper loaded: form_helper
INFO - 2023-05-07 14:36:20 --> Database Driver Class Initialized
INFO - 2023-05-07 14:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:36:20 --> Form Validation Class Initialized
INFO - 2023-05-07 14:36:20 --> Controller Class Initialized
INFO - 2023-05-07 14:36:20 --> Model "m_user" initialized
INFO - 2023-05-07 14:36:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:36:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:36:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:36:20 --> Final output sent to browser
INFO - 2023-05-07 14:36:25 --> Config Class Initialized
INFO - 2023-05-07 14:36:25 --> Hooks Class Initialized
INFO - 2023-05-07 14:36:25 --> Utf8 Class Initialized
INFO - 2023-05-07 14:36:25 --> URI Class Initialized
INFO - 2023-05-07 14:36:25 --> Router Class Initialized
INFO - 2023-05-07 14:36:25 --> Output Class Initialized
INFO - 2023-05-07 14:36:25 --> Security Class Initialized
INFO - 2023-05-07 14:36:25 --> Input Class Initialized
INFO - 2023-05-07 14:36:25 --> Language Class Initialized
INFO - 2023-05-07 14:36:25 --> Loader Class Initialized
INFO - 2023-05-07 14:36:25 --> Helper loaded: url_helper
INFO - 2023-05-07 14:36:25 --> Helper loaded: form_helper
INFO - 2023-05-07 14:36:25 --> Database Driver Class Initialized
INFO - 2023-05-07 14:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:36:25 --> Form Validation Class Initialized
INFO - 2023-05-07 14:36:25 --> Controller Class Initialized
INFO - 2023-05-07 14:36:25 --> Model "m_user" initialized
INFO - 2023-05-07 14:36:25 --> Config Class Initialized
INFO - 2023-05-07 14:36:25 --> Hooks Class Initialized
INFO - 2023-05-07 14:36:25 --> Utf8 Class Initialized
INFO - 2023-05-07 14:36:25 --> URI Class Initialized
INFO - 2023-05-07 14:36:25 --> Router Class Initialized
INFO - 2023-05-07 14:36:25 --> Output Class Initialized
INFO - 2023-05-07 14:36:25 --> Security Class Initialized
INFO - 2023-05-07 14:36:25 --> Input Class Initialized
INFO - 2023-05-07 14:36:25 --> Language Class Initialized
INFO - 2023-05-07 14:36:25 --> Loader Class Initialized
INFO - 2023-05-07 14:36:25 --> Helper loaded: url_helper
INFO - 2023-05-07 14:36:25 --> Helper loaded: form_helper
INFO - 2023-05-07 14:36:25 --> Database Driver Class Initialized
INFO - 2023-05-07 14:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:36:25 --> Form Validation Class Initialized
INFO - 2023-05-07 14:36:25 --> Controller Class Initialized
INFO - 2023-05-07 14:36:25 --> Model "m_user" initialized
INFO - 2023-05-07 14:36:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:36:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:36:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:36:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:36:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:36:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 14:36:25 --> Final output sent to browser
INFO - 2023-05-07 14:39:21 --> Config Class Initialized
INFO - 2023-05-07 14:39:21 --> Hooks Class Initialized
INFO - 2023-05-07 14:39:21 --> Utf8 Class Initialized
INFO - 2023-05-07 14:39:21 --> URI Class Initialized
INFO - 2023-05-07 14:39:21 --> Router Class Initialized
INFO - 2023-05-07 14:39:21 --> Output Class Initialized
INFO - 2023-05-07 14:39:21 --> Security Class Initialized
INFO - 2023-05-07 14:39:21 --> Input Class Initialized
INFO - 2023-05-07 14:39:21 --> Language Class Initialized
INFO - 2023-05-07 14:39:21 --> Loader Class Initialized
INFO - 2023-05-07 14:39:21 --> Helper loaded: url_helper
INFO - 2023-05-07 14:39:21 --> Helper loaded: form_helper
INFO - 2023-05-07 14:39:21 --> Database Driver Class Initialized
INFO - 2023-05-07 14:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:39:21 --> Form Validation Class Initialized
INFO - 2023-05-07 14:39:21 --> Controller Class Initialized
INFO - 2023-05-07 14:39:21 --> Model "m_user" initialized
INFO - 2023-05-07 14:39:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:39:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:39:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:39:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:39:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:39:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 14:39:21 --> Final output sent to browser
INFO - 2023-05-07 14:39:24 --> Config Class Initialized
INFO - 2023-05-07 14:39:24 --> Hooks Class Initialized
INFO - 2023-05-07 14:39:24 --> Utf8 Class Initialized
INFO - 2023-05-07 14:39:24 --> URI Class Initialized
INFO - 2023-05-07 14:39:24 --> Router Class Initialized
INFO - 2023-05-07 14:39:24 --> Output Class Initialized
INFO - 2023-05-07 14:39:24 --> Security Class Initialized
INFO - 2023-05-07 14:39:24 --> Input Class Initialized
INFO - 2023-05-07 14:39:24 --> Language Class Initialized
INFO - 2023-05-07 14:39:24 --> Loader Class Initialized
INFO - 2023-05-07 14:39:24 --> Helper loaded: url_helper
INFO - 2023-05-07 14:39:24 --> Helper loaded: form_helper
INFO - 2023-05-07 14:39:24 --> Database Driver Class Initialized
INFO - 2023-05-07 14:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:39:24 --> Form Validation Class Initialized
INFO - 2023-05-07 14:39:24 --> Controller Class Initialized
INFO - 2023-05-07 14:39:24 --> Model "m_user" initialized
INFO - 2023-05-07 14:39:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:39:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:39:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:39:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:39:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:39:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 14:39:24 --> Final output sent to browser
INFO - 2023-05-07 14:39:43 --> Config Class Initialized
INFO - 2023-05-07 14:39:43 --> Hooks Class Initialized
INFO - 2023-05-07 14:39:43 --> Utf8 Class Initialized
INFO - 2023-05-07 14:39:43 --> URI Class Initialized
INFO - 2023-05-07 14:39:43 --> Router Class Initialized
INFO - 2023-05-07 14:39:43 --> Output Class Initialized
INFO - 2023-05-07 14:39:43 --> Security Class Initialized
INFO - 2023-05-07 14:39:43 --> Input Class Initialized
INFO - 2023-05-07 14:39:43 --> Language Class Initialized
INFO - 2023-05-07 14:39:43 --> Loader Class Initialized
INFO - 2023-05-07 14:39:43 --> Helper loaded: url_helper
INFO - 2023-05-07 14:39:43 --> Helper loaded: form_helper
INFO - 2023-05-07 14:39:43 --> Database Driver Class Initialized
INFO - 2023-05-07 14:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:39:43 --> Form Validation Class Initialized
INFO - 2023-05-07 14:39:43 --> Controller Class Initialized
INFO - 2023-05-07 14:39:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:39:43 --> Final output sent to browser
INFO - 2023-05-07 14:39:44 --> Config Class Initialized
INFO - 2023-05-07 14:39:44 --> Hooks Class Initialized
INFO - 2023-05-07 14:39:44 --> Utf8 Class Initialized
INFO - 2023-05-07 14:39:44 --> URI Class Initialized
INFO - 2023-05-07 14:39:44 --> Router Class Initialized
INFO - 2023-05-07 14:39:44 --> Output Class Initialized
INFO - 2023-05-07 14:39:44 --> Security Class Initialized
INFO - 2023-05-07 14:39:44 --> Input Class Initialized
INFO - 2023-05-07 14:39:44 --> Language Class Initialized
INFO - 2023-05-07 14:39:44 --> Loader Class Initialized
INFO - 2023-05-07 14:39:44 --> Helper loaded: url_helper
INFO - 2023-05-07 14:39:44 --> Helper loaded: form_helper
INFO - 2023-05-07 14:39:44 --> Database Driver Class Initialized
INFO - 2023-05-07 14:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:39:44 --> Form Validation Class Initialized
INFO - 2023-05-07 14:39:44 --> Controller Class Initialized
INFO - 2023-05-07 14:39:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:39:44 --> Final output sent to browser
INFO - 2023-05-07 14:39:46 --> Config Class Initialized
INFO - 2023-05-07 14:39:46 --> Hooks Class Initialized
INFO - 2023-05-07 14:39:46 --> Utf8 Class Initialized
INFO - 2023-05-07 14:39:46 --> URI Class Initialized
INFO - 2023-05-07 14:39:46 --> Router Class Initialized
INFO - 2023-05-07 14:39:46 --> Output Class Initialized
INFO - 2023-05-07 14:39:46 --> Security Class Initialized
INFO - 2023-05-07 14:39:46 --> Input Class Initialized
INFO - 2023-05-07 14:39:46 --> Language Class Initialized
INFO - 2023-05-07 14:39:46 --> Loader Class Initialized
INFO - 2023-05-07 14:39:46 --> Helper loaded: url_helper
INFO - 2023-05-07 14:39:46 --> Helper loaded: form_helper
INFO - 2023-05-07 14:39:46 --> Database Driver Class Initialized
INFO - 2023-05-07 14:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:39:46 --> Form Validation Class Initialized
INFO - 2023-05-07 14:39:46 --> Controller Class Initialized
INFO - 2023-05-07 14:39:46 --> Model "m_user" initialized
INFO - 2023-05-07 14:39:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:39:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:39:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:39:46 --> Final output sent to browser
INFO - 2023-05-07 14:39:49 --> Config Class Initialized
INFO - 2023-05-07 14:39:49 --> Hooks Class Initialized
INFO - 2023-05-07 14:39:49 --> Utf8 Class Initialized
INFO - 2023-05-07 14:39:49 --> URI Class Initialized
INFO - 2023-05-07 14:39:49 --> Router Class Initialized
INFO - 2023-05-07 14:39:49 --> Output Class Initialized
INFO - 2023-05-07 14:39:49 --> Security Class Initialized
INFO - 2023-05-07 14:39:49 --> Input Class Initialized
INFO - 2023-05-07 14:39:49 --> Language Class Initialized
INFO - 2023-05-07 14:39:49 --> Loader Class Initialized
INFO - 2023-05-07 14:39:49 --> Helper loaded: url_helper
INFO - 2023-05-07 14:39:49 --> Helper loaded: form_helper
INFO - 2023-05-07 14:39:49 --> Database Driver Class Initialized
INFO - 2023-05-07 14:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:39:49 --> Form Validation Class Initialized
INFO - 2023-05-07 14:39:49 --> Controller Class Initialized
INFO - 2023-05-07 14:39:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:39:49 --> Final output sent to browser
INFO - 2023-05-07 14:39:50 --> Config Class Initialized
INFO - 2023-05-07 14:39:50 --> Hooks Class Initialized
INFO - 2023-05-07 14:39:50 --> Utf8 Class Initialized
INFO - 2023-05-07 14:39:50 --> URI Class Initialized
INFO - 2023-05-07 14:39:50 --> Router Class Initialized
INFO - 2023-05-07 14:39:50 --> Output Class Initialized
INFO - 2023-05-07 14:39:50 --> Security Class Initialized
INFO - 2023-05-07 14:39:50 --> Input Class Initialized
INFO - 2023-05-07 14:39:50 --> Language Class Initialized
INFO - 2023-05-07 14:39:50 --> Loader Class Initialized
INFO - 2023-05-07 14:39:50 --> Helper loaded: url_helper
INFO - 2023-05-07 14:39:50 --> Helper loaded: form_helper
INFO - 2023-05-07 14:39:50 --> Database Driver Class Initialized
INFO - 2023-05-07 14:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:39:50 --> Form Validation Class Initialized
INFO - 2023-05-07 14:39:50 --> Controller Class Initialized
INFO - 2023-05-07 14:39:50 --> Model "m_user" initialized
INFO - 2023-05-07 14:39:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:39:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:39:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-07 14:39:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:39:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:39:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home_user.php
INFO - 2023-05-07 14:39:50 --> Final output sent to browser
INFO - 2023-05-07 14:40:55 --> Config Class Initialized
INFO - 2023-05-07 14:40:55 --> Hooks Class Initialized
INFO - 2023-05-07 14:40:55 --> Utf8 Class Initialized
INFO - 2023-05-07 14:40:55 --> URI Class Initialized
INFO - 2023-05-07 14:40:55 --> Router Class Initialized
INFO - 2023-05-07 14:40:55 --> Output Class Initialized
INFO - 2023-05-07 14:40:55 --> Security Class Initialized
INFO - 2023-05-07 14:40:55 --> Input Class Initialized
INFO - 2023-05-07 14:40:55 --> Language Class Initialized
INFO - 2023-05-07 14:40:55 --> Loader Class Initialized
INFO - 2023-05-07 14:40:55 --> Helper loaded: url_helper
INFO - 2023-05-07 14:40:55 --> Helper loaded: form_helper
INFO - 2023-05-07 14:40:55 --> Database Driver Class Initialized
INFO - 2023-05-07 14:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:40:55 --> Form Validation Class Initialized
INFO - 2023-05-07 14:40:55 --> Controller Class Initialized
INFO - 2023-05-07 14:40:55 --> Model "m_user" initialized
INFO - 2023-05-07 14:40:55 --> Config Class Initialized
INFO - 2023-05-07 14:40:55 --> Hooks Class Initialized
INFO - 2023-05-07 14:40:55 --> Utf8 Class Initialized
INFO - 2023-05-07 14:40:55 --> URI Class Initialized
INFO - 2023-05-07 14:40:55 --> Router Class Initialized
INFO - 2023-05-07 14:40:55 --> Output Class Initialized
INFO - 2023-05-07 14:40:55 --> Security Class Initialized
INFO - 2023-05-07 14:40:55 --> Input Class Initialized
INFO - 2023-05-07 14:40:55 --> Language Class Initialized
INFO - 2023-05-07 14:40:55 --> Loader Class Initialized
INFO - 2023-05-07 14:40:55 --> Helper loaded: url_helper
INFO - 2023-05-07 14:40:55 --> Helper loaded: form_helper
INFO - 2023-05-07 14:40:55 --> Database Driver Class Initialized
INFO - 2023-05-07 14:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:40:55 --> Form Validation Class Initialized
INFO - 2023-05-07 14:40:55 --> Controller Class Initialized
INFO - 2023-05-07 14:40:55 --> Model "m_user" initialized
INFO - 2023-05-07 14:40:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:40:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:40:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:40:55 --> Final output sent to browser
INFO - 2023-05-07 14:41:01 --> Config Class Initialized
INFO - 2023-05-07 14:41:01 --> Hooks Class Initialized
INFO - 2023-05-07 14:41:01 --> Utf8 Class Initialized
INFO - 2023-05-07 14:41:01 --> URI Class Initialized
INFO - 2023-05-07 14:41:01 --> Router Class Initialized
INFO - 2023-05-07 14:41:01 --> Output Class Initialized
INFO - 2023-05-07 14:41:01 --> Security Class Initialized
INFO - 2023-05-07 14:41:01 --> Input Class Initialized
INFO - 2023-05-07 14:41:01 --> Language Class Initialized
INFO - 2023-05-07 14:41:01 --> Loader Class Initialized
INFO - 2023-05-07 14:41:01 --> Helper loaded: url_helper
INFO - 2023-05-07 14:41:01 --> Helper loaded: form_helper
INFO - 2023-05-07 14:41:01 --> Database Driver Class Initialized
INFO - 2023-05-07 14:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:41:01 --> Form Validation Class Initialized
INFO - 2023-05-07 14:41:01 --> Controller Class Initialized
INFO - 2023-05-07 14:41:01 --> Model "m_user" initialized
INFO - 2023-05-07 14:41:01 --> Config Class Initialized
INFO - 2023-05-07 14:41:01 --> Hooks Class Initialized
INFO - 2023-05-07 14:41:02 --> Utf8 Class Initialized
INFO - 2023-05-07 14:41:02 --> URI Class Initialized
INFO - 2023-05-07 14:41:02 --> Router Class Initialized
INFO - 2023-05-07 14:41:02 --> Output Class Initialized
INFO - 2023-05-07 14:41:02 --> Security Class Initialized
INFO - 2023-05-07 14:41:02 --> Input Class Initialized
INFO - 2023-05-07 14:41:02 --> Language Class Initialized
INFO - 2023-05-07 14:41:02 --> Loader Class Initialized
INFO - 2023-05-07 14:41:02 --> Helper loaded: url_helper
INFO - 2023-05-07 14:41:02 --> Helper loaded: form_helper
INFO - 2023-05-07 14:41:02 --> Database Driver Class Initialized
INFO - 2023-05-07 14:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:41:02 --> Form Validation Class Initialized
INFO - 2023-05-07 14:41:02 --> Controller Class Initialized
INFO - 2023-05-07 14:41:02 --> Model "m_user" initialized
INFO - 2023-05-07 14:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:41:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 14:41:02 --> Final output sent to browser
INFO - 2023-05-07 14:41:20 --> Config Class Initialized
INFO - 2023-05-07 14:41:20 --> Hooks Class Initialized
INFO - 2023-05-07 14:41:20 --> Utf8 Class Initialized
INFO - 2023-05-07 14:41:20 --> URI Class Initialized
INFO - 2023-05-07 14:41:20 --> Router Class Initialized
INFO - 2023-05-07 14:41:20 --> Output Class Initialized
INFO - 2023-05-07 14:41:20 --> Security Class Initialized
INFO - 2023-05-07 14:41:20 --> Input Class Initialized
INFO - 2023-05-07 14:41:20 --> Language Class Initialized
INFO - 2023-05-07 14:41:20 --> Loader Class Initialized
INFO - 2023-05-07 14:41:20 --> Helper loaded: url_helper
INFO - 2023-05-07 14:41:20 --> Helper loaded: form_helper
INFO - 2023-05-07 14:41:20 --> Database Driver Class Initialized
INFO - 2023-05-07 14:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:41:20 --> Form Validation Class Initialized
INFO - 2023-05-07 14:41:20 --> Controller Class Initialized
INFO - 2023-05-07 14:41:20 --> Model "m_user" initialized
INFO - 2023-05-07 14:41:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:41:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:41:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:41:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:41:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:41:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 14:41:20 --> Final output sent to browser
INFO - 2023-05-07 14:41:24 --> Config Class Initialized
INFO - 2023-05-07 14:41:24 --> Hooks Class Initialized
INFO - 2023-05-07 14:41:24 --> Utf8 Class Initialized
INFO - 2023-05-07 14:41:24 --> URI Class Initialized
INFO - 2023-05-07 14:41:24 --> Router Class Initialized
INFO - 2023-05-07 14:41:24 --> Output Class Initialized
INFO - 2023-05-07 14:41:24 --> Security Class Initialized
INFO - 2023-05-07 14:41:24 --> Input Class Initialized
INFO - 2023-05-07 14:41:24 --> Language Class Initialized
INFO - 2023-05-07 14:41:24 --> Loader Class Initialized
INFO - 2023-05-07 14:41:24 --> Helper loaded: url_helper
INFO - 2023-05-07 14:41:24 --> Helper loaded: form_helper
INFO - 2023-05-07 14:41:24 --> Database Driver Class Initialized
INFO - 2023-05-07 14:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:41:24 --> Form Validation Class Initialized
INFO - 2023-05-07 14:41:24 --> Controller Class Initialized
INFO - 2023-05-07 14:41:24 --> Model "m_user" initialized
INFO - 2023-05-07 14:41:24 --> Config Class Initialized
INFO - 2023-05-07 14:41:24 --> Hooks Class Initialized
INFO - 2023-05-07 14:41:24 --> Utf8 Class Initialized
INFO - 2023-05-07 14:41:24 --> URI Class Initialized
INFO - 2023-05-07 14:41:24 --> Router Class Initialized
INFO - 2023-05-07 14:41:24 --> Output Class Initialized
INFO - 2023-05-07 14:41:24 --> Security Class Initialized
INFO - 2023-05-07 14:41:24 --> Input Class Initialized
INFO - 2023-05-07 14:41:24 --> Language Class Initialized
INFO - 2023-05-07 14:41:24 --> Loader Class Initialized
INFO - 2023-05-07 14:41:24 --> Helper loaded: url_helper
INFO - 2023-05-07 14:41:24 --> Helper loaded: form_helper
INFO - 2023-05-07 14:41:24 --> Database Driver Class Initialized
INFO - 2023-05-07 14:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:41:24 --> Form Validation Class Initialized
INFO - 2023-05-07 14:41:24 --> Controller Class Initialized
INFO - 2023-05-07 14:41:24 --> Model "m_user" initialized
INFO - 2023-05-07 14:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:41:24 --> Final output sent to browser
INFO - 2023-05-07 14:43:01 --> Config Class Initialized
INFO - 2023-05-07 14:43:01 --> Hooks Class Initialized
INFO - 2023-05-07 14:43:01 --> Utf8 Class Initialized
INFO - 2023-05-07 14:43:01 --> URI Class Initialized
INFO - 2023-05-07 14:43:01 --> Router Class Initialized
INFO - 2023-05-07 14:43:01 --> Output Class Initialized
INFO - 2023-05-07 14:43:01 --> Security Class Initialized
INFO - 2023-05-07 14:43:01 --> Input Class Initialized
INFO - 2023-05-07 14:43:01 --> Language Class Initialized
INFO - 2023-05-07 14:43:01 --> Loader Class Initialized
INFO - 2023-05-07 14:43:01 --> Helper loaded: url_helper
INFO - 2023-05-07 14:43:01 --> Helper loaded: form_helper
INFO - 2023-05-07 14:43:01 --> Database Driver Class Initialized
INFO - 2023-05-07 14:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:43:01 --> Form Validation Class Initialized
INFO - 2023-05-07 14:43:01 --> Controller Class Initialized
INFO - 2023-05-07 14:43:01 --> Model "m_user" initialized
INFO - 2023-05-07 14:43:01 --> Config Class Initialized
INFO - 2023-05-07 14:43:01 --> Hooks Class Initialized
INFO - 2023-05-07 14:43:01 --> Utf8 Class Initialized
INFO - 2023-05-07 14:43:01 --> URI Class Initialized
INFO - 2023-05-07 14:43:01 --> Router Class Initialized
INFO - 2023-05-07 14:43:01 --> Output Class Initialized
INFO - 2023-05-07 14:43:01 --> Security Class Initialized
INFO - 2023-05-07 14:43:01 --> Input Class Initialized
INFO - 2023-05-07 14:43:01 --> Language Class Initialized
INFO - 2023-05-07 14:43:01 --> Loader Class Initialized
INFO - 2023-05-07 14:43:01 --> Helper loaded: url_helper
INFO - 2023-05-07 14:43:01 --> Helper loaded: form_helper
INFO - 2023-05-07 14:43:01 --> Database Driver Class Initialized
INFO - 2023-05-07 14:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:43:01 --> Form Validation Class Initialized
INFO - 2023-05-07 14:43:01 --> Controller Class Initialized
INFO - 2023-05-07 14:43:01 --> Model "m_user" initialized
INFO - 2023-05-07 14:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:43:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 14:43:01 --> Final output sent to browser
INFO - 2023-05-07 14:43:04 --> Config Class Initialized
INFO - 2023-05-07 14:43:04 --> Hooks Class Initialized
INFO - 2023-05-07 14:43:04 --> Utf8 Class Initialized
INFO - 2023-05-07 14:43:04 --> URI Class Initialized
INFO - 2023-05-07 14:43:04 --> Router Class Initialized
INFO - 2023-05-07 14:43:04 --> Output Class Initialized
INFO - 2023-05-07 14:43:04 --> Security Class Initialized
INFO - 2023-05-07 14:43:04 --> Input Class Initialized
INFO - 2023-05-07 14:43:04 --> Language Class Initialized
INFO - 2023-05-07 14:43:04 --> Loader Class Initialized
INFO - 2023-05-07 14:43:04 --> Helper loaded: url_helper
INFO - 2023-05-07 14:43:04 --> Helper loaded: form_helper
INFO - 2023-05-07 14:43:04 --> Database Driver Class Initialized
INFO - 2023-05-07 14:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:43:04 --> Form Validation Class Initialized
INFO - 2023-05-07 14:43:04 --> Controller Class Initialized
INFO - 2023-05-07 14:43:04 --> Model "m_user" initialized
INFO - 2023-05-07 14:43:04 --> Config Class Initialized
INFO - 2023-05-07 14:43:04 --> Hooks Class Initialized
INFO - 2023-05-07 14:43:04 --> Utf8 Class Initialized
INFO - 2023-05-07 14:43:04 --> URI Class Initialized
INFO - 2023-05-07 14:43:04 --> Router Class Initialized
INFO - 2023-05-07 14:43:04 --> Output Class Initialized
INFO - 2023-05-07 14:43:04 --> Security Class Initialized
INFO - 2023-05-07 14:43:04 --> Input Class Initialized
INFO - 2023-05-07 14:43:04 --> Language Class Initialized
INFO - 2023-05-07 14:43:04 --> Loader Class Initialized
INFO - 2023-05-07 14:43:04 --> Helper loaded: url_helper
INFO - 2023-05-07 14:43:04 --> Helper loaded: form_helper
INFO - 2023-05-07 14:43:04 --> Database Driver Class Initialized
INFO - 2023-05-07 14:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:43:04 --> Form Validation Class Initialized
INFO - 2023-05-07 14:43:04 --> Controller Class Initialized
INFO - 2023-05-07 14:43:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:43:04 --> Final output sent to browser
INFO - 2023-05-07 14:43:33 --> Config Class Initialized
INFO - 2023-05-07 14:43:33 --> Hooks Class Initialized
INFO - 2023-05-07 14:43:33 --> Utf8 Class Initialized
INFO - 2023-05-07 14:43:33 --> URI Class Initialized
INFO - 2023-05-07 14:43:33 --> Router Class Initialized
INFO - 2023-05-07 14:43:33 --> Output Class Initialized
INFO - 2023-05-07 14:43:33 --> Security Class Initialized
INFO - 2023-05-07 14:43:33 --> Input Class Initialized
INFO - 2023-05-07 14:43:33 --> Language Class Initialized
INFO - 2023-05-07 14:43:33 --> Loader Class Initialized
INFO - 2023-05-07 14:43:33 --> Helper loaded: url_helper
INFO - 2023-05-07 14:43:33 --> Helper loaded: form_helper
INFO - 2023-05-07 14:43:33 --> Database Driver Class Initialized
INFO - 2023-05-07 14:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:43:33 --> Form Validation Class Initialized
INFO - 2023-05-07 14:43:33 --> Controller Class Initialized
INFO - 2023-05-07 14:43:33 --> Model "m_user" initialized
INFO - 2023-05-07 14:43:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:43:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:43:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:43:33 --> Final output sent to browser
INFO - 2023-05-07 14:43:37 --> Config Class Initialized
INFO - 2023-05-07 14:43:37 --> Hooks Class Initialized
INFO - 2023-05-07 14:43:37 --> Utf8 Class Initialized
INFO - 2023-05-07 14:43:37 --> URI Class Initialized
INFO - 2023-05-07 14:43:37 --> Router Class Initialized
INFO - 2023-05-07 14:43:37 --> Output Class Initialized
INFO - 2023-05-07 14:43:37 --> Security Class Initialized
INFO - 2023-05-07 14:43:37 --> Input Class Initialized
INFO - 2023-05-07 14:43:37 --> Language Class Initialized
INFO - 2023-05-07 14:43:37 --> Loader Class Initialized
INFO - 2023-05-07 14:43:37 --> Helper loaded: url_helper
INFO - 2023-05-07 14:43:37 --> Helper loaded: form_helper
INFO - 2023-05-07 14:43:37 --> Database Driver Class Initialized
INFO - 2023-05-07 14:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:43:37 --> Form Validation Class Initialized
INFO - 2023-05-07 14:43:37 --> Controller Class Initialized
INFO - 2023-05-07 14:43:37 --> Model "m_user" initialized
INFO - 2023-05-07 14:43:37 --> Config Class Initialized
INFO - 2023-05-07 14:43:37 --> Hooks Class Initialized
INFO - 2023-05-07 14:43:37 --> Utf8 Class Initialized
INFO - 2023-05-07 14:43:37 --> URI Class Initialized
INFO - 2023-05-07 14:43:37 --> Router Class Initialized
INFO - 2023-05-07 14:43:37 --> Output Class Initialized
INFO - 2023-05-07 14:43:37 --> Security Class Initialized
INFO - 2023-05-07 14:43:37 --> Input Class Initialized
INFO - 2023-05-07 14:43:37 --> Language Class Initialized
INFO - 2023-05-07 14:43:37 --> Loader Class Initialized
INFO - 2023-05-07 14:43:37 --> Helper loaded: url_helper
INFO - 2023-05-07 14:43:37 --> Helper loaded: form_helper
INFO - 2023-05-07 14:43:37 --> Database Driver Class Initialized
INFO - 2023-05-07 14:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:43:37 --> Form Validation Class Initialized
INFO - 2023-05-07 14:43:37 --> Controller Class Initialized
INFO - 2023-05-07 14:43:37 --> Model "m_user" initialized
INFO - 2023-05-07 14:43:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:43:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:43:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 14:43:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:43:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:43:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 14:43:37 --> Final output sent to browser
INFO - 2023-05-07 14:54:01 --> Config Class Initialized
INFO - 2023-05-07 14:54:01 --> Hooks Class Initialized
INFO - 2023-05-07 14:54:01 --> Utf8 Class Initialized
INFO - 2023-05-07 14:54:01 --> URI Class Initialized
INFO - 2023-05-07 14:54:01 --> Router Class Initialized
INFO - 2023-05-07 14:54:01 --> Output Class Initialized
INFO - 2023-05-07 14:54:01 --> Security Class Initialized
INFO - 2023-05-07 14:54:01 --> Input Class Initialized
INFO - 2023-05-07 14:54:01 --> Language Class Initialized
INFO - 2023-05-07 14:54:01 --> Loader Class Initialized
INFO - 2023-05-07 14:54:01 --> Helper loaded: url_helper
INFO - 2023-05-07 14:54:01 --> Helper loaded: form_helper
INFO - 2023-05-07 14:54:01 --> Database Driver Class Initialized
INFO - 2023-05-07 14:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:54:01 --> Form Validation Class Initialized
INFO - 2023-05-07 14:54:01 --> Controller Class Initialized
INFO - 2023-05-07 14:54:01 --> Model "m_user" initialized
INFO - 2023-05-07 14:54:01 --> Config Class Initialized
INFO - 2023-05-07 14:54:01 --> Hooks Class Initialized
INFO - 2023-05-07 14:54:01 --> Utf8 Class Initialized
INFO - 2023-05-07 14:54:01 --> URI Class Initialized
INFO - 2023-05-07 14:54:01 --> Router Class Initialized
INFO - 2023-05-07 14:54:01 --> Output Class Initialized
INFO - 2023-05-07 14:54:01 --> Security Class Initialized
INFO - 2023-05-07 14:54:01 --> Input Class Initialized
INFO - 2023-05-07 14:54:01 --> Language Class Initialized
INFO - 2023-05-07 14:54:01 --> Loader Class Initialized
INFO - 2023-05-07 14:54:01 --> Helper loaded: url_helper
INFO - 2023-05-07 14:54:01 --> Helper loaded: form_helper
INFO - 2023-05-07 14:54:01 --> Database Driver Class Initialized
INFO - 2023-05-07 14:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:54:01 --> Form Validation Class Initialized
INFO - 2023-05-07 14:54:01 --> Controller Class Initialized
INFO - 2023-05-07 14:54:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:54:01 --> Final output sent to browser
INFO - 2023-05-07 14:54:03 --> Config Class Initialized
INFO - 2023-05-07 14:54:03 --> Hooks Class Initialized
INFO - 2023-05-07 14:54:03 --> Utf8 Class Initialized
INFO - 2023-05-07 14:54:03 --> URI Class Initialized
INFO - 2023-05-07 14:54:03 --> Router Class Initialized
INFO - 2023-05-07 14:54:03 --> Output Class Initialized
INFO - 2023-05-07 14:54:03 --> Security Class Initialized
INFO - 2023-05-07 14:54:03 --> Input Class Initialized
INFO - 2023-05-07 14:54:03 --> Language Class Initialized
INFO - 2023-05-07 14:54:03 --> Loader Class Initialized
INFO - 2023-05-07 14:54:03 --> Helper loaded: url_helper
INFO - 2023-05-07 14:54:03 --> Helper loaded: form_helper
INFO - 2023-05-07 14:54:03 --> Database Driver Class Initialized
INFO - 2023-05-07 14:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:54:03 --> Form Validation Class Initialized
INFO - 2023-05-07 14:54:03 --> Controller Class Initialized
INFO - 2023-05-07 14:54:03 --> Model "m_user" initialized
INFO - 2023-05-07 14:54:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:54:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:54:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-07 14:54:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:54:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:54:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home_user.php
INFO - 2023-05-07 14:54:03 --> Final output sent to browser
INFO - 2023-05-07 14:54:15 --> Config Class Initialized
INFO - 2023-05-07 14:54:15 --> Hooks Class Initialized
INFO - 2023-05-07 14:54:15 --> Utf8 Class Initialized
INFO - 2023-05-07 14:54:15 --> URI Class Initialized
INFO - 2023-05-07 14:54:15 --> Router Class Initialized
INFO - 2023-05-07 14:54:15 --> Output Class Initialized
INFO - 2023-05-07 14:54:15 --> Security Class Initialized
INFO - 2023-05-07 14:54:15 --> Input Class Initialized
INFO - 2023-05-07 14:54:15 --> Language Class Initialized
INFO - 2023-05-07 14:54:15 --> Loader Class Initialized
INFO - 2023-05-07 14:54:15 --> Helper loaded: url_helper
INFO - 2023-05-07 14:54:15 --> Helper loaded: form_helper
INFO - 2023-05-07 14:54:16 --> Database Driver Class Initialized
INFO - 2023-05-07 14:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:54:16 --> Form Validation Class Initialized
INFO - 2023-05-07 14:54:16 --> Controller Class Initialized
INFO - 2023-05-07 14:54:16 --> Model "m_user" initialized
INFO - 2023-05-07 14:54:16 --> Config Class Initialized
INFO - 2023-05-07 14:54:16 --> Hooks Class Initialized
INFO - 2023-05-07 14:54:16 --> Utf8 Class Initialized
INFO - 2023-05-07 14:54:16 --> URI Class Initialized
INFO - 2023-05-07 14:54:16 --> Router Class Initialized
INFO - 2023-05-07 14:54:16 --> Output Class Initialized
INFO - 2023-05-07 14:54:16 --> Security Class Initialized
INFO - 2023-05-07 14:54:16 --> Input Class Initialized
INFO - 2023-05-07 14:54:16 --> Language Class Initialized
INFO - 2023-05-07 14:54:16 --> Loader Class Initialized
INFO - 2023-05-07 14:54:16 --> Helper loaded: url_helper
INFO - 2023-05-07 14:54:16 --> Helper loaded: form_helper
INFO - 2023-05-07 14:54:16 --> Database Driver Class Initialized
INFO - 2023-05-07 14:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:54:16 --> Form Validation Class Initialized
INFO - 2023-05-07 14:54:16 --> Controller Class Initialized
INFO - 2023-05-07 14:54:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:54:16 --> Final output sent to browser
INFO - 2023-05-07 14:59:27 --> Config Class Initialized
INFO - 2023-05-07 14:59:27 --> Hooks Class Initialized
INFO - 2023-05-07 14:59:27 --> Utf8 Class Initialized
INFO - 2023-05-07 14:59:27 --> URI Class Initialized
INFO - 2023-05-07 14:59:27 --> Router Class Initialized
INFO - 2023-05-07 14:59:27 --> Output Class Initialized
INFO - 2023-05-07 14:59:27 --> Security Class Initialized
INFO - 2023-05-07 14:59:27 --> Input Class Initialized
INFO - 2023-05-07 14:59:27 --> Language Class Initialized
INFO - 2023-05-07 14:59:27 --> Loader Class Initialized
INFO - 2023-05-07 14:59:27 --> Helper loaded: url_helper
INFO - 2023-05-07 14:59:27 --> Helper loaded: form_helper
INFO - 2023-05-07 14:59:27 --> Database Driver Class Initialized
INFO - 2023-05-07 14:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:59:27 --> Form Validation Class Initialized
INFO - 2023-05-07 14:59:27 --> Controller Class Initialized
INFO - 2023-05-07 14:59:27 --> Model "m_user" initialized
INFO - 2023-05-07 14:59:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:59:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:59:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-07 14:59:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:59:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:59:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home_user.php
INFO - 2023-05-07 14:59:27 --> Final output sent to browser
INFO - 2023-05-07 14:59:30 --> Config Class Initialized
INFO - 2023-05-07 14:59:30 --> Hooks Class Initialized
INFO - 2023-05-07 14:59:30 --> Utf8 Class Initialized
INFO - 2023-05-07 14:59:30 --> URI Class Initialized
INFO - 2023-05-07 14:59:30 --> Router Class Initialized
INFO - 2023-05-07 14:59:30 --> Output Class Initialized
INFO - 2023-05-07 14:59:30 --> Security Class Initialized
INFO - 2023-05-07 14:59:30 --> Input Class Initialized
INFO - 2023-05-07 14:59:30 --> Language Class Initialized
INFO - 2023-05-07 14:59:30 --> Loader Class Initialized
INFO - 2023-05-07 14:59:30 --> Helper loaded: url_helper
INFO - 2023-05-07 14:59:30 --> Helper loaded: form_helper
INFO - 2023-05-07 14:59:30 --> Database Driver Class Initialized
INFO - 2023-05-07 14:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:59:30 --> Form Validation Class Initialized
INFO - 2023-05-07 14:59:30 --> Controller Class Initialized
INFO - 2023-05-07 14:59:30 --> Config Class Initialized
INFO - 2023-05-07 14:59:30 --> Hooks Class Initialized
INFO - 2023-05-07 14:59:30 --> Utf8 Class Initialized
INFO - 2023-05-07 14:59:30 --> URI Class Initialized
INFO - 2023-05-07 14:59:30 --> Router Class Initialized
INFO - 2023-05-07 14:59:30 --> Output Class Initialized
INFO - 2023-05-07 14:59:30 --> Security Class Initialized
INFO - 2023-05-07 14:59:30 --> Input Class Initialized
INFO - 2023-05-07 14:59:30 --> Language Class Initialized
INFO - 2023-05-07 14:59:30 --> Loader Class Initialized
INFO - 2023-05-07 14:59:30 --> Helper loaded: url_helper
INFO - 2023-05-07 14:59:30 --> Helper loaded: form_helper
INFO - 2023-05-07 14:59:30 --> Database Driver Class Initialized
INFO - 2023-05-07 14:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:59:30 --> Form Validation Class Initialized
INFO - 2023-05-07 14:59:30 --> Controller Class Initialized
INFO - 2023-05-07 14:59:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:59:30 --> Final output sent to browser
INFO - 2023-05-07 14:59:31 --> Config Class Initialized
INFO - 2023-05-07 14:59:31 --> Hooks Class Initialized
INFO - 2023-05-07 14:59:31 --> Utf8 Class Initialized
INFO - 2023-05-07 14:59:31 --> URI Class Initialized
INFO - 2023-05-07 14:59:31 --> Router Class Initialized
INFO - 2023-05-07 14:59:31 --> Output Class Initialized
INFO - 2023-05-07 14:59:31 --> Security Class Initialized
INFO - 2023-05-07 14:59:31 --> Input Class Initialized
INFO - 2023-05-07 14:59:31 --> Language Class Initialized
INFO - 2023-05-07 14:59:31 --> Loader Class Initialized
INFO - 2023-05-07 14:59:31 --> Helper loaded: url_helper
INFO - 2023-05-07 14:59:31 --> Helper loaded: form_helper
INFO - 2023-05-07 14:59:31 --> Database Driver Class Initialized
INFO - 2023-05-07 14:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:59:31 --> Form Validation Class Initialized
INFO - 2023-05-07 14:59:31 --> Controller Class Initialized
INFO - 2023-05-07 14:59:31 --> Model "m_user" initialized
INFO - 2023-05-07 14:59:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 14:59:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 14:59:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 14:59:31 --> Final output sent to browser
INFO - 2023-05-07 14:59:43 --> Config Class Initialized
INFO - 2023-05-07 14:59:43 --> Hooks Class Initialized
INFO - 2023-05-07 14:59:43 --> Utf8 Class Initialized
INFO - 2023-05-07 14:59:43 --> URI Class Initialized
INFO - 2023-05-07 14:59:43 --> Router Class Initialized
INFO - 2023-05-07 14:59:43 --> Output Class Initialized
INFO - 2023-05-07 14:59:43 --> Security Class Initialized
INFO - 2023-05-07 14:59:43 --> Input Class Initialized
INFO - 2023-05-07 14:59:43 --> Language Class Initialized
INFO - 2023-05-07 14:59:43 --> Loader Class Initialized
INFO - 2023-05-07 14:59:43 --> Helper loaded: url_helper
INFO - 2023-05-07 14:59:43 --> Helper loaded: form_helper
INFO - 2023-05-07 14:59:43 --> Database Driver Class Initialized
INFO - 2023-05-07 14:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:59:43 --> Form Validation Class Initialized
INFO - 2023-05-07 14:59:43 --> Controller Class Initialized
INFO - 2023-05-07 14:59:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 14:59:43 --> Final output sent to browser
INFO - 2023-05-07 14:59:52 --> Config Class Initialized
INFO - 2023-05-07 14:59:52 --> Hooks Class Initialized
INFO - 2023-05-07 14:59:52 --> Utf8 Class Initialized
INFO - 2023-05-07 14:59:52 --> URI Class Initialized
INFO - 2023-05-07 14:59:52 --> Router Class Initialized
INFO - 2023-05-07 14:59:52 --> Output Class Initialized
INFO - 2023-05-07 14:59:52 --> Security Class Initialized
INFO - 2023-05-07 14:59:52 --> Input Class Initialized
INFO - 2023-05-07 14:59:52 --> Language Class Initialized
INFO - 2023-05-07 14:59:52 --> Loader Class Initialized
INFO - 2023-05-07 14:59:52 --> Helper loaded: url_helper
INFO - 2023-05-07 14:59:52 --> Helper loaded: form_helper
INFO - 2023-05-07 14:59:52 --> Database Driver Class Initialized
INFO - 2023-05-07 14:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 14:59:52 --> Form Validation Class Initialized
INFO - 2023-05-07 14:59:52 --> Controller Class Initialized
INFO - 2023-05-07 14:59:52 --> Model "m_user" initialized
INFO - 2023-05-07 14:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 14:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 14:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-07 14:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 14:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 14:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home_user.php
INFO - 2023-05-07 14:59:52 --> Final output sent to browser
INFO - 2023-05-07 15:06:28 --> Config Class Initialized
INFO - 2023-05-07 15:06:28 --> Hooks Class Initialized
INFO - 2023-05-07 15:06:28 --> Utf8 Class Initialized
INFO - 2023-05-07 15:06:28 --> URI Class Initialized
INFO - 2023-05-07 15:06:28 --> Router Class Initialized
INFO - 2023-05-07 15:06:28 --> Output Class Initialized
INFO - 2023-05-07 15:06:28 --> Security Class Initialized
INFO - 2023-05-07 15:06:28 --> Input Class Initialized
INFO - 2023-05-07 15:06:28 --> Language Class Initialized
INFO - 2023-05-07 15:06:28 --> Loader Class Initialized
INFO - 2023-05-07 15:06:28 --> Helper loaded: url_helper
INFO - 2023-05-07 15:06:28 --> Helper loaded: form_helper
INFO - 2023-05-07 15:06:28 --> Database Driver Class Initialized
INFO - 2023-05-07 15:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 15:06:28 --> Form Validation Class Initialized
INFO - 2023-05-07 15:06:28 --> Controller Class Initialized
INFO - 2023-05-07 15:06:28 --> Model "m_user" initialized
INFO - 2023-05-07 15:06:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 15:06:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 15:06:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-07 15:06:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 15:06:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 15:06:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home_user.php
INFO - 2023-05-07 15:06:28 --> Final output sent to browser
INFO - 2023-05-07 15:07:15 --> Config Class Initialized
INFO - 2023-05-07 15:07:15 --> Hooks Class Initialized
INFO - 2023-05-07 15:07:15 --> Utf8 Class Initialized
INFO - 2023-05-07 15:07:15 --> URI Class Initialized
INFO - 2023-05-07 15:07:15 --> Router Class Initialized
INFO - 2023-05-07 15:07:15 --> Output Class Initialized
INFO - 2023-05-07 15:07:15 --> Security Class Initialized
INFO - 2023-05-07 15:07:15 --> Input Class Initialized
INFO - 2023-05-07 15:07:15 --> Language Class Initialized
INFO - 2023-05-07 15:07:15 --> Loader Class Initialized
INFO - 2023-05-07 15:07:15 --> Helper loaded: url_helper
INFO - 2023-05-07 15:07:15 --> Helper loaded: form_helper
INFO - 2023-05-07 15:07:15 --> Database Driver Class Initialized
INFO - 2023-05-07 15:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 15:07:15 --> Form Validation Class Initialized
INFO - 2023-05-07 15:07:15 --> Controller Class Initialized
INFO - 2023-05-07 15:07:15 --> Model "m_user" initialized
INFO - 2023-05-07 15:07:15 --> Config Class Initialized
INFO - 2023-05-07 15:07:15 --> Hooks Class Initialized
INFO - 2023-05-07 15:07:15 --> Utf8 Class Initialized
INFO - 2023-05-07 15:07:15 --> URI Class Initialized
INFO - 2023-05-07 15:07:15 --> Router Class Initialized
INFO - 2023-05-07 15:07:15 --> Output Class Initialized
INFO - 2023-05-07 15:07:15 --> Security Class Initialized
INFO - 2023-05-07 15:07:15 --> Input Class Initialized
INFO - 2023-05-07 15:07:15 --> Language Class Initialized
INFO - 2023-05-07 15:07:15 --> Loader Class Initialized
INFO - 2023-05-07 15:07:15 --> Helper loaded: url_helper
INFO - 2023-05-07 15:07:15 --> Helper loaded: form_helper
INFO - 2023-05-07 15:07:15 --> Database Driver Class Initialized
INFO - 2023-05-07 15:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 15:07:15 --> Form Validation Class Initialized
INFO - 2023-05-07 15:07:15 --> Controller Class Initialized
INFO - 2023-05-07 15:07:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 15:07:15 --> Final output sent to browser
INFO - 2023-05-07 15:09:17 --> Config Class Initialized
INFO - 2023-05-07 15:09:17 --> Hooks Class Initialized
INFO - 2023-05-07 15:09:17 --> Utf8 Class Initialized
INFO - 2023-05-07 15:09:17 --> URI Class Initialized
INFO - 2023-05-07 15:09:17 --> Router Class Initialized
INFO - 2023-05-07 15:09:17 --> Output Class Initialized
INFO - 2023-05-07 15:09:17 --> Security Class Initialized
INFO - 2023-05-07 15:09:17 --> Input Class Initialized
INFO - 2023-05-07 15:09:17 --> Language Class Initialized
INFO - 2023-05-07 15:09:17 --> Loader Class Initialized
INFO - 2023-05-07 15:09:17 --> Helper loaded: url_helper
INFO - 2023-05-07 15:09:17 --> Helper loaded: form_helper
INFO - 2023-05-07 15:09:17 --> Database Driver Class Initialized
INFO - 2023-05-07 15:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 15:09:17 --> Form Validation Class Initialized
INFO - 2023-05-07 15:09:17 --> Controller Class Initialized
INFO - 2023-05-07 15:09:17 --> Model "m_user" initialized
INFO - 2023-05-07 15:09:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 15:09:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 15:09:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-07 15:09:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 15:09:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 15:09:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home_user.php
INFO - 2023-05-07 15:09:17 --> Final output sent to browser
INFO - 2023-05-07 15:09:21 --> Config Class Initialized
INFO - 2023-05-07 15:09:21 --> Hooks Class Initialized
INFO - 2023-05-07 15:09:21 --> Utf8 Class Initialized
INFO - 2023-05-07 15:09:21 --> URI Class Initialized
INFO - 2023-05-07 15:09:21 --> Router Class Initialized
INFO - 2023-05-07 15:09:21 --> Output Class Initialized
INFO - 2023-05-07 15:09:21 --> Security Class Initialized
INFO - 2023-05-07 15:09:21 --> Input Class Initialized
INFO - 2023-05-07 15:09:21 --> Language Class Initialized
INFO - 2023-05-07 15:09:21 --> Loader Class Initialized
INFO - 2023-05-07 15:09:21 --> Helper loaded: url_helper
INFO - 2023-05-07 15:09:21 --> Helper loaded: form_helper
INFO - 2023-05-07 15:09:21 --> Database Driver Class Initialized
INFO - 2023-05-07 15:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 15:09:21 --> Form Validation Class Initialized
INFO - 2023-05-07 15:09:21 --> Controller Class Initialized
INFO - 2023-05-07 15:09:21 --> Model "m_user" initialized
INFO - 2023-05-07 15:09:21 --> Config Class Initialized
INFO - 2023-05-07 15:09:21 --> Hooks Class Initialized
INFO - 2023-05-07 15:09:21 --> Utf8 Class Initialized
INFO - 2023-05-07 15:09:21 --> URI Class Initialized
INFO - 2023-05-07 15:09:21 --> Router Class Initialized
INFO - 2023-05-07 15:09:21 --> Output Class Initialized
INFO - 2023-05-07 15:09:21 --> Security Class Initialized
INFO - 2023-05-07 15:09:21 --> Input Class Initialized
INFO - 2023-05-07 15:09:21 --> Language Class Initialized
INFO - 2023-05-07 15:09:21 --> Loader Class Initialized
INFO - 2023-05-07 15:09:21 --> Helper loaded: url_helper
INFO - 2023-05-07 15:09:21 --> Helper loaded: form_helper
INFO - 2023-05-07 15:09:21 --> Database Driver Class Initialized
INFO - 2023-05-07 15:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 15:09:21 --> Form Validation Class Initialized
INFO - 2023-05-07 15:09:21 --> Controller Class Initialized
INFO - 2023-05-07 15:09:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 15:09:21 --> Final output sent to browser
INFO - 2023-05-07 18:58:08 --> Config Class Initialized
INFO - 2023-05-07 18:58:08 --> Hooks Class Initialized
INFO - 2023-05-07 18:58:08 --> Utf8 Class Initialized
INFO - 2023-05-07 18:58:08 --> URI Class Initialized
INFO - 2023-05-07 18:58:08 --> Router Class Initialized
INFO - 2023-05-07 18:58:08 --> Output Class Initialized
INFO - 2023-05-07 18:58:08 --> Security Class Initialized
INFO - 2023-05-07 18:58:08 --> Input Class Initialized
INFO - 2023-05-07 18:58:08 --> Language Class Initialized
INFO - 2023-05-07 18:58:08 --> Loader Class Initialized
INFO - 2023-05-07 18:58:08 --> Helper loaded: url_helper
INFO - 2023-05-07 18:58:08 --> Helper loaded: form_helper
INFO - 2023-05-07 18:58:08 --> Database Driver Class Initialized
INFO - 2023-05-07 18:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:58:08 --> Form Validation Class Initialized
INFO - 2023-05-07 18:58:08 --> Controller Class Initialized
INFO - 2023-05-07 18:58:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-07 18:58:08 --> Final output sent to browser
INFO - 2023-05-07 18:58:12 --> Config Class Initialized
INFO - 2023-05-07 18:58:12 --> Hooks Class Initialized
INFO - 2023-05-07 18:58:12 --> Utf8 Class Initialized
INFO - 2023-05-07 18:58:12 --> URI Class Initialized
INFO - 2023-05-07 18:58:12 --> Router Class Initialized
INFO - 2023-05-07 18:58:12 --> Output Class Initialized
INFO - 2023-05-07 18:58:12 --> Security Class Initialized
INFO - 2023-05-07 18:58:12 --> Input Class Initialized
INFO - 2023-05-07 18:58:12 --> Language Class Initialized
INFO - 2023-05-07 18:58:12 --> Loader Class Initialized
INFO - 2023-05-07 18:58:12 --> Helper loaded: url_helper
INFO - 2023-05-07 18:58:12 --> Helper loaded: form_helper
INFO - 2023-05-07 18:58:12 --> Database Driver Class Initialized
INFO - 2023-05-07 18:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:58:12 --> Form Validation Class Initialized
INFO - 2023-05-07 18:58:12 --> Controller Class Initialized
INFO - 2023-05-07 18:58:12 --> Model "m_user" initialized
INFO - 2023-05-07 18:58:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-07 18:58:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-07 18:58:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-07 18:58:12 --> Final output sent to browser
INFO - 2023-05-07 18:58:16 --> Config Class Initialized
INFO - 2023-05-07 18:58:16 --> Hooks Class Initialized
INFO - 2023-05-07 18:58:16 --> Utf8 Class Initialized
INFO - 2023-05-07 18:58:16 --> URI Class Initialized
INFO - 2023-05-07 18:58:16 --> Router Class Initialized
INFO - 2023-05-07 18:58:16 --> Output Class Initialized
INFO - 2023-05-07 18:58:16 --> Security Class Initialized
INFO - 2023-05-07 18:58:16 --> Input Class Initialized
INFO - 2023-05-07 18:58:16 --> Language Class Initialized
INFO - 2023-05-07 18:58:16 --> Loader Class Initialized
INFO - 2023-05-07 18:58:16 --> Helper loaded: url_helper
INFO - 2023-05-07 18:58:16 --> Helper loaded: form_helper
INFO - 2023-05-07 18:58:16 --> Database Driver Class Initialized
INFO - 2023-05-07 18:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:58:16 --> Form Validation Class Initialized
INFO - 2023-05-07 18:58:16 --> Controller Class Initialized
INFO - 2023-05-07 18:58:16 --> Model "m_user" initialized
INFO - 2023-05-07 18:58:16 --> Config Class Initialized
INFO - 2023-05-07 18:58:16 --> Hooks Class Initialized
INFO - 2023-05-07 18:58:16 --> Utf8 Class Initialized
INFO - 2023-05-07 18:58:16 --> URI Class Initialized
INFO - 2023-05-07 18:58:16 --> Router Class Initialized
INFO - 2023-05-07 18:58:16 --> Output Class Initialized
INFO - 2023-05-07 18:58:16 --> Security Class Initialized
INFO - 2023-05-07 18:58:16 --> Input Class Initialized
INFO - 2023-05-07 18:58:16 --> Language Class Initialized
INFO - 2023-05-07 18:58:16 --> Loader Class Initialized
INFO - 2023-05-07 18:58:16 --> Helper loaded: url_helper
INFO - 2023-05-07 18:58:16 --> Helper loaded: form_helper
INFO - 2023-05-07 18:58:16 --> Database Driver Class Initialized
INFO - 2023-05-07 18:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:58:16 --> Form Validation Class Initialized
INFO - 2023-05-07 18:58:16 --> Controller Class Initialized
INFO - 2023-05-07 18:58:16 --> Model "m_user" initialized
INFO - 2023-05-07 18:58:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 18:58:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 18:58:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 18:58:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 18:58:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 18:58:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 18:58:16 --> Final output sent to browser
INFO - 2023-05-07 18:58:23 --> Config Class Initialized
INFO - 2023-05-07 18:58:23 --> Hooks Class Initialized
INFO - 2023-05-07 18:58:23 --> Utf8 Class Initialized
INFO - 2023-05-07 18:58:23 --> URI Class Initialized
INFO - 2023-05-07 18:58:23 --> Router Class Initialized
INFO - 2023-05-07 18:58:23 --> Output Class Initialized
INFO - 2023-05-07 18:58:23 --> Security Class Initialized
INFO - 2023-05-07 18:58:23 --> Input Class Initialized
INFO - 2023-05-07 18:58:23 --> Language Class Initialized
ERROR - 2023-05-07 18:58:23 --> 404 Page Not Found: Group/index
INFO - 2023-05-07 18:58:24 --> Config Class Initialized
INFO - 2023-05-07 18:58:24 --> Hooks Class Initialized
INFO - 2023-05-07 18:58:24 --> Utf8 Class Initialized
INFO - 2023-05-07 18:58:24 --> URI Class Initialized
INFO - 2023-05-07 18:58:24 --> Router Class Initialized
INFO - 2023-05-07 18:58:24 --> Output Class Initialized
INFO - 2023-05-07 18:58:24 --> Security Class Initialized
INFO - 2023-05-07 18:58:24 --> Input Class Initialized
INFO - 2023-05-07 18:58:24 --> Language Class Initialized
INFO - 2023-05-07 18:58:24 --> Loader Class Initialized
INFO - 2023-05-07 18:58:24 --> Helper loaded: url_helper
INFO - 2023-05-07 18:58:24 --> Helper loaded: form_helper
INFO - 2023-05-07 18:58:24 --> Database Driver Class Initialized
INFO - 2023-05-07 18:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:58:24 --> Form Validation Class Initialized
INFO - 2023-05-07 18:58:24 --> Controller Class Initialized
INFO - 2023-05-07 18:58:24 --> Model "m_user" initialized
INFO - 2023-05-07 18:58:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 18:58:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 18:58:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 18:58:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 18:58:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 18:58:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 18:58:24 --> Final output sent to browser
INFO - 2023-05-07 18:59:30 --> Config Class Initialized
INFO - 2023-05-07 18:59:30 --> Hooks Class Initialized
INFO - 2023-05-07 18:59:30 --> Utf8 Class Initialized
INFO - 2023-05-07 18:59:30 --> URI Class Initialized
INFO - 2023-05-07 18:59:30 --> Router Class Initialized
INFO - 2023-05-07 18:59:30 --> Output Class Initialized
INFO - 2023-05-07 18:59:30 --> Security Class Initialized
INFO - 2023-05-07 18:59:30 --> Input Class Initialized
INFO - 2023-05-07 18:59:30 --> Language Class Initialized
INFO - 2023-05-07 18:59:30 --> Loader Class Initialized
INFO - 2023-05-07 18:59:30 --> Helper loaded: url_helper
INFO - 2023-05-07 18:59:30 --> Helper loaded: form_helper
INFO - 2023-05-07 18:59:30 --> Database Driver Class Initialized
INFO - 2023-05-07 18:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:59:30 --> Form Validation Class Initialized
INFO - 2023-05-07 18:59:30 --> Controller Class Initialized
INFO - 2023-05-07 18:59:30 --> Model "m_user" initialized
INFO - 2023-05-07 18:59:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 18:59:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 18:59:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 18:59:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 18:59:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 18:59:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 18:59:30 --> Final output sent to browser
INFO - 2023-05-07 18:59:33 --> Config Class Initialized
INFO - 2023-05-07 18:59:33 --> Hooks Class Initialized
INFO - 2023-05-07 18:59:33 --> Utf8 Class Initialized
INFO - 2023-05-07 18:59:33 --> URI Class Initialized
INFO - 2023-05-07 18:59:33 --> Router Class Initialized
INFO - 2023-05-07 18:59:33 --> Output Class Initialized
INFO - 2023-05-07 18:59:33 --> Security Class Initialized
INFO - 2023-05-07 18:59:33 --> Input Class Initialized
INFO - 2023-05-07 18:59:33 --> Language Class Initialized
ERROR - 2023-05-07 18:59:33 --> 404 Page Not Found: C_datatrain/index
INFO - 2023-05-07 19:00:48 --> Config Class Initialized
INFO - 2023-05-07 19:00:48 --> Hooks Class Initialized
INFO - 2023-05-07 19:00:48 --> Utf8 Class Initialized
INFO - 2023-05-07 19:00:48 --> URI Class Initialized
INFO - 2023-05-07 19:00:48 --> Router Class Initialized
INFO - 2023-05-07 19:00:48 --> Output Class Initialized
INFO - 2023-05-07 19:00:48 --> Security Class Initialized
INFO - 2023-05-07 19:00:48 --> Input Class Initialized
INFO - 2023-05-07 19:00:48 --> Language Class Initialized
INFO - 2023-05-07 19:00:48 --> Loader Class Initialized
INFO - 2023-05-07 19:00:48 --> Helper loaded: url_helper
INFO - 2023-05-07 19:00:48 --> Helper loaded: form_helper
INFO - 2023-05-07 19:00:48 --> Database Driver Class Initialized
INFO - 2023-05-07 19:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:00:48 --> Form Validation Class Initialized
INFO - 2023-05-07 19:00:48 --> Controller Class Initialized
ERROR - 2023-05-07 19:00:48 --> Severity: error --> Exception: C:\xampp\htdocs\sistemdiagnosa\application\models/M_datatrain.php exists, but doesn't declare class M_datatrain C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 340
INFO - 2023-05-07 19:02:22 --> Config Class Initialized
INFO - 2023-05-07 19:02:22 --> Hooks Class Initialized
INFO - 2023-05-07 19:02:22 --> Utf8 Class Initialized
INFO - 2023-05-07 19:02:22 --> URI Class Initialized
INFO - 2023-05-07 19:02:22 --> Router Class Initialized
INFO - 2023-05-07 19:02:22 --> Output Class Initialized
INFO - 2023-05-07 19:02:22 --> Security Class Initialized
INFO - 2023-05-07 19:02:22 --> Input Class Initialized
INFO - 2023-05-07 19:02:22 --> Language Class Initialized
INFO - 2023-05-07 19:02:22 --> Loader Class Initialized
INFO - 2023-05-07 19:02:22 --> Helper loaded: url_helper
INFO - 2023-05-07 19:02:22 --> Helper loaded: form_helper
INFO - 2023-05-07 19:02:22 --> Database Driver Class Initialized
INFO - 2023-05-07 19:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:02:22 --> Form Validation Class Initialized
INFO - 2023-05-07 19:02:22 --> Controller Class Initialized
ERROR - 2023-05-07 19:02:22 --> Severity: error --> Exception: C:\xampp\htdocs\sistemdiagnosa\application\models/M_datatrain.php exists, but doesn't declare class M_datatrain C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 340
INFO - 2023-05-07 19:02:23 --> Config Class Initialized
INFO - 2023-05-07 19:02:23 --> Hooks Class Initialized
INFO - 2023-05-07 19:02:23 --> Utf8 Class Initialized
INFO - 2023-05-07 19:02:23 --> URI Class Initialized
INFO - 2023-05-07 19:02:23 --> Router Class Initialized
INFO - 2023-05-07 19:02:23 --> Output Class Initialized
INFO - 2023-05-07 19:02:23 --> Security Class Initialized
INFO - 2023-05-07 19:02:23 --> Input Class Initialized
INFO - 2023-05-07 19:02:23 --> Language Class Initialized
INFO - 2023-05-07 19:02:23 --> Loader Class Initialized
INFO - 2023-05-07 19:02:23 --> Helper loaded: url_helper
INFO - 2023-05-07 19:02:23 --> Helper loaded: form_helper
INFO - 2023-05-07 19:02:23 --> Database Driver Class Initialized
INFO - 2023-05-07 19:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:02:23 --> Form Validation Class Initialized
INFO - 2023-05-07 19:02:23 --> Controller Class Initialized
ERROR - 2023-05-07 19:02:23 --> Severity: error --> Exception: C:\xampp\htdocs\sistemdiagnosa\application\models/M_datatrain.php exists, but doesn't declare class M_datatrain C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 340
INFO - 2023-05-07 19:02:25 --> Config Class Initialized
INFO - 2023-05-07 19:02:25 --> Hooks Class Initialized
INFO - 2023-05-07 19:02:25 --> Utf8 Class Initialized
INFO - 2023-05-07 19:02:25 --> URI Class Initialized
INFO - 2023-05-07 19:02:25 --> Router Class Initialized
INFO - 2023-05-07 19:02:25 --> Output Class Initialized
INFO - 2023-05-07 19:02:25 --> Security Class Initialized
INFO - 2023-05-07 19:02:25 --> Input Class Initialized
INFO - 2023-05-07 19:02:25 --> Language Class Initialized
INFO - 2023-05-07 19:02:25 --> Loader Class Initialized
INFO - 2023-05-07 19:02:25 --> Helper loaded: url_helper
INFO - 2023-05-07 19:02:25 --> Helper loaded: form_helper
INFO - 2023-05-07 19:02:25 --> Database Driver Class Initialized
INFO - 2023-05-07 19:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:02:25 --> Form Validation Class Initialized
INFO - 2023-05-07 19:02:25 --> Controller Class Initialized
ERROR - 2023-05-07 19:02:25 --> Severity: error --> Exception: C:\xampp\htdocs\sistemdiagnosa\application\models/M_datatrain.php exists, but doesn't declare class M_datatrain C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 340
INFO - 2023-05-07 19:02:25 --> Config Class Initialized
INFO - 2023-05-07 19:02:25 --> Hooks Class Initialized
INFO - 2023-05-07 19:02:25 --> Utf8 Class Initialized
INFO - 2023-05-07 19:02:25 --> URI Class Initialized
INFO - 2023-05-07 19:02:25 --> Router Class Initialized
INFO - 2023-05-07 19:02:25 --> Output Class Initialized
INFO - 2023-05-07 19:02:25 --> Security Class Initialized
INFO - 2023-05-07 19:02:25 --> Input Class Initialized
INFO - 2023-05-07 19:02:25 --> Language Class Initialized
INFO - 2023-05-07 19:02:26 --> Loader Class Initialized
INFO - 2023-05-07 19:02:26 --> Helper loaded: url_helper
INFO - 2023-05-07 19:02:26 --> Helper loaded: form_helper
INFO - 2023-05-07 19:02:26 --> Database Driver Class Initialized
INFO - 2023-05-07 19:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:02:26 --> Form Validation Class Initialized
INFO - 2023-05-07 19:02:26 --> Controller Class Initialized
ERROR - 2023-05-07 19:02:26 --> Severity: error --> Exception: C:\xampp\htdocs\sistemdiagnosa\application\models/M_datatrain.php exists, but doesn't declare class M_datatrain C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 340
INFO - 2023-05-07 19:02:26 --> Config Class Initialized
INFO - 2023-05-07 19:02:26 --> Hooks Class Initialized
INFO - 2023-05-07 19:02:26 --> Utf8 Class Initialized
INFO - 2023-05-07 19:02:26 --> URI Class Initialized
INFO - 2023-05-07 19:02:26 --> Router Class Initialized
INFO - 2023-05-07 19:02:26 --> Output Class Initialized
INFO - 2023-05-07 19:02:26 --> Security Class Initialized
INFO - 2023-05-07 19:02:26 --> Input Class Initialized
INFO - 2023-05-07 19:02:26 --> Language Class Initialized
INFO - 2023-05-07 19:02:26 --> Loader Class Initialized
INFO - 2023-05-07 19:02:26 --> Helper loaded: url_helper
INFO - 2023-05-07 19:02:26 --> Helper loaded: form_helper
INFO - 2023-05-07 19:02:26 --> Database Driver Class Initialized
INFO - 2023-05-07 19:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:02:26 --> Form Validation Class Initialized
INFO - 2023-05-07 19:02:26 --> Controller Class Initialized
ERROR - 2023-05-07 19:02:26 --> Severity: error --> Exception: C:\xampp\htdocs\sistemdiagnosa\application\models/M_datatrain.php exists, but doesn't declare class M_datatrain C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 340
INFO - 2023-05-07 19:02:26 --> Config Class Initialized
INFO - 2023-05-07 19:02:26 --> Hooks Class Initialized
INFO - 2023-05-07 19:02:26 --> Utf8 Class Initialized
INFO - 2023-05-07 19:02:26 --> URI Class Initialized
INFO - 2023-05-07 19:02:26 --> Router Class Initialized
INFO - 2023-05-07 19:02:26 --> Output Class Initialized
INFO - 2023-05-07 19:02:26 --> Security Class Initialized
INFO - 2023-05-07 19:02:26 --> Input Class Initialized
INFO - 2023-05-07 19:02:26 --> Language Class Initialized
INFO - 2023-05-07 19:02:26 --> Loader Class Initialized
INFO - 2023-05-07 19:02:26 --> Helper loaded: url_helper
INFO - 2023-05-07 19:02:26 --> Helper loaded: form_helper
INFO - 2023-05-07 19:02:26 --> Database Driver Class Initialized
INFO - 2023-05-07 19:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:02:26 --> Form Validation Class Initialized
INFO - 2023-05-07 19:02:26 --> Controller Class Initialized
ERROR - 2023-05-07 19:02:26 --> Severity: error --> Exception: C:\xampp\htdocs\sistemdiagnosa\application\models/M_datatrain.php exists, but doesn't declare class M_datatrain C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 340
INFO - 2023-05-07 19:02:26 --> Config Class Initialized
INFO - 2023-05-07 19:02:26 --> Hooks Class Initialized
INFO - 2023-05-07 19:02:26 --> Utf8 Class Initialized
INFO - 2023-05-07 19:02:26 --> URI Class Initialized
INFO - 2023-05-07 19:02:26 --> Router Class Initialized
INFO - 2023-05-07 19:02:26 --> Output Class Initialized
INFO - 2023-05-07 19:02:26 --> Security Class Initialized
INFO - 2023-05-07 19:02:26 --> Input Class Initialized
INFO - 2023-05-07 19:02:26 --> Language Class Initialized
INFO - 2023-05-07 19:02:26 --> Loader Class Initialized
INFO - 2023-05-07 19:02:26 --> Helper loaded: url_helper
INFO - 2023-05-07 19:02:26 --> Helper loaded: form_helper
INFO - 2023-05-07 19:02:26 --> Database Driver Class Initialized
INFO - 2023-05-07 19:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:02:26 --> Form Validation Class Initialized
INFO - 2023-05-07 19:02:26 --> Controller Class Initialized
ERROR - 2023-05-07 19:02:26 --> Severity: error --> Exception: C:\xampp\htdocs\sistemdiagnosa\application\models/M_datatrain.php exists, but doesn't declare class M_datatrain C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 340
INFO - 2023-05-07 19:03:20 --> Config Class Initialized
INFO - 2023-05-07 19:03:20 --> Hooks Class Initialized
INFO - 2023-05-07 19:03:20 --> Utf8 Class Initialized
INFO - 2023-05-07 19:03:20 --> URI Class Initialized
INFO - 2023-05-07 19:03:20 --> Router Class Initialized
INFO - 2023-05-07 19:03:20 --> Output Class Initialized
INFO - 2023-05-07 19:03:20 --> Security Class Initialized
INFO - 2023-05-07 19:03:20 --> Input Class Initialized
INFO - 2023-05-07 19:03:20 --> Language Class Initialized
INFO - 2023-05-07 19:03:20 --> Loader Class Initialized
INFO - 2023-05-07 19:03:20 --> Helper loaded: url_helper
INFO - 2023-05-07 19:03:20 --> Helper loaded: form_helper
INFO - 2023-05-07 19:03:20 --> Database Driver Class Initialized
INFO - 2023-05-07 19:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:03:20 --> Form Validation Class Initialized
INFO - 2023-05-07 19:03:20 --> Controller Class Initialized
INFO - 2023-05-07 19:03:20 --> Model "m_user" initialized
INFO - 2023-05-07 19:03:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 19:03:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 19:03:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 19:03:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 19:03:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 19:03:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\v_home.php
INFO - 2023-05-07 19:03:20 --> Final output sent to browser
INFO - 2023-05-07 19:03:22 --> Config Class Initialized
INFO - 2023-05-07 19:03:22 --> Hooks Class Initialized
INFO - 2023-05-07 19:03:22 --> Utf8 Class Initialized
INFO - 2023-05-07 19:03:22 --> URI Class Initialized
INFO - 2023-05-07 19:03:22 --> Router Class Initialized
INFO - 2023-05-07 19:03:23 --> Output Class Initialized
INFO - 2023-05-07 19:03:23 --> Security Class Initialized
INFO - 2023-05-07 19:03:23 --> Input Class Initialized
INFO - 2023-05-07 19:03:23 --> Language Class Initialized
INFO - 2023-05-07 19:03:23 --> Loader Class Initialized
INFO - 2023-05-07 19:03:23 --> Helper loaded: url_helper
INFO - 2023-05-07 19:03:23 --> Helper loaded: form_helper
INFO - 2023-05-07 19:03:23 --> Database Driver Class Initialized
INFO - 2023-05-07 19:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:03:23 --> Form Validation Class Initialized
INFO - 2023-05-07 19:03:23 --> Controller Class Initialized
ERROR - 2023-05-07 19:03:23 --> Severity: error --> Exception: C:\xampp\htdocs\sistemdiagnosa\application\models/M_datatrain.php exists, but doesn't declare class M_datatrain C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 340
INFO - 2023-05-07 19:03:50 --> Config Class Initialized
INFO - 2023-05-07 19:03:50 --> Hooks Class Initialized
INFO - 2023-05-07 19:03:50 --> Utf8 Class Initialized
INFO - 2023-05-07 19:03:50 --> URI Class Initialized
INFO - 2023-05-07 19:03:50 --> Router Class Initialized
INFO - 2023-05-07 19:03:50 --> Output Class Initialized
INFO - 2023-05-07 19:03:50 --> Security Class Initialized
INFO - 2023-05-07 19:03:50 --> Input Class Initialized
INFO - 2023-05-07 19:03:50 --> Language Class Initialized
INFO - 2023-05-07 19:03:50 --> Loader Class Initialized
INFO - 2023-05-07 19:03:50 --> Helper loaded: url_helper
INFO - 2023-05-07 19:03:50 --> Helper loaded: form_helper
INFO - 2023-05-07 19:03:50 --> Database Driver Class Initialized
INFO - 2023-05-07 19:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:03:50 --> Form Validation Class Initialized
INFO - 2023-05-07 19:03:50 --> Controller Class Initialized
INFO - 2023-05-07 19:03:50 --> Model "m_datatrain" initialized
INFO - 2023-05-07 19:03:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 19:03:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 19:03:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-07 19:03:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 19:03:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 19:03:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 19:03:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-07 19:03:50 --> Final output sent to browser
INFO - 2023-05-07 19:04:19 --> Config Class Initialized
INFO - 2023-05-07 19:04:19 --> Hooks Class Initialized
INFO - 2023-05-07 19:04:19 --> Utf8 Class Initialized
INFO - 2023-05-07 19:04:19 --> URI Class Initialized
INFO - 2023-05-07 19:04:19 --> Router Class Initialized
INFO - 2023-05-07 19:04:19 --> Output Class Initialized
INFO - 2023-05-07 19:04:19 --> Security Class Initialized
INFO - 2023-05-07 19:04:19 --> Input Class Initialized
INFO - 2023-05-07 19:04:19 --> Language Class Initialized
INFO - 2023-05-07 19:04:19 --> Loader Class Initialized
INFO - 2023-05-07 19:04:19 --> Helper loaded: url_helper
INFO - 2023-05-07 19:04:19 --> Helper loaded: form_helper
INFO - 2023-05-07 19:04:19 --> Database Driver Class Initialized
INFO - 2023-05-07 19:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:04:19 --> Form Validation Class Initialized
INFO - 2023-05-07 19:04:19 --> Controller Class Initialized
INFO - 2023-05-07 19:04:19 --> Model "m_datatrain" initialized
INFO - 2023-05-07 19:04:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 19:04:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 19:04:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-07 19:04:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 19:04:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 19:04:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 19:04:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-07 19:04:19 --> Final output sent to browser
INFO - 2023-05-07 19:04:45 --> Config Class Initialized
INFO - 2023-05-07 19:04:45 --> Hooks Class Initialized
INFO - 2023-05-07 19:04:45 --> Utf8 Class Initialized
INFO - 2023-05-07 19:04:45 --> URI Class Initialized
INFO - 2023-05-07 19:04:45 --> Router Class Initialized
INFO - 2023-05-07 19:04:45 --> Output Class Initialized
INFO - 2023-05-07 19:04:45 --> Security Class Initialized
INFO - 2023-05-07 19:04:45 --> Input Class Initialized
INFO - 2023-05-07 19:04:45 --> Language Class Initialized
INFO - 2023-05-07 19:04:45 --> Loader Class Initialized
INFO - 2023-05-07 19:04:45 --> Helper loaded: url_helper
INFO - 2023-05-07 19:04:45 --> Helper loaded: form_helper
INFO - 2023-05-07 19:04:45 --> Database Driver Class Initialized
INFO - 2023-05-07 19:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 19:04:45 --> Form Validation Class Initialized
INFO - 2023-05-07 19:04:45 --> Controller Class Initialized
INFO - 2023-05-07 19:04:45 --> Model "m_datatrain" initialized
INFO - 2023-05-07 19:04:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-07 19:04:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-07 19:04:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-07 19:04:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-07 19:04:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-07 19:04:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-07 19:04:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-07 19:04:45 --> Final output sent to browser
