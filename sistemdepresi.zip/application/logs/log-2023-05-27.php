<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-27 15:48:55 --> Config Class Initialized
INFO - 2023-05-27 15:48:55 --> Hooks Class Initialized
INFO - 2023-05-27 15:48:55 --> Utf8 Class Initialized
INFO - 2023-05-27 15:48:55 --> URI Class Initialized
INFO - 2023-05-27 15:48:55 --> Router Class Initialized
INFO - 2023-05-27 15:48:55 --> Output Class Initialized
INFO - 2023-05-27 15:48:55 --> Security Class Initialized
INFO - 2023-05-27 15:48:55 --> Input Class Initialized
INFO - 2023-05-27 15:48:55 --> Language Class Initialized
INFO - 2023-05-27 15:48:55 --> Loader Class Initialized
INFO - 2023-05-27 15:48:55 --> Helper loaded: url_helper
INFO - 2023-05-27 15:48:55 --> Helper loaded: form_helper
INFO - 2023-05-27 15:48:55 --> Database Driver Class Initialized
INFO - 2023-05-27 15:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 15:48:55 --> Form Validation Class Initialized
INFO - 2023-05-27 15:48:55 --> Controller Class Initialized
INFO - 2023-05-27 15:48:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-27 15:48:55 --> Final output sent to browser
INFO - 2023-05-27 15:50:48 --> Config Class Initialized
INFO - 2023-05-27 15:50:48 --> Hooks Class Initialized
INFO - 2023-05-27 15:50:48 --> Utf8 Class Initialized
INFO - 2023-05-27 15:50:48 --> URI Class Initialized
INFO - 2023-05-27 15:50:48 --> Router Class Initialized
INFO - 2023-05-27 15:50:48 --> Output Class Initialized
INFO - 2023-05-27 15:50:48 --> Security Class Initialized
INFO - 2023-05-27 15:50:48 --> Input Class Initialized
INFO - 2023-05-27 15:50:48 --> Language Class Initialized
INFO - 2023-05-27 15:50:48 --> Loader Class Initialized
INFO - 2023-05-27 15:50:48 --> Helper loaded: url_helper
INFO - 2023-05-27 15:50:48 --> Helper loaded: form_helper
INFO - 2023-05-27 15:50:48 --> Database Driver Class Initialized
INFO - 2023-05-27 15:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 15:50:48 --> Form Validation Class Initialized
INFO - 2023-05-27 15:50:48 --> Controller Class Initialized
INFO - 2023-05-27 15:50:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-27 15:50:48 --> Final output sent to browser
INFO - 2023-05-27 15:50:50 --> Config Class Initialized
INFO - 2023-05-27 15:50:50 --> Hooks Class Initialized
INFO - 2023-05-27 15:50:50 --> Utf8 Class Initialized
INFO - 2023-05-27 15:50:50 --> URI Class Initialized
INFO - 2023-05-27 15:50:50 --> Router Class Initialized
INFO - 2023-05-27 15:50:50 --> Output Class Initialized
INFO - 2023-05-27 15:50:50 --> Security Class Initialized
INFO - 2023-05-27 15:50:50 --> Input Class Initialized
INFO - 2023-05-27 15:50:50 --> Language Class Initialized
INFO - 2023-05-27 15:50:50 --> Loader Class Initialized
INFO - 2023-05-27 15:50:50 --> Helper loaded: url_helper
INFO - 2023-05-27 15:50:50 --> Helper loaded: form_helper
INFO - 2023-05-27 15:50:50 --> Database Driver Class Initialized
INFO - 2023-05-27 15:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 15:50:50 --> Form Validation Class Initialized
INFO - 2023-05-27 15:50:50 --> Controller Class Initialized
INFO - 2023-05-27 15:50:50 --> Model "m_user" initialized
INFO - 2023-05-27 15:50:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-27 15:50:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-27 15:50:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-27 15:50:50 --> Final output sent to browser
INFO - 2023-05-27 15:54:07 --> Config Class Initialized
INFO - 2023-05-27 15:54:07 --> Hooks Class Initialized
INFO - 2023-05-27 15:54:07 --> Utf8 Class Initialized
INFO - 2023-05-27 15:54:07 --> URI Class Initialized
INFO - 2023-05-27 15:54:07 --> Router Class Initialized
INFO - 2023-05-27 15:54:07 --> Output Class Initialized
INFO - 2023-05-27 15:54:07 --> Security Class Initialized
INFO - 2023-05-27 15:54:07 --> Input Class Initialized
INFO - 2023-05-27 15:54:07 --> Language Class Initialized
INFO - 2023-05-27 15:54:07 --> Loader Class Initialized
INFO - 2023-05-27 15:54:07 --> Helper loaded: url_helper
INFO - 2023-05-27 15:54:07 --> Helper loaded: form_helper
INFO - 2023-05-27 15:54:07 --> Database Driver Class Initialized
INFO - 2023-05-27 15:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 15:54:07 --> Form Validation Class Initialized
INFO - 2023-05-27 15:54:07 --> Controller Class Initialized
INFO - 2023-05-27 15:54:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-27 15:54:07 --> Final output sent to browser
INFO - 2023-05-27 15:54:09 --> Config Class Initialized
INFO - 2023-05-27 15:54:09 --> Hooks Class Initialized
INFO - 2023-05-27 15:54:09 --> Utf8 Class Initialized
INFO - 2023-05-27 15:54:09 --> URI Class Initialized
INFO - 2023-05-27 15:54:09 --> Router Class Initialized
INFO - 2023-05-27 15:54:09 --> Output Class Initialized
INFO - 2023-05-27 15:54:09 --> Security Class Initialized
INFO - 2023-05-27 15:54:09 --> Input Class Initialized
INFO - 2023-05-27 15:54:09 --> Language Class Initialized
INFO - 2023-05-27 15:54:09 --> Loader Class Initialized
INFO - 2023-05-27 15:54:09 --> Helper loaded: url_helper
INFO - 2023-05-27 15:54:09 --> Helper loaded: form_helper
INFO - 2023-05-27 15:54:09 --> Database Driver Class Initialized
INFO - 2023-05-27 15:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 15:54:09 --> Form Validation Class Initialized
INFO - 2023-05-27 15:54:09 --> Controller Class Initialized
INFO - 2023-05-27 15:54:09 --> Model "m_user" initialized
INFO - 2023-05-27 15:54:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-27 15:54:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-27 15:54:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-27 15:54:09 --> Final output sent to browser
INFO - 2023-05-27 16:06:04 --> Config Class Initialized
INFO - 2023-05-27 16:06:04 --> Hooks Class Initialized
INFO - 2023-05-27 16:06:04 --> Utf8 Class Initialized
INFO - 2023-05-27 16:06:04 --> URI Class Initialized
INFO - 2023-05-27 16:06:04 --> Router Class Initialized
INFO - 2023-05-27 16:06:04 --> Output Class Initialized
INFO - 2023-05-27 16:06:04 --> Security Class Initialized
INFO - 2023-05-27 16:06:04 --> Input Class Initialized
INFO - 2023-05-27 16:06:04 --> Language Class Initialized
INFO - 2023-05-27 16:06:04 --> Loader Class Initialized
INFO - 2023-05-27 16:06:04 --> Helper loaded: url_helper
INFO - 2023-05-27 16:06:04 --> Helper loaded: form_helper
INFO - 2023-05-27 16:06:04 --> Database Driver Class Initialized
INFO - 2023-05-27 16:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:06:04 --> Form Validation Class Initialized
INFO - 2023-05-27 16:06:04 --> Controller Class Initialized
INFO - 2023-05-27 16:06:04 --> Model "m_user" initialized
INFO - 2023-05-27 16:06:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-27 16:06:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-27 16:06:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-27 16:06:04 --> Final output sent to browser
INFO - 2023-05-27 16:06:05 --> Config Class Initialized
INFO - 2023-05-27 16:06:05 --> Hooks Class Initialized
INFO - 2023-05-27 16:06:05 --> Utf8 Class Initialized
INFO - 2023-05-27 16:06:05 --> URI Class Initialized
INFO - 2023-05-27 16:06:05 --> Router Class Initialized
INFO - 2023-05-27 16:06:05 --> Output Class Initialized
INFO - 2023-05-27 16:06:05 --> Security Class Initialized
INFO - 2023-05-27 16:06:05 --> Input Class Initialized
INFO - 2023-05-27 16:06:05 --> Language Class Initialized
INFO - 2023-05-27 16:06:05 --> Loader Class Initialized
INFO - 2023-05-27 16:06:05 --> Helper loaded: url_helper
INFO - 2023-05-27 16:06:05 --> Helper loaded: form_helper
INFO - 2023-05-27 16:06:05 --> Database Driver Class Initialized
INFO - 2023-05-27 16:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:06:05 --> Form Validation Class Initialized
INFO - 2023-05-27 16:06:05 --> Controller Class Initialized
INFO - 2023-05-27 16:06:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-27 16:06:05 --> Final output sent to browser
INFO - 2023-05-27 16:06:07 --> Config Class Initialized
INFO - 2023-05-27 16:06:07 --> Hooks Class Initialized
INFO - 2023-05-27 16:06:07 --> Utf8 Class Initialized
INFO - 2023-05-27 16:06:07 --> URI Class Initialized
INFO - 2023-05-27 16:06:07 --> Router Class Initialized
INFO - 2023-05-27 16:06:07 --> Output Class Initialized
INFO - 2023-05-27 16:06:07 --> Security Class Initialized
INFO - 2023-05-27 16:06:07 --> Input Class Initialized
INFO - 2023-05-27 16:06:07 --> Language Class Initialized
INFO - 2023-05-27 16:06:07 --> Loader Class Initialized
INFO - 2023-05-27 16:06:07 --> Helper loaded: url_helper
INFO - 2023-05-27 16:06:07 --> Helper loaded: form_helper
INFO - 2023-05-27 16:06:07 --> Database Driver Class Initialized
INFO - 2023-05-27 16:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:06:07 --> Form Validation Class Initialized
INFO - 2023-05-27 16:06:07 --> Controller Class Initialized
INFO - 2023-05-27 16:06:07 --> Model "m_user" initialized
INFO - 2023-05-27 16:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-27 16:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:06:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-27 16:06:07 --> Final output sent to browser
INFO - 2023-05-27 16:06:11 --> Config Class Initialized
INFO - 2023-05-27 16:06:11 --> Hooks Class Initialized
INFO - 2023-05-27 16:06:11 --> Utf8 Class Initialized
INFO - 2023-05-27 16:06:11 --> URI Class Initialized
INFO - 2023-05-27 16:06:11 --> Router Class Initialized
INFO - 2023-05-27 16:06:11 --> Output Class Initialized
INFO - 2023-05-27 16:06:11 --> Security Class Initialized
INFO - 2023-05-27 16:06:11 --> Input Class Initialized
INFO - 2023-05-27 16:06:11 --> Language Class Initialized
INFO - 2023-05-27 16:06:11 --> Loader Class Initialized
INFO - 2023-05-27 16:06:11 --> Helper loaded: url_helper
INFO - 2023-05-27 16:06:11 --> Helper loaded: form_helper
INFO - 2023-05-27 16:06:11 --> Database Driver Class Initialized
INFO - 2023-05-27 16:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:06:12 --> Form Validation Class Initialized
INFO - 2023-05-27 16:06:12 --> Controller Class Initialized
INFO - 2023-05-27 16:06:12 --> Model "m_user" initialized
INFO - 2023-05-27 16:06:12 --> Config Class Initialized
INFO - 2023-05-27 16:06:12 --> Hooks Class Initialized
INFO - 2023-05-27 16:06:12 --> Utf8 Class Initialized
INFO - 2023-05-27 16:06:12 --> URI Class Initialized
INFO - 2023-05-27 16:06:12 --> Router Class Initialized
INFO - 2023-05-27 16:06:12 --> Output Class Initialized
INFO - 2023-05-27 16:06:12 --> Security Class Initialized
INFO - 2023-05-27 16:06:12 --> Input Class Initialized
INFO - 2023-05-27 16:06:12 --> Language Class Initialized
INFO - 2023-05-27 16:06:12 --> Loader Class Initialized
INFO - 2023-05-27 16:06:12 --> Helper loaded: url_helper
INFO - 2023-05-27 16:06:12 --> Helper loaded: form_helper
INFO - 2023-05-27 16:06:12 --> Database Driver Class Initialized
INFO - 2023-05-27 16:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:06:12 --> Form Validation Class Initialized
INFO - 2023-05-27 16:06:12 --> Controller Class Initialized
INFO - 2023-05-27 16:06:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-27 16:06:12 --> Final output sent to browser
INFO - 2023-05-27 16:11:09 --> Config Class Initialized
INFO - 2023-05-27 16:11:09 --> Hooks Class Initialized
INFO - 2023-05-27 16:11:09 --> Utf8 Class Initialized
INFO - 2023-05-27 16:11:09 --> URI Class Initialized
INFO - 2023-05-27 16:11:09 --> Router Class Initialized
INFO - 2023-05-27 16:11:09 --> Output Class Initialized
INFO - 2023-05-27 16:11:09 --> Security Class Initialized
INFO - 2023-05-27 16:11:09 --> Input Class Initialized
INFO - 2023-05-27 16:11:09 --> Language Class Initialized
INFO - 2023-05-27 16:11:09 --> Loader Class Initialized
INFO - 2023-05-27 16:11:09 --> Helper loaded: url_helper
INFO - 2023-05-27 16:11:09 --> Helper loaded: form_helper
INFO - 2023-05-27 16:11:09 --> Database Driver Class Initialized
INFO - 2023-05-27 16:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:11:09 --> Form Validation Class Initialized
INFO - 2023-05-27 16:11:09 --> Controller Class Initialized
INFO - 2023-05-27 16:11:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-27 16:11:09 --> Final output sent to browser
INFO - 2023-05-27 16:11:11 --> Config Class Initialized
INFO - 2023-05-27 16:11:11 --> Hooks Class Initialized
INFO - 2023-05-27 16:11:11 --> Utf8 Class Initialized
INFO - 2023-05-27 16:11:11 --> URI Class Initialized
INFO - 2023-05-27 16:11:11 --> Router Class Initialized
INFO - 2023-05-27 16:11:11 --> Output Class Initialized
INFO - 2023-05-27 16:11:11 --> Security Class Initialized
INFO - 2023-05-27 16:11:11 --> Input Class Initialized
INFO - 2023-05-27 16:11:11 --> Language Class Initialized
INFO - 2023-05-27 16:11:11 --> Loader Class Initialized
INFO - 2023-05-27 16:11:11 --> Helper loaded: url_helper
INFO - 2023-05-27 16:11:11 --> Helper loaded: form_helper
INFO - 2023-05-27 16:11:11 --> Database Driver Class Initialized
INFO - 2023-05-27 16:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:11:11 --> Form Validation Class Initialized
INFO - 2023-05-27 16:11:11 --> Controller Class Initialized
INFO - 2023-05-27 16:11:11 --> Model "m_user" initialized
INFO - 2023-05-27 16:11:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-27 16:11:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-27 16:11:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-27 16:11:11 --> Final output sent to browser
INFO - 2023-05-27 16:11:15 --> Config Class Initialized
INFO - 2023-05-27 16:11:15 --> Hooks Class Initialized
INFO - 2023-05-27 16:11:15 --> Utf8 Class Initialized
INFO - 2023-05-27 16:11:15 --> URI Class Initialized
INFO - 2023-05-27 16:11:15 --> Router Class Initialized
INFO - 2023-05-27 16:11:15 --> Output Class Initialized
INFO - 2023-05-27 16:11:15 --> Security Class Initialized
INFO - 2023-05-27 16:11:15 --> Input Class Initialized
INFO - 2023-05-27 16:11:15 --> Language Class Initialized
INFO - 2023-05-27 16:11:15 --> Loader Class Initialized
INFO - 2023-05-27 16:11:15 --> Helper loaded: url_helper
INFO - 2023-05-27 16:11:15 --> Helper loaded: form_helper
INFO - 2023-05-27 16:11:15 --> Database Driver Class Initialized
INFO - 2023-05-27 16:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:11:15 --> Form Validation Class Initialized
INFO - 2023-05-27 16:11:15 --> Controller Class Initialized
INFO - 2023-05-27 16:11:15 --> Model "m_user" initialized
INFO - 2023-05-27 16:11:15 --> Config Class Initialized
INFO - 2023-05-27 16:11:15 --> Hooks Class Initialized
INFO - 2023-05-27 16:11:15 --> Utf8 Class Initialized
INFO - 2023-05-27 16:11:15 --> URI Class Initialized
INFO - 2023-05-27 16:11:15 --> Router Class Initialized
INFO - 2023-05-27 16:11:15 --> Output Class Initialized
INFO - 2023-05-27 16:11:15 --> Security Class Initialized
INFO - 2023-05-27 16:11:15 --> Input Class Initialized
INFO - 2023-05-27 16:11:15 --> Language Class Initialized
INFO - 2023-05-27 16:11:15 --> Loader Class Initialized
INFO - 2023-05-27 16:11:15 --> Helper loaded: url_helper
INFO - 2023-05-27 16:11:15 --> Helper loaded: form_helper
INFO - 2023-05-27 16:11:15 --> Database Driver Class Initialized
INFO - 2023-05-27 16:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:11:15 --> Form Validation Class Initialized
INFO - 2023-05-27 16:11:15 --> Controller Class Initialized
INFO - 2023-05-27 16:11:15 --> Model "m_user" initialized
INFO - 2023-05-27 16:11:15 --> Model "m_datatrain" initialized
INFO - 2023-05-27 16:11:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:11:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-27 16:11:15 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\_partials\sidebar.php 87
INFO - 2023-05-27 16:11:28 --> Config Class Initialized
INFO - 2023-05-27 16:11:28 --> Hooks Class Initialized
INFO - 2023-05-27 16:11:28 --> Utf8 Class Initialized
INFO - 2023-05-27 16:11:28 --> URI Class Initialized
INFO - 2023-05-27 16:11:28 --> Router Class Initialized
INFO - 2023-05-27 16:11:28 --> Output Class Initialized
INFO - 2023-05-27 16:11:28 --> Security Class Initialized
INFO - 2023-05-27 16:11:28 --> Input Class Initialized
INFO - 2023-05-27 16:11:28 --> Language Class Initialized
INFO - 2023-05-27 16:11:28 --> Loader Class Initialized
INFO - 2023-05-27 16:11:28 --> Helper loaded: url_helper
INFO - 2023-05-27 16:11:28 --> Helper loaded: form_helper
INFO - 2023-05-27 16:11:28 --> Database Driver Class Initialized
INFO - 2023-05-27 16:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:11:28 --> Form Validation Class Initialized
INFO - 2023-05-27 16:11:28 --> Controller Class Initialized
INFO - 2023-05-27 16:11:28 --> Model "m_user" initialized
INFO - 2023-05-27 16:11:28 --> Model "m_datatrain" initialized
INFO - 2023-05-27 16:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-27 16:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-27 16:11:28 --> Final output sent to browser
INFO - 2023-05-27 16:12:50 --> Config Class Initialized
INFO - 2023-05-27 16:12:50 --> Hooks Class Initialized
INFO - 2023-05-27 16:12:50 --> Utf8 Class Initialized
INFO - 2023-05-27 16:12:50 --> URI Class Initialized
INFO - 2023-05-27 16:12:50 --> Router Class Initialized
INFO - 2023-05-27 16:12:50 --> Output Class Initialized
INFO - 2023-05-27 16:12:50 --> Security Class Initialized
INFO - 2023-05-27 16:12:50 --> Input Class Initialized
INFO - 2023-05-27 16:12:50 --> Language Class Initialized
ERROR - 2023-05-27 16:12:50 --> 404 Page Not Found: Datatrain/index
INFO - 2023-05-27 16:12:54 --> Config Class Initialized
INFO - 2023-05-27 16:12:54 --> Hooks Class Initialized
INFO - 2023-05-27 16:12:54 --> Utf8 Class Initialized
INFO - 2023-05-27 16:12:54 --> URI Class Initialized
INFO - 2023-05-27 16:12:54 --> Router Class Initialized
INFO - 2023-05-27 16:12:54 --> Output Class Initialized
INFO - 2023-05-27 16:12:54 --> Security Class Initialized
INFO - 2023-05-27 16:12:54 --> Input Class Initialized
INFO - 2023-05-27 16:12:54 --> Language Class Initialized
INFO - 2023-05-27 16:12:54 --> Loader Class Initialized
INFO - 2023-05-27 16:12:54 --> Helper loaded: url_helper
INFO - 2023-05-27 16:12:54 --> Helper loaded: form_helper
INFO - 2023-05-27 16:12:54 --> Database Driver Class Initialized
INFO - 2023-05-27 16:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:12:54 --> Form Validation Class Initialized
INFO - 2023-05-27 16:12:54 --> Controller Class Initialized
INFO - 2023-05-27 16:12:54 --> Model "m_user" initialized
INFO - 2023-05-27 16:12:54 --> Model "m_datatrain" initialized
INFO - 2023-05-27 16:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-27 16:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-27 16:12:54 --> Final output sent to browser
INFO - 2023-05-27 16:12:56 --> Config Class Initialized
INFO - 2023-05-27 16:12:56 --> Hooks Class Initialized
INFO - 2023-05-27 16:12:56 --> Utf8 Class Initialized
INFO - 2023-05-27 16:12:56 --> URI Class Initialized
INFO - 2023-05-27 16:12:56 --> Router Class Initialized
INFO - 2023-05-27 16:12:56 --> Output Class Initialized
INFO - 2023-05-27 16:12:56 --> Security Class Initialized
INFO - 2023-05-27 16:12:56 --> Input Class Initialized
INFO - 2023-05-27 16:12:56 --> Language Class Initialized
INFO - 2023-05-27 16:12:56 --> Loader Class Initialized
INFO - 2023-05-27 16:12:56 --> Helper loaded: url_helper
INFO - 2023-05-27 16:12:56 --> Helper loaded: form_helper
INFO - 2023-05-27 16:12:56 --> Database Driver Class Initialized
INFO - 2023-05-27 16:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:12:56 --> Form Validation Class Initialized
INFO - 2023-05-27 16:12:56 --> Controller Class Initialized
INFO - 2023-05-27 16:12:56 --> Model "m_datatest" initialized
INFO - 2023-05-27 16:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-27 16:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-27 16:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-27 16:12:56 --> Final output sent to browser
INFO - 2023-05-27 16:12:58 --> Config Class Initialized
INFO - 2023-05-27 16:12:58 --> Hooks Class Initialized
INFO - 2023-05-27 16:12:58 --> Utf8 Class Initialized
INFO - 2023-05-27 16:12:58 --> URI Class Initialized
INFO - 2023-05-27 16:12:58 --> Router Class Initialized
INFO - 2023-05-27 16:12:58 --> Output Class Initialized
INFO - 2023-05-27 16:12:58 --> Security Class Initialized
INFO - 2023-05-27 16:12:58 --> Input Class Initialized
INFO - 2023-05-27 16:12:58 --> Language Class Initialized
ERROR - 2023-05-27 16:12:58 --> 404 Page Not Found: Datatrain/index
INFO - 2023-05-27 16:13:23 --> Config Class Initialized
INFO - 2023-05-27 16:13:23 --> Hooks Class Initialized
INFO - 2023-05-27 16:13:23 --> Utf8 Class Initialized
INFO - 2023-05-27 16:13:23 --> URI Class Initialized
INFO - 2023-05-27 16:13:23 --> Router Class Initialized
INFO - 2023-05-27 16:13:23 --> Output Class Initialized
INFO - 2023-05-27 16:13:23 --> Security Class Initialized
INFO - 2023-05-27 16:13:23 --> Input Class Initialized
INFO - 2023-05-27 16:13:23 --> Language Class Initialized
ERROR - 2023-05-27 16:13:23 --> 404 Page Not Found: C_datatraining/index
INFO - 2023-05-27 16:13:24 --> Config Class Initialized
INFO - 2023-05-27 16:13:24 --> Hooks Class Initialized
INFO - 2023-05-27 16:13:25 --> Utf8 Class Initialized
INFO - 2023-05-27 16:13:25 --> URI Class Initialized
INFO - 2023-05-27 16:13:25 --> Router Class Initialized
INFO - 2023-05-27 16:13:25 --> Output Class Initialized
INFO - 2023-05-27 16:13:25 --> Security Class Initialized
INFO - 2023-05-27 16:13:25 --> Input Class Initialized
INFO - 2023-05-27 16:13:25 --> Language Class Initialized
ERROR - 2023-05-27 16:13:25 --> 404 Page Not Found: C_datatraining/index
INFO - 2023-05-27 16:13:26 --> Config Class Initialized
INFO - 2023-05-27 16:13:26 --> Hooks Class Initialized
INFO - 2023-05-27 16:13:26 --> Utf8 Class Initialized
INFO - 2023-05-27 16:13:26 --> URI Class Initialized
INFO - 2023-05-27 16:13:26 --> Router Class Initialized
INFO - 2023-05-27 16:13:26 --> Output Class Initialized
INFO - 2023-05-27 16:13:26 --> Security Class Initialized
INFO - 2023-05-27 16:13:26 --> Input Class Initialized
INFO - 2023-05-27 16:13:26 --> Language Class Initialized
INFO - 2023-05-27 16:13:26 --> Loader Class Initialized
INFO - 2023-05-27 16:13:26 --> Helper loaded: url_helper
INFO - 2023-05-27 16:13:26 --> Helper loaded: form_helper
INFO - 2023-05-27 16:13:26 --> Database Driver Class Initialized
INFO - 2023-05-27 16:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:13:26 --> Form Validation Class Initialized
INFO - 2023-05-27 16:13:26 --> Controller Class Initialized
INFO - 2023-05-27 16:13:26 --> Model "m_datatest" initialized
INFO - 2023-05-27 16:13:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:13:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:13:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-27 16:13:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-27 16:13:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:13:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:13:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-27 16:13:26 --> Final output sent to browser
INFO - 2023-05-27 16:13:27 --> Config Class Initialized
INFO - 2023-05-27 16:13:27 --> Hooks Class Initialized
INFO - 2023-05-27 16:13:28 --> Utf8 Class Initialized
INFO - 2023-05-27 16:13:28 --> URI Class Initialized
INFO - 2023-05-27 16:13:28 --> Router Class Initialized
INFO - 2023-05-27 16:13:28 --> Output Class Initialized
INFO - 2023-05-27 16:13:28 --> Security Class Initialized
INFO - 2023-05-27 16:13:28 --> Input Class Initialized
INFO - 2023-05-27 16:13:28 --> Language Class Initialized
ERROR - 2023-05-27 16:13:28 --> 404 Page Not Found: C_datatraining/index
INFO - 2023-05-27 16:13:47 --> Config Class Initialized
INFO - 2023-05-27 16:13:47 --> Hooks Class Initialized
INFO - 2023-05-27 16:13:47 --> Utf8 Class Initialized
INFO - 2023-05-27 16:13:47 --> URI Class Initialized
INFO - 2023-05-27 16:13:47 --> Router Class Initialized
INFO - 2023-05-27 16:13:47 --> Output Class Initialized
INFO - 2023-05-27 16:13:47 --> Security Class Initialized
INFO - 2023-05-27 16:13:47 --> Input Class Initialized
INFO - 2023-05-27 16:13:47 --> Language Class Initialized
ERROR - 2023-05-27 16:13:47 --> 404 Page Not Found: Datatrain/index
INFO - 2023-05-27 16:13:47 --> Config Class Initialized
INFO - 2023-05-27 16:13:47 --> Hooks Class Initialized
INFO - 2023-05-27 16:13:47 --> Utf8 Class Initialized
INFO - 2023-05-27 16:13:47 --> URI Class Initialized
INFO - 2023-05-27 16:13:47 --> Router Class Initialized
INFO - 2023-05-27 16:13:47 --> Output Class Initialized
INFO - 2023-05-27 16:13:47 --> Security Class Initialized
INFO - 2023-05-27 16:13:47 --> Input Class Initialized
INFO - 2023-05-27 16:13:47 --> Language Class Initialized
ERROR - 2023-05-27 16:13:47 --> 404 Page Not Found: Datatrain/index
INFO - 2023-05-27 16:13:48 --> Config Class Initialized
INFO - 2023-05-27 16:13:48 --> Hooks Class Initialized
INFO - 2023-05-27 16:13:48 --> Utf8 Class Initialized
INFO - 2023-05-27 16:13:48 --> URI Class Initialized
INFO - 2023-05-27 16:13:48 --> Router Class Initialized
INFO - 2023-05-27 16:13:48 --> Output Class Initialized
INFO - 2023-05-27 16:13:48 --> Security Class Initialized
INFO - 2023-05-27 16:13:48 --> Input Class Initialized
INFO - 2023-05-27 16:13:48 --> Language Class Initialized
ERROR - 2023-05-27 16:13:48 --> 404 Page Not Found: Datatrain/index
INFO - 2023-05-27 16:13:48 --> Config Class Initialized
INFO - 2023-05-27 16:13:48 --> Hooks Class Initialized
INFO - 2023-05-27 16:13:48 --> Utf8 Class Initialized
INFO - 2023-05-27 16:13:48 --> URI Class Initialized
INFO - 2023-05-27 16:13:48 --> Router Class Initialized
INFO - 2023-05-27 16:13:48 --> Output Class Initialized
INFO - 2023-05-27 16:13:48 --> Security Class Initialized
INFO - 2023-05-27 16:13:48 --> Input Class Initialized
INFO - 2023-05-27 16:13:48 --> Language Class Initialized
ERROR - 2023-05-27 16:13:48 --> 404 Page Not Found: Datatrain/index
INFO - 2023-05-27 16:13:48 --> Config Class Initialized
INFO - 2023-05-27 16:13:48 --> Hooks Class Initialized
INFO - 2023-05-27 16:13:48 --> Utf8 Class Initialized
INFO - 2023-05-27 16:13:48 --> URI Class Initialized
INFO - 2023-05-27 16:13:48 --> Router Class Initialized
INFO - 2023-05-27 16:13:48 --> Output Class Initialized
INFO - 2023-05-27 16:13:48 --> Security Class Initialized
INFO - 2023-05-27 16:13:48 --> Input Class Initialized
INFO - 2023-05-27 16:13:48 --> Language Class Initialized
INFO - 2023-05-27 16:13:48 --> Loader Class Initialized
INFO - 2023-05-27 16:13:48 --> Helper loaded: url_helper
INFO - 2023-05-27 16:13:48 --> Helper loaded: form_helper
INFO - 2023-05-27 16:13:48 --> Database Driver Class Initialized
INFO - 2023-05-27 16:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:13:48 --> Form Validation Class Initialized
INFO - 2023-05-27 16:13:48 --> Controller Class Initialized
INFO - 2023-05-27 16:13:48 --> Model "m_datatest" initialized
INFO - 2023-05-27 16:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-27 16:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-27 16:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:13:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-27 16:13:48 --> Final output sent to browser
INFO - 2023-05-27 16:13:50 --> Config Class Initialized
INFO - 2023-05-27 16:13:50 --> Hooks Class Initialized
INFO - 2023-05-27 16:13:50 --> Utf8 Class Initialized
INFO - 2023-05-27 16:13:50 --> URI Class Initialized
INFO - 2023-05-27 16:13:50 --> Router Class Initialized
INFO - 2023-05-27 16:13:50 --> Output Class Initialized
INFO - 2023-05-27 16:13:50 --> Security Class Initialized
INFO - 2023-05-27 16:13:50 --> Input Class Initialized
INFO - 2023-05-27 16:13:50 --> Language Class Initialized
ERROR - 2023-05-27 16:13:50 --> 404 Page Not Found: Datatrain/index
INFO - 2023-05-27 16:13:59 --> Config Class Initialized
INFO - 2023-05-27 16:13:59 --> Hooks Class Initialized
INFO - 2023-05-27 16:13:59 --> Utf8 Class Initialized
INFO - 2023-05-27 16:13:59 --> URI Class Initialized
INFO - 2023-05-27 16:13:59 --> Router Class Initialized
INFO - 2023-05-27 16:13:59 --> Output Class Initialized
INFO - 2023-05-27 16:13:59 --> Security Class Initialized
INFO - 2023-05-27 16:13:59 --> Input Class Initialized
INFO - 2023-05-27 16:13:59 --> Language Class Initialized
INFO - 2023-05-27 16:13:59 --> Loader Class Initialized
INFO - 2023-05-27 16:13:59 --> Helper loaded: url_helper
INFO - 2023-05-27 16:13:59 --> Helper loaded: form_helper
INFO - 2023-05-27 16:13:59 --> Database Driver Class Initialized
INFO - 2023-05-27 16:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:13:59 --> Form Validation Class Initialized
INFO - 2023-05-27 16:13:59 --> Controller Class Initialized
INFO - 2023-05-27 16:13:59 --> Model "m_datatrain" initialized
INFO - 2023-05-27 16:13:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:13:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:13:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-27 16:13:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-27 16:13:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:13:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:13:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-27 16:13:59 --> Final output sent to browser
INFO - 2023-05-27 16:14:32 --> Config Class Initialized
INFO - 2023-05-27 16:14:32 --> Hooks Class Initialized
INFO - 2023-05-27 16:14:32 --> Utf8 Class Initialized
INFO - 2023-05-27 16:14:32 --> URI Class Initialized
INFO - 2023-05-27 16:14:32 --> Router Class Initialized
INFO - 2023-05-27 16:14:32 --> Output Class Initialized
INFO - 2023-05-27 16:14:32 --> Security Class Initialized
INFO - 2023-05-27 16:14:32 --> Input Class Initialized
INFO - 2023-05-27 16:14:32 --> Language Class Initialized
INFO - 2023-05-27 16:14:32 --> Loader Class Initialized
INFO - 2023-05-27 16:14:32 --> Helper loaded: url_helper
INFO - 2023-05-27 16:14:32 --> Helper loaded: form_helper
INFO - 2023-05-27 16:14:32 --> Database Driver Class Initialized
INFO - 2023-05-27 16:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:14:32 --> Form Validation Class Initialized
INFO - 2023-05-27 16:14:32 --> Controller Class Initialized
INFO - 2023-05-27 16:14:32 --> Model "m_datatrain" initialized
INFO - 2023-05-27 16:14:32 --> Model "m_penghitungan" initialized
INFO - 2023-05-27 16:14:32 --> Model "m_datatest" initialized
INFO - 2023-05-27 16:14:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:14:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:14:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-27 16:14:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-27 16:14:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:14:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:14:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-27 16:14:33 --> Final output sent to browser
INFO - 2023-05-27 16:14:37 --> Config Class Initialized
INFO - 2023-05-27 16:14:37 --> Hooks Class Initialized
INFO - 2023-05-27 16:14:37 --> Utf8 Class Initialized
INFO - 2023-05-27 16:14:37 --> URI Class Initialized
INFO - 2023-05-27 16:14:37 --> Router Class Initialized
INFO - 2023-05-27 16:14:37 --> Output Class Initialized
INFO - 2023-05-27 16:14:37 --> Security Class Initialized
INFO - 2023-05-27 16:14:37 --> Input Class Initialized
INFO - 2023-05-27 16:14:37 --> Language Class Initialized
INFO - 2023-05-27 16:14:37 --> Loader Class Initialized
INFO - 2023-05-27 16:14:37 --> Helper loaded: url_helper
INFO - 2023-05-27 16:14:37 --> Helper loaded: form_helper
INFO - 2023-05-27 16:14:37 --> Database Driver Class Initialized
INFO - 2023-05-27 16:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:14:37 --> Form Validation Class Initialized
INFO - 2023-05-27 16:14:37 --> Controller Class Initialized
INFO - 2023-05-27 16:14:37 --> Model "m_user" initialized
INFO - 2023-05-27 16:14:37 --> Config Class Initialized
INFO - 2023-05-27 16:14:37 --> Hooks Class Initialized
INFO - 2023-05-27 16:14:37 --> Utf8 Class Initialized
INFO - 2023-05-27 16:14:37 --> URI Class Initialized
INFO - 2023-05-27 16:14:37 --> Router Class Initialized
INFO - 2023-05-27 16:14:37 --> Output Class Initialized
INFO - 2023-05-27 16:14:37 --> Security Class Initialized
INFO - 2023-05-27 16:14:37 --> Input Class Initialized
INFO - 2023-05-27 16:14:37 --> Language Class Initialized
INFO - 2023-05-27 16:14:37 --> Loader Class Initialized
INFO - 2023-05-27 16:14:37 --> Helper loaded: url_helper
INFO - 2023-05-27 16:14:37 --> Helper loaded: form_helper
INFO - 2023-05-27 16:14:37 --> Database Driver Class Initialized
INFO - 2023-05-27 16:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:14:37 --> Form Validation Class Initialized
INFO - 2023-05-27 16:14:37 --> Controller Class Initialized
INFO - 2023-05-27 16:14:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-27 16:14:37 --> Final output sent to browser
INFO - 2023-05-27 16:23:24 --> Config Class Initialized
INFO - 2023-05-27 16:23:24 --> Hooks Class Initialized
INFO - 2023-05-27 16:23:24 --> Utf8 Class Initialized
INFO - 2023-05-27 16:23:24 --> URI Class Initialized
INFO - 2023-05-27 16:23:24 --> Router Class Initialized
INFO - 2023-05-27 16:23:24 --> Output Class Initialized
INFO - 2023-05-27 16:23:24 --> Security Class Initialized
INFO - 2023-05-27 16:23:24 --> Input Class Initialized
INFO - 2023-05-27 16:23:24 --> Language Class Initialized
INFO - 2023-05-27 16:23:24 --> Loader Class Initialized
INFO - 2023-05-27 16:23:24 --> Helper loaded: url_helper
INFO - 2023-05-27 16:23:24 --> Helper loaded: form_helper
INFO - 2023-05-27 16:23:24 --> Database Driver Class Initialized
INFO - 2023-05-27 16:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:23:24 --> Form Validation Class Initialized
INFO - 2023-05-27 16:23:24 --> Controller Class Initialized
INFO - 2023-05-27 16:23:24 --> Model "m_user" initialized
INFO - 2023-05-27 16:23:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:23:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:23:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-27 16:23:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:23:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:23:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-27 16:23:24 --> Final output sent to browser
INFO - 2023-05-27 16:23:29 --> Config Class Initialized
INFO - 2023-05-27 16:23:29 --> Hooks Class Initialized
INFO - 2023-05-27 16:23:29 --> Utf8 Class Initialized
INFO - 2023-05-27 16:23:29 --> URI Class Initialized
INFO - 2023-05-27 16:23:29 --> Router Class Initialized
INFO - 2023-05-27 16:23:29 --> Output Class Initialized
INFO - 2023-05-27 16:23:29 --> Security Class Initialized
INFO - 2023-05-27 16:23:29 --> Input Class Initialized
INFO - 2023-05-27 16:23:29 --> Language Class Initialized
INFO - 2023-05-27 16:23:29 --> Loader Class Initialized
INFO - 2023-05-27 16:23:29 --> Helper loaded: url_helper
INFO - 2023-05-27 16:23:29 --> Helper loaded: form_helper
INFO - 2023-05-27 16:23:29 --> Database Driver Class Initialized
INFO - 2023-05-27 16:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:23:29 --> Form Validation Class Initialized
INFO - 2023-05-27 16:23:29 --> Controller Class Initialized
INFO - 2023-05-27 16:23:29 --> Model "m_datatrain" initialized
INFO - 2023-05-27 16:23:29 --> Model "m_penghitungan" initialized
INFO - 2023-05-27 16:23:29 --> Model "m_datatest" initialized
INFO - 2023-05-27 16:23:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:23:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:23:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-27 16:23:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-27 16:23:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:23:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:23:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-27 16:23:29 --> Final output sent to browser
INFO - 2023-05-27 16:24:19 --> Config Class Initialized
INFO - 2023-05-27 16:24:19 --> Hooks Class Initialized
INFO - 2023-05-27 16:24:19 --> Utf8 Class Initialized
INFO - 2023-05-27 16:24:19 --> URI Class Initialized
INFO - 2023-05-27 16:24:19 --> Router Class Initialized
INFO - 2023-05-27 16:24:19 --> Output Class Initialized
INFO - 2023-05-27 16:24:19 --> Security Class Initialized
INFO - 2023-05-27 16:24:19 --> Input Class Initialized
INFO - 2023-05-27 16:24:19 --> Language Class Initialized
INFO - 2023-05-27 16:24:19 --> Loader Class Initialized
INFO - 2023-05-27 16:24:19 --> Helper loaded: url_helper
INFO - 2023-05-27 16:24:19 --> Helper loaded: form_helper
INFO - 2023-05-27 16:24:19 --> Database Driver Class Initialized
INFO - 2023-05-27 16:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:24:19 --> Form Validation Class Initialized
INFO - 2023-05-27 16:24:19 --> Controller Class Initialized
INFO - 2023-05-27 16:24:19 --> Model "m_datatrain" initialized
INFO - 2023-05-27 16:24:19 --> Model "m_penghitungan" initialized
INFO - 2023-05-27 16:24:19 --> Model "m_datatest" initialized
INFO - 2023-05-27 16:24:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:24:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:24:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-27 16:24:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-27 16:24:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:24:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:24:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-27 16:24:19 --> Final output sent to browser
INFO - 2023-05-27 16:25:46 --> Config Class Initialized
INFO - 2023-05-27 16:25:46 --> Hooks Class Initialized
INFO - 2023-05-27 16:25:46 --> Utf8 Class Initialized
INFO - 2023-05-27 16:25:46 --> URI Class Initialized
INFO - 2023-05-27 16:25:46 --> Router Class Initialized
INFO - 2023-05-27 16:25:46 --> Output Class Initialized
INFO - 2023-05-27 16:25:46 --> Security Class Initialized
INFO - 2023-05-27 16:25:46 --> Input Class Initialized
INFO - 2023-05-27 16:25:46 --> Language Class Initialized
INFO - 2023-05-27 16:25:46 --> Loader Class Initialized
INFO - 2023-05-27 16:25:46 --> Helper loaded: url_helper
INFO - 2023-05-27 16:25:46 --> Helper loaded: form_helper
INFO - 2023-05-27 16:25:46 --> Database Driver Class Initialized
INFO - 2023-05-27 16:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:25:46 --> Form Validation Class Initialized
INFO - 2023-05-27 16:25:46 --> Controller Class Initialized
INFO - 2023-05-27 16:25:46 --> Model "m_datatrain" initialized
INFO - 2023-05-27 16:25:46 --> Model "m_penghitungan" initialized
INFO - 2023-05-27 16:25:46 --> Model "m_datatest" initialized
INFO - 2023-05-27 16:25:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:25:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-27 16:25:46 --> Severity: Parsing Error --> syntax error, unexpected '$percent_prob_GangguanMood' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 23
INFO - 2023-05-27 16:26:18 --> Config Class Initialized
INFO - 2023-05-27 16:26:18 --> Hooks Class Initialized
INFO - 2023-05-27 16:26:18 --> Utf8 Class Initialized
INFO - 2023-05-27 16:26:18 --> URI Class Initialized
INFO - 2023-05-27 16:26:18 --> Router Class Initialized
INFO - 2023-05-27 16:26:18 --> Output Class Initialized
INFO - 2023-05-27 16:26:18 --> Security Class Initialized
INFO - 2023-05-27 16:26:18 --> Input Class Initialized
INFO - 2023-05-27 16:26:18 --> Language Class Initialized
ERROR - 2023-05-27 16:26:18 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 798
INFO - 2023-05-27 16:27:01 --> Config Class Initialized
INFO - 2023-05-27 16:27:01 --> Hooks Class Initialized
INFO - 2023-05-27 16:27:01 --> Utf8 Class Initialized
INFO - 2023-05-27 16:27:01 --> URI Class Initialized
INFO - 2023-05-27 16:27:01 --> Router Class Initialized
INFO - 2023-05-27 16:27:01 --> Output Class Initialized
INFO - 2023-05-27 16:27:01 --> Security Class Initialized
INFO - 2023-05-27 16:27:01 --> Input Class Initialized
INFO - 2023-05-27 16:27:01 --> Language Class Initialized
INFO - 2023-05-27 16:27:01 --> Loader Class Initialized
INFO - 2023-05-27 16:27:01 --> Helper loaded: url_helper
INFO - 2023-05-27 16:27:01 --> Helper loaded: form_helper
INFO - 2023-05-27 16:27:01 --> Database Driver Class Initialized
INFO - 2023-05-27 16:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:27:01 --> Form Validation Class Initialized
INFO - 2023-05-27 16:27:01 --> Controller Class Initialized
INFO - 2023-05-27 16:27:01 --> Model "m_datatrain" initialized
INFO - 2023-05-27 16:27:01 --> Model "m_penghitungan" initialized
INFO - 2023-05-27 16:27:01 --> Model "m_datatest" initialized
INFO - 2023-05-27 16:27:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-27 16:27:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-27 16:27:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-27 16:27:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-27 16:27:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-27 16:27:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-27 16:27:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-27 16:27:01 --> Final output sent to browser
