<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-08 09:08:39 --> Config Class Initialized
INFO - 2023-06-08 09:08:39 --> Hooks Class Initialized
INFO - 2023-06-08 09:08:39 --> Utf8 Class Initialized
INFO - 2023-06-08 09:08:39 --> URI Class Initialized
INFO - 2023-06-08 09:08:39 --> Router Class Initialized
INFO - 2023-06-08 09:08:39 --> Output Class Initialized
INFO - 2023-06-08 09:08:39 --> Security Class Initialized
INFO - 2023-06-08 09:08:39 --> Input Class Initialized
INFO - 2023-06-08 09:08:39 --> Language Class Initialized
INFO - 2023-06-08 09:08:39 --> Loader Class Initialized
INFO - 2023-06-08 09:08:39 --> Helper loaded: url_helper
INFO - 2023-06-08 09:08:39 --> Helper loaded: form_helper
INFO - 2023-06-08 09:08:39 --> Database Driver Class Initialized
INFO - 2023-06-08 09:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:08:40 --> Form Validation Class Initialized
INFO - 2023-06-08 09:08:40 --> Controller Class Initialized
INFO - 2023-06-08 09:08:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-08 09:08:40 --> Final output sent to browser
INFO - 2023-06-08 09:08:42 --> Config Class Initialized
INFO - 2023-06-08 09:08:42 --> Hooks Class Initialized
INFO - 2023-06-08 09:08:42 --> Utf8 Class Initialized
INFO - 2023-06-08 09:08:42 --> URI Class Initialized
INFO - 2023-06-08 09:08:42 --> Router Class Initialized
INFO - 2023-06-08 09:08:42 --> Output Class Initialized
INFO - 2023-06-08 09:08:42 --> Security Class Initialized
INFO - 2023-06-08 09:08:42 --> Input Class Initialized
INFO - 2023-06-08 09:08:42 --> Language Class Initialized
INFO - 2023-06-08 09:08:42 --> Loader Class Initialized
INFO - 2023-06-08 09:08:42 --> Helper loaded: url_helper
INFO - 2023-06-08 09:08:42 --> Helper loaded: form_helper
INFO - 2023-06-08 09:08:42 --> Database Driver Class Initialized
INFO - 2023-06-08 09:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:08:42 --> Form Validation Class Initialized
INFO - 2023-06-08 09:08:42 --> Controller Class Initialized
INFO - 2023-06-08 09:08:42 --> Model "m_user" initialized
INFO - 2023-06-08 09:08:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-08 09:08:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-08 09:08:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-08 09:08:42 --> Final output sent to browser
INFO - 2023-06-08 09:08:50 --> Config Class Initialized
INFO - 2023-06-08 09:08:50 --> Hooks Class Initialized
INFO - 2023-06-08 09:08:50 --> Utf8 Class Initialized
INFO - 2023-06-08 09:08:50 --> URI Class Initialized
INFO - 2023-06-08 09:08:50 --> Router Class Initialized
INFO - 2023-06-08 09:08:50 --> Output Class Initialized
INFO - 2023-06-08 09:08:50 --> Security Class Initialized
INFO - 2023-06-08 09:08:50 --> Input Class Initialized
INFO - 2023-06-08 09:08:50 --> Language Class Initialized
INFO - 2023-06-08 09:08:50 --> Loader Class Initialized
INFO - 2023-06-08 09:08:50 --> Helper loaded: url_helper
INFO - 2023-06-08 09:08:50 --> Helper loaded: form_helper
INFO - 2023-06-08 09:08:50 --> Database Driver Class Initialized
INFO - 2023-06-08 09:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:08:50 --> Form Validation Class Initialized
INFO - 2023-06-08 09:08:50 --> Controller Class Initialized
INFO - 2023-06-08 09:08:50 --> Model "m_user" initialized
INFO - 2023-06-08 09:08:50 --> Config Class Initialized
INFO - 2023-06-08 09:08:50 --> Hooks Class Initialized
INFO - 2023-06-08 09:08:50 --> Utf8 Class Initialized
INFO - 2023-06-08 09:08:50 --> URI Class Initialized
INFO - 2023-06-08 09:08:50 --> Router Class Initialized
INFO - 2023-06-08 09:08:50 --> Output Class Initialized
INFO - 2023-06-08 09:08:50 --> Security Class Initialized
INFO - 2023-06-08 09:08:50 --> Input Class Initialized
INFO - 2023-06-08 09:08:50 --> Language Class Initialized
INFO - 2023-06-08 09:08:50 --> Loader Class Initialized
INFO - 2023-06-08 09:08:50 --> Helper loaded: url_helper
INFO - 2023-06-08 09:08:50 --> Helper loaded: form_helper
INFO - 2023-06-08 09:08:50 --> Database Driver Class Initialized
INFO - 2023-06-08 09:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:08:50 --> Form Validation Class Initialized
INFO - 2023-06-08 09:08:50 --> Controller Class Initialized
INFO - 2023-06-08 09:08:50 --> Model "m_user" initialized
INFO - 2023-06-08 09:08:50 --> Model "m_datatrain" initialized
INFO - 2023-06-08 09:08:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 09:08:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 09:08:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 09:08:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 09:08:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 09:08:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-08 09:08:50 --> Final output sent to browser
INFO - 2023-06-08 09:08:53 --> Config Class Initialized
INFO - 2023-06-08 09:08:53 --> Hooks Class Initialized
INFO - 2023-06-08 09:08:53 --> Utf8 Class Initialized
INFO - 2023-06-08 09:08:53 --> URI Class Initialized
INFO - 2023-06-08 09:08:53 --> Router Class Initialized
INFO - 2023-06-08 09:08:53 --> Output Class Initialized
INFO - 2023-06-08 09:08:53 --> Security Class Initialized
INFO - 2023-06-08 09:08:53 --> Input Class Initialized
INFO - 2023-06-08 09:08:53 --> Language Class Initialized
INFO - 2023-06-08 09:08:53 --> Loader Class Initialized
INFO - 2023-06-08 09:08:53 --> Helper loaded: url_helper
INFO - 2023-06-08 09:08:53 --> Helper loaded: form_helper
INFO - 2023-06-08 09:08:53 --> Database Driver Class Initialized
INFO - 2023-06-08 09:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:08:53 --> Form Validation Class Initialized
INFO - 2023-06-08 09:08:53 --> Controller Class Initialized
INFO - 2023-06-08 09:08:53 --> Model "m_datatest" initialized
INFO - 2023-06-08 09:08:53 --> Model "m_penghitungan" initialized
INFO - 2023-06-08 09:08:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 09:08:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 09:08:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-08 09:08:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 09:08:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 09:08:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 09:08:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-08 09:08:53 --> Final output sent to browser
INFO - 2023-06-08 09:08:55 --> Config Class Initialized
INFO - 2023-06-08 09:08:55 --> Hooks Class Initialized
INFO - 2023-06-08 09:08:55 --> Utf8 Class Initialized
INFO - 2023-06-08 09:08:55 --> URI Class Initialized
INFO - 2023-06-08 09:08:55 --> Router Class Initialized
INFO - 2023-06-08 09:08:55 --> Output Class Initialized
INFO - 2023-06-08 09:08:55 --> Security Class Initialized
INFO - 2023-06-08 09:08:55 --> Input Class Initialized
INFO - 2023-06-08 09:08:55 --> Language Class Initialized
INFO - 2023-06-08 09:08:55 --> Loader Class Initialized
INFO - 2023-06-08 09:08:55 --> Helper loaded: url_helper
INFO - 2023-06-08 09:08:55 --> Helper loaded: form_helper
INFO - 2023-06-08 09:08:55 --> Database Driver Class Initialized
INFO - 2023-06-08 09:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:08:55 --> Form Validation Class Initialized
INFO - 2023-06-08 09:08:55 --> Controller Class Initialized
INFO - 2023-06-08 09:08:55 --> Model "m_datatest" initialized
INFO - 2023-06-08 09:08:55 --> Model "m_penghitungan" initialized
INFO - 2023-06-08 09:08:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 09:08:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 09:08:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-08 09:08:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 09:08:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 09:08:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 09:08:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-08 09:08:56 --> Final output sent to browser
INFO - 2023-06-08 09:09:11 --> Config Class Initialized
INFO - 2023-06-08 09:09:11 --> Hooks Class Initialized
INFO - 2023-06-08 09:09:11 --> Utf8 Class Initialized
INFO - 2023-06-08 09:09:11 --> URI Class Initialized
INFO - 2023-06-08 09:09:11 --> Router Class Initialized
INFO - 2023-06-08 09:09:11 --> Output Class Initialized
INFO - 2023-06-08 09:09:11 --> Security Class Initialized
INFO - 2023-06-08 09:09:11 --> Input Class Initialized
INFO - 2023-06-08 09:09:11 --> Language Class Initialized
INFO - 2023-06-08 09:09:11 --> Loader Class Initialized
INFO - 2023-06-08 09:09:11 --> Helper loaded: url_helper
INFO - 2023-06-08 09:09:11 --> Helper loaded: form_helper
INFO - 2023-06-08 09:09:11 --> Database Driver Class Initialized
INFO - 2023-06-08 09:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:09:11 --> Form Validation Class Initialized
INFO - 2023-06-08 09:09:11 --> Controller Class Initialized
INFO - 2023-06-08 09:09:11 --> Model "m_user" initialized
INFO - 2023-06-08 09:09:11 --> Config Class Initialized
INFO - 2023-06-08 09:09:11 --> Hooks Class Initialized
INFO - 2023-06-08 09:09:11 --> Utf8 Class Initialized
INFO - 2023-06-08 09:09:11 --> URI Class Initialized
INFO - 2023-06-08 09:09:11 --> Router Class Initialized
INFO - 2023-06-08 09:09:11 --> Output Class Initialized
INFO - 2023-06-08 09:09:11 --> Security Class Initialized
INFO - 2023-06-08 09:09:11 --> Input Class Initialized
INFO - 2023-06-08 09:09:11 --> Language Class Initialized
INFO - 2023-06-08 09:09:11 --> Loader Class Initialized
INFO - 2023-06-08 09:09:11 --> Helper loaded: url_helper
INFO - 2023-06-08 09:09:11 --> Helper loaded: form_helper
INFO - 2023-06-08 09:09:11 --> Database Driver Class Initialized
INFO - 2023-06-08 09:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:09:11 --> Form Validation Class Initialized
INFO - 2023-06-08 09:09:11 --> Controller Class Initialized
INFO - 2023-06-08 09:09:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-08 09:09:11 --> Final output sent to browser
INFO - 2023-06-08 09:09:13 --> Config Class Initialized
INFO - 2023-06-08 09:09:13 --> Hooks Class Initialized
INFO - 2023-06-08 09:09:13 --> Utf8 Class Initialized
INFO - 2023-06-08 09:09:14 --> URI Class Initialized
INFO - 2023-06-08 09:09:14 --> Router Class Initialized
INFO - 2023-06-08 09:09:14 --> Output Class Initialized
INFO - 2023-06-08 09:09:14 --> Security Class Initialized
INFO - 2023-06-08 09:09:14 --> Input Class Initialized
INFO - 2023-06-08 09:09:14 --> Language Class Initialized
INFO - 2023-06-08 09:09:14 --> Loader Class Initialized
INFO - 2023-06-08 09:09:14 --> Helper loaded: url_helper
INFO - 2023-06-08 09:09:14 --> Helper loaded: form_helper
INFO - 2023-06-08 09:09:14 --> Database Driver Class Initialized
INFO - 2023-06-08 09:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:09:14 --> Form Validation Class Initialized
INFO - 2023-06-08 09:09:14 --> Controller Class Initialized
INFO - 2023-06-08 09:09:14 --> Model "m_user" initialized
INFO - 2023-06-08 09:09:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 09:09:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 09:09:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 09:09:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 09:09:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 09:09:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-08 09:09:14 --> Final output sent to browser
INFO - 2023-06-08 09:09:16 --> Config Class Initialized
INFO - 2023-06-08 09:09:16 --> Hooks Class Initialized
INFO - 2023-06-08 09:09:16 --> Utf8 Class Initialized
INFO - 2023-06-08 09:09:16 --> URI Class Initialized
INFO - 2023-06-08 09:09:16 --> Router Class Initialized
INFO - 2023-06-08 09:09:16 --> Output Class Initialized
INFO - 2023-06-08 09:09:16 --> Security Class Initialized
INFO - 2023-06-08 09:09:16 --> Input Class Initialized
INFO - 2023-06-08 09:09:16 --> Language Class Initialized
INFO - 2023-06-08 09:09:16 --> Loader Class Initialized
INFO - 2023-06-08 09:09:16 --> Helper loaded: url_helper
INFO - 2023-06-08 09:09:16 --> Helper loaded: form_helper
INFO - 2023-06-08 09:09:16 --> Database Driver Class Initialized
INFO - 2023-06-08 09:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:09:16 --> Form Validation Class Initialized
INFO - 2023-06-08 09:09:16 --> Controller Class Initialized
INFO - 2023-06-08 09:09:16 --> Model "m_datatrain" initialized
INFO - 2023-06-08 09:09:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-08 09:09:16 --> Model "m_datatest" initialized
INFO - 2023-06-08 09:09:16 --> Model "M_solusi" initialized
INFO - 2023-06-08 09:09:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 09:09:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 09:09:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-08 09:09:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 09:09:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 09:09:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 09:09:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 09:09:16 --> Final output sent to browser
INFO - 2023-06-08 09:09:38 --> Config Class Initialized
INFO - 2023-06-08 09:09:38 --> Hooks Class Initialized
INFO - 2023-06-08 09:09:38 --> Utf8 Class Initialized
INFO - 2023-06-08 09:09:38 --> URI Class Initialized
INFO - 2023-06-08 09:09:38 --> Router Class Initialized
INFO - 2023-06-08 09:09:38 --> Output Class Initialized
INFO - 2023-06-08 09:09:38 --> Security Class Initialized
INFO - 2023-06-08 09:09:38 --> Input Class Initialized
INFO - 2023-06-08 09:09:38 --> Language Class Initialized
INFO - 2023-06-08 09:09:38 --> Loader Class Initialized
INFO - 2023-06-08 09:09:38 --> Helper loaded: url_helper
INFO - 2023-06-08 09:09:38 --> Helper loaded: form_helper
INFO - 2023-06-08 09:09:38 --> Database Driver Class Initialized
INFO - 2023-06-08 09:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:09:38 --> Form Validation Class Initialized
INFO - 2023-06-08 09:09:38 --> Controller Class Initialized
INFO - 2023-06-08 09:09:38 --> Model "m_user" initialized
INFO - 2023-06-08 09:09:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 09:09:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 09:09:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 09:09:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 09:09:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 09:09:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-08 09:09:38 --> Final output sent to browser
INFO - 2023-06-08 09:12:40 --> Config Class Initialized
INFO - 2023-06-08 09:12:40 --> Hooks Class Initialized
INFO - 2023-06-08 09:12:40 --> Utf8 Class Initialized
INFO - 2023-06-08 09:12:40 --> URI Class Initialized
INFO - 2023-06-08 09:12:40 --> Router Class Initialized
INFO - 2023-06-08 09:12:40 --> Output Class Initialized
INFO - 2023-06-08 09:12:40 --> Security Class Initialized
INFO - 2023-06-08 09:12:40 --> Input Class Initialized
INFO - 2023-06-08 09:12:40 --> Language Class Initialized
INFO - 2023-06-08 09:12:40 --> Loader Class Initialized
INFO - 2023-06-08 09:12:40 --> Helper loaded: url_helper
INFO - 2023-06-08 09:12:40 --> Helper loaded: form_helper
INFO - 2023-06-08 09:12:40 --> Database Driver Class Initialized
INFO - 2023-06-08 09:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:12:40 --> Form Validation Class Initialized
INFO - 2023-06-08 09:12:40 --> Controller Class Initialized
INFO - 2023-06-08 09:12:40 --> Model "m_user" initialized
INFO - 2023-06-08 09:12:40 --> Config Class Initialized
INFO - 2023-06-08 09:12:40 --> Hooks Class Initialized
INFO - 2023-06-08 09:12:40 --> Utf8 Class Initialized
INFO - 2023-06-08 09:12:40 --> URI Class Initialized
INFO - 2023-06-08 09:12:40 --> Router Class Initialized
INFO - 2023-06-08 09:12:40 --> Output Class Initialized
INFO - 2023-06-08 09:12:40 --> Security Class Initialized
INFO - 2023-06-08 09:12:40 --> Input Class Initialized
INFO - 2023-06-08 09:12:40 --> Language Class Initialized
INFO - 2023-06-08 09:12:40 --> Loader Class Initialized
INFO - 2023-06-08 09:12:40 --> Helper loaded: url_helper
INFO - 2023-06-08 09:12:40 --> Helper loaded: form_helper
INFO - 2023-06-08 09:12:40 --> Database Driver Class Initialized
INFO - 2023-06-08 09:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:12:40 --> Form Validation Class Initialized
INFO - 2023-06-08 09:12:40 --> Controller Class Initialized
INFO - 2023-06-08 09:12:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-08 09:12:40 --> Final output sent to browser
INFO - 2023-06-08 09:18:42 --> Config Class Initialized
INFO - 2023-06-08 09:18:42 --> Hooks Class Initialized
INFO - 2023-06-08 09:18:42 --> Utf8 Class Initialized
INFO - 2023-06-08 09:18:42 --> URI Class Initialized
INFO - 2023-06-08 09:18:42 --> Router Class Initialized
INFO - 2023-06-08 09:18:42 --> Output Class Initialized
INFO - 2023-06-08 09:18:42 --> Security Class Initialized
INFO - 2023-06-08 09:18:42 --> Input Class Initialized
INFO - 2023-06-08 09:18:42 --> Language Class Initialized
INFO - 2023-06-08 09:18:42 --> Loader Class Initialized
INFO - 2023-06-08 09:18:42 --> Helper loaded: url_helper
INFO - 2023-06-08 09:18:42 --> Helper loaded: form_helper
INFO - 2023-06-08 09:18:42 --> Database Driver Class Initialized
INFO - 2023-06-08 09:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:18:42 --> Form Validation Class Initialized
INFO - 2023-06-08 09:18:42 --> Controller Class Initialized
INFO - 2023-06-08 09:18:42 --> Model "m_user" initialized
INFO - 2023-06-08 09:18:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-08 09:18:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-08 09:18:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-08 09:18:42 --> Final output sent to browser
INFO - 2023-06-08 09:18:46 --> Config Class Initialized
INFO - 2023-06-08 09:18:46 --> Hooks Class Initialized
INFO - 2023-06-08 09:18:46 --> Utf8 Class Initialized
INFO - 2023-06-08 09:18:46 --> URI Class Initialized
INFO - 2023-06-08 09:18:46 --> Router Class Initialized
INFO - 2023-06-08 09:18:46 --> Output Class Initialized
INFO - 2023-06-08 09:18:46 --> Security Class Initialized
INFO - 2023-06-08 09:18:46 --> Input Class Initialized
INFO - 2023-06-08 09:18:46 --> Language Class Initialized
INFO - 2023-06-08 09:18:46 --> Loader Class Initialized
INFO - 2023-06-08 09:18:46 --> Helper loaded: url_helper
INFO - 2023-06-08 09:18:46 --> Helper loaded: form_helper
INFO - 2023-06-08 09:18:46 --> Database Driver Class Initialized
INFO - 2023-06-08 09:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:18:46 --> Form Validation Class Initialized
INFO - 2023-06-08 09:18:46 --> Controller Class Initialized
INFO - 2023-06-08 09:18:46 --> Model "m_user" initialized
INFO - 2023-06-08 09:18:47 --> Config Class Initialized
INFO - 2023-06-08 09:18:47 --> Hooks Class Initialized
INFO - 2023-06-08 09:18:47 --> Utf8 Class Initialized
INFO - 2023-06-08 09:18:47 --> URI Class Initialized
INFO - 2023-06-08 09:18:47 --> Router Class Initialized
INFO - 2023-06-08 09:18:47 --> Output Class Initialized
INFO - 2023-06-08 09:18:47 --> Security Class Initialized
INFO - 2023-06-08 09:18:47 --> Input Class Initialized
INFO - 2023-06-08 09:18:47 --> Language Class Initialized
INFO - 2023-06-08 09:18:47 --> Loader Class Initialized
INFO - 2023-06-08 09:18:47 --> Helper loaded: url_helper
INFO - 2023-06-08 09:18:47 --> Helper loaded: form_helper
INFO - 2023-06-08 09:18:47 --> Database Driver Class Initialized
INFO - 2023-06-08 09:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:18:47 --> Form Validation Class Initialized
INFO - 2023-06-08 09:18:47 --> Controller Class Initialized
INFO - 2023-06-08 09:18:47 --> Model "m_user" initialized
INFO - 2023-06-08 09:18:47 --> Model "m_datatrain" initialized
INFO - 2023-06-08 09:18:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 09:18:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 09:18:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 09:18:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 09:18:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 09:18:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-08 09:18:47 --> Final output sent to browser
INFO - 2023-06-08 09:19:07 --> Config Class Initialized
INFO - 2023-06-08 09:19:07 --> Hooks Class Initialized
INFO - 2023-06-08 09:19:07 --> Utf8 Class Initialized
INFO - 2023-06-08 09:19:07 --> URI Class Initialized
INFO - 2023-06-08 09:19:07 --> Router Class Initialized
INFO - 2023-06-08 09:19:07 --> Output Class Initialized
INFO - 2023-06-08 09:19:07 --> Security Class Initialized
INFO - 2023-06-08 09:19:07 --> Input Class Initialized
INFO - 2023-06-08 09:19:07 --> Language Class Initialized
INFO - 2023-06-08 09:19:07 --> Loader Class Initialized
INFO - 2023-06-08 09:19:07 --> Helper loaded: url_helper
INFO - 2023-06-08 09:19:07 --> Helper loaded: form_helper
INFO - 2023-06-08 09:19:07 --> Database Driver Class Initialized
INFO - 2023-06-08 09:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:19:07 --> Form Validation Class Initialized
INFO - 2023-06-08 09:19:07 --> Controller Class Initialized
INFO - 2023-06-08 09:19:07 --> Model "m_datatest" initialized
INFO - 2023-06-08 09:19:07 --> Final output sent to browser
INFO - 2023-06-08 09:19:31 --> Config Class Initialized
INFO - 2023-06-08 09:19:31 --> Hooks Class Initialized
INFO - 2023-06-08 09:19:31 --> Utf8 Class Initialized
INFO - 2023-06-08 09:19:31 --> URI Class Initialized
INFO - 2023-06-08 09:19:31 --> Router Class Initialized
INFO - 2023-06-08 09:19:31 --> Output Class Initialized
INFO - 2023-06-08 09:19:31 --> Security Class Initialized
INFO - 2023-06-08 09:19:31 --> Input Class Initialized
INFO - 2023-06-08 09:19:31 --> Language Class Initialized
INFO - 2023-06-08 09:19:31 --> Loader Class Initialized
INFO - 2023-06-08 09:19:31 --> Helper loaded: url_helper
INFO - 2023-06-08 09:19:31 --> Helper loaded: form_helper
INFO - 2023-06-08 09:19:31 --> Database Driver Class Initialized
INFO - 2023-06-08 09:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:19:31 --> Form Validation Class Initialized
INFO - 2023-06-08 09:19:31 --> Controller Class Initialized
INFO - 2023-06-08 09:19:31 --> Model "m_datatest" initialized
INFO - 2023-06-08 09:19:31 --> Final output sent to browser
INFO - 2023-06-08 09:19:48 --> Config Class Initialized
INFO - 2023-06-08 09:19:48 --> Hooks Class Initialized
INFO - 2023-06-08 09:19:48 --> Utf8 Class Initialized
INFO - 2023-06-08 09:19:48 --> URI Class Initialized
INFO - 2023-06-08 09:19:48 --> Router Class Initialized
INFO - 2023-06-08 09:19:48 --> Output Class Initialized
INFO - 2023-06-08 09:19:48 --> Security Class Initialized
INFO - 2023-06-08 09:19:48 --> Input Class Initialized
INFO - 2023-06-08 09:19:48 --> Language Class Initialized
INFO - 2023-06-08 09:19:48 --> Loader Class Initialized
INFO - 2023-06-08 09:19:48 --> Helper loaded: url_helper
INFO - 2023-06-08 09:19:48 --> Helper loaded: form_helper
INFO - 2023-06-08 09:19:48 --> Database Driver Class Initialized
INFO - 2023-06-08 09:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:19:48 --> Form Validation Class Initialized
INFO - 2023-06-08 09:19:48 --> Controller Class Initialized
INFO - 2023-06-08 09:19:48 --> Model "m_datatest" initialized
INFO - 2023-06-08 09:19:48 --> Final output sent to browser
INFO - 2023-06-08 09:20:54 --> Config Class Initialized
INFO - 2023-06-08 09:20:54 --> Hooks Class Initialized
INFO - 2023-06-08 09:20:54 --> Utf8 Class Initialized
INFO - 2023-06-08 09:20:54 --> URI Class Initialized
INFO - 2023-06-08 09:20:54 --> Router Class Initialized
INFO - 2023-06-08 09:20:54 --> Output Class Initialized
INFO - 2023-06-08 09:20:54 --> Security Class Initialized
INFO - 2023-06-08 09:20:54 --> Input Class Initialized
INFO - 2023-06-08 09:20:54 --> Language Class Initialized
INFO - 2023-06-08 09:20:54 --> Loader Class Initialized
INFO - 2023-06-08 09:20:54 --> Helper loaded: url_helper
INFO - 2023-06-08 09:20:54 --> Helper loaded: form_helper
INFO - 2023-06-08 09:20:54 --> Database Driver Class Initialized
INFO - 2023-06-08 09:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:20:54 --> Form Validation Class Initialized
INFO - 2023-06-08 09:20:54 --> Controller Class Initialized
INFO - 2023-06-08 09:20:54 --> Model "m_datatest" initialized
INFO - 2023-06-08 09:20:54 --> Final output sent to browser
INFO - 2023-06-08 09:23:26 --> Config Class Initialized
INFO - 2023-06-08 09:23:26 --> Hooks Class Initialized
INFO - 2023-06-08 09:23:26 --> Utf8 Class Initialized
INFO - 2023-06-08 09:23:26 --> URI Class Initialized
INFO - 2023-06-08 09:23:26 --> Router Class Initialized
INFO - 2023-06-08 09:23:26 --> Output Class Initialized
INFO - 2023-06-08 09:23:26 --> Security Class Initialized
INFO - 2023-06-08 09:23:26 --> Input Class Initialized
INFO - 2023-06-08 09:23:26 --> Language Class Initialized
INFO - 2023-06-08 09:23:26 --> Loader Class Initialized
INFO - 2023-06-08 09:23:26 --> Helper loaded: url_helper
INFO - 2023-06-08 09:23:26 --> Helper loaded: form_helper
INFO - 2023-06-08 09:23:26 --> Database Driver Class Initialized
INFO - 2023-06-08 09:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:23:26 --> Form Validation Class Initialized
INFO - 2023-06-08 09:23:26 --> Controller Class Initialized
INFO - 2023-06-08 09:23:26 --> Model "m_datatest" initialized
INFO - 2023-06-08 09:23:26 --> Final output sent to browser
INFO - 2023-06-08 09:23:47 --> Config Class Initialized
INFO - 2023-06-08 09:23:47 --> Hooks Class Initialized
INFO - 2023-06-08 09:23:47 --> Utf8 Class Initialized
INFO - 2023-06-08 09:23:47 --> URI Class Initialized
INFO - 2023-06-08 09:23:47 --> Router Class Initialized
INFO - 2023-06-08 09:23:47 --> Output Class Initialized
INFO - 2023-06-08 09:23:47 --> Security Class Initialized
INFO - 2023-06-08 09:23:47 --> Input Class Initialized
INFO - 2023-06-08 09:23:47 --> Language Class Initialized
INFO - 2023-06-08 09:23:47 --> Loader Class Initialized
INFO - 2023-06-08 09:23:47 --> Helper loaded: url_helper
INFO - 2023-06-08 09:23:47 --> Helper loaded: form_helper
INFO - 2023-06-08 09:23:47 --> Database Driver Class Initialized
INFO - 2023-06-08 09:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:23:47 --> Form Validation Class Initialized
INFO - 2023-06-08 09:23:47 --> Controller Class Initialized
INFO - 2023-06-08 09:23:47 --> Model "m_datatest" initialized
INFO - 2023-06-08 09:23:47 --> Final output sent to browser
INFO - 2023-06-08 09:28:25 --> Config Class Initialized
INFO - 2023-06-08 09:28:25 --> Hooks Class Initialized
INFO - 2023-06-08 09:28:25 --> Utf8 Class Initialized
INFO - 2023-06-08 09:28:25 --> URI Class Initialized
INFO - 2023-06-08 09:28:25 --> Router Class Initialized
INFO - 2023-06-08 09:28:25 --> Output Class Initialized
INFO - 2023-06-08 09:28:25 --> Security Class Initialized
INFO - 2023-06-08 09:28:25 --> Input Class Initialized
INFO - 2023-06-08 09:28:25 --> Language Class Initialized
INFO - 2023-06-08 09:28:25 --> Loader Class Initialized
INFO - 2023-06-08 09:28:25 --> Helper loaded: url_helper
INFO - 2023-06-08 09:28:25 --> Helper loaded: form_helper
INFO - 2023-06-08 09:28:25 --> Database Driver Class Initialized
INFO - 2023-06-08 09:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 09:28:25 --> Form Validation Class Initialized
INFO - 2023-06-08 09:28:25 --> Controller Class Initialized
INFO - 2023-06-08 09:28:25 --> Model "m_datatest" initialized
INFO - 2023-06-08 09:28:25 --> Final output sent to browser
INFO - 2023-06-08 12:13:25 --> Config Class Initialized
INFO - 2023-06-08 12:13:25 --> Hooks Class Initialized
INFO - 2023-06-08 12:13:25 --> Utf8 Class Initialized
INFO - 2023-06-08 12:13:25 --> URI Class Initialized
INFO - 2023-06-08 12:13:25 --> Router Class Initialized
INFO - 2023-06-08 12:13:25 --> Output Class Initialized
INFO - 2023-06-08 12:13:25 --> Security Class Initialized
INFO - 2023-06-08 12:13:25 --> Input Class Initialized
INFO - 2023-06-08 12:13:25 --> Language Class Initialized
INFO - 2023-06-08 12:13:25 --> Loader Class Initialized
INFO - 2023-06-08 12:13:25 --> Helper loaded: url_helper
INFO - 2023-06-08 12:13:25 --> Helper loaded: form_helper
INFO - 2023-06-08 12:13:25 --> Database Driver Class Initialized
INFO - 2023-06-08 12:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:13:25 --> Form Validation Class Initialized
INFO - 2023-06-08 12:13:25 --> Controller Class Initialized
INFO - 2023-06-08 12:13:25 --> Model "m_datatest" initialized
INFO - 2023-06-08 12:13:25 --> Final output sent to browser
INFO - 2023-06-08 12:17:34 --> Config Class Initialized
INFO - 2023-06-08 12:17:34 --> Hooks Class Initialized
INFO - 2023-06-08 12:17:34 --> Utf8 Class Initialized
INFO - 2023-06-08 12:17:34 --> URI Class Initialized
INFO - 2023-06-08 12:17:34 --> Router Class Initialized
INFO - 2023-06-08 12:17:34 --> Output Class Initialized
INFO - 2023-06-08 12:17:34 --> Security Class Initialized
INFO - 2023-06-08 12:17:34 --> Input Class Initialized
INFO - 2023-06-08 12:17:34 --> Language Class Initialized
INFO - 2023-06-08 12:17:34 --> Loader Class Initialized
INFO - 2023-06-08 12:17:34 --> Helper loaded: url_helper
INFO - 2023-06-08 12:17:34 --> Helper loaded: form_helper
INFO - 2023-06-08 12:17:34 --> Database Driver Class Initialized
INFO - 2023-06-08 12:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:17:34 --> Form Validation Class Initialized
INFO - 2023-06-08 12:17:34 --> Controller Class Initialized
INFO - 2023-06-08 12:17:34 --> Model "m_datatest" initialized
INFO - 2023-06-08 12:17:34 --> Final output sent to browser
INFO - 2023-06-08 12:18:45 --> Config Class Initialized
INFO - 2023-06-08 12:18:45 --> Hooks Class Initialized
INFO - 2023-06-08 12:18:45 --> Utf8 Class Initialized
INFO - 2023-06-08 12:18:45 --> URI Class Initialized
INFO - 2023-06-08 12:18:45 --> Router Class Initialized
INFO - 2023-06-08 12:18:45 --> Output Class Initialized
INFO - 2023-06-08 12:18:45 --> Security Class Initialized
INFO - 2023-06-08 12:18:45 --> Input Class Initialized
INFO - 2023-06-08 12:18:45 --> Language Class Initialized
INFO - 2023-06-08 12:18:45 --> Loader Class Initialized
INFO - 2023-06-08 12:18:45 --> Helper loaded: url_helper
INFO - 2023-06-08 12:18:45 --> Helper loaded: form_helper
INFO - 2023-06-08 12:18:45 --> Database Driver Class Initialized
INFO - 2023-06-08 12:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:18:45 --> Form Validation Class Initialized
INFO - 2023-06-08 12:18:45 --> Controller Class Initialized
INFO - 2023-06-08 12:18:45 --> Model "m_datatest" initialized
ERROR - 2023-06-08 12:18:45 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 71
INFO - 2023-06-08 12:19:18 --> Config Class Initialized
INFO - 2023-06-08 12:19:18 --> Hooks Class Initialized
INFO - 2023-06-08 12:19:18 --> Utf8 Class Initialized
INFO - 2023-06-08 12:19:18 --> URI Class Initialized
INFO - 2023-06-08 12:19:18 --> Router Class Initialized
INFO - 2023-06-08 12:19:18 --> Output Class Initialized
INFO - 2023-06-08 12:19:18 --> Security Class Initialized
INFO - 2023-06-08 12:19:18 --> Input Class Initialized
INFO - 2023-06-08 12:19:18 --> Language Class Initialized
INFO - 2023-06-08 12:19:18 --> Loader Class Initialized
INFO - 2023-06-08 12:19:18 --> Helper loaded: url_helper
INFO - 2023-06-08 12:19:18 --> Helper loaded: form_helper
INFO - 2023-06-08 12:19:18 --> Database Driver Class Initialized
INFO - 2023-06-08 12:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:19:18 --> Form Validation Class Initialized
INFO - 2023-06-08 12:19:18 --> Controller Class Initialized
INFO - 2023-06-08 12:19:18 --> Model "m_datatest" initialized
INFO - 2023-06-08 12:19:18 --> Final output sent to browser
INFO - 2023-06-08 12:20:33 --> Config Class Initialized
INFO - 2023-06-08 12:20:33 --> Hooks Class Initialized
INFO - 2023-06-08 12:20:33 --> Utf8 Class Initialized
INFO - 2023-06-08 12:20:33 --> URI Class Initialized
INFO - 2023-06-08 12:20:33 --> Router Class Initialized
INFO - 2023-06-08 12:20:33 --> Output Class Initialized
INFO - 2023-06-08 12:20:33 --> Security Class Initialized
INFO - 2023-06-08 12:20:33 --> Input Class Initialized
INFO - 2023-06-08 12:20:33 --> Language Class Initialized
INFO - 2023-06-08 12:20:33 --> Loader Class Initialized
INFO - 2023-06-08 12:20:33 --> Helper loaded: url_helper
INFO - 2023-06-08 12:20:33 --> Helper loaded: form_helper
INFO - 2023-06-08 12:20:33 --> Database Driver Class Initialized
INFO - 2023-06-08 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:20:33 --> Form Validation Class Initialized
INFO - 2023-06-08 12:20:33 --> Controller Class Initialized
INFO - 2023-06-08 12:20:33 --> Model "m_datatest" initialized
INFO - 2023-06-08 12:20:33 --> Final output sent to browser
INFO - 2023-06-08 12:23:54 --> Config Class Initialized
INFO - 2023-06-08 12:23:54 --> Hooks Class Initialized
INFO - 2023-06-08 12:23:54 --> Utf8 Class Initialized
INFO - 2023-06-08 12:23:54 --> URI Class Initialized
INFO - 2023-06-08 12:23:54 --> Router Class Initialized
INFO - 2023-06-08 12:23:54 --> Output Class Initialized
INFO - 2023-06-08 12:23:54 --> Security Class Initialized
INFO - 2023-06-08 12:23:54 --> Input Class Initialized
INFO - 2023-06-08 12:23:54 --> Language Class Initialized
INFO - 2023-06-08 12:23:54 --> Loader Class Initialized
INFO - 2023-06-08 12:23:54 --> Helper loaded: url_helper
INFO - 2023-06-08 12:23:54 --> Helper loaded: form_helper
INFO - 2023-06-08 12:23:54 --> Database Driver Class Initialized
INFO - 2023-06-08 12:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:23:54 --> Form Validation Class Initialized
INFO - 2023-06-08 12:23:54 --> Controller Class Initialized
INFO - 2023-06-08 12:23:54 --> Model "m_datatest" initialized
INFO - 2023-06-08 12:23:54 --> Final output sent to browser
INFO - 2023-06-08 12:24:35 --> Config Class Initialized
INFO - 2023-06-08 12:24:35 --> Hooks Class Initialized
INFO - 2023-06-08 12:24:35 --> Utf8 Class Initialized
INFO - 2023-06-08 12:24:35 --> URI Class Initialized
INFO - 2023-06-08 12:24:35 --> Router Class Initialized
INFO - 2023-06-08 12:24:35 --> Output Class Initialized
INFO - 2023-06-08 12:24:35 --> Security Class Initialized
INFO - 2023-06-08 12:24:35 --> Input Class Initialized
INFO - 2023-06-08 12:24:35 --> Language Class Initialized
INFO - 2023-06-08 12:24:35 --> Loader Class Initialized
INFO - 2023-06-08 12:24:35 --> Helper loaded: url_helper
INFO - 2023-06-08 12:24:35 --> Helper loaded: form_helper
INFO - 2023-06-08 12:24:35 --> Database Driver Class Initialized
INFO - 2023-06-08 12:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:24:35 --> Form Validation Class Initialized
INFO - 2023-06-08 12:24:35 --> Controller Class Initialized
INFO - 2023-06-08 12:24:35 --> Model "m_datatest" initialized
ERROR - 2023-06-08 12:24:35 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 81
INFO - 2023-06-08 12:24:43 --> Config Class Initialized
INFO - 2023-06-08 12:24:43 --> Hooks Class Initialized
INFO - 2023-06-08 12:24:43 --> Utf8 Class Initialized
INFO - 2023-06-08 12:24:43 --> URI Class Initialized
INFO - 2023-06-08 12:24:43 --> Router Class Initialized
INFO - 2023-06-08 12:24:43 --> Output Class Initialized
INFO - 2023-06-08 12:24:43 --> Security Class Initialized
INFO - 2023-06-08 12:24:43 --> Input Class Initialized
INFO - 2023-06-08 12:24:43 --> Language Class Initialized
INFO - 2023-06-08 12:24:43 --> Loader Class Initialized
INFO - 2023-06-08 12:24:43 --> Helper loaded: url_helper
INFO - 2023-06-08 12:24:43 --> Helper loaded: form_helper
INFO - 2023-06-08 12:24:43 --> Database Driver Class Initialized
INFO - 2023-06-08 12:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:24:43 --> Form Validation Class Initialized
INFO - 2023-06-08 12:24:43 --> Controller Class Initialized
INFO - 2023-06-08 12:24:43 --> Model "m_datatest" initialized
INFO - 2023-06-08 12:24:43 --> Final output sent to browser
INFO - 2023-06-08 12:25:05 --> Config Class Initialized
INFO - 2023-06-08 12:25:05 --> Hooks Class Initialized
INFO - 2023-06-08 12:25:05 --> Utf8 Class Initialized
INFO - 2023-06-08 12:25:05 --> URI Class Initialized
INFO - 2023-06-08 12:25:05 --> Router Class Initialized
INFO - 2023-06-08 12:25:05 --> Output Class Initialized
INFO - 2023-06-08 12:25:05 --> Security Class Initialized
INFO - 2023-06-08 12:25:05 --> Input Class Initialized
INFO - 2023-06-08 12:25:05 --> Language Class Initialized
INFO - 2023-06-08 12:25:05 --> Loader Class Initialized
INFO - 2023-06-08 12:25:05 --> Helper loaded: url_helper
INFO - 2023-06-08 12:25:05 --> Helper loaded: form_helper
INFO - 2023-06-08 12:25:05 --> Database Driver Class Initialized
INFO - 2023-06-08 12:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:25:05 --> Form Validation Class Initialized
INFO - 2023-06-08 12:25:05 --> Controller Class Initialized
INFO - 2023-06-08 12:25:05 --> Model "m_datatest" initialized
ERROR - 2023-06-08 12:25:05 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 81
INFO - 2023-06-08 12:25:29 --> Config Class Initialized
INFO - 2023-06-08 12:25:29 --> Hooks Class Initialized
INFO - 2023-06-08 12:25:29 --> Utf8 Class Initialized
INFO - 2023-06-08 12:25:29 --> URI Class Initialized
INFO - 2023-06-08 12:25:29 --> Router Class Initialized
INFO - 2023-06-08 12:25:29 --> Output Class Initialized
INFO - 2023-06-08 12:25:29 --> Security Class Initialized
INFO - 2023-06-08 12:25:29 --> Input Class Initialized
INFO - 2023-06-08 12:25:29 --> Language Class Initialized
INFO - 2023-06-08 12:25:29 --> Loader Class Initialized
INFO - 2023-06-08 12:25:29 --> Helper loaded: url_helper
INFO - 2023-06-08 12:25:29 --> Helper loaded: form_helper
INFO - 2023-06-08 12:25:29 --> Database Driver Class Initialized
INFO - 2023-06-08 12:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:25:29 --> Form Validation Class Initialized
INFO - 2023-06-08 12:25:29 --> Controller Class Initialized
INFO - 2023-06-08 12:25:29 --> Model "m_datatest" initialized
INFO - 2023-06-08 12:25:29 --> Final output sent to browser
INFO - 2023-06-08 12:25:32 --> Config Class Initialized
INFO - 2023-06-08 12:25:32 --> Hooks Class Initialized
INFO - 2023-06-08 12:25:32 --> Utf8 Class Initialized
INFO - 2023-06-08 12:25:32 --> URI Class Initialized
INFO - 2023-06-08 12:25:32 --> Router Class Initialized
INFO - 2023-06-08 12:25:32 --> Output Class Initialized
INFO - 2023-06-08 12:25:32 --> Security Class Initialized
INFO - 2023-06-08 12:25:32 --> Input Class Initialized
INFO - 2023-06-08 12:25:32 --> Language Class Initialized
INFO - 2023-06-08 12:25:32 --> Loader Class Initialized
INFO - 2023-06-08 12:25:32 --> Helper loaded: url_helper
INFO - 2023-06-08 12:25:32 --> Helper loaded: form_helper
INFO - 2023-06-08 12:25:32 --> Database Driver Class Initialized
INFO - 2023-06-08 12:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:25:32 --> Form Validation Class Initialized
INFO - 2023-06-08 12:25:32 --> Controller Class Initialized
INFO - 2023-06-08 12:25:32 --> Model "m_datatest" initialized
INFO - 2023-06-08 12:25:32 --> Final output sent to browser
INFO - 2023-06-08 12:25:52 --> Config Class Initialized
INFO - 2023-06-08 12:25:52 --> Hooks Class Initialized
INFO - 2023-06-08 12:25:52 --> Utf8 Class Initialized
INFO - 2023-06-08 12:25:52 --> URI Class Initialized
INFO - 2023-06-08 12:25:52 --> Router Class Initialized
INFO - 2023-06-08 12:25:52 --> Output Class Initialized
INFO - 2023-06-08 12:25:52 --> Security Class Initialized
INFO - 2023-06-08 12:25:52 --> Input Class Initialized
INFO - 2023-06-08 12:25:52 --> Language Class Initialized
INFO - 2023-06-08 12:25:52 --> Loader Class Initialized
INFO - 2023-06-08 12:25:52 --> Helper loaded: url_helper
INFO - 2023-06-08 12:25:52 --> Helper loaded: form_helper
INFO - 2023-06-08 12:25:52 --> Database Driver Class Initialized
INFO - 2023-06-08 12:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:25:52 --> Form Validation Class Initialized
INFO - 2023-06-08 12:25:52 --> Controller Class Initialized
INFO - 2023-06-08 12:25:52 --> Model "m_datatest" initialized
INFO - 2023-06-08 12:25:52 --> Final output sent to browser
INFO - 2023-06-08 12:26:29 --> Config Class Initialized
INFO - 2023-06-08 12:26:29 --> Hooks Class Initialized
INFO - 2023-06-08 12:26:29 --> Utf8 Class Initialized
INFO - 2023-06-08 12:26:29 --> URI Class Initialized
INFO - 2023-06-08 12:26:29 --> Router Class Initialized
INFO - 2023-06-08 12:26:29 --> Output Class Initialized
INFO - 2023-06-08 12:26:29 --> Security Class Initialized
INFO - 2023-06-08 12:26:29 --> Input Class Initialized
INFO - 2023-06-08 12:26:29 --> Language Class Initialized
INFO - 2023-06-08 12:26:29 --> Loader Class Initialized
INFO - 2023-06-08 12:26:29 --> Helper loaded: url_helper
INFO - 2023-06-08 12:26:29 --> Helper loaded: form_helper
INFO - 2023-06-08 12:26:29 --> Database Driver Class Initialized
INFO - 2023-06-08 12:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:26:29 --> Form Validation Class Initialized
INFO - 2023-06-08 12:26:29 --> Controller Class Initialized
INFO - 2023-06-08 12:26:29 --> Model "m_datatest" initialized
INFO - 2023-06-08 12:26:29 --> Final output sent to browser
INFO - 2023-06-08 12:26:38 --> Config Class Initialized
INFO - 2023-06-08 12:26:38 --> Hooks Class Initialized
INFO - 2023-06-08 12:26:38 --> Utf8 Class Initialized
INFO - 2023-06-08 12:26:38 --> URI Class Initialized
INFO - 2023-06-08 12:26:38 --> Router Class Initialized
INFO - 2023-06-08 12:26:38 --> Output Class Initialized
INFO - 2023-06-08 12:26:38 --> Security Class Initialized
INFO - 2023-06-08 12:26:38 --> Input Class Initialized
INFO - 2023-06-08 12:26:38 --> Language Class Initialized
INFO - 2023-06-08 12:26:38 --> Loader Class Initialized
INFO - 2023-06-08 12:26:38 --> Helper loaded: url_helper
INFO - 2023-06-08 12:26:38 --> Helper loaded: form_helper
INFO - 2023-06-08 12:26:38 --> Database Driver Class Initialized
INFO - 2023-06-08 12:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 12:26:38 --> Form Validation Class Initialized
INFO - 2023-06-08 12:26:38 --> Controller Class Initialized
INFO - 2023-06-08 12:26:38 --> Model "m_datatest" initialized
INFO - 2023-06-08 12:26:38 --> Final output sent to browser
INFO - 2023-06-08 13:24:29 --> Config Class Initialized
INFO - 2023-06-08 13:24:29 --> Hooks Class Initialized
INFO - 2023-06-08 13:24:29 --> Utf8 Class Initialized
INFO - 2023-06-08 13:24:29 --> URI Class Initialized
INFO - 2023-06-08 13:24:29 --> Router Class Initialized
INFO - 2023-06-08 13:24:29 --> Output Class Initialized
INFO - 2023-06-08 13:24:29 --> Security Class Initialized
INFO - 2023-06-08 13:24:29 --> Input Class Initialized
INFO - 2023-06-08 13:24:29 --> Language Class Initialized
INFO - 2023-06-08 13:24:29 --> Loader Class Initialized
INFO - 2023-06-08 13:24:29 --> Helper loaded: url_helper
INFO - 2023-06-08 13:24:29 --> Helper loaded: form_helper
INFO - 2023-06-08 13:24:29 --> Database Driver Class Initialized
INFO - 2023-06-08 13:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 13:24:29 --> Form Validation Class Initialized
INFO - 2023-06-08 13:24:29 --> Controller Class Initialized
INFO - 2023-06-08 13:24:29 --> Model "m_datatrain" initialized
INFO - 2023-06-08 13:24:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-08 13:24:29 --> Model "m_datatest" initialized
INFO - 2023-06-08 13:24:29 --> Model "M_solusi" initialized
INFO - 2023-06-08 13:24:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 13:24:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 13:24:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-08 13:24:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 13:24:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 13:24:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 13:24:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 13:24:29 --> Final output sent to browser
INFO - 2023-06-08 13:29:09 --> Config Class Initialized
INFO - 2023-06-08 13:29:09 --> Hooks Class Initialized
INFO - 2023-06-08 13:29:09 --> Utf8 Class Initialized
INFO - 2023-06-08 13:29:09 --> URI Class Initialized
INFO - 2023-06-08 13:29:09 --> Router Class Initialized
INFO - 2023-06-08 13:29:09 --> Output Class Initialized
INFO - 2023-06-08 13:29:09 --> Security Class Initialized
INFO - 2023-06-08 13:29:09 --> Input Class Initialized
INFO - 2023-06-08 13:29:09 --> Language Class Initialized
INFO - 2023-06-08 13:29:09 --> Loader Class Initialized
INFO - 2023-06-08 13:29:10 --> Helper loaded: url_helper
INFO - 2023-06-08 13:29:10 --> Helper loaded: form_helper
INFO - 2023-06-08 13:29:10 --> Database Driver Class Initialized
INFO - 2023-06-08 13:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 13:29:10 --> Form Validation Class Initialized
INFO - 2023-06-08 13:29:10 --> Controller Class Initialized
INFO - 2023-06-08 13:29:10 --> Model "m_datatest" initialized
INFO - 2023-06-08 13:29:10 --> Final output sent to browser
INFO - 2023-06-08 19:36:32 --> Config Class Initialized
INFO - 2023-06-08 19:36:32 --> Hooks Class Initialized
INFO - 2023-06-08 19:36:32 --> Utf8 Class Initialized
INFO - 2023-06-08 19:36:32 --> URI Class Initialized
INFO - 2023-06-08 19:36:32 --> Router Class Initialized
INFO - 2023-06-08 19:36:32 --> Output Class Initialized
INFO - 2023-06-08 19:36:32 --> Security Class Initialized
INFO - 2023-06-08 19:36:32 --> Input Class Initialized
INFO - 2023-06-08 19:36:32 --> Language Class Initialized
INFO - 2023-06-08 19:36:32 --> Loader Class Initialized
INFO - 2023-06-08 19:36:33 --> Helper loaded: url_helper
INFO - 2023-06-08 19:36:33 --> Helper loaded: form_helper
INFO - 2023-06-08 19:36:33 --> Database Driver Class Initialized
INFO - 2023-06-08 19:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:36:33 --> Form Validation Class Initialized
INFO - 2023-06-08 19:36:33 --> Controller Class Initialized
INFO - 2023-06-08 19:36:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-08 19:36:33 --> Final output sent to browser
INFO - 2023-06-08 19:36:36 --> Config Class Initialized
INFO - 2023-06-08 19:36:36 --> Hooks Class Initialized
INFO - 2023-06-08 19:36:36 --> Utf8 Class Initialized
INFO - 2023-06-08 19:36:36 --> URI Class Initialized
INFO - 2023-06-08 19:36:36 --> Router Class Initialized
INFO - 2023-06-08 19:36:36 --> Output Class Initialized
INFO - 2023-06-08 19:36:36 --> Security Class Initialized
INFO - 2023-06-08 19:36:36 --> Input Class Initialized
INFO - 2023-06-08 19:36:36 --> Language Class Initialized
INFO - 2023-06-08 19:36:36 --> Loader Class Initialized
INFO - 2023-06-08 19:36:36 --> Helper loaded: url_helper
INFO - 2023-06-08 19:36:36 --> Helper loaded: form_helper
INFO - 2023-06-08 19:36:36 --> Database Driver Class Initialized
INFO - 2023-06-08 19:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:36:36 --> Form Validation Class Initialized
INFO - 2023-06-08 19:36:36 --> Controller Class Initialized
INFO - 2023-06-08 19:36:37 --> Model "m_user" initialized
INFO - 2023-06-08 19:36:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-08 19:36:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-08 19:36:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-08 19:36:37 --> Final output sent to browser
INFO - 2023-06-08 19:36:40 --> Config Class Initialized
INFO - 2023-06-08 19:36:40 --> Hooks Class Initialized
INFO - 2023-06-08 19:36:40 --> Utf8 Class Initialized
INFO - 2023-06-08 19:36:40 --> URI Class Initialized
INFO - 2023-06-08 19:36:40 --> Router Class Initialized
INFO - 2023-06-08 19:36:40 --> Output Class Initialized
INFO - 2023-06-08 19:36:40 --> Security Class Initialized
INFO - 2023-06-08 19:36:40 --> Input Class Initialized
INFO - 2023-06-08 19:36:40 --> Language Class Initialized
INFO - 2023-06-08 19:36:40 --> Loader Class Initialized
INFO - 2023-06-08 19:36:40 --> Helper loaded: url_helper
INFO - 2023-06-08 19:36:40 --> Helper loaded: form_helper
INFO - 2023-06-08 19:36:40 --> Database Driver Class Initialized
INFO - 2023-06-08 19:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:36:40 --> Form Validation Class Initialized
INFO - 2023-06-08 19:36:40 --> Controller Class Initialized
INFO - 2023-06-08 19:36:40 --> Model "m_user" initialized
INFO - 2023-06-08 19:36:40 --> Config Class Initialized
INFO - 2023-06-08 19:36:40 --> Hooks Class Initialized
INFO - 2023-06-08 19:36:40 --> Utf8 Class Initialized
INFO - 2023-06-08 19:36:40 --> URI Class Initialized
INFO - 2023-06-08 19:36:40 --> Router Class Initialized
INFO - 2023-06-08 19:36:40 --> Output Class Initialized
INFO - 2023-06-08 19:36:40 --> Security Class Initialized
INFO - 2023-06-08 19:36:40 --> Input Class Initialized
INFO - 2023-06-08 19:36:40 --> Language Class Initialized
INFO - 2023-06-08 19:36:40 --> Loader Class Initialized
INFO - 2023-06-08 19:36:40 --> Helper loaded: url_helper
INFO - 2023-06-08 19:36:40 --> Helper loaded: form_helper
INFO - 2023-06-08 19:36:40 --> Database Driver Class Initialized
INFO - 2023-06-08 19:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:36:40 --> Form Validation Class Initialized
INFO - 2023-06-08 19:36:40 --> Controller Class Initialized
INFO - 2023-06-08 19:36:40 --> Model "m_user" initialized
INFO - 2023-06-08 19:36:40 --> Model "m_datatrain" initialized
INFO - 2023-06-08 19:36:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 19:36:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 19:36:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 19:36:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 19:36:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 19:36:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-08 19:36:41 --> Final output sent to browser
INFO - 2023-06-08 19:36:45 --> Config Class Initialized
INFO - 2023-06-08 19:36:45 --> Hooks Class Initialized
INFO - 2023-06-08 19:36:45 --> Utf8 Class Initialized
INFO - 2023-06-08 19:36:45 --> URI Class Initialized
INFO - 2023-06-08 19:36:45 --> Router Class Initialized
INFO - 2023-06-08 19:36:45 --> Output Class Initialized
INFO - 2023-06-08 19:36:45 --> Security Class Initialized
INFO - 2023-06-08 19:36:45 --> Input Class Initialized
INFO - 2023-06-08 19:36:45 --> Language Class Initialized
INFO - 2023-06-08 19:36:45 --> Loader Class Initialized
INFO - 2023-06-08 19:36:45 --> Helper loaded: url_helper
INFO - 2023-06-08 19:36:45 --> Helper loaded: form_helper
INFO - 2023-06-08 19:36:45 --> Database Driver Class Initialized
INFO - 2023-06-08 19:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:36:45 --> Form Validation Class Initialized
INFO - 2023-06-08 19:36:45 --> Controller Class Initialized
INFO - 2023-06-08 19:36:45 --> Model "m_user" initialized
INFO - 2023-06-08 19:36:45 --> Config Class Initialized
INFO - 2023-06-08 19:36:45 --> Hooks Class Initialized
INFO - 2023-06-08 19:36:45 --> Utf8 Class Initialized
INFO - 2023-06-08 19:36:45 --> URI Class Initialized
INFO - 2023-06-08 19:36:45 --> Router Class Initialized
INFO - 2023-06-08 19:36:45 --> Output Class Initialized
INFO - 2023-06-08 19:36:45 --> Security Class Initialized
INFO - 2023-06-08 19:36:45 --> Input Class Initialized
INFO - 2023-06-08 19:36:45 --> Language Class Initialized
INFO - 2023-06-08 19:36:45 --> Loader Class Initialized
INFO - 2023-06-08 19:36:45 --> Helper loaded: url_helper
INFO - 2023-06-08 19:36:45 --> Helper loaded: form_helper
INFO - 2023-06-08 19:36:45 --> Database Driver Class Initialized
INFO - 2023-06-08 19:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:36:45 --> Form Validation Class Initialized
INFO - 2023-06-08 19:36:45 --> Controller Class Initialized
INFO - 2023-06-08 19:36:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-08 19:36:45 --> Final output sent to browser
INFO - 2023-06-08 19:36:47 --> Config Class Initialized
INFO - 2023-06-08 19:36:47 --> Hooks Class Initialized
INFO - 2023-06-08 19:36:47 --> Utf8 Class Initialized
INFO - 2023-06-08 19:36:47 --> URI Class Initialized
INFO - 2023-06-08 19:36:47 --> Router Class Initialized
INFO - 2023-06-08 19:36:47 --> Output Class Initialized
INFO - 2023-06-08 19:36:47 --> Security Class Initialized
INFO - 2023-06-08 19:36:47 --> Input Class Initialized
INFO - 2023-06-08 19:36:47 --> Language Class Initialized
INFO - 2023-06-08 19:36:47 --> Loader Class Initialized
INFO - 2023-06-08 19:36:47 --> Helper loaded: url_helper
INFO - 2023-06-08 19:36:47 --> Helper loaded: form_helper
INFO - 2023-06-08 19:36:47 --> Database Driver Class Initialized
INFO - 2023-06-08 19:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:36:47 --> Form Validation Class Initialized
INFO - 2023-06-08 19:36:47 --> Controller Class Initialized
INFO - 2023-06-08 19:36:47 --> Model "m_user" initialized
INFO - 2023-06-08 19:36:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 19:36:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 19:36:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 19:36:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 19:36:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 19:36:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-08 19:36:47 --> Final output sent to browser
INFO - 2023-06-08 19:36:55 --> Config Class Initialized
INFO - 2023-06-08 19:36:55 --> Hooks Class Initialized
INFO - 2023-06-08 19:36:55 --> Utf8 Class Initialized
INFO - 2023-06-08 19:36:55 --> URI Class Initialized
INFO - 2023-06-08 19:36:55 --> Router Class Initialized
INFO - 2023-06-08 19:36:55 --> Output Class Initialized
INFO - 2023-06-08 19:36:55 --> Security Class Initialized
INFO - 2023-06-08 19:36:55 --> Input Class Initialized
INFO - 2023-06-08 19:36:55 --> Language Class Initialized
INFO - 2023-06-08 19:36:55 --> Loader Class Initialized
INFO - 2023-06-08 19:36:55 --> Helper loaded: url_helper
INFO - 2023-06-08 19:36:55 --> Helper loaded: form_helper
INFO - 2023-06-08 19:36:55 --> Database Driver Class Initialized
INFO - 2023-06-08 19:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:36:55 --> Form Validation Class Initialized
INFO - 2023-06-08 19:36:55 --> Controller Class Initialized
INFO - 2023-06-08 19:36:55 --> Model "m_datatest" initialized
INFO - 2023-06-08 19:36:55 --> Final output sent to browser
INFO - 2023-06-08 19:37:04 --> Config Class Initialized
INFO - 2023-06-08 19:37:04 --> Hooks Class Initialized
INFO - 2023-06-08 19:37:04 --> Utf8 Class Initialized
INFO - 2023-06-08 19:37:04 --> URI Class Initialized
INFO - 2023-06-08 19:37:04 --> Router Class Initialized
INFO - 2023-06-08 19:37:04 --> Output Class Initialized
INFO - 2023-06-08 19:37:04 --> Security Class Initialized
INFO - 2023-06-08 19:37:04 --> Input Class Initialized
INFO - 2023-06-08 19:37:04 --> Language Class Initialized
INFO - 2023-06-08 19:37:04 --> Loader Class Initialized
INFO - 2023-06-08 19:37:04 --> Helper loaded: url_helper
INFO - 2023-06-08 19:37:04 --> Helper loaded: form_helper
INFO - 2023-06-08 19:37:04 --> Database Driver Class Initialized
INFO - 2023-06-08 19:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:37:04 --> Form Validation Class Initialized
INFO - 2023-06-08 19:37:04 --> Controller Class Initialized
INFO - 2023-06-08 19:37:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-08 19:37:04 --> Final output sent to browser
INFO - 2023-06-08 19:37:06 --> Config Class Initialized
INFO - 2023-06-08 19:37:06 --> Hooks Class Initialized
INFO - 2023-06-08 19:37:06 --> Utf8 Class Initialized
INFO - 2023-06-08 19:37:06 --> URI Class Initialized
INFO - 2023-06-08 19:37:06 --> Router Class Initialized
INFO - 2023-06-08 19:37:06 --> Output Class Initialized
INFO - 2023-06-08 19:37:06 --> Security Class Initialized
INFO - 2023-06-08 19:37:06 --> Input Class Initialized
INFO - 2023-06-08 19:37:06 --> Language Class Initialized
INFO - 2023-06-08 19:37:06 --> Loader Class Initialized
INFO - 2023-06-08 19:37:06 --> Helper loaded: url_helper
INFO - 2023-06-08 19:37:06 --> Helper loaded: form_helper
INFO - 2023-06-08 19:37:06 --> Database Driver Class Initialized
INFO - 2023-06-08 19:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:37:06 --> Form Validation Class Initialized
INFO - 2023-06-08 19:37:06 --> Controller Class Initialized
INFO - 2023-06-08 19:37:06 --> Model "m_datatest" initialized
INFO - 2023-06-08 19:37:06 --> Final output sent to browser
INFO - 2023-06-08 19:37:16 --> Config Class Initialized
INFO - 2023-06-08 19:37:16 --> Hooks Class Initialized
INFO - 2023-06-08 19:37:16 --> Utf8 Class Initialized
INFO - 2023-06-08 19:37:16 --> URI Class Initialized
INFO - 2023-06-08 19:37:16 --> Router Class Initialized
INFO - 2023-06-08 19:37:16 --> Output Class Initialized
INFO - 2023-06-08 19:37:16 --> Security Class Initialized
INFO - 2023-06-08 19:37:16 --> Input Class Initialized
INFO - 2023-06-08 19:37:16 --> Language Class Initialized
INFO - 2023-06-08 19:37:16 --> Loader Class Initialized
INFO - 2023-06-08 19:37:16 --> Helper loaded: url_helper
INFO - 2023-06-08 19:37:16 --> Helper loaded: form_helper
INFO - 2023-06-08 19:37:16 --> Database Driver Class Initialized
INFO - 2023-06-08 19:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:37:16 --> Form Validation Class Initialized
INFO - 2023-06-08 19:37:16 --> Controller Class Initialized
INFO - 2023-06-08 19:37:16 --> Model "m_datatest" initialized
INFO - 2023-06-08 19:37:16 --> Final output sent to browser
INFO - 2023-06-08 19:37:35 --> Config Class Initialized
INFO - 2023-06-08 19:37:35 --> Hooks Class Initialized
INFO - 2023-06-08 19:37:35 --> Utf8 Class Initialized
INFO - 2023-06-08 19:37:35 --> URI Class Initialized
INFO - 2023-06-08 19:37:35 --> Router Class Initialized
INFO - 2023-06-08 19:37:35 --> Output Class Initialized
INFO - 2023-06-08 19:37:35 --> Security Class Initialized
INFO - 2023-06-08 19:37:35 --> Input Class Initialized
INFO - 2023-06-08 19:37:35 --> Language Class Initialized
INFO - 2023-06-08 19:37:35 --> Loader Class Initialized
INFO - 2023-06-08 19:37:35 --> Helper loaded: url_helper
INFO - 2023-06-08 19:37:35 --> Helper loaded: form_helper
INFO - 2023-06-08 19:37:35 --> Database Driver Class Initialized
INFO - 2023-06-08 19:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:37:35 --> Form Validation Class Initialized
INFO - 2023-06-08 19:37:35 --> Controller Class Initialized
INFO - 2023-06-08 19:37:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-08 19:37:35 --> Final output sent to browser
INFO - 2023-06-08 19:37:37 --> Config Class Initialized
INFO - 2023-06-08 19:37:37 --> Hooks Class Initialized
INFO - 2023-06-08 19:37:37 --> Utf8 Class Initialized
INFO - 2023-06-08 19:37:37 --> URI Class Initialized
INFO - 2023-06-08 19:37:37 --> Router Class Initialized
INFO - 2023-06-08 19:37:37 --> Output Class Initialized
INFO - 2023-06-08 19:37:37 --> Security Class Initialized
INFO - 2023-06-08 19:37:37 --> Input Class Initialized
INFO - 2023-06-08 19:37:37 --> Language Class Initialized
INFO - 2023-06-08 19:37:37 --> Loader Class Initialized
INFO - 2023-06-08 19:37:37 --> Helper loaded: url_helper
INFO - 2023-06-08 19:37:37 --> Helper loaded: form_helper
INFO - 2023-06-08 19:37:37 --> Database Driver Class Initialized
INFO - 2023-06-08 19:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:37:37 --> Form Validation Class Initialized
INFO - 2023-06-08 19:37:37 --> Controller Class Initialized
INFO - 2023-06-08 19:37:37 --> Model "m_user" initialized
INFO - 2023-06-08 19:37:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-08 19:37:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-08 19:37:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-08 19:37:37 --> Final output sent to browser
INFO - 2023-06-08 19:37:41 --> Config Class Initialized
INFO - 2023-06-08 19:37:41 --> Hooks Class Initialized
INFO - 2023-06-08 19:37:41 --> Utf8 Class Initialized
INFO - 2023-06-08 19:37:41 --> URI Class Initialized
INFO - 2023-06-08 19:37:41 --> Router Class Initialized
INFO - 2023-06-08 19:37:41 --> Output Class Initialized
INFO - 2023-06-08 19:37:41 --> Security Class Initialized
INFO - 2023-06-08 19:37:41 --> Input Class Initialized
INFO - 2023-06-08 19:37:41 --> Language Class Initialized
INFO - 2023-06-08 19:37:41 --> Loader Class Initialized
INFO - 2023-06-08 19:37:41 --> Helper loaded: url_helper
INFO - 2023-06-08 19:37:41 --> Helper loaded: form_helper
INFO - 2023-06-08 19:37:41 --> Database Driver Class Initialized
INFO - 2023-06-08 19:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:37:41 --> Form Validation Class Initialized
INFO - 2023-06-08 19:37:41 --> Controller Class Initialized
INFO - 2023-06-08 19:37:41 --> Model "m_user" initialized
INFO - 2023-06-08 19:37:41 --> Config Class Initialized
INFO - 2023-06-08 19:37:41 --> Hooks Class Initialized
INFO - 2023-06-08 19:37:41 --> Utf8 Class Initialized
INFO - 2023-06-08 19:37:41 --> URI Class Initialized
INFO - 2023-06-08 19:37:41 --> Router Class Initialized
INFO - 2023-06-08 19:37:41 --> Output Class Initialized
INFO - 2023-06-08 19:37:41 --> Security Class Initialized
INFO - 2023-06-08 19:37:41 --> Input Class Initialized
INFO - 2023-06-08 19:37:41 --> Language Class Initialized
INFO - 2023-06-08 19:37:41 --> Loader Class Initialized
INFO - 2023-06-08 19:37:41 --> Helper loaded: url_helper
INFO - 2023-06-08 19:37:41 --> Helper loaded: form_helper
INFO - 2023-06-08 19:37:41 --> Database Driver Class Initialized
INFO - 2023-06-08 19:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:37:41 --> Form Validation Class Initialized
INFO - 2023-06-08 19:37:41 --> Controller Class Initialized
INFO - 2023-06-08 19:37:41 --> Model "m_user" initialized
INFO - 2023-06-08 19:37:41 --> Model "m_datatrain" initialized
INFO - 2023-06-08 19:37:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 19:37:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 19:37:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 19:37:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 19:37:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 19:37:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-08 19:37:41 --> Final output sent to browser
INFO - 2023-06-08 19:37:43 --> Config Class Initialized
INFO - 2023-06-08 19:37:43 --> Hooks Class Initialized
INFO - 2023-06-08 19:37:43 --> Utf8 Class Initialized
INFO - 2023-06-08 19:37:43 --> URI Class Initialized
INFO - 2023-06-08 19:37:43 --> Router Class Initialized
INFO - 2023-06-08 19:37:43 --> Output Class Initialized
INFO - 2023-06-08 19:37:43 --> Security Class Initialized
INFO - 2023-06-08 19:37:43 --> Input Class Initialized
INFO - 2023-06-08 19:37:43 --> Language Class Initialized
INFO - 2023-06-08 19:37:43 --> Loader Class Initialized
INFO - 2023-06-08 19:37:43 --> Helper loaded: url_helper
INFO - 2023-06-08 19:37:43 --> Helper loaded: form_helper
INFO - 2023-06-08 19:37:43 --> Database Driver Class Initialized
INFO - 2023-06-08 19:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:37:43 --> Form Validation Class Initialized
INFO - 2023-06-08 19:37:43 --> Controller Class Initialized
INFO - 2023-06-08 19:37:43 --> Model "m_datatest" initialized
INFO - 2023-06-08 19:37:43 --> Model "m_penghitungan" initialized
INFO - 2023-06-08 19:37:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 19:37:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 19:37:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-08 19:37:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 19:37:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 19:37:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 19:37:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-08 19:37:43 --> Final output sent to browser
INFO - 2023-06-08 19:37:46 --> Config Class Initialized
INFO - 2023-06-08 19:37:46 --> Hooks Class Initialized
INFO - 2023-06-08 19:37:46 --> Utf8 Class Initialized
INFO - 2023-06-08 19:37:46 --> URI Class Initialized
INFO - 2023-06-08 19:37:46 --> Router Class Initialized
INFO - 2023-06-08 19:37:46 --> Output Class Initialized
INFO - 2023-06-08 19:37:46 --> Security Class Initialized
INFO - 2023-06-08 19:37:46 --> Input Class Initialized
INFO - 2023-06-08 19:37:46 --> Language Class Initialized
INFO - 2023-06-08 19:37:46 --> Loader Class Initialized
INFO - 2023-06-08 19:37:46 --> Helper loaded: url_helper
INFO - 2023-06-08 19:37:46 --> Helper loaded: form_helper
INFO - 2023-06-08 19:37:46 --> Database Driver Class Initialized
INFO - 2023-06-08 19:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:37:46 --> Form Validation Class Initialized
INFO - 2023-06-08 19:37:46 --> Controller Class Initialized
INFO - 2023-06-08 19:37:46 --> Model "m_datatrain" initialized
INFO - 2023-06-08 19:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 19:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 19:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-08 19:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 19:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 19:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 19:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-08 19:37:47 --> Final output sent to browser
INFO - 2023-06-08 19:42:01 --> Config Class Initialized
INFO - 2023-06-08 19:42:01 --> Hooks Class Initialized
INFO - 2023-06-08 19:42:01 --> Utf8 Class Initialized
INFO - 2023-06-08 19:42:01 --> URI Class Initialized
INFO - 2023-06-08 19:42:01 --> Router Class Initialized
INFO - 2023-06-08 19:42:01 --> Output Class Initialized
INFO - 2023-06-08 19:42:01 --> Security Class Initialized
INFO - 2023-06-08 19:42:01 --> Input Class Initialized
INFO - 2023-06-08 19:42:01 --> Language Class Initialized
INFO - 2023-06-08 19:42:01 --> Loader Class Initialized
INFO - 2023-06-08 19:42:01 --> Helper loaded: url_helper
INFO - 2023-06-08 19:42:01 --> Helper loaded: form_helper
INFO - 2023-06-08 19:42:01 --> Database Driver Class Initialized
INFO - 2023-06-08 19:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:42:01 --> Form Validation Class Initialized
INFO - 2023-06-08 19:42:01 --> Controller Class Initialized
INFO - 2023-06-08 19:42:01 --> Model "m_datatest" initialized
INFO - 2023-06-08 19:42:01 --> Final output sent to browser
INFO - 2023-06-08 19:42:07 --> Config Class Initialized
INFO - 2023-06-08 19:42:07 --> Hooks Class Initialized
INFO - 2023-06-08 19:42:07 --> Utf8 Class Initialized
INFO - 2023-06-08 19:42:07 --> URI Class Initialized
INFO - 2023-06-08 19:42:07 --> Router Class Initialized
INFO - 2023-06-08 19:42:07 --> Output Class Initialized
INFO - 2023-06-08 19:42:07 --> Security Class Initialized
INFO - 2023-06-08 19:42:07 --> Input Class Initialized
INFO - 2023-06-08 19:42:07 --> Language Class Initialized
INFO - 2023-06-08 19:42:07 --> Loader Class Initialized
INFO - 2023-06-08 19:42:07 --> Helper loaded: url_helper
INFO - 2023-06-08 19:42:07 --> Helper loaded: form_helper
INFO - 2023-06-08 19:42:07 --> Database Driver Class Initialized
INFO - 2023-06-08 19:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:42:07 --> Form Validation Class Initialized
INFO - 2023-06-08 19:42:07 --> Controller Class Initialized
INFO - 2023-06-08 19:42:07 --> Model "m_datatrain" initialized
INFO - 2023-06-08 19:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 19:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 19:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-08 19:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 19:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 19:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 19:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-08 19:42:07 --> Final output sent to browser
INFO - 2023-06-08 19:42:10 --> Config Class Initialized
INFO - 2023-06-08 19:42:10 --> Hooks Class Initialized
INFO - 2023-06-08 19:42:10 --> Utf8 Class Initialized
INFO - 2023-06-08 19:42:10 --> URI Class Initialized
INFO - 2023-06-08 19:42:10 --> Router Class Initialized
INFO - 2023-06-08 19:42:10 --> Output Class Initialized
INFO - 2023-06-08 19:42:10 --> Security Class Initialized
INFO - 2023-06-08 19:42:10 --> Input Class Initialized
INFO - 2023-06-08 19:42:10 --> Language Class Initialized
INFO - 2023-06-08 19:42:10 --> Loader Class Initialized
INFO - 2023-06-08 19:42:10 --> Helper loaded: url_helper
INFO - 2023-06-08 19:42:10 --> Helper loaded: form_helper
INFO - 2023-06-08 19:42:10 --> Database Driver Class Initialized
INFO - 2023-06-08 19:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:42:10 --> Form Validation Class Initialized
INFO - 2023-06-08 19:42:10 --> Controller Class Initialized
INFO - 2023-06-08 19:42:10 --> Model "m_datatest" initialized
INFO - 2023-06-08 19:42:10 --> Model "m_penghitungan" initialized
INFO - 2023-06-08 19:42:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 19:42:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 19:42:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-08 19:42:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 19:42:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 19:42:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 19:42:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-08 19:42:10 --> Final output sent to browser
INFO - 2023-06-08 19:42:45 --> Config Class Initialized
INFO - 2023-06-08 19:42:45 --> Hooks Class Initialized
INFO - 2023-06-08 19:42:45 --> Utf8 Class Initialized
INFO - 2023-06-08 19:42:45 --> URI Class Initialized
INFO - 2023-06-08 19:42:45 --> Router Class Initialized
INFO - 2023-06-08 19:42:45 --> Output Class Initialized
INFO - 2023-06-08 19:42:45 --> Security Class Initialized
INFO - 2023-06-08 19:42:45 --> Input Class Initialized
INFO - 2023-06-08 19:42:45 --> Language Class Initialized
INFO - 2023-06-08 19:42:45 --> Loader Class Initialized
INFO - 2023-06-08 19:42:45 --> Helper loaded: url_helper
INFO - 2023-06-08 19:42:45 --> Helper loaded: form_helper
INFO - 2023-06-08 19:42:45 --> Database Driver Class Initialized
INFO - 2023-06-08 19:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:42:45 --> Form Validation Class Initialized
INFO - 2023-06-08 19:42:45 --> Controller Class Initialized
INFO - 2023-06-08 19:42:45 --> Model "m_datatest" initialized
INFO - 2023-06-08 19:42:45 --> Final output sent to browser
INFO - 2023-06-08 19:42:52 --> Config Class Initialized
INFO - 2023-06-08 19:42:52 --> Hooks Class Initialized
INFO - 2023-06-08 19:42:52 --> Utf8 Class Initialized
INFO - 2023-06-08 19:42:52 --> URI Class Initialized
INFO - 2023-06-08 19:42:52 --> Router Class Initialized
INFO - 2023-06-08 19:42:52 --> Output Class Initialized
INFO - 2023-06-08 19:42:52 --> Security Class Initialized
INFO - 2023-06-08 19:42:52 --> Input Class Initialized
INFO - 2023-06-08 19:42:52 --> Language Class Initialized
INFO - 2023-06-08 19:42:52 --> Loader Class Initialized
INFO - 2023-06-08 19:42:52 --> Helper loaded: url_helper
INFO - 2023-06-08 19:42:52 --> Helper loaded: form_helper
INFO - 2023-06-08 19:42:52 --> Database Driver Class Initialized
INFO - 2023-06-08 19:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:42:52 --> Form Validation Class Initialized
INFO - 2023-06-08 19:42:52 --> Controller Class Initialized
INFO - 2023-06-08 19:42:52 --> Model "m_datatest" initialized
INFO - 2023-06-08 19:42:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-08 19:42:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 19:42:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 19:42:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-08 19:42:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 19:42:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 19:42:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 19:42:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-08 19:42:52 --> Final output sent to browser
INFO - 2023-06-08 19:43:01 --> Config Class Initialized
INFO - 2023-06-08 19:43:01 --> Hooks Class Initialized
INFO - 2023-06-08 19:43:01 --> Utf8 Class Initialized
INFO - 2023-06-08 19:43:01 --> URI Class Initialized
INFO - 2023-06-08 19:43:01 --> Router Class Initialized
INFO - 2023-06-08 19:43:01 --> Output Class Initialized
INFO - 2023-06-08 19:43:01 --> Security Class Initialized
INFO - 2023-06-08 19:43:01 --> Input Class Initialized
INFO - 2023-06-08 19:43:01 --> Language Class Initialized
INFO - 2023-06-08 19:43:01 --> Loader Class Initialized
INFO - 2023-06-08 19:43:01 --> Helper loaded: url_helper
INFO - 2023-06-08 19:43:01 --> Helper loaded: form_helper
INFO - 2023-06-08 19:43:01 --> Database Driver Class Initialized
INFO - 2023-06-08 19:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 19:43:01 --> Form Validation Class Initialized
INFO - 2023-06-08 19:43:01 --> Controller Class Initialized
INFO - 2023-06-08 19:43:01 --> Model "m_datatest" initialized
INFO - 2023-06-08 19:43:01 --> Final output sent to browser
INFO - 2023-06-08 20:20:31 --> Config Class Initialized
INFO - 2023-06-08 20:20:31 --> Hooks Class Initialized
INFO - 2023-06-08 20:20:31 --> Utf8 Class Initialized
INFO - 2023-06-08 20:20:31 --> URI Class Initialized
INFO - 2023-06-08 20:20:31 --> Router Class Initialized
INFO - 2023-06-08 20:20:31 --> Output Class Initialized
INFO - 2023-06-08 20:20:31 --> Security Class Initialized
INFO - 2023-06-08 20:20:31 --> Input Class Initialized
INFO - 2023-06-08 20:20:31 --> Language Class Initialized
INFO - 2023-06-08 20:20:31 --> Loader Class Initialized
INFO - 2023-06-08 20:20:31 --> Helper loaded: url_helper
INFO - 2023-06-08 20:20:31 --> Helper loaded: form_helper
INFO - 2023-06-08 20:20:31 --> Database Driver Class Initialized
INFO - 2023-06-08 20:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:20:31 --> Form Validation Class Initialized
INFO - 2023-06-08 20:20:31 --> Controller Class Initialized
INFO - 2023-06-08 20:20:31 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:20:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:20:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:20:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:20:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-08 20:20:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:20:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:20:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
ERROR - 2023-06-08 20:20:32 --> Severity: Notice --> Undefined variable: GB C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 128
ERROR - 2023-06-08 20:20:32 --> Severity: Notice --> Undefined variable: RG C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 128
INFO - 2023-06-08 20:20:32 --> Final output sent to browser
INFO - 2023-06-08 20:21:02 --> Config Class Initialized
INFO - 2023-06-08 20:21:02 --> Hooks Class Initialized
INFO - 2023-06-08 20:21:02 --> Utf8 Class Initialized
INFO - 2023-06-08 20:21:02 --> URI Class Initialized
INFO - 2023-06-08 20:21:02 --> Router Class Initialized
INFO - 2023-06-08 20:21:02 --> Output Class Initialized
INFO - 2023-06-08 20:21:02 --> Security Class Initialized
INFO - 2023-06-08 20:21:02 --> Input Class Initialized
INFO - 2023-06-08 20:21:02 --> Language Class Initialized
INFO - 2023-06-08 20:21:02 --> Loader Class Initialized
INFO - 2023-06-08 20:21:02 --> Helper loaded: url_helper
INFO - 2023-06-08 20:21:02 --> Helper loaded: form_helper
INFO - 2023-06-08 20:21:02 --> Database Driver Class Initialized
INFO - 2023-06-08 20:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:21:02 --> Form Validation Class Initialized
INFO - 2023-06-08 20:21:02 --> Controller Class Initialized
INFO - 2023-06-08 20:21:02 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:21:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:21:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:21:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:21:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:21:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:21:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:21:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:21:02 --> Final output sent to browser
INFO - 2023-06-08 20:21:54 --> Config Class Initialized
INFO - 2023-06-08 20:21:54 --> Hooks Class Initialized
INFO - 2023-06-08 20:21:54 --> Utf8 Class Initialized
INFO - 2023-06-08 20:21:54 --> URI Class Initialized
INFO - 2023-06-08 20:21:54 --> Router Class Initialized
INFO - 2023-06-08 20:21:54 --> Output Class Initialized
INFO - 2023-06-08 20:21:54 --> Security Class Initialized
INFO - 2023-06-08 20:21:54 --> Input Class Initialized
INFO - 2023-06-08 20:21:54 --> Language Class Initialized
INFO - 2023-06-08 20:21:54 --> Loader Class Initialized
INFO - 2023-06-08 20:21:54 --> Helper loaded: url_helper
INFO - 2023-06-08 20:21:54 --> Helper loaded: form_helper
INFO - 2023-06-08 20:21:54 --> Database Driver Class Initialized
INFO - 2023-06-08 20:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:21:54 --> Form Validation Class Initialized
INFO - 2023-06-08 20:21:54 --> Controller Class Initialized
INFO - 2023-06-08 20:21:54 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:21:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:21:54 --> Final output sent to browser
INFO - 2023-06-08 20:22:17 --> Config Class Initialized
INFO - 2023-06-08 20:22:17 --> Hooks Class Initialized
INFO - 2023-06-08 20:22:17 --> Utf8 Class Initialized
INFO - 2023-06-08 20:22:17 --> URI Class Initialized
INFO - 2023-06-08 20:22:17 --> Router Class Initialized
INFO - 2023-06-08 20:22:17 --> Output Class Initialized
INFO - 2023-06-08 20:22:17 --> Security Class Initialized
INFO - 2023-06-08 20:22:17 --> Input Class Initialized
INFO - 2023-06-08 20:22:17 --> Language Class Initialized
INFO - 2023-06-08 20:22:17 --> Loader Class Initialized
INFO - 2023-06-08 20:22:17 --> Helper loaded: url_helper
INFO - 2023-06-08 20:22:17 --> Helper loaded: form_helper
INFO - 2023-06-08 20:22:17 --> Database Driver Class Initialized
INFO - 2023-06-08 20:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:22:17 --> Form Validation Class Initialized
INFO - 2023-06-08 20:22:17 --> Controller Class Initialized
INFO - 2023-06-08 20:22:17 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:22:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:22:17 --> Final output sent to browser
INFO - 2023-06-08 20:23:05 --> Config Class Initialized
INFO - 2023-06-08 20:23:05 --> Hooks Class Initialized
INFO - 2023-06-08 20:23:05 --> Utf8 Class Initialized
INFO - 2023-06-08 20:23:05 --> URI Class Initialized
INFO - 2023-06-08 20:23:05 --> Router Class Initialized
INFO - 2023-06-08 20:23:05 --> Output Class Initialized
INFO - 2023-06-08 20:23:05 --> Security Class Initialized
INFO - 2023-06-08 20:23:05 --> Input Class Initialized
INFO - 2023-06-08 20:23:05 --> Language Class Initialized
INFO - 2023-06-08 20:23:05 --> Loader Class Initialized
INFO - 2023-06-08 20:23:05 --> Helper loaded: url_helper
INFO - 2023-06-08 20:23:05 --> Helper loaded: form_helper
INFO - 2023-06-08 20:23:05 --> Database Driver Class Initialized
INFO - 2023-06-08 20:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:23:05 --> Form Validation Class Initialized
INFO - 2023-06-08 20:23:05 --> Controller Class Initialized
INFO - 2023-06-08 20:23:05 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:23:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:23:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:23:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:23:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:23:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:23:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:23:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:23:05 --> Final output sent to browser
INFO - 2023-06-08 20:25:29 --> Config Class Initialized
INFO - 2023-06-08 20:25:29 --> Hooks Class Initialized
INFO - 2023-06-08 20:25:29 --> Utf8 Class Initialized
INFO - 2023-06-08 20:25:29 --> URI Class Initialized
INFO - 2023-06-08 20:25:29 --> Router Class Initialized
INFO - 2023-06-08 20:25:29 --> Output Class Initialized
INFO - 2023-06-08 20:25:29 --> Security Class Initialized
INFO - 2023-06-08 20:25:29 --> Input Class Initialized
INFO - 2023-06-08 20:25:29 --> Language Class Initialized
INFO - 2023-06-08 20:25:29 --> Loader Class Initialized
INFO - 2023-06-08 20:25:29 --> Helper loaded: url_helper
INFO - 2023-06-08 20:25:29 --> Helper loaded: form_helper
INFO - 2023-06-08 20:25:29 --> Database Driver Class Initialized
INFO - 2023-06-08 20:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:25:29 --> Form Validation Class Initialized
INFO - 2023-06-08 20:25:29 --> Controller Class Initialized
INFO - 2023-06-08 20:25:29 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:25:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:25:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:25:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:25:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:25:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:25:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:25:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:25:29 --> Final output sent to browser
INFO - 2023-06-08 20:26:18 --> Config Class Initialized
INFO - 2023-06-08 20:26:18 --> Hooks Class Initialized
INFO - 2023-06-08 20:26:18 --> Utf8 Class Initialized
INFO - 2023-06-08 20:26:18 --> URI Class Initialized
INFO - 2023-06-08 20:26:18 --> Router Class Initialized
INFO - 2023-06-08 20:26:18 --> Output Class Initialized
INFO - 2023-06-08 20:26:18 --> Security Class Initialized
INFO - 2023-06-08 20:26:18 --> Input Class Initialized
INFO - 2023-06-08 20:26:18 --> Language Class Initialized
INFO - 2023-06-08 20:26:18 --> Loader Class Initialized
INFO - 2023-06-08 20:26:18 --> Helper loaded: url_helper
INFO - 2023-06-08 20:26:18 --> Helper loaded: form_helper
INFO - 2023-06-08 20:26:18 --> Database Driver Class Initialized
INFO - 2023-06-08 20:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:26:18 --> Form Validation Class Initialized
INFO - 2023-06-08 20:26:18 --> Controller Class Initialized
INFO - 2023-06-08 20:26:18 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:26:18 --> Final output sent to browser
INFO - 2023-06-08 20:30:40 --> Config Class Initialized
INFO - 2023-06-08 20:30:40 --> Hooks Class Initialized
INFO - 2023-06-08 20:30:40 --> Utf8 Class Initialized
INFO - 2023-06-08 20:30:40 --> URI Class Initialized
INFO - 2023-06-08 20:30:40 --> Router Class Initialized
INFO - 2023-06-08 20:30:40 --> Output Class Initialized
INFO - 2023-06-08 20:30:40 --> Security Class Initialized
INFO - 2023-06-08 20:30:40 --> Input Class Initialized
INFO - 2023-06-08 20:30:40 --> Language Class Initialized
INFO - 2023-06-08 20:30:40 --> Loader Class Initialized
INFO - 2023-06-08 20:30:40 --> Helper loaded: url_helper
INFO - 2023-06-08 20:30:40 --> Helper loaded: form_helper
INFO - 2023-06-08 20:30:40 --> Database Driver Class Initialized
INFO - 2023-06-08 20:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:30:40 --> Form Validation Class Initialized
INFO - 2023-06-08 20:30:40 --> Controller Class Initialized
INFO - 2023-06-08 20:30:40 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:30:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:30:40 --> Final output sent to browser
INFO - 2023-06-08 20:37:34 --> Config Class Initialized
INFO - 2023-06-08 20:37:34 --> Hooks Class Initialized
INFO - 2023-06-08 20:37:34 --> Utf8 Class Initialized
INFO - 2023-06-08 20:37:34 --> URI Class Initialized
INFO - 2023-06-08 20:37:34 --> Router Class Initialized
INFO - 2023-06-08 20:37:34 --> Output Class Initialized
INFO - 2023-06-08 20:37:34 --> Security Class Initialized
INFO - 2023-06-08 20:37:34 --> Input Class Initialized
INFO - 2023-06-08 20:37:34 --> Language Class Initialized
INFO - 2023-06-08 20:37:34 --> Loader Class Initialized
INFO - 2023-06-08 20:37:34 --> Helper loaded: url_helper
INFO - 2023-06-08 20:37:34 --> Helper loaded: form_helper
INFO - 2023-06-08 20:37:34 --> Database Driver Class Initialized
INFO - 2023-06-08 20:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:37:34 --> Form Validation Class Initialized
INFO - 2023-06-08 20:37:34 --> Controller Class Initialized
INFO - 2023-06-08 20:37:34 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:37:34 --> Final output sent to browser
INFO - 2023-06-08 20:40:20 --> Config Class Initialized
INFO - 2023-06-08 20:40:20 --> Hooks Class Initialized
INFO - 2023-06-08 20:40:20 --> Utf8 Class Initialized
INFO - 2023-06-08 20:40:20 --> URI Class Initialized
INFO - 2023-06-08 20:40:20 --> Router Class Initialized
INFO - 2023-06-08 20:40:20 --> Output Class Initialized
INFO - 2023-06-08 20:40:20 --> Security Class Initialized
INFO - 2023-06-08 20:40:20 --> Input Class Initialized
INFO - 2023-06-08 20:40:20 --> Language Class Initialized
INFO - 2023-06-08 20:40:20 --> Loader Class Initialized
INFO - 2023-06-08 20:40:20 --> Helper loaded: url_helper
INFO - 2023-06-08 20:40:20 --> Helper loaded: form_helper
INFO - 2023-06-08 20:40:20 --> Database Driver Class Initialized
INFO - 2023-06-08 20:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:40:20 --> Form Validation Class Initialized
INFO - 2023-06-08 20:40:20 --> Controller Class Initialized
INFO - 2023-06-08 20:40:20 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:40:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:40:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:40:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:40:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:40:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:40:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:40:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:40:20 --> Final output sent to browser
INFO - 2023-06-08 20:41:04 --> Config Class Initialized
INFO - 2023-06-08 20:41:04 --> Hooks Class Initialized
INFO - 2023-06-08 20:41:04 --> Utf8 Class Initialized
INFO - 2023-06-08 20:41:04 --> URI Class Initialized
INFO - 2023-06-08 20:41:04 --> Router Class Initialized
INFO - 2023-06-08 20:41:04 --> Output Class Initialized
INFO - 2023-06-08 20:41:04 --> Security Class Initialized
INFO - 2023-06-08 20:41:04 --> Input Class Initialized
INFO - 2023-06-08 20:41:04 --> Language Class Initialized
INFO - 2023-06-08 20:41:04 --> Loader Class Initialized
INFO - 2023-06-08 20:41:04 --> Helper loaded: url_helper
INFO - 2023-06-08 20:41:04 --> Helper loaded: form_helper
INFO - 2023-06-08 20:41:04 --> Database Driver Class Initialized
INFO - 2023-06-08 20:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:41:04 --> Form Validation Class Initialized
INFO - 2023-06-08 20:41:04 --> Controller Class Initialized
INFO - 2023-06-08 20:41:04 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:41:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:41:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:41:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:41:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:41:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:41:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:41:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:41:04 --> Final output sent to browser
INFO - 2023-06-08 20:41:47 --> Config Class Initialized
INFO - 2023-06-08 20:41:47 --> Hooks Class Initialized
INFO - 2023-06-08 20:41:47 --> Utf8 Class Initialized
INFO - 2023-06-08 20:41:47 --> URI Class Initialized
INFO - 2023-06-08 20:41:47 --> Router Class Initialized
INFO - 2023-06-08 20:41:47 --> Output Class Initialized
INFO - 2023-06-08 20:41:47 --> Security Class Initialized
INFO - 2023-06-08 20:41:47 --> Input Class Initialized
INFO - 2023-06-08 20:41:47 --> Language Class Initialized
INFO - 2023-06-08 20:41:47 --> Loader Class Initialized
INFO - 2023-06-08 20:41:47 --> Helper loaded: url_helper
INFO - 2023-06-08 20:41:47 --> Helper loaded: form_helper
INFO - 2023-06-08 20:41:47 --> Database Driver Class Initialized
INFO - 2023-06-08 20:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:41:47 --> Form Validation Class Initialized
INFO - 2023-06-08 20:41:47 --> Controller Class Initialized
INFO - 2023-06-08 20:41:47 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:41:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:41:47 --> Final output sent to browser
INFO - 2023-06-08 20:42:07 --> Config Class Initialized
INFO - 2023-06-08 20:42:07 --> Hooks Class Initialized
INFO - 2023-06-08 20:42:07 --> Utf8 Class Initialized
INFO - 2023-06-08 20:42:07 --> URI Class Initialized
INFO - 2023-06-08 20:42:07 --> Router Class Initialized
INFO - 2023-06-08 20:42:07 --> Output Class Initialized
INFO - 2023-06-08 20:42:07 --> Security Class Initialized
INFO - 2023-06-08 20:42:07 --> Input Class Initialized
INFO - 2023-06-08 20:42:07 --> Language Class Initialized
INFO - 2023-06-08 20:42:07 --> Loader Class Initialized
INFO - 2023-06-08 20:42:07 --> Helper loaded: url_helper
INFO - 2023-06-08 20:42:07 --> Helper loaded: form_helper
INFO - 2023-06-08 20:42:07 --> Database Driver Class Initialized
INFO - 2023-06-08 20:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:42:07 --> Form Validation Class Initialized
INFO - 2023-06-08 20:42:07 --> Controller Class Initialized
INFO - 2023-06-08 20:42:07 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:42:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:42:07 --> Final output sent to browser
INFO - 2023-06-08 20:42:28 --> Config Class Initialized
INFO - 2023-06-08 20:42:28 --> Hooks Class Initialized
INFO - 2023-06-08 20:42:28 --> Utf8 Class Initialized
INFO - 2023-06-08 20:42:28 --> URI Class Initialized
INFO - 2023-06-08 20:42:28 --> Router Class Initialized
INFO - 2023-06-08 20:42:28 --> Output Class Initialized
INFO - 2023-06-08 20:42:28 --> Security Class Initialized
INFO - 2023-06-08 20:42:28 --> Input Class Initialized
INFO - 2023-06-08 20:42:28 --> Language Class Initialized
INFO - 2023-06-08 20:42:28 --> Loader Class Initialized
INFO - 2023-06-08 20:42:28 --> Helper loaded: url_helper
INFO - 2023-06-08 20:42:28 --> Helper loaded: form_helper
INFO - 2023-06-08 20:42:28 --> Database Driver Class Initialized
INFO - 2023-06-08 20:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-08 20:42:28 --> Form Validation Class Initialized
INFO - 2023-06-08 20:42:28 --> Controller Class Initialized
INFO - 2023-06-08 20:42:28 --> Model "m_datatest" initialized
INFO - 2023-06-08 20:42:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-08 20:42:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-08 20:42:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\pengujian.php
INFO - 2023-06-08 20:42:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-08 20:42:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-08 20:42:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-08 20:42:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-08 20:42:28 --> Final output sent to browser
