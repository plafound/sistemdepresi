<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-16 06:03:37 --> Config Class Initialized
INFO - 2023-05-16 06:03:37 --> Hooks Class Initialized
INFO - 2023-05-16 06:03:37 --> Utf8 Class Initialized
INFO - 2023-05-16 06:03:37 --> URI Class Initialized
INFO - 2023-05-16 06:03:37 --> Router Class Initialized
INFO - 2023-05-16 06:03:38 --> Output Class Initialized
INFO - 2023-05-16 06:03:38 --> Security Class Initialized
INFO - 2023-05-16 06:03:38 --> Input Class Initialized
INFO - 2023-05-16 06:03:38 --> Language Class Initialized
INFO - 2023-05-16 06:03:38 --> Loader Class Initialized
INFO - 2023-05-16 06:03:38 --> Helper loaded: url_helper
INFO - 2023-05-16 06:03:38 --> Helper loaded: form_helper
INFO - 2023-05-16 06:03:38 --> Database Driver Class Initialized
INFO - 2023-05-16 06:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:03:39 --> Form Validation Class Initialized
INFO - 2023-05-16 06:03:39 --> Controller Class Initialized
INFO - 2023-05-16 06:03:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-16 06:03:39 --> Final output sent to browser
INFO - 2023-05-16 06:03:54 --> Config Class Initialized
INFO - 2023-05-16 06:03:54 --> Hooks Class Initialized
INFO - 2023-05-16 06:03:54 --> Utf8 Class Initialized
INFO - 2023-05-16 06:03:54 --> URI Class Initialized
INFO - 2023-05-16 06:03:54 --> Router Class Initialized
INFO - 2023-05-16 06:03:54 --> Output Class Initialized
INFO - 2023-05-16 06:03:54 --> Security Class Initialized
INFO - 2023-05-16 06:03:54 --> Input Class Initialized
INFO - 2023-05-16 06:03:54 --> Language Class Initialized
INFO - 2023-05-16 06:03:54 --> Loader Class Initialized
INFO - 2023-05-16 06:03:54 --> Helper loaded: url_helper
INFO - 2023-05-16 06:03:54 --> Helper loaded: form_helper
INFO - 2023-05-16 06:03:54 --> Database Driver Class Initialized
INFO - 2023-05-16 06:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:03:54 --> Form Validation Class Initialized
INFO - 2023-05-16 06:03:54 --> Controller Class Initialized
INFO - 2023-05-16 06:03:54 --> Model "m_user" initialized
INFO - 2023-05-16 06:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-16 06:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-16 06:03:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-16 06:03:54 --> Final output sent to browser
INFO - 2023-05-16 06:04:00 --> Config Class Initialized
INFO - 2023-05-16 06:04:00 --> Hooks Class Initialized
INFO - 2023-05-16 06:04:00 --> Utf8 Class Initialized
INFO - 2023-05-16 06:04:00 --> URI Class Initialized
INFO - 2023-05-16 06:04:00 --> Router Class Initialized
INFO - 2023-05-16 06:04:00 --> Output Class Initialized
INFO - 2023-05-16 06:04:00 --> Security Class Initialized
INFO - 2023-05-16 06:04:01 --> Input Class Initialized
INFO - 2023-05-16 06:04:01 --> Language Class Initialized
INFO - 2023-05-16 06:04:01 --> Loader Class Initialized
INFO - 2023-05-16 06:04:01 --> Helper loaded: url_helper
INFO - 2023-05-16 06:04:01 --> Helper loaded: form_helper
INFO - 2023-05-16 06:04:01 --> Database Driver Class Initialized
INFO - 2023-05-16 06:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:04:01 --> Form Validation Class Initialized
INFO - 2023-05-16 06:04:01 --> Controller Class Initialized
INFO - 2023-05-16 06:04:01 --> Model "m_user" initialized
INFO - 2023-05-16 06:04:01 --> Config Class Initialized
INFO - 2023-05-16 06:04:01 --> Hooks Class Initialized
INFO - 2023-05-16 06:04:01 --> Utf8 Class Initialized
INFO - 2023-05-16 06:04:01 --> URI Class Initialized
INFO - 2023-05-16 06:04:01 --> Router Class Initialized
INFO - 2023-05-16 06:04:01 --> Output Class Initialized
INFO - 2023-05-16 06:04:01 --> Security Class Initialized
INFO - 2023-05-16 06:04:01 --> Input Class Initialized
INFO - 2023-05-16 06:04:01 --> Language Class Initialized
INFO - 2023-05-16 06:04:01 --> Loader Class Initialized
INFO - 2023-05-16 06:04:01 --> Helper loaded: url_helper
INFO - 2023-05-16 06:04:01 --> Helper loaded: form_helper
INFO - 2023-05-16 06:04:01 --> Database Driver Class Initialized
INFO - 2023-05-16 06:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:04:01 --> Form Validation Class Initialized
INFO - 2023-05-16 06:04:01 --> Controller Class Initialized
INFO - 2023-05-16 06:04:01 --> Model "m_user" initialized
INFO - 2023-05-16 06:04:01 --> Model "m_datatrain" initialized
INFO - 2023-05-16 06:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 06:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 06:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 06:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 06:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 06:04:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-16 06:04:01 --> Final output sent to browser
INFO - 2023-05-16 06:04:03 --> Config Class Initialized
INFO - 2023-05-16 06:04:03 --> Hooks Class Initialized
INFO - 2023-05-16 06:04:03 --> Utf8 Class Initialized
INFO - 2023-05-16 06:04:03 --> URI Class Initialized
INFO - 2023-05-16 06:04:03 --> Router Class Initialized
INFO - 2023-05-16 06:04:03 --> Output Class Initialized
INFO - 2023-05-16 06:04:03 --> Security Class Initialized
INFO - 2023-05-16 06:04:03 --> Input Class Initialized
INFO - 2023-05-16 06:04:03 --> Language Class Initialized
INFO - 2023-05-16 06:04:03 --> Loader Class Initialized
INFO - 2023-05-16 06:04:03 --> Helper loaded: url_helper
INFO - 2023-05-16 06:04:03 --> Helper loaded: form_helper
INFO - 2023-05-16 06:04:03 --> Database Driver Class Initialized
INFO - 2023-05-16 06:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:04:03 --> Form Validation Class Initialized
INFO - 2023-05-16 06:04:03 --> Controller Class Initialized
INFO - 2023-05-16 06:04:03 --> Model "m_datatrain" initialized
INFO - 2023-05-16 06:04:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 06:04:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 06:04:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-16 06:04:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 06:04:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 06:04:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 06:04:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-16 06:04:04 --> Final output sent to browser
INFO - 2023-05-16 06:04:08 --> Config Class Initialized
INFO - 2023-05-16 06:04:08 --> Hooks Class Initialized
INFO - 2023-05-16 06:04:08 --> Utf8 Class Initialized
INFO - 2023-05-16 06:04:08 --> URI Class Initialized
INFO - 2023-05-16 06:04:08 --> Router Class Initialized
INFO - 2023-05-16 06:04:08 --> Output Class Initialized
INFO - 2023-05-16 06:04:08 --> Security Class Initialized
INFO - 2023-05-16 06:04:08 --> Input Class Initialized
INFO - 2023-05-16 06:04:08 --> Language Class Initialized
INFO - 2023-05-16 06:04:08 --> Loader Class Initialized
INFO - 2023-05-16 06:04:08 --> Helper loaded: url_helper
INFO - 2023-05-16 06:04:08 --> Helper loaded: form_helper
INFO - 2023-05-16 06:04:08 --> Database Driver Class Initialized
INFO - 2023-05-16 06:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:04:08 --> Form Validation Class Initialized
INFO - 2023-05-16 06:04:08 --> Controller Class Initialized
INFO - 2023-05-16 06:04:08 --> Model "m_datatest" initialized
INFO - 2023-05-16 06:04:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 06:04:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 06:04:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-16 06:04:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 06:04:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 06:04:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 06:04:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-16 06:04:08 --> Final output sent to browser
INFO - 2023-05-16 06:04:10 --> Config Class Initialized
INFO - 2023-05-16 06:04:10 --> Hooks Class Initialized
INFO - 2023-05-16 06:04:10 --> Utf8 Class Initialized
INFO - 2023-05-16 06:04:10 --> URI Class Initialized
INFO - 2023-05-16 06:04:10 --> Router Class Initialized
INFO - 2023-05-16 06:04:10 --> Output Class Initialized
INFO - 2023-05-16 06:04:10 --> Security Class Initialized
INFO - 2023-05-16 06:04:10 --> Input Class Initialized
INFO - 2023-05-16 06:04:10 --> Language Class Initialized
INFO - 2023-05-16 06:04:10 --> Loader Class Initialized
INFO - 2023-05-16 06:04:10 --> Helper loaded: url_helper
INFO - 2023-05-16 06:04:10 --> Helper loaded: form_helper
INFO - 2023-05-16 06:04:10 --> Database Driver Class Initialized
INFO - 2023-05-16 06:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:04:10 --> Form Validation Class Initialized
INFO - 2023-05-16 06:04:10 --> Controller Class Initialized
INFO - 2023-05-16 06:04:10 --> Model "m_datatrain" initialized
INFO - 2023-05-16 06:04:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 06:04:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 06:04:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-16 06:04:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 06:04:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 06:04:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 06:04:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-16 06:04:10 --> Final output sent to browser
INFO - 2023-05-16 06:04:35 --> Config Class Initialized
INFO - 2023-05-16 06:04:35 --> Hooks Class Initialized
INFO - 2023-05-16 06:04:35 --> Utf8 Class Initialized
INFO - 2023-05-16 06:04:35 --> URI Class Initialized
INFO - 2023-05-16 06:04:35 --> Router Class Initialized
INFO - 2023-05-16 06:04:35 --> Output Class Initialized
INFO - 2023-05-16 06:04:35 --> Security Class Initialized
INFO - 2023-05-16 06:04:35 --> Input Class Initialized
INFO - 2023-05-16 06:04:35 --> Language Class Initialized
INFO - 2023-05-16 06:04:35 --> Loader Class Initialized
INFO - 2023-05-16 06:04:35 --> Helper loaded: url_helper
INFO - 2023-05-16 06:04:35 --> Helper loaded: form_helper
INFO - 2023-05-16 06:04:35 --> Database Driver Class Initialized
INFO - 2023-05-16 06:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:04:35 --> Form Validation Class Initialized
INFO - 2023-05-16 06:04:35 --> Controller Class Initialized
INFO - 2023-05-16 06:04:35 --> Model "m_user" initialized
INFO - 2023-05-16 06:04:35 --> Config Class Initialized
INFO - 2023-05-16 06:04:35 --> Hooks Class Initialized
INFO - 2023-05-16 06:04:35 --> Utf8 Class Initialized
INFO - 2023-05-16 06:04:35 --> URI Class Initialized
INFO - 2023-05-16 06:04:35 --> Router Class Initialized
INFO - 2023-05-16 06:04:35 --> Output Class Initialized
INFO - 2023-05-16 06:04:35 --> Security Class Initialized
INFO - 2023-05-16 06:04:35 --> Input Class Initialized
INFO - 2023-05-16 06:04:35 --> Language Class Initialized
INFO - 2023-05-16 06:04:35 --> Loader Class Initialized
INFO - 2023-05-16 06:04:35 --> Helper loaded: url_helper
INFO - 2023-05-16 06:04:35 --> Helper loaded: form_helper
INFO - 2023-05-16 06:04:35 --> Database Driver Class Initialized
INFO - 2023-05-16 06:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:04:35 --> Form Validation Class Initialized
INFO - 2023-05-16 06:04:35 --> Controller Class Initialized
INFO - 2023-05-16 06:04:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-16 06:04:35 --> Final output sent to browser
INFO - 2023-05-16 06:04:37 --> Config Class Initialized
INFO - 2023-05-16 06:04:37 --> Hooks Class Initialized
INFO - 2023-05-16 06:04:37 --> Utf8 Class Initialized
INFO - 2023-05-16 06:04:37 --> URI Class Initialized
INFO - 2023-05-16 06:04:37 --> Router Class Initialized
INFO - 2023-05-16 06:04:37 --> Output Class Initialized
INFO - 2023-05-16 06:04:37 --> Security Class Initialized
INFO - 2023-05-16 06:04:37 --> Input Class Initialized
INFO - 2023-05-16 06:04:37 --> Language Class Initialized
INFO - 2023-05-16 06:04:37 --> Loader Class Initialized
INFO - 2023-05-16 06:04:37 --> Helper loaded: url_helper
INFO - 2023-05-16 06:04:37 --> Helper loaded: form_helper
INFO - 2023-05-16 06:04:37 --> Database Driver Class Initialized
INFO - 2023-05-16 06:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:04:37 --> Form Validation Class Initialized
INFO - 2023-05-16 06:04:37 --> Controller Class Initialized
INFO - 2023-05-16 06:04:37 --> Model "m_user" initialized
INFO - 2023-05-16 06:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 06:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 06:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-16 06:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 06:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 06:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-16 06:04:37 --> Final output sent to browser
INFO - 2023-05-16 06:04:39 --> Config Class Initialized
INFO - 2023-05-16 06:04:39 --> Hooks Class Initialized
INFO - 2023-05-16 06:04:39 --> Utf8 Class Initialized
INFO - 2023-05-16 06:04:39 --> URI Class Initialized
INFO - 2023-05-16 06:04:39 --> Router Class Initialized
INFO - 2023-05-16 06:04:39 --> Output Class Initialized
INFO - 2023-05-16 06:04:39 --> Security Class Initialized
INFO - 2023-05-16 06:04:39 --> Input Class Initialized
INFO - 2023-05-16 06:04:39 --> Language Class Initialized
INFO - 2023-05-16 06:04:39 --> Loader Class Initialized
INFO - 2023-05-16 06:04:39 --> Helper loaded: url_helper
INFO - 2023-05-16 06:04:39 --> Helper loaded: form_helper
INFO - 2023-05-16 06:04:39 --> Database Driver Class Initialized
INFO - 2023-05-16 06:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:04:39 --> Form Validation Class Initialized
INFO - 2023-05-16 06:04:39 --> Controller Class Initialized
INFO - 2023-05-16 06:04:39 --> Model "m_datatrain" initialized
INFO - 2023-05-16 06:04:39 --> Model "m_datatest" initialized
INFO - 2023-05-16 06:04:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 06:04:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 06:04:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-16 06:04:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-16 06:04:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 06:04:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 06:04:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-16 06:04:39 --> Final output sent to browser
INFO - 2023-05-16 06:05:13 --> Config Class Initialized
INFO - 2023-05-16 06:05:13 --> Hooks Class Initialized
INFO - 2023-05-16 06:05:13 --> Utf8 Class Initialized
INFO - 2023-05-16 06:05:13 --> URI Class Initialized
INFO - 2023-05-16 06:05:13 --> Router Class Initialized
INFO - 2023-05-16 06:05:13 --> Output Class Initialized
INFO - 2023-05-16 06:05:13 --> Security Class Initialized
INFO - 2023-05-16 06:05:13 --> Input Class Initialized
INFO - 2023-05-16 06:05:13 --> Language Class Initialized
INFO - 2023-05-16 06:05:13 --> Loader Class Initialized
INFO - 2023-05-16 06:05:13 --> Helper loaded: url_helper
INFO - 2023-05-16 06:05:13 --> Helper loaded: form_helper
INFO - 2023-05-16 06:05:13 --> Database Driver Class Initialized
INFO - 2023-05-16 06:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:05:13 --> Form Validation Class Initialized
INFO - 2023-05-16 06:05:13 --> Controller Class Initialized
INFO - 2023-05-16 06:05:13 --> Model "m_user" initialized
INFO - 2023-05-16 06:05:13 --> Config Class Initialized
INFO - 2023-05-16 06:05:13 --> Hooks Class Initialized
INFO - 2023-05-16 06:05:13 --> Utf8 Class Initialized
INFO - 2023-05-16 06:05:13 --> URI Class Initialized
INFO - 2023-05-16 06:05:13 --> Router Class Initialized
INFO - 2023-05-16 06:05:13 --> Output Class Initialized
INFO - 2023-05-16 06:05:13 --> Security Class Initialized
INFO - 2023-05-16 06:05:13 --> Input Class Initialized
INFO - 2023-05-16 06:05:13 --> Language Class Initialized
INFO - 2023-05-16 06:05:13 --> Loader Class Initialized
INFO - 2023-05-16 06:05:13 --> Helper loaded: url_helper
INFO - 2023-05-16 06:05:13 --> Helper loaded: form_helper
INFO - 2023-05-16 06:05:13 --> Database Driver Class Initialized
INFO - 2023-05-16 06:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 06:05:13 --> Form Validation Class Initialized
INFO - 2023-05-16 06:05:13 --> Controller Class Initialized
INFO - 2023-05-16 06:05:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-16 06:05:13 --> Final output sent to browser
INFO - 2023-05-16 07:15:28 --> Config Class Initialized
INFO - 2023-05-16 07:15:28 --> Hooks Class Initialized
INFO - 2023-05-16 07:15:28 --> Utf8 Class Initialized
INFO - 2023-05-16 07:15:28 --> URI Class Initialized
INFO - 2023-05-16 07:15:28 --> Router Class Initialized
INFO - 2023-05-16 07:15:28 --> Output Class Initialized
INFO - 2023-05-16 07:15:28 --> Security Class Initialized
INFO - 2023-05-16 07:15:28 --> Input Class Initialized
INFO - 2023-05-16 07:15:28 --> Language Class Initialized
INFO - 2023-05-16 07:15:28 --> Loader Class Initialized
INFO - 2023-05-16 07:15:28 --> Helper loaded: url_helper
INFO - 2023-05-16 07:15:28 --> Helper loaded: form_helper
INFO - 2023-05-16 07:15:28 --> Database Driver Class Initialized
INFO - 2023-05-16 07:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:15:28 --> Form Validation Class Initialized
INFO - 2023-05-16 07:15:28 --> Controller Class Initialized
INFO - 2023-05-16 07:15:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-16 07:15:28 --> Final output sent to browser
INFO - 2023-05-16 07:16:08 --> Config Class Initialized
INFO - 2023-05-16 07:16:08 --> Hooks Class Initialized
INFO - 2023-05-16 07:16:08 --> Utf8 Class Initialized
INFO - 2023-05-16 07:16:08 --> URI Class Initialized
INFO - 2023-05-16 07:16:08 --> Router Class Initialized
INFO - 2023-05-16 07:16:08 --> Output Class Initialized
INFO - 2023-05-16 07:16:08 --> Security Class Initialized
INFO - 2023-05-16 07:16:08 --> Input Class Initialized
INFO - 2023-05-16 07:16:08 --> Language Class Initialized
INFO - 2023-05-16 07:16:08 --> Loader Class Initialized
INFO - 2023-05-16 07:16:08 --> Helper loaded: url_helper
INFO - 2023-05-16 07:16:08 --> Helper loaded: form_helper
INFO - 2023-05-16 07:16:08 --> Database Driver Class Initialized
INFO - 2023-05-16 07:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:16:08 --> Form Validation Class Initialized
INFO - 2023-05-16 07:16:08 --> Controller Class Initialized
INFO - 2023-05-16 07:16:08 --> Model "m_user" initialized
INFO - 2023-05-16 07:16:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:16:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:16:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-16 07:16:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:16:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:16:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-16 07:16:08 --> Final output sent to browser
INFO - 2023-05-16 07:16:13 --> Config Class Initialized
INFO - 2023-05-16 07:16:13 --> Hooks Class Initialized
INFO - 2023-05-16 07:16:13 --> Utf8 Class Initialized
INFO - 2023-05-16 07:16:13 --> URI Class Initialized
INFO - 2023-05-16 07:16:13 --> Router Class Initialized
INFO - 2023-05-16 07:16:13 --> Output Class Initialized
INFO - 2023-05-16 07:16:13 --> Security Class Initialized
INFO - 2023-05-16 07:16:13 --> Input Class Initialized
INFO - 2023-05-16 07:16:13 --> Language Class Initialized
INFO - 2023-05-16 07:16:13 --> Loader Class Initialized
INFO - 2023-05-16 07:16:13 --> Helper loaded: url_helper
INFO - 2023-05-16 07:16:13 --> Helper loaded: form_helper
INFO - 2023-05-16 07:16:13 --> Database Driver Class Initialized
INFO - 2023-05-16 07:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:16:13 --> Form Validation Class Initialized
INFO - 2023-05-16 07:16:13 --> Controller Class Initialized
INFO - 2023-05-16 07:16:13 --> Model "m_datatrain" initialized
INFO - 2023-05-16 07:16:13 --> Model "m_datatest" initialized
INFO - 2023-05-16 07:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-16 07:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-16 07:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:16:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-16 07:16:13 --> Final output sent to browser
INFO - 2023-05-16 07:16:28 --> Config Class Initialized
INFO - 2023-05-16 07:16:28 --> Hooks Class Initialized
INFO - 2023-05-16 07:16:28 --> Utf8 Class Initialized
INFO - 2023-05-16 07:16:28 --> URI Class Initialized
INFO - 2023-05-16 07:16:28 --> Router Class Initialized
INFO - 2023-05-16 07:16:28 --> Output Class Initialized
INFO - 2023-05-16 07:16:28 --> Security Class Initialized
INFO - 2023-05-16 07:16:28 --> Input Class Initialized
INFO - 2023-05-16 07:16:28 --> Language Class Initialized
INFO - 2023-05-16 07:16:28 --> Loader Class Initialized
INFO - 2023-05-16 07:16:28 --> Helper loaded: url_helper
INFO - 2023-05-16 07:16:28 --> Helper loaded: form_helper
INFO - 2023-05-16 07:16:28 --> Database Driver Class Initialized
INFO - 2023-05-16 07:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:16:28 --> Form Validation Class Initialized
INFO - 2023-05-16 07:16:28 --> Controller Class Initialized
INFO - 2023-05-16 07:16:28 --> Model "m_user" initialized
INFO - 2023-05-16 07:16:28 --> Config Class Initialized
INFO - 2023-05-16 07:16:28 --> Hooks Class Initialized
INFO - 2023-05-16 07:16:28 --> Utf8 Class Initialized
INFO - 2023-05-16 07:16:28 --> URI Class Initialized
INFO - 2023-05-16 07:16:28 --> Router Class Initialized
INFO - 2023-05-16 07:16:28 --> Output Class Initialized
INFO - 2023-05-16 07:16:28 --> Security Class Initialized
INFO - 2023-05-16 07:16:28 --> Input Class Initialized
INFO - 2023-05-16 07:16:28 --> Language Class Initialized
INFO - 2023-05-16 07:16:28 --> Loader Class Initialized
INFO - 2023-05-16 07:16:28 --> Helper loaded: url_helper
INFO - 2023-05-16 07:16:28 --> Helper loaded: form_helper
INFO - 2023-05-16 07:16:28 --> Database Driver Class Initialized
INFO - 2023-05-16 07:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:16:28 --> Form Validation Class Initialized
INFO - 2023-05-16 07:16:28 --> Controller Class Initialized
INFO - 2023-05-16 07:16:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-16 07:16:28 --> Final output sent to browser
INFO - 2023-05-16 07:16:29 --> Config Class Initialized
INFO - 2023-05-16 07:16:29 --> Hooks Class Initialized
INFO - 2023-05-16 07:16:29 --> Utf8 Class Initialized
INFO - 2023-05-16 07:16:29 --> URI Class Initialized
INFO - 2023-05-16 07:16:29 --> Router Class Initialized
INFO - 2023-05-16 07:16:29 --> Output Class Initialized
INFO - 2023-05-16 07:16:29 --> Security Class Initialized
INFO - 2023-05-16 07:16:29 --> Input Class Initialized
INFO - 2023-05-16 07:16:29 --> Language Class Initialized
INFO - 2023-05-16 07:16:29 --> Loader Class Initialized
INFO - 2023-05-16 07:16:29 --> Helper loaded: url_helper
INFO - 2023-05-16 07:16:29 --> Helper loaded: form_helper
INFO - 2023-05-16 07:16:29 --> Database Driver Class Initialized
INFO - 2023-05-16 07:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:16:29 --> Form Validation Class Initialized
INFO - 2023-05-16 07:16:29 --> Controller Class Initialized
INFO - 2023-05-16 07:16:29 --> Model "m_user" initialized
INFO - 2023-05-16 07:16:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-16 07:16:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-16 07:16:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-16 07:16:29 --> Final output sent to browser
INFO - 2023-05-16 07:16:35 --> Config Class Initialized
INFO - 2023-05-16 07:16:35 --> Hooks Class Initialized
INFO - 2023-05-16 07:16:35 --> Utf8 Class Initialized
INFO - 2023-05-16 07:16:35 --> URI Class Initialized
INFO - 2023-05-16 07:16:35 --> Router Class Initialized
INFO - 2023-05-16 07:16:35 --> Output Class Initialized
INFO - 2023-05-16 07:16:35 --> Security Class Initialized
INFO - 2023-05-16 07:16:35 --> Input Class Initialized
INFO - 2023-05-16 07:16:35 --> Language Class Initialized
INFO - 2023-05-16 07:16:35 --> Loader Class Initialized
INFO - 2023-05-16 07:16:35 --> Helper loaded: url_helper
INFO - 2023-05-16 07:16:35 --> Helper loaded: form_helper
INFO - 2023-05-16 07:16:35 --> Database Driver Class Initialized
INFO - 2023-05-16 07:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:16:35 --> Form Validation Class Initialized
INFO - 2023-05-16 07:16:35 --> Controller Class Initialized
INFO - 2023-05-16 07:16:35 --> Model "m_user" initialized
INFO - 2023-05-16 07:16:35 --> Config Class Initialized
INFO - 2023-05-16 07:16:35 --> Hooks Class Initialized
INFO - 2023-05-16 07:16:35 --> Utf8 Class Initialized
INFO - 2023-05-16 07:16:35 --> URI Class Initialized
INFO - 2023-05-16 07:16:35 --> Router Class Initialized
INFO - 2023-05-16 07:16:35 --> Output Class Initialized
INFO - 2023-05-16 07:16:35 --> Security Class Initialized
INFO - 2023-05-16 07:16:35 --> Input Class Initialized
INFO - 2023-05-16 07:16:35 --> Language Class Initialized
INFO - 2023-05-16 07:16:35 --> Loader Class Initialized
INFO - 2023-05-16 07:16:35 --> Helper loaded: url_helper
INFO - 2023-05-16 07:16:35 --> Helper loaded: form_helper
INFO - 2023-05-16 07:16:35 --> Database Driver Class Initialized
INFO - 2023-05-16 07:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:16:35 --> Form Validation Class Initialized
INFO - 2023-05-16 07:16:35 --> Controller Class Initialized
INFO - 2023-05-16 07:16:35 --> Model "m_user" initialized
INFO - 2023-05-16 07:16:35 --> Model "m_datatrain" initialized
INFO - 2023-05-16 07:16:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:16:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:16:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 07:16:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:16:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:16:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-16 07:16:35 --> Final output sent to browser
INFO - 2023-05-16 07:16:37 --> Config Class Initialized
INFO - 2023-05-16 07:16:37 --> Hooks Class Initialized
INFO - 2023-05-16 07:16:38 --> Utf8 Class Initialized
INFO - 2023-05-16 07:16:38 --> URI Class Initialized
INFO - 2023-05-16 07:16:38 --> Router Class Initialized
INFO - 2023-05-16 07:16:38 --> Output Class Initialized
INFO - 2023-05-16 07:16:38 --> Security Class Initialized
INFO - 2023-05-16 07:16:38 --> Input Class Initialized
INFO - 2023-05-16 07:16:38 --> Language Class Initialized
INFO - 2023-05-16 07:16:38 --> Loader Class Initialized
INFO - 2023-05-16 07:16:38 --> Helper loaded: url_helper
INFO - 2023-05-16 07:16:38 --> Helper loaded: form_helper
INFO - 2023-05-16 07:16:38 --> Database Driver Class Initialized
INFO - 2023-05-16 07:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:16:38 --> Form Validation Class Initialized
INFO - 2023-05-16 07:16:38 --> Controller Class Initialized
INFO - 2023-05-16 07:16:38 --> Model "m_datatrain" initialized
INFO - 2023-05-16 07:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-16 07:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 07:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:16:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-16 07:16:38 --> Final output sent to browser
INFO - 2023-05-16 07:16:40 --> Config Class Initialized
INFO - 2023-05-16 07:16:40 --> Hooks Class Initialized
INFO - 2023-05-16 07:16:40 --> Utf8 Class Initialized
INFO - 2023-05-16 07:16:40 --> URI Class Initialized
INFO - 2023-05-16 07:16:40 --> Router Class Initialized
INFO - 2023-05-16 07:16:40 --> Output Class Initialized
INFO - 2023-05-16 07:16:40 --> Security Class Initialized
INFO - 2023-05-16 07:16:40 --> Input Class Initialized
INFO - 2023-05-16 07:16:40 --> Language Class Initialized
INFO - 2023-05-16 07:16:40 --> Loader Class Initialized
INFO - 2023-05-16 07:16:40 --> Helper loaded: url_helper
INFO - 2023-05-16 07:16:40 --> Helper loaded: form_helper
INFO - 2023-05-16 07:16:40 --> Database Driver Class Initialized
INFO - 2023-05-16 07:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:16:40 --> Form Validation Class Initialized
INFO - 2023-05-16 07:16:40 --> Controller Class Initialized
INFO - 2023-05-16 07:16:40 --> Model "m_datatest" initialized
INFO - 2023-05-16 07:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-16 07:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 07:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-16 07:16:40 --> Final output sent to browser
INFO - 2023-05-16 07:16:56 --> Config Class Initialized
INFO - 2023-05-16 07:16:56 --> Hooks Class Initialized
INFO - 2023-05-16 07:16:56 --> Utf8 Class Initialized
INFO - 2023-05-16 07:16:56 --> URI Class Initialized
INFO - 2023-05-16 07:16:56 --> Router Class Initialized
INFO - 2023-05-16 07:16:56 --> Output Class Initialized
INFO - 2023-05-16 07:16:56 --> Security Class Initialized
INFO - 2023-05-16 07:16:56 --> Input Class Initialized
INFO - 2023-05-16 07:16:56 --> Language Class Initialized
INFO - 2023-05-16 07:16:56 --> Loader Class Initialized
INFO - 2023-05-16 07:16:56 --> Helper loaded: url_helper
INFO - 2023-05-16 07:16:56 --> Helper loaded: form_helper
INFO - 2023-05-16 07:16:56 --> Database Driver Class Initialized
INFO - 2023-05-16 07:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:16:56 --> Form Validation Class Initialized
INFO - 2023-05-16 07:16:56 --> Controller Class Initialized
INFO - 2023-05-16 07:16:56 --> Model "m_datatrain" initialized
INFO - 2023-05-16 07:16:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:16:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:16:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-16 07:16:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 07:16:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:16:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:16:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-16 07:16:56 --> Final output sent to browser
INFO - 2023-05-16 07:17:01 --> Config Class Initialized
INFO - 2023-05-16 07:17:01 --> Hooks Class Initialized
INFO - 2023-05-16 07:17:01 --> Utf8 Class Initialized
INFO - 2023-05-16 07:17:01 --> URI Class Initialized
INFO - 2023-05-16 07:17:01 --> Router Class Initialized
INFO - 2023-05-16 07:17:01 --> Output Class Initialized
INFO - 2023-05-16 07:17:01 --> Security Class Initialized
INFO - 2023-05-16 07:17:01 --> Input Class Initialized
INFO - 2023-05-16 07:17:01 --> Language Class Initialized
INFO - 2023-05-16 07:17:01 --> Loader Class Initialized
INFO - 2023-05-16 07:17:01 --> Helper loaded: url_helper
INFO - 2023-05-16 07:17:01 --> Helper loaded: form_helper
INFO - 2023-05-16 07:17:01 --> Database Driver Class Initialized
INFO - 2023-05-16 07:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:17:01 --> Form Validation Class Initialized
INFO - 2023-05-16 07:17:01 --> Controller Class Initialized
INFO - 2023-05-16 07:17:01 --> Model "m_user" initialized
INFO - 2023-05-16 07:17:01 --> Config Class Initialized
INFO - 2023-05-16 07:17:01 --> Hooks Class Initialized
INFO - 2023-05-16 07:17:01 --> Utf8 Class Initialized
INFO - 2023-05-16 07:17:01 --> URI Class Initialized
INFO - 2023-05-16 07:17:01 --> Router Class Initialized
INFO - 2023-05-16 07:17:01 --> Output Class Initialized
INFO - 2023-05-16 07:17:01 --> Security Class Initialized
INFO - 2023-05-16 07:17:01 --> Input Class Initialized
INFO - 2023-05-16 07:17:01 --> Language Class Initialized
INFO - 2023-05-16 07:17:01 --> Loader Class Initialized
INFO - 2023-05-16 07:17:01 --> Helper loaded: url_helper
INFO - 2023-05-16 07:17:01 --> Helper loaded: form_helper
INFO - 2023-05-16 07:17:01 --> Database Driver Class Initialized
INFO - 2023-05-16 07:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:17:01 --> Form Validation Class Initialized
INFO - 2023-05-16 07:17:01 --> Controller Class Initialized
INFO - 2023-05-16 07:17:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-16 07:17:01 --> Final output sent to browser
INFO - 2023-05-16 07:55:58 --> Config Class Initialized
INFO - 2023-05-16 07:55:58 --> Hooks Class Initialized
INFO - 2023-05-16 07:55:58 --> Utf8 Class Initialized
INFO - 2023-05-16 07:55:58 --> URI Class Initialized
INFO - 2023-05-16 07:55:58 --> Router Class Initialized
INFO - 2023-05-16 07:55:58 --> Output Class Initialized
INFO - 2023-05-16 07:55:58 --> Security Class Initialized
INFO - 2023-05-16 07:55:58 --> Input Class Initialized
INFO - 2023-05-16 07:55:58 --> Language Class Initialized
INFO - 2023-05-16 07:55:58 --> Loader Class Initialized
INFO - 2023-05-16 07:55:58 --> Helper loaded: url_helper
INFO - 2023-05-16 07:55:58 --> Helper loaded: form_helper
INFO - 2023-05-16 07:55:58 --> Database Driver Class Initialized
INFO - 2023-05-16 07:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:55:58 --> Form Validation Class Initialized
INFO - 2023-05-16 07:55:58 --> Controller Class Initialized
INFO - 2023-05-16 07:55:58 --> Model "m_user" initialized
INFO - 2023-05-16 07:55:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:55:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:55:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-16 07:55:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:55:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:55:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-16 07:55:58 --> Final output sent to browser
INFO - 2023-05-16 07:56:08 --> Config Class Initialized
INFO - 2023-05-16 07:56:08 --> Hooks Class Initialized
INFO - 2023-05-16 07:56:08 --> Utf8 Class Initialized
INFO - 2023-05-16 07:56:08 --> URI Class Initialized
INFO - 2023-05-16 07:56:08 --> Router Class Initialized
INFO - 2023-05-16 07:56:08 --> Output Class Initialized
INFO - 2023-05-16 07:56:08 --> Security Class Initialized
INFO - 2023-05-16 07:56:08 --> Input Class Initialized
INFO - 2023-05-16 07:56:08 --> Language Class Initialized
INFO - 2023-05-16 07:56:08 --> Loader Class Initialized
INFO - 2023-05-16 07:56:08 --> Helper loaded: url_helper
INFO - 2023-05-16 07:56:08 --> Helper loaded: form_helper
INFO - 2023-05-16 07:56:08 --> Database Driver Class Initialized
INFO - 2023-05-16 07:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:56:08 --> Form Validation Class Initialized
INFO - 2023-05-16 07:56:08 --> Controller Class Initialized
INFO - 2023-05-16 07:56:08 --> Model "m_datatrain" initialized
INFO - 2023-05-16 07:56:08 --> Model "m_datatest" initialized
INFO - 2023-05-16 07:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-16 07:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-16 07:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-16 07:56:08 --> Final output sent to browser
INFO - 2023-05-16 07:58:27 --> Config Class Initialized
INFO - 2023-05-16 07:58:27 --> Hooks Class Initialized
INFO - 2023-05-16 07:58:27 --> Utf8 Class Initialized
INFO - 2023-05-16 07:58:27 --> URI Class Initialized
INFO - 2023-05-16 07:58:27 --> Router Class Initialized
INFO - 2023-05-16 07:58:27 --> Output Class Initialized
INFO - 2023-05-16 07:58:27 --> Security Class Initialized
INFO - 2023-05-16 07:58:27 --> Input Class Initialized
INFO - 2023-05-16 07:58:27 --> Language Class Initialized
INFO - 2023-05-16 07:58:27 --> Loader Class Initialized
INFO - 2023-05-16 07:58:27 --> Helper loaded: url_helper
INFO - 2023-05-16 07:58:27 --> Helper loaded: form_helper
INFO - 2023-05-16 07:58:27 --> Database Driver Class Initialized
INFO - 2023-05-16 07:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:58:27 --> Form Validation Class Initialized
INFO - 2023-05-16 07:58:27 --> Controller Class Initialized
INFO - 2023-05-16 07:58:27 --> Model "m_user" initialized
INFO - 2023-05-16 07:58:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:58:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:58:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-16 07:58:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:58:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:58:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-16 07:58:27 --> Final output sent to browser
INFO - 2023-05-16 07:58:29 --> Config Class Initialized
INFO - 2023-05-16 07:58:29 --> Hooks Class Initialized
INFO - 2023-05-16 07:58:29 --> Utf8 Class Initialized
INFO - 2023-05-16 07:58:29 --> URI Class Initialized
INFO - 2023-05-16 07:58:29 --> Router Class Initialized
INFO - 2023-05-16 07:58:29 --> Output Class Initialized
INFO - 2023-05-16 07:58:29 --> Security Class Initialized
INFO - 2023-05-16 07:58:29 --> Input Class Initialized
INFO - 2023-05-16 07:58:29 --> Language Class Initialized
INFO - 2023-05-16 07:58:29 --> Loader Class Initialized
INFO - 2023-05-16 07:58:29 --> Helper loaded: url_helper
INFO - 2023-05-16 07:58:29 --> Helper loaded: form_helper
INFO - 2023-05-16 07:58:29 --> Database Driver Class Initialized
INFO - 2023-05-16 07:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:58:29 --> Form Validation Class Initialized
INFO - 2023-05-16 07:58:29 --> Controller Class Initialized
INFO - 2023-05-16 07:58:29 --> Model "m_datatrain" initialized
INFO - 2023-05-16 07:58:29 --> Model "m_datatest" initialized
INFO - 2023-05-16 07:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-16 07:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-16 07:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:58:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-16 07:58:29 --> Final output sent to browser
INFO - 2023-05-16 07:58:31 --> Config Class Initialized
INFO - 2023-05-16 07:58:31 --> Hooks Class Initialized
INFO - 2023-05-16 07:58:31 --> Utf8 Class Initialized
INFO - 2023-05-16 07:58:31 --> URI Class Initialized
INFO - 2023-05-16 07:58:31 --> Router Class Initialized
INFO - 2023-05-16 07:58:31 --> Output Class Initialized
INFO - 2023-05-16 07:58:31 --> Security Class Initialized
INFO - 2023-05-16 07:58:31 --> Input Class Initialized
INFO - 2023-05-16 07:58:31 --> Language Class Initialized
INFO - 2023-05-16 07:58:31 --> Loader Class Initialized
INFO - 2023-05-16 07:58:31 --> Helper loaded: url_helper
INFO - 2023-05-16 07:58:31 --> Helper loaded: form_helper
INFO - 2023-05-16 07:58:31 --> Database Driver Class Initialized
INFO - 2023-05-16 07:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:58:31 --> Form Validation Class Initialized
INFO - 2023-05-16 07:58:31 --> Controller Class Initialized
INFO - 2023-05-16 07:58:31 --> Model "m_user" initialized
INFO - 2023-05-16 07:58:31 --> Config Class Initialized
INFO - 2023-05-16 07:58:31 --> Hooks Class Initialized
INFO - 2023-05-16 07:58:31 --> Utf8 Class Initialized
INFO - 2023-05-16 07:58:31 --> URI Class Initialized
INFO - 2023-05-16 07:58:31 --> Router Class Initialized
INFO - 2023-05-16 07:58:31 --> Output Class Initialized
INFO - 2023-05-16 07:58:31 --> Security Class Initialized
INFO - 2023-05-16 07:58:31 --> Input Class Initialized
INFO - 2023-05-16 07:58:31 --> Language Class Initialized
INFO - 2023-05-16 07:58:31 --> Loader Class Initialized
INFO - 2023-05-16 07:58:31 --> Helper loaded: url_helper
INFO - 2023-05-16 07:58:31 --> Helper loaded: form_helper
INFO - 2023-05-16 07:58:31 --> Database Driver Class Initialized
INFO - 2023-05-16 07:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:58:31 --> Form Validation Class Initialized
INFO - 2023-05-16 07:58:31 --> Controller Class Initialized
INFO - 2023-05-16 07:58:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-16 07:58:31 --> Final output sent to browser
INFO - 2023-05-16 07:58:33 --> Config Class Initialized
INFO - 2023-05-16 07:58:33 --> Hooks Class Initialized
INFO - 2023-05-16 07:58:33 --> Utf8 Class Initialized
INFO - 2023-05-16 07:58:33 --> URI Class Initialized
INFO - 2023-05-16 07:58:33 --> Router Class Initialized
INFO - 2023-05-16 07:58:33 --> Output Class Initialized
INFO - 2023-05-16 07:58:33 --> Security Class Initialized
INFO - 2023-05-16 07:58:33 --> Input Class Initialized
INFO - 2023-05-16 07:58:33 --> Language Class Initialized
INFO - 2023-05-16 07:58:33 --> Loader Class Initialized
INFO - 2023-05-16 07:58:33 --> Helper loaded: url_helper
INFO - 2023-05-16 07:58:33 --> Helper loaded: form_helper
INFO - 2023-05-16 07:58:33 --> Database Driver Class Initialized
INFO - 2023-05-16 07:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:58:33 --> Form Validation Class Initialized
INFO - 2023-05-16 07:58:33 --> Controller Class Initialized
INFO - 2023-05-16 07:58:33 --> Model "m_user" initialized
INFO - 2023-05-16 07:58:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-16 07:58:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-16 07:58:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-16 07:58:33 --> Final output sent to browser
INFO - 2023-05-16 07:58:37 --> Config Class Initialized
INFO - 2023-05-16 07:58:37 --> Hooks Class Initialized
INFO - 2023-05-16 07:58:37 --> Utf8 Class Initialized
INFO - 2023-05-16 07:58:37 --> URI Class Initialized
INFO - 2023-05-16 07:58:37 --> Router Class Initialized
INFO - 2023-05-16 07:58:37 --> Output Class Initialized
INFO - 2023-05-16 07:58:37 --> Security Class Initialized
INFO - 2023-05-16 07:58:37 --> Input Class Initialized
INFO - 2023-05-16 07:58:37 --> Language Class Initialized
INFO - 2023-05-16 07:58:37 --> Loader Class Initialized
INFO - 2023-05-16 07:58:37 --> Helper loaded: url_helper
INFO - 2023-05-16 07:58:37 --> Helper loaded: form_helper
INFO - 2023-05-16 07:58:37 --> Database Driver Class Initialized
INFO - 2023-05-16 07:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:58:37 --> Form Validation Class Initialized
INFO - 2023-05-16 07:58:37 --> Controller Class Initialized
INFO - 2023-05-16 07:58:37 --> Model "m_user" initialized
INFO - 2023-05-16 07:58:38 --> Config Class Initialized
INFO - 2023-05-16 07:58:38 --> Hooks Class Initialized
INFO - 2023-05-16 07:58:38 --> Utf8 Class Initialized
INFO - 2023-05-16 07:58:38 --> URI Class Initialized
INFO - 2023-05-16 07:58:38 --> Router Class Initialized
INFO - 2023-05-16 07:58:38 --> Output Class Initialized
INFO - 2023-05-16 07:58:38 --> Security Class Initialized
INFO - 2023-05-16 07:58:38 --> Input Class Initialized
INFO - 2023-05-16 07:58:38 --> Language Class Initialized
INFO - 2023-05-16 07:58:38 --> Loader Class Initialized
INFO - 2023-05-16 07:58:38 --> Helper loaded: url_helper
INFO - 2023-05-16 07:58:38 --> Helper loaded: form_helper
INFO - 2023-05-16 07:58:38 --> Database Driver Class Initialized
INFO - 2023-05-16 07:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:58:38 --> Form Validation Class Initialized
INFO - 2023-05-16 07:58:38 --> Controller Class Initialized
INFO - 2023-05-16 07:58:38 --> Model "m_user" initialized
INFO - 2023-05-16 07:58:38 --> Model "m_datatrain" initialized
INFO - 2023-05-16 07:58:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:58:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:58:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 07:58:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:58:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:58:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-16 07:58:38 --> Final output sent to browser
INFO - 2023-05-16 07:58:40 --> Config Class Initialized
INFO - 2023-05-16 07:58:40 --> Hooks Class Initialized
INFO - 2023-05-16 07:58:40 --> Utf8 Class Initialized
INFO - 2023-05-16 07:58:40 --> URI Class Initialized
INFO - 2023-05-16 07:58:40 --> Router Class Initialized
INFO - 2023-05-16 07:58:40 --> Output Class Initialized
INFO - 2023-05-16 07:58:40 --> Security Class Initialized
INFO - 2023-05-16 07:58:40 --> Input Class Initialized
INFO - 2023-05-16 07:58:40 --> Language Class Initialized
INFO - 2023-05-16 07:58:40 --> Loader Class Initialized
INFO - 2023-05-16 07:58:40 --> Helper loaded: url_helper
INFO - 2023-05-16 07:58:40 --> Helper loaded: form_helper
INFO - 2023-05-16 07:58:40 --> Database Driver Class Initialized
INFO - 2023-05-16 07:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:58:40 --> Form Validation Class Initialized
INFO - 2023-05-16 07:58:40 --> Controller Class Initialized
INFO - 2023-05-16 07:58:40 --> Model "m_datatrain" initialized
INFO - 2023-05-16 07:58:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:58:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:58:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-16 07:58:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 07:58:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:58:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:58:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-16 07:58:40 --> Final output sent to browser
INFO - 2023-05-16 07:58:49 --> Config Class Initialized
INFO - 2023-05-16 07:58:49 --> Hooks Class Initialized
INFO - 2023-05-16 07:58:49 --> Utf8 Class Initialized
INFO - 2023-05-16 07:58:49 --> URI Class Initialized
INFO - 2023-05-16 07:58:49 --> Router Class Initialized
INFO - 2023-05-16 07:58:49 --> Output Class Initialized
INFO - 2023-05-16 07:58:49 --> Security Class Initialized
INFO - 2023-05-16 07:58:49 --> Input Class Initialized
INFO - 2023-05-16 07:58:49 --> Language Class Initialized
INFO - 2023-05-16 07:58:49 --> Loader Class Initialized
INFO - 2023-05-16 07:58:49 --> Helper loaded: url_helper
INFO - 2023-05-16 07:58:49 --> Helper loaded: form_helper
INFO - 2023-05-16 07:58:49 --> Database Driver Class Initialized
INFO - 2023-05-16 07:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:58:49 --> Form Validation Class Initialized
INFO - 2023-05-16 07:58:49 --> Controller Class Initialized
INFO - 2023-05-16 07:58:49 --> Model "m_user" initialized
INFO - 2023-05-16 07:58:49 --> Model "m_datatrain" initialized
INFO - 2023-05-16 07:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 07:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:58:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-16 07:58:49 --> Final output sent to browser
INFO - 2023-05-16 07:58:51 --> Config Class Initialized
INFO - 2023-05-16 07:58:51 --> Hooks Class Initialized
INFO - 2023-05-16 07:58:51 --> Utf8 Class Initialized
INFO - 2023-05-16 07:58:51 --> URI Class Initialized
INFO - 2023-05-16 07:58:51 --> Router Class Initialized
INFO - 2023-05-16 07:58:51 --> Output Class Initialized
INFO - 2023-05-16 07:58:51 --> Security Class Initialized
INFO - 2023-05-16 07:58:51 --> Input Class Initialized
INFO - 2023-05-16 07:58:51 --> Language Class Initialized
INFO - 2023-05-16 07:58:51 --> Loader Class Initialized
INFO - 2023-05-16 07:58:51 --> Helper loaded: url_helper
INFO - 2023-05-16 07:58:51 --> Helper loaded: form_helper
INFO - 2023-05-16 07:58:51 --> Database Driver Class Initialized
INFO - 2023-05-16 07:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:58:52 --> Form Validation Class Initialized
INFO - 2023-05-16 07:58:52 --> Controller Class Initialized
INFO - 2023-05-16 07:58:52 --> Model "m_datatrain" initialized
INFO - 2023-05-16 07:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-16 07:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 07:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-16 07:58:52 --> Final output sent to browser
INFO - 2023-05-16 07:59:02 --> Config Class Initialized
INFO - 2023-05-16 07:59:02 --> Hooks Class Initialized
INFO - 2023-05-16 07:59:02 --> Utf8 Class Initialized
INFO - 2023-05-16 07:59:02 --> URI Class Initialized
INFO - 2023-05-16 07:59:02 --> Router Class Initialized
INFO - 2023-05-16 07:59:02 --> Output Class Initialized
INFO - 2023-05-16 07:59:02 --> Security Class Initialized
INFO - 2023-05-16 07:59:02 --> Input Class Initialized
INFO - 2023-05-16 07:59:02 --> Language Class Initialized
INFO - 2023-05-16 07:59:02 --> Loader Class Initialized
INFO - 2023-05-16 07:59:02 --> Helper loaded: url_helper
INFO - 2023-05-16 07:59:02 --> Helper loaded: form_helper
INFO - 2023-05-16 07:59:02 --> Database Driver Class Initialized
INFO - 2023-05-16 07:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-16 07:59:02 --> Form Validation Class Initialized
INFO - 2023-05-16 07:59:02 --> Controller Class Initialized
INFO - 2023-05-16 07:59:02 --> Model "m_datatest" initialized
INFO - 2023-05-16 07:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-16 07:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-16 07:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-16 07:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-16 07:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-16 07:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-16 07:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-16 07:59:02 --> Final output sent to browser
