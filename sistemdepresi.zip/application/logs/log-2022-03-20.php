<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-20 08:29:19 --> Config Class Initialized
INFO - 2022-03-20 08:29:19 --> Hooks Class Initialized
INFO - 2022-03-20 08:29:20 --> Utf8 Class Initialized
INFO - 2022-03-20 08:29:20 --> URI Class Initialized
INFO - 2022-03-20 08:29:20 --> Router Class Initialized
INFO - 2022-03-20 08:29:20 --> Output Class Initialized
INFO - 2022-03-20 08:29:20 --> Security Class Initialized
INFO - 2022-03-20 08:29:20 --> Input Class Initialized
INFO - 2022-03-20 08:29:20 --> Language Class Initialized
INFO - 2022-03-20 08:29:20 --> Loader Class Initialized
INFO - 2022-03-20 08:29:21 --> Helper loaded: url_helper
INFO - 2022-03-20 08:29:21 --> Helper loaded: form_helper
INFO - 2022-03-20 08:29:21 --> Database Driver Class Initialized
INFO - 2022-03-20 08:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:29:21 --> Form Validation Class Initialized
INFO - 2022-03-20 08:29:21 --> Controller Class Initialized
INFO - 2022-03-20 08:29:21 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:29:21 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 08:29:21 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 08:29:21 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 08:29:21 --> Final output sent to browser
INFO - 2022-03-20 08:35:42 --> Config Class Initialized
INFO - 2022-03-20 08:35:42 --> Hooks Class Initialized
INFO - 2022-03-20 08:35:42 --> Utf8 Class Initialized
INFO - 2022-03-20 08:35:42 --> URI Class Initialized
INFO - 2022-03-20 08:35:42 --> Router Class Initialized
INFO - 2022-03-20 08:35:42 --> Output Class Initialized
INFO - 2022-03-20 08:35:42 --> Security Class Initialized
INFO - 2022-03-20 08:35:42 --> Input Class Initialized
INFO - 2022-03-20 08:35:42 --> Language Class Initialized
INFO - 2022-03-20 08:35:42 --> Loader Class Initialized
INFO - 2022-03-20 08:35:42 --> Helper loaded: url_helper
INFO - 2022-03-20 08:35:42 --> Helper loaded: form_helper
INFO - 2022-03-20 08:35:42 --> Database Driver Class Initialized
INFO - 2022-03-20 08:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:35:42 --> Form Validation Class Initialized
INFO - 2022-03-20 08:35:42 --> Controller Class Initialized
INFO - 2022-03-20 08:35:42 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:35:42 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 08:35:42 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 08:35:42 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 08:35:42 --> Final output sent to browser
INFO - 2022-03-20 08:37:00 --> Config Class Initialized
INFO - 2022-03-20 08:37:00 --> Hooks Class Initialized
INFO - 2022-03-20 08:37:00 --> Utf8 Class Initialized
INFO - 2022-03-20 08:37:00 --> URI Class Initialized
INFO - 2022-03-20 08:37:00 --> Router Class Initialized
INFO - 2022-03-20 08:37:00 --> Output Class Initialized
INFO - 2022-03-20 08:37:00 --> Security Class Initialized
INFO - 2022-03-20 08:37:00 --> Input Class Initialized
INFO - 2022-03-20 08:37:00 --> Language Class Initialized
INFO - 2022-03-20 08:37:00 --> Loader Class Initialized
INFO - 2022-03-20 08:37:00 --> Helper loaded: url_helper
INFO - 2022-03-20 08:37:00 --> Helper loaded: form_helper
INFO - 2022-03-20 08:37:00 --> Database Driver Class Initialized
INFO - 2022-03-20 08:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:37:00 --> Form Validation Class Initialized
INFO - 2022-03-20 08:37:00 --> Controller Class Initialized
INFO - 2022-03-20 08:37:00 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:37:00 --> Config Class Initialized
INFO - 2022-03-20 08:37:00 --> Hooks Class Initialized
INFO - 2022-03-20 08:37:00 --> Utf8 Class Initialized
INFO - 2022-03-20 08:37:00 --> URI Class Initialized
INFO - 2022-03-20 08:37:00 --> Router Class Initialized
INFO - 2022-03-20 08:37:00 --> Output Class Initialized
INFO - 2022-03-20 08:37:00 --> Security Class Initialized
INFO - 2022-03-20 08:37:00 --> Input Class Initialized
INFO - 2022-03-20 08:37:00 --> Language Class Initialized
INFO - 2022-03-20 08:37:00 --> Loader Class Initialized
INFO - 2022-03-20 08:37:00 --> Helper loaded: url_helper
INFO - 2022-03-20 08:37:00 --> Helper loaded: form_helper
INFO - 2022-03-20 08:37:00 --> Database Driver Class Initialized
INFO - 2022-03-20 08:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:37:00 --> Form Validation Class Initialized
INFO - 2022-03-20 08:37:00 --> Controller Class Initialized
INFO - 2022-03-20 08:37:00 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:37:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 08:37:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 08:37:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 08:37:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 08:37:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 08:37:01 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 08:37:01 --> Final output sent to browser
INFO - 2022-03-20 08:43:17 --> Config Class Initialized
INFO - 2022-03-20 08:43:17 --> Hooks Class Initialized
INFO - 2022-03-20 08:43:17 --> Utf8 Class Initialized
INFO - 2022-03-20 08:43:17 --> URI Class Initialized
INFO - 2022-03-20 08:43:17 --> Router Class Initialized
INFO - 2022-03-20 08:43:17 --> Output Class Initialized
INFO - 2022-03-20 08:43:17 --> Security Class Initialized
INFO - 2022-03-20 08:43:17 --> Input Class Initialized
INFO - 2022-03-20 08:43:17 --> Language Class Initialized
INFO - 2022-03-20 08:43:17 --> Loader Class Initialized
INFO - 2022-03-20 08:43:17 --> Helper loaded: url_helper
INFO - 2022-03-20 08:43:17 --> Helper loaded: form_helper
INFO - 2022-03-20 08:43:17 --> Database Driver Class Initialized
INFO - 2022-03-20 08:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:43:17 --> Form Validation Class Initialized
INFO - 2022-03-20 08:43:17 --> Controller Class Initialized
INFO - 2022-03-20 08:43:17 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:43:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 08:43:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 08:43:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 08:43:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 08:43:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 08:43:17 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 08:43:17 --> Final output sent to browser
INFO - 2022-03-20 08:43:46 --> Config Class Initialized
INFO - 2022-03-20 08:43:46 --> Hooks Class Initialized
INFO - 2022-03-20 08:43:46 --> Utf8 Class Initialized
INFO - 2022-03-20 08:43:46 --> URI Class Initialized
INFO - 2022-03-20 08:43:46 --> Router Class Initialized
INFO - 2022-03-20 08:43:46 --> Output Class Initialized
INFO - 2022-03-20 08:43:46 --> Security Class Initialized
INFO - 2022-03-20 08:43:46 --> Input Class Initialized
INFO - 2022-03-20 08:43:46 --> Language Class Initialized
INFO - 2022-03-20 08:43:46 --> Loader Class Initialized
INFO - 2022-03-20 08:43:46 --> Helper loaded: url_helper
INFO - 2022-03-20 08:43:46 --> Helper loaded: form_helper
INFO - 2022-03-20 08:43:46 --> Database Driver Class Initialized
INFO - 2022-03-20 08:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:43:46 --> Form Validation Class Initialized
INFO - 2022-03-20 08:43:46 --> Controller Class Initialized
INFO - 2022-03-20 08:43:46 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:44:21 --> Config Class Initialized
INFO - 2022-03-20 08:44:21 --> Hooks Class Initialized
INFO - 2022-03-20 08:44:21 --> Utf8 Class Initialized
INFO - 2022-03-20 08:44:21 --> URI Class Initialized
INFO - 2022-03-20 08:44:21 --> Router Class Initialized
INFO - 2022-03-20 08:44:21 --> Output Class Initialized
INFO - 2022-03-20 08:44:21 --> Security Class Initialized
INFO - 2022-03-20 08:44:22 --> Input Class Initialized
INFO - 2022-03-20 08:44:22 --> Language Class Initialized
INFO - 2022-03-20 08:44:22 --> Loader Class Initialized
INFO - 2022-03-20 08:44:22 --> Helper loaded: url_helper
INFO - 2022-03-20 08:44:22 --> Helper loaded: form_helper
INFO - 2022-03-20 08:44:22 --> Database Driver Class Initialized
INFO - 2022-03-20 08:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:44:22 --> Form Validation Class Initialized
INFO - 2022-03-20 08:44:22 --> Controller Class Initialized
INFO - 2022-03-20 08:44:22 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:44:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 08:44:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 08:44:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 08:44:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 08:44:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 08:44:22 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 08:44:22 --> Final output sent to browser
INFO - 2022-03-20 08:45:12 --> Config Class Initialized
INFO - 2022-03-20 08:45:12 --> Hooks Class Initialized
INFO - 2022-03-20 08:45:12 --> Utf8 Class Initialized
INFO - 2022-03-20 08:45:12 --> URI Class Initialized
INFO - 2022-03-20 08:45:12 --> Router Class Initialized
INFO - 2022-03-20 08:45:12 --> Output Class Initialized
INFO - 2022-03-20 08:45:12 --> Security Class Initialized
INFO - 2022-03-20 08:45:12 --> Input Class Initialized
INFO - 2022-03-20 08:45:12 --> Language Class Initialized
INFO - 2022-03-20 08:45:12 --> Loader Class Initialized
INFO - 2022-03-20 08:45:12 --> Helper loaded: url_helper
INFO - 2022-03-20 08:45:12 --> Helper loaded: form_helper
INFO - 2022-03-20 08:45:12 --> Database Driver Class Initialized
INFO - 2022-03-20 08:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:45:12 --> Form Validation Class Initialized
INFO - 2022-03-20 08:45:12 --> Controller Class Initialized
INFO - 2022-03-20 08:45:12 --> Model "M_todo_group" initialized
INFO - 2022-03-20 08:45:12 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 08:45:12 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:45:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 08:45:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 08:45:12 --> File loaded: C:\laragon\www\list-todo\application\views\todo_group/v_index.php
INFO - 2022-03-20 08:45:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 08:45:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 08:45:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 08:45:12 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 08:45:12 --> Final output sent to browser
INFO - 2022-03-20 08:45:17 --> Config Class Initialized
INFO - 2022-03-20 08:45:17 --> Hooks Class Initialized
INFO - 2022-03-20 08:45:17 --> Utf8 Class Initialized
INFO - 2022-03-20 08:45:17 --> URI Class Initialized
INFO - 2022-03-20 08:45:17 --> Router Class Initialized
INFO - 2022-03-20 08:45:17 --> Output Class Initialized
INFO - 2022-03-20 08:45:17 --> Security Class Initialized
INFO - 2022-03-20 08:45:17 --> Input Class Initialized
INFO - 2022-03-20 08:45:17 --> Language Class Initialized
INFO - 2022-03-20 08:45:17 --> Loader Class Initialized
INFO - 2022-03-20 08:45:17 --> Helper loaded: url_helper
INFO - 2022-03-20 08:45:17 --> Helper loaded: form_helper
INFO - 2022-03-20 08:45:17 --> Database Driver Class Initialized
INFO - 2022-03-20 08:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:45:17 --> Form Validation Class Initialized
INFO - 2022-03-20 08:45:17 --> Controller Class Initialized
INFO - 2022-03-20 08:45:17 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:45:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 08:45:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 08:45:17 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-20 08:45:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 08:45:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 08:45:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 08:45:17 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 08:45:17 --> Final output sent to browser
INFO - 2022-03-20 08:45:45 --> Config Class Initialized
INFO - 2022-03-20 08:45:45 --> Hooks Class Initialized
INFO - 2022-03-20 08:45:45 --> Utf8 Class Initialized
INFO - 2022-03-20 08:45:45 --> URI Class Initialized
INFO - 2022-03-20 08:45:45 --> Router Class Initialized
INFO - 2022-03-20 08:45:45 --> Output Class Initialized
INFO - 2022-03-20 08:45:45 --> Security Class Initialized
INFO - 2022-03-20 08:45:45 --> Input Class Initialized
INFO - 2022-03-20 08:45:45 --> Language Class Initialized
INFO - 2022-03-20 08:45:45 --> Loader Class Initialized
INFO - 2022-03-20 08:45:45 --> Helper loaded: url_helper
INFO - 2022-03-20 08:45:45 --> Helper loaded: form_helper
INFO - 2022-03-20 08:45:45 --> Database Driver Class Initialized
INFO - 2022-03-20 08:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:45:46 --> Form Validation Class Initialized
INFO - 2022-03-20 08:45:46 --> Controller Class Initialized
INFO - 2022-03-20 08:45:46 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:45:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 08:45:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 08:45:46 --> File loaded: C:\laragon\www\list-todo\application\views\todo_admin/v_index.php
INFO - 2022-03-20 08:45:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 08:45:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 08:45:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 08:45:46 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 08:45:46 --> Final output sent to browser
INFO - 2022-03-20 08:45:48 --> Config Class Initialized
INFO - 2022-03-20 08:45:48 --> Hooks Class Initialized
INFO - 2022-03-20 08:45:48 --> Utf8 Class Initialized
INFO - 2022-03-20 08:45:48 --> URI Class Initialized
INFO - 2022-03-20 08:45:48 --> Router Class Initialized
INFO - 2022-03-20 08:45:48 --> Output Class Initialized
INFO - 2022-03-20 08:45:48 --> Security Class Initialized
INFO - 2022-03-20 08:45:48 --> Input Class Initialized
INFO - 2022-03-20 08:45:48 --> Language Class Initialized
INFO - 2022-03-20 08:45:48 --> Loader Class Initialized
INFO - 2022-03-20 08:45:48 --> Helper loaded: url_helper
INFO - 2022-03-20 08:45:48 --> Helper loaded: form_helper
INFO - 2022-03-20 08:45:48 --> Database Driver Class Initialized
INFO - 2022-03-20 08:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:45:48 --> Form Validation Class Initialized
INFO - 2022-03-20 08:45:48 --> Controller Class Initialized
INFO - 2022-03-20 08:45:48 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 08:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 08:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\todo_admin/v_index.php
INFO - 2022-03-20 08:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 08:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 08:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 08:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 08:45:48 --> Final output sent to browser
INFO - 2022-03-20 08:45:53 --> Config Class Initialized
INFO - 2022-03-20 08:45:53 --> Hooks Class Initialized
INFO - 2022-03-20 08:45:53 --> Utf8 Class Initialized
INFO - 2022-03-20 08:45:53 --> URI Class Initialized
INFO - 2022-03-20 08:45:53 --> Router Class Initialized
INFO - 2022-03-20 08:45:53 --> Output Class Initialized
INFO - 2022-03-20 08:45:53 --> Security Class Initialized
INFO - 2022-03-20 08:45:53 --> Input Class Initialized
INFO - 2022-03-20 08:45:53 --> Language Class Initialized
INFO - 2022-03-20 08:45:53 --> Loader Class Initialized
INFO - 2022-03-20 08:45:53 --> Helper loaded: url_helper
INFO - 2022-03-20 08:45:53 --> Helper loaded: form_helper
INFO - 2022-03-20 08:45:53 --> Database Driver Class Initialized
INFO - 2022-03-20 08:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:45:53 --> Form Validation Class Initialized
INFO - 2022-03-20 08:45:53 --> Controller Class Initialized
INFO - 2022-03-20 08:45:53 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:45:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 08:45:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 08:45:53 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_index.php
INFO - 2022-03-20 08:45:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 08:45:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 08:45:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 08:45:53 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 08:45:53 --> Final output sent to browser
INFO - 2022-03-20 08:59:33 --> Config Class Initialized
INFO - 2022-03-20 08:59:33 --> Hooks Class Initialized
INFO - 2022-03-20 08:59:33 --> Utf8 Class Initialized
INFO - 2022-03-20 08:59:33 --> URI Class Initialized
INFO - 2022-03-20 08:59:33 --> Router Class Initialized
INFO - 2022-03-20 08:59:33 --> Output Class Initialized
INFO - 2022-03-20 08:59:33 --> Security Class Initialized
INFO - 2022-03-20 08:59:33 --> Input Class Initialized
INFO - 2022-03-20 08:59:33 --> Language Class Initialized
INFO - 2022-03-20 08:59:33 --> Loader Class Initialized
INFO - 2022-03-20 08:59:33 --> Helper loaded: url_helper
INFO - 2022-03-20 08:59:33 --> Helper loaded: form_helper
INFO - 2022-03-20 08:59:33 --> Database Driver Class Initialized
INFO - 2022-03-20 08:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:59:33 --> Form Validation Class Initialized
INFO - 2022-03-20 08:59:33 --> Controller Class Initialized
INFO - 2022-03-20 08:59:33 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:59:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 08:59:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 08:59:33 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_tambah.php
INFO - 2022-03-20 08:59:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 08:59:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 08:59:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 08:59:33 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 08:59:33 --> Final output sent to browser
INFO - 2022-03-20 08:59:49 --> Config Class Initialized
INFO - 2022-03-20 08:59:49 --> Hooks Class Initialized
INFO - 2022-03-20 08:59:49 --> Utf8 Class Initialized
INFO - 2022-03-20 08:59:49 --> URI Class Initialized
INFO - 2022-03-20 08:59:49 --> Router Class Initialized
INFO - 2022-03-20 08:59:49 --> Output Class Initialized
INFO - 2022-03-20 08:59:49 --> Security Class Initialized
INFO - 2022-03-20 08:59:49 --> Input Class Initialized
INFO - 2022-03-20 08:59:49 --> Language Class Initialized
INFO - 2022-03-20 08:59:49 --> Loader Class Initialized
INFO - 2022-03-20 08:59:49 --> Helper loaded: url_helper
INFO - 2022-03-20 08:59:50 --> Helper loaded: form_helper
INFO - 2022-03-20 08:59:50 --> Database Driver Class Initialized
INFO - 2022-03-20 08:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:59:50 --> Form Validation Class Initialized
INFO - 2022-03-20 08:59:50 --> Controller Class Initialized
INFO - 2022-03-20 08:59:50 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:59:50 --> Config Class Initialized
INFO - 2022-03-20 08:59:50 --> Hooks Class Initialized
INFO - 2022-03-20 08:59:50 --> Utf8 Class Initialized
INFO - 2022-03-20 08:59:50 --> URI Class Initialized
INFO - 2022-03-20 08:59:50 --> Router Class Initialized
INFO - 2022-03-20 08:59:50 --> Output Class Initialized
INFO - 2022-03-20 08:59:50 --> Security Class Initialized
INFO - 2022-03-20 08:59:50 --> Input Class Initialized
INFO - 2022-03-20 08:59:50 --> Language Class Initialized
INFO - 2022-03-20 08:59:50 --> Loader Class Initialized
INFO - 2022-03-20 08:59:50 --> Helper loaded: url_helper
INFO - 2022-03-20 08:59:50 --> Helper loaded: form_helper
INFO - 2022-03-20 08:59:50 --> Database Driver Class Initialized
INFO - 2022-03-20 08:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 08:59:50 --> Form Validation Class Initialized
INFO - 2022-03-20 08:59:50 --> Controller Class Initialized
INFO - 2022-03-20 08:59:50 --> Model "M_tutor" initialized
INFO - 2022-03-20 08:59:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 08:59:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 08:59:50 --> File loaded: C:\laragon\www\list-todo\application\views\todo_tutor/v_tambah.php
INFO - 2022-03-20 08:59:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 08:59:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 08:59:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 08:59:50 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 08:59:50 --> Final output sent to browser
INFO - 2022-03-20 09:00:14 --> Config Class Initialized
INFO - 2022-03-20 09:00:14 --> Hooks Class Initialized
INFO - 2022-03-20 09:00:14 --> Utf8 Class Initialized
INFO - 2022-03-20 09:00:14 --> URI Class Initialized
INFO - 2022-03-20 09:00:14 --> Router Class Initialized
INFO - 2022-03-20 09:00:14 --> Output Class Initialized
INFO - 2022-03-20 09:00:14 --> Security Class Initialized
INFO - 2022-03-20 09:00:14 --> Input Class Initialized
INFO - 2022-03-20 09:00:14 --> Language Class Initialized
INFO - 2022-03-20 09:00:14 --> Loader Class Initialized
INFO - 2022-03-20 09:00:14 --> Helper loaded: url_helper
INFO - 2022-03-20 09:00:14 --> Helper loaded: form_helper
INFO - 2022-03-20 09:00:14 --> Database Driver Class Initialized
INFO - 2022-03-20 09:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:00:14 --> Form Validation Class Initialized
INFO - 2022-03-20 09:00:14 --> Controller Class Initialized
INFO - 2022-03-20 09:00:14 --> Model "M_tutor" initialized
INFO - 2022-03-20 09:00:14 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 09:00:14 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 09:00:14 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 09:00:14 --> Final output sent to browser
INFO - 2022-03-20 09:00:18 --> Config Class Initialized
INFO - 2022-03-20 09:00:18 --> Hooks Class Initialized
INFO - 2022-03-20 09:00:18 --> Utf8 Class Initialized
INFO - 2022-03-20 09:00:18 --> URI Class Initialized
INFO - 2022-03-20 09:00:18 --> Router Class Initialized
INFO - 2022-03-20 09:00:18 --> Output Class Initialized
INFO - 2022-03-20 09:00:18 --> Security Class Initialized
INFO - 2022-03-20 09:00:18 --> Input Class Initialized
INFO - 2022-03-20 09:00:18 --> Language Class Initialized
INFO - 2022-03-20 09:00:18 --> Loader Class Initialized
INFO - 2022-03-20 09:00:18 --> Helper loaded: url_helper
INFO - 2022-03-20 09:00:18 --> Helper loaded: form_helper
INFO - 2022-03-20 09:00:18 --> Database Driver Class Initialized
INFO - 2022-03-20 09:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:00:18 --> Form Validation Class Initialized
INFO - 2022-03-20 09:00:18 --> Controller Class Initialized
INFO - 2022-03-20 09:00:18 --> Model "M_tutor" initialized
INFO - 2022-03-20 09:00:18 --> Config Class Initialized
INFO - 2022-03-20 09:00:18 --> Hooks Class Initialized
INFO - 2022-03-20 09:00:18 --> Utf8 Class Initialized
INFO - 2022-03-20 09:00:18 --> URI Class Initialized
INFO - 2022-03-20 09:00:18 --> Router Class Initialized
INFO - 2022-03-20 09:00:18 --> Output Class Initialized
INFO - 2022-03-20 09:00:18 --> Security Class Initialized
INFO - 2022-03-20 09:00:18 --> Input Class Initialized
INFO - 2022-03-20 09:00:18 --> Language Class Initialized
INFO - 2022-03-20 09:00:18 --> Loader Class Initialized
INFO - 2022-03-20 09:00:18 --> Helper loaded: url_helper
INFO - 2022-03-20 09:00:18 --> Helper loaded: form_helper
INFO - 2022-03-20 09:00:18 --> Database Driver Class Initialized
INFO - 2022-03-20 09:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:00:18 --> Form Validation Class Initialized
INFO - 2022-03-20 09:00:18 --> Controller Class Initialized
INFO - 2022-03-20 09:00:18 --> Model "M_tutor" initialized
INFO - 2022-03-20 09:00:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 09:00:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 09:00:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 09:00:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 09:00:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 09:00:18 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 09:00:18 --> Final output sent to browser
INFO - 2022-03-20 09:00:26 --> Config Class Initialized
INFO - 2022-03-20 09:00:26 --> Hooks Class Initialized
INFO - 2022-03-20 09:00:26 --> Utf8 Class Initialized
INFO - 2022-03-20 09:00:26 --> URI Class Initialized
INFO - 2022-03-20 09:00:26 --> Router Class Initialized
INFO - 2022-03-20 09:00:26 --> Output Class Initialized
INFO - 2022-03-20 09:00:26 --> Security Class Initialized
INFO - 2022-03-20 09:00:26 --> Input Class Initialized
INFO - 2022-03-20 09:00:26 --> Language Class Initialized
INFO - 2022-03-20 09:00:26 --> Loader Class Initialized
INFO - 2022-03-20 09:00:26 --> Helper loaded: url_helper
INFO - 2022-03-20 09:00:26 --> Helper loaded: form_helper
INFO - 2022-03-20 09:00:26 --> Database Driver Class Initialized
INFO - 2022-03-20 09:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:00:26 --> Form Validation Class Initialized
INFO - 2022-03-20 09:00:26 --> Controller Class Initialized
INFO - 2022-03-20 09:00:26 --> Model "M_tutor" initialized
ERROR - 2022-03-20 09:00:26 --> 404 Page Not Found: 
INFO - 2022-03-20 09:00:26 --> Config Class Initialized
INFO - 2022-03-20 09:00:26 --> Hooks Class Initialized
INFO - 2022-03-20 09:00:26 --> Utf8 Class Initialized
INFO - 2022-03-20 09:00:26 --> URI Class Initialized
INFO - 2022-03-20 09:00:26 --> Router Class Initialized
INFO - 2022-03-20 09:00:26 --> Output Class Initialized
INFO - 2022-03-20 09:00:26 --> Security Class Initialized
INFO - 2022-03-20 09:00:26 --> Input Class Initialized
INFO - 2022-03-20 09:00:26 --> Language Class Initialized
ERROR - 2022-03-20 09:00:26 --> 404 Page Not Found: Faviconico/index
INFO - 2022-03-20 09:00:29 --> Config Class Initialized
INFO - 2022-03-20 09:00:29 --> Hooks Class Initialized
INFO - 2022-03-20 09:00:29 --> Utf8 Class Initialized
INFO - 2022-03-20 09:00:29 --> URI Class Initialized
INFO - 2022-03-20 09:00:29 --> Router Class Initialized
INFO - 2022-03-20 09:00:29 --> Output Class Initialized
INFO - 2022-03-20 09:00:29 --> Security Class Initialized
INFO - 2022-03-20 09:00:29 --> Input Class Initialized
INFO - 2022-03-20 09:00:29 --> Language Class Initialized
INFO - 2022-03-20 09:00:29 --> Loader Class Initialized
INFO - 2022-03-20 09:00:29 --> Helper loaded: url_helper
INFO - 2022-03-20 09:00:29 --> Helper loaded: form_helper
INFO - 2022-03-20 09:00:29 --> Database Driver Class Initialized
INFO - 2022-03-20 09:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:00:29 --> Form Validation Class Initialized
INFO - 2022-03-20 09:00:29 --> Controller Class Initialized
INFO - 2022-03-20 09:00:29 --> Model "M_tutor" initialized
ERROR - 2022-03-20 09:00:29 --> 404 Page Not Found: 
INFO - 2022-03-20 09:00:33 --> Config Class Initialized
INFO - 2022-03-20 09:00:33 --> Hooks Class Initialized
INFO - 2022-03-20 09:00:33 --> Utf8 Class Initialized
INFO - 2022-03-20 09:00:33 --> URI Class Initialized
INFO - 2022-03-20 09:00:33 --> Router Class Initialized
INFO - 2022-03-20 09:00:33 --> Output Class Initialized
INFO - 2022-03-20 09:00:33 --> Security Class Initialized
INFO - 2022-03-20 09:00:33 --> Input Class Initialized
INFO - 2022-03-20 09:00:33 --> Language Class Initialized
INFO - 2022-03-20 09:00:33 --> Loader Class Initialized
INFO - 2022-03-20 09:00:33 --> Helper loaded: url_helper
INFO - 2022-03-20 09:00:33 --> Helper loaded: form_helper
INFO - 2022-03-20 09:00:33 --> Database Driver Class Initialized
INFO - 2022-03-20 09:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:00:33 --> Form Validation Class Initialized
INFO - 2022-03-20 09:00:33 --> Controller Class Initialized
INFO - 2022-03-20 09:00:33 --> Model "M_tutor" initialized
ERROR - 2022-03-20 09:00:33 --> 404 Page Not Found: 
INFO - 2022-03-20 09:44:57 --> Config Class Initialized
INFO - 2022-03-20 09:44:57 --> Hooks Class Initialized
INFO - 2022-03-20 09:44:57 --> Utf8 Class Initialized
INFO - 2022-03-20 09:44:57 --> URI Class Initialized
INFO - 2022-03-20 09:44:57 --> Router Class Initialized
INFO - 2022-03-20 09:44:57 --> Output Class Initialized
INFO - 2022-03-20 09:44:57 --> Security Class Initialized
INFO - 2022-03-20 09:44:57 --> Input Class Initialized
INFO - 2022-03-20 09:44:57 --> Language Class Initialized
INFO - 2022-03-20 09:44:57 --> Loader Class Initialized
INFO - 2022-03-20 09:44:57 --> Helper loaded: url_helper
INFO - 2022-03-20 09:44:57 --> Helper loaded: form_helper
INFO - 2022-03-20 09:44:57 --> Database Driver Class Initialized
INFO - 2022-03-20 09:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:44:57 --> Form Validation Class Initialized
INFO - 2022-03-20 09:44:57 --> Controller Class Initialized
INFO - 2022-03-20 09:44:57 --> Model "M_tutor" initialized
ERROR - 2022-03-20 09:44:57 --> 404 Page Not Found: 
INFO - 2022-03-20 09:44:58 --> Config Class Initialized
INFO - 2022-03-20 09:44:58 --> Hooks Class Initialized
INFO - 2022-03-20 09:44:58 --> Utf8 Class Initialized
INFO - 2022-03-20 09:44:58 --> URI Class Initialized
INFO - 2022-03-20 09:44:58 --> Router Class Initialized
INFO - 2022-03-20 09:44:58 --> Output Class Initialized
INFO - 2022-03-20 09:44:58 --> Security Class Initialized
INFO - 2022-03-20 09:44:58 --> Input Class Initialized
INFO - 2022-03-20 09:44:58 --> Language Class Initialized
INFO - 2022-03-20 09:44:58 --> Loader Class Initialized
INFO - 2022-03-20 09:44:58 --> Helper loaded: url_helper
INFO - 2022-03-20 09:44:58 --> Helper loaded: form_helper
INFO - 2022-03-20 09:44:58 --> Database Driver Class Initialized
INFO - 2022-03-20 09:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:44:58 --> Form Validation Class Initialized
INFO - 2022-03-20 09:44:58 --> Controller Class Initialized
INFO - 2022-03-20 09:44:58 --> Model "M_tutor" initialized
ERROR - 2022-03-20 09:44:58 --> 404 Page Not Found: 
INFO - 2022-03-20 09:44:59 --> Config Class Initialized
INFO - 2022-03-20 09:44:59 --> Hooks Class Initialized
INFO - 2022-03-20 09:44:59 --> Utf8 Class Initialized
INFO - 2022-03-20 09:44:59 --> URI Class Initialized
INFO - 2022-03-20 09:44:59 --> Router Class Initialized
INFO - 2022-03-20 09:44:59 --> Output Class Initialized
INFO - 2022-03-20 09:44:59 --> Security Class Initialized
INFO - 2022-03-20 09:44:59 --> Input Class Initialized
INFO - 2022-03-20 09:44:59 --> Language Class Initialized
INFO - 2022-03-20 09:44:59 --> Loader Class Initialized
INFO - 2022-03-20 09:44:59 --> Helper loaded: url_helper
INFO - 2022-03-20 09:44:59 --> Helper loaded: form_helper
INFO - 2022-03-20 09:44:59 --> Database Driver Class Initialized
INFO - 2022-03-20 09:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:44:59 --> Form Validation Class Initialized
INFO - 2022-03-20 09:44:59 --> Controller Class Initialized
INFO - 2022-03-20 09:44:59 --> Model "M_tutor" initialized
INFO - 2022-03-20 09:44:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 09:44:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 09:44:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 09:44:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 09:44:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 09:44:59 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 09:44:59 --> Final output sent to browser
INFO - 2022-03-20 09:45:01 --> Config Class Initialized
INFO - 2022-03-20 09:45:01 --> Hooks Class Initialized
INFO - 2022-03-20 09:45:01 --> Utf8 Class Initialized
INFO - 2022-03-20 09:45:01 --> URI Class Initialized
INFO - 2022-03-20 09:45:01 --> Router Class Initialized
INFO - 2022-03-20 09:45:01 --> Output Class Initialized
INFO - 2022-03-20 09:45:01 --> Security Class Initialized
INFO - 2022-03-20 09:45:01 --> Input Class Initialized
INFO - 2022-03-20 09:45:01 --> Language Class Initialized
INFO - 2022-03-20 09:45:01 --> Loader Class Initialized
INFO - 2022-03-20 09:45:01 --> Helper loaded: url_helper
INFO - 2022-03-20 09:45:01 --> Helper loaded: form_helper
INFO - 2022-03-20 09:45:01 --> Database Driver Class Initialized
INFO - 2022-03-20 09:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:45:02 --> Form Validation Class Initialized
INFO - 2022-03-20 09:45:02 --> Controller Class Initialized
INFO - 2022-03-20 09:45:02 --> Model "M_todo_list" initialized
INFO - 2022-03-20 09:45:02 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 09:45:02 --> Model "M_todo_group" initialized
INFO - 2022-03-20 09:45:02 --> Model "M_todo_task" initialized
INFO - 2022-03-20 09:45:02 --> Model "M_tutor" initialized
INFO - 2022-03-20 09:45:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 09:45:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 09:45:02 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 09:45:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 09:45:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 09:45:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 09:45:02 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 09:45:02 --> Final output sent to browser
INFO - 2022-03-20 09:47:07 --> Config Class Initialized
INFO - 2022-03-20 09:47:07 --> Hooks Class Initialized
INFO - 2022-03-20 09:47:07 --> Utf8 Class Initialized
INFO - 2022-03-20 09:47:07 --> URI Class Initialized
INFO - 2022-03-20 09:47:07 --> Router Class Initialized
INFO - 2022-03-20 09:47:07 --> Output Class Initialized
INFO - 2022-03-20 09:47:07 --> Security Class Initialized
INFO - 2022-03-20 09:47:07 --> Input Class Initialized
INFO - 2022-03-20 09:47:07 --> Language Class Initialized
INFO - 2022-03-20 09:47:07 --> Loader Class Initialized
INFO - 2022-03-20 09:47:07 --> Helper loaded: url_helper
INFO - 2022-03-20 09:47:07 --> Helper loaded: form_helper
INFO - 2022-03-20 09:47:07 --> Database Driver Class Initialized
INFO - 2022-03-20 09:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:47:07 --> Form Validation Class Initialized
INFO - 2022-03-20 09:47:07 --> Controller Class Initialized
INFO - 2022-03-20 09:47:07 --> Model "M_tutor" initialized
ERROR - 2022-03-20 09:47:07 --> Severity: Parsing Error --> syntax error, unexpected '/' C:\laragon\www\list-todo\application\views\home.php 31
INFO - 2022-03-20 09:47:15 --> Config Class Initialized
INFO - 2022-03-20 09:47:15 --> Hooks Class Initialized
INFO - 2022-03-20 09:47:15 --> Utf8 Class Initialized
INFO - 2022-03-20 09:47:15 --> URI Class Initialized
INFO - 2022-03-20 09:47:15 --> Router Class Initialized
INFO - 2022-03-20 09:47:15 --> Output Class Initialized
INFO - 2022-03-20 09:47:15 --> Security Class Initialized
INFO - 2022-03-20 09:47:15 --> Input Class Initialized
INFO - 2022-03-20 09:47:15 --> Language Class Initialized
INFO - 2022-03-20 09:47:15 --> Loader Class Initialized
INFO - 2022-03-20 09:47:15 --> Helper loaded: url_helper
INFO - 2022-03-20 09:47:15 --> Helper loaded: form_helper
INFO - 2022-03-20 09:47:15 --> Database Driver Class Initialized
INFO - 2022-03-20 09:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:47:15 --> Form Validation Class Initialized
INFO - 2022-03-20 09:47:15 --> Controller Class Initialized
INFO - 2022-03-20 09:47:15 --> Model "M_tutor" initialized
INFO - 2022-03-20 09:47:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 09:47:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 09:47:15 --> Severity: Error --> Call to undefined method CI_Loader::session() C:\laragon\www\list-todo\application\views\home.php 30
INFO - 2022-03-20 09:47:22 --> Config Class Initialized
INFO - 2022-03-20 09:47:22 --> Hooks Class Initialized
INFO - 2022-03-20 09:47:22 --> Utf8 Class Initialized
INFO - 2022-03-20 09:47:22 --> URI Class Initialized
INFO - 2022-03-20 09:47:22 --> Router Class Initialized
INFO - 2022-03-20 09:47:22 --> Output Class Initialized
INFO - 2022-03-20 09:47:22 --> Security Class Initialized
INFO - 2022-03-20 09:47:22 --> Input Class Initialized
INFO - 2022-03-20 09:47:22 --> Language Class Initialized
INFO - 2022-03-20 09:47:22 --> Loader Class Initialized
INFO - 2022-03-20 09:47:22 --> Helper loaded: url_helper
INFO - 2022-03-20 09:47:22 --> Helper loaded: form_helper
INFO - 2022-03-20 09:47:22 --> Database Driver Class Initialized
INFO - 2022-03-20 09:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 09:47:22 --> Form Validation Class Initialized
INFO - 2022-03-20 09:47:22 --> Controller Class Initialized
INFO - 2022-03-20 09:47:22 --> Model "M_tutor" initialized
INFO - 2022-03-20 09:47:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 09:47:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 09:47:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 09:47:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 09:47:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 09:47:22 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 09:47:22 --> Final output sent to browser
INFO - 2022-03-20 10:50:00 --> Config Class Initialized
INFO - 2022-03-20 10:50:00 --> Hooks Class Initialized
INFO - 2022-03-20 10:50:00 --> Utf8 Class Initialized
INFO - 2022-03-20 10:50:00 --> URI Class Initialized
INFO - 2022-03-20 10:50:00 --> Router Class Initialized
INFO - 2022-03-20 10:50:00 --> Output Class Initialized
INFO - 2022-03-20 10:50:00 --> Security Class Initialized
INFO - 2022-03-20 10:50:00 --> Input Class Initialized
INFO - 2022-03-20 10:50:00 --> Language Class Initialized
INFO - 2022-03-20 10:50:00 --> Loader Class Initialized
INFO - 2022-03-20 10:50:00 --> Helper loaded: url_helper
INFO - 2022-03-20 10:50:00 --> Helper loaded: form_helper
INFO - 2022-03-20 10:50:00 --> Database Driver Class Initialized
INFO - 2022-03-20 10:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:50:00 --> Form Validation Class Initialized
INFO - 2022-03-20 10:50:00 --> Controller Class Initialized
INFO - 2022-03-20 10:50:00 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:50:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 10:50:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 10:50:00 --> Severity: Notice --> Undefined variable: data C:\laragon\www\list-todo\application\views\home.php 32
INFO - 2022-03-20 10:50:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 10:50:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 10:50:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 10:50:00 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 10:50:00 --> Final output sent to browser
INFO - 2022-03-20 10:51:11 --> Config Class Initialized
INFO - 2022-03-20 10:51:11 --> Hooks Class Initialized
INFO - 2022-03-20 10:51:11 --> Utf8 Class Initialized
INFO - 2022-03-20 10:51:11 --> URI Class Initialized
INFO - 2022-03-20 10:51:11 --> Router Class Initialized
INFO - 2022-03-20 10:51:11 --> Output Class Initialized
INFO - 2022-03-20 10:51:11 --> Security Class Initialized
INFO - 2022-03-20 10:51:11 --> Input Class Initialized
INFO - 2022-03-20 10:51:11 --> Language Class Initialized
INFO - 2022-03-20 10:51:11 --> Loader Class Initialized
INFO - 2022-03-20 10:51:11 --> Helper loaded: url_helper
INFO - 2022-03-20 10:51:11 --> Helper loaded: form_helper
INFO - 2022-03-20 10:51:11 --> Database Driver Class Initialized
INFO - 2022-03-20 10:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:51:11 --> Form Validation Class Initialized
INFO - 2022-03-20 10:51:11 --> Controller Class Initialized
INFO - 2022-03-20 10:51:11 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:51:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 10:51:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 10:51:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 10:51:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 10:51:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 10:51:11 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 10:51:11 --> Final output sent to browser
INFO - 2022-03-20 10:53:49 --> Config Class Initialized
INFO - 2022-03-20 10:53:49 --> Hooks Class Initialized
INFO - 2022-03-20 10:53:49 --> Utf8 Class Initialized
INFO - 2022-03-20 10:53:50 --> URI Class Initialized
INFO - 2022-03-20 10:53:50 --> Router Class Initialized
INFO - 2022-03-20 10:53:50 --> Output Class Initialized
INFO - 2022-03-20 10:53:50 --> Security Class Initialized
INFO - 2022-03-20 10:53:50 --> Input Class Initialized
INFO - 2022-03-20 10:53:50 --> Language Class Initialized
INFO - 2022-03-20 10:53:50 --> Loader Class Initialized
INFO - 2022-03-20 10:53:50 --> Helper loaded: url_helper
INFO - 2022-03-20 10:53:50 --> Helper loaded: form_helper
INFO - 2022-03-20 10:53:50 --> Database Driver Class Initialized
INFO - 2022-03-20 10:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:53:50 --> Form Validation Class Initialized
INFO - 2022-03-20 10:53:50 --> Controller Class Initialized
INFO - 2022-03-20 10:53:50 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:53:50 --> Config Class Initialized
INFO - 2022-03-20 10:53:50 --> Hooks Class Initialized
INFO - 2022-03-20 10:53:50 --> Utf8 Class Initialized
INFO - 2022-03-20 10:53:50 --> URI Class Initialized
INFO - 2022-03-20 10:53:50 --> Router Class Initialized
INFO - 2022-03-20 10:53:50 --> Output Class Initialized
INFO - 2022-03-20 10:53:50 --> Security Class Initialized
INFO - 2022-03-20 10:53:50 --> Input Class Initialized
INFO - 2022-03-20 10:53:50 --> Language Class Initialized
INFO - 2022-03-20 10:53:50 --> Loader Class Initialized
INFO - 2022-03-20 10:53:50 --> Helper loaded: url_helper
INFO - 2022-03-20 10:53:50 --> Helper loaded: form_helper
INFO - 2022-03-20 10:53:50 --> Database Driver Class Initialized
INFO - 2022-03-20 10:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:53:50 --> Form Validation Class Initialized
INFO - 2022-03-20 10:53:50 --> Controller Class Initialized
INFO - 2022-03-20 10:53:50 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:53:50 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 10:53:50 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 10:53:50 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 10:53:50 --> Final output sent to browser
INFO - 2022-03-20 10:53:53 --> Config Class Initialized
INFO - 2022-03-20 10:53:53 --> Hooks Class Initialized
INFO - 2022-03-20 10:53:53 --> Utf8 Class Initialized
INFO - 2022-03-20 10:53:53 --> URI Class Initialized
INFO - 2022-03-20 10:53:53 --> Router Class Initialized
INFO - 2022-03-20 10:53:53 --> Output Class Initialized
INFO - 2022-03-20 10:53:53 --> Security Class Initialized
INFO - 2022-03-20 10:53:53 --> Input Class Initialized
INFO - 2022-03-20 10:53:53 --> Language Class Initialized
INFO - 2022-03-20 10:53:53 --> Loader Class Initialized
INFO - 2022-03-20 10:53:53 --> Helper loaded: url_helper
INFO - 2022-03-20 10:53:53 --> Helper loaded: form_helper
INFO - 2022-03-20 10:53:53 --> Database Driver Class Initialized
INFO - 2022-03-20 10:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:53:53 --> Form Validation Class Initialized
INFO - 2022-03-20 10:53:53 --> Controller Class Initialized
INFO - 2022-03-20 10:53:53 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:53:53 --> Config Class Initialized
INFO - 2022-03-20 10:53:53 --> Hooks Class Initialized
INFO - 2022-03-20 10:53:53 --> Utf8 Class Initialized
INFO - 2022-03-20 10:53:53 --> URI Class Initialized
INFO - 2022-03-20 10:53:53 --> Router Class Initialized
INFO - 2022-03-20 10:53:53 --> Output Class Initialized
INFO - 2022-03-20 10:53:53 --> Security Class Initialized
INFO - 2022-03-20 10:53:53 --> Input Class Initialized
INFO - 2022-03-20 10:53:53 --> Language Class Initialized
INFO - 2022-03-20 10:53:53 --> Loader Class Initialized
INFO - 2022-03-20 10:53:53 --> Helper loaded: url_helper
INFO - 2022-03-20 10:53:53 --> Helper loaded: form_helper
INFO - 2022-03-20 10:53:53 --> Database Driver Class Initialized
INFO - 2022-03-20 10:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:53:53 --> Form Validation Class Initialized
INFO - 2022-03-20 10:53:53 --> Controller Class Initialized
INFO - 2022-03-20 10:53:53 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:53:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 10:53:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 10:53:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 10:53:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 10:53:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 10:53:53 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 10:53:53 --> Final output sent to browser
INFO - 2022-03-20 10:54:15 --> Config Class Initialized
INFO - 2022-03-20 10:54:15 --> Hooks Class Initialized
INFO - 2022-03-20 10:54:15 --> Utf8 Class Initialized
INFO - 2022-03-20 10:54:15 --> URI Class Initialized
INFO - 2022-03-20 10:54:15 --> Router Class Initialized
INFO - 2022-03-20 10:54:15 --> Output Class Initialized
INFO - 2022-03-20 10:54:15 --> Security Class Initialized
INFO - 2022-03-20 10:54:15 --> Input Class Initialized
INFO - 2022-03-20 10:54:15 --> Language Class Initialized
INFO - 2022-03-20 10:54:15 --> Loader Class Initialized
INFO - 2022-03-20 10:54:15 --> Helper loaded: url_helper
INFO - 2022-03-20 10:54:15 --> Helper loaded: form_helper
INFO - 2022-03-20 10:54:15 --> Database Driver Class Initialized
INFO - 2022-03-20 10:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:54:15 --> Form Validation Class Initialized
INFO - 2022-03-20 10:54:15 --> Controller Class Initialized
INFO - 2022-03-20 10:54:15 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:54:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 10:54:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 10:54:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 10:54:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 10:54:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 10:54:15 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 10:54:15 --> Final output sent to browser
INFO - 2022-03-20 10:54:17 --> Config Class Initialized
INFO - 2022-03-20 10:54:17 --> Hooks Class Initialized
INFO - 2022-03-20 10:54:17 --> Utf8 Class Initialized
INFO - 2022-03-20 10:54:17 --> URI Class Initialized
INFO - 2022-03-20 10:54:17 --> Router Class Initialized
INFO - 2022-03-20 10:54:17 --> Output Class Initialized
INFO - 2022-03-20 10:54:17 --> Security Class Initialized
INFO - 2022-03-20 10:54:17 --> Input Class Initialized
INFO - 2022-03-20 10:54:17 --> Language Class Initialized
INFO - 2022-03-20 10:54:17 --> Loader Class Initialized
INFO - 2022-03-20 10:54:17 --> Helper loaded: url_helper
INFO - 2022-03-20 10:54:17 --> Helper loaded: form_helper
INFO - 2022-03-20 10:54:17 --> Database Driver Class Initialized
INFO - 2022-03-20 10:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:54:17 --> Form Validation Class Initialized
INFO - 2022-03-20 10:54:17 --> Controller Class Initialized
INFO - 2022-03-20 10:54:17 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:54:17 --> Config Class Initialized
INFO - 2022-03-20 10:54:17 --> Hooks Class Initialized
INFO - 2022-03-20 10:54:17 --> Utf8 Class Initialized
INFO - 2022-03-20 10:54:17 --> URI Class Initialized
INFO - 2022-03-20 10:54:17 --> Router Class Initialized
INFO - 2022-03-20 10:54:17 --> Output Class Initialized
INFO - 2022-03-20 10:54:17 --> Security Class Initialized
INFO - 2022-03-20 10:54:17 --> Input Class Initialized
INFO - 2022-03-20 10:54:17 --> Language Class Initialized
INFO - 2022-03-20 10:54:17 --> Loader Class Initialized
INFO - 2022-03-20 10:54:17 --> Helper loaded: url_helper
INFO - 2022-03-20 10:54:17 --> Helper loaded: form_helper
INFO - 2022-03-20 10:54:17 --> Database Driver Class Initialized
INFO - 2022-03-20 10:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:54:17 --> Form Validation Class Initialized
INFO - 2022-03-20 10:54:17 --> Controller Class Initialized
INFO - 2022-03-20 10:54:17 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:54:17 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 10:54:17 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 10:54:17 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 10:54:17 --> Final output sent to browser
INFO - 2022-03-20 10:54:23 --> Config Class Initialized
INFO - 2022-03-20 10:54:23 --> Hooks Class Initialized
INFO - 2022-03-20 10:54:23 --> Utf8 Class Initialized
INFO - 2022-03-20 10:54:23 --> URI Class Initialized
INFO - 2022-03-20 10:54:23 --> Router Class Initialized
INFO - 2022-03-20 10:54:23 --> Output Class Initialized
INFO - 2022-03-20 10:54:23 --> Security Class Initialized
INFO - 2022-03-20 10:54:23 --> Input Class Initialized
INFO - 2022-03-20 10:54:23 --> Language Class Initialized
INFO - 2022-03-20 10:54:23 --> Loader Class Initialized
INFO - 2022-03-20 10:54:23 --> Helper loaded: url_helper
INFO - 2022-03-20 10:54:23 --> Helper loaded: form_helper
INFO - 2022-03-20 10:54:23 --> Database Driver Class Initialized
INFO - 2022-03-20 10:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:54:23 --> Form Validation Class Initialized
INFO - 2022-03-20 10:54:23 --> Controller Class Initialized
INFO - 2022-03-20 10:54:23 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:54:23 --> Config Class Initialized
INFO - 2022-03-20 10:54:23 --> Hooks Class Initialized
INFO - 2022-03-20 10:54:23 --> Utf8 Class Initialized
INFO - 2022-03-20 10:54:23 --> URI Class Initialized
INFO - 2022-03-20 10:54:23 --> Router Class Initialized
INFO - 2022-03-20 10:54:23 --> Output Class Initialized
INFO - 2022-03-20 10:54:23 --> Security Class Initialized
INFO - 2022-03-20 10:54:23 --> Input Class Initialized
INFO - 2022-03-20 10:54:23 --> Language Class Initialized
INFO - 2022-03-20 10:54:23 --> Loader Class Initialized
INFO - 2022-03-20 10:54:23 --> Helper loaded: url_helper
INFO - 2022-03-20 10:54:23 --> Helper loaded: form_helper
INFO - 2022-03-20 10:54:23 --> Database Driver Class Initialized
INFO - 2022-03-20 10:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:54:23 --> Form Validation Class Initialized
INFO - 2022-03-20 10:54:23 --> Controller Class Initialized
INFO - 2022-03-20 10:54:23 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:54:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 10:54:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 10:54:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 10:54:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 10:54:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 10:54:23 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 10:54:23 --> Final output sent to browser
INFO - 2022-03-20 10:56:00 --> Config Class Initialized
INFO - 2022-03-20 10:56:00 --> Hooks Class Initialized
INFO - 2022-03-20 10:56:00 --> Utf8 Class Initialized
INFO - 2022-03-20 10:56:00 --> URI Class Initialized
INFO - 2022-03-20 10:56:00 --> Router Class Initialized
INFO - 2022-03-20 10:56:00 --> Output Class Initialized
INFO - 2022-03-20 10:56:00 --> Security Class Initialized
INFO - 2022-03-20 10:56:00 --> Input Class Initialized
INFO - 2022-03-20 10:56:00 --> Language Class Initialized
INFO - 2022-03-20 10:56:00 --> Loader Class Initialized
INFO - 2022-03-20 10:56:00 --> Helper loaded: url_helper
INFO - 2022-03-20 10:56:00 --> Helper loaded: form_helper
INFO - 2022-03-20 10:56:00 --> Database Driver Class Initialized
INFO - 2022-03-20 10:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:56:00 --> Form Validation Class Initialized
INFO - 2022-03-20 10:56:00 --> Controller Class Initialized
INFO - 2022-03-20 10:56:00 --> Model "M_todo_list" initialized
INFO - 2022-03-20 10:56:00 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 10:56:00 --> Model "M_todo_group" initialized
INFO - 2022-03-20 10:56:00 --> Model "M_todo_task" initialized
INFO - 2022-03-20 10:56:00 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:56:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 10:56:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 10:56:00 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 10:56:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 10:56:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 10:56:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 10:56:00 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 10:56:00 --> Final output sent to browser
INFO - 2022-03-20 10:56:03 --> Config Class Initialized
INFO - 2022-03-20 10:56:03 --> Hooks Class Initialized
INFO - 2022-03-20 10:56:03 --> Utf8 Class Initialized
INFO - 2022-03-20 10:56:03 --> URI Class Initialized
INFO - 2022-03-20 10:56:03 --> Router Class Initialized
INFO - 2022-03-20 10:56:03 --> Output Class Initialized
INFO - 2022-03-20 10:56:03 --> Security Class Initialized
INFO - 2022-03-20 10:56:03 --> Input Class Initialized
INFO - 2022-03-20 10:56:03 --> Language Class Initialized
INFO - 2022-03-20 10:56:03 --> Loader Class Initialized
INFO - 2022-03-20 10:56:03 --> Helper loaded: url_helper
INFO - 2022-03-20 10:56:03 --> Helper loaded: form_helper
INFO - 2022-03-20 10:56:04 --> Database Driver Class Initialized
INFO - 2022-03-20 10:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 10:56:04 --> Form Validation Class Initialized
INFO - 2022-03-20 10:56:04 --> Controller Class Initialized
INFO - 2022-03-20 10:56:04 --> Model "M_tutor" initialized
INFO - 2022-03-20 10:56:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 10:56:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 10:56:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 10:56:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 10:56:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 10:56:04 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 10:56:04 --> Final output sent to browser
INFO - 2022-03-20 12:22:37 --> Config Class Initialized
INFO - 2022-03-20 12:22:37 --> Hooks Class Initialized
INFO - 2022-03-20 12:22:37 --> Utf8 Class Initialized
INFO - 2022-03-20 12:22:37 --> URI Class Initialized
INFO - 2022-03-20 12:22:37 --> Router Class Initialized
INFO - 2022-03-20 12:22:37 --> Output Class Initialized
INFO - 2022-03-20 12:22:37 --> Security Class Initialized
INFO - 2022-03-20 12:22:37 --> Input Class Initialized
INFO - 2022-03-20 12:22:37 --> Language Class Initialized
INFO - 2022-03-20 12:22:37 --> Loader Class Initialized
INFO - 2022-03-20 12:22:37 --> Helper loaded: url_helper
INFO - 2022-03-20 12:22:37 --> Helper loaded: form_helper
INFO - 2022-03-20 12:22:37 --> Database Driver Class Initialized
INFO - 2022-03-20 12:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:22:37 --> Form Validation Class Initialized
INFO - 2022-03-20 12:22:37 --> Controller Class Initialized
INFO - 2022-03-20 12:22:37 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:22:37 --> Config Class Initialized
INFO - 2022-03-20 12:22:37 --> Hooks Class Initialized
INFO - 2022-03-20 12:22:37 --> Utf8 Class Initialized
INFO - 2022-03-20 12:22:37 --> URI Class Initialized
INFO - 2022-03-20 12:22:37 --> Router Class Initialized
INFO - 2022-03-20 12:22:37 --> Output Class Initialized
INFO - 2022-03-20 12:22:37 --> Security Class Initialized
INFO - 2022-03-20 12:22:37 --> Input Class Initialized
INFO - 2022-03-20 12:22:37 --> Language Class Initialized
INFO - 2022-03-20 12:22:37 --> Loader Class Initialized
INFO - 2022-03-20 12:22:37 --> Helper loaded: url_helper
INFO - 2022-03-20 12:22:37 --> Helper loaded: form_helper
INFO - 2022-03-20 12:22:37 --> Database Driver Class Initialized
INFO - 2022-03-20 12:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:22:37 --> Form Validation Class Initialized
INFO - 2022-03-20 12:22:37 --> Controller Class Initialized
INFO - 2022-03-20 12:22:37 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:22:37 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 12:22:37 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 12:22:37 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 12:22:37 --> Final output sent to browser
INFO - 2022-03-20 12:22:43 --> Config Class Initialized
INFO - 2022-03-20 12:22:43 --> Hooks Class Initialized
INFO - 2022-03-20 12:22:43 --> Utf8 Class Initialized
INFO - 2022-03-20 12:22:43 --> URI Class Initialized
INFO - 2022-03-20 12:22:43 --> Router Class Initialized
INFO - 2022-03-20 12:22:43 --> Output Class Initialized
INFO - 2022-03-20 12:22:43 --> Security Class Initialized
INFO - 2022-03-20 12:22:43 --> Input Class Initialized
INFO - 2022-03-20 12:22:43 --> Language Class Initialized
INFO - 2022-03-20 12:22:43 --> Loader Class Initialized
INFO - 2022-03-20 12:22:43 --> Helper loaded: url_helper
INFO - 2022-03-20 12:22:43 --> Helper loaded: form_helper
INFO - 2022-03-20 12:22:43 --> Database Driver Class Initialized
INFO - 2022-03-20 12:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:22:43 --> Form Validation Class Initialized
INFO - 2022-03-20 12:22:43 --> Controller Class Initialized
INFO - 2022-03-20 12:22:43 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:22:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 12:22:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 12:22:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 12:22:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 12:22:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 12:22:43 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 12:22:43 --> Final output sent to browser
INFO - 2022-03-20 12:24:06 --> Config Class Initialized
INFO - 2022-03-20 12:24:06 --> Hooks Class Initialized
INFO - 2022-03-20 12:24:06 --> Utf8 Class Initialized
INFO - 2022-03-20 12:24:06 --> URI Class Initialized
INFO - 2022-03-20 12:24:06 --> Router Class Initialized
INFO - 2022-03-20 12:24:06 --> Output Class Initialized
INFO - 2022-03-20 12:24:06 --> Security Class Initialized
INFO - 2022-03-20 12:24:06 --> Input Class Initialized
INFO - 2022-03-20 12:24:06 --> Language Class Initialized
INFO - 2022-03-20 12:24:06 --> Loader Class Initialized
INFO - 2022-03-20 12:24:06 --> Helper loaded: url_helper
INFO - 2022-03-20 12:24:06 --> Helper loaded: form_helper
INFO - 2022-03-20 12:24:06 --> Database Driver Class Initialized
INFO - 2022-03-20 12:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:24:06 --> Form Validation Class Initialized
INFO - 2022-03-20 12:24:06 --> Controller Class Initialized
INFO - 2022-03-20 12:24:06 --> Model "M_tutor" initialized
ERROR - 2022-03-20 12:24:06 --> Severity: Notice --> Undefined property: C_home::$data C:\laragon\www\list-todo\application\controllers\C_home.php 14
INFO - 2022-03-20 12:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 12:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 12:24:06 --> Severity: Notice --> Undefined variable: data C:\laragon\www\list-todo\application\views\home.php 32
INFO - 2022-03-20 12:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 12:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 12:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 12:24:06 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 12:24:06 --> Final output sent to browser
INFO - 2022-03-20 12:25:54 --> Config Class Initialized
INFO - 2022-03-20 12:25:54 --> Hooks Class Initialized
INFO - 2022-03-20 12:25:54 --> Utf8 Class Initialized
INFO - 2022-03-20 12:25:54 --> URI Class Initialized
INFO - 2022-03-20 12:25:54 --> Router Class Initialized
INFO - 2022-03-20 12:25:55 --> Output Class Initialized
INFO - 2022-03-20 12:25:55 --> Security Class Initialized
INFO - 2022-03-20 12:25:55 --> Input Class Initialized
INFO - 2022-03-20 12:25:55 --> Language Class Initialized
INFO - 2022-03-20 12:25:55 --> Loader Class Initialized
INFO - 2022-03-20 12:25:55 --> Helper loaded: url_helper
INFO - 2022-03-20 12:25:55 --> Helper loaded: form_helper
INFO - 2022-03-20 12:25:55 --> Database Driver Class Initialized
INFO - 2022-03-20 12:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:25:55 --> Form Validation Class Initialized
INFO - 2022-03-20 12:25:55 --> Controller Class Initialized
INFO - 2022-03-20 12:25:55 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:25:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 12:25:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 12:25:55 --> Severity: Notice --> Undefined variable: data C:\laragon\www\list-todo\application\views\home.php 32
INFO - 2022-03-20 12:25:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 12:25:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 12:25:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 12:25:55 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 12:25:55 --> Final output sent to browser
INFO - 2022-03-20 12:27:25 --> Config Class Initialized
INFO - 2022-03-20 12:27:25 --> Hooks Class Initialized
INFO - 2022-03-20 12:27:25 --> Utf8 Class Initialized
INFO - 2022-03-20 12:27:25 --> URI Class Initialized
INFO - 2022-03-20 12:27:25 --> Router Class Initialized
INFO - 2022-03-20 12:27:25 --> Output Class Initialized
INFO - 2022-03-20 12:27:25 --> Security Class Initialized
INFO - 2022-03-20 12:27:25 --> Input Class Initialized
INFO - 2022-03-20 12:27:25 --> Language Class Initialized
INFO - 2022-03-20 12:27:25 --> Loader Class Initialized
INFO - 2022-03-20 12:27:25 --> Helper loaded: url_helper
INFO - 2022-03-20 12:27:25 --> Helper loaded: form_helper
INFO - 2022-03-20 12:27:25 --> Database Driver Class Initialized
INFO - 2022-03-20 12:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:27:25 --> Form Validation Class Initialized
INFO - 2022-03-20 12:27:25 --> Controller Class Initialized
INFO - 2022-03-20 12:27:25 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:27:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 12:27:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 12:27:25 --> Severity: Notice --> Undefined variable: data C:\laragon\www\list-todo\application\views\home.php 32
INFO - 2022-03-20 12:27:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 12:27:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 12:27:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 12:27:25 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 12:27:25 --> Final output sent to browser
INFO - 2022-03-20 12:28:05 --> Config Class Initialized
INFO - 2022-03-20 12:28:05 --> Hooks Class Initialized
INFO - 2022-03-20 12:28:05 --> Utf8 Class Initialized
INFO - 2022-03-20 12:28:05 --> URI Class Initialized
INFO - 2022-03-20 12:28:05 --> Router Class Initialized
INFO - 2022-03-20 12:28:05 --> Output Class Initialized
INFO - 2022-03-20 12:28:05 --> Security Class Initialized
INFO - 2022-03-20 12:28:05 --> Input Class Initialized
INFO - 2022-03-20 12:28:05 --> Language Class Initialized
INFO - 2022-03-20 12:28:05 --> Loader Class Initialized
INFO - 2022-03-20 12:28:05 --> Helper loaded: url_helper
INFO - 2022-03-20 12:28:05 --> Helper loaded: form_helper
INFO - 2022-03-20 12:28:05 --> Database Driver Class Initialized
INFO - 2022-03-20 12:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:28:05 --> Form Validation Class Initialized
INFO - 2022-03-20 12:28:05 --> Controller Class Initialized
INFO - 2022-03-20 12:28:05 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:28:05 --> Model "M_todo_group" initialized
INFO - 2022-03-20 12:28:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 12:28:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 12:28:05 --> Severity: Notice --> Undefined variable: data C:\laragon\www\list-todo\application\views\home.php 32
INFO - 2022-03-20 12:28:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 12:28:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 12:28:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 12:28:05 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 12:28:05 --> Final output sent to browser
INFO - 2022-03-20 12:28:18 --> Config Class Initialized
INFO - 2022-03-20 12:28:18 --> Hooks Class Initialized
INFO - 2022-03-20 12:28:18 --> Utf8 Class Initialized
INFO - 2022-03-20 12:28:18 --> URI Class Initialized
INFO - 2022-03-20 12:28:18 --> Router Class Initialized
INFO - 2022-03-20 12:28:18 --> Output Class Initialized
INFO - 2022-03-20 12:28:18 --> Security Class Initialized
INFO - 2022-03-20 12:28:18 --> Input Class Initialized
INFO - 2022-03-20 12:28:18 --> Language Class Initialized
INFO - 2022-03-20 12:28:18 --> Loader Class Initialized
INFO - 2022-03-20 12:28:18 --> Helper loaded: url_helper
INFO - 2022-03-20 12:28:18 --> Helper loaded: form_helper
INFO - 2022-03-20 12:28:18 --> Database Driver Class Initialized
INFO - 2022-03-20 12:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:28:18 --> Form Validation Class Initialized
INFO - 2022-03-20 12:28:18 --> Controller Class Initialized
INFO - 2022-03-20 12:28:18 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:28:18 --> Model "M_todo_group" initialized
INFO - 2022-03-20 12:28:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 12:28:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 12:28:18 --> Severity: Notice --> Undefined variable: data C:\laragon\www\list-todo\application\views\home.php 32
INFO - 2022-03-20 12:28:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 12:28:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 12:28:18 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 12:28:18 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 12:28:18 --> Final output sent to browser
INFO - 2022-03-20 12:28:53 --> Config Class Initialized
INFO - 2022-03-20 12:28:53 --> Hooks Class Initialized
INFO - 2022-03-20 12:28:53 --> Utf8 Class Initialized
INFO - 2022-03-20 12:28:53 --> URI Class Initialized
INFO - 2022-03-20 12:28:53 --> Router Class Initialized
INFO - 2022-03-20 12:28:53 --> Output Class Initialized
INFO - 2022-03-20 12:28:53 --> Security Class Initialized
INFO - 2022-03-20 12:28:53 --> Input Class Initialized
INFO - 2022-03-20 12:28:53 --> Language Class Initialized
INFO - 2022-03-20 12:28:53 --> Loader Class Initialized
INFO - 2022-03-20 12:28:53 --> Helper loaded: url_helper
INFO - 2022-03-20 12:28:53 --> Helper loaded: form_helper
INFO - 2022-03-20 12:28:53 --> Database Driver Class Initialized
INFO - 2022-03-20 12:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:28:53 --> Form Validation Class Initialized
INFO - 2022-03-20 12:28:53 --> Controller Class Initialized
INFO - 2022-03-20 12:28:53 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:28:53 --> Model "M_todo_group" initialized
INFO - 2022-03-20 12:28:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 12:28:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 12:28:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 12:28:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 12:28:53 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 12:28:53 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 12:28:53 --> Final output sent to browser
INFO - 2022-03-20 12:53:52 --> Config Class Initialized
INFO - 2022-03-20 12:53:52 --> Hooks Class Initialized
INFO - 2022-03-20 12:53:52 --> Utf8 Class Initialized
INFO - 2022-03-20 12:53:52 --> URI Class Initialized
INFO - 2022-03-20 12:53:52 --> Router Class Initialized
INFO - 2022-03-20 12:53:52 --> Output Class Initialized
INFO - 2022-03-20 12:53:52 --> Security Class Initialized
INFO - 2022-03-20 12:53:52 --> Input Class Initialized
INFO - 2022-03-20 12:53:52 --> Language Class Initialized
INFO - 2022-03-20 12:53:52 --> Loader Class Initialized
INFO - 2022-03-20 12:53:52 --> Helper loaded: url_helper
INFO - 2022-03-20 12:53:52 --> Helper loaded: form_helper
INFO - 2022-03-20 12:53:52 --> Database Driver Class Initialized
INFO - 2022-03-20 12:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:53:52 --> Form Validation Class Initialized
INFO - 2022-03-20 12:53:52 --> Controller Class Initialized
INFO - 2022-03-20 12:53:52 --> Model "M_todo_list" initialized
INFO - 2022-03-20 12:53:52 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 12:53:52 --> Model "M_todo_group" initialized
INFO - 2022-03-20 12:53:52 --> Model "M_todo_task" initialized
INFO - 2022-03-20 12:53:52 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:53:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 12:53:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 12:53:52 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 12:53:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 12:53:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 12:53:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 12:53:52 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 12:53:52 --> Final output sent to browser
INFO - 2022-03-20 12:55:50 --> Config Class Initialized
INFO - 2022-03-20 12:55:50 --> Hooks Class Initialized
INFO - 2022-03-20 12:55:50 --> Utf8 Class Initialized
INFO - 2022-03-20 12:55:50 --> URI Class Initialized
INFO - 2022-03-20 12:55:50 --> Router Class Initialized
INFO - 2022-03-20 12:55:50 --> Output Class Initialized
INFO - 2022-03-20 12:55:50 --> Security Class Initialized
INFO - 2022-03-20 12:55:50 --> Input Class Initialized
INFO - 2022-03-20 12:55:50 --> Language Class Initialized
INFO - 2022-03-20 12:55:50 --> Loader Class Initialized
INFO - 2022-03-20 12:55:50 --> Helper loaded: url_helper
INFO - 2022-03-20 12:55:50 --> Helper loaded: form_helper
INFO - 2022-03-20 12:55:50 --> Database Driver Class Initialized
INFO - 2022-03-20 12:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:55:50 --> Form Validation Class Initialized
INFO - 2022-03-20 12:55:50 --> Controller Class Initialized
INFO - 2022-03-20 12:55:50 --> Model "M_todo_list" initialized
INFO - 2022-03-20 12:55:50 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 12:55:50 --> Model "M_todo_group" initialized
INFO - 2022-03-20 12:55:50 --> Model "M_todo_task" initialized
INFO - 2022-03-20 12:55:50 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:55:50 --> Final output sent to browser
INFO - 2022-03-20 12:56:04 --> Config Class Initialized
INFO - 2022-03-20 12:56:04 --> Hooks Class Initialized
INFO - 2022-03-20 12:56:04 --> Utf8 Class Initialized
INFO - 2022-03-20 12:56:04 --> URI Class Initialized
INFO - 2022-03-20 12:56:04 --> Router Class Initialized
INFO - 2022-03-20 12:56:04 --> Output Class Initialized
INFO - 2022-03-20 12:56:04 --> Security Class Initialized
INFO - 2022-03-20 12:56:04 --> Input Class Initialized
INFO - 2022-03-20 12:56:04 --> Language Class Initialized
INFO - 2022-03-20 12:56:04 --> Loader Class Initialized
INFO - 2022-03-20 12:56:04 --> Helper loaded: url_helper
INFO - 2022-03-20 12:56:04 --> Helper loaded: form_helper
INFO - 2022-03-20 12:56:04 --> Database Driver Class Initialized
INFO - 2022-03-20 12:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:56:04 --> Form Validation Class Initialized
INFO - 2022-03-20 12:56:04 --> Controller Class Initialized
INFO - 2022-03-20 12:56:04 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:56:05 --> Config Class Initialized
INFO - 2022-03-20 12:56:05 --> Hooks Class Initialized
INFO - 2022-03-20 12:56:05 --> Utf8 Class Initialized
INFO - 2022-03-20 12:56:05 --> URI Class Initialized
INFO - 2022-03-20 12:56:05 --> Router Class Initialized
INFO - 2022-03-20 12:56:05 --> Output Class Initialized
INFO - 2022-03-20 12:56:05 --> Security Class Initialized
INFO - 2022-03-20 12:56:05 --> Input Class Initialized
INFO - 2022-03-20 12:56:05 --> Language Class Initialized
INFO - 2022-03-20 12:56:05 --> Loader Class Initialized
INFO - 2022-03-20 12:56:05 --> Helper loaded: url_helper
INFO - 2022-03-20 12:56:05 --> Helper loaded: form_helper
INFO - 2022-03-20 12:56:05 --> Database Driver Class Initialized
INFO - 2022-03-20 12:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:56:05 --> Form Validation Class Initialized
INFO - 2022-03-20 12:56:05 --> Controller Class Initialized
INFO - 2022-03-20 12:56:05 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:56:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 12:56:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 12:56:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 12:56:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 12:56:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 12:56:05 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 12:56:05 --> Final output sent to browser
INFO - 2022-03-20 12:56:08 --> Config Class Initialized
INFO - 2022-03-20 12:56:08 --> Hooks Class Initialized
INFO - 2022-03-20 12:56:08 --> Utf8 Class Initialized
INFO - 2022-03-20 12:56:08 --> URI Class Initialized
INFO - 2022-03-20 12:56:08 --> Router Class Initialized
INFO - 2022-03-20 12:56:08 --> Output Class Initialized
INFO - 2022-03-20 12:56:08 --> Security Class Initialized
INFO - 2022-03-20 12:56:08 --> Input Class Initialized
INFO - 2022-03-20 12:56:08 --> Language Class Initialized
INFO - 2022-03-20 12:56:08 --> Loader Class Initialized
INFO - 2022-03-20 12:56:08 --> Helper loaded: url_helper
INFO - 2022-03-20 12:56:08 --> Helper loaded: form_helper
INFO - 2022-03-20 12:56:08 --> Database Driver Class Initialized
INFO - 2022-03-20 12:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:56:08 --> Form Validation Class Initialized
INFO - 2022-03-20 12:56:08 --> Controller Class Initialized
INFO - 2022-03-20 12:56:08 --> Model "M_todo_list" initialized
INFO - 2022-03-20 12:56:08 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 12:56:08 --> Model "M_todo_group" initialized
INFO - 2022-03-20 12:56:08 --> Model "M_todo_task" initialized
INFO - 2022-03-20 12:56:08 --> Model "M_tutor" initialized
INFO - 2022-03-20 12:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 12:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 12:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 12:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 12:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 12:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 12:56:08 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 12:56:08 --> Final output sent to browser
INFO - 2022-03-20 12:58:05 --> Config Class Initialized
INFO - 2022-03-20 12:58:05 --> Hooks Class Initialized
INFO - 2022-03-20 12:58:05 --> Utf8 Class Initialized
INFO - 2022-03-20 12:58:05 --> URI Class Initialized
INFO - 2022-03-20 12:58:05 --> Router Class Initialized
INFO - 2022-03-20 12:58:05 --> Output Class Initialized
INFO - 2022-03-20 12:58:05 --> Security Class Initialized
INFO - 2022-03-20 12:58:05 --> Input Class Initialized
INFO - 2022-03-20 12:58:05 --> Language Class Initialized
INFO - 2022-03-20 12:58:05 --> Loader Class Initialized
INFO - 2022-03-20 12:58:05 --> Helper loaded: url_helper
INFO - 2022-03-20 12:58:05 --> Helper loaded: form_helper
INFO - 2022-03-20 12:58:05 --> Database Driver Class Initialized
INFO - 2022-03-20 12:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 12:58:05 --> Form Validation Class Initialized
INFO - 2022-03-20 12:58:05 --> Controller Class Initialized
INFO - 2022-03-20 12:58:05 --> Model "M_todo_list" initialized
INFO - 2022-03-20 12:58:05 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 12:58:05 --> Model "M_todo_group" initialized
INFO - 2022-03-20 12:58:05 --> Model "M_todo_task" initialized
INFO - 2022-03-20 12:58:05 --> Model "M_tutor" initialized
ERROR - 2022-03-20 12:58:05 --> Severity: Error --> Call to undefined method M_todo_list::getAllJoinById() C:\laragon\www\list-todo\application\controllers\C_todo_list.php 27
INFO - 2022-03-20 13:03:23 --> Config Class Initialized
INFO - 2022-03-20 13:03:23 --> Hooks Class Initialized
INFO - 2022-03-20 13:03:23 --> Utf8 Class Initialized
INFO - 2022-03-20 13:03:23 --> URI Class Initialized
INFO - 2022-03-20 13:03:23 --> Router Class Initialized
INFO - 2022-03-20 13:03:23 --> Output Class Initialized
INFO - 2022-03-20 13:03:23 --> Security Class Initialized
INFO - 2022-03-20 13:03:23 --> Input Class Initialized
INFO - 2022-03-20 13:03:23 --> Language Class Initialized
INFO - 2022-03-20 13:03:23 --> Loader Class Initialized
INFO - 2022-03-20 13:03:23 --> Helper loaded: url_helper
INFO - 2022-03-20 13:03:23 --> Helper loaded: form_helper
INFO - 2022-03-20 13:03:23 --> Database Driver Class Initialized
INFO - 2022-03-20 13:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:03:23 --> Form Validation Class Initialized
INFO - 2022-03-20 13:03:23 --> Controller Class Initialized
INFO - 2022-03-20 13:03:23 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:03:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:03:23 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:03:23 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:03:23 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:03:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:03:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:03:23 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:03:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:03:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:03:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:03:23 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:03:23 --> Final output sent to browser
INFO - 2022-03-20 13:04:33 --> Config Class Initialized
INFO - 2022-03-20 13:04:33 --> Hooks Class Initialized
INFO - 2022-03-20 13:04:33 --> Utf8 Class Initialized
INFO - 2022-03-20 13:04:33 --> URI Class Initialized
INFO - 2022-03-20 13:04:33 --> Router Class Initialized
INFO - 2022-03-20 13:04:33 --> Output Class Initialized
INFO - 2022-03-20 13:04:33 --> Security Class Initialized
INFO - 2022-03-20 13:04:33 --> Input Class Initialized
INFO - 2022-03-20 13:04:33 --> Language Class Initialized
INFO - 2022-03-20 13:04:33 --> Loader Class Initialized
INFO - 2022-03-20 13:04:33 --> Helper loaded: url_helper
INFO - 2022-03-20 13:04:33 --> Helper loaded: form_helper
INFO - 2022-03-20 13:04:33 --> Database Driver Class Initialized
INFO - 2022-03-20 13:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:04:33 --> Form Validation Class Initialized
INFO - 2022-03-20 13:04:33 --> Controller Class Initialized
INFO - 2022-03-20 13:04:33 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:04:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:04:33 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:04:33 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:04:33 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:04:33 --> Query error: Unknown column 'todo_group.ptk' in 'where clause' - Invalid query: SELECT `todo_list`.*, `tutor`.`nama` AS `nama_user`, `todo_group`.`nama` AS `nama_group`
FROM `todo_list`
JOIN `todo_group` ON `todo_group`.`id` = `todo_list`.`todo_group`
JOIN `tutor` ON `tutor`.`id` = `todo_list`.`user`
WHERE `todo_group`.`ptk` = '7'
INFO - 2022-03-20 13:04:33 --> Language file loaded: language/english/db_lang.php
INFO - 2022-03-20 13:04:53 --> Config Class Initialized
INFO - 2022-03-20 13:04:53 --> Hooks Class Initialized
INFO - 2022-03-20 13:04:53 --> Utf8 Class Initialized
INFO - 2022-03-20 13:04:53 --> URI Class Initialized
INFO - 2022-03-20 13:04:53 --> Router Class Initialized
INFO - 2022-03-20 13:04:53 --> Output Class Initialized
INFO - 2022-03-20 13:04:53 --> Security Class Initialized
INFO - 2022-03-20 13:04:53 --> Input Class Initialized
INFO - 2022-03-20 13:04:53 --> Language Class Initialized
INFO - 2022-03-20 13:04:53 --> Loader Class Initialized
INFO - 2022-03-20 13:04:53 --> Helper loaded: url_helper
INFO - 2022-03-20 13:04:53 --> Helper loaded: form_helper
INFO - 2022-03-20 13:04:53 --> Database Driver Class Initialized
INFO - 2022-03-20 13:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:04:53 --> Form Validation Class Initialized
INFO - 2022-03-20 13:04:53 --> Controller Class Initialized
INFO - 2022-03-20 13:04:53 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:04:53 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:04:53 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:04:53 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:04:53 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:04:53 --> Query error: Unknown column 'todo_group.ptk' in 'field list' - Invalid query: SELECT `todo_list`.*, `tutor`.`nama` AS `nama_user`, `todo_group`.`nama` AS `nama_group`, `todo_group`.`ptk`
FROM `todo_list`
JOIN `todo_group` ON `todo_group`.`id` = `todo_list`.`todo_group`
JOIN `tutor` ON `tutor`.`id` = `todo_list`.`user`
WHERE `todo_group`.`ptk` = '7'
INFO - 2022-03-20 13:04:53 --> Language file loaded: language/english/db_lang.php
INFO - 2022-03-20 13:12:04 --> Config Class Initialized
INFO - 2022-03-20 13:12:04 --> Hooks Class Initialized
INFO - 2022-03-20 13:12:04 --> Utf8 Class Initialized
INFO - 2022-03-20 13:12:04 --> URI Class Initialized
INFO - 2022-03-20 13:12:04 --> Router Class Initialized
INFO - 2022-03-20 13:12:04 --> Output Class Initialized
INFO - 2022-03-20 13:12:04 --> Security Class Initialized
INFO - 2022-03-20 13:12:04 --> Input Class Initialized
INFO - 2022-03-20 13:12:04 --> Language Class Initialized
INFO - 2022-03-20 13:12:04 --> Loader Class Initialized
INFO - 2022-03-20 13:12:04 --> Helper loaded: url_helper
INFO - 2022-03-20 13:12:04 --> Helper loaded: form_helper
INFO - 2022-03-20 13:12:04 --> Database Driver Class Initialized
INFO - 2022-03-20 13:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:12:04 --> Form Validation Class Initialized
INFO - 2022-03-20 13:12:04 --> Controller Class Initialized
INFO - 2022-03-20 13:12:04 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:12:04 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:12:04 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:12:04 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:12:04 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:12:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:12:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 43
INFO - 2022-03-20 13:12:05 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:12:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:12:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:12:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:12:05 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:12:05 --> Final output sent to browser
INFO - 2022-03-20 13:12:43 --> Config Class Initialized
INFO - 2022-03-20 13:12:43 --> Hooks Class Initialized
INFO - 2022-03-20 13:12:43 --> Utf8 Class Initialized
INFO - 2022-03-20 13:12:43 --> URI Class Initialized
INFO - 2022-03-20 13:12:43 --> Router Class Initialized
INFO - 2022-03-20 13:12:43 --> Output Class Initialized
INFO - 2022-03-20 13:12:43 --> Security Class Initialized
INFO - 2022-03-20 13:12:43 --> Input Class Initialized
INFO - 2022-03-20 13:12:43 --> Language Class Initialized
INFO - 2022-03-20 13:12:43 --> Loader Class Initialized
INFO - 2022-03-20 13:12:43 --> Helper loaded: url_helper
INFO - 2022-03-20 13:12:43 --> Helper loaded: form_helper
INFO - 2022-03-20 13:12:43 --> Database Driver Class Initialized
INFO - 2022-03-20 13:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:12:43 --> Form Validation Class Initialized
INFO - 2022-03-20 13:12:43 --> Controller Class Initialized
INFO - 2022-03-20 13:12:43 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:12:43 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:12:43 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:12:43 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:12:43 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:12:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:12:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 44
INFO - 2022-03-20 13:12:43 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:12:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:12:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:12:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:12:43 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:12:43 --> Final output sent to browser
INFO - 2022-03-20 13:16:20 --> Config Class Initialized
INFO - 2022-03-20 13:16:20 --> Hooks Class Initialized
INFO - 2022-03-20 13:16:20 --> Utf8 Class Initialized
INFO - 2022-03-20 13:16:20 --> URI Class Initialized
INFO - 2022-03-20 13:16:20 --> Router Class Initialized
INFO - 2022-03-20 13:16:20 --> Output Class Initialized
INFO - 2022-03-20 13:16:20 --> Security Class Initialized
INFO - 2022-03-20 13:16:20 --> Input Class Initialized
INFO - 2022-03-20 13:16:20 --> Language Class Initialized
INFO - 2022-03-20 13:16:20 --> Loader Class Initialized
INFO - 2022-03-20 13:16:20 --> Helper loaded: url_helper
INFO - 2022-03-20 13:16:20 --> Helper loaded: form_helper
INFO - 2022-03-20 13:16:20 --> Database Driver Class Initialized
INFO - 2022-03-20 13:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:16:20 --> Form Validation Class Initialized
INFO - 2022-03-20 13:16:20 --> Controller Class Initialized
INFO - 2022-03-20 13:16:20 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:16:20 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:16:20 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:16:20 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:16:20 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:16:20 --> Severity: Error --> Call to undefined method M_todo_group::cek_group() C:\laragon\www\list-todo\application\controllers\C_todo_list.php 25
INFO - 2022-03-20 13:18:07 --> Config Class Initialized
INFO - 2022-03-20 13:18:07 --> Hooks Class Initialized
INFO - 2022-03-20 13:18:07 --> Utf8 Class Initialized
INFO - 2022-03-20 13:18:07 --> URI Class Initialized
INFO - 2022-03-20 13:18:07 --> Router Class Initialized
INFO - 2022-03-20 13:18:07 --> Output Class Initialized
INFO - 2022-03-20 13:18:07 --> Security Class Initialized
INFO - 2022-03-20 13:18:07 --> Input Class Initialized
INFO - 2022-03-20 13:18:07 --> Language Class Initialized
INFO - 2022-03-20 13:18:07 --> Loader Class Initialized
INFO - 2022-03-20 13:18:07 --> Helper loaded: url_helper
INFO - 2022-03-20 13:18:07 --> Helper loaded: form_helper
INFO - 2022-03-20 13:18:07 --> Database Driver Class Initialized
INFO - 2022-03-20 13:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:18:07 --> Form Validation Class Initialized
INFO - 2022-03-20 13:18:07 --> Controller Class Initialized
INFO - 2022-03-20 13:18:07 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:18:07 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:18:07 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:18:07 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:18:07 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:18:07 --> Severity: Warning --> Missing argument 1 for M_todo_list::getAllJoinById(), called in C:\laragon\www\list-todo\application\controllers\C_todo_list.php on line 27 and defined C:\laragon\www\list-todo\application\models\M_todo_list.php 61
ERROR - 2022-03-20 13:18:07 --> Severity: Notice --> Undefined variable: id C:\laragon\www\list-todo\application\models\M_todo_list.php 69
ERROR - 2022-03-20 13:18:07 --> Query error: Not unique table/alias: 'todo_group' - Invalid query: SELECT `todo_list`.*, `tutor`.`nama` AS `nama_user`, `todo_group`.`nama` AS `nama_group`, `todo_group`.`ptk`
FROM `todo_list`
JOIN `todo_group` ON `todo_group`.`id` = `todo_list`.`todo_group`
JOIN `todo_group` ON `todo_group`.`id` = `todo_list`.`todo_group`
JOIN `todo_group` ON `todo_group`.`id` = `todo_list`.`todo_group`
JOIN `tutor` ON `tutor`.`id` = `todo_list`.`user`
WHERE `todo_group`.`ptk` IS NULL
INFO - 2022-03-20 13:18:07 --> Language file loaded: language/english/db_lang.php
INFO - 2022-03-20 13:19:33 --> Config Class Initialized
INFO - 2022-03-20 13:19:33 --> Hooks Class Initialized
INFO - 2022-03-20 13:19:33 --> Utf8 Class Initialized
INFO - 2022-03-20 13:19:33 --> URI Class Initialized
INFO - 2022-03-20 13:19:33 --> Router Class Initialized
INFO - 2022-03-20 13:19:33 --> Output Class Initialized
INFO - 2022-03-20 13:19:33 --> Security Class Initialized
INFO - 2022-03-20 13:19:33 --> Input Class Initialized
INFO - 2022-03-20 13:19:33 --> Language Class Initialized
INFO - 2022-03-20 13:19:33 --> Loader Class Initialized
INFO - 2022-03-20 13:19:33 --> Helper loaded: url_helper
INFO - 2022-03-20 13:19:33 --> Helper loaded: form_helper
INFO - 2022-03-20 13:19:33 --> Database Driver Class Initialized
INFO - 2022-03-20 13:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:19:33 --> Form Validation Class Initialized
INFO - 2022-03-20 13:19:33 --> Controller Class Initialized
INFO - 2022-03-20 13:19:33 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:19:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:19:33 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:19:33 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:19:33 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:19:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:19:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:19:33 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:19:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:19:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:19:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:19:33 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:19:33 --> Final output sent to browser
INFO - 2022-03-20 13:19:36 --> Config Class Initialized
INFO - 2022-03-20 13:19:36 --> Hooks Class Initialized
INFO - 2022-03-20 13:19:36 --> Utf8 Class Initialized
INFO - 2022-03-20 13:19:36 --> URI Class Initialized
INFO - 2022-03-20 13:19:36 --> Router Class Initialized
INFO - 2022-03-20 13:19:36 --> Output Class Initialized
INFO - 2022-03-20 13:19:36 --> Security Class Initialized
INFO - 2022-03-20 13:19:36 --> Input Class Initialized
INFO - 2022-03-20 13:19:36 --> Language Class Initialized
INFO - 2022-03-20 13:19:36 --> Loader Class Initialized
INFO - 2022-03-20 13:19:36 --> Helper loaded: url_helper
INFO - 2022-03-20 13:19:36 --> Helper loaded: form_helper
INFO - 2022-03-20 13:19:36 --> Database Driver Class Initialized
INFO - 2022-03-20 13:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:19:36 --> Form Validation Class Initialized
INFO - 2022-03-20 13:19:36 --> Controller Class Initialized
INFO - 2022-03-20 13:19:36 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:19:36 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:19:36 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:19:36 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:19:36 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:19:36 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
ERROR - 2022-03-20 13:19:36 --> Query error: Unknown column 'todo_group.ptk' in 'field list' - Invalid query: SELECT `todo_list`.*, `tutor`.`nama` AS `nama_user`, `todo_group`.`nama` AS `nama_group`, `todo_group`.`ptk`
FROM `todo_list`
JOIN `todo_group` ON `todo_group`.`id` = `todo_list`.`todo_group`
JOIN `tutor` ON `tutor`.`id` = `todo_list`.`user`
WHERE `todo_list`.`todo_group` IS NULL
INFO - 2022-03-20 13:19:36 --> Language file loaded: language/english/db_lang.php
INFO - 2022-03-20 13:19:54 --> Config Class Initialized
INFO - 2022-03-20 13:19:54 --> Hooks Class Initialized
INFO - 2022-03-20 13:19:54 --> Utf8 Class Initialized
INFO - 2022-03-20 13:19:54 --> URI Class Initialized
INFO - 2022-03-20 13:19:54 --> Router Class Initialized
INFO - 2022-03-20 13:19:54 --> Output Class Initialized
INFO - 2022-03-20 13:19:54 --> Security Class Initialized
INFO - 2022-03-20 13:19:54 --> Input Class Initialized
INFO - 2022-03-20 13:19:54 --> Language Class Initialized
INFO - 2022-03-20 13:19:54 --> Loader Class Initialized
INFO - 2022-03-20 13:19:54 --> Helper loaded: url_helper
INFO - 2022-03-20 13:19:54 --> Helper loaded: form_helper
INFO - 2022-03-20 13:19:54 --> Database Driver Class Initialized
INFO - 2022-03-20 13:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:19:54 --> Form Validation Class Initialized
INFO - 2022-03-20 13:19:54 --> Controller Class Initialized
INFO - 2022-03-20 13:19:54 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:19:54 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:19:54 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:19:54 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:19:54 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:19:54 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
INFO - 2022-03-20 13:19:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:19:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:19:54 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:19:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:19:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:19:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:19:54 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:19:54 --> Final output sent to browser
INFO - 2022-03-20 13:20:38 --> Config Class Initialized
INFO - 2022-03-20 13:20:38 --> Hooks Class Initialized
INFO - 2022-03-20 13:20:38 --> Utf8 Class Initialized
INFO - 2022-03-20 13:20:38 --> URI Class Initialized
INFO - 2022-03-20 13:20:38 --> Router Class Initialized
INFO - 2022-03-20 13:20:38 --> Output Class Initialized
INFO - 2022-03-20 13:20:38 --> Security Class Initialized
INFO - 2022-03-20 13:20:38 --> Input Class Initialized
INFO - 2022-03-20 13:20:38 --> Language Class Initialized
INFO - 2022-03-20 13:20:38 --> Loader Class Initialized
INFO - 2022-03-20 13:20:38 --> Helper loaded: url_helper
INFO - 2022-03-20 13:20:38 --> Helper loaded: form_helper
INFO - 2022-03-20 13:20:38 --> Database Driver Class Initialized
INFO - 2022-03-20 13:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:20:38 --> Form Validation Class Initialized
INFO - 2022-03-20 13:20:38 --> Controller Class Initialized
INFO - 2022-03-20 13:20:38 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:20:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:20:38 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:20:38 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:20:38 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:20:38 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
ERROR - 2022-03-20 13:20:38 --> Severity: Notice --> Undefined variable: list C:\laragon\www\list-todo\application\controllers\C_todo_list.php 27
INFO - 2022-03-20 13:20:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:20:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:20:38 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:20:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:20:38 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:20:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:20:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:20:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:20:38 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:20:38 --> Final output sent to browser
INFO - 2022-03-20 13:21:31 --> Config Class Initialized
INFO - 2022-03-20 13:21:31 --> Hooks Class Initialized
INFO - 2022-03-20 13:21:31 --> Utf8 Class Initialized
INFO - 2022-03-20 13:21:31 --> URI Class Initialized
INFO - 2022-03-20 13:21:31 --> Router Class Initialized
INFO - 2022-03-20 13:21:31 --> Output Class Initialized
INFO - 2022-03-20 13:21:31 --> Security Class Initialized
INFO - 2022-03-20 13:21:31 --> Input Class Initialized
INFO - 2022-03-20 13:21:31 --> Language Class Initialized
INFO - 2022-03-20 13:21:31 --> Loader Class Initialized
INFO - 2022-03-20 13:21:31 --> Helper loaded: url_helper
INFO - 2022-03-20 13:21:31 --> Helper loaded: form_helper
INFO - 2022-03-20 13:21:31 --> Database Driver Class Initialized
INFO - 2022-03-20 13:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:21:31 --> Form Validation Class Initialized
INFO - 2022-03-20 13:21:31 --> Controller Class Initialized
INFO - 2022-03-20 13:21:31 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:21:31 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:21:31 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:21:31 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:21:31 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:21:31 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
INFO - 2022-03-20 13:21:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:21:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:21:31 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:21:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:21:31 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:21:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:21:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:21:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:21:31 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:21:31 --> Final output sent to browser
INFO - 2022-03-20 13:21:50 --> Config Class Initialized
INFO - 2022-03-20 13:21:50 --> Hooks Class Initialized
INFO - 2022-03-20 13:21:50 --> Utf8 Class Initialized
INFO - 2022-03-20 13:21:50 --> URI Class Initialized
INFO - 2022-03-20 13:21:50 --> Router Class Initialized
INFO - 2022-03-20 13:21:50 --> Output Class Initialized
INFO - 2022-03-20 13:21:50 --> Security Class Initialized
INFO - 2022-03-20 13:21:50 --> Input Class Initialized
INFO - 2022-03-20 13:21:50 --> Language Class Initialized
INFO - 2022-03-20 13:21:50 --> Loader Class Initialized
INFO - 2022-03-20 13:21:50 --> Helper loaded: url_helper
INFO - 2022-03-20 13:21:50 --> Helper loaded: form_helper
INFO - 2022-03-20 13:21:50 --> Database Driver Class Initialized
INFO - 2022-03-20 13:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:21:50 --> Form Validation Class Initialized
INFO - 2022-03-20 13:21:50 --> Controller Class Initialized
INFO - 2022-03-20 13:21:50 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:21:50 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:21:50 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:21:50 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:21:50 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:21:50 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
ERROR - 2022-03-20 13:21:50 --> Query error: Unknown column 'todo_list.todo_grou' in 'where clause' - Invalid query: SELECT `todo_list`.*, `tutor`.`nama` AS `nama_user`, `todo_group`.`nama` AS `nama_group`
FROM `todo_list`
JOIN `todo_group` ON `todo_group`.`id` = `todo_list`.`todo_group`
JOIN `tutor` ON `tutor`.`id` = `todo_list`.`user`
WHERE `todo_list`.`todo_grou` IS NULL
INFO - 2022-03-20 13:21:50 --> Language file loaded: language/english/db_lang.php
INFO - 2022-03-20 13:22:25 --> Config Class Initialized
INFO - 2022-03-20 13:22:25 --> Hooks Class Initialized
INFO - 2022-03-20 13:22:25 --> Utf8 Class Initialized
INFO - 2022-03-20 13:22:25 --> URI Class Initialized
INFO - 2022-03-20 13:22:25 --> Router Class Initialized
INFO - 2022-03-20 13:22:25 --> Output Class Initialized
INFO - 2022-03-20 13:22:25 --> Security Class Initialized
INFO - 2022-03-20 13:22:25 --> Input Class Initialized
INFO - 2022-03-20 13:22:25 --> Language Class Initialized
INFO - 2022-03-20 13:22:25 --> Loader Class Initialized
INFO - 2022-03-20 13:22:25 --> Helper loaded: url_helper
INFO - 2022-03-20 13:22:25 --> Helper loaded: form_helper
INFO - 2022-03-20 13:22:25 --> Database Driver Class Initialized
INFO - 2022-03-20 13:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:22:25 --> Form Validation Class Initialized
INFO - 2022-03-20 13:22:25 --> Controller Class Initialized
INFO - 2022-03-20 13:22:25 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:22:25 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:22:25 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:22:25 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:22:25 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:22:25 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
INFO - 2022-03-20 13:22:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:22:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:22:25 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:22:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:22:25 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:22:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:22:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:22:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:22:25 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:22:25 --> Final output sent to browser
INFO - 2022-03-20 13:22:50 --> Config Class Initialized
INFO - 2022-03-20 13:22:50 --> Hooks Class Initialized
INFO - 2022-03-20 13:22:50 --> Utf8 Class Initialized
INFO - 2022-03-20 13:22:50 --> URI Class Initialized
INFO - 2022-03-20 13:22:50 --> Router Class Initialized
INFO - 2022-03-20 13:22:50 --> Output Class Initialized
INFO - 2022-03-20 13:22:50 --> Security Class Initialized
INFO - 2022-03-20 13:22:50 --> Input Class Initialized
INFO - 2022-03-20 13:22:50 --> Language Class Initialized
INFO - 2022-03-20 13:22:50 --> Loader Class Initialized
INFO - 2022-03-20 13:22:50 --> Helper loaded: url_helper
INFO - 2022-03-20 13:22:50 --> Helper loaded: form_helper
INFO - 2022-03-20 13:22:50 --> Database Driver Class Initialized
INFO - 2022-03-20 13:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:22:50 --> Form Validation Class Initialized
INFO - 2022-03-20 13:22:50 --> Controller Class Initialized
INFO - 2022-03-20 13:22:50 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:22:50 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:22:50 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:22:50 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:22:50 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:22:50 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
ERROR - 2022-03-20 13:22:50 --> Severity: Notice --> Undefined variable: list C:\laragon\www\list-todo\application\controllers\C_todo_list.php 27
INFO - 2022-03-20 13:22:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:22:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:22:50 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:22:50 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:22:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:22:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:22:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:22:50 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:22:50 --> Final output sent to browser
INFO - 2022-03-20 13:23:33 --> Config Class Initialized
INFO - 2022-03-20 13:23:33 --> Hooks Class Initialized
INFO - 2022-03-20 13:23:33 --> Utf8 Class Initialized
INFO - 2022-03-20 13:23:33 --> URI Class Initialized
INFO - 2022-03-20 13:23:33 --> Router Class Initialized
INFO - 2022-03-20 13:23:33 --> Output Class Initialized
INFO - 2022-03-20 13:23:33 --> Security Class Initialized
INFO - 2022-03-20 13:23:33 --> Input Class Initialized
INFO - 2022-03-20 13:23:33 --> Language Class Initialized
INFO - 2022-03-20 13:23:33 --> Loader Class Initialized
INFO - 2022-03-20 13:23:33 --> Helper loaded: url_helper
INFO - 2022-03-20 13:23:33 --> Helper loaded: form_helper
INFO - 2022-03-20 13:23:33 --> Database Driver Class Initialized
INFO - 2022-03-20 13:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:23:33 --> Form Validation Class Initialized
INFO - 2022-03-20 13:23:33 --> Controller Class Initialized
INFO - 2022-03-20 13:23:33 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:23:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:23:33 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:23:33 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:23:33 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:23:33 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
ERROR - 2022-03-20 13:23:33 --> Severity: Notice --> Undefined variable: list C:\laragon\www\list-todo\application\controllers\C_todo_list.php 27
INFO - 2022-03-20 13:23:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:23:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:23:33 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:23:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:23:33 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:23:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:23:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:23:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:23:33 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:23:33 --> Final output sent to browser
INFO - 2022-03-20 13:23:45 --> Config Class Initialized
INFO - 2022-03-20 13:23:45 --> Hooks Class Initialized
INFO - 2022-03-20 13:23:45 --> Utf8 Class Initialized
INFO - 2022-03-20 13:23:45 --> URI Class Initialized
INFO - 2022-03-20 13:23:45 --> Router Class Initialized
INFO - 2022-03-20 13:23:45 --> Output Class Initialized
INFO - 2022-03-20 13:23:45 --> Security Class Initialized
INFO - 2022-03-20 13:23:45 --> Input Class Initialized
INFO - 2022-03-20 13:23:45 --> Language Class Initialized
INFO - 2022-03-20 13:23:45 --> Loader Class Initialized
INFO - 2022-03-20 13:23:45 --> Helper loaded: url_helper
INFO - 2022-03-20 13:23:45 --> Helper loaded: form_helper
INFO - 2022-03-20 13:23:45 --> Database Driver Class Initialized
INFO - 2022-03-20 13:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:23:45 --> Form Validation Class Initialized
INFO - 2022-03-20 13:23:45 --> Controller Class Initialized
INFO - 2022-03-20 13:23:45 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:23:45 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:23:45 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:23:45 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:23:45 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:23:45 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
INFO - 2022-03-20 13:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:23:45 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:23:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:23:45 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:23:45 --> Final output sent to browser
INFO - 2022-03-20 13:24:06 --> Config Class Initialized
INFO - 2022-03-20 13:24:06 --> Hooks Class Initialized
INFO - 2022-03-20 13:24:06 --> Utf8 Class Initialized
INFO - 2022-03-20 13:24:06 --> URI Class Initialized
INFO - 2022-03-20 13:24:06 --> Router Class Initialized
INFO - 2022-03-20 13:24:06 --> Output Class Initialized
INFO - 2022-03-20 13:24:06 --> Security Class Initialized
INFO - 2022-03-20 13:24:06 --> Input Class Initialized
INFO - 2022-03-20 13:24:06 --> Language Class Initialized
INFO - 2022-03-20 13:24:06 --> Loader Class Initialized
INFO - 2022-03-20 13:24:06 --> Helper loaded: url_helper
INFO - 2022-03-20 13:24:06 --> Helper loaded: form_helper
INFO - 2022-03-20 13:24:07 --> Database Driver Class Initialized
INFO - 2022-03-20 13:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:24:07 --> Form Validation Class Initialized
INFO - 2022-03-20 13:24:07 --> Controller Class Initialized
INFO - 2022-03-20 13:24:07 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:24:07 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:24:07 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:24:07 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:24:07 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:24:07 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
ERROR - 2022-03-20 13:24:07 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 27
INFO - 2022-03-20 13:24:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:24:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:24:07 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:24:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:24:07 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:24:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:24:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:24:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:24:07 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:24:07 --> Final output sent to browser
INFO - 2022-03-20 13:24:16 --> Config Class Initialized
INFO - 2022-03-20 13:24:16 --> Hooks Class Initialized
INFO - 2022-03-20 13:24:16 --> Utf8 Class Initialized
INFO - 2022-03-20 13:24:16 --> URI Class Initialized
INFO - 2022-03-20 13:24:16 --> Router Class Initialized
INFO - 2022-03-20 13:24:16 --> Output Class Initialized
INFO - 2022-03-20 13:24:16 --> Security Class Initialized
INFO - 2022-03-20 13:24:16 --> Input Class Initialized
INFO - 2022-03-20 13:24:16 --> Language Class Initialized
INFO - 2022-03-20 13:24:16 --> Loader Class Initialized
INFO - 2022-03-20 13:24:16 --> Helper loaded: url_helper
INFO - 2022-03-20 13:24:16 --> Helper loaded: form_helper
INFO - 2022-03-20 13:24:16 --> Database Driver Class Initialized
INFO - 2022-03-20 13:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:24:16 --> Form Validation Class Initialized
INFO - 2022-03-20 13:24:16 --> Controller Class Initialized
INFO - 2022-03-20 13:24:16 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:24:16 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:24:16 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:24:16 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:24:16 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:24:16 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
ERROR - 2022-03-20 13:24:16 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 28
INFO - 2022-03-20 13:24:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:24:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:24:16 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:24:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:24:16 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:24:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:24:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:24:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:24:16 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:24:16 --> Final output sent to browser
INFO - 2022-03-20 13:24:27 --> Config Class Initialized
INFO - 2022-03-20 13:24:27 --> Hooks Class Initialized
INFO - 2022-03-20 13:24:27 --> Utf8 Class Initialized
INFO - 2022-03-20 13:24:27 --> URI Class Initialized
INFO - 2022-03-20 13:24:27 --> Router Class Initialized
INFO - 2022-03-20 13:24:27 --> Output Class Initialized
INFO - 2022-03-20 13:24:27 --> Security Class Initialized
INFO - 2022-03-20 13:24:27 --> Input Class Initialized
INFO - 2022-03-20 13:24:27 --> Language Class Initialized
INFO - 2022-03-20 13:24:27 --> Loader Class Initialized
INFO - 2022-03-20 13:24:27 --> Helper loaded: url_helper
INFO - 2022-03-20 13:24:27 --> Helper loaded: form_helper
INFO - 2022-03-20 13:24:27 --> Database Driver Class Initialized
INFO - 2022-03-20 13:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:24:27 --> Form Validation Class Initialized
INFO - 2022-03-20 13:24:27 --> Controller Class Initialized
INFO - 2022-03-20 13:24:27 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:24:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:24:27 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:24:27 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:24:27 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:24:27 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 28
INFO - 2022-03-20 13:24:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:24:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:24:27 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:24:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:24:27 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:24:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:24:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:24:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:24:27 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:24:27 --> Final output sent to browser
INFO - 2022-03-20 13:24:54 --> Config Class Initialized
INFO - 2022-03-20 13:24:54 --> Hooks Class Initialized
INFO - 2022-03-20 13:24:54 --> Utf8 Class Initialized
INFO - 2022-03-20 13:24:54 --> URI Class Initialized
INFO - 2022-03-20 13:24:54 --> Router Class Initialized
INFO - 2022-03-20 13:24:54 --> Output Class Initialized
INFO - 2022-03-20 13:24:54 --> Security Class Initialized
INFO - 2022-03-20 13:24:54 --> Input Class Initialized
INFO - 2022-03-20 13:24:54 --> Language Class Initialized
INFO - 2022-03-20 13:24:55 --> Loader Class Initialized
INFO - 2022-03-20 13:24:55 --> Helper loaded: url_helper
INFO - 2022-03-20 13:24:55 --> Helper loaded: form_helper
INFO - 2022-03-20 13:24:55 --> Database Driver Class Initialized
INFO - 2022-03-20 13:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:24:55 --> Form Validation Class Initialized
INFO - 2022-03-20 13:24:55 --> Controller Class Initialized
INFO - 2022-03-20 13:24:55 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:24:55 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:24:55 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:24:55 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:24:55 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:24:55 --> Severity: Notice --> Undefined index: todo_group C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
ERROR - 2022-03-20 13:24:55 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 28
INFO - 2022-03-20 13:24:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:24:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:24:55 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:24:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:24:55 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:24:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:24:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:24:55 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:24:55 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:24:55 --> Final output sent to browser
INFO - 2022-03-20 13:26:52 --> Config Class Initialized
INFO - 2022-03-20 13:26:52 --> Hooks Class Initialized
INFO - 2022-03-20 13:26:52 --> Utf8 Class Initialized
INFO - 2022-03-20 13:26:52 --> URI Class Initialized
INFO - 2022-03-20 13:26:52 --> Router Class Initialized
INFO - 2022-03-20 13:26:52 --> Output Class Initialized
INFO - 2022-03-20 13:26:52 --> Security Class Initialized
INFO - 2022-03-20 13:26:52 --> Input Class Initialized
INFO - 2022-03-20 13:26:52 --> Language Class Initialized
INFO - 2022-03-20 13:26:52 --> Loader Class Initialized
INFO - 2022-03-20 13:26:52 --> Helper loaded: url_helper
INFO - 2022-03-20 13:26:52 --> Helper loaded: form_helper
INFO - 2022-03-20 13:26:52 --> Database Driver Class Initialized
INFO - 2022-03-20 13:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:26:52 --> Form Validation Class Initialized
INFO - 2022-03-20 13:26:52 --> Controller Class Initialized
INFO - 2022-03-20 13:26:52 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:26:52 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:26:52 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:26:52 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:26:52 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:26:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 44
ERROR - 2022-03-20 13:26:52 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:26:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:26:52 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:26:52 --> Final output sent to browser
INFO - 2022-03-20 13:27:07 --> Config Class Initialized
INFO - 2022-03-20 13:27:07 --> Hooks Class Initialized
INFO - 2022-03-20 13:27:07 --> Utf8 Class Initialized
INFO - 2022-03-20 13:27:07 --> URI Class Initialized
INFO - 2022-03-20 13:27:07 --> Router Class Initialized
INFO - 2022-03-20 13:27:07 --> Output Class Initialized
INFO - 2022-03-20 13:27:07 --> Security Class Initialized
INFO - 2022-03-20 13:27:07 --> Input Class Initialized
INFO - 2022-03-20 13:27:07 --> Language Class Initialized
INFO - 2022-03-20 13:27:07 --> Loader Class Initialized
INFO - 2022-03-20 13:27:07 --> Helper loaded: url_helper
INFO - 2022-03-20 13:27:07 --> Helper loaded: form_helper
INFO - 2022-03-20 13:27:07 --> Database Driver Class Initialized
INFO - 2022-03-20 13:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:27:07 --> Form Validation Class Initialized
INFO - 2022-03-20 13:27:07 --> Controller Class Initialized
INFO - 2022-03-20 13:27:07 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:27:07 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:27:07 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:27:07 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:27:07 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:27:07 --> Final output sent to browser
INFO - 2022-03-20 13:27:16 --> Config Class Initialized
INFO - 2022-03-20 13:27:16 --> Hooks Class Initialized
INFO - 2022-03-20 13:27:16 --> Utf8 Class Initialized
INFO - 2022-03-20 13:27:16 --> URI Class Initialized
INFO - 2022-03-20 13:27:16 --> Router Class Initialized
INFO - 2022-03-20 13:27:16 --> Output Class Initialized
INFO - 2022-03-20 13:27:16 --> Security Class Initialized
INFO - 2022-03-20 13:27:16 --> Input Class Initialized
INFO - 2022-03-20 13:27:16 --> Language Class Initialized
INFO - 2022-03-20 13:27:16 --> Loader Class Initialized
INFO - 2022-03-20 13:27:16 --> Helper loaded: url_helper
INFO - 2022-03-20 13:27:16 --> Helper loaded: form_helper
INFO - 2022-03-20 13:27:16 --> Database Driver Class Initialized
INFO - 2022-03-20 13:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:27:16 --> Form Validation Class Initialized
INFO - 2022-03-20 13:27:16 --> Controller Class Initialized
INFO - 2022-03-20 13:27:16 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:27:16 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:27:16 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:27:16 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:27:16 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:27:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:27:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:27:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 44
ERROR - 2022-03-20 13:27:16 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:27:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:27:16 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:27:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:27:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:27:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:27:16 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:27:16 --> Final output sent to browser
INFO - 2022-03-20 13:27:29 --> Config Class Initialized
INFO - 2022-03-20 13:27:29 --> Hooks Class Initialized
INFO - 2022-03-20 13:27:29 --> Utf8 Class Initialized
INFO - 2022-03-20 13:27:29 --> URI Class Initialized
INFO - 2022-03-20 13:27:29 --> Router Class Initialized
INFO - 2022-03-20 13:27:29 --> Output Class Initialized
INFO - 2022-03-20 13:27:29 --> Security Class Initialized
INFO - 2022-03-20 13:27:29 --> Input Class Initialized
INFO - 2022-03-20 13:27:29 --> Language Class Initialized
INFO - 2022-03-20 13:27:29 --> Loader Class Initialized
INFO - 2022-03-20 13:27:29 --> Helper loaded: url_helper
INFO - 2022-03-20 13:27:29 --> Helper loaded: form_helper
INFO - 2022-03-20 13:27:29 --> Database Driver Class Initialized
INFO - 2022-03-20 13:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:27:29 --> Form Validation Class Initialized
INFO - 2022-03-20 13:27:29 --> Controller Class Initialized
INFO - 2022-03-20 13:27:29 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:27:29 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:27:29 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:27:29 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:27:29 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:27:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:27:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:27:29 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:27:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:27:29 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:27:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:27:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:27:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:27:29 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:27:29 --> Final output sent to browser
INFO - 2022-03-20 13:28:16 --> Config Class Initialized
INFO - 2022-03-20 13:28:16 --> Hooks Class Initialized
INFO - 2022-03-20 13:28:16 --> Utf8 Class Initialized
INFO - 2022-03-20 13:28:16 --> URI Class Initialized
INFO - 2022-03-20 13:28:16 --> Router Class Initialized
INFO - 2022-03-20 13:28:16 --> Output Class Initialized
INFO - 2022-03-20 13:28:16 --> Security Class Initialized
INFO - 2022-03-20 13:28:16 --> Input Class Initialized
INFO - 2022-03-20 13:28:16 --> Language Class Initialized
INFO - 2022-03-20 13:28:16 --> Loader Class Initialized
INFO - 2022-03-20 13:28:16 --> Helper loaded: url_helper
INFO - 2022-03-20 13:28:16 --> Helper loaded: form_helper
INFO - 2022-03-20 13:28:16 --> Database Driver Class Initialized
INFO - 2022-03-20 13:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:28:16 --> Form Validation Class Initialized
INFO - 2022-03-20 13:28:16 --> Controller Class Initialized
INFO - 2022-03-20 13:28:16 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:28:16 --> Config Class Initialized
INFO - 2022-03-20 13:28:16 --> Hooks Class Initialized
INFO - 2022-03-20 13:28:16 --> Utf8 Class Initialized
INFO - 2022-03-20 13:28:16 --> URI Class Initialized
INFO - 2022-03-20 13:28:16 --> Router Class Initialized
INFO - 2022-03-20 13:28:16 --> Output Class Initialized
INFO - 2022-03-20 13:28:16 --> Security Class Initialized
INFO - 2022-03-20 13:28:16 --> Input Class Initialized
INFO - 2022-03-20 13:28:16 --> Language Class Initialized
INFO - 2022-03-20 13:28:16 --> Loader Class Initialized
INFO - 2022-03-20 13:28:16 --> Helper loaded: url_helper
INFO - 2022-03-20 13:28:16 --> Helper loaded: form_helper
INFO - 2022-03-20 13:28:16 --> Database Driver Class Initialized
INFO - 2022-03-20 13:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:28:16 --> Form Validation Class Initialized
INFO - 2022-03-20 13:28:16 --> Controller Class Initialized
INFO - 2022-03-20 13:28:16 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:28:16 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 13:28:16 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 13:28:16 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 13:28:16 --> Final output sent to browser
INFO - 2022-03-20 13:28:21 --> Config Class Initialized
INFO - 2022-03-20 13:28:21 --> Hooks Class Initialized
INFO - 2022-03-20 13:28:21 --> Utf8 Class Initialized
INFO - 2022-03-20 13:28:21 --> URI Class Initialized
INFO - 2022-03-20 13:28:21 --> Router Class Initialized
INFO - 2022-03-20 13:28:21 --> Output Class Initialized
INFO - 2022-03-20 13:28:21 --> Security Class Initialized
INFO - 2022-03-20 13:28:21 --> Input Class Initialized
INFO - 2022-03-20 13:28:21 --> Language Class Initialized
INFO - 2022-03-20 13:28:21 --> Loader Class Initialized
INFO - 2022-03-20 13:28:21 --> Helper loaded: url_helper
INFO - 2022-03-20 13:28:21 --> Helper loaded: form_helper
INFO - 2022-03-20 13:28:21 --> Database Driver Class Initialized
INFO - 2022-03-20 13:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:28:21 --> Form Validation Class Initialized
INFO - 2022-03-20 13:28:21 --> Controller Class Initialized
INFO - 2022-03-20 13:28:21 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:28:21 --> Config Class Initialized
INFO - 2022-03-20 13:28:21 --> Hooks Class Initialized
INFO - 2022-03-20 13:28:21 --> Utf8 Class Initialized
INFO - 2022-03-20 13:28:21 --> URI Class Initialized
INFO - 2022-03-20 13:28:21 --> Router Class Initialized
INFO - 2022-03-20 13:28:21 --> Output Class Initialized
INFO - 2022-03-20 13:28:21 --> Security Class Initialized
INFO - 2022-03-20 13:28:21 --> Input Class Initialized
INFO - 2022-03-20 13:28:21 --> Language Class Initialized
INFO - 2022-03-20 13:28:21 --> Loader Class Initialized
INFO - 2022-03-20 13:28:21 --> Helper loaded: url_helper
INFO - 2022-03-20 13:28:21 --> Helper loaded: form_helper
INFO - 2022-03-20 13:28:21 --> Database Driver Class Initialized
INFO - 2022-03-20 13:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:28:21 --> Form Validation Class Initialized
INFO - 2022-03-20 13:28:21 --> Controller Class Initialized
INFO - 2022-03-20 13:28:21 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:28:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:28:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:28:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:28:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:28:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:28:22 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 13:28:22 --> Final output sent to browser
INFO - 2022-03-20 13:28:23 --> Config Class Initialized
INFO - 2022-03-20 13:28:23 --> Hooks Class Initialized
INFO - 2022-03-20 13:28:23 --> Utf8 Class Initialized
INFO - 2022-03-20 13:28:23 --> URI Class Initialized
INFO - 2022-03-20 13:28:23 --> Router Class Initialized
INFO - 2022-03-20 13:28:23 --> Output Class Initialized
INFO - 2022-03-20 13:28:23 --> Security Class Initialized
INFO - 2022-03-20 13:28:23 --> Input Class Initialized
INFO - 2022-03-20 13:28:23 --> Language Class Initialized
INFO - 2022-03-20 13:28:23 --> Loader Class Initialized
INFO - 2022-03-20 13:28:23 --> Helper loaded: url_helper
INFO - 2022-03-20 13:28:23 --> Helper loaded: form_helper
INFO - 2022-03-20 13:28:23 --> Database Driver Class Initialized
INFO - 2022-03-20 13:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:28:23 --> Form Validation Class Initialized
INFO - 2022-03-20 13:28:23 --> Controller Class Initialized
INFO - 2022-03-20 13:28:23 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:28:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:28:23 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:28:23 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:28:23 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:28:23 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
INFO - 2022-03-20 13:28:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:28:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:28:23 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:28:23 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:28:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:28:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:28:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:28:23 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:28:23 --> Final output sent to browser
INFO - 2022-03-20 13:28:52 --> Config Class Initialized
INFO - 2022-03-20 13:28:52 --> Hooks Class Initialized
INFO - 2022-03-20 13:28:52 --> Utf8 Class Initialized
INFO - 2022-03-20 13:28:52 --> URI Class Initialized
INFO - 2022-03-20 13:28:52 --> Router Class Initialized
INFO - 2022-03-20 13:28:52 --> Output Class Initialized
INFO - 2022-03-20 13:28:52 --> Security Class Initialized
INFO - 2022-03-20 13:28:52 --> Input Class Initialized
INFO - 2022-03-20 13:28:52 --> Language Class Initialized
INFO - 2022-03-20 13:28:52 --> Loader Class Initialized
INFO - 2022-03-20 13:28:52 --> Helper loaded: url_helper
INFO - 2022-03-20 13:28:52 --> Helper loaded: form_helper
INFO - 2022-03-20 13:28:52 --> Database Driver Class Initialized
INFO - 2022-03-20 13:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:28:52 --> Form Validation Class Initialized
INFO - 2022-03-20 13:28:52 --> Controller Class Initialized
INFO - 2022-03-20 13:28:52 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:28:52 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:28:52 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:28:52 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:28:52 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:28:52 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:28:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:28:52 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:28:52 --> Final output sent to browser
INFO - 2022-03-20 13:29:15 --> Config Class Initialized
INFO - 2022-03-20 13:29:15 --> Hooks Class Initialized
INFO - 2022-03-20 13:29:15 --> Utf8 Class Initialized
INFO - 2022-03-20 13:29:15 --> URI Class Initialized
INFO - 2022-03-20 13:29:15 --> Router Class Initialized
INFO - 2022-03-20 13:29:15 --> Output Class Initialized
INFO - 2022-03-20 13:29:15 --> Security Class Initialized
INFO - 2022-03-20 13:29:15 --> Input Class Initialized
INFO - 2022-03-20 13:29:15 --> Language Class Initialized
INFO - 2022-03-20 13:29:15 --> Loader Class Initialized
INFO - 2022-03-20 13:29:15 --> Helper loaded: url_helper
INFO - 2022-03-20 13:29:15 --> Helper loaded: form_helper
INFO - 2022-03-20 13:29:15 --> Database Driver Class Initialized
INFO - 2022-03-20 13:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:29:15 --> Form Validation Class Initialized
INFO - 2022-03-20 13:29:15 --> Controller Class Initialized
INFO - 2022-03-20 13:29:15 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:29:15 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:29:15 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:29:15 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:29:15 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:29:15 --> Severity: Notice --> Trying to get property of non-object C:\laragon\www\list-todo\application\controllers\C_todo_list.php 26
INFO - 2022-03-20 13:29:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:29:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:29:15 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:29:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:29:15 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:29:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:29:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:29:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:29:15 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:29:15 --> Final output sent to browser
INFO - 2022-03-20 13:30:16 --> Config Class Initialized
INFO - 2022-03-20 13:30:16 --> Hooks Class Initialized
INFO - 2022-03-20 13:30:16 --> Utf8 Class Initialized
INFO - 2022-03-20 13:30:16 --> URI Class Initialized
INFO - 2022-03-20 13:30:16 --> Router Class Initialized
INFO - 2022-03-20 13:30:16 --> Output Class Initialized
INFO - 2022-03-20 13:30:16 --> Security Class Initialized
INFO - 2022-03-20 13:30:16 --> Input Class Initialized
INFO - 2022-03-20 13:30:16 --> Language Class Initialized
INFO - 2022-03-20 13:30:16 --> Loader Class Initialized
INFO - 2022-03-20 13:30:16 --> Helper loaded: url_helper
INFO - 2022-03-20 13:30:16 --> Helper loaded: form_helper
INFO - 2022-03-20 13:30:16 --> Database Driver Class Initialized
INFO - 2022-03-20 13:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:30:16 --> Form Validation Class Initialized
INFO - 2022-03-20 13:30:16 --> Controller Class Initialized
INFO - 2022-03-20 13:30:16 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:30:16 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:30:16 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:30:16 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:30:16 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:30:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:30:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:30:16 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:30:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:30:16 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:30:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:30:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:30:16 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:30:16 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:30:16 --> Final output sent to browser
INFO - 2022-03-20 13:30:32 --> Config Class Initialized
INFO - 2022-03-20 13:30:32 --> Hooks Class Initialized
INFO - 2022-03-20 13:30:32 --> Utf8 Class Initialized
INFO - 2022-03-20 13:30:32 --> URI Class Initialized
INFO - 2022-03-20 13:30:32 --> Router Class Initialized
INFO - 2022-03-20 13:30:32 --> Output Class Initialized
INFO - 2022-03-20 13:30:32 --> Security Class Initialized
INFO - 2022-03-20 13:30:32 --> Input Class Initialized
INFO - 2022-03-20 13:30:32 --> Language Class Initialized
INFO - 2022-03-20 13:30:32 --> Loader Class Initialized
INFO - 2022-03-20 13:30:32 --> Helper loaded: url_helper
INFO - 2022-03-20 13:30:33 --> Helper loaded: form_helper
INFO - 2022-03-20 13:30:33 --> Database Driver Class Initialized
INFO - 2022-03-20 13:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:30:33 --> Form Validation Class Initialized
INFO - 2022-03-20 13:30:33 --> Controller Class Initialized
INFO - 2022-03-20 13:30:33 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:30:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:30:33 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:30:33 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:30:33 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:30:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:30:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:30:33 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:30:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:30:33 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:30:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:30:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:30:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:30:33 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:30:33 --> Final output sent to browser
INFO - 2022-03-20 13:30:40 --> Config Class Initialized
INFO - 2022-03-20 13:30:40 --> Hooks Class Initialized
INFO - 2022-03-20 13:30:40 --> Utf8 Class Initialized
INFO - 2022-03-20 13:30:40 --> URI Class Initialized
INFO - 2022-03-20 13:30:40 --> Router Class Initialized
INFO - 2022-03-20 13:30:40 --> Output Class Initialized
INFO - 2022-03-20 13:30:40 --> Security Class Initialized
INFO - 2022-03-20 13:30:40 --> Input Class Initialized
INFO - 2022-03-20 13:30:40 --> Language Class Initialized
INFO - 2022-03-20 13:30:40 --> Loader Class Initialized
INFO - 2022-03-20 13:30:40 --> Helper loaded: url_helper
INFO - 2022-03-20 13:30:40 --> Helper loaded: form_helper
INFO - 2022-03-20 13:30:40 --> Database Driver Class Initialized
INFO - 2022-03-20 13:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:30:40 --> Form Validation Class Initialized
INFO - 2022-03-20 13:30:40 --> Controller Class Initialized
INFO - 2022-03-20 13:30:40 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:30:40 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:30:40 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:30:40 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:30:40 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:30:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:30:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:30:40 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:30:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:30:40 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:30:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:30:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:30:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:30:40 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:30:40 --> Final output sent to browser
INFO - 2022-03-20 13:31:22 --> Config Class Initialized
INFO - 2022-03-20 13:31:22 --> Hooks Class Initialized
INFO - 2022-03-20 13:31:22 --> Utf8 Class Initialized
INFO - 2022-03-20 13:31:22 --> URI Class Initialized
INFO - 2022-03-20 13:31:22 --> Router Class Initialized
INFO - 2022-03-20 13:31:22 --> Output Class Initialized
INFO - 2022-03-20 13:31:22 --> Security Class Initialized
INFO - 2022-03-20 13:31:22 --> Input Class Initialized
INFO - 2022-03-20 13:31:22 --> Language Class Initialized
INFO - 2022-03-20 13:31:22 --> Loader Class Initialized
INFO - 2022-03-20 13:31:22 --> Helper loaded: url_helper
INFO - 2022-03-20 13:31:22 --> Helper loaded: form_helper
INFO - 2022-03-20 13:31:22 --> Database Driver Class Initialized
INFO - 2022-03-20 13:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:31:22 --> Form Validation Class Initialized
INFO - 2022-03-20 13:31:22 --> Controller Class Initialized
INFO - 2022-03-20 13:31:22 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:31:22 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:31:22 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:31:22 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:31:22 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:31:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:31:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:31:22 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:31:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:31:22 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:31:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:31:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:31:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:31:22 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:31:22 --> Final output sent to browser
INFO - 2022-03-20 13:31:33 --> Config Class Initialized
INFO - 2022-03-20 13:31:33 --> Hooks Class Initialized
INFO - 2022-03-20 13:31:33 --> Utf8 Class Initialized
INFO - 2022-03-20 13:31:33 --> URI Class Initialized
INFO - 2022-03-20 13:31:33 --> Router Class Initialized
INFO - 2022-03-20 13:31:33 --> Output Class Initialized
INFO - 2022-03-20 13:31:33 --> Security Class Initialized
INFO - 2022-03-20 13:31:33 --> Input Class Initialized
INFO - 2022-03-20 13:31:33 --> Language Class Initialized
INFO - 2022-03-20 13:31:33 --> Loader Class Initialized
INFO - 2022-03-20 13:31:33 --> Helper loaded: url_helper
INFO - 2022-03-20 13:31:33 --> Helper loaded: form_helper
INFO - 2022-03-20 13:31:33 --> Database Driver Class Initialized
INFO - 2022-03-20 13:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:31:33 --> Form Validation Class Initialized
INFO - 2022-03-20 13:31:33 --> Controller Class Initialized
INFO - 2022-03-20 13:31:33 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:31:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:31:33 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:31:33 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:31:33 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:31:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:31:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:31:33 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:31:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:31:33 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:31:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:31:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:31:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:31:33 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:31:33 --> Final output sent to browser
INFO - 2022-03-20 13:31:38 --> Config Class Initialized
INFO - 2022-03-20 13:31:38 --> Hooks Class Initialized
INFO - 2022-03-20 13:31:38 --> Utf8 Class Initialized
INFO - 2022-03-20 13:31:38 --> URI Class Initialized
INFO - 2022-03-20 13:31:38 --> Router Class Initialized
INFO - 2022-03-20 13:31:38 --> Output Class Initialized
INFO - 2022-03-20 13:31:38 --> Security Class Initialized
INFO - 2022-03-20 13:31:38 --> Input Class Initialized
INFO - 2022-03-20 13:31:38 --> Language Class Initialized
INFO - 2022-03-20 13:31:38 --> Loader Class Initialized
INFO - 2022-03-20 13:31:38 --> Helper loaded: url_helper
INFO - 2022-03-20 13:31:38 --> Helper loaded: form_helper
INFO - 2022-03-20 13:31:38 --> Database Driver Class Initialized
INFO - 2022-03-20 13:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:31:38 --> Form Validation Class Initialized
INFO - 2022-03-20 13:31:38 --> Controller Class Initialized
INFO - 2022-03-20 13:31:38 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:31:38 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:31:38 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:31:38 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:31:38 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:31:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:31:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:31:38 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:31:38 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:31:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:31:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:31:38 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:31:38 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:31:38 --> Final output sent to browser
INFO - 2022-03-20 13:31:55 --> Config Class Initialized
INFO - 2022-03-20 13:31:55 --> Hooks Class Initialized
INFO - 2022-03-20 13:31:55 --> Utf8 Class Initialized
INFO - 2022-03-20 13:31:55 --> URI Class Initialized
INFO - 2022-03-20 13:31:55 --> Router Class Initialized
INFO - 2022-03-20 13:31:55 --> Output Class Initialized
INFO - 2022-03-20 13:31:55 --> Security Class Initialized
INFO - 2022-03-20 13:31:55 --> Input Class Initialized
INFO - 2022-03-20 13:31:55 --> Language Class Initialized
INFO - 2022-03-20 13:31:55 --> Loader Class Initialized
INFO - 2022-03-20 13:31:55 --> Helper loaded: url_helper
INFO - 2022-03-20 13:31:55 --> Helper loaded: form_helper
INFO - 2022-03-20 13:31:55 --> Database Driver Class Initialized
INFO - 2022-03-20 13:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:31:55 --> Form Validation Class Initialized
INFO - 2022-03-20 13:31:55 --> Controller Class Initialized
INFO - 2022-03-20 13:31:55 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:31:55 --> Config Class Initialized
INFO - 2022-03-20 13:31:55 --> Hooks Class Initialized
INFO - 2022-03-20 13:31:55 --> Utf8 Class Initialized
INFO - 2022-03-20 13:31:55 --> URI Class Initialized
INFO - 2022-03-20 13:31:55 --> Router Class Initialized
INFO - 2022-03-20 13:31:55 --> Output Class Initialized
INFO - 2022-03-20 13:31:55 --> Security Class Initialized
INFO - 2022-03-20 13:31:55 --> Input Class Initialized
INFO - 2022-03-20 13:31:55 --> Language Class Initialized
INFO - 2022-03-20 13:31:55 --> Loader Class Initialized
INFO - 2022-03-20 13:31:55 --> Helper loaded: url_helper
INFO - 2022-03-20 13:31:55 --> Helper loaded: form_helper
INFO - 2022-03-20 13:31:55 --> Database Driver Class Initialized
INFO - 2022-03-20 13:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:31:55 --> Form Validation Class Initialized
INFO - 2022-03-20 13:31:55 --> Controller Class Initialized
INFO - 2022-03-20 13:31:55 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:31:55 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 13:31:55 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 13:31:55 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 13:31:55 --> Final output sent to browser
INFO - 2022-03-20 13:31:58 --> Config Class Initialized
INFO - 2022-03-20 13:31:58 --> Hooks Class Initialized
INFO - 2022-03-20 13:31:58 --> Utf8 Class Initialized
INFO - 2022-03-20 13:31:58 --> URI Class Initialized
INFO - 2022-03-20 13:31:58 --> Router Class Initialized
INFO - 2022-03-20 13:31:59 --> Output Class Initialized
INFO - 2022-03-20 13:31:59 --> Security Class Initialized
INFO - 2022-03-20 13:31:59 --> Input Class Initialized
INFO - 2022-03-20 13:31:59 --> Language Class Initialized
INFO - 2022-03-20 13:31:59 --> Loader Class Initialized
INFO - 2022-03-20 13:31:59 --> Helper loaded: url_helper
INFO - 2022-03-20 13:31:59 --> Helper loaded: form_helper
INFO - 2022-03-20 13:31:59 --> Database Driver Class Initialized
INFO - 2022-03-20 13:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:31:59 --> Form Validation Class Initialized
INFO - 2022-03-20 13:31:59 --> Controller Class Initialized
INFO - 2022-03-20 13:31:59 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:31:59 --> Config Class Initialized
INFO - 2022-03-20 13:31:59 --> Hooks Class Initialized
INFO - 2022-03-20 13:31:59 --> Utf8 Class Initialized
INFO - 2022-03-20 13:31:59 --> URI Class Initialized
INFO - 2022-03-20 13:31:59 --> Router Class Initialized
INFO - 2022-03-20 13:31:59 --> Output Class Initialized
INFO - 2022-03-20 13:31:59 --> Security Class Initialized
INFO - 2022-03-20 13:31:59 --> Input Class Initialized
INFO - 2022-03-20 13:31:59 --> Language Class Initialized
INFO - 2022-03-20 13:31:59 --> Loader Class Initialized
INFO - 2022-03-20 13:31:59 --> Helper loaded: url_helper
INFO - 2022-03-20 13:31:59 --> Helper loaded: form_helper
INFO - 2022-03-20 13:31:59 --> Database Driver Class Initialized
INFO - 2022-03-20 13:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:31:59 --> Form Validation Class Initialized
INFO - 2022-03-20 13:31:59 --> Controller Class Initialized
INFO - 2022-03-20 13:31:59 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:31:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:31:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:31:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:31:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:31:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:31:59 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 13:31:59 --> Final output sent to browser
INFO - 2022-03-20 13:32:00 --> Config Class Initialized
INFO - 2022-03-20 13:32:00 --> Hooks Class Initialized
INFO - 2022-03-20 13:32:01 --> Utf8 Class Initialized
INFO - 2022-03-20 13:32:01 --> URI Class Initialized
INFO - 2022-03-20 13:32:01 --> Router Class Initialized
INFO - 2022-03-20 13:32:01 --> Output Class Initialized
INFO - 2022-03-20 13:32:01 --> Security Class Initialized
INFO - 2022-03-20 13:32:01 --> Input Class Initialized
INFO - 2022-03-20 13:32:01 --> Language Class Initialized
INFO - 2022-03-20 13:32:01 --> Loader Class Initialized
INFO - 2022-03-20 13:32:01 --> Helper loaded: url_helper
INFO - 2022-03-20 13:32:01 --> Helper loaded: form_helper
INFO - 2022-03-20 13:32:01 --> Database Driver Class Initialized
INFO - 2022-03-20 13:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:32:01 --> Form Validation Class Initialized
INFO - 2022-03-20 13:32:01 --> Controller Class Initialized
INFO - 2022-03-20 13:32:01 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:32:01 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:32:01 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:32:01 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:32:01 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:32:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:32:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:32:01 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:32:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:32:01 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:32:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:32:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:32:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:32:01 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:32:01 --> Final output sent to browser
INFO - 2022-03-20 13:32:32 --> Config Class Initialized
INFO - 2022-03-20 13:32:32 --> Hooks Class Initialized
INFO - 2022-03-20 13:32:32 --> Utf8 Class Initialized
INFO - 2022-03-20 13:32:32 --> URI Class Initialized
INFO - 2022-03-20 13:32:32 --> Router Class Initialized
INFO - 2022-03-20 13:32:32 --> Output Class Initialized
INFO - 2022-03-20 13:32:32 --> Security Class Initialized
INFO - 2022-03-20 13:32:32 --> Input Class Initialized
INFO - 2022-03-20 13:32:32 --> Language Class Initialized
INFO - 2022-03-20 13:32:32 --> Loader Class Initialized
INFO - 2022-03-20 13:32:32 --> Helper loaded: url_helper
INFO - 2022-03-20 13:32:32 --> Helper loaded: form_helper
INFO - 2022-03-20 13:32:32 --> Database Driver Class Initialized
INFO - 2022-03-20 13:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:32:32 --> Form Validation Class Initialized
INFO - 2022-03-20 13:32:32 --> Controller Class Initialized
INFO - 2022-03-20 13:32:32 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:32:32 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:32:32 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:32:32 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:32:32 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:32:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:32:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:32:32 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:32:32 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:32:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:32:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:32:32 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:32:32 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:32:32 --> Final output sent to browser
INFO - 2022-03-20 13:33:14 --> Config Class Initialized
INFO - 2022-03-20 13:33:14 --> Hooks Class Initialized
INFO - 2022-03-20 13:33:14 --> Utf8 Class Initialized
INFO - 2022-03-20 13:33:14 --> URI Class Initialized
INFO - 2022-03-20 13:33:14 --> Router Class Initialized
INFO - 2022-03-20 13:33:14 --> Output Class Initialized
INFO - 2022-03-20 13:33:14 --> Security Class Initialized
INFO - 2022-03-20 13:33:15 --> Input Class Initialized
INFO - 2022-03-20 13:33:15 --> Language Class Initialized
INFO - 2022-03-20 13:33:15 --> Loader Class Initialized
INFO - 2022-03-20 13:33:15 --> Helper loaded: url_helper
INFO - 2022-03-20 13:33:15 --> Helper loaded: form_helper
INFO - 2022-03-20 13:33:15 --> Database Driver Class Initialized
INFO - 2022-03-20 13:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:33:15 --> Form Validation Class Initialized
INFO - 2022-03-20 13:33:15 --> Controller Class Initialized
INFO - 2022-03-20 13:33:15 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:33:15 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:33:15 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:33:15 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:33:15 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:33:15 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:33:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:33:15 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:33:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:33:15 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:33:15 --> Final output sent to browser
INFO - 2022-03-20 13:33:22 --> Config Class Initialized
INFO - 2022-03-20 13:33:22 --> Hooks Class Initialized
INFO - 2022-03-20 13:33:22 --> Utf8 Class Initialized
INFO - 2022-03-20 13:33:23 --> URI Class Initialized
INFO - 2022-03-20 13:33:23 --> Router Class Initialized
INFO - 2022-03-20 13:33:23 --> Output Class Initialized
INFO - 2022-03-20 13:33:23 --> Security Class Initialized
INFO - 2022-03-20 13:33:23 --> Input Class Initialized
INFO - 2022-03-20 13:33:23 --> Language Class Initialized
INFO - 2022-03-20 13:33:23 --> Loader Class Initialized
INFO - 2022-03-20 13:33:23 --> Helper loaded: url_helper
INFO - 2022-03-20 13:33:23 --> Helper loaded: form_helper
INFO - 2022-03-20 13:33:23 --> Database Driver Class Initialized
INFO - 2022-03-20 13:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:33:23 --> Form Validation Class Initialized
INFO - 2022-03-20 13:33:23 --> Controller Class Initialized
INFO - 2022-03-20 13:33:23 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:33:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:33:23 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:33:23 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:33:23 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:33:23 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:33:23 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:33:23 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:33:23 --> Final output sent to browser
INFO - 2022-03-20 13:34:20 --> Config Class Initialized
INFO - 2022-03-20 13:34:20 --> Hooks Class Initialized
INFO - 2022-03-20 13:34:20 --> Utf8 Class Initialized
INFO - 2022-03-20 13:34:20 --> URI Class Initialized
INFO - 2022-03-20 13:34:20 --> Router Class Initialized
INFO - 2022-03-20 13:34:20 --> Output Class Initialized
INFO - 2022-03-20 13:34:20 --> Security Class Initialized
INFO - 2022-03-20 13:34:20 --> Input Class Initialized
INFO - 2022-03-20 13:34:20 --> Language Class Initialized
INFO - 2022-03-20 13:34:20 --> Loader Class Initialized
INFO - 2022-03-20 13:34:20 --> Helper loaded: url_helper
INFO - 2022-03-20 13:34:20 --> Helper loaded: form_helper
INFO - 2022-03-20 13:34:20 --> Database Driver Class Initialized
INFO - 2022-03-20 13:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:34:20 --> Form Validation Class Initialized
INFO - 2022-03-20 13:34:20 --> Controller Class Initialized
INFO - 2022-03-20 13:34:20 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:34:20 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:34:20 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:34:20 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:34:20 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:34:20 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:34:20 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:34:20 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:34:20 --> Final output sent to browser
INFO - 2022-03-20 13:35:03 --> Config Class Initialized
INFO - 2022-03-20 13:35:03 --> Hooks Class Initialized
INFO - 2022-03-20 13:35:03 --> Utf8 Class Initialized
INFO - 2022-03-20 13:35:03 --> URI Class Initialized
INFO - 2022-03-20 13:35:03 --> Router Class Initialized
INFO - 2022-03-20 13:35:03 --> Output Class Initialized
INFO - 2022-03-20 13:35:03 --> Security Class Initialized
INFO - 2022-03-20 13:35:03 --> Input Class Initialized
INFO - 2022-03-20 13:35:03 --> Language Class Initialized
INFO - 2022-03-20 13:35:03 --> Loader Class Initialized
INFO - 2022-03-20 13:35:03 --> Helper loaded: url_helper
INFO - 2022-03-20 13:35:03 --> Helper loaded: form_helper
INFO - 2022-03-20 13:35:03 --> Database Driver Class Initialized
INFO - 2022-03-20 13:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:35:03 --> Form Validation Class Initialized
INFO - 2022-03-20 13:35:03 --> Controller Class Initialized
INFO - 2022-03-20 13:35:03 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:35:03 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:35:03 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:35:03 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:35:03 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:35:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:35:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:35:03 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:35:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:35:03 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:35:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:35:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:35:03 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:35:03 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:35:03 --> Final output sent to browser
INFO - 2022-03-20 13:35:22 --> Config Class Initialized
INFO - 2022-03-20 13:35:22 --> Hooks Class Initialized
INFO - 2022-03-20 13:35:22 --> Utf8 Class Initialized
INFO - 2022-03-20 13:35:22 --> URI Class Initialized
INFO - 2022-03-20 13:35:22 --> Router Class Initialized
INFO - 2022-03-20 13:35:22 --> Output Class Initialized
INFO - 2022-03-20 13:35:22 --> Security Class Initialized
INFO - 2022-03-20 13:35:22 --> Input Class Initialized
INFO - 2022-03-20 13:35:22 --> Language Class Initialized
INFO - 2022-03-20 13:35:22 --> Loader Class Initialized
INFO - 2022-03-20 13:35:22 --> Helper loaded: url_helper
INFO - 2022-03-20 13:35:22 --> Helper loaded: form_helper
INFO - 2022-03-20 13:35:22 --> Database Driver Class Initialized
INFO - 2022-03-20 13:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:35:22 --> Form Validation Class Initialized
INFO - 2022-03-20 13:35:22 --> Controller Class Initialized
INFO - 2022-03-20 13:35:22 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:35:22 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:35:22 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:35:22 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:35:22 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:35:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:35:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:35:22 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:35:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:35:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:35:22 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:35:22 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:35:22 --> Final output sent to browser
INFO - 2022-03-20 13:35:38 --> Config Class Initialized
INFO - 2022-03-20 13:35:38 --> Hooks Class Initialized
INFO - 2022-03-20 13:35:39 --> Utf8 Class Initialized
INFO - 2022-03-20 13:35:39 --> URI Class Initialized
INFO - 2022-03-20 13:35:39 --> Router Class Initialized
INFO - 2022-03-20 13:35:39 --> Output Class Initialized
INFO - 2022-03-20 13:35:39 --> Security Class Initialized
INFO - 2022-03-20 13:35:39 --> Input Class Initialized
INFO - 2022-03-20 13:35:39 --> Language Class Initialized
INFO - 2022-03-20 13:35:39 --> Loader Class Initialized
INFO - 2022-03-20 13:35:39 --> Helper loaded: url_helper
INFO - 2022-03-20 13:35:39 --> Helper loaded: form_helper
INFO - 2022-03-20 13:35:39 --> Database Driver Class Initialized
INFO - 2022-03-20 13:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:35:39 --> Form Validation Class Initialized
INFO - 2022-03-20 13:35:39 --> Controller Class Initialized
INFO - 2022-03-20 13:35:39 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:35:39 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:35:39 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:35:39 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:35:39 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:35:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:35:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:35:39 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:35:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:35:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:35:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:35:39 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:35:39 --> Final output sent to browser
INFO - 2022-03-20 13:35:42 --> Config Class Initialized
INFO - 2022-03-20 13:35:42 --> Hooks Class Initialized
INFO - 2022-03-20 13:35:42 --> Utf8 Class Initialized
INFO - 2022-03-20 13:35:42 --> URI Class Initialized
INFO - 2022-03-20 13:35:42 --> Router Class Initialized
INFO - 2022-03-20 13:35:42 --> Output Class Initialized
INFO - 2022-03-20 13:35:42 --> Security Class Initialized
INFO - 2022-03-20 13:35:42 --> Input Class Initialized
INFO - 2022-03-20 13:35:42 --> Language Class Initialized
INFO - 2022-03-20 13:35:42 --> Loader Class Initialized
INFO - 2022-03-20 13:35:42 --> Helper loaded: url_helper
INFO - 2022-03-20 13:35:42 --> Helper loaded: form_helper
INFO - 2022-03-20 13:35:42 --> Database Driver Class Initialized
INFO - 2022-03-20 13:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:35:42 --> Form Validation Class Initialized
INFO - 2022-03-20 13:35:42 --> Controller Class Initialized
INFO - 2022-03-20 13:35:42 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:35:45 --> Config Class Initialized
INFO - 2022-03-20 13:35:45 --> Hooks Class Initialized
INFO - 2022-03-20 13:35:45 --> Utf8 Class Initialized
INFO - 2022-03-20 13:35:45 --> URI Class Initialized
INFO - 2022-03-20 13:35:45 --> Router Class Initialized
INFO - 2022-03-20 13:35:45 --> Output Class Initialized
INFO - 2022-03-20 13:35:45 --> Security Class Initialized
INFO - 2022-03-20 13:35:45 --> Input Class Initialized
INFO - 2022-03-20 13:35:45 --> Language Class Initialized
INFO - 2022-03-20 13:35:45 --> Loader Class Initialized
INFO - 2022-03-20 13:35:45 --> Helper loaded: url_helper
INFO - 2022-03-20 13:35:45 --> Helper loaded: form_helper
INFO - 2022-03-20 13:35:45 --> Database Driver Class Initialized
INFO - 2022-03-20 13:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:35:45 --> Form Validation Class Initialized
INFO - 2022-03-20 13:35:45 --> Controller Class Initialized
INFO - 2022-03-20 13:35:45 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:35:45 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 13:35:45 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 13:35:45 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 13:35:45 --> Final output sent to browser
INFO - 2022-03-20 13:35:50 --> Config Class Initialized
INFO - 2022-03-20 13:35:50 --> Hooks Class Initialized
INFO - 2022-03-20 13:35:50 --> Utf8 Class Initialized
INFO - 2022-03-20 13:35:50 --> URI Class Initialized
INFO - 2022-03-20 13:35:50 --> Router Class Initialized
INFO - 2022-03-20 13:35:50 --> Output Class Initialized
INFO - 2022-03-20 13:35:50 --> Security Class Initialized
INFO - 2022-03-20 13:35:50 --> Input Class Initialized
INFO - 2022-03-20 13:35:50 --> Language Class Initialized
INFO - 2022-03-20 13:35:50 --> Loader Class Initialized
INFO - 2022-03-20 13:35:50 --> Helper loaded: url_helper
INFO - 2022-03-20 13:35:50 --> Helper loaded: form_helper
INFO - 2022-03-20 13:35:50 --> Database Driver Class Initialized
INFO - 2022-03-20 13:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:35:50 --> Form Validation Class Initialized
INFO - 2022-03-20 13:35:50 --> Controller Class Initialized
INFO - 2022-03-20 13:35:50 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:35:51 --> Config Class Initialized
INFO - 2022-03-20 13:35:51 --> Hooks Class Initialized
INFO - 2022-03-20 13:35:51 --> Utf8 Class Initialized
INFO - 2022-03-20 13:35:51 --> URI Class Initialized
INFO - 2022-03-20 13:35:51 --> Router Class Initialized
INFO - 2022-03-20 13:35:51 --> Output Class Initialized
INFO - 2022-03-20 13:35:51 --> Security Class Initialized
INFO - 2022-03-20 13:35:51 --> Input Class Initialized
INFO - 2022-03-20 13:35:51 --> Language Class Initialized
INFO - 2022-03-20 13:35:51 --> Loader Class Initialized
INFO - 2022-03-20 13:35:51 --> Helper loaded: url_helper
INFO - 2022-03-20 13:35:51 --> Helper loaded: form_helper
INFO - 2022-03-20 13:35:51 --> Database Driver Class Initialized
INFO - 2022-03-20 13:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:35:51 --> Form Validation Class Initialized
INFO - 2022-03-20 13:35:51 --> Controller Class Initialized
INFO - 2022-03-20 13:35:51 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:35:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:35:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:35:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:35:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:35:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:35:51 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 13:35:51 --> Final output sent to browser
INFO - 2022-03-20 13:35:53 --> Config Class Initialized
INFO - 2022-03-20 13:35:53 --> Hooks Class Initialized
INFO - 2022-03-20 13:35:53 --> Utf8 Class Initialized
INFO - 2022-03-20 13:35:53 --> URI Class Initialized
INFO - 2022-03-20 13:35:53 --> Router Class Initialized
INFO - 2022-03-20 13:35:53 --> Output Class Initialized
INFO - 2022-03-20 13:35:53 --> Security Class Initialized
INFO - 2022-03-20 13:35:53 --> Input Class Initialized
INFO - 2022-03-20 13:35:53 --> Language Class Initialized
INFO - 2022-03-20 13:35:53 --> Loader Class Initialized
INFO - 2022-03-20 13:35:53 --> Helper loaded: url_helper
INFO - 2022-03-20 13:35:53 --> Helper loaded: form_helper
INFO - 2022-03-20 13:35:54 --> Database Driver Class Initialized
INFO - 2022-03-20 13:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:35:54 --> Form Validation Class Initialized
INFO - 2022-03-20 13:35:54 --> Controller Class Initialized
INFO - 2022-03-20 13:35:54 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:35:54 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:35:54 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:35:54 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:35:54 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:35:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:35:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:35:54 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:35:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:35:54 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:35:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:35:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:35:54 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:35:54 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:35:54 --> Final output sent to browser
INFO - 2022-03-20 13:36:27 --> Config Class Initialized
INFO - 2022-03-20 13:36:27 --> Hooks Class Initialized
INFO - 2022-03-20 13:36:27 --> Utf8 Class Initialized
INFO - 2022-03-20 13:36:27 --> URI Class Initialized
INFO - 2022-03-20 13:36:27 --> Router Class Initialized
INFO - 2022-03-20 13:36:27 --> Output Class Initialized
INFO - 2022-03-20 13:36:27 --> Security Class Initialized
INFO - 2022-03-20 13:36:27 --> Input Class Initialized
INFO - 2022-03-20 13:36:27 --> Language Class Initialized
INFO - 2022-03-20 13:36:27 --> Loader Class Initialized
INFO - 2022-03-20 13:36:27 --> Helper loaded: url_helper
INFO - 2022-03-20 13:36:27 --> Helper loaded: form_helper
INFO - 2022-03-20 13:36:27 --> Database Driver Class Initialized
INFO - 2022-03-20 13:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:36:28 --> Form Validation Class Initialized
INFO - 2022-03-20 13:36:28 --> Controller Class Initialized
INFO - 2022-03-20 13:36:28 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:36:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:36:28 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:36:28 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:36:28 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:36:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:36:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-20 13:36:28 --> Severity: Notice --> Undefined variable: group C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
ERROR - 2022-03-20 13:36:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 113
INFO - 2022-03-20 13:36:28 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:36:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:36:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:36:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:36:28 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:36:28 --> Final output sent to browser
INFO - 2022-03-20 13:36:35 --> Config Class Initialized
INFO - 2022-03-20 13:36:35 --> Hooks Class Initialized
INFO - 2022-03-20 13:36:35 --> Utf8 Class Initialized
INFO - 2022-03-20 13:36:35 --> URI Class Initialized
INFO - 2022-03-20 13:36:35 --> Router Class Initialized
INFO - 2022-03-20 13:36:35 --> Output Class Initialized
INFO - 2022-03-20 13:36:35 --> Security Class Initialized
INFO - 2022-03-20 13:36:35 --> Input Class Initialized
INFO - 2022-03-20 13:36:35 --> Language Class Initialized
INFO - 2022-03-20 13:36:35 --> Loader Class Initialized
INFO - 2022-03-20 13:36:35 --> Helper loaded: url_helper
INFO - 2022-03-20 13:36:35 --> Helper loaded: form_helper
INFO - 2022-03-20 13:36:35 --> Database Driver Class Initialized
INFO - 2022-03-20 13:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:36:35 --> Form Validation Class Initialized
INFO - 2022-03-20 13:36:35 --> Controller Class Initialized
INFO - 2022-03-20 13:36:35 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:36:35 --> Config Class Initialized
INFO - 2022-03-20 13:36:35 --> Hooks Class Initialized
INFO - 2022-03-20 13:36:35 --> Utf8 Class Initialized
INFO - 2022-03-20 13:36:35 --> URI Class Initialized
INFO - 2022-03-20 13:36:35 --> Router Class Initialized
INFO - 2022-03-20 13:36:35 --> Output Class Initialized
INFO - 2022-03-20 13:36:35 --> Security Class Initialized
INFO - 2022-03-20 13:36:35 --> Input Class Initialized
INFO - 2022-03-20 13:36:35 --> Language Class Initialized
INFO - 2022-03-20 13:36:35 --> Loader Class Initialized
INFO - 2022-03-20 13:36:35 --> Helper loaded: url_helper
INFO - 2022-03-20 13:36:35 --> Helper loaded: form_helper
INFO - 2022-03-20 13:36:35 --> Database Driver Class Initialized
INFO - 2022-03-20 13:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:36:35 --> Form Validation Class Initialized
INFO - 2022-03-20 13:36:35 --> Controller Class Initialized
INFO - 2022-03-20 13:36:35 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:36:35 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 13:36:35 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 13:36:35 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 13:36:35 --> Final output sent to browser
INFO - 2022-03-20 13:36:54 --> Config Class Initialized
INFO - 2022-03-20 13:36:54 --> Hooks Class Initialized
INFO - 2022-03-20 13:36:54 --> Utf8 Class Initialized
INFO - 2022-03-20 13:36:54 --> URI Class Initialized
INFO - 2022-03-20 13:36:54 --> Router Class Initialized
INFO - 2022-03-20 13:36:54 --> Output Class Initialized
INFO - 2022-03-20 13:36:54 --> Security Class Initialized
INFO - 2022-03-20 13:36:54 --> Input Class Initialized
INFO - 2022-03-20 13:36:54 --> Language Class Initialized
INFO - 2022-03-20 13:36:54 --> Loader Class Initialized
INFO - 2022-03-20 13:36:54 --> Helper loaded: url_helper
INFO - 2022-03-20 13:36:54 --> Helper loaded: form_helper
INFO - 2022-03-20 13:36:54 --> Database Driver Class Initialized
INFO - 2022-03-20 13:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:36:54 --> Form Validation Class Initialized
INFO - 2022-03-20 13:36:54 --> Controller Class Initialized
INFO - 2022-03-20 13:36:54 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:36:54 --> Config Class Initialized
INFO - 2022-03-20 13:36:54 --> Hooks Class Initialized
INFO - 2022-03-20 13:36:54 --> Utf8 Class Initialized
INFO - 2022-03-20 13:36:54 --> URI Class Initialized
INFO - 2022-03-20 13:36:54 --> Router Class Initialized
INFO - 2022-03-20 13:36:54 --> Output Class Initialized
INFO - 2022-03-20 13:36:54 --> Security Class Initialized
INFO - 2022-03-20 13:36:54 --> Input Class Initialized
INFO - 2022-03-20 13:36:54 --> Language Class Initialized
INFO - 2022-03-20 13:36:54 --> Loader Class Initialized
INFO - 2022-03-20 13:36:54 --> Helper loaded: url_helper
INFO - 2022-03-20 13:36:54 --> Helper loaded: form_helper
INFO - 2022-03-20 13:36:54 --> Database Driver Class Initialized
INFO - 2022-03-20 13:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:36:54 --> Form Validation Class Initialized
INFO - 2022-03-20 13:36:54 --> Controller Class Initialized
INFO - 2022-03-20 13:36:54 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:36:54 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 13:36:54 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 13:36:54 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 13:36:54 --> Final output sent to browser
INFO - 2022-03-20 13:37:01 --> Config Class Initialized
INFO - 2022-03-20 13:37:01 --> Hooks Class Initialized
INFO - 2022-03-20 13:37:01 --> Utf8 Class Initialized
INFO - 2022-03-20 13:37:01 --> URI Class Initialized
INFO - 2022-03-20 13:37:01 --> Router Class Initialized
INFO - 2022-03-20 13:37:01 --> Output Class Initialized
INFO - 2022-03-20 13:37:01 --> Security Class Initialized
INFO - 2022-03-20 13:37:01 --> Input Class Initialized
INFO - 2022-03-20 13:37:01 --> Language Class Initialized
INFO - 2022-03-20 13:37:01 --> Loader Class Initialized
INFO - 2022-03-20 13:37:01 --> Helper loaded: url_helper
INFO - 2022-03-20 13:37:01 --> Helper loaded: form_helper
INFO - 2022-03-20 13:37:01 --> Database Driver Class Initialized
INFO - 2022-03-20 13:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:37:01 --> Form Validation Class Initialized
INFO - 2022-03-20 13:37:01 --> Controller Class Initialized
INFO - 2022-03-20 13:37:01 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:37:01 --> Config Class Initialized
INFO - 2022-03-20 13:37:01 --> Hooks Class Initialized
INFO - 2022-03-20 13:37:01 --> Utf8 Class Initialized
INFO - 2022-03-20 13:37:01 --> URI Class Initialized
INFO - 2022-03-20 13:37:01 --> Router Class Initialized
INFO - 2022-03-20 13:37:01 --> Output Class Initialized
INFO - 2022-03-20 13:37:01 --> Security Class Initialized
INFO - 2022-03-20 13:37:01 --> Input Class Initialized
INFO - 2022-03-20 13:37:01 --> Language Class Initialized
INFO - 2022-03-20 13:37:01 --> Loader Class Initialized
INFO - 2022-03-20 13:37:01 --> Helper loaded: url_helper
INFO - 2022-03-20 13:37:01 --> Helper loaded: form_helper
INFO - 2022-03-20 13:37:01 --> Database Driver Class Initialized
INFO - 2022-03-20 13:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:37:01 --> Form Validation Class Initialized
INFO - 2022-03-20 13:37:01 --> Controller Class Initialized
INFO - 2022-03-20 13:37:01 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:37:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:37:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:37:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:37:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:37:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:37:01 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 13:37:01 --> Final output sent to browser
INFO - 2022-03-20 13:37:03 --> Config Class Initialized
INFO - 2022-03-20 13:37:03 --> Hooks Class Initialized
INFO - 2022-03-20 13:37:04 --> Utf8 Class Initialized
INFO - 2022-03-20 13:37:04 --> URI Class Initialized
INFO - 2022-03-20 13:37:04 --> Router Class Initialized
INFO - 2022-03-20 13:37:04 --> Output Class Initialized
INFO - 2022-03-20 13:37:04 --> Security Class Initialized
INFO - 2022-03-20 13:37:04 --> Input Class Initialized
INFO - 2022-03-20 13:37:04 --> Language Class Initialized
INFO - 2022-03-20 13:37:04 --> Loader Class Initialized
INFO - 2022-03-20 13:37:04 --> Helper loaded: url_helper
INFO - 2022-03-20 13:37:04 --> Helper loaded: form_helper
INFO - 2022-03-20 13:37:04 --> Database Driver Class Initialized
INFO - 2022-03-20 13:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:37:04 --> Form Validation Class Initialized
INFO - 2022-03-20 13:37:04 --> Controller Class Initialized
INFO - 2022-03-20 13:37:04 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:37:04 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:37:04 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:37:04 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:37:04 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:37:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:37:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:37:04 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:37:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:37:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:37:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:37:04 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:37:04 --> Final output sent to browser
INFO - 2022-03-20 13:37:14 --> Config Class Initialized
INFO - 2022-03-20 13:37:14 --> Hooks Class Initialized
INFO - 2022-03-20 13:37:14 --> Utf8 Class Initialized
INFO - 2022-03-20 13:37:14 --> URI Class Initialized
INFO - 2022-03-20 13:37:14 --> Router Class Initialized
INFO - 2022-03-20 13:37:14 --> Output Class Initialized
INFO - 2022-03-20 13:37:14 --> Security Class Initialized
INFO - 2022-03-20 13:37:14 --> Input Class Initialized
INFO - 2022-03-20 13:37:14 --> Language Class Initialized
INFO - 2022-03-20 13:37:14 --> Loader Class Initialized
INFO - 2022-03-20 13:37:14 --> Helper loaded: url_helper
INFO - 2022-03-20 13:37:14 --> Helper loaded: form_helper
INFO - 2022-03-20 13:37:14 --> Database Driver Class Initialized
INFO - 2022-03-20 13:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:37:14 --> Form Validation Class Initialized
INFO - 2022-03-20 13:37:14 --> Controller Class Initialized
INFO - 2022-03-20 13:37:14 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:37:14 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:37:14 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:37:14 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:37:14 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:37:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:37:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:37:14 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-20 13:37:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:37:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:37:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:37:14 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-20 13:37:14 --> Final output sent to browser
INFO - 2022-03-20 13:37:18 --> Config Class Initialized
INFO - 2022-03-20 13:37:18 --> Hooks Class Initialized
INFO - 2022-03-20 13:37:18 --> Utf8 Class Initialized
INFO - 2022-03-20 13:37:18 --> URI Class Initialized
INFO - 2022-03-20 13:37:18 --> Router Class Initialized
INFO - 2022-03-20 13:37:18 --> Output Class Initialized
INFO - 2022-03-20 13:37:18 --> Security Class Initialized
INFO - 2022-03-20 13:37:18 --> Input Class Initialized
INFO - 2022-03-20 13:37:18 --> Language Class Initialized
INFO - 2022-03-20 13:37:18 --> Loader Class Initialized
INFO - 2022-03-20 13:37:18 --> Helper loaded: url_helper
INFO - 2022-03-20 13:37:18 --> Helper loaded: form_helper
INFO - 2022-03-20 13:37:18 --> Database Driver Class Initialized
INFO - 2022-03-20 13:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:37:18 --> Form Validation Class Initialized
INFO - 2022-03-20 13:37:18 --> Controller Class Initialized
INFO - 2022-03-20 13:37:18 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:37:18 --> Config Class Initialized
INFO - 2022-03-20 13:37:18 --> Hooks Class Initialized
INFO - 2022-03-20 13:37:18 --> Utf8 Class Initialized
INFO - 2022-03-20 13:37:18 --> URI Class Initialized
INFO - 2022-03-20 13:37:18 --> Router Class Initialized
INFO - 2022-03-20 13:37:18 --> Output Class Initialized
INFO - 2022-03-20 13:37:18 --> Security Class Initialized
INFO - 2022-03-20 13:37:18 --> Input Class Initialized
INFO - 2022-03-20 13:37:18 --> Language Class Initialized
INFO - 2022-03-20 13:37:18 --> Loader Class Initialized
INFO - 2022-03-20 13:37:18 --> Helper loaded: url_helper
INFO - 2022-03-20 13:37:18 --> Helper loaded: form_helper
INFO - 2022-03-20 13:37:18 --> Database Driver Class Initialized
INFO - 2022-03-20 13:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:37:18 --> Form Validation Class Initialized
INFO - 2022-03-20 13:37:18 --> Controller Class Initialized
INFO - 2022-03-20 13:37:18 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:37:18 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 13:37:18 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 13:37:18 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 13:37:18 --> Final output sent to browser
INFO - 2022-03-20 13:37:25 --> Config Class Initialized
INFO - 2022-03-20 13:37:25 --> Hooks Class Initialized
INFO - 2022-03-20 13:37:25 --> Utf8 Class Initialized
INFO - 2022-03-20 13:37:25 --> URI Class Initialized
INFO - 2022-03-20 13:37:25 --> Router Class Initialized
INFO - 2022-03-20 13:37:25 --> Output Class Initialized
INFO - 2022-03-20 13:37:25 --> Security Class Initialized
INFO - 2022-03-20 13:37:25 --> Input Class Initialized
INFO - 2022-03-20 13:37:25 --> Language Class Initialized
INFO - 2022-03-20 13:37:25 --> Loader Class Initialized
INFO - 2022-03-20 13:37:25 --> Helper loaded: url_helper
INFO - 2022-03-20 13:37:25 --> Helper loaded: form_helper
INFO - 2022-03-20 13:37:25 --> Database Driver Class Initialized
INFO - 2022-03-20 13:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:37:25 --> Form Validation Class Initialized
INFO - 2022-03-20 13:37:25 --> Controller Class Initialized
INFO - 2022-03-20 13:37:25 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:37:25 --> Config Class Initialized
INFO - 2022-03-20 13:37:25 --> Hooks Class Initialized
INFO - 2022-03-20 13:37:25 --> Utf8 Class Initialized
INFO - 2022-03-20 13:37:25 --> URI Class Initialized
INFO - 2022-03-20 13:37:25 --> Router Class Initialized
INFO - 2022-03-20 13:37:25 --> Output Class Initialized
INFO - 2022-03-20 13:37:25 --> Security Class Initialized
INFO - 2022-03-20 13:37:25 --> Input Class Initialized
INFO - 2022-03-20 13:37:25 --> Language Class Initialized
INFO - 2022-03-20 13:37:25 --> Loader Class Initialized
INFO - 2022-03-20 13:37:25 --> Helper loaded: url_helper
INFO - 2022-03-20 13:37:25 --> Helper loaded: form_helper
INFO - 2022-03-20 13:37:25 --> Database Driver Class Initialized
INFO - 2022-03-20 13:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:37:25 --> Form Validation Class Initialized
INFO - 2022-03-20 13:37:25 --> Controller Class Initialized
INFO - 2022-03-20 13:37:25 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:37:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:37:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:37:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:37:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:37:25 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:37:25 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 13:37:25 --> Final output sent to browser
INFO - 2022-03-20 13:37:27 --> Config Class Initialized
INFO - 2022-03-20 13:37:27 --> Hooks Class Initialized
INFO - 2022-03-20 13:37:27 --> Utf8 Class Initialized
INFO - 2022-03-20 13:37:27 --> URI Class Initialized
INFO - 2022-03-20 13:37:27 --> Router Class Initialized
INFO - 2022-03-20 13:37:27 --> Output Class Initialized
INFO - 2022-03-20 13:37:27 --> Security Class Initialized
INFO - 2022-03-20 13:37:27 --> Input Class Initialized
INFO - 2022-03-20 13:37:27 --> Language Class Initialized
INFO - 2022-03-20 13:37:27 --> Loader Class Initialized
INFO - 2022-03-20 13:37:27 --> Helper loaded: url_helper
INFO - 2022-03-20 13:37:27 --> Helper loaded: form_helper
INFO - 2022-03-20 13:37:27 --> Database Driver Class Initialized
INFO - 2022-03-20 13:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:37:27 --> Form Validation Class Initialized
INFO - 2022-03-20 13:37:27 --> Controller Class Initialized
INFO - 2022-03-20 13:37:27 --> Model "M_todo_list" initialized
INFO - 2022-03-20 13:37:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-20 13:37:27 --> Model "M_todo_group" initialized
INFO - 2022-03-20 13:37:27 --> Model "M_todo_task" initialized
INFO - 2022-03-20 13:37:27 --> Model "M_tutor" initialized
ERROR - 2022-03-20 13:37:27 --> 404 Page Not Found: 
INFO - 2022-03-20 13:37:42 --> Config Class Initialized
INFO - 2022-03-20 13:37:42 --> Hooks Class Initialized
INFO - 2022-03-20 13:37:42 --> Utf8 Class Initialized
INFO - 2022-03-20 13:37:42 --> URI Class Initialized
INFO - 2022-03-20 13:37:42 --> Router Class Initialized
INFO - 2022-03-20 13:37:42 --> Output Class Initialized
INFO - 2022-03-20 13:37:43 --> Security Class Initialized
INFO - 2022-03-20 13:37:43 --> Input Class Initialized
INFO - 2022-03-20 13:37:43 --> Language Class Initialized
INFO - 2022-03-20 13:37:43 --> Loader Class Initialized
INFO - 2022-03-20 13:37:43 --> Helper loaded: url_helper
INFO - 2022-03-20 13:37:43 --> Helper loaded: form_helper
INFO - 2022-03-20 13:37:43 --> Database Driver Class Initialized
INFO - 2022-03-20 13:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:37:43 --> Form Validation Class Initialized
INFO - 2022-03-20 13:37:43 --> Controller Class Initialized
INFO - 2022-03-20 13:37:43 --> Model "M_tutor" initialized
INFO - 2022-03-20 13:37:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-20 13:37:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-20 13:37:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-20 13:37:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-20 13:37:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-20 13:37:43 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-20 13:37:43 --> Final output sent to browser
INFO - 2022-03-20 20:32:25 --> Config Class Initialized
INFO - 2022-03-20 20:32:25 --> Hooks Class Initialized
INFO - 2022-03-20 20:32:25 --> Utf8 Class Initialized
INFO - 2022-03-20 20:32:25 --> URI Class Initialized
INFO - 2022-03-20 20:32:25 --> Router Class Initialized
INFO - 2022-03-20 20:32:25 --> Output Class Initialized
INFO - 2022-03-20 20:32:25 --> Security Class Initialized
INFO - 2022-03-20 20:32:25 --> Input Class Initialized
INFO - 2022-03-20 20:32:25 --> Language Class Initialized
INFO - 2022-03-20 20:32:26 --> Loader Class Initialized
INFO - 2022-03-20 20:32:26 --> Helper loaded: url_helper
INFO - 2022-03-20 20:32:26 --> Helper loaded: form_helper
INFO - 2022-03-20 20:32:26 --> Database Driver Class Initialized
INFO - 2022-03-20 20:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 20:32:26 --> Form Validation Class Initialized
INFO - 2022-03-20 20:32:26 --> Controller Class Initialized
INFO - 2022-03-20 20:32:27 --> Model "M_tutor" initialized
INFO - 2022-03-20 20:32:27 --> Config Class Initialized
INFO - 2022-03-20 20:32:27 --> Hooks Class Initialized
INFO - 2022-03-20 20:32:27 --> Utf8 Class Initialized
INFO - 2022-03-20 20:32:27 --> URI Class Initialized
INFO - 2022-03-20 20:32:27 --> Router Class Initialized
INFO - 2022-03-20 20:32:27 --> Output Class Initialized
INFO - 2022-03-20 20:32:27 --> Security Class Initialized
INFO - 2022-03-20 20:32:27 --> Input Class Initialized
INFO - 2022-03-20 20:32:27 --> Language Class Initialized
INFO - 2022-03-20 20:32:27 --> Loader Class Initialized
INFO - 2022-03-20 20:32:27 --> Helper loaded: url_helper
INFO - 2022-03-20 20:32:27 --> Helper loaded: form_helper
INFO - 2022-03-20 20:32:27 --> Database Driver Class Initialized
INFO - 2022-03-20 20:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 20:32:27 --> Form Validation Class Initialized
INFO - 2022-03-20 20:32:27 --> Controller Class Initialized
INFO - 2022-03-20 20:32:27 --> Model "M_tutor" initialized
INFO - 2022-03-20 20:32:27 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-20 20:32:27 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-20 20:32:27 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-20 20:32:27 --> Final output sent to browser
