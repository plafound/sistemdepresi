<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-29 04:45:24 --> Config Class Initialized
INFO - 2022-03-29 04:45:24 --> Hooks Class Initialized
INFO - 2022-03-29 04:45:25 --> Utf8 Class Initialized
INFO - 2022-03-29 04:45:25 --> URI Class Initialized
INFO - 2022-03-29 04:45:25 --> Router Class Initialized
INFO - 2022-03-29 04:45:25 --> Output Class Initialized
INFO - 2022-03-29 04:45:25 --> Security Class Initialized
INFO - 2022-03-29 04:45:25 --> Input Class Initialized
INFO - 2022-03-29 04:45:25 --> Language Class Initialized
ERROR - 2022-03-29 04:45:25 --> 404 Page Not Found: Assets/plugins
INFO - 2022-03-29 04:45:41 --> Config Class Initialized
INFO - 2022-03-29 04:45:41 --> Hooks Class Initialized
INFO - 2022-03-29 04:45:41 --> Utf8 Class Initialized
INFO - 2022-03-29 04:45:41 --> URI Class Initialized
INFO - 2022-03-29 04:45:41 --> Router Class Initialized
INFO - 2022-03-29 04:45:41 --> Output Class Initialized
INFO - 2022-03-29 04:45:41 --> Security Class Initialized
INFO - 2022-03-29 04:45:41 --> Input Class Initialized
INFO - 2022-03-29 04:45:41 --> Language Class Initialized
ERROR - 2022-03-29 04:45:41 --> 404 Page Not Found: Assets/plugins
