<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-29 16:13:17 --> Config Class Initialized
INFO - 2023-05-29 16:13:17 --> Hooks Class Initialized
INFO - 2023-05-29 16:13:17 --> Utf8 Class Initialized
INFO - 2023-05-29 16:13:17 --> URI Class Initialized
INFO - 2023-05-29 16:13:17 --> Router Class Initialized
INFO - 2023-05-29 16:13:17 --> Output Class Initialized
INFO - 2023-05-29 16:13:17 --> Security Class Initialized
INFO - 2023-05-29 16:13:17 --> Input Class Initialized
INFO - 2023-05-29 16:13:17 --> Language Class Initialized
INFO - 2023-05-29 16:13:17 --> Loader Class Initialized
INFO - 2023-05-29 16:13:17 --> Helper loaded: url_helper
INFO - 2023-05-29 16:13:17 --> Helper loaded: form_helper
INFO - 2023-05-29 16:13:17 --> Database Driver Class Initialized
INFO - 2023-05-29 16:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:13:17 --> Form Validation Class Initialized
INFO - 2023-05-29 16:13:17 --> Controller Class Initialized
INFO - 2023-05-29 16:13:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-29 16:13:17 --> Final output sent to browser
INFO - 2023-05-29 16:13:19 --> Config Class Initialized
INFO - 2023-05-29 16:13:19 --> Hooks Class Initialized
INFO - 2023-05-29 16:13:19 --> Utf8 Class Initialized
INFO - 2023-05-29 16:13:19 --> URI Class Initialized
INFO - 2023-05-29 16:13:19 --> Router Class Initialized
INFO - 2023-05-29 16:13:19 --> Output Class Initialized
INFO - 2023-05-29 16:13:19 --> Security Class Initialized
INFO - 2023-05-29 16:13:19 --> Input Class Initialized
INFO - 2023-05-29 16:13:19 --> Language Class Initialized
INFO - 2023-05-29 16:13:19 --> Loader Class Initialized
INFO - 2023-05-29 16:13:19 --> Helper loaded: url_helper
INFO - 2023-05-29 16:13:19 --> Helper loaded: form_helper
INFO - 2023-05-29 16:13:19 --> Database Driver Class Initialized
INFO - 2023-05-29 16:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:13:19 --> Form Validation Class Initialized
INFO - 2023-05-29 16:13:19 --> Controller Class Initialized
INFO - 2023-05-29 16:13:19 --> Model "m_user" initialized
INFO - 2023-05-29 16:13:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-29 16:13:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-29 16:13:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-29 16:13:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-29 16:13:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-29 16:13:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-29 16:13:19 --> Final output sent to browser
INFO - 2023-05-29 16:13:20 --> Config Class Initialized
INFO - 2023-05-29 16:13:20 --> Hooks Class Initialized
INFO - 2023-05-29 16:13:20 --> Utf8 Class Initialized
INFO - 2023-05-29 16:13:20 --> URI Class Initialized
INFO - 2023-05-29 16:13:20 --> Router Class Initialized
INFO - 2023-05-29 16:13:20 --> Output Class Initialized
INFO - 2023-05-29 16:13:20 --> Security Class Initialized
INFO - 2023-05-29 16:13:20 --> Input Class Initialized
INFO - 2023-05-29 16:13:20 --> Language Class Initialized
INFO - 2023-05-29 16:13:20 --> Loader Class Initialized
INFO - 2023-05-29 16:13:20 --> Helper loaded: url_helper
INFO - 2023-05-29 16:13:20 --> Helper loaded: form_helper
INFO - 2023-05-29 16:13:20 --> Database Driver Class Initialized
INFO - 2023-05-29 16:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:13:20 --> Form Validation Class Initialized
INFO - 2023-05-29 16:13:20 --> Controller Class Initialized
INFO - 2023-05-29 16:13:20 --> Model "m_datatrain" initialized
INFO - 2023-05-29 16:13:20 --> Model "m_penghitungan" initialized
INFO - 2023-05-29 16:13:20 --> Model "m_datatest" initialized
INFO - 2023-05-29 16:13:20 --> Model "M_solusi" initialized
INFO - 2023-05-29 16:13:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-29 16:13:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-29 16:13:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-29 16:13:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-29 16:13:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-29 16:13:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-29 16:13:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-29 16:13:20 --> Final output sent to browser
INFO - 2023-05-29 16:13:25 --> Config Class Initialized
INFO - 2023-05-29 16:13:25 --> Hooks Class Initialized
INFO - 2023-05-29 16:13:25 --> Utf8 Class Initialized
INFO - 2023-05-29 16:13:25 --> URI Class Initialized
INFO - 2023-05-29 16:13:25 --> Router Class Initialized
INFO - 2023-05-29 16:13:25 --> Output Class Initialized
INFO - 2023-05-29 16:13:25 --> Security Class Initialized
INFO - 2023-05-29 16:13:25 --> Input Class Initialized
INFO - 2023-05-29 16:13:25 --> Language Class Initialized
ERROR - 2023-05-29 16:13:25 --> 404 Page Not Found: Diagnosa/cek
INFO - 2023-05-29 16:14:06 --> Config Class Initialized
INFO - 2023-05-29 16:14:06 --> Hooks Class Initialized
INFO - 2023-05-29 16:14:06 --> Utf8 Class Initialized
INFO - 2023-05-29 16:14:06 --> URI Class Initialized
INFO - 2023-05-29 16:14:06 --> Router Class Initialized
INFO - 2023-05-29 16:14:06 --> Output Class Initialized
INFO - 2023-05-29 16:14:06 --> Security Class Initialized
INFO - 2023-05-29 16:14:06 --> Input Class Initialized
INFO - 2023-05-29 16:14:06 --> Language Class Initialized
INFO - 2023-05-29 16:14:06 --> Loader Class Initialized
INFO - 2023-05-29 16:14:06 --> Helper loaded: url_helper
INFO - 2023-05-29 16:14:06 --> Helper loaded: form_helper
INFO - 2023-05-29 16:14:06 --> Database Driver Class Initialized
INFO - 2023-05-29 16:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:14:06 --> Form Validation Class Initialized
INFO - 2023-05-29 16:14:06 --> Controller Class Initialized
INFO - 2023-05-29 16:14:06 --> Model "m_datatrain" initialized
INFO - 2023-05-29 16:14:06 --> Model "m_penghitungan" initialized
INFO - 2023-05-29 16:14:06 --> Model "m_datatest" initialized
INFO - 2023-05-29 16:14:06 --> Model "M_solusi" initialized
INFO - 2023-05-29 16:14:06 --> Final output sent to browser
INFO - 2023-05-29 16:14:22 --> Config Class Initialized
INFO - 2023-05-29 16:14:22 --> Hooks Class Initialized
INFO - 2023-05-29 16:14:22 --> Utf8 Class Initialized
INFO - 2023-05-29 16:14:22 --> URI Class Initialized
INFO - 2023-05-29 16:14:22 --> Router Class Initialized
INFO - 2023-05-29 16:14:22 --> Output Class Initialized
INFO - 2023-05-29 16:14:22 --> Security Class Initialized
INFO - 2023-05-29 16:14:22 --> Input Class Initialized
INFO - 2023-05-29 16:14:22 --> Language Class Initialized
INFO - 2023-05-29 16:14:22 --> Loader Class Initialized
INFO - 2023-05-29 16:14:22 --> Helper loaded: url_helper
INFO - 2023-05-29 16:14:22 --> Helper loaded: form_helper
INFO - 2023-05-29 16:14:22 --> Database Driver Class Initialized
INFO - 2023-05-29 16:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:14:22 --> Form Validation Class Initialized
INFO - 2023-05-29 16:14:22 --> Controller Class Initialized
INFO - 2023-05-29 16:14:22 --> Model "m_datatrain" initialized
INFO - 2023-05-29 16:14:22 --> Model "m_penghitungan" initialized
INFO - 2023-05-29 16:14:22 --> Model "m_datatest" initialized
INFO - 2023-05-29 16:14:22 --> Model "M_solusi" initialized
INFO - 2023-05-29 16:14:22 --> Final output sent to browser
INFO - 2023-05-29 16:15:19 --> Config Class Initialized
INFO - 2023-05-29 16:15:19 --> Hooks Class Initialized
INFO - 2023-05-29 16:15:19 --> Utf8 Class Initialized
INFO - 2023-05-29 16:15:19 --> URI Class Initialized
INFO - 2023-05-29 16:15:19 --> Router Class Initialized
INFO - 2023-05-29 16:15:19 --> Output Class Initialized
INFO - 2023-05-29 16:15:19 --> Security Class Initialized
INFO - 2023-05-29 16:15:19 --> Input Class Initialized
INFO - 2023-05-29 16:15:19 --> Language Class Initialized
INFO - 2023-05-29 16:15:19 --> Loader Class Initialized
INFO - 2023-05-29 16:15:19 --> Helper loaded: url_helper
INFO - 2023-05-29 16:15:19 --> Helper loaded: form_helper
INFO - 2023-05-29 16:15:19 --> Database Driver Class Initialized
INFO - 2023-05-29 16:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:15:19 --> Form Validation Class Initialized
INFO - 2023-05-29 16:15:19 --> Controller Class Initialized
INFO - 2023-05-29 16:15:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-29 16:15:19 --> Final output sent to browser
INFO - 2023-05-29 16:15:21 --> Config Class Initialized
INFO - 2023-05-29 16:15:21 --> Hooks Class Initialized
INFO - 2023-05-29 16:15:21 --> Utf8 Class Initialized
INFO - 2023-05-29 16:15:21 --> URI Class Initialized
INFO - 2023-05-29 16:15:21 --> Router Class Initialized
INFO - 2023-05-29 16:15:21 --> Output Class Initialized
INFO - 2023-05-29 16:15:21 --> Security Class Initialized
INFO - 2023-05-29 16:15:21 --> Input Class Initialized
INFO - 2023-05-29 16:15:21 --> Language Class Initialized
INFO - 2023-05-29 16:15:21 --> Loader Class Initialized
INFO - 2023-05-29 16:15:21 --> Helper loaded: url_helper
INFO - 2023-05-29 16:15:21 --> Helper loaded: form_helper
INFO - 2023-05-29 16:15:21 --> Database Driver Class Initialized
INFO - 2023-05-29 16:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:15:21 --> Form Validation Class Initialized
INFO - 2023-05-29 16:15:21 --> Controller Class Initialized
INFO - 2023-05-29 16:15:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-29 16:15:21 --> Final output sent to browser
INFO - 2023-05-29 16:16:35 --> Config Class Initialized
INFO - 2023-05-29 16:16:35 --> Hooks Class Initialized
INFO - 2023-05-29 16:16:35 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:35 --> URI Class Initialized
INFO - 2023-05-29 16:16:35 --> Router Class Initialized
INFO - 2023-05-29 16:16:35 --> Output Class Initialized
INFO - 2023-05-29 16:16:35 --> Security Class Initialized
INFO - 2023-05-29 16:16:35 --> Input Class Initialized
INFO - 2023-05-29 16:16:35 --> Language Class Initialized
INFO - 2023-05-29 16:16:35 --> Loader Class Initialized
INFO - 2023-05-29 16:16:35 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:35 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:35 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:35 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:35 --> Controller Class Initialized
INFO - 2023-05-29 16:16:35 --> Model "m_user" initialized
INFO - 2023-05-29 16:16:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-29 16:16:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-29 16:16:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-29 16:16:35 --> Final output sent to browser
INFO - 2023-05-29 16:16:39 --> Config Class Initialized
INFO - 2023-05-29 16:16:39 --> Hooks Class Initialized
INFO - 2023-05-29 16:16:39 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:39 --> URI Class Initialized
INFO - 2023-05-29 16:16:39 --> Router Class Initialized
INFO - 2023-05-29 16:16:39 --> Output Class Initialized
INFO - 2023-05-29 16:16:39 --> Security Class Initialized
INFO - 2023-05-29 16:16:39 --> Input Class Initialized
INFO - 2023-05-29 16:16:39 --> Language Class Initialized
INFO - 2023-05-29 16:16:39 --> Loader Class Initialized
INFO - 2023-05-29 16:16:39 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:39 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:39 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:39 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:39 --> Controller Class Initialized
INFO - 2023-05-29 16:16:39 --> Model "m_user" initialized
INFO - 2023-05-29 16:16:39 --> Config Class Initialized
INFO - 2023-05-29 16:16:39 --> Hooks Class Initialized
INFO - 2023-05-29 16:16:39 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:39 --> URI Class Initialized
INFO - 2023-05-29 16:16:39 --> Router Class Initialized
INFO - 2023-05-29 16:16:39 --> Output Class Initialized
INFO - 2023-05-29 16:16:39 --> Security Class Initialized
INFO - 2023-05-29 16:16:39 --> Input Class Initialized
INFO - 2023-05-29 16:16:39 --> Language Class Initialized
INFO - 2023-05-29 16:16:40 --> Loader Class Initialized
INFO - 2023-05-29 16:16:40 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:40 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:40 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:40 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:40 --> Controller Class Initialized
INFO - 2023-05-29 16:16:40 --> Model "m_user" initialized
INFO - 2023-05-29 16:16:40 --> Model "m_datatrain" initialized
INFO - 2023-05-29 16:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-29 16:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-29 16:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-29 16:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-29 16:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-29 16:16:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-29 16:16:40 --> Final output sent to browser
INFO - 2023-05-29 16:16:41 --> Config Class Initialized
INFO - 2023-05-29 16:16:41 --> Hooks Class Initialized
INFO - 2023-05-29 16:16:41 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:41 --> URI Class Initialized
INFO - 2023-05-29 16:16:41 --> Router Class Initialized
INFO - 2023-05-29 16:16:41 --> Output Class Initialized
INFO - 2023-05-29 16:16:41 --> Security Class Initialized
INFO - 2023-05-29 16:16:41 --> Input Class Initialized
INFO - 2023-05-29 16:16:41 --> Language Class Initialized
INFO - 2023-05-29 16:16:41 --> Loader Class Initialized
INFO - 2023-05-29 16:16:41 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:41 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:41 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:41 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:41 --> Controller Class Initialized
INFO - 2023-05-29 16:16:41 --> Model "m_datatrain" initialized
INFO - 2023-05-29 16:16:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-29 16:16:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-29 16:16:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-29 16:16:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-29 16:16:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-29 16:16:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-29 16:16:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-29 16:16:41 --> Final output sent to browser
INFO - 2023-05-29 16:16:44 --> Config Class Initialized
INFO - 2023-05-29 16:16:44 --> Hooks Class Initialized
INFO - 2023-05-29 16:16:44 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:44 --> URI Class Initialized
INFO - 2023-05-29 16:16:44 --> Router Class Initialized
INFO - 2023-05-29 16:16:44 --> Output Class Initialized
INFO - 2023-05-29 16:16:44 --> Security Class Initialized
INFO - 2023-05-29 16:16:44 --> Input Class Initialized
INFO - 2023-05-29 16:16:44 --> Language Class Initialized
INFO - 2023-05-29 16:16:44 --> Loader Class Initialized
INFO - 2023-05-29 16:16:44 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:44 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:44 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:44 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:44 --> Controller Class Initialized
INFO - 2023-05-29 16:16:44 --> Model "m_datatrain" initialized
INFO - 2023-05-29 16:16:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-29 16:16:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-29 16:16:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-29 16:16:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-29 16:16:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-29 16:16:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-29 16:16:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-29 16:16:44 --> Final output sent to browser
INFO - 2023-05-29 16:43:54 --> Config Class Initialized
INFO - 2023-05-29 16:43:54 --> Hooks Class Initialized
INFO - 2023-05-29 16:43:54 --> Utf8 Class Initialized
INFO - 2023-05-29 16:43:54 --> URI Class Initialized
INFO - 2023-05-29 16:43:54 --> Router Class Initialized
INFO - 2023-05-29 16:43:54 --> Output Class Initialized
INFO - 2023-05-29 16:43:54 --> Security Class Initialized
INFO - 2023-05-29 16:43:54 --> Input Class Initialized
INFO - 2023-05-29 16:43:54 --> Language Class Initialized
INFO - 2023-05-29 16:43:54 --> Loader Class Initialized
INFO - 2023-05-29 16:43:54 --> Helper loaded: url_helper
INFO - 2023-05-29 16:43:54 --> Helper loaded: form_helper
INFO - 2023-05-29 16:43:54 --> Database Driver Class Initialized
INFO - 2023-05-29 16:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:43:54 --> Form Validation Class Initialized
INFO - 2023-05-29 16:43:54 --> Controller Class Initialized
INFO - 2023-05-29 16:43:54 --> Model "m_user" initialized
INFO - 2023-05-29 16:43:54 --> Config Class Initialized
INFO - 2023-05-29 16:43:54 --> Hooks Class Initialized
INFO - 2023-05-29 16:43:54 --> Utf8 Class Initialized
INFO - 2023-05-29 16:43:54 --> URI Class Initialized
INFO - 2023-05-29 16:43:54 --> Router Class Initialized
INFO - 2023-05-29 16:43:54 --> Output Class Initialized
INFO - 2023-05-29 16:43:54 --> Security Class Initialized
INFO - 2023-05-29 16:43:54 --> Input Class Initialized
INFO - 2023-05-29 16:43:54 --> Language Class Initialized
INFO - 2023-05-29 16:43:54 --> Loader Class Initialized
INFO - 2023-05-29 16:43:54 --> Helper loaded: url_helper
INFO - 2023-05-29 16:43:54 --> Helper loaded: form_helper
INFO - 2023-05-29 16:43:55 --> Database Driver Class Initialized
INFO - 2023-05-29 16:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:43:55 --> Form Validation Class Initialized
INFO - 2023-05-29 16:43:55 --> Controller Class Initialized
INFO - 2023-05-29 16:43:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-29 16:43:55 --> Final output sent to browser
INFO - 2023-05-29 16:43:56 --> Config Class Initialized
INFO - 2023-05-29 16:43:56 --> Hooks Class Initialized
INFO - 2023-05-29 16:43:56 --> Utf8 Class Initialized
INFO - 2023-05-29 16:43:56 --> URI Class Initialized
INFO - 2023-05-29 16:43:56 --> Router Class Initialized
INFO - 2023-05-29 16:43:56 --> Output Class Initialized
INFO - 2023-05-29 16:43:56 --> Security Class Initialized
INFO - 2023-05-29 16:43:56 --> Input Class Initialized
INFO - 2023-05-29 16:43:56 --> Language Class Initialized
INFO - 2023-05-29 16:43:56 --> Loader Class Initialized
INFO - 2023-05-29 16:43:56 --> Helper loaded: url_helper
INFO - 2023-05-29 16:43:56 --> Helper loaded: form_helper
INFO - 2023-05-29 16:43:56 --> Database Driver Class Initialized
INFO - 2023-05-29 16:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:43:56 --> Form Validation Class Initialized
INFO - 2023-05-29 16:43:56 --> Controller Class Initialized
INFO - 2023-05-29 16:43:56 --> Model "m_user" initialized
INFO - 2023-05-29 16:43:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-29 16:43:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-29 16:43:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-29 16:43:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-29 16:43:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-29 16:43:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-29 16:43:56 --> Final output sent to browser
INFO - 2023-05-29 16:44:04 --> Config Class Initialized
INFO - 2023-05-29 16:44:04 --> Hooks Class Initialized
INFO - 2023-05-29 16:44:04 --> Utf8 Class Initialized
INFO - 2023-05-29 16:44:04 --> URI Class Initialized
INFO - 2023-05-29 16:44:04 --> Router Class Initialized
INFO - 2023-05-29 16:44:05 --> Output Class Initialized
INFO - 2023-05-29 16:44:05 --> Security Class Initialized
INFO - 2023-05-29 16:44:05 --> Input Class Initialized
INFO - 2023-05-29 16:44:05 --> Language Class Initialized
INFO - 2023-05-29 16:44:05 --> Loader Class Initialized
INFO - 2023-05-29 16:44:05 --> Helper loaded: url_helper
INFO - 2023-05-29 16:44:05 --> Helper loaded: form_helper
INFO - 2023-05-29 16:44:05 --> Database Driver Class Initialized
INFO - 2023-05-29 16:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:44:05 --> Form Validation Class Initialized
INFO - 2023-05-29 16:44:05 --> Controller Class Initialized
INFO - 2023-05-29 16:44:05 --> Model "m_datatrain" initialized
INFO - 2023-05-29 16:44:05 --> Model "m_penghitungan" initialized
INFO - 2023-05-29 16:44:05 --> Model "m_datatest" initialized
INFO - 2023-05-29 16:44:05 --> Model "M_solusi" initialized
INFO - 2023-05-29 16:44:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-29 16:44:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-29 16:44:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-29 16:44:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-29 16:44:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-29 16:44:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-29 16:44:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-29 16:44:05 --> Final output sent to browser
INFO - 2023-05-29 16:49:58 --> Config Class Initialized
INFO - 2023-05-29 16:49:58 --> Hooks Class Initialized
INFO - 2023-05-29 16:49:58 --> Utf8 Class Initialized
INFO - 2023-05-29 16:49:58 --> URI Class Initialized
INFO - 2023-05-29 16:49:58 --> Router Class Initialized
INFO - 2023-05-29 16:49:58 --> Output Class Initialized
INFO - 2023-05-29 16:49:58 --> Security Class Initialized
INFO - 2023-05-29 16:49:58 --> Input Class Initialized
INFO - 2023-05-29 16:49:58 --> Language Class Initialized
INFO - 2023-05-29 16:49:58 --> Loader Class Initialized
INFO - 2023-05-29 16:49:58 --> Helper loaded: url_helper
INFO - 2023-05-29 16:49:58 --> Helper loaded: form_helper
INFO - 2023-05-29 16:49:58 --> Database Driver Class Initialized
INFO - 2023-05-29 16:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:49:58 --> Form Validation Class Initialized
INFO - 2023-05-29 16:49:58 --> Controller Class Initialized
INFO - 2023-05-29 16:49:58 --> Model "m_datatrain" initialized
INFO - 2023-05-29 16:49:58 --> Model "m_penghitungan" initialized
INFO - 2023-05-29 16:49:58 --> Model "m_datatest" initialized
INFO - 2023-05-29 16:49:58 --> Model "M_solusi" initialized
INFO - 2023-05-29 16:49:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-29 16:49:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-29 16:49:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-29 16:49:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-29 16:49:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-29 16:49:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-29 16:49:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-29 16:49:58 --> Final output sent to browser
INFO - 2023-05-29 16:51:39 --> Config Class Initialized
INFO - 2023-05-29 16:51:39 --> Hooks Class Initialized
INFO - 2023-05-29 16:51:39 --> Utf8 Class Initialized
INFO - 2023-05-29 16:51:39 --> URI Class Initialized
INFO - 2023-05-29 16:51:39 --> Router Class Initialized
INFO - 2023-05-29 16:51:39 --> Output Class Initialized
INFO - 2023-05-29 16:51:39 --> Security Class Initialized
INFO - 2023-05-29 16:51:39 --> Input Class Initialized
INFO - 2023-05-29 16:51:39 --> Language Class Initialized
INFO - 2023-05-29 16:51:39 --> Loader Class Initialized
INFO - 2023-05-29 16:51:39 --> Helper loaded: url_helper
INFO - 2023-05-29 16:51:39 --> Helper loaded: form_helper
INFO - 2023-05-29 16:51:39 --> Database Driver Class Initialized
INFO - 2023-05-29 16:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:51:39 --> Form Validation Class Initialized
INFO - 2023-05-29 16:51:39 --> Controller Class Initialized
INFO - 2023-05-29 16:51:39 --> Model "m_datatrain" initialized
INFO - 2023-05-29 16:51:39 --> Model "m_penghitungan" initialized
INFO - 2023-05-29 16:51:39 --> Model "m_datatest" initialized
INFO - 2023-05-29 16:51:39 --> Model "M_solusi" initialized
INFO - 2023-05-29 16:51:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-29 16:51:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-29 16:51:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-29 16:51:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-29 16:51:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-29 16:51:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-29 16:51:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-29 16:51:40 --> Final output sent to browser
INFO - 2023-05-29 16:56:46 --> Config Class Initialized
INFO - 2023-05-29 16:56:46 --> Hooks Class Initialized
INFO - 2023-05-29 16:56:46 --> Utf8 Class Initialized
INFO - 2023-05-29 16:56:46 --> URI Class Initialized
INFO - 2023-05-29 16:56:46 --> Router Class Initialized
INFO - 2023-05-29 16:56:46 --> Output Class Initialized
INFO - 2023-05-29 16:56:46 --> Security Class Initialized
INFO - 2023-05-29 16:56:46 --> Input Class Initialized
INFO - 2023-05-29 16:56:46 --> Language Class Initialized
INFO - 2023-05-29 16:56:46 --> Loader Class Initialized
INFO - 2023-05-29 16:56:46 --> Helper loaded: url_helper
INFO - 2023-05-29 16:56:46 --> Helper loaded: form_helper
INFO - 2023-05-29 16:56:46 --> Database Driver Class Initialized
INFO - 2023-05-29 16:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:56:46 --> Form Validation Class Initialized
INFO - 2023-05-29 16:56:46 --> Controller Class Initialized
INFO - 2023-05-29 16:56:46 --> Model "m_datatrain" initialized
INFO - 2023-05-29 16:56:46 --> Model "m_penghitungan" initialized
INFO - 2023-05-29 16:56:46 --> Model "m_datatest" initialized
INFO - 2023-05-29 16:56:46 --> Model "M_solusi" initialized
INFO - 2023-05-29 16:56:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-29 16:56:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-29 16:56:46 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 64
INFO - 2023-05-29 16:58:18 --> Config Class Initialized
INFO - 2023-05-29 16:58:18 --> Hooks Class Initialized
INFO - 2023-05-29 16:58:18 --> Utf8 Class Initialized
INFO - 2023-05-29 16:58:19 --> URI Class Initialized
INFO - 2023-05-29 16:58:19 --> Router Class Initialized
INFO - 2023-05-29 16:58:19 --> Output Class Initialized
INFO - 2023-05-29 16:58:19 --> Security Class Initialized
INFO - 2023-05-29 16:58:19 --> Input Class Initialized
INFO - 2023-05-29 16:58:19 --> Language Class Initialized
INFO - 2023-05-29 16:58:19 --> Loader Class Initialized
INFO - 2023-05-29 16:58:19 --> Helper loaded: url_helper
INFO - 2023-05-29 16:58:19 --> Helper loaded: form_helper
INFO - 2023-05-29 16:58:19 --> Database Driver Class Initialized
INFO - 2023-05-29 16:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:58:19 --> Form Validation Class Initialized
INFO - 2023-05-29 16:58:19 --> Controller Class Initialized
INFO - 2023-05-29 16:58:19 --> Model "m_datatrain" initialized
INFO - 2023-05-29 16:58:19 --> Model "m_penghitungan" initialized
INFO - 2023-05-29 16:58:19 --> Model "m_datatest" initialized
INFO - 2023-05-29 16:58:19 --> Model "M_solusi" initialized
INFO - 2023-05-29 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-29 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-29 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-29 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-29 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-29 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-29 16:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-29 16:58:19 --> Final output sent to browser
