<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-18 17:40:23 --> Config Class Initialized
INFO - 2023-05-18 17:40:23 --> Hooks Class Initialized
INFO - 2023-05-18 17:40:24 --> Utf8 Class Initialized
INFO - 2023-05-18 17:40:24 --> URI Class Initialized
INFO - 2023-05-18 17:40:24 --> Router Class Initialized
INFO - 2023-05-18 17:40:24 --> Output Class Initialized
INFO - 2023-05-18 17:40:24 --> Security Class Initialized
INFO - 2023-05-18 17:40:24 --> Input Class Initialized
INFO - 2023-05-18 17:40:24 --> Language Class Initialized
INFO - 2023-05-18 17:40:24 --> Loader Class Initialized
INFO - 2023-05-18 17:40:24 --> Helper loaded: url_helper
INFO - 2023-05-18 17:40:24 --> Helper loaded: form_helper
INFO - 2023-05-18 17:40:24 --> Database Driver Class Initialized
INFO - 2023-05-18 17:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 17:40:25 --> Form Validation Class Initialized
INFO - 2023-05-18 17:40:25 --> Controller Class Initialized
INFO - 2023-05-18 17:40:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-18 17:40:25 --> Final output sent to browser
INFO - 2023-05-18 18:14:05 --> Config Class Initialized
INFO - 2023-05-18 18:14:05 --> Hooks Class Initialized
INFO - 2023-05-18 18:14:05 --> Utf8 Class Initialized
INFO - 2023-05-18 18:14:05 --> URI Class Initialized
INFO - 2023-05-18 18:14:05 --> Router Class Initialized
INFO - 2023-05-18 18:14:05 --> Output Class Initialized
INFO - 2023-05-18 18:14:05 --> Security Class Initialized
INFO - 2023-05-18 18:14:05 --> Input Class Initialized
INFO - 2023-05-18 18:14:05 --> Language Class Initialized
INFO - 2023-05-18 18:14:05 --> Loader Class Initialized
INFO - 2023-05-18 18:14:05 --> Helper loaded: url_helper
INFO - 2023-05-18 18:14:05 --> Helper loaded: form_helper
INFO - 2023-05-18 18:14:05 --> Database Driver Class Initialized
INFO - 2023-05-18 18:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:14:05 --> Form Validation Class Initialized
INFO - 2023-05-18 18:14:05 --> Controller Class Initialized
INFO - 2023-05-18 18:14:05 --> Model "m_user" initialized
INFO - 2023-05-18 18:14:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-18 18:14:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-18 18:14:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-18 18:14:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-18 18:14:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-18 18:14:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-18 18:14:05 --> Final output sent to browser
INFO - 2023-05-18 18:14:23 --> Config Class Initialized
INFO - 2023-05-18 18:14:23 --> Hooks Class Initialized
INFO - 2023-05-18 18:14:23 --> Utf8 Class Initialized
INFO - 2023-05-18 18:14:23 --> URI Class Initialized
INFO - 2023-05-18 18:14:23 --> Router Class Initialized
INFO - 2023-05-18 18:14:23 --> Output Class Initialized
INFO - 2023-05-18 18:14:23 --> Security Class Initialized
INFO - 2023-05-18 18:14:23 --> Input Class Initialized
INFO - 2023-05-18 18:14:23 --> Language Class Initialized
ERROR - 2023-05-18 18:14:23 --> 404 Page Not Found: C_penghitungan/probhasil
INFO - 2023-05-18 18:14:52 --> Config Class Initialized
INFO - 2023-05-18 18:14:52 --> Hooks Class Initialized
INFO - 2023-05-18 18:14:52 --> Utf8 Class Initialized
INFO - 2023-05-18 18:14:52 --> URI Class Initialized
INFO - 2023-05-18 18:14:52 --> Router Class Initialized
INFO - 2023-05-18 18:14:52 --> Output Class Initialized
INFO - 2023-05-18 18:14:52 --> Security Class Initialized
INFO - 2023-05-18 18:14:52 --> Input Class Initialized
INFO - 2023-05-18 18:14:52 --> Language Class Initialized
INFO - 2023-05-18 18:14:52 --> Loader Class Initialized
INFO - 2023-05-18 18:14:52 --> Helper loaded: url_helper
INFO - 2023-05-18 18:14:52 --> Helper loaded: form_helper
INFO - 2023-05-18 18:14:52 --> Database Driver Class Initialized
INFO - 2023-05-18 18:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:14:52 --> Form Validation Class Initialized
INFO - 2023-05-18 18:14:52 --> Controller Class Initialized
INFO - 2023-05-18 18:14:52 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:14:52 --> Model "m_penghitungan" initialized
INFO - 2023-05-18 18:14:52 --> Model "m_datatest" initialized
ERROR - 2023-05-18 18:14:52 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_penghitungan.php 34
INFO - 2023-05-18 18:14:52 --> Final output sent to browser
INFO - 2023-05-18 18:15:17 --> Config Class Initialized
INFO - 2023-05-18 18:15:17 --> Hooks Class Initialized
INFO - 2023-05-18 18:15:17 --> Utf8 Class Initialized
INFO - 2023-05-18 18:15:17 --> URI Class Initialized
INFO - 2023-05-18 18:15:17 --> Router Class Initialized
INFO - 2023-05-18 18:15:17 --> Output Class Initialized
INFO - 2023-05-18 18:15:17 --> Security Class Initialized
INFO - 2023-05-18 18:15:17 --> Input Class Initialized
INFO - 2023-05-18 18:15:17 --> Language Class Initialized
INFO - 2023-05-18 18:15:17 --> Loader Class Initialized
INFO - 2023-05-18 18:15:17 --> Helper loaded: url_helper
INFO - 2023-05-18 18:15:17 --> Helper loaded: form_helper
INFO - 2023-05-18 18:15:17 --> Database Driver Class Initialized
INFO - 2023-05-18 18:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:15:17 --> Form Validation Class Initialized
INFO - 2023-05-18 18:15:17 --> Controller Class Initialized
INFO - 2023-05-18 18:15:17 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:15:17 --> Model "m_penghitungan" initialized
INFO - 2023-05-18 18:15:17 --> Model "m_datatest" initialized
ERROR - 2023-05-18 18:15:17 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_penghitungan.php 48
INFO - 2023-05-18 18:15:17 --> Final output sent to browser
INFO - 2023-05-18 18:15:18 --> Config Class Initialized
INFO - 2023-05-18 18:15:18 --> Hooks Class Initialized
INFO - 2023-05-18 18:15:18 --> Utf8 Class Initialized
INFO - 2023-05-18 18:15:18 --> URI Class Initialized
INFO - 2023-05-18 18:15:18 --> Router Class Initialized
INFO - 2023-05-18 18:15:18 --> Output Class Initialized
INFO - 2023-05-18 18:15:18 --> Security Class Initialized
INFO - 2023-05-18 18:15:18 --> Input Class Initialized
INFO - 2023-05-18 18:15:18 --> Language Class Initialized
INFO - 2023-05-18 18:15:18 --> Loader Class Initialized
INFO - 2023-05-18 18:15:18 --> Helper loaded: url_helper
INFO - 2023-05-18 18:15:18 --> Helper loaded: form_helper
INFO - 2023-05-18 18:15:18 --> Database Driver Class Initialized
INFO - 2023-05-18 18:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:15:18 --> Form Validation Class Initialized
INFO - 2023-05-18 18:15:18 --> Controller Class Initialized
INFO - 2023-05-18 18:15:18 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:15:18 --> Model "m_penghitungan" initialized
INFO - 2023-05-18 18:15:18 --> Model "m_datatest" initialized
ERROR - 2023-05-18 18:15:18 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_penghitungan.php 48
INFO - 2023-05-18 18:15:18 --> Final output sent to browser
INFO - 2023-05-18 18:16:29 --> Config Class Initialized
INFO - 2023-05-18 18:16:29 --> Hooks Class Initialized
INFO - 2023-05-18 18:16:29 --> Utf8 Class Initialized
INFO - 2023-05-18 18:16:29 --> URI Class Initialized
INFO - 2023-05-18 18:16:29 --> Router Class Initialized
INFO - 2023-05-18 18:16:29 --> Output Class Initialized
INFO - 2023-05-18 18:16:29 --> Security Class Initialized
INFO - 2023-05-18 18:16:29 --> Input Class Initialized
INFO - 2023-05-18 18:16:29 --> Language Class Initialized
INFO - 2023-05-18 18:16:29 --> Loader Class Initialized
INFO - 2023-05-18 18:16:29 --> Helper loaded: url_helper
INFO - 2023-05-18 18:16:29 --> Helper loaded: form_helper
INFO - 2023-05-18 18:16:29 --> Database Driver Class Initialized
INFO - 2023-05-18 18:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:16:29 --> Form Validation Class Initialized
INFO - 2023-05-18 18:16:29 --> Controller Class Initialized
INFO - 2023-05-18 18:16:29 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:16:29 --> Model "m_penghitungan" initialized
INFO - 2023-05-18 18:16:29 --> Model "m_datatest" initialized
INFO - 2023-05-18 18:16:29 --> Final output sent to browser
INFO - 2023-05-18 18:19:10 --> Config Class Initialized
INFO - 2023-05-18 18:19:10 --> Hooks Class Initialized
INFO - 2023-05-18 18:19:10 --> Utf8 Class Initialized
INFO - 2023-05-18 18:19:10 --> URI Class Initialized
INFO - 2023-05-18 18:19:10 --> Router Class Initialized
INFO - 2023-05-18 18:19:10 --> Output Class Initialized
INFO - 2023-05-18 18:19:10 --> Security Class Initialized
INFO - 2023-05-18 18:19:10 --> Input Class Initialized
INFO - 2023-05-18 18:19:10 --> Language Class Initialized
INFO - 2023-05-18 18:19:10 --> Loader Class Initialized
INFO - 2023-05-18 18:19:10 --> Helper loaded: url_helper
INFO - 2023-05-18 18:19:10 --> Helper loaded: form_helper
INFO - 2023-05-18 18:19:10 --> Database Driver Class Initialized
INFO - 2023-05-18 18:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:19:10 --> Form Validation Class Initialized
INFO - 2023-05-18 18:19:10 --> Controller Class Initialized
INFO - 2023-05-18 18:19:10 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:19:10 --> Model "m_penghitungan" initialized
INFO - 2023-05-18 18:19:10 --> Model "m_datatest" initialized
INFO - 2023-05-18 18:19:10 --> Final output sent to browser
INFO - 2023-05-18 18:22:19 --> Config Class Initialized
INFO - 2023-05-18 18:22:19 --> Hooks Class Initialized
INFO - 2023-05-18 18:22:19 --> Utf8 Class Initialized
INFO - 2023-05-18 18:22:19 --> URI Class Initialized
INFO - 2023-05-18 18:22:19 --> Router Class Initialized
INFO - 2023-05-18 18:22:19 --> Output Class Initialized
INFO - 2023-05-18 18:22:19 --> Security Class Initialized
INFO - 2023-05-18 18:22:19 --> Input Class Initialized
INFO - 2023-05-18 18:22:19 --> Language Class Initialized
INFO - 2023-05-18 18:22:19 --> Loader Class Initialized
INFO - 2023-05-18 18:22:19 --> Helper loaded: url_helper
INFO - 2023-05-18 18:22:19 --> Helper loaded: form_helper
INFO - 2023-05-18 18:22:19 --> Database Driver Class Initialized
INFO - 2023-05-18 18:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:22:19 --> Form Validation Class Initialized
INFO - 2023-05-18 18:22:19 --> Controller Class Initialized
INFO - 2023-05-18 18:22:19 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:22:19 --> Model "m_penghitungan" initialized
INFO - 2023-05-18 18:22:19 --> Model "m_datatest" initialized
INFO - 2023-05-18 18:22:19 --> Final output sent to browser
INFO - 2023-05-18 18:26:21 --> Config Class Initialized
INFO - 2023-05-18 18:26:21 --> Hooks Class Initialized
INFO - 2023-05-18 18:26:21 --> Utf8 Class Initialized
INFO - 2023-05-18 18:26:21 --> URI Class Initialized
INFO - 2023-05-18 18:26:21 --> Router Class Initialized
INFO - 2023-05-18 18:26:21 --> Output Class Initialized
INFO - 2023-05-18 18:26:21 --> Security Class Initialized
INFO - 2023-05-18 18:26:21 --> Input Class Initialized
INFO - 2023-05-18 18:26:21 --> Language Class Initialized
INFO - 2023-05-18 18:26:21 --> Loader Class Initialized
INFO - 2023-05-18 18:26:21 --> Helper loaded: url_helper
INFO - 2023-05-18 18:26:21 --> Helper loaded: form_helper
INFO - 2023-05-18 18:26:21 --> Database Driver Class Initialized
INFO - 2023-05-18 18:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:26:21 --> Form Validation Class Initialized
INFO - 2023-05-18 18:26:21 --> Controller Class Initialized
INFO - 2023-05-18 18:26:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-18 18:26:21 --> Final output sent to browser
INFO - 2023-05-18 18:26:22 --> Config Class Initialized
INFO - 2023-05-18 18:26:22 --> Hooks Class Initialized
INFO - 2023-05-18 18:26:22 --> Utf8 Class Initialized
INFO - 2023-05-18 18:26:22 --> URI Class Initialized
INFO - 2023-05-18 18:26:22 --> Router Class Initialized
INFO - 2023-05-18 18:26:22 --> Output Class Initialized
INFO - 2023-05-18 18:26:22 --> Security Class Initialized
INFO - 2023-05-18 18:26:22 --> Input Class Initialized
INFO - 2023-05-18 18:26:22 --> Language Class Initialized
INFO - 2023-05-18 18:26:22 --> Loader Class Initialized
INFO - 2023-05-18 18:26:22 --> Helper loaded: url_helper
INFO - 2023-05-18 18:26:22 --> Helper loaded: form_helper
INFO - 2023-05-18 18:26:22 --> Database Driver Class Initialized
INFO - 2023-05-18 18:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:26:22 --> Form Validation Class Initialized
INFO - 2023-05-18 18:26:22 --> Controller Class Initialized
INFO - 2023-05-18 18:26:22 --> Model "m_user" initialized
INFO - 2023-05-18 18:26:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-18 18:26:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-18 18:26:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-18 18:26:22 --> Final output sent to browser
INFO - 2023-05-18 18:26:28 --> Config Class Initialized
INFO - 2023-05-18 18:26:28 --> Hooks Class Initialized
INFO - 2023-05-18 18:26:28 --> Utf8 Class Initialized
INFO - 2023-05-18 18:26:28 --> URI Class Initialized
INFO - 2023-05-18 18:26:28 --> Router Class Initialized
INFO - 2023-05-18 18:26:28 --> Output Class Initialized
INFO - 2023-05-18 18:26:28 --> Security Class Initialized
INFO - 2023-05-18 18:26:28 --> Input Class Initialized
INFO - 2023-05-18 18:26:28 --> Language Class Initialized
INFO - 2023-05-18 18:26:28 --> Loader Class Initialized
INFO - 2023-05-18 18:26:28 --> Helper loaded: url_helper
INFO - 2023-05-18 18:26:28 --> Helper loaded: form_helper
INFO - 2023-05-18 18:26:28 --> Database Driver Class Initialized
INFO - 2023-05-18 18:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:26:28 --> Form Validation Class Initialized
INFO - 2023-05-18 18:26:28 --> Controller Class Initialized
INFO - 2023-05-18 18:26:28 --> Model "m_user" initialized
INFO - 2023-05-18 18:26:28 --> Config Class Initialized
INFO - 2023-05-18 18:26:28 --> Hooks Class Initialized
INFO - 2023-05-18 18:26:28 --> Utf8 Class Initialized
INFO - 2023-05-18 18:26:28 --> URI Class Initialized
INFO - 2023-05-18 18:26:28 --> Router Class Initialized
INFO - 2023-05-18 18:26:28 --> Output Class Initialized
INFO - 2023-05-18 18:26:28 --> Security Class Initialized
INFO - 2023-05-18 18:26:28 --> Input Class Initialized
INFO - 2023-05-18 18:26:28 --> Language Class Initialized
INFO - 2023-05-18 18:26:28 --> Loader Class Initialized
INFO - 2023-05-18 18:26:28 --> Helper loaded: url_helper
INFO - 2023-05-18 18:26:28 --> Helper loaded: form_helper
INFO - 2023-05-18 18:26:28 --> Database Driver Class Initialized
INFO - 2023-05-18 18:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:26:28 --> Form Validation Class Initialized
INFO - 2023-05-18 18:26:28 --> Controller Class Initialized
INFO - 2023-05-18 18:26:28 --> Model "m_user" initialized
INFO - 2023-05-18 18:26:28 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-18 18:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-18 18:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-18 18:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-18 18:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-18 18:26:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-18 18:26:28 --> Final output sent to browser
INFO - 2023-05-18 18:26:30 --> Config Class Initialized
INFO - 2023-05-18 18:26:30 --> Hooks Class Initialized
INFO - 2023-05-18 18:26:30 --> Utf8 Class Initialized
INFO - 2023-05-18 18:26:30 --> URI Class Initialized
INFO - 2023-05-18 18:26:30 --> Router Class Initialized
INFO - 2023-05-18 18:26:30 --> Output Class Initialized
INFO - 2023-05-18 18:26:30 --> Security Class Initialized
INFO - 2023-05-18 18:26:30 --> Input Class Initialized
INFO - 2023-05-18 18:26:30 --> Language Class Initialized
INFO - 2023-05-18 18:26:30 --> Loader Class Initialized
INFO - 2023-05-18 18:26:30 --> Helper loaded: url_helper
INFO - 2023-05-18 18:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:26:30 --> Form Validation Class Initialized
INFO - 2023-05-18 18:26:30 --> Controller Class Initialized
INFO - 2023-05-18 18:26:30 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-18 18:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-18 18:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-18 18:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-18 18:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-18 18:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-18 18:26:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-18 18:26:30 --> Final output sent to browser
INFO - 2023-05-18 18:37:12 --> Config Class Initialized
INFO - 2023-05-18 18:37:12 --> Hooks Class Initialized
INFO - 2023-05-18 18:37:12 --> Utf8 Class Initialized
INFO - 2023-05-18 18:37:12 --> URI Class Initialized
INFO - 2023-05-18 18:37:12 --> Router Class Initialized
INFO - 2023-05-18 18:37:12 --> Output Class Initialized
INFO - 2023-05-18 18:37:12 --> Security Class Initialized
INFO - 2023-05-18 18:37:12 --> Input Class Initialized
INFO - 2023-05-18 18:37:12 --> Language Class Initialized
INFO - 2023-05-18 18:37:12 --> Loader Class Initialized
INFO - 2023-05-18 18:37:12 --> Helper loaded: url_helper
INFO - 2023-05-18 18:37:12 --> Helper loaded: form_helper
INFO - 2023-05-18 18:37:12 --> Database Driver Class Initialized
INFO - 2023-05-18 18:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:37:12 --> Form Validation Class Initialized
INFO - 2023-05-18 18:37:12 --> Controller Class Initialized
INFO - 2023-05-18 18:37:12 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:37:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-18 18:37:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-18 18:37:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-18 18:37:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-18 18:37:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-18 18:37:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-18 18:37:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-18 18:37:12 --> Final output sent to browser
INFO - 2023-05-18 18:44:01 --> Config Class Initialized
INFO - 2023-05-18 18:44:01 --> Hooks Class Initialized
INFO - 2023-05-18 18:44:01 --> Utf8 Class Initialized
INFO - 2023-05-18 18:44:01 --> URI Class Initialized
INFO - 2023-05-18 18:44:01 --> Router Class Initialized
INFO - 2023-05-18 18:44:01 --> Output Class Initialized
INFO - 2023-05-18 18:44:01 --> Security Class Initialized
INFO - 2023-05-18 18:44:01 --> Input Class Initialized
INFO - 2023-05-18 18:44:01 --> Language Class Initialized
INFO - 2023-05-18 18:44:01 --> Loader Class Initialized
INFO - 2023-05-18 18:44:01 --> Helper loaded: url_helper
INFO - 2023-05-18 18:44:01 --> Helper loaded: form_helper
INFO - 2023-05-18 18:44:01 --> Database Driver Class Initialized
INFO - 2023-05-18 18:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:44:01 --> Form Validation Class Initialized
INFO - 2023-05-18 18:44:01 --> Controller Class Initialized
INFO - 2023-05-18 18:44:01 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:44:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-18 18:44:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-18 18:44:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-18 18:44:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-18 18:44:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-18 18:44:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-18 18:44:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-18 18:44:01 --> Final output sent to browser
INFO - 2023-05-18 18:47:00 --> Config Class Initialized
INFO - 2023-05-18 18:47:00 --> Hooks Class Initialized
INFO - 2023-05-18 18:47:00 --> Utf8 Class Initialized
INFO - 2023-05-18 18:47:00 --> URI Class Initialized
INFO - 2023-05-18 18:47:00 --> Router Class Initialized
INFO - 2023-05-18 18:47:00 --> Output Class Initialized
INFO - 2023-05-18 18:47:00 --> Security Class Initialized
INFO - 2023-05-18 18:47:00 --> Input Class Initialized
INFO - 2023-05-18 18:47:00 --> Language Class Initialized
INFO - 2023-05-18 18:47:00 --> Loader Class Initialized
INFO - 2023-05-18 18:47:00 --> Helper loaded: url_helper
INFO - 2023-05-18 18:47:00 --> Helper loaded: form_helper
INFO - 2023-05-18 18:47:00 --> Database Driver Class Initialized
INFO - 2023-05-18 18:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:47:00 --> Form Validation Class Initialized
INFO - 2023-05-18 18:47:00 --> Controller Class Initialized
INFO - 2023-05-18 18:47:00 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-18 18:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-18 18:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-18 18:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-18 18:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-18 18:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-18 18:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-18 18:47:00 --> Final output sent to browser
INFO - 2023-05-18 18:50:39 --> Config Class Initialized
INFO - 2023-05-18 18:50:39 --> Hooks Class Initialized
INFO - 2023-05-18 18:50:39 --> Utf8 Class Initialized
INFO - 2023-05-18 18:50:39 --> URI Class Initialized
INFO - 2023-05-18 18:50:39 --> Router Class Initialized
INFO - 2023-05-18 18:50:39 --> Output Class Initialized
INFO - 2023-05-18 18:50:39 --> Security Class Initialized
INFO - 2023-05-18 18:50:39 --> Input Class Initialized
INFO - 2023-05-18 18:50:39 --> Language Class Initialized
INFO - 2023-05-18 18:50:39 --> Loader Class Initialized
INFO - 2023-05-18 18:50:39 --> Helper loaded: url_helper
INFO - 2023-05-18 18:50:39 --> Helper loaded: form_helper
INFO - 2023-05-18 18:50:39 --> Database Driver Class Initialized
INFO - 2023-05-18 18:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:50:39 --> Form Validation Class Initialized
INFO - 2023-05-18 18:50:39 --> Controller Class Initialized
INFO - 2023-05-18 18:50:39 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:50:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-18 18:50:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-18 18:50:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-18 18:50:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-18 18:50:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-18 18:50:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-18 18:50:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-18 18:50:39 --> Final output sent to browser
INFO - 2023-05-18 18:52:27 --> Config Class Initialized
INFO - 2023-05-18 18:52:27 --> Hooks Class Initialized
INFO - 2023-05-18 18:52:27 --> Utf8 Class Initialized
INFO - 2023-05-18 18:52:27 --> URI Class Initialized
INFO - 2023-05-18 18:52:27 --> Router Class Initialized
INFO - 2023-05-18 18:52:27 --> Output Class Initialized
INFO - 2023-05-18 18:52:27 --> Security Class Initialized
INFO - 2023-05-18 18:52:27 --> Input Class Initialized
INFO - 2023-05-18 18:52:27 --> Language Class Initialized
INFO - 2023-05-18 18:52:27 --> Loader Class Initialized
INFO - 2023-05-18 18:52:27 --> Helper loaded: url_helper
INFO - 2023-05-18 18:52:27 --> Helper loaded: form_helper
INFO - 2023-05-18 18:52:27 --> Database Driver Class Initialized
INFO - 2023-05-18 18:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:52:27 --> Form Validation Class Initialized
INFO - 2023-05-18 18:52:27 --> Controller Class Initialized
INFO - 2023-05-18 18:52:27 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-18 18:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-18 18:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-18 18:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-18 18:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-18 18:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-18 18:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-18 18:52:27 --> Final output sent to browser
INFO - 2023-05-18 18:53:39 --> Config Class Initialized
INFO - 2023-05-18 18:53:39 --> Hooks Class Initialized
INFO - 2023-05-18 18:53:39 --> Utf8 Class Initialized
INFO - 2023-05-18 18:53:39 --> URI Class Initialized
INFO - 2023-05-18 18:53:39 --> Router Class Initialized
INFO - 2023-05-18 18:53:39 --> Output Class Initialized
INFO - 2023-05-18 18:53:39 --> Security Class Initialized
INFO - 2023-05-18 18:53:39 --> Input Class Initialized
INFO - 2023-05-18 18:53:39 --> Language Class Initialized
INFO - 2023-05-18 18:53:39 --> Loader Class Initialized
INFO - 2023-05-18 18:53:39 --> Helper loaded: url_helper
INFO - 2023-05-18 18:53:39 --> Helper loaded: form_helper
INFO - 2023-05-18 18:53:39 --> Database Driver Class Initialized
INFO - 2023-05-18 18:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-18 18:53:39 --> Form Validation Class Initialized
INFO - 2023-05-18 18:53:39 --> Controller Class Initialized
INFO - 2023-05-18 18:53:39 --> Model "m_datatrain" initialized
INFO - 2023-05-18 18:53:40 --> Model "m_penghitungan" initialized
INFO - 2023-05-18 18:53:40 --> Model "m_datatest" initialized
INFO - 2023-05-18 18:53:40 --> Final output sent to browser
