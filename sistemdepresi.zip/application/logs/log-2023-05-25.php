<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-25 16:51:16 --> Config Class Initialized
INFO - 2023-05-25 16:51:16 --> Hooks Class Initialized
INFO - 2023-05-25 16:51:16 --> Utf8 Class Initialized
INFO - 2023-05-25 16:51:16 --> URI Class Initialized
INFO - 2023-05-25 16:51:16 --> Router Class Initialized
INFO - 2023-05-25 16:51:16 --> Output Class Initialized
INFO - 2023-05-25 16:51:16 --> Security Class Initialized
INFO - 2023-05-25 16:51:16 --> Input Class Initialized
INFO - 2023-05-25 16:51:16 --> Language Class Initialized
INFO - 2023-05-25 16:51:16 --> Loader Class Initialized
INFO - 2023-05-25 16:51:16 --> Helper loaded: url_helper
INFO - 2023-05-25 16:51:16 --> Helper loaded: form_helper
INFO - 2023-05-25 16:51:17 --> Database Driver Class Initialized
INFO - 2023-05-25 16:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:51:17 --> Form Validation Class Initialized
INFO - 2023-05-25 16:51:17 --> Controller Class Initialized
INFO - 2023-05-25 16:51:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-25 16:51:17 --> Final output sent to browser
INFO - 2023-05-25 16:51:21 --> Config Class Initialized
INFO - 2023-05-25 16:51:21 --> Hooks Class Initialized
INFO - 2023-05-25 16:51:21 --> Utf8 Class Initialized
INFO - 2023-05-25 16:51:21 --> URI Class Initialized
INFO - 2023-05-25 16:51:21 --> Router Class Initialized
INFO - 2023-05-25 16:51:21 --> Output Class Initialized
INFO - 2023-05-25 16:51:21 --> Security Class Initialized
INFO - 2023-05-25 16:51:21 --> Input Class Initialized
INFO - 2023-05-25 16:51:21 --> Language Class Initialized
INFO - 2023-05-25 16:51:21 --> Loader Class Initialized
INFO - 2023-05-25 16:51:21 --> Helper loaded: url_helper
INFO - 2023-05-25 16:51:21 --> Helper loaded: form_helper
INFO - 2023-05-25 16:51:21 --> Database Driver Class Initialized
INFO - 2023-05-25 16:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:51:21 --> Form Validation Class Initialized
INFO - 2023-05-25 16:51:21 --> Controller Class Initialized
INFO - 2023-05-25 16:51:21 --> Model "m_user" initialized
INFO - 2023-05-25 16:51:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-25 16:51:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-25 16:51:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-25 16:51:21 --> Final output sent to browser
INFO - 2023-05-25 16:51:25 --> Config Class Initialized
INFO - 2023-05-25 16:51:25 --> Hooks Class Initialized
INFO - 2023-05-25 16:51:25 --> Utf8 Class Initialized
INFO - 2023-05-25 16:51:25 --> URI Class Initialized
INFO - 2023-05-25 16:51:25 --> Router Class Initialized
INFO - 2023-05-25 16:51:25 --> Output Class Initialized
INFO - 2023-05-25 16:51:25 --> Security Class Initialized
INFO - 2023-05-25 16:51:25 --> Input Class Initialized
INFO - 2023-05-25 16:51:25 --> Language Class Initialized
INFO - 2023-05-25 16:51:25 --> Loader Class Initialized
INFO - 2023-05-25 16:51:25 --> Helper loaded: url_helper
INFO - 2023-05-25 16:51:25 --> Helper loaded: form_helper
INFO - 2023-05-25 16:51:25 --> Database Driver Class Initialized
INFO - 2023-05-25 16:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:51:25 --> Form Validation Class Initialized
INFO - 2023-05-25 16:51:25 --> Controller Class Initialized
INFO - 2023-05-25 16:51:25 --> Model "m_user" initialized
INFO - 2023-05-25 16:51:25 --> Config Class Initialized
INFO - 2023-05-25 16:51:25 --> Hooks Class Initialized
INFO - 2023-05-25 16:51:25 --> Utf8 Class Initialized
INFO - 2023-05-25 16:51:25 --> URI Class Initialized
INFO - 2023-05-25 16:51:25 --> Router Class Initialized
INFO - 2023-05-25 16:51:25 --> Output Class Initialized
INFO - 2023-05-25 16:51:25 --> Security Class Initialized
INFO - 2023-05-25 16:51:25 --> Input Class Initialized
INFO - 2023-05-25 16:51:25 --> Language Class Initialized
INFO - 2023-05-25 16:51:25 --> Loader Class Initialized
INFO - 2023-05-25 16:51:25 --> Helper loaded: url_helper
INFO - 2023-05-25 16:51:25 --> Helper loaded: form_helper
INFO - 2023-05-25 16:51:25 --> Database Driver Class Initialized
INFO - 2023-05-25 16:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:51:25 --> Form Validation Class Initialized
INFO - 2023-05-25 16:51:25 --> Controller Class Initialized
INFO - 2023-05-25 16:51:25 --> Model "m_user" initialized
INFO - 2023-05-25 16:51:25 --> Model "m_datatrain" initialized
INFO - 2023-05-25 16:51:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 16:51:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 16:51:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 16:51:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 16:51:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 16:51:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-25 16:51:25 --> Final output sent to browser
INFO - 2023-05-25 16:51:30 --> Config Class Initialized
INFO - 2023-05-25 16:51:30 --> Hooks Class Initialized
INFO - 2023-05-25 16:51:30 --> Utf8 Class Initialized
INFO - 2023-05-25 16:51:30 --> URI Class Initialized
INFO - 2023-05-25 16:51:30 --> Router Class Initialized
INFO - 2023-05-25 16:51:30 --> Output Class Initialized
INFO - 2023-05-25 16:51:30 --> Security Class Initialized
INFO - 2023-05-25 16:51:30 --> Input Class Initialized
INFO - 2023-05-25 16:51:30 --> Language Class Initialized
INFO - 2023-05-25 16:51:30 --> Loader Class Initialized
INFO - 2023-05-25 16:51:30 --> Helper loaded: url_helper
INFO - 2023-05-25 16:51:30 --> Helper loaded: form_helper
INFO - 2023-05-25 16:51:30 --> Database Driver Class Initialized
INFO - 2023-05-25 16:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:51:30 --> Form Validation Class Initialized
INFO - 2023-05-25 16:51:30 --> Controller Class Initialized
INFO - 2023-05-25 16:51:30 --> Model "m_datatrain" initialized
INFO - 2023-05-25 16:51:30 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 16:51:30 --> Model "m_datatest" initialized
INFO - 2023-05-25 16:51:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 16:51:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 16:51:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-25 16:51:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 16:51:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 16:51:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 16:51:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 16:51:31 --> Final output sent to browser
INFO - 2023-05-25 16:52:11 --> Config Class Initialized
INFO - 2023-05-25 16:52:11 --> Hooks Class Initialized
INFO - 2023-05-25 16:52:11 --> Utf8 Class Initialized
INFO - 2023-05-25 16:52:11 --> URI Class Initialized
INFO - 2023-05-25 16:52:11 --> Router Class Initialized
INFO - 2023-05-25 16:52:11 --> Output Class Initialized
INFO - 2023-05-25 16:52:11 --> Security Class Initialized
INFO - 2023-05-25 16:52:11 --> Input Class Initialized
INFO - 2023-05-25 16:52:11 --> Language Class Initialized
INFO - 2023-05-25 16:52:11 --> Loader Class Initialized
INFO - 2023-05-25 16:52:11 --> Helper loaded: url_helper
INFO - 2023-05-25 16:52:11 --> Helper loaded: form_helper
INFO - 2023-05-25 16:52:11 --> Database Driver Class Initialized
INFO - 2023-05-25 16:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:52:11 --> Form Validation Class Initialized
INFO - 2023-05-25 16:52:11 --> Controller Class Initialized
INFO - 2023-05-25 16:52:11 --> Model "m_datatrain" initialized
INFO - 2023-05-25 16:52:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 16:52:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 16:52:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-25 16:52:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 16:52:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 16:52:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 16:52:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 16:52:11 --> Final output sent to browser
INFO - 2023-05-25 16:52:15 --> Config Class Initialized
INFO - 2023-05-25 16:52:15 --> Hooks Class Initialized
INFO - 2023-05-25 16:52:15 --> Utf8 Class Initialized
INFO - 2023-05-25 16:52:15 --> URI Class Initialized
INFO - 2023-05-25 16:52:15 --> Router Class Initialized
INFO - 2023-05-25 16:52:15 --> Output Class Initialized
INFO - 2023-05-25 16:52:15 --> Security Class Initialized
INFO - 2023-05-25 16:52:15 --> Input Class Initialized
INFO - 2023-05-25 16:52:15 --> Language Class Initialized
INFO - 2023-05-25 16:52:15 --> Loader Class Initialized
INFO - 2023-05-25 16:52:15 --> Helper loaded: url_helper
INFO - 2023-05-25 16:52:15 --> Helper loaded: form_helper
INFO - 2023-05-25 16:52:15 --> Database Driver Class Initialized
INFO - 2023-05-25 16:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:52:15 --> Form Validation Class Initialized
INFO - 2023-05-25 16:52:15 --> Controller Class Initialized
INFO - 2023-05-25 16:52:15 --> Model "m_datatest" initialized
INFO - 2023-05-25 16:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 16:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 16:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-25 16:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 16:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 16:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 16:52:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 16:52:15 --> Final output sent to browser
INFO - 2023-05-25 16:52:17 --> Config Class Initialized
INFO - 2023-05-25 16:52:17 --> Hooks Class Initialized
INFO - 2023-05-25 16:52:17 --> Utf8 Class Initialized
INFO - 2023-05-25 16:52:17 --> URI Class Initialized
INFO - 2023-05-25 16:52:17 --> Router Class Initialized
INFO - 2023-05-25 16:52:17 --> Output Class Initialized
INFO - 2023-05-25 16:52:17 --> Security Class Initialized
INFO - 2023-05-25 16:52:17 --> Input Class Initialized
INFO - 2023-05-25 16:52:17 --> Language Class Initialized
INFO - 2023-05-25 16:52:17 --> Loader Class Initialized
INFO - 2023-05-25 16:52:17 --> Helper loaded: url_helper
INFO - 2023-05-25 16:52:17 --> Helper loaded: form_helper
INFO - 2023-05-25 16:52:17 --> Database Driver Class Initialized
INFO - 2023-05-25 16:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:52:17 --> Form Validation Class Initialized
INFO - 2023-05-25 16:52:17 --> Controller Class Initialized
INFO - 2023-05-25 16:52:17 --> Model "m_datatrain" initialized
INFO - 2023-05-25 16:52:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 16:52:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 16:52:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-25 16:52:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 16:52:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 16:52:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 16:52:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 16:52:17 --> Final output sent to browser
INFO - 2023-05-25 16:52:18 --> Config Class Initialized
INFO - 2023-05-25 16:52:18 --> Hooks Class Initialized
INFO - 2023-05-25 16:52:18 --> Utf8 Class Initialized
INFO - 2023-05-25 16:52:18 --> URI Class Initialized
INFO - 2023-05-25 16:52:18 --> Router Class Initialized
INFO - 2023-05-25 16:52:18 --> Output Class Initialized
INFO - 2023-05-25 16:52:18 --> Security Class Initialized
INFO - 2023-05-25 16:52:18 --> Input Class Initialized
INFO - 2023-05-25 16:52:18 --> Language Class Initialized
INFO - 2023-05-25 16:52:18 --> Loader Class Initialized
INFO - 2023-05-25 16:52:18 --> Helper loaded: url_helper
INFO - 2023-05-25 16:52:18 --> Helper loaded: form_helper
INFO - 2023-05-25 16:52:18 --> Database Driver Class Initialized
INFO - 2023-05-25 16:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:52:18 --> Form Validation Class Initialized
INFO - 2023-05-25 16:52:18 --> Controller Class Initialized
INFO - 2023-05-25 16:52:18 --> Model "m_datatrain" initialized
INFO - 2023-05-25 16:52:18 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 16:52:18 --> Model "m_datatest" initialized
INFO - 2023-05-25 16:52:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 16:52:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 16:52:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-25 16:52:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 16:52:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 16:52:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 16:52:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 16:52:18 --> Final output sent to browser
INFO - 2023-05-25 16:56:04 --> Config Class Initialized
INFO - 2023-05-25 16:56:04 --> Hooks Class Initialized
INFO - 2023-05-25 16:56:04 --> Utf8 Class Initialized
INFO - 2023-05-25 16:56:04 --> URI Class Initialized
INFO - 2023-05-25 16:56:04 --> Router Class Initialized
INFO - 2023-05-25 16:56:04 --> Output Class Initialized
INFO - 2023-05-25 16:56:04 --> Security Class Initialized
INFO - 2023-05-25 16:56:04 --> Input Class Initialized
INFO - 2023-05-25 16:56:04 --> Language Class Initialized
INFO - 2023-05-25 16:56:04 --> Loader Class Initialized
INFO - 2023-05-25 16:56:04 --> Helper loaded: url_helper
INFO - 2023-05-25 16:56:04 --> Helper loaded: form_helper
INFO - 2023-05-25 16:56:04 --> Database Driver Class Initialized
INFO - 2023-05-25 16:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:56:04 --> Form Validation Class Initialized
INFO - 2023-05-25 16:56:04 --> Controller Class Initialized
INFO - 2023-05-25 16:56:04 --> Model "m_datatrain" initialized
INFO - 2023-05-25 16:56:04 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 16:56:04 --> Model "m_datatest" initialized
INFO - 2023-05-25 16:56:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 16:56:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 16:56:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-25 16:56:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 16:56:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 16:56:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 16:56:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 16:56:04 --> Final output sent to browser
INFO - 2023-05-25 17:51:11 --> Config Class Initialized
INFO - 2023-05-25 17:51:11 --> Hooks Class Initialized
INFO - 2023-05-25 17:51:11 --> Utf8 Class Initialized
INFO - 2023-05-25 17:51:11 --> URI Class Initialized
INFO - 2023-05-25 17:51:11 --> Router Class Initialized
INFO - 2023-05-25 17:51:11 --> Output Class Initialized
INFO - 2023-05-25 17:51:11 --> Security Class Initialized
INFO - 2023-05-25 17:51:11 --> Input Class Initialized
INFO - 2023-05-25 17:51:11 --> Language Class Initialized
INFO - 2023-05-25 17:51:11 --> Loader Class Initialized
INFO - 2023-05-25 17:51:11 --> Helper loaded: url_helper
INFO - 2023-05-25 17:51:11 --> Helper loaded: form_helper
INFO - 2023-05-25 17:51:11 --> Database Driver Class Initialized
INFO - 2023-05-25 17:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 17:51:11 --> Form Validation Class Initialized
INFO - 2023-05-25 17:51:11 --> Controller Class Initialized
INFO - 2023-05-25 17:51:11 --> Model "m_user" initialized
INFO - 2023-05-25 17:51:11 --> Config Class Initialized
INFO - 2023-05-25 17:51:11 --> Hooks Class Initialized
INFO - 2023-05-25 17:51:11 --> Utf8 Class Initialized
INFO - 2023-05-25 17:51:11 --> URI Class Initialized
INFO - 2023-05-25 17:51:11 --> Router Class Initialized
INFO - 2023-05-25 17:51:11 --> Output Class Initialized
INFO - 2023-05-25 17:51:11 --> Security Class Initialized
INFO - 2023-05-25 17:51:11 --> Input Class Initialized
INFO - 2023-05-25 17:51:11 --> Language Class Initialized
INFO - 2023-05-25 17:51:11 --> Loader Class Initialized
INFO - 2023-05-25 17:51:11 --> Helper loaded: url_helper
INFO - 2023-05-25 17:51:11 --> Helper loaded: form_helper
INFO - 2023-05-25 17:51:11 --> Database Driver Class Initialized
INFO - 2023-05-25 17:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 17:51:11 --> Form Validation Class Initialized
INFO - 2023-05-25 17:51:11 --> Controller Class Initialized
INFO - 2023-05-25 17:51:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-25 17:51:11 --> Final output sent to browser
INFO - 2023-05-25 17:51:12 --> Config Class Initialized
INFO - 2023-05-25 17:51:12 --> Hooks Class Initialized
INFO - 2023-05-25 17:51:12 --> Utf8 Class Initialized
INFO - 2023-05-25 17:51:12 --> URI Class Initialized
INFO - 2023-05-25 17:51:12 --> Router Class Initialized
INFO - 2023-05-25 17:51:12 --> Output Class Initialized
INFO - 2023-05-25 17:51:12 --> Security Class Initialized
INFO - 2023-05-25 17:51:12 --> Input Class Initialized
INFO - 2023-05-25 17:51:12 --> Language Class Initialized
INFO - 2023-05-25 17:51:12 --> Loader Class Initialized
INFO - 2023-05-25 17:51:12 --> Helper loaded: url_helper
INFO - 2023-05-25 17:51:12 --> Helper loaded: form_helper
INFO - 2023-05-25 17:51:12 --> Database Driver Class Initialized
INFO - 2023-05-25 17:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 17:51:12 --> Form Validation Class Initialized
INFO - 2023-05-25 17:51:12 --> Controller Class Initialized
INFO - 2023-05-25 17:51:12 --> Model "m_user" initialized
INFO - 2023-05-25 17:51:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 17:51:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 17:51:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-25 17:51:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 17:51:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 17:51:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-25 17:51:12 --> Final output sent to browser
INFO - 2023-05-25 17:51:23 --> Config Class Initialized
INFO - 2023-05-25 17:51:23 --> Hooks Class Initialized
INFO - 2023-05-25 17:51:23 --> Utf8 Class Initialized
INFO - 2023-05-25 17:51:23 --> URI Class Initialized
INFO - 2023-05-25 17:51:23 --> Router Class Initialized
INFO - 2023-05-25 17:51:23 --> Output Class Initialized
INFO - 2023-05-25 17:51:23 --> Security Class Initialized
INFO - 2023-05-25 17:51:23 --> Input Class Initialized
INFO - 2023-05-25 17:51:23 --> Language Class Initialized
ERROR - 2023-05-25 17:51:23 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 782
INFO - 2023-05-25 17:52:01 --> Config Class Initialized
INFO - 2023-05-25 17:52:01 --> Hooks Class Initialized
INFO - 2023-05-25 17:52:01 --> Utf8 Class Initialized
INFO - 2023-05-25 17:52:01 --> URI Class Initialized
INFO - 2023-05-25 17:52:01 --> Router Class Initialized
INFO - 2023-05-25 17:52:01 --> Output Class Initialized
INFO - 2023-05-25 17:52:01 --> Security Class Initialized
INFO - 2023-05-25 17:52:01 --> Input Class Initialized
INFO - 2023-05-25 17:52:01 --> Language Class Initialized
INFO - 2023-05-25 17:52:01 --> Loader Class Initialized
INFO - 2023-05-25 17:52:01 --> Helper loaded: url_helper
INFO - 2023-05-25 17:52:01 --> Helper loaded: form_helper
INFO - 2023-05-25 17:52:01 --> Database Driver Class Initialized
INFO - 2023-05-25 17:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 17:52:01 --> Form Validation Class Initialized
INFO - 2023-05-25 17:52:01 --> Controller Class Initialized
INFO - 2023-05-25 17:52:01 --> Model "m_datatrain" initialized
INFO - 2023-05-25 17:52:01 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 17:52:01 --> Model "m_datatest" initialized
INFO - 2023-05-25 17:52:01 --> Final output sent to browser
INFO - 2023-05-25 17:59:50 --> Config Class Initialized
INFO - 2023-05-25 17:59:50 --> Hooks Class Initialized
INFO - 2023-05-25 17:59:50 --> Utf8 Class Initialized
INFO - 2023-05-25 17:59:50 --> URI Class Initialized
INFO - 2023-05-25 17:59:50 --> Router Class Initialized
INFO - 2023-05-25 17:59:50 --> Output Class Initialized
INFO - 2023-05-25 17:59:50 --> Security Class Initialized
INFO - 2023-05-25 17:59:50 --> Input Class Initialized
INFO - 2023-05-25 17:59:50 --> Language Class Initialized
INFO - 2023-05-25 17:59:50 --> Loader Class Initialized
INFO - 2023-05-25 17:59:50 --> Helper loaded: url_helper
INFO - 2023-05-25 17:59:50 --> Helper loaded: form_helper
INFO - 2023-05-25 17:59:50 --> Database Driver Class Initialized
INFO - 2023-05-25 17:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 17:59:50 --> Form Validation Class Initialized
INFO - 2023-05-25 17:59:50 --> Controller Class Initialized
INFO - 2023-05-25 17:59:50 --> Model "m_datatrain" initialized
INFO - 2023-05-25 17:59:50 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 17:59:50 --> Model "m_datatest" initialized
INFO - 2023-05-25 17:59:50 --> Final output sent to browser
INFO - 2023-05-25 18:00:22 --> Config Class Initialized
INFO - 2023-05-25 18:00:22 --> Hooks Class Initialized
INFO - 2023-05-25 18:00:22 --> Utf8 Class Initialized
INFO - 2023-05-25 18:00:22 --> URI Class Initialized
INFO - 2023-05-25 18:00:22 --> Router Class Initialized
INFO - 2023-05-25 18:00:22 --> Output Class Initialized
INFO - 2023-05-25 18:00:22 --> Security Class Initialized
INFO - 2023-05-25 18:00:22 --> Input Class Initialized
INFO - 2023-05-25 18:00:22 --> Language Class Initialized
INFO - 2023-05-25 18:00:22 --> Loader Class Initialized
INFO - 2023-05-25 18:00:22 --> Helper loaded: url_helper
INFO - 2023-05-25 18:00:22 --> Helper loaded: form_helper
INFO - 2023-05-25 18:00:22 --> Database Driver Class Initialized
INFO - 2023-05-25 18:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:00:22 --> Form Validation Class Initialized
INFO - 2023-05-25 18:00:22 --> Controller Class Initialized
INFO - 2023-05-25 18:00:22 --> Model "m_datatrain" initialized
INFO - 2023-05-25 18:00:22 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 18:00:22 --> Model "m_datatest" initialized
INFO - 2023-05-25 18:00:22 --> Final output sent to browser
INFO - 2023-05-25 18:26:53 --> Config Class Initialized
INFO - 2023-05-25 18:26:53 --> Hooks Class Initialized
INFO - 2023-05-25 18:26:53 --> Utf8 Class Initialized
INFO - 2023-05-25 18:26:53 --> URI Class Initialized
INFO - 2023-05-25 18:26:53 --> Router Class Initialized
INFO - 2023-05-25 18:26:53 --> Output Class Initialized
INFO - 2023-05-25 18:26:53 --> Security Class Initialized
INFO - 2023-05-25 18:26:53 --> Input Class Initialized
INFO - 2023-05-25 18:26:53 --> Language Class Initialized
INFO - 2023-05-25 18:26:53 --> Loader Class Initialized
INFO - 2023-05-25 18:26:53 --> Helper loaded: url_helper
INFO - 2023-05-25 18:26:53 --> Helper loaded: form_helper
INFO - 2023-05-25 18:26:53 --> Database Driver Class Initialized
INFO - 2023-05-25 18:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:26:53 --> Form Validation Class Initialized
INFO - 2023-05-25 18:26:53 --> Controller Class Initialized
INFO - 2023-05-25 18:26:53 --> Model "m_user" initialized
INFO - 2023-05-25 18:26:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 18:26:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 18:26:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-25 18:26:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 18:26:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 18:26:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-25 18:26:53 --> Final output sent to browser
INFO - 2023-05-25 18:26:58 --> Config Class Initialized
INFO - 2023-05-25 18:26:58 --> Hooks Class Initialized
INFO - 2023-05-25 18:26:58 --> Utf8 Class Initialized
INFO - 2023-05-25 18:26:58 --> URI Class Initialized
INFO - 2023-05-25 18:26:58 --> Router Class Initialized
INFO - 2023-05-25 18:26:58 --> Output Class Initialized
INFO - 2023-05-25 18:26:58 --> Security Class Initialized
INFO - 2023-05-25 18:26:58 --> Input Class Initialized
INFO - 2023-05-25 18:26:58 --> Language Class Initialized
INFO - 2023-05-25 18:26:58 --> Loader Class Initialized
INFO - 2023-05-25 18:26:58 --> Helper loaded: url_helper
INFO - 2023-05-25 18:26:58 --> Helper loaded: form_helper
INFO - 2023-05-25 18:26:58 --> Database Driver Class Initialized
INFO - 2023-05-25 18:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:26:58 --> Form Validation Class Initialized
INFO - 2023-05-25 18:26:58 --> Controller Class Initialized
INFO - 2023-05-25 18:26:58 --> Model "m_user" initialized
INFO - 2023-05-25 18:26:58 --> Config Class Initialized
INFO - 2023-05-25 18:26:58 --> Hooks Class Initialized
INFO - 2023-05-25 18:26:58 --> Utf8 Class Initialized
INFO - 2023-05-25 18:26:58 --> URI Class Initialized
INFO - 2023-05-25 18:26:58 --> Router Class Initialized
INFO - 2023-05-25 18:26:58 --> Output Class Initialized
INFO - 2023-05-25 18:26:58 --> Security Class Initialized
INFO - 2023-05-25 18:26:58 --> Input Class Initialized
INFO - 2023-05-25 18:26:58 --> Language Class Initialized
INFO - 2023-05-25 18:26:58 --> Loader Class Initialized
INFO - 2023-05-25 18:26:58 --> Helper loaded: url_helper
INFO - 2023-05-25 18:26:58 --> Helper loaded: form_helper
INFO - 2023-05-25 18:26:58 --> Database Driver Class Initialized
INFO - 2023-05-25 18:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:26:58 --> Form Validation Class Initialized
INFO - 2023-05-25 18:26:58 --> Controller Class Initialized
INFO - 2023-05-25 18:26:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-25 18:26:58 --> Final output sent to browser
INFO - 2023-05-25 18:26:59 --> Config Class Initialized
INFO - 2023-05-25 18:26:59 --> Hooks Class Initialized
INFO - 2023-05-25 18:26:59 --> Utf8 Class Initialized
INFO - 2023-05-25 18:26:59 --> URI Class Initialized
INFO - 2023-05-25 18:26:59 --> Router Class Initialized
INFO - 2023-05-25 18:26:59 --> Output Class Initialized
INFO - 2023-05-25 18:26:59 --> Security Class Initialized
INFO - 2023-05-25 18:26:59 --> Input Class Initialized
INFO - 2023-05-25 18:26:59 --> Language Class Initialized
INFO - 2023-05-25 18:26:59 --> Loader Class Initialized
INFO - 2023-05-25 18:26:59 --> Helper loaded: url_helper
INFO - 2023-05-25 18:26:59 --> Helper loaded: form_helper
INFO - 2023-05-25 18:26:59 --> Database Driver Class Initialized
INFO - 2023-05-25 18:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:26:59 --> Form Validation Class Initialized
INFO - 2023-05-25 18:26:59 --> Controller Class Initialized
INFO - 2023-05-25 18:26:59 --> Model "m_user" initialized
INFO - 2023-05-25 18:26:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-25 18:26:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-25 18:26:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-25 18:26:59 --> Final output sent to browser
INFO - 2023-05-25 18:27:04 --> Config Class Initialized
INFO - 2023-05-25 18:27:04 --> Hooks Class Initialized
INFO - 2023-05-25 18:27:04 --> Utf8 Class Initialized
INFO - 2023-05-25 18:27:04 --> URI Class Initialized
INFO - 2023-05-25 18:27:04 --> Router Class Initialized
INFO - 2023-05-25 18:27:04 --> Output Class Initialized
INFO - 2023-05-25 18:27:04 --> Security Class Initialized
INFO - 2023-05-25 18:27:04 --> Input Class Initialized
INFO - 2023-05-25 18:27:04 --> Language Class Initialized
INFO - 2023-05-25 18:27:04 --> Loader Class Initialized
INFO - 2023-05-25 18:27:04 --> Helper loaded: url_helper
INFO - 2023-05-25 18:27:04 --> Helper loaded: form_helper
INFO - 2023-05-25 18:27:04 --> Database Driver Class Initialized
INFO - 2023-05-25 18:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:27:04 --> Form Validation Class Initialized
INFO - 2023-05-25 18:27:04 --> Controller Class Initialized
INFO - 2023-05-25 18:27:04 --> Model "m_user" initialized
INFO - 2023-05-25 18:27:04 --> Config Class Initialized
INFO - 2023-05-25 18:27:04 --> Hooks Class Initialized
INFO - 2023-05-25 18:27:04 --> Utf8 Class Initialized
INFO - 2023-05-25 18:27:04 --> URI Class Initialized
INFO - 2023-05-25 18:27:04 --> Router Class Initialized
INFO - 2023-05-25 18:27:04 --> Output Class Initialized
INFO - 2023-05-25 18:27:04 --> Security Class Initialized
INFO - 2023-05-25 18:27:04 --> Input Class Initialized
INFO - 2023-05-25 18:27:04 --> Language Class Initialized
INFO - 2023-05-25 18:27:04 --> Loader Class Initialized
INFO - 2023-05-25 18:27:04 --> Helper loaded: url_helper
INFO - 2023-05-25 18:27:04 --> Helper loaded: form_helper
INFO - 2023-05-25 18:27:04 --> Database Driver Class Initialized
INFO - 2023-05-25 18:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:27:04 --> Form Validation Class Initialized
INFO - 2023-05-25 18:27:04 --> Controller Class Initialized
INFO - 2023-05-25 18:27:04 --> Model "m_user" initialized
INFO - 2023-05-25 18:27:04 --> Model "m_datatrain" initialized
INFO - 2023-05-25 18:27:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 18:27:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 18:27:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 18:27:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 18:27:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 18:27:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-25 18:27:04 --> Final output sent to browser
INFO - 2023-05-25 18:27:07 --> Config Class Initialized
INFO - 2023-05-25 18:27:07 --> Hooks Class Initialized
INFO - 2023-05-25 18:27:07 --> Utf8 Class Initialized
INFO - 2023-05-25 18:27:07 --> URI Class Initialized
INFO - 2023-05-25 18:27:07 --> Router Class Initialized
INFO - 2023-05-25 18:27:07 --> Output Class Initialized
INFO - 2023-05-25 18:27:07 --> Security Class Initialized
INFO - 2023-05-25 18:27:07 --> Input Class Initialized
INFO - 2023-05-25 18:27:07 --> Language Class Initialized
INFO - 2023-05-25 18:27:07 --> Loader Class Initialized
INFO - 2023-05-25 18:27:07 --> Helper loaded: url_helper
INFO - 2023-05-25 18:27:07 --> Helper loaded: form_helper
INFO - 2023-05-25 18:27:07 --> Database Driver Class Initialized
INFO - 2023-05-25 18:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:27:07 --> Form Validation Class Initialized
INFO - 2023-05-25 18:27:07 --> Controller Class Initialized
INFO - 2023-05-25 18:27:07 --> Model "m_datatrain" initialized
INFO - 2023-05-25 18:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 18:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 18:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-25 18:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 18:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 18:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 18:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 18:27:07 --> Final output sent to browser
INFO - 2023-05-25 18:27:29 --> Config Class Initialized
INFO - 2023-05-25 18:27:29 --> Hooks Class Initialized
INFO - 2023-05-25 18:27:29 --> Utf8 Class Initialized
INFO - 2023-05-25 18:27:29 --> URI Class Initialized
INFO - 2023-05-25 18:27:29 --> Router Class Initialized
INFO - 2023-05-25 18:27:29 --> Output Class Initialized
INFO - 2023-05-25 18:27:29 --> Security Class Initialized
INFO - 2023-05-25 18:27:29 --> Input Class Initialized
INFO - 2023-05-25 18:27:29 --> Language Class Initialized
INFO - 2023-05-25 18:27:29 --> Loader Class Initialized
INFO - 2023-05-25 18:27:29 --> Helper loaded: url_helper
INFO - 2023-05-25 18:27:29 --> Helper loaded: form_helper
INFO - 2023-05-25 18:27:29 --> Database Driver Class Initialized
INFO - 2023-05-25 18:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:27:29 --> Form Validation Class Initialized
INFO - 2023-05-25 18:27:29 --> Controller Class Initialized
INFO - 2023-05-25 18:27:29 --> Model "m_user" initialized
INFO - 2023-05-25 18:27:29 --> Config Class Initialized
INFO - 2023-05-25 18:27:29 --> Hooks Class Initialized
INFO - 2023-05-25 18:27:29 --> Utf8 Class Initialized
INFO - 2023-05-25 18:27:29 --> URI Class Initialized
INFO - 2023-05-25 18:27:29 --> Router Class Initialized
INFO - 2023-05-25 18:27:29 --> Output Class Initialized
INFO - 2023-05-25 18:27:29 --> Security Class Initialized
INFO - 2023-05-25 18:27:29 --> Input Class Initialized
INFO - 2023-05-25 18:27:29 --> Language Class Initialized
INFO - 2023-05-25 18:27:29 --> Loader Class Initialized
INFO - 2023-05-25 18:27:29 --> Helper loaded: url_helper
INFO - 2023-05-25 18:27:29 --> Helper loaded: form_helper
INFO - 2023-05-25 18:27:29 --> Database Driver Class Initialized
INFO - 2023-05-25 18:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:27:29 --> Form Validation Class Initialized
INFO - 2023-05-25 18:27:29 --> Controller Class Initialized
INFO - 2023-05-25 18:27:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-25 18:27:29 --> Final output sent to browser
INFO - 2023-05-25 18:27:30 --> Config Class Initialized
INFO - 2023-05-25 18:27:30 --> Hooks Class Initialized
INFO - 2023-05-25 18:27:30 --> Utf8 Class Initialized
INFO - 2023-05-25 18:27:30 --> URI Class Initialized
INFO - 2023-05-25 18:27:30 --> Router Class Initialized
INFO - 2023-05-25 18:27:30 --> Output Class Initialized
INFO - 2023-05-25 18:27:30 --> Security Class Initialized
INFO - 2023-05-25 18:27:30 --> Input Class Initialized
INFO - 2023-05-25 18:27:30 --> Language Class Initialized
INFO - 2023-05-25 18:27:30 --> Loader Class Initialized
INFO - 2023-05-25 18:27:30 --> Helper loaded: url_helper
INFO - 2023-05-25 18:27:30 --> Helper loaded: form_helper
INFO - 2023-05-25 18:27:30 --> Database Driver Class Initialized
INFO - 2023-05-25 18:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:27:30 --> Form Validation Class Initialized
INFO - 2023-05-25 18:27:30 --> Controller Class Initialized
INFO - 2023-05-25 18:27:30 --> Model "m_user" initialized
INFO - 2023-05-25 18:27:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 18:27:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 18:27:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-25 18:27:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 18:27:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 18:27:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-25 18:27:30 --> Final output sent to browser
INFO - 2023-05-25 18:27:31 --> Config Class Initialized
INFO - 2023-05-25 18:27:31 --> Hooks Class Initialized
INFO - 2023-05-25 18:27:31 --> Utf8 Class Initialized
INFO - 2023-05-25 18:27:31 --> URI Class Initialized
INFO - 2023-05-25 18:27:31 --> Router Class Initialized
INFO - 2023-05-25 18:27:31 --> Output Class Initialized
INFO - 2023-05-25 18:27:31 --> Security Class Initialized
INFO - 2023-05-25 18:27:31 --> Input Class Initialized
INFO - 2023-05-25 18:27:31 --> Language Class Initialized
INFO - 2023-05-25 18:27:31 --> Loader Class Initialized
INFO - 2023-05-25 18:27:31 --> Helper loaded: url_helper
INFO - 2023-05-25 18:27:31 --> Helper loaded: form_helper
INFO - 2023-05-25 18:27:31 --> Database Driver Class Initialized
INFO - 2023-05-25 18:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:27:31 --> Form Validation Class Initialized
INFO - 2023-05-25 18:27:31 --> Controller Class Initialized
INFO - 2023-05-25 18:27:31 --> Model "m_datatrain" initialized
INFO - 2023-05-25 18:27:31 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 18:27:31 --> Model "m_datatest" initialized
INFO - 2023-05-25 18:27:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 18:27:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 18:27:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-25 18:27:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-25 18:27:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 18:27:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 18:27:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-25 18:27:31 --> Final output sent to browser
INFO - 2023-05-25 18:28:50 --> Config Class Initialized
INFO - 2023-05-25 18:28:50 --> Hooks Class Initialized
INFO - 2023-05-25 18:28:50 --> Utf8 Class Initialized
INFO - 2023-05-25 18:28:50 --> URI Class Initialized
INFO - 2023-05-25 18:28:50 --> Router Class Initialized
INFO - 2023-05-25 18:28:50 --> Output Class Initialized
INFO - 2023-05-25 18:28:50 --> Security Class Initialized
INFO - 2023-05-25 18:28:50 --> Input Class Initialized
INFO - 2023-05-25 18:28:50 --> Language Class Initialized
INFO - 2023-05-25 18:28:50 --> Loader Class Initialized
INFO - 2023-05-25 18:28:50 --> Helper loaded: url_helper
INFO - 2023-05-25 18:28:50 --> Helper loaded: form_helper
INFO - 2023-05-25 18:28:50 --> Database Driver Class Initialized
INFO - 2023-05-25 18:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:28:50 --> Form Validation Class Initialized
INFO - 2023-05-25 18:28:50 --> Controller Class Initialized
INFO - 2023-05-25 18:28:50 --> Model "m_datatrain" initialized
INFO - 2023-05-25 18:28:50 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 18:28:50 --> Model "m_datatest" initialized
INFO - 2023-05-25 18:28:50 --> Config Class Initialized
INFO - 2023-05-25 18:28:50 --> Hooks Class Initialized
INFO - 2023-05-25 18:28:50 --> Utf8 Class Initialized
INFO - 2023-05-25 18:28:50 --> URI Class Initialized
INFO - 2023-05-25 18:28:50 --> Router Class Initialized
INFO - 2023-05-25 18:28:50 --> Output Class Initialized
INFO - 2023-05-25 18:28:50 --> Security Class Initialized
INFO - 2023-05-25 18:28:50 --> Input Class Initialized
INFO - 2023-05-25 18:28:50 --> Language Class Initialized
INFO - 2023-05-25 18:28:50 --> Loader Class Initialized
INFO - 2023-05-25 18:28:50 --> Helper loaded: url_helper
INFO - 2023-05-25 18:28:50 --> Helper loaded: form_helper
INFO - 2023-05-25 18:28:50 --> Database Driver Class Initialized
INFO - 2023-05-25 18:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:28:50 --> Form Validation Class Initialized
INFO - 2023-05-25 18:28:50 --> Controller Class Initialized
INFO - 2023-05-25 18:28:50 --> Model "m_datatrain" initialized
INFO - 2023-05-25 18:28:50 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 18:28:50 --> Model "m_datatest" initialized
INFO - 2023-05-25 18:28:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 18:28:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 18:28:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-25 18:28:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-25 18:28:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 18:28:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 18:28:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-25 18:28:50 --> Final output sent to browser
INFO - 2023-05-25 18:28:59 --> Config Class Initialized
INFO - 2023-05-25 18:28:59 --> Hooks Class Initialized
INFO - 2023-05-25 18:28:59 --> Utf8 Class Initialized
INFO - 2023-05-25 18:28:59 --> URI Class Initialized
INFO - 2023-05-25 18:28:59 --> Router Class Initialized
INFO - 2023-05-25 18:28:59 --> Output Class Initialized
INFO - 2023-05-25 18:28:59 --> Security Class Initialized
INFO - 2023-05-25 18:28:59 --> Input Class Initialized
INFO - 2023-05-25 18:28:59 --> Language Class Initialized
INFO - 2023-05-25 18:28:59 --> Loader Class Initialized
INFO - 2023-05-25 18:28:59 --> Helper loaded: url_helper
INFO - 2023-05-25 18:28:59 --> Helper loaded: form_helper
INFO - 2023-05-25 18:28:59 --> Database Driver Class Initialized
INFO - 2023-05-25 18:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:28:59 --> Form Validation Class Initialized
INFO - 2023-05-25 18:28:59 --> Controller Class Initialized
INFO - 2023-05-25 18:28:59 --> Model "m_user" initialized
INFO - 2023-05-25 18:28:59 --> Config Class Initialized
INFO - 2023-05-25 18:28:59 --> Hooks Class Initialized
INFO - 2023-05-25 18:28:59 --> Utf8 Class Initialized
INFO - 2023-05-25 18:28:59 --> URI Class Initialized
INFO - 2023-05-25 18:28:59 --> Router Class Initialized
INFO - 2023-05-25 18:28:59 --> Output Class Initialized
INFO - 2023-05-25 18:28:59 --> Security Class Initialized
INFO - 2023-05-25 18:28:59 --> Input Class Initialized
INFO - 2023-05-25 18:28:59 --> Language Class Initialized
INFO - 2023-05-25 18:28:59 --> Loader Class Initialized
INFO - 2023-05-25 18:28:59 --> Helper loaded: url_helper
INFO - 2023-05-25 18:28:59 --> Helper loaded: form_helper
INFO - 2023-05-25 18:28:59 --> Database Driver Class Initialized
INFO - 2023-05-25 18:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:28:59 --> Form Validation Class Initialized
INFO - 2023-05-25 18:28:59 --> Controller Class Initialized
INFO - 2023-05-25 18:28:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-25 18:28:59 --> Final output sent to browser
INFO - 2023-05-25 18:29:02 --> Config Class Initialized
INFO - 2023-05-25 18:29:02 --> Hooks Class Initialized
INFO - 2023-05-25 18:29:02 --> Utf8 Class Initialized
INFO - 2023-05-25 18:29:02 --> URI Class Initialized
INFO - 2023-05-25 18:29:02 --> Router Class Initialized
INFO - 2023-05-25 18:29:02 --> Output Class Initialized
INFO - 2023-05-25 18:29:02 --> Security Class Initialized
INFO - 2023-05-25 18:29:02 --> Input Class Initialized
INFO - 2023-05-25 18:29:02 --> Language Class Initialized
INFO - 2023-05-25 18:29:02 --> Loader Class Initialized
INFO - 2023-05-25 18:29:02 --> Helper loaded: url_helper
INFO - 2023-05-25 18:29:02 --> Helper loaded: form_helper
INFO - 2023-05-25 18:29:02 --> Database Driver Class Initialized
INFO - 2023-05-25 18:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:29:02 --> Form Validation Class Initialized
INFO - 2023-05-25 18:29:02 --> Controller Class Initialized
INFO - 2023-05-25 18:29:02 --> Model "m_user" initialized
INFO - 2023-05-25 18:29:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-25 18:29:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-25 18:29:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-25 18:29:02 --> Final output sent to browser
INFO - 2023-05-25 18:29:09 --> Config Class Initialized
INFO - 2023-05-25 18:29:09 --> Hooks Class Initialized
INFO - 2023-05-25 18:29:09 --> Utf8 Class Initialized
INFO - 2023-05-25 18:29:09 --> URI Class Initialized
INFO - 2023-05-25 18:29:09 --> Router Class Initialized
INFO - 2023-05-25 18:29:09 --> Output Class Initialized
INFO - 2023-05-25 18:29:09 --> Security Class Initialized
INFO - 2023-05-25 18:29:09 --> Input Class Initialized
INFO - 2023-05-25 18:29:09 --> Language Class Initialized
INFO - 2023-05-25 18:29:09 --> Loader Class Initialized
INFO - 2023-05-25 18:29:09 --> Helper loaded: url_helper
INFO - 2023-05-25 18:29:09 --> Helper loaded: form_helper
INFO - 2023-05-25 18:29:09 --> Database Driver Class Initialized
INFO - 2023-05-25 18:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:29:09 --> Form Validation Class Initialized
INFO - 2023-05-25 18:29:09 --> Controller Class Initialized
INFO - 2023-05-25 18:29:09 --> Model "m_user" initialized
INFO - 2023-05-25 18:29:09 --> Config Class Initialized
INFO - 2023-05-25 18:29:09 --> Hooks Class Initialized
INFO - 2023-05-25 18:29:09 --> Utf8 Class Initialized
INFO - 2023-05-25 18:29:09 --> URI Class Initialized
INFO - 2023-05-25 18:29:09 --> Router Class Initialized
INFO - 2023-05-25 18:29:09 --> Output Class Initialized
INFO - 2023-05-25 18:29:09 --> Security Class Initialized
INFO - 2023-05-25 18:29:09 --> Input Class Initialized
INFO - 2023-05-25 18:29:09 --> Language Class Initialized
INFO - 2023-05-25 18:29:09 --> Loader Class Initialized
INFO - 2023-05-25 18:29:09 --> Helper loaded: url_helper
INFO - 2023-05-25 18:29:09 --> Helper loaded: form_helper
INFO - 2023-05-25 18:29:09 --> Database Driver Class Initialized
INFO - 2023-05-25 18:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:29:09 --> Form Validation Class Initialized
INFO - 2023-05-25 18:29:09 --> Controller Class Initialized
INFO - 2023-05-25 18:29:09 --> Model "m_user" initialized
INFO - 2023-05-25 18:29:09 --> Model "m_datatrain" initialized
INFO - 2023-05-25 18:29:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 18:29:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 18:29:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 18:29:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 18:29:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 18:29:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-25 18:29:09 --> Final output sent to browser
INFO - 2023-05-25 18:29:10 --> Config Class Initialized
INFO - 2023-05-25 18:29:10 --> Hooks Class Initialized
INFO - 2023-05-25 18:29:10 --> Utf8 Class Initialized
INFO - 2023-05-25 18:29:10 --> URI Class Initialized
INFO - 2023-05-25 18:29:10 --> Router Class Initialized
INFO - 2023-05-25 18:29:10 --> Output Class Initialized
INFO - 2023-05-25 18:29:10 --> Security Class Initialized
INFO - 2023-05-25 18:29:10 --> Input Class Initialized
INFO - 2023-05-25 18:29:10 --> Language Class Initialized
INFO - 2023-05-25 18:29:10 --> Loader Class Initialized
INFO - 2023-05-25 18:29:10 --> Helper loaded: url_helper
INFO - 2023-05-25 18:29:10 --> Helper loaded: form_helper
INFO - 2023-05-25 18:29:10 --> Database Driver Class Initialized
INFO - 2023-05-25 18:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:29:10 --> Form Validation Class Initialized
INFO - 2023-05-25 18:29:10 --> Controller Class Initialized
INFO - 2023-05-25 18:29:10 --> Model "m_datatest" initialized
INFO - 2023-05-25 18:29:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 18:29:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 18:29:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-25 18:29:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 18:29:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 18:29:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 18:29:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 18:29:10 --> Final output sent to browser
INFO - 2023-05-25 18:34:00 --> Config Class Initialized
INFO - 2023-05-25 18:34:00 --> Hooks Class Initialized
INFO - 2023-05-25 18:34:00 --> Utf8 Class Initialized
INFO - 2023-05-25 18:34:00 --> URI Class Initialized
INFO - 2023-05-25 18:34:00 --> Router Class Initialized
INFO - 2023-05-25 18:34:00 --> Output Class Initialized
INFO - 2023-05-25 18:34:00 --> Security Class Initialized
INFO - 2023-05-25 18:34:00 --> Input Class Initialized
INFO - 2023-05-25 18:34:00 --> Language Class Initialized
INFO - 2023-05-25 18:34:00 --> Loader Class Initialized
INFO - 2023-05-25 18:34:00 --> Helper loaded: url_helper
INFO - 2023-05-25 18:34:00 --> Helper loaded: form_helper
INFO - 2023-05-25 18:34:00 --> Database Driver Class Initialized
INFO - 2023-05-25 18:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 18:34:00 --> Form Validation Class Initialized
INFO - 2023-05-25 18:34:00 --> Controller Class Initialized
INFO - 2023-05-25 18:34:00 --> Model "m_datatrain" initialized
INFO - 2023-05-25 18:34:00 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 18:34:00 --> Model "m_datatest" initialized
INFO - 2023-05-25 18:34:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 18:34:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 18:34:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-05-25 18:34:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 18:34:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 18:34:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 18:34:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 18:34:00 --> Final output sent to browser
INFO - 2023-05-25 20:55:53 --> Config Class Initialized
INFO - 2023-05-25 20:55:53 --> Hooks Class Initialized
INFO - 2023-05-25 20:55:53 --> Utf8 Class Initialized
INFO - 2023-05-25 20:55:53 --> URI Class Initialized
INFO - 2023-05-25 20:55:53 --> Router Class Initialized
INFO - 2023-05-25 20:55:53 --> Output Class Initialized
INFO - 2023-05-25 20:55:53 --> Security Class Initialized
INFO - 2023-05-25 20:55:53 --> Input Class Initialized
INFO - 2023-05-25 20:55:53 --> Language Class Initialized
INFO - 2023-05-25 20:55:53 --> Loader Class Initialized
INFO - 2023-05-25 20:55:53 --> Helper loaded: url_helper
INFO - 2023-05-25 20:55:53 --> Helper loaded: form_helper
INFO - 2023-05-25 20:55:53 --> Database Driver Class Initialized
INFO - 2023-05-25 20:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 20:55:53 --> Form Validation Class Initialized
INFO - 2023-05-25 20:55:53 --> Controller Class Initialized
INFO - 2023-05-25 20:55:53 --> Model "m_datatest" initialized
INFO - 2023-05-25 20:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 20:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 20:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-25 20:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 20:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 20:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 20:55:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 20:55:53 --> Final output sent to browser
INFO - 2023-05-25 20:55:57 --> Config Class Initialized
INFO - 2023-05-25 20:55:57 --> Hooks Class Initialized
INFO - 2023-05-25 20:55:57 --> Utf8 Class Initialized
INFO - 2023-05-25 20:55:57 --> URI Class Initialized
INFO - 2023-05-25 20:55:57 --> Router Class Initialized
INFO - 2023-05-25 20:55:57 --> Output Class Initialized
INFO - 2023-05-25 20:55:57 --> Security Class Initialized
INFO - 2023-05-25 20:55:57 --> Input Class Initialized
INFO - 2023-05-25 20:55:57 --> Language Class Initialized
INFO - 2023-05-25 20:55:57 --> Loader Class Initialized
INFO - 2023-05-25 20:55:57 --> Helper loaded: url_helper
INFO - 2023-05-25 20:55:57 --> Helper loaded: form_helper
INFO - 2023-05-25 20:55:57 --> Database Driver Class Initialized
INFO - 2023-05-25 20:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 20:55:57 --> Form Validation Class Initialized
INFO - 2023-05-25 20:55:57 --> Controller Class Initialized
INFO - 2023-05-25 20:55:57 --> Model "m_datatest" initialized
INFO - 2023-05-25 20:55:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 20:55:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 20:55:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-25 20:55:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 20:55:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 20:55:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 20:55:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 20:55:57 --> Final output sent to browser
INFO - 2023-05-25 20:56:00 --> Config Class Initialized
INFO - 2023-05-25 20:56:00 --> Hooks Class Initialized
INFO - 2023-05-25 20:56:00 --> Utf8 Class Initialized
INFO - 2023-05-25 20:56:00 --> URI Class Initialized
INFO - 2023-05-25 20:56:00 --> Router Class Initialized
INFO - 2023-05-25 20:56:00 --> Output Class Initialized
INFO - 2023-05-25 20:56:00 --> Security Class Initialized
INFO - 2023-05-25 20:56:00 --> Input Class Initialized
INFO - 2023-05-25 20:56:00 --> Language Class Initialized
INFO - 2023-05-25 20:56:00 --> Loader Class Initialized
INFO - 2023-05-25 20:56:00 --> Helper loaded: url_helper
INFO - 2023-05-25 20:56:00 --> Helper loaded: form_helper
INFO - 2023-05-25 20:56:00 --> Database Driver Class Initialized
INFO - 2023-05-25 20:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 20:56:00 --> Form Validation Class Initialized
INFO - 2023-05-25 20:56:00 --> Controller Class Initialized
INFO - 2023-05-25 20:56:00 --> Model "m_user" initialized
INFO - 2023-05-25 20:56:00 --> Config Class Initialized
INFO - 2023-05-25 20:56:00 --> Hooks Class Initialized
INFO - 2023-05-25 20:56:00 --> Utf8 Class Initialized
INFO - 2023-05-25 20:56:00 --> URI Class Initialized
INFO - 2023-05-25 20:56:00 --> Router Class Initialized
INFO - 2023-05-25 20:56:00 --> Output Class Initialized
INFO - 2023-05-25 20:56:00 --> Security Class Initialized
INFO - 2023-05-25 20:56:00 --> Input Class Initialized
INFO - 2023-05-25 20:56:00 --> Language Class Initialized
INFO - 2023-05-25 20:56:00 --> Loader Class Initialized
INFO - 2023-05-25 20:56:00 --> Helper loaded: url_helper
INFO - 2023-05-25 20:56:00 --> Helper loaded: form_helper
INFO - 2023-05-25 20:56:00 --> Database Driver Class Initialized
INFO - 2023-05-25 20:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 20:56:00 --> Form Validation Class Initialized
INFO - 2023-05-25 20:56:00 --> Controller Class Initialized
INFO - 2023-05-25 20:56:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-25 20:56:00 --> Final output sent to browser
INFO - 2023-05-25 20:56:01 --> Config Class Initialized
INFO - 2023-05-25 20:56:01 --> Hooks Class Initialized
INFO - 2023-05-25 20:56:01 --> Utf8 Class Initialized
INFO - 2023-05-25 20:56:01 --> URI Class Initialized
INFO - 2023-05-25 20:56:01 --> Router Class Initialized
INFO - 2023-05-25 20:56:01 --> Output Class Initialized
INFO - 2023-05-25 20:56:01 --> Security Class Initialized
INFO - 2023-05-25 20:56:01 --> Input Class Initialized
INFO - 2023-05-25 20:56:01 --> Language Class Initialized
INFO - 2023-05-25 20:56:01 --> Loader Class Initialized
INFO - 2023-05-25 20:56:01 --> Helper loaded: url_helper
INFO - 2023-05-25 20:56:01 --> Helper loaded: form_helper
INFO - 2023-05-25 20:56:01 --> Database Driver Class Initialized
INFO - 2023-05-25 20:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 20:56:01 --> Form Validation Class Initialized
INFO - 2023-05-25 20:56:01 --> Controller Class Initialized
INFO - 2023-05-25 20:56:01 --> Model "m_user" initialized
INFO - 2023-05-25 20:56:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-25 20:56:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-25 20:56:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-25 20:56:01 --> Final output sent to browser
INFO - 2023-05-25 20:56:04 --> Config Class Initialized
INFO - 2023-05-25 20:56:04 --> Hooks Class Initialized
INFO - 2023-05-25 20:56:04 --> Utf8 Class Initialized
INFO - 2023-05-25 20:56:04 --> URI Class Initialized
INFO - 2023-05-25 20:56:04 --> Router Class Initialized
INFO - 2023-05-25 20:56:04 --> Output Class Initialized
INFO - 2023-05-25 20:56:04 --> Security Class Initialized
INFO - 2023-05-25 20:56:04 --> Input Class Initialized
INFO - 2023-05-25 20:56:04 --> Language Class Initialized
INFO - 2023-05-25 20:56:04 --> Loader Class Initialized
INFO - 2023-05-25 20:56:04 --> Helper loaded: url_helper
INFO - 2023-05-25 20:56:04 --> Helper loaded: form_helper
INFO - 2023-05-25 20:56:04 --> Database Driver Class Initialized
INFO - 2023-05-25 20:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 20:56:04 --> Form Validation Class Initialized
INFO - 2023-05-25 20:56:04 --> Controller Class Initialized
INFO - 2023-05-25 20:56:04 --> Model "m_user" initialized
INFO - 2023-05-25 20:56:05 --> Config Class Initialized
INFO - 2023-05-25 20:56:05 --> Hooks Class Initialized
INFO - 2023-05-25 20:56:05 --> Utf8 Class Initialized
INFO - 2023-05-25 20:56:05 --> URI Class Initialized
INFO - 2023-05-25 20:56:05 --> Router Class Initialized
INFO - 2023-05-25 20:56:05 --> Output Class Initialized
INFO - 2023-05-25 20:56:05 --> Security Class Initialized
INFO - 2023-05-25 20:56:05 --> Input Class Initialized
INFO - 2023-05-25 20:56:05 --> Language Class Initialized
INFO - 2023-05-25 20:56:05 --> Loader Class Initialized
INFO - 2023-05-25 20:56:05 --> Helper loaded: url_helper
INFO - 2023-05-25 20:56:05 --> Helper loaded: form_helper
INFO - 2023-05-25 20:56:05 --> Database Driver Class Initialized
INFO - 2023-05-25 20:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 20:56:05 --> Form Validation Class Initialized
INFO - 2023-05-25 20:56:05 --> Controller Class Initialized
INFO - 2023-05-25 20:56:05 --> Model "m_user" initialized
INFO - 2023-05-25 20:56:05 --> Model "m_datatrain" initialized
INFO - 2023-05-25 20:56:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 20:56:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 20:56:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 20:56:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 20:56:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 20:56:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-25 20:56:05 --> Final output sent to browser
INFO - 2023-05-25 20:56:08 --> Config Class Initialized
INFO - 2023-05-25 20:56:08 --> Hooks Class Initialized
INFO - 2023-05-25 20:56:08 --> Utf8 Class Initialized
INFO - 2023-05-25 20:56:08 --> URI Class Initialized
INFO - 2023-05-25 20:56:08 --> Router Class Initialized
INFO - 2023-05-25 20:56:08 --> Output Class Initialized
INFO - 2023-05-25 20:56:08 --> Security Class Initialized
INFO - 2023-05-25 20:56:08 --> Input Class Initialized
INFO - 2023-05-25 20:56:08 --> Language Class Initialized
INFO - 2023-05-25 20:56:08 --> Loader Class Initialized
INFO - 2023-05-25 20:56:08 --> Helper loaded: url_helper
INFO - 2023-05-25 20:56:08 --> Helper loaded: form_helper
INFO - 2023-05-25 20:56:08 --> Database Driver Class Initialized
INFO - 2023-05-25 20:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 20:56:08 --> Form Validation Class Initialized
INFO - 2023-05-25 20:56:08 --> Controller Class Initialized
INFO - 2023-05-25 20:56:08 --> Model "m_datatest" initialized
INFO - 2023-05-25 20:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 20:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 20:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-25 20:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 20:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 20:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 20:56:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 20:56:08 --> Final output sent to browser
INFO - 2023-05-25 20:56:09 --> Config Class Initialized
INFO - 2023-05-25 20:56:09 --> Hooks Class Initialized
INFO - 2023-05-25 20:56:09 --> Utf8 Class Initialized
INFO - 2023-05-25 20:56:09 --> URI Class Initialized
INFO - 2023-05-25 20:56:09 --> Router Class Initialized
INFO - 2023-05-25 20:56:09 --> Output Class Initialized
INFO - 2023-05-25 20:56:09 --> Security Class Initialized
INFO - 2023-05-25 20:56:09 --> Input Class Initialized
INFO - 2023-05-25 20:56:09 --> Language Class Initialized
INFO - 2023-05-25 20:56:09 --> Loader Class Initialized
INFO - 2023-05-25 20:56:09 --> Helper loaded: url_helper
INFO - 2023-05-25 20:56:09 --> Helper loaded: form_helper
INFO - 2023-05-25 20:56:09 --> Database Driver Class Initialized
INFO - 2023-05-25 20:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 20:56:09 --> Form Validation Class Initialized
INFO - 2023-05-25 20:56:09 --> Controller Class Initialized
INFO - 2023-05-25 20:56:09 --> Model "m_datatest" initialized
INFO - 2023-05-25 20:56:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 20:56:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 20:56:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-05-25 20:56:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 20:56:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 20:56:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 20:56:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 20:56:09 --> Final output sent to browser
INFO - 2023-05-25 20:56:11 --> Config Class Initialized
INFO - 2023-05-25 20:56:11 --> Hooks Class Initialized
INFO - 2023-05-25 20:56:11 --> Utf8 Class Initialized
INFO - 2023-05-25 20:56:11 --> URI Class Initialized
INFO - 2023-05-25 20:56:11 --> Router Class Initialized
INFO - 2023-05-25 20:56:11 --> Output Class Initialized
INFO - 2023-05-25 20:56:11 --> Security Class Initialized
INFO - 2023-05-25 20:56:11 --> Input Class Initialized
INFO - 2023-05-25 20:56:11 --> Language Class Initialized
INFO - 2023-05-25 20:56:11 --> Loader Class Initialized
INFO - 2023-05-25 20:56:11 --> Helper loaded: url_helper
INFO - 2023-05-25 20:56:11 --> Helper loaded: form_helper
INFO - 2023-05-25 20:56:11 --> Database Driver Class Initialized
INFO - 2023-05-25 20:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 20:56:11 --> Form Validation Class Initialized
INFO - 2023-05-25 20:56:11 --> Controller Class Initialized
INFO - 2023-05-25 20:56:11 --> Model "m_datatrain" initialized
INFO - 2023-05-25 20:56:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 20:56:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 20:56:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-25 20:56:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 20:56:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 20:56:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 20:56:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 20:56:11 --> Final output sent to browser
INFO - 2023-05-25 21:03:10 --> Config Class Initialized
INFO - 2023-05-25 21:03:10 --> Hooks Class Initialized
INFO - 2023-05-25 21:03:10 --> Utf8 Class Initialized
INFO - 2023-05-25 21:03:10 --> URI Class Initialized
INFO - 2023-05-25 21:03:10 --> Router Class Initialized
INFO - 2023-05-25 21:03:10 --> Output Class Initialized
INFO - 2023-05-25 21:03:10 --> Security Class Initialized
INFO - 2023-05-25 21:03:10 --> Input Class Initialized
INFO - 2023-05-25 21:03:10 --> Language Class Initialized
INFO - 2023-05-25 21:03:10 --> Loader Class Initialized
INFO - 2023-05-25 21:03:10 --> Helper loaded: url_helper
INFO - 2023-05-25 21:03:10 --> Helper loaded: form_helper
INFO - 2023-05-25 21:03:10 --> Database Driver Class Initialized
INFO - 2023-05-25 21:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 21:03:10 --> Form Validation Class Initialized
INFO - 2023-05-25 21:03:10 --> Controller Class Initialized
INFO - 2023-05-25 21:03:10 --> Model "m_user" initialized
INFO - 2023-05-25 21:03:10 --> Config Class Initialized
INFO - 2023-05-25 21:03:10 --> Hooks Class Initialized
INFO - 2023-05-25 21:03:10 --> Utf8 Class Initialized
INFO - 2023-05-25 21:03:10 --> URI Class Initialized
INFO - 2023-05-25 21:03:10 --> Router Class Initialized
INFO - 2023-05-25 21:03:10 --> Output Class Initialized
INFO - 2023-05-25 21:03:10 --> Security Class Initialized
INFO - 2023-05-25 21:03:10 --> Input Class Initialized
INFO - 2023-05-25 21:03:10 --> Language Class Initialized
INFO - 2023-05-25 21:03:10 --> Loader Class Initialized
INFO - 2023-05-25 21:03:10 --> Helper loaded: url_helper
INFO - 2023-05-25 21:03:10 --> Helper loaded: form_helper
INFO - 2023-05-25 21:03:10 --> Database Driver Class Initialized
INFO - 2023-05-25 21:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 21:03:10 --> Form Validation Class Initialized
INFO - 2023-05-25 21:03:10 --> Controller Class Initialized
INFO - 2023-05-25 21:03:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-25 21:03:10 --> Final output sent to browser
INFO - 2023-05-25 21:03:12 --> Config Class Initialized
INFO - 2023-05-25 21:03:12 --> Hooks Class Initialized
INFO - 2023-05-25 21:03:12 --> Utf8 Class Initialized
INFO - 2023-05-25 21:03:12 --> URI Class Initialized
INFO - 2023-05-25 21:03:12 --> Router Class Initialized
INFO - 2023-05-25 21:03:12 --> Output Class Initialized
INFO - 2023-05-25 21:03:12 --> Security Class Initialized
INFO - 2023-05-25 21:03:12 --> Input Class Initialized
INFO - 2023-05-25 21:03:12 --> Language Class Initialized
INFO - 2023-05-25 21:03:12 --> Loader Class Initialized
INFO - 2023-05-25 21:03:12 --> Helper loaded: url_helper
INFO - 2023-05-25 21:03:12 --> Helper loaded: form_helper
INFO - 2023-05-25 21:03:12 --> Database Driver Class Initialized
INFO - 2023-05-25 21:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 21:03:12 --> Form Validation Class Initialized
INFO - 2023-05-25 21:03:12 --> Controller Class Initialized
INFO - 2023-05-25 21:03:12 --> Model "m_user" initialized
INFO - 2023-05-25 21:03:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 21:03:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 21:03:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-25 21:03:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 21:03:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 21:03:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-25 21:03:12 --> Final output sent to browser
INFO - 2023-05-25 21:03:16 --> Config Class Initialized
INFO - 2023-05-25 21:03:16 --> Hooks Class Initialized
INFO - 2023-05-25 21:03:16 --> Utf8 Class Initialized
INFO - 2023-05-25 21:03:16 --> URI Class Initialized
INFO - 2023-05-25 21:03:16 --> Router Class Initialized
INFO - 2023-05-25 21:03:16 --> Output Class Initialized
INFO - 2023-05-25 21:03:16 --> Security Class Initialized
INFO - 2023-05-25 21:03:16 --> Input Class Initialized
INFO - 2023-05-25 21:03:16 --> Language Class Initialized
INFO - 2023-05-25 21:03:16 --> Loader Class Initialized
INFO - 2023-05-25 21:03:16 --> Helper loaded: url_helper
INFO - 2023-05-25 21:03:16 --> Helper loaded: form_helper
INFO - 2023-05-25 21:03:16 --> Database Driver Class Initialized
INFO - 2023-05-25 21:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 21:03:16 --> Form Validation Class Initialized
INFO - 2023-05-25 21:03:16 --> Controller Class Initialized
INFO - 2023-05-25 21:03:16 --> Model "m_datatrain" initialized
INFO - 2023-05-25 21:03:16 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 21:03:16 --> Model "m_datatest" initialized
INFO - 2023-05-25 21:03:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 21:03:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 21:03:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-25 21:03:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-25 21:03:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 21:03:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 21:03:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-25 21:03:16 --> Final output sent to browser
INFO - 2023-05-25 21:04:05 --> Config Class Initialized
INFO - 2023-05-25 21:04:05 --> Hooks Class Initialized
INFO - 2023-05-25 21:04:05 --> Utf8 Class Initialized
INFO - 2023-05-25 21:04:05 --> URI Class Initialized
INFO - 2023-05-25 21:04:05 --> Router Class Initialized
INFO - 2023-05-25 21:04:05 --> Output Class Initialized
INFO - 2023-05-25 21:04:05 --> Security Class Initialized
INFO - 2023-05-25 21:04:05 --> Input Class Initialized
INFO - 2023-05-25 21:04:05 --> Language Class Initialized
INFO - 2023-05-25 21:04:05 --> Loader Class Initialized
INFO - 2023-05-25 21:04:05 --> Helper loaded: url_helper
INFO - 2023-05-25 21:04:05 --> Helper loaded: form_helper
INFO - 2023-05-25 21:04:05 --> Database Driver Class Initialized
INFO - 2023-05-25 21:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 21:04:05 --> Form Validation Class Initialized
INFO - 2023-05-25 21:04:05 --> Controller Class Initialized
INFO - 2023-05-25 21:04:05 --> Model "m_datatrain" initialized
INFO - 2023-05-25 21:04:05 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 21:04:05 --> Model "m_datatest" initialized
INFO - 2023-05-25 21:04:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 21:04:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-25 21:04:05 --> Severity: Notice --> Undefined variable: HasilGangguanMood C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 22
ERROR - 2023-05-25 21:04:05 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 22
ERROR - 2023-05-25 21:04:05 --> Severity: Notice --> Undefined variable: HasilRingan C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 23
ERROR - 2023-05-25 21:04:05 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 23
ERROR - 2023-05-25 21:04:05 --> Severity: Notice --> Undefined variable: HasilSedang C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 24
ERROR - 2023-05-25 21:04:05 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 24
ERROR - 2023-05-25 21:04:05 --> Severity: Notice --> Undefined variable: HasilBerat C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 25
ERROR - 2023-05-25 21:04:05 --> Severity: Notice --> Undefined variable: All C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa\V_hasil.php 25
INFO - 2023-05-25 21:04:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-25 21:04:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 21:04:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 21:04:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 21:04:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 21:04:05 --> Final output sent to browser
INFO - 2023-05-25 21:04:24 --> Config Class Initialized
INFO - 2023-05-25 21:04:24 --> Hooks Class Initialized
INFO - 2023-05-25 21:04:24 --> Utf8 Class Initialized
INFO - 2023-05-25 21:04:24 --> URI Class Initialized
INFO - 2023-05-25 21:04:24 --> Router Class Initialized
INFO - 2023-05-25 21:04:24 --> Output Class Initialized
INFO - 2023-05-25 21:04:24 --> Security Class Initialized
INFO - 2023-05-25 21:04:24 --> Input Class Initialized
INFO - 2023-05-25 21:04:24 --> Language Class Initialized
INFO - 2023-05-25 21:04:25 --> Loader Class Initialized
INFO - 2023-05-25 21:04:25 --> Helper loaded: url_helper
INFO - 2023-05-25 21:04:25 --> Helper loaded: form_helper
INFO - 2023-05-25 21:04:25 --> Database Driver Class Initialized
INFO - 2023-05-25 21:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 21:04:25 --> Form Validation Class Initialized
INFO - 2023-05-25 21:04:25 --> Controller Class Initialized
INFO - 2023-05-25 21:04:25 --> Model "m_datatrain" initialized
INFO - 2023-05-25 21:04:25 --> Model "m_penghitungan" initialized
INFO - 2023-05-25 21:04:25 --> Model "m_datatest" initialized
INFO - 2023-05-25 21:04:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-25 21:04:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-25 21:04:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-05-25 21:04:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-25 21:04:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-25 21:04:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-25 21:04:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-25 21:04:25 --> Final output sent to browser
