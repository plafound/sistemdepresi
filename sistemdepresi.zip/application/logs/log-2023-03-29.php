<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-29 12:24:33 --> Config Class Initialized
INFO - 2023-03-29 12:24:33 --> Hooks Class Initialized
INFO - 2023-03-29 12:24:33 --> Utf8 Class Initialized
INFO - 2023-03-29 12:24:33 --> URI Class Initialized
INFO - 2023-03-29 12:24:33 --> Router Class Initialized
INFO - 2023-03-29 12:24:33 --> Output Class Initialized
INFO - 2023-03-29 12:24:33 --> Security Class Initialized
INFO - 2023-03-29 12:24:33 --> Input Class Initialized
INFO - 2023-03-29 12:24:33 --> Language Class Initialized
INFO - 2023-03-29 12:24:33 --> Loader Class Initialized
INFO - 2023-03-29 12:24:33 --> Helper loaded: url_helper
INFO - 2023-03-29 12:24:33 --> Helper loaded: form_helper
INFO - 2023-03-29 12:24:33 --> Database Driver Class Initialized
INFO - 2023-03-29 12:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 12:24:34 --> Form Validation Class Initialized
INFO - 2023-03-29 12:24:34 --> Controller Class Initialized
INFO - 2023-03-29 12:24:34 --> Model "M_tutor" initialized
INFO - 2023-03-29 12:24:34 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_header.php
INFO - 2023-03-29 12:24:34 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\auth/login.php
INFO - 2023-03-29 12:24:34 --> File loaded: C:\xampp\htdocs\lisa-todo\application\views\templates/auth_footer.php
INFO - 2023-03-29 12:24:34 --> Final output sent to browser
