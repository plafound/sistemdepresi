<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-07 03:06:38 --> Config Class Initialized
INFO - 2023-06-07 03:06:38 --> Hooks Class Initialized
INFO - 2023-06-07 03:06:38 --> Utf8 Class Initialized
INFO - 2023-06-07 03:06:38 --> URI Class Initialized
INFO - 2023-06-07 03:06:38 --> Router Class Initialized
INFO - 2023-06-07 03:06:38 --> Output Class Initialized
INFO - 2023-06-07 03:06:38 --> Security Class Initialized
INFO - 2023-06-07 03:06:38 --> Input Class Initialized
INFO - 2023-06-07 03:06:38 --> Language Class Initialized
INFO - 2023-06-07 03:06:38 --> Loader Class Initialized
INFO - 2023-06-07 03:06:38 --> Helper loaded: url_helper
INFO - 2023-06-07 03:06:38 --> Helper loaded: form_helper
INFO - 2023-06-07 03:06:38 --> Database Driver Class Initialized
INFO - 2023-06-07 03:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:06:38 --> Form Validation Class Initialized
INFO - 2023-06-07 03:06:38 --> Controller Class Initialized
INFO - 2023-06-07 03:06:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-07 03:06:38 --> Final output sent to browser
INFO - 2023-06-07 03:06:41 --> Config Class Initialized
INFO - 2023-06-07 03:06:41 --> Hooks Class Initialized
INFO - 2023-06-07 03:06:41 --> Utf8 Class Initialized
INFO - 2023-06-07 03:06:41 --> URI Class Initialized
INFO - 2023-06-07 03:06:41 --> Router Class Initialized
INFO - 2023-06-07 03:06:41 --> Output Class Initialized
INFO - 2023-06-07 03:06:41 --> Security Class Initialized
INFO - 2023-06-07 03:06:41 --> Input Class Initialized
INFO - 2023-06-07 03:06:41 --> Language Class Initialized
INFO - 2023-06-07 03:06:41 --> Loader Class Initialized
INFO - 2023-06-07 03:06:41 --> Helper loaded: url_helper
INFO - 2023-06-07 03:06:41 --> Helper loaded: form_helper
INFO - 2023-06-07 03:06:41 --> Database Driver Class Initialized
INFO - 2023-06-07 03:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:06:41 --> Form Validation Class Initialized
INFO - 2023-06-07 03:06:41 --> Controller Class Initialized
INFO - 2023-06-07 03:06:41 --> Model "m_user" initialized
INFO - 2023-06-07 03:06:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-07 03:06:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-07 03:06:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-07 03:06:41 --> Final output sent to browser
INFO - 2023-06-07 03:06:45 --> Config Class Initialized
INFO - 2023-06-07 03:06:45 --> Hooks Class Initialized
INFO - 2023-06-07 03:06:45 --> Utf8 Class Initialized
INFO - 2023-06-07 03:06:45 --> URI Class Initialized
INFO - 2023-06-07 03:06:45 --> Router Class Initialized
INFO - 2023-06-07 03:06:45 --> Output Class Initialized
INFO - 2023-06-07 03:06:45 --> Security Class Initialized
INFO - 2023-06-07 03:06:45 --> Input Class Initialized
INFO - 2023-06-07 03:06:45 --> Language Class Initialized
INFO - 2023-06-07 03:06:45 --> Loader Class Initialized
INFO - 2023-06-07 03:06:45 --> Helper loaded: url_helper
INFO - 2023-06-07 03:06:45 --> Helper loaded: form_helper
INFO - 2023-06-07 03:06:45 --> Database Driver Class Initialized
INFO - 2023-06-07 03:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:06:45 --> Form Validation Class Initialized
INFO - 2023-06-07 03:06:45 --> Controller Class Initialized
INFO - 2023-06-07 03:06:45 --> Model "m_user" initialized
INFO - 2023-06-07 03:06:46 --> Config Class Initialized
INFO - 2023-06-07 03:06:46 --> Hooks Class Initialized
INFO - 2023-06-07 03:06:46 --> Utf8 Class Initialized
INFO - 2023-06-07 03:06:46 --> URI Class Initialized
INFO - 2023-06-07 03:06:46 --> Router Class Initialized
INFO - 2023-06-07 03:06:46 --> Output Class Initialized
INFO - 2023-06-07 03:06:46 --> Security Class Initialized
INFO - 2023-06-07 03:06:46 --> Input Class Initialized
INFO - 2023-06-07 03:06:46 --> Language Class Initialized
INFO - 2023-06-07 03:06:46 --> Loader Class Initialized
INFO - 2023-06-07 03:06:46 --> Helper loaded: url_helper
INFO - 2023-06-07 03:06:46 --> Helper loaded: form_helper
INFO - 2023-06-07 03:06:46 --> Database Driver Class Initialized
INFO - 2023-06-07 03:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:06:46 --> Form Validation Class Initialized
INFO - 2023-06-07 03:06:46 --> Controller Class Initialized
INFO - 2023-06-07 03:06:46 --> Model "m_user" initialized
INFO - 2023-06-07 03:06:46 --> Model "m_datatrain" initialized
INFO - 2023-06-07 03:06:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:06:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:06:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:06:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:06:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:06:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-07 03:06:46 --> Final output sent to browser
INFO - 2023-06-07 03:06:48 --> Config Class Initialized
INFO - 2023-06-07 03:06:48 --> Hooks Class Initialized
INFO - 2023-06-07 03:06:48 --> Utf8 Class Initialized
INFO - 2023-06-07 03:06:48 --> URI Class Initialized
INFO - 2023-06-07 03:06:48 --> Router Class Initialized
INFO - 2023-06-07 03:06:48 --> Output Class Initialized
INFO - 2023-06-07 03:06:48 --> Security Class Initialized
INFO - 2023-06-07 03:06:48 --> Input Class Initialized
INFO - 2023-06-07 03:06:48 --> Language Class Initialized
INFO - 2023-06-07 03:06:48 --> Loader Class Initialized
INFO - 2023-06-07 03:06:48 --> Helper loaded: url_helper
INFO - 2023-06-07 03:06:48 --> Helper loaded: form_helper
INFO - 2023-06-07 03:06:48 --> Database Driver Class Initialized
INFO - 2023-06-07 03:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:06:48 --> Form Validation Class Initialized
INFO - 2023-06-07 03:06:48 --> Controller Class Initialized
INFO - 2023-06-07 03:06:48 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:06:48 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:06:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:06:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:06:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 03:06:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:06:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:06:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:06:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:06:48 --> Final output sent to browser
INFO - 2023-06-07 03:06:57 --> Config Class Initialized
INFO - 2023-06-07 03:06:57 --> Hooks Class Initialized
INFO - 2023-06-07 03:06:57 --> Utf8 Class Initialized
INFO - 2023-06-07 03:06:57 --> URI Class Initialized
INFO - 2023-06-07 03:06:57 --> Router Class Initialized
INFO - 2023-06-07 03:06:57 --> Output Class Initialized
INFO - 2023-06-07 03:06:57 --> Security Class Initialized
INFO - 2023-06-07 03:06:57 --> Input Class Initialized
INFO - 2023-06-07 03:06:57 --> Language Class Initialized
INFO - 2023-06-07 03:06:57 --> Loader Class Initialized
INFO - 2023-06-07 03:06:57 --> Helper loaded: url_helper
INFO - 2023-06-07 03:06:57 --> Helper loaded: form_helper
INFO - 2023-06-07 03:06:57 --> Database Driver Class Initialized
INFO - 2023-06-07 03:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:06:57 --> Form Validation Class Initialized
INFO - 2023-06-07 03:06:57 --> Controller Class Initialized
INFO - 2023-06-07 03:06:57 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:06:57 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:06:57 --> Config Class Initialized
INFO - 2023-06-07 03:06:57 --> Hooks Class Initialized
INFO - 2023-06-07 03:06:57 --> Utf8 Class Initialized
INFO - 2023-06-07 03:06:57 --> URI Class Initialized
INFO - 2023-06-07 03:06:57 --> Router Class Initialized
INFO - 2023-06-07 03:06:57 --> Output Class Initialized
INFO - 2023-06-07 03:06:57 --> Security Class Initialized
INFO - 2023-06-07 03:06:57 --> Input Class Initialized
INFO - 2023-06-07 03:06:57 --> Language Class Initialized
INFO - 2023-06-07 03:06:57 --> Loader Class Initialized
INFO - 2023-06-07 03:06:57 --> Helper loaded: url_helper
INFO - 2023-06-07 03:06:57 --> Helper loaded: form_helper
INFO - 2023-06-07 03:06:57 --> Database Driver Class Initialized
INFO - 2023-06-07 03:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:06:57 --> Form Validation Class Initialized
INFO - 2023-06-07 03:06:57 --> Controller Class Initialized
INFO - 2023-06-07 03:06:57 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:06:57 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:06:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:06:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:06:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 03:06:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:06:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:06:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:06:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:06:57 --> Final output sent to browser
INFO - 2023-06-07 03:06:59 --> Config Class Initialized
INFO - 2023-06-07 03:06:59 --> Hooks Class Initialized
INFO - 2023-06-07 03:06:59 --> Utf8 Class Initialized
INFO - 2023-06-07 03:06:59 --> URI Class Initialized
INFO - 2023-06-07 03:06:59 --> Router Class Initialized
INFO - 2023-06-07 03:06:59 --> Output Class Initialized
INFO - 2023-06-07 03:06:59 --> Security Class Initialized
INFO - 2023-06-07 03:06:59 --> Input Class Initialized
INFO - 2023-06-07 03:06:59 --> Language Class Initialized
INFO - 2023-06-07 03:06:59 --> Loader Class Initialized
INFO - 2023-06-07 03:06:59 --> Helper loaded: url_helper
INFO - 2023-06-07 03:06:59 --> Helper loaded: form_helper
INFO - 2023-06-07 03:06:59 --> Database Driver Class Initialized
INFO - 2023-06-07 03:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:06:59 --> Form Validation Class Initialized
INFO - 2023-06-07 03:06:59 --> Controller Class Initialized
INFO - 2023-06-07 03:06:59 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:06:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:07:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:07:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:07:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 03:07:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:07:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:07:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:07:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:07:00 --> Final output sent to browser
INFO - 2023-06-07 03:07:55 --> Config Class Initialized
INFO - 2023-06-07 03:07:55 --> Hooks Class Initialized
INFO - 2023-06-07 03:07:55 --> Utf8 Class Initialized
INFO - 2023-06-07 03:07:55 --> URI Class Initialized
INFO - 2023-06-07 03:07:55 --> Router Class Initialized
INFO - 2023-06-07 03:07:55 --> Output Class Initialized
INFO - 2023-06-07 03:07:55 --> Security Class Initialized
INFO - 2023-06-07 03:07:55 --> Input Class Initialized
INFO - 2023-06-07 03:07:55 --> Language Class Initialized
INFO - 2023-06-07 03:07:55 --> Loader Class Initialized
INFO - 2023-06-07 03:07:55 --> Helper loaded: url_helper
INFO - 2023-06-07 03:07:55 --> Helper loaded: form_helper
INFO - 2023-06-07 03:07:55 --> Database Driver Class Initialized
INFO - 2023-06-07 03:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:07:55 --> Form Validation Class Initialized
INFO - 2023-06-07 03:07:55 --> Controller Class Initialized
INFO - 2023-06-07 03:07:55 --> Model "m_datatrain" initialized
INFO - 2023-06-07 03:07:55 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:07:55 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:07:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:07:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:07:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-06-07 03:07:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:07:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:07:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:07:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:07:55 --> Final output sent to browser
INFO - 2023-06-07 03:10:17 --> Config Class Initialized
INFO - 2023-06-07 03:10:17 --> Hooks Class Initialized
INFO - 2023-06-07 03:10:17 --> Utf8 Class Initialized
INFO - 2023-06-07 03:10:17 --> URI Class Initialized
INFO - 2023-06-07 03:10:17 --> Router Class Initialized
INFO - 2023-06-07 03:10:17 --> Output Class Initialized
INFO - 2023-06-07 03:10:17 --> Security Class Initialized
INFO - 2023-06-07 03:10:17 --> Input Class Initialized
INFO - 2023-06-07 03:10:17 --> Language Class Initialized
INFO - 2023-06-07 03:10:17 --> Loader Class Initialized
INFO - 2023-06-07 03:10:17 --> Helper loaded: url_helper
INFO - 2023-06-07 03:10:17 --> Helper loaded: form_helper
INFO - 2023-06-07 03:10:17 --> Database Driver Class Initialized
INFO - 2023-06-07 03:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:10:17 --> Form Validation Class Initialized
INFO - 2023-06-07 03:10:17 --> Controller Class Initialized
INFO - 2023-06-07 03:10:17 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:10:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 03:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:10:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:10:17 --> Final output sent to browser
INFO - 2023-06-07 03:10:18 --> Config Class Initialized
INFO - 2023-06-07 03:10:18 --> Hooks Class Initialized
INFO - 2023-06-07 03:10:18 --> Utf8 Class Initialized
INFO - 2023-06-07 03:10:18 --> URI Class Initialized
INFO - 2023-06-07 03:10:18 --> Router Class Initialized
INFO - 2023-06-07 03:10:18 --> Output Class Initialized
INFO - 2023-06-07 03:10:18 --> Security Class Initialized
INFO - 2023-06-07 03:10:18 --> Input Class Initialized
INFO - 2023-06-07 03:10:18 --> Language Class Initialized
INFO - 2023-06-07 03:10:18 --> Loader Class Initialized
INFO - 2023-06-07 03:10:18 --> Helper loaded: url_helper
INFO - 2023-06-07 03:10:18 --> Helper loaded: form_helper
INFO - 2023-06-07 03:10:18 --> Database Driver Class Initialized
INFO - 2023-06-07 03:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:10:18 --> Form Validation Class Initialized
INFO - 2023-06-07 03:10:18 --> Controller Class Initialized
INFO - 2023-06-07 03:10:18 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:10:18 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:10:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:10:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 03:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:10:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:10:19 --> Final output sent to browser
INFO - 2023-06-07 03:24:42 --> Config Class Initialized
INFO - 2023-06-07 03:24:42 --> Hooks Class Initialized
INFO - 2023-06-07 03:24:42 --> Utf8 Class Initialized
INFO - 2023-06-07 03:24:42 --> URI Class Initialized
INFO - 2023-06-07 03:24:42 --> Router Class Initialized
INFO - 2023-06-07 03:24:42 --> Output Class Initialized
INFO - 2023-06-07 03:24:42 --> Security Class Initialized
INFO - 2023-06-07 03:24:42 --> Input Class Initialized
INFO - 2023-06-07 03:24:42 --> Language Class Initialized
INFO - 2023-06-07 03:24:42 --> Loader Class Initialized
INFO - 2023-06-07 03:24:42 --> Helper loaded: url_helper
INFO - 2023-06-07 03:24:42 --> Helper loaded: form_helper
INFO - 2023-06-07 03:24:42 --> Database Driver Class Initialized
INFO - 2023-06-07 03:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:24:42 --> Form Validation Class Initialized
INFO - 2023-06-07 03:24:42 --> Controller Class Initialized
INFO - 2023-06-07 03:24:42 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:24:42 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:24:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:24:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:24:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 03:24:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:24:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:24:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:24:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:24:43 --> Final output sent to browser
INFO - 2023-06-07 03:32:14 --> Config Class Initialized
INFO - 2023-06-07 03:32:14 --> Hooks Class Initialized
INFO - 2023-06-07 03:32:15 --> Utf8 Class Initialized
INFO - 2023-06-07 03:32:15 --> URI Class Initialized
INFO - 2023-06-07 03:32:15 --> Router Class Initialized
INFO - 2023-06-07 03:32:15 --> Output Class Initialized
INFO - 2023-06-07 03:32:15 --> Security Class Initialized
INFO - 2023-06-07 03:32:15 --> Input Class Initialized
INFO - 2023-06-07 03:32:15 --> Language Class Initialized
INFO - 2023-06-07 03:32:15 --> Loader Class Initialized
INFO - 2023-06-07 03:32:15 --> Helper loaded: url_helper
INFO - 2023-06-07 03:32:15 --> Helper loaded: form_helper
INFO - 2023-06-07 03:32:15 --> Database Driver Class Initialized
INFO - 2023-06-07 03:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:32:15 --> Form Validation Class Initialized
INFO - 2023-06-07 03:32:15 --> Controller Class Initialized
INFO - 2023-06-07 03:32:15 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:32:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:32:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:32:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:32:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 03:32:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:32:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:32:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:32:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:32:15 --> Final output sent to browser
INFO - 2023-06-07 03:33:45 --> Config Class Initialized
INFO - 2023-06-07 03:33:45 --> Hooks Class Initialized
INFO - 2023-06-07 03:33:45 --> Utf8 Class Initialized
INFO - 2023-06-07 03:33:45 --> URI Class Initialized
INFO - 2023-06-07 03:33:45 --> Router Class Initialized
INFO - 2023-06-07 03:33:45 --> Output Class Initialized
INFO - 2023-06-07 03:33:45 --> Security Class Initialized
INFO - 2023-06-07 03:33:45 --> Input Class Initialized
INFO - 2023-06-07 03:33:45 --> Language Class Initialized
INFO - 2023-06-07 03:33:45 --> Loader Class Initialized
INFO - 2023-06-07 03:33:45 --> Helper loaded: url_helper
INFO - 2023-06-07 03:33:45 --> Helper loaded: form_helper
INFO - 2023-06-07 03:33:45 --> Database Driver Class Initialized
INFO - 2023-06-07 03:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:33:45 --> Form Validation Class Initialized
INFO - 2023-06-07 03:33:45 --> Controller Class Initialized
INFO - 2023-06-07 03:33:45 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:33:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:33:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:33:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:33:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 03:33:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:33:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:33:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:33:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:33:46 --> Final output sent to browser
INFO - 2023-06-07 03:34:51 --> Config Class Initialized
INFO - 2023-06-07 03:34:51 --> Hooks Class Initialized
INFO - 2023-06-07 03:34:51 --> Utf8 Class Initialized
INFO - 2023-06-07 03:34:51 --> URI Class Initialized
INFO - 2023-06-07 03:34:51 --> Router Class Initialized
INFO - 2023-06-07 03:34:51 --> Output Class Initialized
INFO - 2023-06-07 03:34:51 --> Security Class Initialized
INFO - 2023-06-07 03:34:51 --> Input Class Initialized
INFO - 2023-06-07 03:34:51 --> Language Class Initialized
INFO - 2023-06-07 03:34:51 --> Loader Class Initialized
INFO - 2023-06-07 03:34:51 --> Helper loaded: url_helper
INFO - 2023-06-07 03:34:51 --> Helper loaded: form_helper
INFO - 2023-06-07 03:34:51 --> Database Driver Class Initialized
INFO - 2023-06-07 03:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:34:51 --> Form Validation Class Initialized
INFO - 2023-06-07 03:34:51 --> Controller Class Initialized
INFO - 2023-06-07 03:34:51 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:34:51 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:34:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:34:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:34:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 03:34:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:34:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:34:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:34:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:34:52 --> Final output sent to browser
INFO - 2023-06-07 03:35:04 --> Config Class Initialized
INFO - 2023-06-07 03:35:04 --> Hooks Class Initialized
INFO - 2023-06-07 03:35:04 --> Utf8 Class Initialized
INFO - 2023-06-07 03:35:04 --> URI Class Initialized
INFO - 2023-06-07 03:35:04 --> Router Class Initialized
INFO - 2023-06-07 03:35:04 --> Output Class Initialized
INFO - 2023-06-07 03:35:04 --> Security Class Initialized
INFO - 2023-06-07 03:35:04 --> Input Class Initialized
INFO - 2023-06-07 03:35:04 --> Language Class Initialized
INFO - 2023-06-07 03:35:04 --> Loader Class Initialized
INFO - 2023-06-07 03:35:04 --> Helper loaded: url_helper
INFO - 2023-06-07 03:35:04 --> Helper loaded: form_helper
INFO - 2023-06-07 03:35:04 --> Database Driver Class Initialized
INFO - 2023-06-07 03:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:35:04 --> Form Validation Class Initialized
INFO - 2023-06-07 03:35:04 --> Controller Class Initialized
INFO - 2023-06-07 03:35:04 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:35:04 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:35:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:35:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:35:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 03:35:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:35:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:35:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:35:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:35:05 --> Final output sent to browser
INFO - 2023-06-07 03:35:33 --> Config Class Initialized
INFO - 2023-06-07 03:35:33 --> Hooks Class Initialized
INFO - 2023-06-07 03:35:33 --> Utf8 Class Initialized
INFO - 2023-06-07 03:35:33 --> URI Class Initialized
INFO - 2023-06-07 03:35:33 --> Router Class Initialized
INFO - 2023-06-07 03:35:33 --> Output Class Initialized
INFO - 2023-06-07 03:35:33 --> Security Class Initialized
INFO - 2023-06-07 03:35:33 --> Input Class Initialized
INFO - 2023-06-07 03:35:33 --> Language Class Initialized
INFO - 2023-06-07 03:35:33 --> Loader Class Initialized
INFO - 2023-06-07 03:35:33 --> Helper loaded: url_helper
INFO - 2023-06-07 03:35:33 --> Helper loaded: form_helper
INFO - 2023-06-07 03:35:33 --> Database Driver Class Initialized
INFO - 2023-06-07 03:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:35:33 --> Form Validation Class Initialized
INFO - 2023-06-07 03:35:33 --> Controller Class Initialized
INFO - 2023-06-07 03:35:33 --> Model "m_datatest" initialized
INFO - 2023-06-07 03:35:33 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 03:35:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 03:35:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 03:35:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 03:35:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 03:35:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 03:35:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 03:35:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 03:35:34 --> Final output sent to browser
INFO - 2023-06-07 04:51:49 --> Config Class Initialized
INFO - 2023-06-07 04:51:49 --> Hooks Class Initialized
INFO - 2023-06-07 04:51:50 --> Utf8 Class Initialized
INFO - 2023-06-07 04:51:50 --> URI Class Initialized
INFO - 2023-06-07 04:51:50 --> Router Class Initialized
INFO - 2023-06-07 04:51:50 --> Output Class Initialized
INFO - 2023-06-07 04:51:50 --> Security Class Initialized
INFO - 2023-06-07 04:51:50 --> Input Class Initialized
INFO - 2023-06-07 04:51:50 --> Language Class Initialized
INFO - 2023-06-07 04:51:50 --> Loader Class Initialized
INFO - 2023-06-07 04:51:50 --> Helper loaded: url_helper
INFO - 2023-06-07 04:51:50 --> Helper loaded: form_helper
INFO - 2023-06-07 04:51:50 --> Database Driver Class Initialized
INFO - 2023-06-07 04:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:51:50 --> Form Validation Class Initialized
INFO - 2023-06-07 04:51:50 --> Controller Class Initialized
INFO - 2023-06-07 04:51:50 --> Model "m_datatest" initialized
INFO - 2023-06-07 04:51:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 04:51:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 04:51:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 04:51:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 04:51:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 04:51:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 04:51:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 04:51:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 04:51:50 --> Final output sent to browser
INFO - 2023-06-07 04:51:52 --> Config Class Initialized
INFO - 2023-06-07 04:51:52 --> Hooks Class Initialized
INFO - 2023-06-07 04:51:52 --> Utf8 Class Initialized
INFO - 2023-06-07 04:51:52 --> URI Class Initialized
INFO - 2023-06-07 04:51:52 --> Router Class Initialized
INFO - 2023-06-07 04:51:52 --> Output Class Initialized
INFO - 2023-06-07 04:51:52 --> Security Class Initialized
INFO - 2023-06-07 04:51:52 --> Input Class Initialized
INFO - 2023-06-07 04:51:52 --> Language Class Initialized
INFO - 2023-06-07 04:51:52 --> Loader Class Initialized
INFO - 2023-06-07 04:51:52 --> Helper loaded: url_helper
INFO - 2023-06-07 04:51:52 --> Helper loaded: form_helper
INFO - 2023-06-07 04:51:52 --> Database Driver Class Initialized
INFO - 2023-06-07 04:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:51:52 --> Form Validation Class Initialized
INFO - 2023-06-07 04:51:52 --> Controller Class Initialized
INFO - 2023-06-07 04:51:52 --> Model "m_datatest" initialized
INFO - 2023-06-07 04:51:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 04:51:52 --> Final output sent to browser
INFO - 2023-06-07 04:52:59 --> Config Class Initialized
INFO - 2023-06-07 04:52:59 --> Hooks Class Initialized
INFO - 2023-06-07 04:52:59 --> Utf8 Class Initialized
INFO - 2023-06-07 04:52:59 --> URI Class Initialized
INFO - 2023-06-07 04:52:59 --> Router Class Initialized
INFO - 2023-06-07 04:52:59 --> Output Class Initialized
INFO - 2023-06-07 04:52:59 --> Security Class Initialized
INFO - 2023-06-07 04:52:59 --> Input Class Initialized
INFO - 2023-06-07 04:52:59 --> Language Class Initialized
INFO - 2023-06-07 04:52:59 --> Loader Class Initialized
INFO - 2023-06-07 04:52:59 --> Helper loaded: url_helper
INFO - 2023-06-07 04:52:59 --> Helper loaded: form_helper
INFO - 2023-06-07 04:52:59 --> Database Driver Class Initialized
INFO - 2023-06-07 04:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:52:59 --> Form Validation Class Initialized
INFO - 2023-06-07 04:52:59 --> Controller Class Initialized
INFO - 2023-06-07 04:52:59 --> Model "m_datatest" initialized
INFO - 2023-06-07 04:52:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 04:52:59 --> Final output sent to browser
INFO - 2023-06-07 05:26:49 --> Config Class Initialized
INFO - 2023-06-07 05:26:49 --> Hooks Class Initialized
INFO - 2023-06-07 05:26:49 --> Utf8 Class Initialized
INFO - 2023-06-07 05:26:49 --> URI Class Initialized
INFO - 2023-06-07 05:26:49 --> Router Class Initialized
INFO - 2023-06-07 05:26:49 --> Output Class Initialized
INFO - 2023-06-07 05:26:49 --> Security Class Initialized
INFO - 2023-06-07 05:26:49 --> Input Class Initialized
INFO - 2023-06-07 05:26:49 --> Language Class Initialized
INFO - 2023-06-07 05:26:49 --> Loader Class Initialized
INFO - 2023-06-07 05:26:49 --> Helper loaded: url_helper
INFO - 2023-06-07 05:26:49 --> Helper loaded: form_helper
INFO - 2023-06-07 05:26:49 --> Database Driver Class Initialized
INFO - 2023-06-07 05:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:26:49 --> Form Validation Class Initialized
INFO - 2023-06-07 05:26:49 --> Controller Class Initialized
INFO - 2023-06-07 05:26:49 --> Model "m_datatest" initialized
INFO - 2023-06-07 05:26:49 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 05:26:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 05:26:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 05:26:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 05:26:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 05:26:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 05:26:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 05:26:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 05:26:49 --> Final output sent to browser
INFO - 2023-06-07 05:26:51 --> Config Class Initialized
INFO - 2023-06-07 05:26:51 --> Hooks Class Initialized
INFO - 2023-06-07 05:26:51 --> Utf8 Class Initialized
INFO - 2023-06-07 05:26:51 --> URI Class Initialized
INFO - 2023-06-07 05:26:51 --> Router Class Initialized
INFO - 2023-06-07 05:26:51 --> Output Class Initialized
INFO - 2023-06-07 05:26:51 --> Security Class Initialized
INFO - 2023-06-07 05:26:51 --> Input Class Initialized
INFO - 2023-06-07 05:26:51 --> Language Class Initialized
INFO - 2023-06-07 05:26:51 --> Loader Class Initialized
INFO - 2023-06-07 05:26:51 --> Helper loaded: url_helper
INFO - 2023-06-07 05:26:51 --> Helper loaded: form_helper
INFO - 2023-06-07 05:26:51 --> Database Driver Class Initialized
INFO - 2023-06-07 05:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:26:51 --> Form Validation Class Initialized
INFO - 2023-06-07 05:26:51 --> Controller Class Initialized
INFO - 2023-06-07 05:26:51 --> Model "m_datatest" initialized
INFO - 2023-06-07 05:26:51 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 05:26:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 05:26:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA1Ortu C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 75
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilRinganA1Ortu C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 76
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilSedangA1Ortu C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 77
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilBeratA1Ortu C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 78
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 222
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilRinganA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 223
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilSedangA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 224
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilBeratA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 225
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 238
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilRinganA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 239
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilSedangA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 240
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilBeratA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 241
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 308
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilRinganA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 309
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilSedangA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 310
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilBeratA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 311
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 324
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilRinganA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 325
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilSedangA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 326
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilBeratA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 327
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 523
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilRinganA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 524
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilSedangA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 525
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilBeratA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 526
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 539
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilRinganA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 540
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilSedangA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 541
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilBeratA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 542
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 608
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilRinganA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 609
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilSedangA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 610
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilBeratA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 611
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 624
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilRinganA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 625
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilSedangA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 626
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilBeratA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 627
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 719
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilRinganA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 720
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilSedangA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 721
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: HasilBeratA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 722
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 735
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilRinganA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 736
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilSedangA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 737
ERROR - 2023-06-07 05:26:52 --> Severity: Notice --> Undefined variable: P_HasilBeratA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 738
INFO - 2023-06-07 05:26:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 05:26:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 05:26:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 05:26:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 05:26:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 05:26:52 --> Final output sent to browser
INFO - 2023-06-07 05:27:47 --> Config Class Initialized
INFO - 2023-06-07 05:27:47 --> Hooks Class Initialized
INFO - 2023-06-07 05:27:47 --> Utf8 Class Initialized
INFO - 2023-06-07 05:27:47 --> URI Class Initialized
INFO - 2023-06-07 05:27:47 --> Router Class Initialized
INFO - 2023-06-07 05:27:47 --> Output Class Initialized
INFO - 2023-06-07 05:27:47 --> Security Class Initialized
INFO - 2023-06-07 05:27:47 --> Input Class Initialized
INFO - 2023-06-07 05:27:47 --> Language Class Initialized
INFO - 2023-06-07 05:27:47 --> Loader Class Initialized
INFO - 2023-06-07 05:27:47 --> Helper loaded: url_helper
INFO - 2023-06-07 05:27:47 --> Helper loaded: form_helper
INFO - 2023-06-07 05:27:47 --> Database Driver Class Initialized
INFO - 2023-06-07 05:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:27:47 --> Form Validation Class Initialized
INFO - 2023-06-07 05:27:47 --> Controller Class Initialized
INFO - 2023-06-07 05:27:47 --> Model "m_datatest" initialized
INFO - 2023-06-07 05:27:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 05:27:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 05:27:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 222
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilRinganA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 223
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilSedangA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 224
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilBeratA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 225
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 238
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilRinganA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 239
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilSedangA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 240
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilBeratA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 241
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 308
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilRinganA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 309
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilSedangA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 310
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilBeratA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 311
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 324
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilRinganA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 325
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilSedangA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 326
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilBeratA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 327
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 523
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilRinganA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 524
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilSedangA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 525
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilBeratA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 526
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 539
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilRinganA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 540
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilSedangA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 541
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilBeratA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 542
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 608
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilRinganA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 609
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilSedangA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 610
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilBeratA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 611
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 624
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilRinganA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 625
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilSedangA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 626
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilBeratA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 627
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 719
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilRinganA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 720
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilSedangA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 721
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: HasilBeratA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 722
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 735
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilRinganA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 736
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilSedangA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 737
ERROR - 2023-06-07 05:27:48 --> Severity: Notice --> Undefined variable: P_HasilBeratA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 738
INFO - 2023-06-07 05:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 05:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 05:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 05:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 05:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 05:27:48 --> Final output sent to browser
INFO - 2023-06-07 05:32:52 --> Config Class Initialized
INFO - 2023-06-07 05:32:52 --> Hooks Class Initialized
INFO - 2023-06-07 05:32:52 --> Utf8 Class Initialized
INFO - 2023-06-07 05:32:52 --> URI Class Initialized
INFO - 2023-06-07 05:32:52 --> Router Class Initialized
INFO - 2023-06-07 05:32:52 --> Output Class Initialized
INFO - 2023-06-07 05:32:52 --> Security Class Initialized
INFO - 2023-06-07 05:32:52 --> Input Class Initialized
INFO - 2023-06-07 05:32:52 --> Language Class Initialized
INFO - 2023-06-07 05:32:52 --> Loader Class Initialized
INFO - 2023-06-07 05:32:52 --> Helper loaded: url_helper
INFO - 2023-06-07 05:32:52 --> Helper loaded: form_helper
INFO - 2023-06-07 05:32:52 --> Database Driver Class Initialized
INFO - 2023-06-07 05:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:32:52 --> Form Validation Class Initialized
INFO - 2023-06-07 05:32:52 --> Controller Class Initialized
INFO - 2023-06-07 05:32:52 --> Model "m_datatest" initialized
INFO - 2023-06-07 05:32:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 05:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 05:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 222
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilRinganA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 223
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilSedangA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 224
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilBeratA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 225
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 238
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilRinganA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 239
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilSedangA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 240
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilBeratA2Baik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 241
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 308
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilRinganA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 309
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilSedangA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 310
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilBeratA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 311
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 324
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilRinganA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 325
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilSedangA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 326
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilBeratA3Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 327
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 523
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilRinganA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 524
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilSedangA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 525
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilBeratA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 526
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 539
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilRinganA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 540
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilSedangA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 541
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilBeratA4SangatBaik C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 542
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 608
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilRinganA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 609
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilSedangA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 610
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilBeratA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 611
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 624
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilRinganA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 625
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilSedangA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 626
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilBeratA5Cukup C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 627
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilGangguanMoodA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 719
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilRinganA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 720
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilSedangA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 721
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: HasilBeratA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 722
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilGangguanMoodA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 735
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilRinganA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 736
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilSedangA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 737
ERROR - 2023-06-07 05:32:53 --> Severity: Notice --> Undefined variable: P_HasilBeratA6Buruk C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 738
INFO - 2023-06-07 05:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 05:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 05:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 05:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 05:32:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 05:32:53 --> Final output sent to browser
INFO - 2023-06-07 05:44:16 --> Config Class Initialized
INFO - 2023-06-07 05:44:16 --> Hooks Class Initialized
INFO - 2023-06-07 05:44:16 --> Utf8 Class Initialized
INFO - 2023-06-07 05:44:16 --> URI Class Initialized
INFO - 2023-06-07 05:44:16 --> Router Class Initialized
INFO - 2023-06-07 05:44:16 --> Output Class Initialized
INFO - 2023-06-07 05:44:16 --> Security Class Initialized
INFO - 2023-06-07 05:44:16 --> Input Class Initialized
INFO - 2023-06-07 05:44:16 --> Language Class Initialized
INFO - 2023-06-07 05:44:16 --> Loader Class Initialized
INFO - 2023-06-07 05:44:16 --> Helper loaded: url_helper
INFO - 2023-06-07 05:44:16 --> Helper loaded: form_helper
INFO - 2023-06-07 05:44:16 --> Database Driver Class Initialized
INFO - 2023-06-07 05:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:44:16 --> Form Validation Class Initialized
INFO - 2023-06-07 05:44:16 --> Controller Class Initialized
INFO - 2023-06-07 05:44:16 --> Model "m_datatest" initialized
INFO - 2023-06-07 05:44:16 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 05:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 05:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-07 05:44:16 --> Severity: Notice --> Undefined variable: A2Rngan C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 223
ERROR - 2023-06-07 05:44:16 --> Severity: Notice --> Undefined variable: A3Rngan C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 309
ERROR - 2023-06-07 05:44:16 --> Severity: Notice --> Undefined variable: A4Rngan C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 524
ERROR - 2023-06-07 05:44:16 --> Severity: Notice --> Undefined variable: A5Rngan C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 609
ERROR - 2023-06-07 05:44:16 --> Severity: Notice --> Undefined variable: A6Rngan C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 720
INFO - 2023-06-07 05:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 05:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 05:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 05:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 05:44:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 05:44:16 --> Final output sent to browser
INFO - 2023-06-07 05:45:12 --> Config Class Initialized
INFO - 2023-06-07 05:45:12 --> Hooks Class Initialized
INFO - 2023-06-07 05:45:12 --> Utf8 Class Initialized
INFO - 2023-06-07 05:45:12 --> URI Class Initialized
INFO - 2023-06-07 05:45:12 --> Router Class Initialized
INFO - 2023-06-07 05:45:12 --> Output Class Initialized
INFO - 2023-06-07 05:45:12 --> Security Class Initialized
INFO - 2023-06-07 05:45:12 --> Input Class Initialized
INFO - 2023-06-07 05:45:12 --> Language Class Initialized
INFO - 2023-06-07 05:45:12 --> Loader Class Initialized
INFO - 2023-06-07 05:45:12 --> Helper loaded: url_helper
INFO - 2023-06-07 05:45:12 --> Helper loaded: form_helper
INFO - 2023-06-07 05:45:12 --> Database Driver Class Initialized
INFO - 2023-06-07 05:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:45:12 --> Form Validation Class Initialized
INFO - 2023-06-07 05:45:12 --> Controller Class Initialized
INFO - 2023-06-07 05:45:12 --> Model "m_datatest" initialized
INFO - 2023-06-07 05:45:12 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 05:45:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 05:45:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 05:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 05:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 05:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 05:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 05:45:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 05:45:13 --> Final output sent to browser
INFO - 2023-06-07 05:51:29 --> Config Class Initialized
INFO - 2023-06-07 05:51:29 --> Hooks Class Initialized
INFO - 2023-06-07 05:51:29 --> Utf8 Class Initialized
INFO - 2023-06-07 05:51:29 --> URI Class Initialized
INFO - 2023-06-07 05:51:29 --> Router Class Initialized
INFO - 2023-06-07 05:51:29 --> Output Class Initialized
INFO - 2023-06-07 05:51:29 --> Security Class Initialized
INFO - 2023-06-07 05:51:29 --> Input Class Initialized
INFO - 2023-06-07 05:51:29 --> Language Class Initialized
INFO - 2023-06-07 05:51:29 --> Loader Class Initialized
INFO - 2023-06-07 05:51:29 --> Helper loaded: url_helper
INFO - 2023-06-07 05:51:29 --> Helper loaded: form_helper
INFO - 2023-06-07 05:51:29 --> Database Driver Class Initialized
INFO - 2023-06-07 05:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:51:29 --> Form Validation Class Initialized
INFO - 2023-06-07 05:51:29 --> Controller Class Initialized
INFO - 2023-06-07 05:51:29 --> Model "m_datatest" initialized
INFO - 2023-06-07 05:51:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 05:51:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 05:51:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 05:51:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 05:51:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 05:51:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 05:51:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 05:51:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 05:51:30 --> Final output sent to browser
INFO - 2023-06-07 05:52:02 --> Config Class Initialized
INFO - 2023-06-07 05:52:02 --> Hooks Class Initialized
INFO - 2023-06-07 05:52:02 --> Utf8 Class Initialized
INFO - 2023-06-07 05:52:02 --> URI Class Initialized
INFO - 2023-06-07 05:52:02 --> Router Class Initialized
INFO - 2023-06-07 05:52:02 --> Output Class Initialized
INFO - 2023-06-07 05:52:02 --> Security Class Initialized
INFO - 2023-06-07 05:52:02 --> Input Class Initialized
INFO - 2023-06-07 05:52:02 --> Language Class Initialized
INFO - 2023-06-07 05:52:02 --> Loader Class Initialized
INFO - 2023-06-07 05:52:02 --> Helper loaded: url_helper
INFO - 2023-06-07 05:52:02 --> Helper loaded: form_helper
INFO - 2023-06-07 05:52:02 --> Database Driver Class Initialized
INFO - 2023-06-07 05:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:52:02 --> Form Validation Class Initialized
INFO - 2023-06-07 05:52:02 --> Controller Class Initialized
INFO - 2023-06-07 05:52:02 --> Model "m_datatest" initialized
INFO - 2023-06-07 05:52:02 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 05:52:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 05:52:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 05:52:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 05:52:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 05:52:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 05:52:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 05:52:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 05:52:02 --> Final output sent to browser
INFO - 2023-06-07 05:53:35 --> Config Class Initialized
INFO - 2023-06-07 05:53:35 --> Hooks Class Initialized
INFO - 2023-06-07 05:53:35 --> Utf8 Class Initialized
INFO - 2023-06-07 05:53:35 --> URI Class Initialized
INFO - 2023-06-07 05:53:35 --> Router Class Initialized
INFO - 2023-06-07 05:53:35 --> Output Class Initialized
INFO - 2023-06-07 05:53:35 --> Security Class Initialized
INFO - 2023-06-07 05:53:35 --> Input Class Initialized
INFO - 2023-06-07 05:53:35 --> Language Class Initialized
INFO - 2023-06-07 05:53:35 --> Loader Class Initialized
INFO - 2023-06-07 05:53:35 --> Helper loaded: url_helper
INFO - 2023-06-07 05:53:35 --> Helper loaded: form_helper
INFO - 2023-06-07 05:53:35 --> Database Driver Class Initialized
INFO - 2023-06-07 05:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:53:35 --> Form Validation Class Initialized
INFO - 2023-06-07 05:53:35 --> Controller Class Initialized
INFO - 2023-06-07 05:53:35 --> Model "m_datatest" initialized
INFO - 2023-06-07 05:53:35 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 05:53:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 05:53:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 05:53:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 05:53:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 05:53:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 05:53:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 05:53:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 05:53:36 --> Final output sent to browser
INFO - 2023-06-07 06:00:05 --> Config Class Initialized
INFO - 2023-06-07 06:00:05 --> Hooks Class Initialized
INFO - 2023-06-07 06:00:05 --> Utf8 Class Initialized
INFO - 2023-06-07 06:00:05 --> URI Class Initialized
INFO - 2023-06-07 06:00:05 --> Router Class Initialized
INFO - 2023-06-07 06:00:05 --> Output Class Initialized
INFO - 2023-06-07 06:00:05 --> Security Class Initialized
INFO - 2023-06-07 06:00:05 --> Input Class Initialized
INFO - 2023-06-07 06:00:05 --> Language Class Initialized
INFO - 2023-06-07 06:00:05 --> Loader Class Initialized
INFO - 2023-06-07 06:00:05 --> Helper loaded: url_helper
INFO - 2023-06-07 06:00:05 --> Helper loaded: form_helper
INFO - 2023-06-07 06:00:05 --> Database Driver Class Initialized
INFO - 2023-06-07 06:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:00:05 --> Form Validation Class Initialized
INFO - 2023-06-07 06:00:05 --> Controller Class Initialized
INFO - 2023-06-07 06:00:05 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:00:05 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:00:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:00:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:00:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 06:00:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 06:00:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:00:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:00:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 06:00:05 --> Final output sent to browser
INFO - 2023-06-07 06:01:13 --> Config Class Initialized
INFO - 2023-06-07 06:01:13 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:13 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:13 --> URI Class Initialized
INFO - 2023-06-07 06:01:13 --> Router Class Initialized
INFO - 2023-06-07 06:01:13 --> Output Class Initialized
INFO - 2023-06-07 06:01:13 --> Security Class Initialized
INFO - 2023-06-07 06:01:13 --> Input Class Initialized
INFO - 2023-06-07 06:01:13 --> Language Class Initialized
INFO - 2023-06-07 06:01:13 --> Loader Class Initialized
INFO - 2023-06-07 06:01:13 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:13 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:13 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:13 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:13 --> Controller Class Initialized
INFO - 2023-06-07 06:01:13 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:01:13 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:01:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:01:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:01:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 06:01:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 06:01:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:01:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:01:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 06:01:13 --> Final output sent to browser
INFO - 2023-06-07 06:01:19 --> Config Class Initialized
INFO - 2023-06-07 06:01:19 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:19 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:19 --> URI Class Initialized
INFO - 2023-06-07 06:01:19 --> Router Class Initialized
INFO - 2023-06-07 06:01:19 --> Output Class Initialized
INFO - 2023-06-07 06:01:19 --> Security Class Initialized
INFO - 2023-06-07 06:01:19 --> Input Class Initialized
INFO - 2023-06-07 06:01:19 --> Language Class Initialized
INFO - 2023-06-07 06:01:19 --> Loader Class Initialized
INFO - 2023-06-07 06:01:19 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:19 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:19 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:19 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:19 --> Controller Class Initialized
INFO - 2023-06-07 06:01:19 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:01:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:01:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:01:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:01:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 06:01:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 06:01:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:01:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:01:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 06:01:19 --> Final output sent to browser
INFO - 2023-06-07 06:01:34 --> Config Class Initialized
INFO - 2023-06-07 06:01:34 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:34 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:34 --> URI Class Initialized
INFO - 2023-06-07 06:01:34 --> Router Class Initialized
INFO - 2023-06-07 06:01:34 --> Output Class Initialized
INFO - 2023-06-07 06:01:34 --> Security Class Initialized
INFO - 2023-06-07 06:01:34 --> Input Class Initialized
INFO - 2023-06-07 06:01:34 --> Language Class Initialized
INFO - 2023-06-07 06:01:34 --> Loader Class Initialized
INFO - 2023-06-07 06:01:34 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:34 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:34 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:34 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:34 --> Controller Class Initialized
INFO - 2023-06-07 06:01:34 --> Model "m_user" initialized
INFO - 2023-06-07 06:01:34 --> Config Class Initialized
INFO - 2023-06-07 06:01:34 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:34 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:34 --> URI Class Initialized
INFO - 2023-06-07 06:01:34 --> Router Class Initialized
INFO - 2023-06-07 06:01:34 --> Output Class Initialized
INFO - 2023-06-07 06:01:34 --> Security Class Initialized
INFO - 2023-06-07 06:01:34 --> Input Class Initialized
INFO - 2023-06-07 06:01:34 --> Language Class Initialized
INFO - 2023-06-07 06:01:34 --> Loader Class Initialized
INFO - 2023-06-07 06:01:34 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:34 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:34 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:34 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:34 --> Controller Class Initialized
INFO - 2023-06-07 06:01:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-07 06:01:34 --> Final output sent to browser
INFO - 2023-06-07 06:01:35 --> Config Class Initialized
INFO - 2023-06-07 06:01:35 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:35 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:35 --> URI Class Initialized
INFO - 2023-06-07 06:01:35 --> Router Class Initialized
INFO - 2023-06-07 06:01:35 --> Output Class Initialized
INFO - 2023-06-07 06:01:35 --> Security Class Initialized
INFO - 2023-06-07 06:01:35 --> Input Class Initialized
INFO - 2023-06-07 06:01:35 --> Language Class Initialized
INFO - 2023-06-07 06:01:35 --> Loader Class Initialized
INFO - 2023-06-07 06:01:35 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:35 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:35 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:35 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:35 --> Controller Class Initialized
INFO - 2023-06-07 06:01:35 --> Model "m_user" initialized
INFO - 2023-06-07 06:01:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:01:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:01:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-07 06:01:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:01:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:01:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-07 06:01:35 --> Final output sent to browser
INFO - 2023-06-07 06:01:37 --> Config Class Initialized
INFO - 2023-06-07 06:01:37 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:37 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:37 --> URI Class Initialized
INFO - 2023-06-07 06:01:37 --> Router Class Initialized
INFO - 2023-06-07 06:01:37 --> Output Class Initialized
INFO - 2023-06-07 06:01:37 --> Security Class Initialized
INFO - 2023-06-07 06:01:37 --> Input Class Initialized
INFO - 2023-06-07 06:01:37 --> Language Class Initialized
INFO - 2023-06-07 06:01:37 --> Loader Class Initialized
INFO - 2023-06-07 06:01:37 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:37 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:37 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:37 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:37 --> Controller Class Initialized
INFO - 2023-06-07 06:01:37 --> Model "m_datatrain" initialized
INFO - 2023-06-07 06:01:37 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:01:37 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:01:38 --> Model "M_solusi" initialized
INFO - 2023-06-07 06:01:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:01:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:01:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-07 06:01:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-07 06:01:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:01:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:01:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-07 06:01:38 --> Final output sent to browser
INFO - 2023-06-07 06:01:43 --> Config Class Initialized
INFO - 2023-06-07 06:01:43 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:43 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:43 --> URI Class Initialized
INFO - 2023-06-07 06:01:43 --> Router Class Initialized
INFO - 2023-06-07 06:01:43 --> Output Class Initialized
INFO - 2023-06-07 06:01:43 --> Security Class Initialized
INFO - 2023-06-07 06:01:43 --> Input Class Initialized
INFO - 2023-06-07 06:01:43 --> Language Class Initialized
INFO - 2023-06-07 06:01:43 --> Loader Class Initialized
INFO - 2023-06-07 06:01:43 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:43 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:43 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:43 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:43 --> Controller Class Initialized
INFO - 2023-06-07 06:01:43 --> Model "m_user" initialized
INFO - 2023-06-07 06:01:43 --> Config Class Initialized
INFO - 2023-06-07 06:01:43 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:43 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:43 --> URI Class Initialized
INFO - 2023-06-07 06:01:43 --> Router Class Initialized
INFO - 2023-06-07 06:01:43 --> Output Class Initialized
INFO - 2023-06-07 06:01:43 --> Security Class Initialized
INFO - 2023-06-07 06:01:43 --> Input Class Initialized
INFO - 2023-06-07 06:01:43 --> Language Class Initialized
INFO - 2023-06-07 06:01:43 --> Loader Class Initialized
INFO - 2023-06-07 06:01:43 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:43 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:43 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:43 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:43 --> Controller Class Initialized
INFO - 2023-06-07 06:01:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-07 06:01:43 --> Final output sent to browser
INFO - 2023-06-07 06:01:44 --> Config Class Initialized
INFO - 2023-06-07 06:01:44 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:44 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:44 --> URI Class Initialized
INFO - 2023-06-07 06:01:44 --> Router Class Initialized
INFO - 2023-06-07 06:01:44 --> Output Class Initialized
INFO - 2023-06-07 06:01:44 --> Security Class Initialized
INFO - 2023-06-07 06:01:44 --> Input Class Initialized
INFO - 2023-06-07 06:01:44 --> Language Class Initialized
INFO - 2023-06-07 06:01:44 --> Loader Class Initialized
INFO - 2023-06-07 06:01:44 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:44 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:44 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:44 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:44 --> Controller Class Initialized
INFO - 2023-06-07 06:01:44 --> Model "m_user" initialized
INFO - 2023-06-07 06:01:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-07 06:01:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-07 06:01:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-07 06:01:44 --> Final output sent to browser
INFO - 2023-06-07 06:01:48 --> Config Class Initialized
INFO - 2023-06-07 06:01:48 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:48 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:48 --> URI Class Initialized
INFO - 2023-06-07 06:01:48 --> Router Class Initialized
INFO - 2023-06-07 06:01:48 --> Output Class Initialized
INFO - 2023-06-07 06:01:48 --> Security Class Initialized
INFO - 2023-06-07 06:01:48 --> Input Class Initialized
INFO - 2023-06-07 06:01:48 --> Language Class Initialized
INFO - 2023-06-07 06:01:48 --> Loader Class Initialized
INFO - 2023-06-07 06:01:48 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:48 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:48 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:48 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:48 --> Controller Class Initialized
INFO - 2023-06-07 06:01:48 --> Model "m_user" initialized
INFO - 2023-06-07 06:01:48 --> Config Class Initialized
INFO - 2023-06-07 06:01:48 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:48 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:48 --> URI Class Initialized
INFO - 2023-06-07 06:01:48 --> Router Class Initialized
INFO - 2023-06-07 06:01:48 --> Output Class Initialized
INFO - 2023-06-07 06:01:48 --> Security Class Initialized
INFO - 2023-06-07 06:01:48 --> Input Class Initialized
INFO - 2023-06-07 06:01:48 --> Language Class Initialized
INFO - 2023-06-07 06:01:48 --> Loader Class Initialized
INFO - 2023-06-07 06:01:48 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:48 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:48 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:48 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:48 --> Controller Class Initialized
INFO - 2023-06-07 06:01:48 --> Model "m_user" initialized
INFO - 2023-06-07 06:01:48 --> Model "m_datatrain" initialized
INFO - 2023-06-07 06:01:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:01:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:01:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 06:01:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:01:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:01:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-07 06:01:48 --> Final output sent to browser
INFO - 2023-06-07 06:01:50 --> Config Class Initialized
INFO - 2023-06-07 06:01:50 --> Hooks Class Initialized
INFO - 2023-06-07 06:01:50 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:50 --> URI Class Initialized
INFO - 2023-06-07 06:01:50 --> Router Class Initialized
INFO - 2023-06-07 06:01:50 --> Output Class Initialized
INFO - 2023-06-07 06:01:50 --> Security Class Initialized
INFO - 2023-06-07 06:01:50 --> Input Class Initialized
INFO - 2023-06-07 06:01:50 --> Language Class Initialized
INFO - 2023-06-07 06:01:50 --> Loader Class Initialized
INFO - 2023-06-07 06:01:50 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:50 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:50 --> Database Driver Class Initialized
INFO - 2023-06-07 06:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:50 --> Form Validation Class Initialized
INFO - 2023-06-07 06:01:50 --> Controller Class Initialized
INFO - 2023-06-07 06:01:50 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:01:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 06:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 06:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:01:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 06:01:50 --> Final output sent to browser
INFO - 2023-06-07 06:04:22 --> Config Class Initialized
INFO - 2023-06-07 06:04:22 --> Hooks Class Initialized
INFO - 2023-06-07 06:04:22 --> Utf8 Class Initialized
INFO - 2023-06-07 06:04:22 --> URI Class Initialized
INFO - 2023-06-07 06:04:22 --> Router Class Initialized
INFO - 2023-06-07 06:04:22 --> Output Class Initialized
INFO - 2023-06-07 06:04:22 --> Security Class Initialized
INFO - 2023-06-07 06:04:22 --> Input Class Initialized
INFO - 2023-06-07 06:04:22 --> Language Class Initialized
INFO - 2023-06-07 06:04:22 --> Loader Class Initialized
INFO - 2023-06-07 06:04:22 --> Helper loaded: url_helper
INFO - 2023-06-07 06:04:22 --> Helper loaded: form_helper
INFO - 2023-06-07 06:04:22 --> Database Driver Class Initialized
INFO - 2023-06-07 06:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:04:22 --> Form Validation Class Initialized
INFO - 2023-06-07 06:04:22 --> Controller Class Initialized
INFO - 2023-06-07 06:04:22 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:04:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 06:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 06:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 06:04:22 --> Final output sent to browser
INFO - 2023-06-07 06:04:24 --> Config Class Initialized
INFO - 2023-06-07 06:04:24 --> Hooks Class Initialized
INFO - 2023-06-07 06:04:24 --> Utf8 Class Initialized
INFO - 2023-06-07 06:04:24 --> URI Class Initialized
INFO - 2023-06-07 06:04:24 --> Router Class Initialized
INFO - 2023-06-07 06:04:24 --> Output Class Initialized
INFO - 2023-06-07 06:04:24 --> Security Class Initialized
INFO - 2023-06-07 06:04:24 --> Input Class Initialized
INFO - 2023-06-07 06:04:24 --> Language Class Initialized
INFO - 2023-06-07 06:04:24 --> Loader Class Initialized
INFO - 2023-06-07 06:04:24 --> Helper loaded: url_helper
INFO - 2023-06-07 06:04:24 --> Helper loaded: form_helper
INFO - 2023-06-07 06:04:24 --> Database Driver Class Initialized
INFO - 2023-06-07 06:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:04:24 --> Form Validation Class Initialized
INFO - 2023-06-07 06:04:24 --> Controller Class Initialized
INFO - 2023-06-07 06:04:24 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:04:24 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:04:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:04:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:04:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 06:04:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 06:04:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:04:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:04:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 06:04:24 --> Final output sent to browser
INFO - 2023-06-07 06:04:47 --> Config Class Initialized
INFO - 2023-06-07 06:04:47 --> Hooks Class Initialized
INFO - 2023-06-07 06:04:47 --> Utf8 Class Initialized
INFO - 2023-06-07 06:04:47 --> URI Class Initialized
INFO - 2023-06-07 06:04:47 --> Router Class Initialized
INFO - 2023-06-07 06:04:47 --> Output Class Initialized
INFO - 2023-06-07 06:04:47 --> Security Class Initialized
INFO - 2023-06-07 06:04:47 --> Input Class Initialized
INFO - 2023-06-07 06:04:47 --> Language Class Initialized
INFO - 2023-06-07 06:04:47 --> Loader Class Initialized
INFO - 2023-06-07 06:04:47 --> Helper loaded: url_helper
INFO - 2023-06-07 06:04:47 --> Helper loaded: form_helper
INFO - 2023-06-07 06:04:47 --> Database Driver Class Initialized
INFO - 2023-06-07 06:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:04:47 --> Form Validation Class Initialized
INFO - 2023-06-07 06:04:47 --> Controller Class Initialized
INFO - 2023-06-07 06:04:47 --> Model "m_user" initialized
INFO - 2023-06-07 06:04:47 --> Config Class Initialized
INFO - 2023-06-07 06:04:47 --> Hooks Class Initialized
INFO - 2023-06-07 06:04:47 --> Utf8 Class Initialized
INFO - 2023-06-07 06:04:47 --> URI Class Initialized
INFO - 2023-06-07 06:04:47 --> Router Class Initialized
INFO - 2023-06-07 06:04:47 --> Output Class Initialized
INFO - 2023-06-07 06:04:47 --> Security Class Initialized
INFO - 2023-06-07 06:04:47 --> Input Class Initialized
INFO - 2023-06-07 06:04:47 --> Language Class Initialized
INFO - 2023-06-07 06:04:47 --> Loader Class Initialized
INFO - 2023-06-07 06:04:47 --> Helper loaded: url_helper
INFO - 2023-06-07 06:04:47 --> Helper loaded: form_helper
INFO - 2023-06-07 06:04:47 --> Database Driver Class Initialized
INFO - 2023-06-07 06:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:04:47 --> Form Validation Class Initialized
INFO - 2023-06-07 06:04:47 --> Controller Class Initialized
INFO - 2023-06-07 06:04:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-07 06:04:47 --> Final output sent to browser
INFO - 2023-06-07 06:04:49 --> Config Class Initialized
INFO - 2023-06-07 06:04:49 --> Hooks Class Initialized
INFO - 2023-06-07 06:04:49 --> Utf8 Class Initialized
INFO - 2023-06-07 06:04:49 --> URI Class Initialized
INFO - 2023-06-07 06:04:49 --> Router Class Initialized
INFO - 2023-06-07 06:04:49 --> Output Class Initialized
INFO - 2023-06-07 06:04:49 --> Security Class Initialized
INFO - 2023-06-07 06:04:49 --> Input Class Initialized
INFO - 2023-06-07 06:04:49 --> Language Class Initialized
INFO - 2023-06-07 06:04:49 --> Loader Class Initialized
INFO - 2023-06-07 06:04:49 --> Helper loaded: url_helper
INFO - 2023-06-07 06:04:49 --> Helper loaded: form_helper
INFO - 2023-06-07 06:04:49 --> Database Driver Class Initialized
INFO - 2023-06-07 06:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:04:49 --> Form Validation Class Initialized
INFO - 2023-06-07 06:04:49 --> Controller Class Initialized
INFO - 2023-06-07 06:04:49 --> Model "m_user" initialized
INFO - 2023-06-07 06:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-07 06:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:04:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-07 06:04:49 --> Final output sent to browser
INFO - 2023-06-07 06:04:50 --> Config Class Initialized
INFO - 2023-06-07 06:04:50 --> Hooks Class Initialized
INFO - 2023-06-07 06:04:50 --> Utf8 Class Initialized
INFO - 2023-06-07 06:04:50 --> URI Class Initialized
INFO - 2023-06-07 06:04:50 --> Router Class Initialized
INFO - 2023-06-07 06:04:50 --> Output Class Initialized
INFO - 2023-06-07 06:04:50 --> Security Class Initialized
INFO - 2023-06-07 06:04:50 --> Input Class Initialized
INFO - 2023-06-07 06:04:50 --> Language Class Initialized
INFO - 2023-06-07 06:04:50 --> Loader Class Initialized
INFO - 2023-06-07 06:04:50 --> Helper loaded: url_helper
INFO - 2023-06-07 06:04:50 --> Helper loaded: form_helper
INFO - 2023-06-07 06:04:50 --> Database Driver Class Initialized
INFO - 2023-06-07 06:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:04:50 --> Form Validation Class Initialized
INFO - 2023-06-07 06:04:50 --> Controller Class Initialized
INFO - 2023-06-07 06:04:50 --> Model "m_datatrain" initialized
INFO - 2023-06-07 06:04:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:04:50 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:04:50 --> Model "M_solusi" initialized
INFO - 2023-06-07 06:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-07 06:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-07 06:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-07 06:04:50 --> Final output sent to browser
INFO - 2023-06-07 06:07:45 --> Config Class Initialized
INFO - 2023-06-07 06:07:45 --> Hooks Class Initialized
INFO - 2023-06-07 06:07:45 --> Utf8 Class Initialized
INFO - 2023-06-07 06:07:45 --> URI Class Initialized
INFO - 2023-06-07 06:07:45 --> Router Class Initialized
INFO - 2023-06-07 06:07:45 --> Output Class Initialized
INFO - 2023-06-07 06:07:45 --> Security Class Initialized
INFO - 2023-06-07 06:07:45 --> Input Class Initialized
INFO - 2023-06-07 06:07:45 --> Language Class Initialized
INFO - 2023-06-07 06:07:45 --> Loader Class Initialized
INFO - 2023-06-07 06:07:45 --> Helper loaded: url_helper
INFO - 2023-06-07 06:07:45 --> Helper loaded: form_helper
INFO - 2023-06-07 06:07:45 --> Database Driver Class Initialized
INFO - 2023-06-07 06:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:07:45 --> Form Validation Class Initialized
INFO - 2023-06-07 06:07:45 --> Controller Class Initialized
INFO - 2023-06-07 06:07:45 --> Model "m_user" initialized
INFO - 2023-06-07 06:07:45 --> Config Class Initialized
INFO - 2023-06-07 06:07:45 --> Hooks Class Initialized
INFO - 2023-06-07 06:07:45 --> Utf8 Class Initialized
INFO - 2023-06-07 06:07:45 --> URI Class Initialized
INFO - 2023-06-07 06:07:45 --> Router Class Initialized
INFO - 2023-06-07 06:07:45 --> Output Class Initialized
INFO - 2023-06-07 06:07:45 --> Security Class Initialized
INFO - 2023-06-07 06:07:45 --> Input Class Initialized
INFO - 2023-06-07 06:07:45 --> Language Class Initialized
INFO - 2023-06-07 06:07:45 --> Loader Class Initialized
INFO - 2023-06-07 06:07:45 --> Helper loaded: url_helper
INFO - 2023-06-07 06:07:45 --> Helper loaded: form_helper
INFO - 2023-06-07 06:07:45 --> Database Driver Class Initialized
INFO - 2023-06-07 06:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:07:45 --> Form Validation Class Initialized
INFO - 2023-06-07 06:07:45 --> Controller Class Initialized
INFO - 2023-06-07 06:07:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-07 06:07:45 --> Final output sent to browser
INFO - 2023-06-07 06:12:05 --> Config Class Initialized
INFO - 2023-06-07 06:12:05 --> Hooks Class Initialized
INFO - 2023-06-07 06:12:05 --> Utf8 Class Initialized
INFO - 2023-06-07 06:12:05 --> URI Class Initialized
INFO - 2023-06-07 06:12:05 --> Router Class Initialized
INFO - 2023-06-07 06:12:05 --> Output Class Initialized
INFO - 2023-06-07 06:12:05 --> Security Class Initialized
INFO - 2023-06-07 06:12:05 --> Input Class Initialized
INFO - 2023-06-07 06:12:05 --> Language Class Initialized
INFO - 2023-06-07 06:12:05 --> Loader Class Initialized
INFO - 2023-06-07 06:12:05 --> Helper loaded: url_helper
INFO - 2023-06-07 06:12:05 --> Helper loaded: form_helper
INFO - 2023-06-07 06:12:05 --> Database Driver Class Initialized
INFO - 2023-06-07 06:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:12:05 --> Form Validation Class Initialized
INFO - 2023-06-07 06:12:05 --> Controller Class Initialized
INFO - 2023-06-07 06:12:05 --> Model "m_user" initialized
INFO - 2023-06-07 06:12:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:12:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:12:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-07 06:12:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:12:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:12:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-07 06:12:05 --> Final output sent to browser
INFO - 2023-06-07 06:12:07 --> Config Class Initialized
INFO - 2023-06-07 06:12:07 --> Hooks Class Initialized
INFO - 2023-06-07 06:12:07 --> Utf8 Class Initialized
INFO - 2023-06-07 06:12:07 --> URI Class Initialized
INFO - 2023-06-07 06:12:07 --> Router Class Initialized
INFO - 2023-06-07 06:12:07 --> Output Class Initialized
INFO - 2023-06-07 06:12:07 --> Security Class Initialized
INFO - 2023-06-07 06:12:07 --> Input Class Initialized
INFO - 2023-06-07 06:12:07 --> Language Class Initialized
INFO - 2023-06-07 06:12:07 --> Loader Class Initialized
INFO - 2023-06-07 06:12:07 --> Helper loaded: url_helper
INFO - 2023-06-07 06:12:07 --> Helper loaded: form_helper
INFO - 2023-06-07 06:12:07 --> Database Driver Class Initialized
INFO - 2023-06-07 06:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:12:07 --> Form Validation Class Initialized
INFO - 2023-06-07 06:12:07 --> Controller Class Initialized
INFO - 2023-06-07 06:12:07 --> Model "m_datatrain" initialized
INFO - 2023-06-07 06:12:07 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:12:07 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:12:07 --> Model "M_solusi" initialized
INFO - 2023-06-07 06:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-07 06:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-07 06:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:12:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-07 06:12:07 --> Final output sent to browser
INFO - 2023-06-07 06:12:17 --> Config Class Initialized
INFO - 2023-06-07 06:12:17 --> Hooks Class Initialized
INFO - 2023-06-07 06:12:17 --> Utf8 Class Initialized
INFO - 2023-06-07 06:12:17 --> URI Class Initialized
INFO - 2023-06-07 06:12:17 --> Router Class Initialized
INFO - 2023-06-07 06:12:17 --> Output Class Initialized
INFO - 2023-06-07 06:12:17 --> Security Class Initialized
INFO - 2023-06-07 06:12:17 --> Input Class Initialized
INFO - 2023-06-07 06:12:17 --> Language Class Initialized
INFO - 2023-06-07 06:12:17 --> Loader Class Initialized
INFO - 2023-06-07 06:12:17 --> Helper loaded: url_helper
INFO - 2023-06-07 06:12:17 --> Helper loaded: form_helper
INFO - 2023-06-07 06:12:17 --> Database Driver Class Initialized
INFO - 2023-06-07 06:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:12:17 --> Form Validation Class Initialized
INFO - 2023-06-07 06:12:17 --> Controller Class Initialized
INFO - 2023-06-07 06:12:17 --> Model "m_user" initialized
INFO - 2023-06-07 06:12:17 --> Config Class Initialized
INFO - 2023-06-07 06:12:17 --> Hooks Class Initialized
INFO - 2023-06-07 06:12:17 --> Utf8 Class Initialized
INFO - 2023-06-07 06:12:17 --> URI Class Initialized
INFO - 2023-06-07 06:12:17 --> Router Class Initialized
INFO - 2023-06-07 06:12:17 --> Output Class Initialized
INFO - 2023-06-07 06:12:17 --> Security Class Initialized
INFO - 2023-06-07 06:12:17 --> Input Class Initialized
INFO - 2023-06-07 06:12:17 --> Language Class Initialized
INFO - 2023-06-07 06:12:17 --> Loader Class Initialized
INFO - 2023-06-07 06:12:17 --> Helper loaded: url_helper
INFO - 2023-06-07 06:12:17 --> Helper loaded: form_helper
INFO - 2023-06-07 06:12:17 --> Database Driver Class Initialized
INFO - 2023-06-07 06:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:12:17 --> Form Validation Class Initialized
INFO - 2023-06-07 06:12:17 --> Controller Class Initialized
INFO - 2023-06-07 06:12:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-07 06:12:17 --> Final output sent to browser
INFO - 2023-06-07 06:12:53 --> Config Class Initialized
INFO - 2023-06-07 06:12:53 --> Hooks Class Initialized
INFO - 2023-06-07 06:12:53 --> Utf8 Class Initialized
INFO - 2023-06-07 06:12:53 --> URI Class Initialized
INFO - 2023-06-07 06:12:53 --> Router Class Initialized
INFO - 2023-06-07 06:12:53 --> Output Class Initialized
INFO - 2023-06-07 06:12:53 --> Security Class Initialized
INFO - 2023-06-07 06:12:53 --> Input Class Initialized
INFO - 2023-06-07 06:12:53 --> Language Class Initialized
INFO - 2023-06-07 06:12:53 --> Loader Class Initialized
INFO - 2023-06-07 06:12:53 --> Helper loaded: url_helper
INFO - 2023-06-07 06:12:53 --> Helper loaded: form_helper
INFO - 2023-06-07 06:12:53 --> Database Driver Class Initialized
INFO - 2023-06-07 06:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:12:53 --> Form Validation Class Initialized
INFO - 2023-06-07 06:12:53 --> Controller Class Initialized
INFO - 2023-06-07 06:12:53 --> Model "m_user" initialized
INFO - 2023-06-07 06:12:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-07 06:12:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-07 06:12:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-07 06:12:53 --> Final output sent to browser
INFO - 2023-06-07 06:12:57 --> Config Class Initialized
INFO - 2023-06-07 06:12:57 --> Hooks Class Initialized
INFO - 2023-06-07 06:12:57 --> Utf8 Class Initialized
INFO - 2023-06-07 06:12:57 --> URI Class Initialized
INFO - 2023-06-07 06:12:57 --> Router Class Initialized
INFO - 2023-06-07 06:12:57 --> Output Class Initialized
INFO - 2023-06-07 06:12:57 --> Security Class Initialized
INFO - 2023-06-07 06:12:57 --> Input Class Initialized
INFO - 2023-06-07 06:12:57 --> Language Class Initialized
INFO - 2023-06-07 06:12:57 --> Loader Class Initialized
INFO - 2023-06-07 06:12:57 --> Helper loaded: url_helper
INFO - 2023-06-07 06:12:57 --> Helper loaded: form_helper
INFO - 2023-06-07 06:12:57 --> Database Driver Class Initialized
INFO - 2023-06-07 06:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:12:57 --> Form Validation Class Initialized
INFO - 2023-06-07 06:12:57 --> Controller Class Initialized
INFO - 2023-06-07 06:12:57 --> Model "m_user" initialized
INFO - 2023-06-07 06:12:57 --> Config Class Initialized
INFO - 2023-06-07 06:12:57 --> Hooks Class Initialized
INFO - 2023-06-07 06:12:57 --> Utf8 Class Initialized
INFO - 2023-06-07 06:12:57 --> URI Class Initialized
INFO - 2023-06-07 06:12:57 --> Router Class Initialized
INFO - 2023-06-07 06:12:57 --> Output Class Initialized
INFO - 2023-06-07 06:12:57 --> Security Class Initialized
INFO - 2023-06-07 06:12:57 --> Input Class Initialized
INFO - 2023-06-07 06:12:57 --> Language Class Initialized
INFO - 2023-06-07 06:12:57 --> Loader Class Initialized
INFO - 2023-06-07 06:12:57 --> Helper loaded: url_helper
INFO - 2023-06-07 06:12:57 --> Helper loaded: form_helper
INFO - 2023-06-07 06:12:57 --> Database Driver Class Initialized
INFO - 2023-06-07 06:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:12:57 --> Form Validation Class Initialized
INFO - 2023-06-07 06:12:57 --> Controller Class Initialized
INFO - 2023-06-07 06:12:57 --> Model "m_user" initialized
INFO - 2023-06-07 06:12:57 --> Model "m_datatrain" initialized
INFO - 2023-06-07 06:12:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:12:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:12:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 06:12:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:12:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:12:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-07 06:12:57 --> Final output sent to browser
INFO - 2023-06-07 06:12:59 --> Config Class Initialized
INFO - 2023-06-07 06:12:59 --> Hooks Class Initialized
INFO - 2023-06-07 06:12:59 --> Utf8 Class Initialized
INFO - 2023-06-07 06:12:59 --> URI Class Initialized
INFO - 2023-06-07 06:12:59 --> Router Class Initialized
INFO - 2023-06-07 06:12:59 --> Output Class Initialized
INFO - 2023-06-07 06:12:59 --> Security Class Initialized
INFO - 2023-06-07 06:12:59 --> Input Class Initialized
INFO - 2023-06-07 06:12:59 --> Language Class Initialized
INFO - 2023-06-07 06:12:59 --> Loader Class Initialized
INFO - 2023-06-07 06:12:59 --> Helper loaded: url_helper
INFO - 2023-06-07 06:12:59 --> Helper loaded: form_helper
INFO - 2023-06-07 06:12:59 --> Database Driver Class Initialized
INFO - 2023-06-07 06:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:12:59 --> Form Validation Class Initialized
INFO - 2023-06-07 06:12:59 --> Controller Class Initialized
INFO - 2023-06-07 06:12:59 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:12:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 06:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 06:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 06:12:59 --> Final output sent to browser
INFO - 2023-06-07 06:13:01 --> Config Class Initialized
INFO - 2023-06-07 06:13:01 --> Hooks Class Initialized
INFO - 2023-06-07 06:13:01 --> Utf8 Class Initialized
INFO - 2023-06-07 06:13:01 --> URI Class Initialized
INFO - 2023-06-07 06:13:01 --> Router Class Initialized
INFO - 2023-06-07 06:13:01 --> Output Class Initialized
INFO - 2023-06-07 06:13:01 --> Security Class Initialized
INFO - 2023-06-07 06:13:01 --> Input Class Initialized
INFO - 2023-06-07 06:13:01 --> Language Class Initialized
INFO - 2023-06-07 06:13:01 --> Loader Class Initialized
INFO - 2023-06-07 06:13:01 --> Helper loaded: url_helper
INFO - 2023-06-07 06:13:01 --> Helper loaded: form_helper
INFO - 2023-06-07 06:13:01 --> Database Driver Class Initialized
INFO - 2023-06-07 06:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:13:01 --> Form Validation Class Initialized
INFO - 2023-06-07 06:13:01 --> Controller Class Initialized
INFO - 2023-06-07 06:13:01 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:13:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:13:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:13:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:13:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 06:13:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 06:13:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:13:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:13:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 06:13:01 --> Final output sent to browser
INFO - 2023-06-07 06:37:48 --> Config Class Initialized
INFO - 2023-06-07 06:37:48 --> Hooks Class Initialized
INFO - 2023-06-07 06:37:48 --> Utf8 Class Initialized
INFO - 2023-06-07 06:37:48 --> URI Class Initialized
INFO - 2023-06-07 06:37:48 --> Router Class Initialized
INFO - 2023-06-07 06:37:48 --> Output Class Initialized
INFO - 2023-06-07 06:37:48 --> Security Class Initialized
INFO - 2023-06-07 06:37:48 --> Input Class Initialized
INFO - 2023-06-07 06:37:48 --> Language Class Initialized
INFO - 2023-06-07 06:37:48 --> Loader Class Initialized
INFO - 2023-06-07 06:37:48 --> Helper loaded: url_helper
INFO - 2023-06-07 06:37:48 --> Helper loaded: form_helper
INFO - 2023-06-07 06:37:48 --> Database Driver Class Initialized
INFO - 2023-06-07 06:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:37:48 --> Form Validation Class Initialized
INFO - 2023-06-07 06:37:48 --> Controller Class Initialized
INFO - 2023-06-07 06:37:48 --> Model "m_user" initialized
INFO - 2023-06-07 06:37:48 --> Config Class Initialized
INFO - 2023-06-07 06:37:48 --> Hooks Class Initialized
INFO - 2023-06-07 06:37:48 --> Utf8 Class Initialized
INFO - 2023-06-07 06:37:48 --> URI Class Initialized
INFO - 2023-06-07 06:37:48 --> Router Class Initialized
INFO - 2023-06-07 06:37:48 --> Output Class Initialized
INFO - 2023-06-07 06:37:48 --> Security Class Initialized
INFO - 2023-06-07 06:37:48 --> Input Class Initialized
INFO - 2023-06-07 06:37:48 --> Language Class Initialized
INFO - 2023-06-07 06:37:48 --> Loader Class Initialized
INFO - 2023-06-07 06:37:48 --> Helper loaded: url_helper
INFO - 2023-06-07 06:37:48 --> Helper loaded: form_helper
INFO - 2023-06-07 06:37:48 --> Database Driver Class Initialized
INFO - 2023-06-07 06:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:37:48 --> Form Validation Class Initialized
INFO - 2023-06-07 06:37:48 --> Controller Class Initialized
INFO - 2023-06-07 06:37:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-07 06:37:48 --> Final output sent to browser
INFO - 2023-06-07 06:37:49 --> Config Class Initialized
INFO - 2023-06-07 06:37:49 --> Hooks Class Initialized
INFO - 2023-06-07 06:37:49 --> Utf8 Class Initialized
INFO - 2023-06-07 06:37:49 --> URI Class Initialized
INFO - 2023-06-07 06:37:49 --> Router Class Initialized
INFO - 2023-06-07 06:37:49 --> Output Class Initialized
INFO - 2023-06-07 06:37:49 --> Security Class Initialized
INFO - 2023-06-07 06:37:49 --> Input Class Initialized
INFO - 2023-06-07 06:37:49 --> Language Class Initialized
INFO - 2023-06-07 06:37:49 --> Loader Class Initialized
INFO - 2023-06-07 06:37:49 --> Helper loaded: url_helper
INFO - 2023-06-07 06:37:49 --> Helper loaded: form_helper
INFO - 2023-06-07 06:37:49 --> Database Driver Class Initialized
INFO - 2023-06-07 06:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:37:49 --> Form Validation Class Initialized
INFO - 2023-06-07 06:37:49 --> Controller Class Initialized
INFO - 2023-06-07 06:37:49 --> Model "m_user" initialized
INFO - 2023-06-07 06:37:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:37:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:37:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-07 06:37:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:37:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:37:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-07 06:37:49 --> Final output sent to browser
INFO - 2023-06-07 06:37:50 --> Config Class Initialized
INFO - 2023-06-07 06:37:50 --> Hooks Class Initialized
INFO - 2023-06-07 06:37:50 --> Utf8 Class Initialized
INFO - 2023-06-07 06:37:50 --> URI Class Initialized
INFO - 2023-06-07 06:37:50 --> Router Class Initialized
INFO - 2023-06-07 06:37:50 --> Output Class Initialized
INFO - 2023-06-07 06:37:50 --> Security Class Initialized
INFO - 2023-06-07 06:37:50 --> Input Class Initialized
INFO - 2023-06-07 06:37:50 --> Language Class Initialized
INFO - 2023-06-07 06:37:50 --> Loader Class Initialized
INFO - 2023-06-07 06:37:50 --> Helper loaded: url_helper
INFO - 2023-06-07 06:37:50 --> Helper loaded: form_helper
INFO - 2023-06-07 06:37:50 --> Database Driver Class Initialized
INFO - 2023-06-07 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:37:50 --> Form Validation Class Initialized
INFO - 2023-06-07 06:37:50 --> Controller Class Initialized
INFO - 2023-06-07 06:37:50 --> Model "m_datatrain" initialized
INFO - 2023-06-07 06:37:50 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:37:50 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:37:50 --> Model "M_solusi" initialized
INFO - 2023-06-07 06:37:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:37:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:37:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-07 06:37:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-07 06:37:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:37:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:37:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-07 06:37:50 --> Final output sent to browser
INFO - 2023-06-07 06:38:39 --> Config Class Initialized
INFO - 2023-06-07 06:38:39 --> Hooks Class Initialized
INFO - 2023-06-07 06:38:39 --> Utf8 Class Initialized
INFO - 2023-06-07 06:38:39 --> URI Class Initialized
INFO - 2023-06-07 06:38:39 --> Router Class Initialized
INFO - 2023-06-07 06:38:39 --> Output Class Initialized
INFO - 2023-06-07 06:38:39 --> Security Class Initialized
INFO - 2023-06-07 06:38:39 --> Input Class Initialized
INFO - 2023-06-07 06:38:39 --> Language Class Initialized
INFO - 2023-06-07 06:38:39 --> Loader Class Initialized
INFO - 2023-06-07 06:38:39 --> Helper loaded: url_helper
INFO - 2023-06-07 06:38:39 --> Helper loaded: form_helper
INFO - 2023-06-07 06:38:39 --> Database Driver Class Initialized
INFO - 2023-06-07 06:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:38:39 --> Form Validation Class Initialized
INFO - 2023-06-07 06:38:39 --> Controller Class Initialized
INFO - 2023-06-07 06:38:39 --> Model "m_datatrain" initialized
INFO - 2023-06-07 06:38:39 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 06:38:39 --> Model "m_datatest" initialized
INFO - 2023-06-07 06:38:39 --> Model "M_solusi" initialized
ERROR - 2023-06-07 06:38:39 --> Severity: Notice --> Undefined variable: prob_A1GangguanMood C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 826
ERROR - 2023-06-07 06:38:39 --> Severity: Notice --> Undefined variable: prob_A1Ringan C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 827
ERROR - 2023-06-07 06:38:39 --> Severity: Notice --> Undefined variable: prob_A1Sedang C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 828
ERROR - 2023-06-07 06:38:39 --> Severity: Notice --> Undefined variable: prob_A1Berat C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 829
ERROR - 2023-06-07 06:38:39 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 847
ERROR - 2023-06-07 06:38:39 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 848
ERROR - 2023-06-07 06:38:39 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 849
ERROR - 2023-06-07 06:38:39 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_diagnosa.php 850
INFO - 2023-06-07 06:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 06:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 06:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_hasil.php
INFO - 2023-06-07 06:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-07 06:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 06:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 06:38:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-07 06:38:39 --> Final output sent to browser
INFO - 2023-06-07 09:37:09 --> Config Class Initialized
INFO - 2023-06-07 09:37:09 --> Hooks Class Initialized
INFO - 2023-06-07 09:37:09 --> Utf8 Class Initialized
INFO - 2023-06-07 09:37:09 --> URI Class Initialized
INFO - 2023-06-07 09:37:09 --> Router Class Initialized
INFO - 2023-06-07 09:37:09 --> Output Class Initialized
INFO - 2023-06-07 09:37:09 --> Security Class Initialized
INFO - 2023-06-07 09:37:09 --> Input Class Initialized
INFO - 2023-06-07 09:37:09 --> Language Class Initialized
INFO - 2023-06-07 09:37:09 --> Loader Class Initialized
INFO - 2023-06-07 09:37:09 --> Helper loaded: url_helper
INFO - 2023-06-07 09:37:09 --> Helper loaded: form_helper
INFO - 2023-06-07 09:37:09 --> Database Driver Class Initialized
INFO - 2023-06-07 09:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:37:09 --> Form Validation Class Initialized
INFO - 2023-06-07 09:37:09 --> Controller Class Initialized
INFO - 2023-06-07 09:37:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-07 09:37:09 --> Final output sent to browser
INFO - 2023-06-07 09:37:14 --> Config Class Initialized
INFO - 2023-06-07 09:37:14 --> Hooks Class Initialized
INFO - 2023-06-07 09:37:14 --> Utf8 Class Initialized
INFO - 2023-06-07 09:37:14 --> URI Class Initialized
INFO - 2023-06-07 09:37:14 --> Router Class Initialized
INFO - 2023-06-07 09:37:14 --> Output Class Initialized
INFO - 2023-06-07 09:37:14 --> Security Class Initialized
INFO - 2023-06-07 09:37:14 --> Input Class Initialized
INFO - 2023-06-07 09:37:14 --> Language Class Initialized
INFO - 2023-06-07 09:37:14 --> Loader Class Initialized
INFO - 2023-06-07 09:37:14 --> Helper loaded: url_helper
INFO - 2023-06-07 09:37:14 --> Helper loaded: form_helper
INFO - 2023-06-07 09:37:14 --> Database Driver Class Initialized
INFO - 2023-06-07 09:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:37:14 --> Form Validation Class Initialized
INFO - 2023-06-07 09:37:14 --> Controller Class Initialized
INFO - 2023-06-07 09:37:14 --> Model "m_user" initialized
INFO - 2023-06-07 09:37:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-07 09:37:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-07 09:37:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-07 09:37:14 --> Final output sent to browser
INFO - 2023-06-07 09:37:30 --> Config Class Initialized
INFO - 2023-06-07 09:37:30 --> Hooks Class Initialized
INFO - 2023-06-07 09:37:30 --> Utf8 Class Initialized
INFO - 2023-06-07 09:37:30 --> URI Class Initialized
INFO - 2023-06-07 09:37:30 --> Router Class Initialized
INFO - 2023-06-07 09:37:30 --> Output Class Initialized
INFO - 2023-06-07 09:37:30 --> Security Class Initialized
INFO - 2023-06-07 09:37:30 --> Input Class Initialized
INFO - 2023-06-07 09:37:30 --> Language Class Initialized
INFO - 2023-06-07 09:37:30 --> Loader Class Initialized
INFO - 2023-06-07 09:37:30 --> Helper loaded: url_helper
INFO - 2023-06-07 09:37:30 --> Helper loaded: form_helper
INFO - 2023-06-07 09:37:30 --> Database Driver Class Initialized
INFO - 2023-06-07 09:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:37:30 --> Form Validation Class Initialized
INFO - 2023-06-07 09:37:30 --> Controller Class Initialized
INFO - 2023-06-07 09:37:30 --> Model "m_user" initialized
INFO - 2023-06-07 09:37:31 --> Config Class Initialized
INFO - 2023-06-07 09:37:31 --> Hooks Class Initialized
INFO - 2023-06-07 09:37:31 --> Utf8 Class Initialized
INFO - 2023-06-07 09:37:31 --> URI Class Initialized
INFO - 2023-06-07 09:37:31 --> Router Class Initialized
INFO - 2023-06-07 09:37:31 --> Output Class Initialized
INFO - 2023-06-07 09:37:31 --> Security Class Initialized
INFO - 2023-06-07 09:37:31 --> Input Class Initialized
INFO - 2023-06-07 09:37:31 --> Language Class Initialized
INFO - 2023-06-07 09:37:31 --> Loader Class Initialized
INFO - 2023-06-07 09:37:31 --> Helper loaded: url_helper
INFO - 2023-06-07 09:37:31 --> Helper loaded: form_helper
INFO - 2023-06-07 09:37:31 --> Database Driver Class Initialized
INFO - 2023-06-07 09:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:37:31 --> Form Validation Class Initialized
INFO - 2023-06-07 09:37:31 --> Controller Class Initialized
INFO - 2023-06-07 09:37:31 --> Model "m_user" initialized
INFO - 2023-06-07 09:37:31 --> Model "m_datatrain" initialized
INFO - 2023-06-07 09:37:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 09:37:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 09:37:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 09:37:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 09:37:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 09:37:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-07 09:37:31 --> Final output sent to browser
INFO - 2023-06-07 09:37:34 --> Config Class Initialized
INFO - 2023-06-07 09:37:34 --> Hooks Class Initialized
INFO - 2023-06-07 09:37:34 --> Utf8 Class Initialized
INFO - 2023-06-07 09:37:34 --> URI Class Initialized
INFO - 2023-06-07 09:37:34 --> Router Class Initialized
INFO - 2023-06-07 09:37:34 --> Output Class Initialized
INFO - 2023-06-07 09:37:34 --> Security Class Initialized
INFO - 2023-06-07 09:37:34 --> Input Class Initialized
INFO - 2023-06-07 09:37:34 --> Language Class Initialized
INFO - 2023-06-07 09:37:34 --> Loader Class Initialized
INFO - 2023-06-07 09:37:34 --> Helper loaded: url_helper
INFO - 2023-06-07 09:37:34 --> Helper loaded: form_helper
INFO - 2023-06-07 09:37:34 --> Database Driver Class Initialized
INFO - 2023-06-07 09:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:37:34 --> Form Validation Class Initialized
INFO - 2023-06-07 09:37:34 --> Controller Class Initialized
INFO - 2023-06-07 09:37:34 --> Model "m_datatest" initialized
INFO - 2023-06-07 09:37:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 09:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 09:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 09:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 09:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 09:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 09:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 09:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 09:37:34 --> Final output sent to browser
INFO - 2023-06-07 09:37:45 --> Config Class Initialized
INFO - 2023-06-07 09:37:45 --> Hooks Class Initialized
INFO - 2023-06-07 09:37:45 --> Utf8 Class Initialized
INFO - 2023-06-07 09:37:45 --> URI Class Initialized
INFO - 2023-06-07 09:37:45 --> Router Class Initialized
INFO - 2023-06-07 09:37:45 --> Output Class Initialized
INFO - 2023-06-07 09:37:45 --> Security Class Initialized
INFO - 2023-06-07 09:37:45 --> Input Class Initialized
INFO - 2023-06-07 09:37:45 --> Language Class Initialized
INFO - 2023-06-07 09:37:45 --> Loader Class Initialized
INFO - 2023-06-07 09:37:45 --> Helper loaded: url_helper
INFO - 2023-06-07 09:37:45 --> Helper loaded: form_helper
INFO - 2023-06-07 09:37:45 --> Database Driver Class Initialized
INFO - 2023-06-07 09:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:37:45 --> Form Validation Class Initialized
INFO - 2023-06-07 09:37:45 --> Controller Class Initialized
INFO - 2023-06-07 09:37:45 --> Model "m_datatest" initialized
INFO - 2023-06-07 09:37:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 09:37:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 09:37:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 09:37:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 09:37:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 09:37:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 09:37:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 09:37:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 09:37:46 --> Final output sent to browser
INFO - 2023-06-07 09:52:07 --> Config Class Initialized
INFO - 2023-06-07 09:52:07 --> Hooks Class Initialized
INFO - 2023-06-07 09:52:07 --> Utf8 Class Initialized
INFO - 2023-06-07 09:52:07 --> URI Class Initialized
INFO - 2023-06-07 09:52:07 --> Router Class Initialized
INFO - 2023-06-07 09:52:07 --> Output Class Initialized
INFO - 2023-06-07 09:52:07 --> Security Class Initialized
INFO - 2023-06-07 09:52:07 --> Input Class Initialized
INFO - 2023-06-07 09:52:07 --> Language Class Initialized
INFO - 2023-06-07 09:52:07 --> Loader Class Initialized
INFO - 2023-06-07 09:52:07 --> Helper loaded: url_helper
INFO - 2023-06-07 09:52:07 --> Helper loaded: form_helper
INFO - 2023-06-07 09:52:07 --> Database Driver Class Initialized
INFO - 2023-06-07 09:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:52:07 --> Form Validation Class Initialized
INFO - 2023-06-07 09:52:07 --> Controller Class Initialized
INFO - 2023-06-07 09:52:07 --> Model "m_datatest" initialized
INFO - 2023-06-07 09:52:07 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 09:52:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 09:52:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 09:52:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 09:52:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 09:52:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 09:52:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 09:52:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 09:52:07 --> Final output sent to browser
INFO - 2023-06-07 10:03:24 --> Config Class Initialized
INFO - 2023-06-07 10:03:24 --> Hooks Class Initialized
INFO - 2023-06-07 10:03:24 --> Utf8 Class Initialized
INFO - 2023-06-07 10:03:24 --> URI Class Initialized
INFO - 2023-06-07 10:03:24 --> Router Class Initialized
INFO - 2023-06-07 10:03:24 --> Output Class Initialized
INFO - 2023-06-07 10:03:24 --> Security Class Initialized
INFO - 2023-06-07 10:03:24 --> Input Class Initialized
INFO - 2023-06-07 10:03:24 --> Language Class Initialized
INFO - 2023-06-07 10:03:24 --> Loader Class Initialized
INFO - 2023-06-07 10:03:24 --> Helper loaded: url_helper
INFO - 2023-06-07 10:03:24 --> Helper loaded: form_helper
INFO - 2023-06-07 10:03:25 --> Database Driver Class Initialized
INFO - 2023-06-07 10:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:03:25 --> Form Validation Class Initialized
INFO - 2023-06-07 10:03:25 --> Controller Class Initialized
INFO - 2023-06-07 10:03:25 --> Model "m_datatest" initialized
INFO - 2023-06-07 10:03:25 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 10:03:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 10:03:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 10:03:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 10:03:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 10:03:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 10:03:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 10:03:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 10:03:25 --> Final output sent to browser
INFO - 2023-06-07 10:06:58 --> Config Class Initialized
INFO - 2023-06-07 10:06:58 --> Hooks Class Initialized
INFO - 2023-06-07 10:06:58 --> Utf8 Class Initialized
INFO - 2023-06-07 10:06:58 --> URI Class Initialized
INFO - 2023-06-07 10:06:58 --> Router Class Initialized
INFO - 2023-06-07 10:06:58 --> Output Class Initialized
INFO - 2023-06-07 10:06:58 --> Security Class Initialized
INFO - 2023-06-07 10:06:58 --> Input Class Initialized
INFO - 2023-06-07 10:06:58 --> Language Class Initialized
INFO - 2023-06-07 10:06:58 --> Loader Class Initialized
INFO - 2023-06-07 10:06:58 --> Helper loaded: url_helper
INFO - 2023-06-07 10:06:58 --> Helper loaded: form_helper
INFO - 2023-06-07 10:06:58 --> Database Driver Class Initialized
INFO - 2023-06-07 10:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:06:58 --> Form Validation Class Initialized
INFO - 2023-06-07 10:06:58 --> Controller Class Initialized
INFO - 2023-06-07 10:06:58 --> Model "m_datatest" initialized
INFO - 2023-06-07 10:06:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 10:06:59 --> Final output sent to browser
INFO - 2023-06-07 10:16:51 --> Config Class Initialized
INFO - 2023-06-07 10:16:51 --> Hooks Class Initialized
INFO - 2023-06-07 10:16:51 --> Utf8 Class Initialized
INFO - 2023-06-07 10:16:51 --> URI Class Initialized
INFO - 2023-06-07 10:16:51 --> Router Class Initialized
INFO - 2023-06-07 10:16:51 --> Output Class Initialized
INFO - 2023-06-07 10:16:51 --> Security Class Initialized
INFO - 2023-06-07 10:16:51 --> Input Class Initialized
INFO - 2023-06-07 10:16:51 --> Language Class Initialized
INFO - 2023-06-07 10:16:51 --> Loader Class Initialized
INFO - 2023-06-07 10:16:51 --> Helper loaded: url_helper
INFO - 2023-06-07 10:16:51 --> Helper loaded: form_helper
INFO - 2023-06-07 10:16:51 --> Database Driver Class Initialized
INFO - 2023-06-07 10:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:16:51 --> Form Validation Class Initialized
INFO - 2023-06-07 10:16:51 --> Controller Class Initialized
INFO - 2023-06-07 10:16:51 --> Model "m_datatest" initialized
INFO - 2023-06-07 10:16:51 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 10:16:51 --> Final output sent to browser
INFO - 2023-06-07 10:26:04 --> Config Class Initialized
INFO - 2023-06-07 10:26:04 --> Hooks Class Initialized
INFO - 2023-06-07 10:26:04 --> Utf8 Class Initialized
INFO - 2023-06-07 10:26:04 --> URI Class Initialized
INFO - 2023-06-07 10:26:04 --> Router Class Initialized
INFO - 2023-06-07 10:26:04 --> Output Class Initialized
INFO - 2023-06-07 10:26:04 --> Security Class Initialized
INFO - 2023-06-07 10:26:04 --> Input Class Initialized
INFO - 2023-06-07 10:26:04 --> Language Class Initialized
INFO - 2023-06-07 10:26:04 --> Loader Class Initialized
INFO - 2023-06-07 10:26:04 --> Helper loaded: url_helper
INFO - 2023-06-07 10:26:04 --> Helper loaded: form_helper
INFO - 2023-06-07 10:26:04 --> Database Driver Class Initialized
INFO - 2023-06-07 10:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:26:04 --> Form Validation Class Initialized
INFO - 2023-06-07 10:26:04 --> Controller Class Initialized
INFO - 2023-06-07 10:26:04 --> Model "m_datatest" initialized
INFO - 2023-06-07 10:26:04 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 10:26:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 10:26:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 10:26:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 10:26:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 10:26:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 10:26:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 10:26:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 10:26:05 --> Final output sent to browser
INFO - 2023-06-07 10:26:25 --> Config Class Initialized
INFO - 2023-06-07 10:26:25 --> Hooks Class Initialized
INFO - 2023-06-07 10:26:25 --> Utf8 Class Initialized
INFO - 2023-06-07 10:26:25 --> URI Class Initialized
INFO - 2023-06-07 10:26:25 --> Router Class Initialized
INFO - 2023-06-07 10:26:25 --> Output Class Initialized
INFO - 2023-06-07 10:26:25 --> Security Class Initialized
INFO - 2023-06-07 10:26:25 --> Input Class Initialized
INFO - 2023-06-07 10:26:25 --> Language Class Initialized
INFO - 2023-06-07 10:26:25 --> Loader Class Initialized
INFO - 2023-06-07 10:26:25 --> Helper loaded: url_helper
INFO - 2023-06-07 10:26:25 --> Helper loaded: form_helper
INFO - 2023-06-07 10:26:25 --> Database Driver Class Initialized
INFO - 2023-06-07 10:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:26:25 --> Form Validation Class Initialized
INFO - 2023-06-07 10:26:25 --> Controller Class Initialized
INFO - 2023-06-07 10:26:25 --> Model "m_datatest" initialized
INFO - 2023-06-07 10:26:25 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 10:26:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 10:26:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 10:26:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 10:26:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 10:26:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 10:26:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 10:26:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 10:26:26 --> Final output sent to browser
INFO - 2023-06-07 10:27:12 --> Config Class Initialized
INFO - 2023-06-07 10:27:12 --> Hooks Class Initialized
INFO - 2023-06-07 10:27:12 --> Utf8 Class Initialized
INFO - 2023-06-07 10:27:12 --> URI Class Initialized
INFO - 2023-06-07 10:27:12 --> Router Class Initialized
INFO - 2023-06-07 10:27:12 --> Output Class Initialized
INFO - 2023-06-07 10:27:12 --> Security Class Initialized
INFO - 2023-06-07 10:27:12 --> Input Class Initialized
INFO - 2023-06-07 10:27:12 --> Language Class Initialized
INFO - 2023-06-07 10:27:12 --> Loader Class Initialized
INFO - 2023-06-07 10:27:12 --> Helper loaded: url_helper
INFO - 2023-06-07 10:27:12 --> Helper loaded: form_helper
INFO - 2023-06-07 10:27:12 --> Database Driver Class Initialized
INFO - 2023-06-07 10:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:27:12 --> Form Validation Class Initialized
INFO - 2023-06-07 10:27:12 --> Controller Class Initialized
INFO - 2023-06-07 10:27:12 --> Model "m_datatest" initialized
INFO - 2023-06-07 10:27:12 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 10:27:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 10:27:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 10:27:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 10:27:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 10:27:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 10:27:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 10:27:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 10:27:13 --> Final output sent to browser
INFO - 2023-06-07 10:27:44 --> Config Class Initialized
INFO - 2023-06-07 10:27:44 --> Hooks Class Initialized
INFO - 2023-06-07 10:27:44 --> Utf8 Class Initialized
INFO - 2023-06-07 10:27:44 --> URI Class Initialized
INFO - 2023-06-07 10:27:44 --> Router Class Initialized
INFO - 2023-06-07 10:27:44 --> Output Class Initialized
INFO - 2023-06-07 10:27:44 --> Security Class Initialized
INFO - 2023-06-07 10:27:44 --> Input Class Initialized
INFO - 2023-06-07 10:27:44 --> Language Class Initialized
INFO - 2023-06-07 10:27:44 --> Loader Class Initialized
INFO - 2023-06-07 10:27:44 --> Helper loaded: url_helper
INFO - 2023-06-07 10:27:44 --> Helper loaded: form_helper
INFO - 2023-06-07 10:27:44 --> Database Driver Class Initialized
INFO - 2023-06-07 10:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:27:44 --> Form Validation Class Initialized
INFO - 2023-06-07 10:27:44 --> Controller Class Initialized
INFO - 2023-06-07 10:27:44 --> Model "m_datatest" initialized
INFO - 2023-06-07 10:27:44 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 10:27:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 10:27:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 10:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 10:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 10:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 10:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 10:27:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 10:27:45 --> Final output sent to browser
INFO - 2023-06-07 10:29:47 --> Config Class Initialized
INFO - 2023-06-07 10:29:47 --> Hooks Class Initialized
INFO - 2023-06-07 10:29:47 --> Utf8 Class Initialized
INFO - 2023-06-07 10:29:47 --> URI Class Initialized
INFO - 2023-06-07 10:29:47 --> Router Class Initialized
INFO - 2023-06-07 10:29:47 --> Output Class Initialized
INFO - 2023-06-07 10:29:47 --> Security Class Initialized
INFO - 2023-06-07 10:29:47 --> Input Class Initialized
INFO - 2023-06-07 10:29:47 --> Language Class Initialized
INFO - 2023-06-07 10:29:47 --> Loader Class Initialized
INFO - 2023-06-07 10:29:47 --> Helper loaded: url_helper
INFO - 2023-06-07 10:29:47 --> Helper loaded: form_helper
INFO - 2023-06-07 10:29:47 --> Database Driver Class Initialized
INFO - 2023-06-07 10:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:29:47 --> Form Validation Class Initialized
INFO - 2023-06-07 10:29:47 --> Controller Class Initialized
INFO - 2023-06-07 10:29:47 --> Model "m_datatest" initialized
INFO - 2023-06-07 10:29:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 10:29:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 10:29:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 10:29:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-07 10:29:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 10:29:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 10:29:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 10:29:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 10:29:48 --> Final output sent to browser
INFO - 2023-06-07 10:31:21 --> Config Class Initialized
INFO - 2023-06-07 10:31:21 --> Hooks Class Initialized
INFO - 2023-06-07 10:31:21 --> Utf8 Class Initialized
INFO - 2023-06-07 10:31:21 --> URI Class Initialized
INFO - 2023-06-07 10:31:21 --> Router Class Initialized
INFO - 2023-06-07 10:31:21 --> Output Class Initialized
INFO - 2023-06-07 10:31:21 --> Security Class Initialized
INFO - 2023-06-07 10:31:21 --> Input Class Initialized
INFO - 2023-06-07 10:31:21 --> Language Class Initialized
INFO - 2023-06-07 10:31:21 --> Loader Class Initialized
INFO - 2023-06-07 10:31:21 --> Helper loaded: url_helper
INFO - 2023-06-07 10:31:21 --> Helper loaded: form_helper
INFO - 2023-06-07 10:31:21 --> Database Driver Class Initialized
INFO - 2023-06-07 10:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:31:21 --> Form Validation Class Initialized
INFO - 2023-06-07 10:31:21 --> Controller Class Initialized
INFO - 2023-06-07 10:31:21 --> Model "m_datatrain" initialized
INFO - 2023-06-07 10:31:21 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 10:31:21 --> Model "m_datatest" initialized
INFO - 2023-06-07 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-06-07 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 10:31:21 --> Final output sent to browser
INFO - 2023-06-07 10:53:58 --> Config Class Initialized
INFO - 2023-06-07 10:53:58 --> Hooks Class Initialized
INFO - 2023-06-07 10:53:58 --> Utf8 Class Initialized
INFO - 2023-06-07 10:53:58 --> URI Class Initialized
INFO - 2023-06-07 10:53:58 --> Router Class Initialized
INFO - 2023-06-07 10:53:58 --> Output Class Initialized
INFO - 2023-06-07 10:53:58 --> Security Class Initialized
INFO - 2023-06-07 10:53:58 --> Input Class Initialized
INFO - 2023-06-07 10:53:58 --> Language Class Initialized
INFO - 2023-06-07 10:53:58 --> Loader Class Initialized
INFO - 2023-06-07 10:53:58 --> Helper loaded: url_helper
INFO - 2023-06-07 10:53:58 --> Helper loaded: form_helper
INFO - 2023-06-07 10:53:58 --> Database Driver Class Initialized
INFO - 2023-06-07 10:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:53:58 --> Form Validation Class Initialized
INFO - 2023-06-07 10:53:58 --> Controller Class Initialized
INFO - 2023-06-07 10:53:58 --> Model "m_datatest" initialized
INFO - 2023-06-07 10:53:58 --> Model "m_penghitungan" initialized
INFO - 2023-06-07 10:53:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 10:53:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 10:53:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-07 10:53:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 10:53:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 10:53:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 10:53:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 10:53:58 --> Final output sent to browser
INFO - 2023-06-07 10:54:00 --> Config Class Initialized
INFO - 2023-06-07 10:54:00 --> Hooks Class Initialized
INFO - 2023-06-07 10:54:00 --> Utf8 Class Initialized
INFO - 2023-06-07 10:54:00 --> URI Class Initialized
INFO - 2023-06-07 10:54:00 --> Router Class Initialized
INFO - 2023-06-07 10:54:00 --> Output Class Initialized
INFO - 2023-06-07 10:54:00 --> Security Class Initialized
INFO - 2023-06-07 10:54:00 --> Input Class Initialized
INFO - 2023-06-07 10:54:00 --> Language Class Initialized
INFO - 2023-06-07 10:54:00 --> Loader Class Initialized
INFO - 2023-06-07 10:54:00 --> Helper loaded: url_helper
INFO - 2023-06-07 10:54:00 --> Helper loaded: form_helper
INFO - 2023-06-07 10:54:00 --> Database Driver Class Initialized
INFO - 2023-06-07 10:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:54:00 --> Form Validation Class Initialized
INFO - 2023-06-07 10:54:00 --> Controller Class Initialized
INFO - 2023-06-07 10:54:00 --> Model "m_datatrain" initialized
INFO - 2023-06-07 10:54:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-07 10:54:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-07 10:54:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-07 10:54:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-07 10:54:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-07 10:54:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-07 10:54:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-07 10:54:00 --> Final output sent to browser
INFO - 2023-06-07 11:02:57 --> Config Class Initialized
INFO - 2023-06-07 11:02:57 --> Hooks Class Initialized
INFO - 2023-06-07 11:02:57 --> Utf8 Class Initialized
INFO - 2023-06-07 11:02:57 --> URI Class Initialized
INFO - 2023-06-07 11:02:57 --> Router Class Initialized
INFO - 2023-06-07 11:02:57 --> Output Class Initialized
INFO - 2023-06-07 11:02:57 --> Security Class Initialized
INFO - 2023-06-07 11:02:57 --> Input Class Initialized
INFO - 2023-06-07 11:02:57 --> Language Class Initialized
INFO - 2023-06-07 11:02:57 --> Loader Class Initialized
INFO - 2023-06-07 11:02:57 --> Helper loaded: url_helper
INFO - 2023-06-07 11:02:57 --> Helper loaded: form_helper
INFO - 2023-06-07 11:02:57 --> Database Driver Class Initialized
INFO - 2023-06-07 11:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 11:02:57 --> Form Validation Class Initialized
INFO - 2023-06-07 11:02:57 --> Controller Class Initialized
INFO - 2023-06-07 11:02:57 --> Model "m_datatest" initialized
INFO - 2023-06-07 11:02:57 --> Final output sent to browser
INFO - 2023-06-07 11:05:10 --> Config Class Initialized
INFO - 2023-06-07 11:05:10 --> Hooks Class Initialized
INFO - 2023-06-07 11:05:10 --> Utf8 Class Initialized
INFO - 2023-06-07 11:05:10 --> URI Class Initialized
INFO - 2023-06-07 11:05:10 --> Router Class Initialized
INFO - 2023-06-07 11:05:10 --> Output Class Initialized
INFO - 2023-06-07 11:05:10 --> Security Class Initialized
INFO - 2023-06-07 11:05:10 --> Input Class Initialized
INFO - 2023-06-07 11:05:10 --> Language Class Initialized
INFO - 2023-06-07 11:05:10 --> Loader Class Initialized
INFO - 2023-06-07 11:05:10 --> Helper loaded: url_helper
INFO - 2023-06-07 11:05:10 --> Helper loaded: form_helper
INFO - 2023-06-07 11:05:10 --> Database Driver Class Initialized
INFO - 2023-06-07 11:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 11:05:10 --> Form Validation Class Initialized
INFO - 2023-06-07 11:05:10 --> Controller Class Initialized
INFO - 2023-06-07 11:05:10 --> Model "m_datatest" initialized
INFO - 2023-06-07 11:05:10 --> Final output sent to browser
INFO - 2023-06-07 11:07:05 --> Config Class Initialized
INFO - 2023-06-07 11:07:05 --> Hooks Class Initialized
INFO - 2023-06-07 11:07:05 --> Utf8 Class Initialized
INFO - 2023-06-07 11:07:05 --> URI Class Initialized
INFO - 2023-06-07 11:07:05 --> Router Class Initialized
INFO - 2023-06-07 11:07:05 --> Output Class Initialized
INFO - 2023-06-07 11:07:05 --> Security Class Initialized
INFO - 2023-06-07 11:07:05 --> Input Class Initialized
INFO - 2023-06-07 11:07:05 --> Language Class Initialized
INFO - 2023-06-07 11:07:05 --> Loader Class Initialized
INFO - 2023-06-07 11:07:05 --> Helper loaded: url_helper
INFO - 2023-06-07 11:07:05 --> Helper loaded: form_helper
INFO - 2023-06-07 11:07:05 --> Database Driver Class Initialized
INFO - 2023-06-07 11:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 11:07:05 --> Form Validation Class Initialized
INFO - 2023-06-07 11:07:05 --> Controller Class Initialized
INFO - 2023-06-07 11:07:05 --> Model "m_datatest" initialized
INFO - 2023-06-07 11:07:05 --> Final output sent to browser
INFO - 2023-06-07 11:09:44 --> Config Class Initialized
INFO - 2023-06-07 11:09:44 --> Hooks Class Initialized
INFO - 2023-06-07 11:09:44 --> Utf8 Class Initialized
INFO - 2023-06-07 11:09:44 --> URI Class Initialized
INFO - 2023-06-07 11:09:44 --> Router Class Initialized
INFO - 2023-06-07 11:09:44 --> Output Class Initialized
INFO - 2023-06-07 11:09:44 --> Security Class Initialized
INFO - 2023-06-07 11:09:44 --> Input Class Initialized
INFO - 2023-06-07 11:09:44 --> Language Class Initialized
INFO - 2023-06-07 11:09:44 --> Loader Class Initialized
INFO - 2023-06-07 11:09:44 --> Helper loaded: url_helper
INFO - 2023-06-07 11:09:44 --> Helper loaded: form_helper
INFO - 2023-06-07 11:09:44 --> Database Driver Class Initialized
INFO - 2023-06-07 11:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 11:09:44 --> Form Validation Class Initialized
INFO - 2023-06-07 11:09:44 --> Controller Class Initialized
INFO - 2023-06-07 11:09:44 --> Model "m_datatest" initialized
INFO - 2023-06-07 11:09:44 --> Final output sent to browser
INFO - 2023-06-07 11:14:54 --> Config Class Initialized
INFO - 2023-06-07 11:14:54 --> Hooks Class Initialized
INFO - 2023-06-07 11:14:54 --> Utf8 Class Initialized
INFO - 2023-06-07 11:14:54 --> URI Class Initialized
INFO - 2023-06-07 11:14:54 --> Router Class Initialized
INFO - 2023-06-07 11:14:54 --> Output Class Initialized
INFO - 2023-06-07 11:14:54 --> Security Class Initialized
INFO - 2023-06-07 11:14:54 --> Input Class Initialized
INFO - 2023-06-07 11:14:54 --> Language Class Initialized
INFO - 2023-06-07 11:14:54 --> Loader Class Initialized
INFO - 2023-06-07 11:14:54 --> Helper loaded: url_helper
INFO - 2023-06-07 11:14:54 --> Helper loaded: form_helper
INFO - 2023-06-07 11:14:54 --> Database Driver Class Initialized
INFO - 2023-06-07 11:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 11:14:54 --> Form Validation Class Initialized
INFO - 2023-06-07 11:14:54 --> Controller Class Initialized
INFO - 2023-06-07 11:14:54 --> Model "m_datatest" initialized
ERROR - 2023-06-07 11:14:54 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 33
ERROR - 2023-06-07 11:14:54 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 33
INFO - 2023-06-07 11:14:54 --> Final output sent to browser
INFO - 2023-06-07 11:15:47 --> Config Class Initialized
INFO - 2023-06-07 11:15:47 --> Hooks Class Initialized
INFO - 2023-06-07 11:15:47 --> Utf8 Class Initialized
INFO - 2023-06-07 11:15:48 --> URI Class Initialized
INFO - 2023-06-07 11:15:48 --> Router Class Initialized
INFO - 2023-06-07 11:15:48 --> Output Class Initialized
INFO - 2023-06-07 11:15:48 --> Security Class Initialized
INFO - 2023-06-07 11:15:48 --> Input Class Initialized
INFO - 2023-06-07 11:15:48 --> Language Class Initialized
INFO - 2023-06-07 11:15:48 --> Loader Class Initialized
INFO - 2023-06-07 11:15:48 --> Helper loaded: url_helper
INFO - 2023-06-07 11:15:48 --> Helper loaded: form_helper
INFO - 2023-06-07 11:15:48 --> Database Driver Class Initialized
INFO - 2023-06-07 11:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 11:15:48 --> Form Validation Class Initialized
INFO - 2023-06-07 11:15:48 --> Controller Class Initialized
INFO - 2023-06-07 11:15:48 --> Model "m_datatest" initialized
ERROR - 2023-06-07 11:15:48 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 33
ERROR - 2023-06-07 11:15:48 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 33
INFO - 2023-06-07 11:15:48 --> Final output sent to browser
INFO - 2023-06-07 11:25:37 --> Config Class Initialized
INFO - 2023-06-07 11:25:37 --> Hooks Class Initialized
INFO - 2023-06-07 11:25:38 --> Utf8 Class Initialized
INFO - 2023-06-07 11:25:38 --> URI Class Initialized
INFO - 2023-06-07 11:25:38 --> Router Class Initialized
INFO - 2023-06-07 11:25:38 --> Output Class Initialized
INFO - 2023-06-07 11:25:38 --> Security Class Initialized
INFO - 2023-06-07 11:25:38 --> Input Class Initialized
INFO - 2023-06-07 11:25:38 --> Language Class Initialized
INFO - 2023-06-07 11:25:38 --> Loader Class Initialized
INFO - 2023-06-07 11:25:38 --> Helper loaded: url_helper
INFO - 2023-06-07 11:25:38 --> Helper loaded: form_helper
INFO - 2023-06-07 11:25:38 --> Database Driver Class Initialized
INFO - 2023-06-07 11:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 11:25:38 --> Form Validation Class Initialized
INFO - 2023-06-07 11:25:38 --> Controller Class Initialized
INFO - 2023-06-07 11:25:38 --> Model "m_datatest" initialized
ERROR - 2023-06-07 11:25:38 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 33
ERROR - 2023-06-07 11:25:38 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 33
ERROR - 2023-06-07 11:25:38 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 61
INFO - 2023-06-07 11:25:38 --> Final output sent to browser
INFO - 2023-06-07 11:25:39 --> Config Class Initialized
INFO - 2023-06-07 11:25:39 --> Hooks Class Initialized
INFO - 2023-06-07 11:25:39 --> Utf8 Class Initialized
INFO - 2023-06-07 11:25:39 --> URI Class Initialized
INFO - 2023-06-07 11:25:39 --> Router Class Initialized
INFO - 2023-06-07 11:25:39 --> Output Class Initialized
INFO - 2023-06-07 11:25:39 --> Security Class Initialized
INFO - 2023-06-07 11:25:39 --> Input Class Initialized
INFO - 2023-06-07 11:25:39 --> Language Class Initialized
INFO - 2023-06-07 11:25:39 --> Loader Class Initialized
INFO - 2023-06-07 11:25:39 --> Helper loaded: url_helper
INFO - 2023-06-07 11:25:39 --> Helper loaded: form_helper
INFO - 2023-06-07 11:25:39 --> Database Driver Class Initialized
INFO - 2023-06-07 11:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 11:25:39 --> Form Validation Class Initialized
INFO - 2023-06-07 11:25:39 --> Controller Class Initialized
INFO - 2023-06-07 11:25:39 --> Model "m_datatest" initialized
ERROR - 2023-06-07 11:25:39 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 33
ERROR - 2023-06-07 11:25:39 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 33
ERROR - 2023-06-07 11:25:39 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 61
INFO - 2023-06-07 11:25:39 --> Final output sent to browser
INFO - 2023-06-07 11:27:51 --> Config Class Initialized
INFO - 2023-06-07 11:27:51 --> Hooks Class Initialized
INFO - 2023-06-07 11:27:51 --> Utf8 Class Initialized
INFO - 2023-06-07 11:27:51 --> URI Class Initialized
INFO - 2023-06-07 11:27:51 --> Router Class Initialized
INFO - 2023-06-07 11:27:51 --> Output Class Initialized
INFO - 2023-06-07 11:27:51 --> Security Class Initialized
INFO - 2023-06-07 11:27:52 --> Input Class Initialized
INFO - 2023-06-07 11:27:52 --> Language Class Initialized
INFO - 2023-06-07 11:27:52 --> Loader Class Initialized
INFO - 2023-06-07 11:27:52 --> Helper loaded: url_helper
INFO - 2023-06-07 11:27:52 --> Helper loaded: form_helper
INFO - 2023-06-07 11:27:52 --> Database Driver Class Initialized
INFO - 2023-06-07 11:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 11:27:52 --> Form Validation Class Initialized
INFO - 2023-06-07 11:27:52 --> Controller Class Initialized
INFO - 2023-06-07 11:27:52 --> Model "m_datatest" initialized
ERROR - 2023-06-07 11:27:52 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 33
ERROR - 2023-06-07 11:27:52 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 33
ERROR - 2023-06-07 11:27:52 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_pengujian.php 61
INFO - 2023-06-07 11:27:52 --> Final output sent to browser
INFO - 2023-06-07 11:37:48 --> Config Class Initialized
INFO - 2023-06-07 11:37:48 --> Hooks Class Initialized
INFO - 2023-06-07 11:37:48 --> Utf8 Class Initialized
INFO - 2023-06-07 11:37:48 --> URI Class Initialized
INFO - 2023-06-07 11:37:48 --> Router Class Initialized
INFO - 2023-06-07 11:37:48 --> Output Class Initialized
INFO - 2023-06-07 11:37:48 --> Security Class Initialized
INFO - 2023-06-07 11:37:48 --> Input Class Initialized
INFO - 2023-06-07 11:37:48 --> Language Class Initialized
INFO - 2023-06-07 11:37:49 --> Loader Class Initialized
INFO - 2023-06-07 11:37:49 --> Helper loaded: url_helper
INFO - 2023-06-07 11:37:49 --> Helper loaded: form_helper
INFO - 2023-06-07 11:37:49 --> Database Driver Class Initialized
INFO - 2023-06-07 11:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 11:37:49 --> Form Validation Class Initialized
INFO - 2023-06-07 11:37:49 --> Controller Class Initialized
INFO - 2023-06-07 11:37:49 --> Model "m_datatest" initialized
INFO - 2023-06-07 11:37:49 --> Final output sent to browser
