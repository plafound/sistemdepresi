<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-09 05:58:49 --> Config Class Initialized
INFO - 2023-05-09 05:58:49 --> Hooks Class Initialized
INFO - 2023-05-09 05:58:50 --> Utf8 Class Initialized
INFO - 2023-05-09 05:58:50 --> URI Class Initialized
INFO - 2023-05-09 05:58:50 --> Router Class Initialized
INFO - 2023-05-09 05:58:50 --> Output Class Initialized
INFO - 2023-05-09 05:58:50 --> Security Class Initialized
INFO - 2023-05-09 05:58:50 --> Input Class Initialized
INFO - 2023-05-09 05:58:50 --> Language Class Initialized
INFO - 2023-05-09 05:58:50 --> Loader Class Initialized
INFO - 2023-05-09 05:58:50 --> Helper loaded: url_helper
INFO - 2023-05-09 05:58:50 --> Helper loaded: form_helper
INFO - 2023-05-09 05:58:50 --> Database Driver Class Initialized
INFO - 2023-05-09 05:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 05:58:50 --> Form Validation Class Initialized
INFO - 2023-05-09 05:58:50 --> Controller Class Initialized
INFO - 2023-05-09 05:58:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-09 05:58:50 --> Final output sent to browser
INFO - 2023-05-09 05:58:54 --> Config Class Initialized
INFO - 2023-05-09 05:58:54 --> Hooks Class Initialized
INFO - 2023-05-09 05:58:54 --> Utf8 Class Initialized
INFO - 2023-05-09 05:58:54 --> URI Class Initialized
INFO - 2023-05-09 05:58:54 --> Router Class Initialized
INFO - 2023-05-09 05:58:54 --> Output Class Initialized
INFO - 2023-05-09 05:58:54 --> Security Class Initialized
INFO - 2023-05-09 05:58:54 --> Input Class Initialized
INFO - 2023-05-09 05:58:54 --> Language Class Initialized
INFO - 2023-05-09 05:58:54 --> Loader Class Initialized
INFO - 2023-05-09 05:58:54 --> Helper loaded: url_helper
INFO - 2023-05-09 05:58:54 --> Helper loaded: form_helper
INFO - 2023-05-09 05:58:54 --> Database Driver Class Initialized
INFO - 2023-05-09 05:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 05:58:54 --> Form Validation Class Initialized
INFO - 2023-05-09 05:58:54 --> Controller Class Initialized
INFO - 2023-05-09 05:58:54 --> Model "m_user" initialized
INFO - 2023-05-09 05:58:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-09 05:58:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-09 05:58:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-09 05:58:54 --> Final output sent to browser
INFO - 2023-05-09 05:59:01 --> Config Class Initialized
INFO - 2023-05-09 05:59:01 --> Hooks Class Initialized
INFO - 2023-05-09 05:59:01 --> Utf8 Class Initialized
INFO - 2023-05-09 05:59:01 --> URI Class Initialized
INFO - 2023-05-09 05:59:01 --> Router Class Initialized
INFO - 2023-05-09 05:59:01 --> Output Class Initialized
INFO - 2023-05-09 05:59:01 --> Security Class Initialized
INFO - 2023-05-09 05:59:01 --> Input Class Initialized
INFO - 2023-05-09 05:59:01 --> Language Class Initialized
INFO - 2023-05-09 05:59:01 --> Loader Class Initialized
INFO - 2023-05-09 05:59:01 --> Helper loaded: url_helper
INFO - 2023-05-09 05:59:01 --> Helper loaded: form_helper
INFO - 2023-05-09 05:59:01 --> Database Driver Class Initialized
INFO - 2023-05-09 05:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 05:59:01 --> Form Validation Class Initialized
INFO - 2023-05-09 05:59:01 --> Controller Class Initialized
INFO - 2023-05-09 05:59:01 --> Model "m_user" initialized
INFO - 2023-05-09 05:59:01 --> Config Class Initialized
INFO - 2023-05-09 05:59:01 --> Hooks Class Initialized
INFO - 2023-05-09 05:59:01 --> Utf8 Class Initialized
INFO - 2023-05-09 05:59:01 --> URI Class Initialized
INFO - 2023-05-09 05:59:01 --> Router Class Initialized
INFO - 2023-05-09 05:59:01 --> Output Class Initialized
INFO - 2023-05-09 05:59:01 --> Security Class Initialized
INFO - 2023-05-09 05:59:01 --> Input Class Initialized
INFO - 2023-05-09 05:59:01 --> Language Class Initialized
INFO - 2023-05-09 05:59:01 --> Loader Class Initialized
INFO - 2023-05-09 05:59:02 --> Helper loaded: url_helper
INFO - 2023-05-09 05:59:02 --> Helper loaded: form_helper
INFO - 2023-05-09 05:59:02 --> Database Driver Class Initialized
INFO - 2023-05-09 05:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 05:59:02 --> Form Validation Class Initialized
INFO - 2023-05-09 05:59:02 --> Controller Class Initialized
INFO - 2023-05-09 05:59:02 --> Model "m_user" initialized
INFO - 2023-05-09 05:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-09 05:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-09 05:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-09 05:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-09 05:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-09 05:59:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-09 05:59:02 --> Final output sent to browser
INFO - 2023-05-09 05:59:04 --> Config Class Initialized
INFO - 2023-05-09 05:59:04 --> Hooks Class Initialized
INFO - 2023-05-09 05:59:04 --> Utf8 Class Initialized
INFO - 2023-05-09 05:59:04 --> URI Class Initialized
INFO - 2023-05-09 05:59:04 --> Router Class Initialized
INFO - 2023-05-09 05:59:04 --> Output Class Initialized
INFO - 2023-05-09 05:59:04 --> Security Class Initialized
INFO - 2023-05-09 05:59:04 --> Input Class Initialized
INFO - 2023-05-09 05:59:04 --> Language Class Initialized
INFO - 2023-05-09 05:59:04 --> Loader Class Initialized
INFO - 2023-05-09 05:59:04 --> Helper loaded: url_helper
INFO - 2023-05-09 05:59:04 --> Helper loaded: form_helper
INFO - 2023-05-09 05:59:04 --> Database Driver Class Initialized
INFO - 2023-05-09 05:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 05:59:04 --> Form Validation Class Initialized
INFO - 2023-05-09 05:59:04 --> Controller Class Initialized
INFO - 2023-05-09 05:59:04 --> Model "m_datatrain" initialized
INFO - 2023-05-09 05:59:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-09 05:59:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-09 05:59:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-09 05:59:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-09 05:59:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-09 05:59:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-09 05:59:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-09 05:59:04 --> Final output sent to browser
INFO - 2023-05-09 05:59:07 --> Config Class Initialized
INFO - 2023-05-09 05:59:07 --> Hooks Class Initialized
INFO - 2023-05-09 05:59:07 --> Utf8 Class Initialized
INFO - 2023-05-09 05:59:07 --> URI Class Initialized
INFO - 2023-05-09 05:59:07 --> Router Class Initialized
INFO - 2023-05-09 05:59:07 --> Output Class Initialized
INFO - 2023-05-09 05:59:07 --> Security Class Initialized
INFO - 2023-05-09 05:59:07 --> Input Class Initialized
INFO - 2023-05-09 05:59:07 --> Language Class Initialized
INFO - 2023-05-09 05:59:07 --> Loader Class Initialized
INFO - 2023-05-09 05:59:07 --> Helper loaded: url_helper
INFO - 2023-05-09 05:59:07 --> Helper loaded: form_helper
INFO - 2023-05-09 05:59:07 --> Database Driver Class Initialized
INFO - 2023-05-09 05:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 05:59:07 --> Form Validation Class Initialized
INFO - 2023-05-09 05:59:07 --> Controller Class Initialized
INFO - 2023-05-09 05:59:07 --> Model "m_datatrain" initialized
INFO - 2023-05-09 05:59:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-09 05:59:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-09 05:59:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-05-09 05:59:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-09 05:59:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-09 05:59:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-09 05:59:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-09 05:59:07 --> Final output sent to browser
INFO - 2023-05-09 05:59:12 --> Config Class Initialized
INFO - 2023-05-09 05:59:12 --> Hooks Class Initialized
INFO - 2023-05-09 05:59:12 --> Utf8 Class Initialized
INFO - 2023-05-09 05:59:12 --> URI Class Initialized
INFO - 2023-05-09 05:59:12 --> Router Class Initialized
INFO - 2023-05-09 05:59:12 --> Output Class Initialized
INFO - 2023-05-09 05:59:12 --> Security Class Initialized
INFO - 2023-05-09 05:59:12 --> Input Class Initialized
INFO - 2023-05-09 05:59:12 --> Language Class Initialized
INFO - 2023-05-09 05:59:12 --> Loader Class Initialized
INFO - 2023-05-09 05:59:12 --> Helper loaded: url_helper
INFO - 2023-05-09 05:59:12 --> Helper loaded: form_helper
INFO - 2023-05-09 05:59:12 --> Database Driver Class Initialized
INFO - 2023-05-09 05:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 05:59:12 --> Form Validation Class Initialized
INFO - 2023-05-09 05:59:12 --> Controller Class Initialized
INFO - 2023-05-09 05:59:12 --> Model "m_datatrain" initialized
INFO - 2023-05-09 05:59:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-09 05:59:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-09 05:59:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-09 05:59:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-09 05:59:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-09 05:59:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-09 05:59:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-09 05:59:12 --> Final output sent to browser
INFO - 2023-05-09 06:18:57 --> Config Class Initialized
INFO - 2023-05-09 06:18:57 --> Hooks Class Initialized
INFO - 2023-05-09 06:18:57 --> Utf8 Class Initialized
INFO - 2023-05-09 06:18:57 --> URI Class Initialized
INFO - 2023-05-09 06:18:57 --> Router Class Initialized
INFO - 2023-05-09 06:18:57 --> Output Class Initialized
INFO - 2023-05-09 06:18:57 --> Security Class Initialized
INFO - 2023-05-09 06:18:57 --> Input Class Initialized
INFO - 2023-05-09 06:18:57 --> Language Class Initialized
ERROR - 2023-05-09 06:18:57 --> 404 Page Not Found: C_todo_list/index
INFO - 2023-05-09 06:18:59 --> Config Class Initialized
INFO - 2023-05-09 06:18:59 --> Hooks Class Initialized
INFO - 2023-05-09 06:18:59 --> Utf8 Class Initialized
INFO - 2023-05-09 06:18:59 --> URI Class Initialized
INFO - 2023-05-09 06:18:59 --> Router Class Initialized
INFO - 2023-05-09 06:18:59 --> Output Class Initialized
INFO - 2023-05-09 06:18:59 --> Security Class Initialized
INFO - 2023-05-09 06:18:59 --> Input Class Initialized
INFO - 2023-05-09 06:18:59 --> Language Class Initialized
INFO - 2023-05-09 06:18:59 --> Loader Class Initialized
INFO - 2023-05-09 06:18:59 --> Helper loaded: url_helper
INFO - 2023-05-09 06:18:59 --> Helper loaded: form_helper
INFO - 2023-05-09 06:18:59 --> Database Driver Class Initialized
INFO - 2023-05-09 06:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 06:18:59 --> Form Validation Class Initialized
INFO - 2023-05-09 06:18:59 --> Controller Class Initialized
INFO - 2023-05-09 06:18:59 --> Model "m_datatrain" initialized
INFO - 2023-05-09 06:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-09 06:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-09 06:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-09 06:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-09 06:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-09 06:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-09 06:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-09 06:18:59 --> Final output sent to browser
INFO - 2023-05-09 06:19:42 --> Config Class Initialized
INFO - 2023-05-09 06:19:42 --> Hooks Class Initialized
INFO - 2023-05-09 06:19:42 --> Utf8 Class Initialized
INFO - 2023-05-09 06:19:42 --> URI Class Initialized
INFO - 2023-05-09 06:19:42 --> Router Class Initialized
INFO - 2023-05-09 06:19:42 --> Output Class Initialized
INFO - 2023-05-09 06:19:42 --> Security Class Initialized
INFO - 2023-05-09 06:19:42 --> Input Class Initialized
INFO - 2023-05-09 06:19:42 --> Language Class Initialized
ERROR - 2023-05-09 06:19:42 --> 404 Page Not Found: C_tutor/form_ubah
INFO - 2023-05-09 06:19:43 --> Config Class Initialized
INFO - 2023-05-09 06:19:43 --> Hooks Class Initialized
INFO - 2023-05-09 06:19:43 --> Utf8 Class Initialized
INFO - 2023-05-09 06:19:43 --> URI Class Initialized
INFO - 2023-05-09 06:19:43 --> Router Class Initialized
INFO - 2023-05-09 06:19:43 --> Output Class Initialized
INFO - 2023-05-09 06:19:43 --> Security Class Initialized
INFO - 2023-05-09 06:19:43 --> Input Class Initialized
INFO - 2023-05-09 06:19:43 --> Language Class Initialized
INFO - 2023-05-09 06:19:43 --> Loader Class Initialized
INFO - 2023-05-09 06:19:43 --> Helper loaded: url_helper
INFO - 2023-05-09 06:19:43 --> Helper loaded: form_helper
INFO - 2023-05-09 06:19:43 --> Database Driver Class Initialized
INFO - 2023-05-09 06:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 06:19:43 --> Form Validation Class Initialized
INFO - 2023-05-09 06:19:43 --> Controller Class Initialized
INFO - 2023-05-09 06:19:43 --> Model "m_datatrain" initialized
INFO - 2023-05-09 06:19:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-09 06:19:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-09 06:19:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-09 06:19:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-09 06:19:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-09 06:19:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-09 06:19:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-09 06:19:43 --> Final output sent to browser
INFO - 2023-05-09 07:50:48 --> Config Class Initialized
INFO - 2023-05-09 07:50:48 --> Hooks Class Initialized
INFO - 2023-05-09 07:50:48 --> Utf8 Class Initialized
INFO - 2023-05-09 07:50:48 --> URI Class Initialized
INFO - 2023-05-09 07:50:48 --> Router Class Initialized
INFO - 2023-05-09 07:50:48 --> Output Class Initialized
INFO - 2023-05-09 07:50:48 --> Security Class Initialized
INFO - 2023-05-09 07:50:48 --> Input Class Initialized
INFO - 2023-05-09 07:50:48 --> Language Class Initialized
INFO - 2023-05-09 07:50:48 --> Loader Class Initialized
INFO - 2023-05-09 07:50:48 --> Helper loaded: url_helper
INFO - 2023-05-09 07:50:48 --> Helper loaded: form_helper
INFO - 2023-05-09 07:50:48 --> Database Driver Class Initialized
INFO - 2023-05-09 07:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 07:50:48 --> Form Validation Class Initialized
INFO - 2023-05-09 07:50:48 --> Controller Class Initialized
INFO - 2023-05-09 07:50:48 --> Model "m_datatrain" initialized
INFO - 2023-05-09 07:50:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-09 07:50:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-09 07:50:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-09 07:50:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-09 07:50:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-09 07:50:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-09 07:50:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-09 07:50:49 --> Final output sent to browser
INFO - 2023-05-09 08:05:27 --> Config Class Initialized
INFO - 2023-05-09 08:05:27 --> Hooks Class Initialized
INFO - 2023-05-09 08:05:27 --> Utf8 Class Initialized
INFO - 2023-05-09 08:05:27 --> URI Class Initialized
INFO - 2023-05-09 08:05:27 --> Router Class Initialized
INFO - 2023-05-09 08:05:27 --> Output Class Initialized
INFO - 2023-05-09 08:05:27 --> Security Class Initialized
INFO - 2023-05-09 08:05:27 --> Input Class Initialized
INFO - 2023-05-09 08:05:27 --> Language Class Initialized
ERROR - 2023-05-09 08:05:27 --> 404 Page Not Found: C_diagnosa/cek
INFO - 2023-05-09 08:05:36 --> Config Class Initialized
INFO - 2023-05-09 08:05:36 --> Hooks Class Initialized
INFO - 2023-05-09 08:05:36 --> Utf8 Class Initialized
INFO - 2023-05-09 08:05:36 --> URI Class Initialized
INFO - 2023-05-09 08:05:36 --> Router Class Initialized
INFO - 2023-05-09 08:05:36 --> Output Class Initialized
INFO - 2023-05-09 08:05:36 --> Security Class Initialized
INFO - 2023-05-09 08:05:36 --> Input Class Initialized
INFO - 2023-05-09 08:05:36 --> Language Class Initialized
ERROR - 2023-05-09 08:05:36 --> 404 Page Not Found: C_diagnosa/index
INFO - 2023-05-09 08:05:41 --> Config Class Initialized
INFO - 2023-05-09 08:05:41 --> Hooks Class Initialized
INFO - 2023-05-09 08:05:41 --> Utf8 Class Initialized
INFO - 2023-05-09 08:05:41 --> URI Class Initialized
INFO - 2023-05-09 08:05:41 --> Router Class Initialized
INFO - 2023-05-09 08:05:41 --> Output Class Initialized
INFO - 2023-05-09 08:05:41 --> Security Class Initialized
INFO - 2023-05-09 08:05:41 --> Input Class Initialized
INFO - 2023-05-09 08:05:41 --> Language Class Initialized
INFO - 2023-05-09 08:05:41 --> Loader Class Initialized
INFO - 2023-05-09 08:05:41 --> Helper loaded: url_helper
INFO - 2023-05-09 08:05:41 --> Helper loaded: form_helper
INFO - 2023-05-09 08:05:41 --> Database Driver Class Initialized
INFO - 2023-05-09 08:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:05:41 --> Form Validation Class Initialized
INFO - 2023-05-09 08:05:41 --> Controller Class Initialized
INFO - 2023-05-09 08:05:41 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:05:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-09 08:05:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-09 08:05:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-09 08:05:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-09 08:05:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-09 08:05:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-09 08:05:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-09 08:05:41 --> Final output sent to browser
INFO - 2023-05-09 08:05:52 --> Config Class Initialized
INFO - 2023-05-09 08:05:52 --> Hooks Class Initialized
INFO - 2023-05-09 08:05:52 --> Utf8 Class Initialized
INFO - 2023-05-09 08:05:52 --> URI Class Initialized
INFO - 2023-05-09 08:05:52 --> Router Class Initialized
INFO - 2023-05-09 08:05:52 --> Output Class Initialized
INFO - 2023-05-09 08:05:52 --> Security Class Initialized
INFO - 2023-05-09 08:05:52 --> Input Class Initialized
INFO - 2023-05-09 08:05:52 --> Language Class Initialized
INFO - 2023-05-09 08:05:52 --> Loader Class Initialized
INFO - 2023-05-09 08:05:52 --> Helper loaded: url_helper
INFO - 2023-05-09 08:05:52 --> Helper loaded: form_helper
INFO - 2023-05-09 08:05:52 --> Database Driver Class Initialized
INFO - 2023-05-09 08:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:05:52 --> Form Validation Class Initialized
INFO - 2023-05-09 08:05:52 --> Controller Class Initialized
INFO - 2023-05-09 08:05:52 --> Model "m_user" initialized
INFO - 2023-05-09 08:05:52 --> Config Class Initialized
INFO - 2023-05-09 08:05:52 --> Hooks Class Initialized
INFO - 2023-05-09 08:05:52 --> Utf8 Class Initialized
INFO - 2023-05-09 08:05:52 --> URI Class Initialized
INFO - 2023-05-09 08:05:52 --> Router Class Initialized
INFO - 2023-05-09 08:05:52 --> Output Class Initialized
INFO - 2023-05-09 08:05:52 --> Security Class Initialized
INFO - 2023-05-09 08:05:52 --> Input Class Initialized
INFO - 2023-05-09 08:05:52 --> Language Class Initialized
INFO - 2023-05-09 08:05:52 --> Loader Class Initialized
INFO - 2023-05-09 08:05:52 --> Helper loaded: url_helper
INFO - 2023-05-09 08:05:52 --> Helper loaded: form_helper
INFO - 2023-05-09 08:05:52 --> Database Driver Class Initialized
INFO - 2023-05-09 08:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:05:52 --> Form Validation Class Initialized
INFO - 2023-05-09 08:05:52 --> Controller Class Initialized
INFO - 2023-05-09 08:05:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-09 08:05:52 --> Final output sent to browser
INFO - 2023-05-09 08:05:54 --> Config Class Initialized
INFO - 2023-05-09 08:05:54 --> Hooks Class Initialized
INFO - 2023-05-09 08:05:54 --> Utf8 Class Initialized
INFO - 2023-05-09 08:05:54 --> URI Class Initialized
INFO - 2023-05-09 08:05:54 --> Router Class Initialized
INFO - 2023-05-09 08:05:54 --> Output Class Initialized
INFO - 2023-05-09 08:05:54 --> Security Class Initialized
INFO - 2023-05-09 08:05:54 --> Input Class Initialized
INFO - 2023-05-09 08:05:54 --> Language Class Initialized
INFO - 2023-05-09 08:05:54 --> Loader Class Initialized
INFO - 2023-05-09 08:05:54 --> Helper loaded: url_helper
INFO - 2023-05-09 08:05:54 --> Helper loaded: form_helper
INFO - 2023-05-09 08:05:54 --> Database Driver Class Initialized
INFO - 2023-05-09 08:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:05:54 --> Form Validation Class Initialized
INFO - 2023-05-09 08:05:54 --> Controller Class Initialized
INFO - 2023-05-09 08:05:54 --> Model "m_user" initialized
INFO - 2023-05-09 08:05:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-09 08:05:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-09 08:05:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-09 08:05:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-09 08:05:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-09 08:05:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-09 08:05:54 --> Final output sent to browser
INFO - 2023-05-09 08:06:02 --> Config Class Initialized
INFO - 2023-05-09 08:06:02 --> Hooks Class Initialized
INFO - 2023-05-09 08:06:02 --> Utf8 Class Initialized
INFO - 2023-05-09 08:06:02 --> URI Class Initialized
INFO - 2023-05-09 08:06:02 --> Router Class Initialized
INFO - 2023-05-09 08:06:02 --> Output Class Initialized
INFO - 2023-05-09 08:06:02 --> Security Class Initialized
INFO - 2023-05-09 08:06:02 --> Input Class Initialized
INFO - 2023-05-09 08:06:02 --> Language Class Initialized
ERROR - 2023-05-09 08:06:02 --> 404 Page Not Found: C_diagnosa/index
INFO - 2023-05-09 08:06:07 --> Config Class Initialized
INFO - 2023-05-09 08:06:07 --> Hooks Class Initialized
INFO - 2023-05-09 08:06:07 --> Utf8 Class Initialized
INFO - 2023-05-09 08:06:07 --> URI Class Initialized
INFO - 2023-05-09 08:06:07 --> Router Class Initialized
INFO - 2023-05-09 08:06:07 --> Output Class Initialized
INFO - 2023-05-09 08:06:07 --> Security Class Initialized
INFO - 2023-05-09 08:06:07 --> Input Class Initialized
INFO - 2023-05-09 08:06:07 --> Language Class Initialized
ERROR - 2023-05-09 08:06:07 --> 404 Page Not Found: C_diagnosa/cek
INFO - 2023-05-09 08:06:55 --> Config Class Initialized
INFO - 2023-05-09 08:06:55 --> Hooks Class Initialized
INFO - 2023-05-09 08:06:55 --> Utf8 Class Initialized
INFO - 2023-05-09 08:06:55 --> URI Class Initialized
INFO - 2023-05-09 08:06:55 --> Router Class Initialized
INFO - 2023-05-09 08:06:55 --> Output Class Initialized
INFO - 2023-05-09 08:06:55 --> Security Class Initialized
INFO - 2023-05-09 08:06:55 --> Input Class Initialized
INFO - 2023-05-09 08:06:55 --> Language Class Initialized
INFO - 2023-05-09 08:06:55 --> Loader Class Initialized
INFO - 2023-05-09 08:06:55 --> Helper loaded: url_helper
INFO - 2023-05-09 08:06:55 --> Helper loaded: form_helper
INFO - 2023-05-09 08:06:55 --> Database Driver Class Initialized
INFO - 2023-05-09 08:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:06:55 --> Form Validation Class Initialized
INFO - 2023-05-09 08:06:55 --> Controller Class Initialized
INFO - 2023-05-09 08:06:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-09 08:06:55 --> Final output sent to browser
INFO - 2023-05-09 08:06:56 --> Config Class Initialized
INFO - 2023-05-09 08:06:56 --> Hooks Class Initialized
INFO - 2023-05-09 08:06:56 --> Utf8 Class Initialized
INFO - 2023-05-09 08:06:56 --> URI Class Initialized
INFO - 2023-05-09 08:06:56 --> Router Class Initialized
INFO - 2023-05-09 08:06:56 --> Output Class Initialized
INFO - 2023-05-09 08:06:56 --> Security Class Initialized
INFO - 2023-05-09 08:06:56 --> Input Class Initialized
INFO - 2023-05-09 08:06:56 --> Language Class Initialized
INFO - 2023-05-09 08:06:56 --> Loader Class Initialized
INFO - 2023-05-09 08:06:56 --> Helper loaded: url_helper
INFO - 2023-05-09 08:06:56 --> Helper loaded: form_helper
INFO - 2023-05-09 08:06:56 --> Database Driver Class Initialized
INFO - 2023-05-09 08:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:06:56 --> Form Validation Class Initialized
INFO - 2023-05-09 08:06:56 --> Controller Class Initialized
INFO - 2023-05-09 08:06:56 --> Model "m_user" initialized
INFO - 2023-05-09 08:06:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-09 08:06:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-09 08:06:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-09 08:06:56 --> Final output sent to browser
INFO - 2023-05-09 08:07:01 --> Config Class Initialized
INFO - 2023-05-09 08:07:01 --> Hooks Class Initialized
INFO - 2023-05-09 08:07:01 --> Utf8 Class Initialized
INFO - 2023-05-09 08:07:01 --> URI Class Initialized
INFO - 2023-05-09 08:07:01 --> Router Class Initialized
INFO - 2023-05-09 08:07:01 --> Output Class Initialized
INFO - 2023-05-09 08:07:01 --> Security Class Initialized
INFO - 2023-05-09 08:07:01 --> Input Class Initialized
INFO - 2023-05-09 08:07:01 --> Language Class Initialized
INFO - 2023-05-09 08:07:01 --> Loader Class Initialized
INFO - 2023-05-09 08:07:01 --> Helper loaded: url_helper
INFO - 2023-05-09 08:07:01 --> Helper loaded: form_helper
INFO - 2023-05-09 08:07:01 --> Database Driver Class Initialized
INFO - 2023-05-09 08:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:07:01 --> Form Validation Class Initialized
INFO - 2023-05-09 08:07:01 --> Controller Class Initialized
INFO - 2023-05-09 08:07:01 --> Model "m_user" initialized
INFO - 2023-05-09 08:07:01 --> Config Class Initialized
INFO - 2023-05-09 08:07:01 --> Hooks Class Initialized
INFO - 2023-05-09 08:07:01 --> Utf8 Class Initialized
INFO - 2023-05-09 08:07:01 --> URI Class Initialized
INFO - 2023-05-09 08:07:01 --> Router Class Initialized
INFO - 2023-05-09 08:07:01 --> Output Class Initialized
INFO - 2023-05-09 08:07:01 --> Security Class Initialized
INFO - 2023-05-09 08:07:01 --> Input Class Initialized
INFO - 2023-05-09 08:07:01 --> Language Class Initialized
INFO - 2023-05-09 08:07:01 --> Loader Class Initialized
INFO - 2023-05-09 08:07:01 --> Helper loaded: url_helper
INFO - 2023-05-09 08:07:01 --> Helper loaded: form_helper
INFO - 2023-05-09 08:07:01 --> Database Driver Class Initialized
INFO - 2023-05-09 08:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:07:01 --> Form Validation Class Initialized
INFO - 2023-05-09 08:07:01 --> Controller Class Initialized
INFO - 2023-05-09 08:07:01 --> Model "m_user" initialized
INFO - 2023-05-09 08:07:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-09 08:07:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-09 08:07:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-09 08:07:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-09 08:07:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-09 08:07:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-09 08:07:01 --> Final output sent to browser
INFO - 2023-05-09 08:07:06 --> Config Class Initialized
INFO - 2023-05-09 08:07:06 --> Hooks Class Initialized
INFO - 2023-05-09 08:07:06 --> Utf8 Class Initialized
INFO - 2023-05-09 08:07:06 --> URI Class Initialized
INFO - 2023-05-09 08:07:06 --> Router Class Initialized
INFO - 2023-05-09 08:07:06 --> Output Class Initialized
INFO - 2023-05-09 08:07:06 --> Security Class Initialized
INFO - 2023-05-09 08:07:06 --> Input Class Initialized
INFO - 2023-05-09 08:07:06 --> Language Class Initialized
ERROR - 2023-05-09 08:07:06 --> 404 Page Not Found: Home/cek
INFO - 2023-05-09 08:07:15 --> Config Class Initialized
INFO - 2023-05-09 08:07:15 --> Hooks Class Initialized
INFO - 2023-05-09 08:07:15 --> Utf8 Class Initialized
INFO - 2023-05-09 08:07:15 --> URI Class Initialized
INFO - 2023-05-09 08:07:15 --> Router Class Initialized
INFO - 2023-05-09 08:07:15 --> Output Class Initialized
INFO - 2023-05-09 08:07:15 --> Security Class Initialized
INFO - 2023-05-09 08:07:15 --> Input Class Initialized
INFO - 2023-05-09 08:07:15 --> Language Class Initialized
INFO - 2023-05-09 08:07:15 --> Loader Class Initialized
INFO - 2023-05-09 08:07:15 --> Helper loaded: url_helper
INFO - 2023-05-09 08:07:15 --> Helper loaded: form_helper
INFO - 2023-05-09 08:07:15 --> Database Driver Class Initialized
INFO - 2023-05-09 08:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:07:15 --> Form Validation Class Initialized
INFO - 2023-05-09 08:07:15 --> Controller Class Initialized
INFO - 2023-05-09 08:07:15 --> Model "m_user" initialized
ERROR - 2023-05-09 08:07:15 --> Severity: Notice --> Undefined property: C_home::$m_datatrain C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 18
ERROR - 2023-05-09 08:07:15 --> Severity: Error --> Call to a member function getCoba() on null C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 18
INFO - 2023-05-09 08:07:38 --> Config Class Initialized
INFO - 2023-05-09 08:07:38 --> Hooks Class Initialized
INFO - 2023-05-09 08:07:38 --> Utf8 Class Initialized
INFO - 2023-05-09 08:07:38 --> URI Class Initialized
INFO - 2023-05-09 08:07:38 --> Router Class Initialized
INFO - 2023-05-09 08:07:38 --> Output Class Initialized
INFO - 2023-05-09 08:07:38 --> Security Class Initialized
INFO - 2023-05-09 08:07:38 --> Input Class Initialized
INFO - 2023-05-09 08:07:38 --> Language Class Initialized
INFO - 2023-05-09 08:07:38 --> Loader Class Initialized
INFO - 2023-05-09 08:07:38 --> Helper loaded: url_helper
INFO - 2023-05-09 08:07:38 --> Helper loaded: form_helper
INFO - 2023-05-09 08:07:38 --> Database Driver Class Initialized
INFO - 2023-05-09 08:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:07:38 --> Form Validation Class Initialized
INFO - 2023-05-09 08:07:38 --> Controller Class Initialized
INFO - 2023-05-09 08:07:38 --> Model "m_user" initialized
INFO - 2023-05-09 08:07:38 --> Model "m_datatrain" initialized
ERROR - 2023-05-09 08:07:38 --> Query error: Table 'sistemdiagnosa.datatrain' doesn't exist - Invalid query: SELECT `hasil`, count(*)
FROM `datatrain`
GROUP BY `hasil`
INFO - 2023-05-09 08:07:38 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-09 08:07:51 --> Config Class Initialized
INFO - 2023-05-09 08:07:51 --> Hooks Class Initialized
INFO - 2023-05-09 08:07:51 --> Utf8 Class Initialized
INFO - 2023-05-09 08:07:51 --> URI Class Initialized
INFO - 2023-05-09 08:07:51 --> Router Class Initialized
INFO - 2023-05-09 08:07:51 --> Output Class Initialized
INFO - 2023-05-09 08:07:51 --> Security Class Initialized
INFO - 2023-05-09 08:07:51 --> Input Class Initialized
INFO - 2023-05-09 08:07:51 --> Language Class Initialized
INFO - 2023-05-09 08:07:51 --> Loader Class Initialized
INFO - 2023-05-09 08:07:51 --> Helper loaded: url_helper
INFO - 2023-05-09 08:07:51 --> Helper loaded: form_helper
INFO - 2023-05-09 08:07:51 --> Database Driver Class Initialized
INFO - 2023-05-09 08:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:07:51 --> Form Validation Class Initialized
INFO - 2023-05-09 08:07:51 --> Controller Class Initialized
INFO - 2023-05-09 08:07:51 --> Model "m_user" initialized
ERROR - 2023-05-09 08:07:51 --> Severity: error --> Exception: Unable to locate the model you have specified: M_datatraining C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 348
INFO - 2023-05-09 08:08:19 --> Config Class Initialized
INFO - 2023-05-09 08:08:19 --> Hooks Class Initialized
INFO - 2023-05-09 08:08:19 --> Utf8 Class Initialized
INFO - 2023-05-09 08:08:19 --> URI Class Initialized
INFO - 2023-05-09 08:08:19 --> Router Class Initialized
INFO - 2023-05-09 08:08:19 --> Output Class Initialized
INFO - 2023-05-09 08:08:19 --> Security Class Initialized
INFO - 2023-05-09 08:08:19 --> Input Class Initialized
INFO - 2023-05-09 08:08:19 --> Language Class Initialized
INFO - 2023-05-09 08:08:19 --> Loader Class Initialized
INFO - 2023-05-09 08:08:19 --> Helper loaded: url_helper
INFO - 2023-05-09 08:08:19 --> Helper loaded: form_helper
INFO - 2023-05-09 08:08:19 --> Database Driver Class Initialized
INFO - 2023-05-09 08:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:08:19 --> Form Validation Class Initialized
INFO - 2023-05-09 08:08:19 --> Controller Class Initialized
INFO - 2023-05-09 08:08:19 --> Model "m_user" initialized
INFO - 2023-05-09 08:08:19 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:08:19 --> Final output sent to browser
INFO - 2023-05-09 08:08:21 --> Config Class Initialized
INFO - 2023-05-09 08:08:21 --> Hooks Class Initialized
INFO - 2023-05-09 08:08:21 --> Utf8 Class Initialized
INFO - 2023-05-09 08:08:21 --> URI Class Initialized
INFO - 2023-05-09 08:08:21 --> Router Class Initialized
INFO - 2023-05-09 08:08:21 --> Output Class Initialized
INFO - 2023-05-09 08:08:21 --> Security Class Initialized
INFO - 2023-05-09 08:08:21 --> Input Class Initialized
INFO - 2023-05-09 08:08:21 --> Language Class Initialized
INFO - 2023-05-09 08:08:21 --> Loader Class Initialized
INFO - 2023-05-09 08:08:21 --> Helper loaded: url_helper
INFO - 2023-05-09 08:08:21 --> Helper loaded: form_helper
INFO - 2023-05-09 08:08:21 --> Database Driver Class Initialized
INFO - 2023-05-09 08:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:08:21 --> Form Validation Class Initialized
INFO - 2023-05-09 08:08:21 --> Controller Class Initialized
INFO - 2023-05-09 08:08:21 --> Model "m_user" initialized
INFO - 2023-05-09 08:08:21 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:08:21 --> Final output sent to browser
INFO - 2023-05-09 08:08:47 --> Config Class Initialized
INFO - 2023-05-09 08:08:47 --> Hooks Class Initialized
INFO - 2023-05-09 08:08:47 --> Utf8 Class Initialized
INFO - 2023-05-09 08:08:47 --> URI Class Initialized
INFO - 2023-05-09 08:08:47 --> Router Class Initialized
INFO - 2023-05-09 08:08:47 --> Output Class Initialized
INFO - 2023-05-09 08:08:47 --> Security Class Initialized
INFO - 2023-05-09 08:08:47 --> Input Class Initialized
INFO - 2023-05-09 08:08:47 --> Language Class Initialized
INFO - 2023-05-09 08:08:47 --> Loader Class Initialized
INFO - 2023-05-09 08:08:47 --> Helper loaded: url_helper
INFO - 2023-05-09 08:08:47 --> Helper loaded: form_helper
INFO - 2023-05-09 08:08:47 --> Database Driver Class Initialized
INFO - 2023-05-09 08:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:08:47 --> Form Validation Class Initialized
INFO - 2023-05-09 08:08:47 --> Controller Class Initialized
INFO - 2023-05-09 08:08:47 --> Model "m_user" initialized
INFO - 2023-05-09 08:08:47 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:08:47 --> Final output sent to browser
INFO - 2023-05-09 08:08:59 --> Config Class Initialized
INFO - 2023-05-09 08:08:59 --> Hooks Class Initialized
INFO - 2023-05-09 08:08:59 --> Utf8 Class Initialized
INFO - 2023-05-09 08:08:59 --> URI Class Initialized
INFO - 2023-05-09 08:08:59 --> Router Class Initialized
INFO - 2023-05-09 08:08:59 --> Output Class Initialized
INFO - 2023-05-09 08:08:59 --> Security Class Initialized
INFO - 2023-05-09 08:08:59 --> Input Class Initialized
INFO - 2023-05-09 08:08:59 --> Language Class Initialized
INFO - 2023-05-09 08:08:59 --> Loader Class Initialized
INFO - 2023-05-09 08:08:59 --> Helper loaded: url_helper
INFO - 2023-05-09 08:08:59 --> Helper loaded: form_helper
INFO - 2023-05-09 08:08:59 --> Database Driver Class Initialized
INFO - 2023-05-09 08:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:08:59 --> Form Validation Class Initialized
INFO - 2023-05-09 08:08:59 --> Controller Class Initialized
INFO - 2023-05-09 08:08:59 --> Model "m_user" initialized
INFO - 2023-05-09 08:08:59 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:08:59 --> Final output sent to browser
INFO - 2023-05-09 08:09:38 --> Config Class Initialized
INFO - 2023-05-09 08:09:38 --> Hooks Class Initialized
INFO - 2023-05-09 08:09:38 --> Utf8 Class Initialized
INFO - 2023-05-09 08:09:38 --> URI Class Initialized
INFO - 2023-05-09 08:09:38 --> Router Class Initialized
INFO - 2023-05-09 08:09:38 --> Output Class Initialized
INFO - 2023-05-09 08:09:38 --> Security Class Initialized
INFO - 2023-05-09 08:09:38 --> Input Class Initialized
INFO - 2023-05-09 08:09:38 --> Language Class Initialized
INFO - 2023-05-09 08:09:38 --> Loader Class Initialized
INFO - 2023-05-09 08:09:38 --> Helper loaded: url_helper
INFO - 2023-05-09 08:09:38 --> Helper loaded: form_helper
INFO - 2023-05-09 08:09:38 --> Database Driver Class Initialized
INFO - 2023-05-09 08:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:09:38 --> Form Validation Class Initialized
INFO - 2023-05-09 08:09:38 --> Controller Class Initialized
INFO - 2023-05-09 08:09:38 --> Model "m_user" initialized
INFO - 2023-05-09 08:09:38 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:09:38 --> Final output sent to browser
INFO - 2023-05-09 08:09:48 --> Config Class Initialized
INFO - 2023-05-09 08:09:48 --> Hooks Class Initialized
INFO - 2023-05-09 08:09:48 --> Utf8 Class Initialized
INFO - 2023-05-09 08:09:48 --> URI Class Initialized
INFO - 2023-05-09 08:09:48 --> Router Class Initialized
INFO - 2023-05-09 08:09:48 --> Output Class Initialized
INFO - 2023-05-09 08:09:48 --> Security Class Initialized
INFO - 2023-05-09 08:09:48 --> Input Class Initialized
INFO - 2023-05-09 08:09:48 --> Language Class Initialized
INFO - 2023-05-09 08:09:48 --> Loader Class Initialized
INFO - 2023-05-09 08:09:48 --> Helper loaded: url_helper
INFO - 2023-05-09 08:09:48 --> Helper loaded: form_helper
INFO - 2023-05-09 08:09:48 --> Database Driver Class Initialized
INFO - 2023-05-09 08:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:09:48 --> Form Validation Class Initialized
INFO - 2023-05-09 08:09:48 --> Controller Class Initialized
INFO - 2023-05-09 08:09:48 --> Model "m_user" initialized
INFO - 2023-05-09 08:09:48 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:09:48 --> Final output sent to browser
INFO - 2023-05-09 08:11:27 --> Config Class Initialized
INFO - 2023-05-09 08:11:27 --> Hooks Class Initialized
INFO - 2023-05-09 08:11:27 --> Utf8 Class Initialized
INFO - 2023-05-09 08:11:27 --> URI Class Initialized
INFO - 2023-05-09 08:11:27 --> Router Class Initialized
INFO - 2023-05-09 08:11:27 --> Output Class Initialized
INFO - 2023-05-09 08:11:27 --> Security Class Initialized
INFO - 2023-05-09 08:11:27 --> Input Class Initialized
INFO - 2023-05-09 08:11:27 --> Language Class Initialized
INFO - 2023-05-09 08:11:27 --> Loader Class Initialized
INFO - 2023-05-09 08:11:27 --> Helper loaded: url_helper
INFO - 2023-05-09 08:11:27 --> Helper loaded: form_helper
INFO - 2023-05-09 08:11:27 --> Database Driver Class Initialized
INFO - 2023-05-09 08:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:11:27 --> Form Validation Class Initialized
INFO - 2023-05-09 08:11:27 --> Controller Class Initialized
INFO - 2023-05-09 08:11:27 --> Model "m_user" initialized
INFO - 2023-05-09 08:11:27 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:11:27 --> Final output sent to browser
INFO - 2023-05-09 08:11:44 --> Config Class Initialized
INFO - 2023-05-09 08:11:44 --> Hooks Class Initialized
INFO - 2023-05-09 08:11:44 --> Utf8 Class Initialized
INFO - 2023-05-09 08:11:44 --> URI Class Initialized
INFO - 2023-05-09 08:11:44 --> Router Class Initialized
INFO - 2023-05-09 08:11:44 --> Output Class Initialized
INFO - 2023-05-09 08:11:44 --> Security Class Initialized
INFO - 2023-05-09 08:11:44 --> Input Class Initialized
INFO - 2023-05-09 08:11:44 --> Language Class Initialized
INFO - 2023-05-09 08:11:44 --> Loader Class Initialized
INFO - 2023-05-09 08:11:44 --> Helper loaded: url_helper
INFO - 2023-05-09 08:11:44 --> Helper loaded: form_helper
INFO - 2023-05-09 08:11:44 --> Database Driver Class Initialized
INFO - 2023-05-09 08:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:11:44 --> Form Validation Class Initialized
INFO - 2023-05-09 08:11:44 --> Controller Class Initialized
INFO - 2023-05-09 08:11:44 --> Model "m_user" initialized
INFO - 2023-05-09 08:11:44 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:11:44 --> Final output sent to browser
INFO - 2023-05-09 08:13:00 --> Config Class Initialized
INFO - 2023-05-09 08:13:00 --> Hooks Class Initialized
INFO - 2023-05-09 08:13:00 --> Utf8 Class Initialized
INFO - 2023-05-09 08:13:00 --> URI Class Initialized
INFO - 2023-05-09 08:13:00 --> Router Class Initialized
INFO - 2023-05-09 08:13:00 --> Output Class Initialized
INFO - 2023-05-09 08:13:00 --> Security Class Initialized
INFO - 2023-05-09 08:13:00 --> Input Class Initialized
INFO - 2023-05-09 08:13:00 --> Language Class Initialized
INFO - 2023-05-09 08:13:00 --> Loader Class Initialized
INFO - 2023-05-09 08:13:00 --> Helper loaded: url_helper
INFO - 2023-05-09 08:13:00 --> Helper loaded: form_helper
INFO - 2023-05-09 08:13:00 --> Database Driver Class Initialized
INFO - 2023-05-09 08:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:13:01 --> Form Validation Class Initialized
INFO - 2023-05-09 08:13:01 --> Controller Class Initialized
INFO - 2023-05-09 08:13:01 --> Model "m_user" initialized
INFO - 2023-05-09 08:13:01 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:13:01 --> Final output sent to browser
INFO - 2023-05-09 08:13:10 --> Config Class Initialized
INFO - 2023-05-09 08:13:10 --> Hooks Class Initialized
INFO - 2023-05-09 08:13:10 --> Utf8 Class Initialized
INFO - 2023-05-09 08:13:10 --> URI Class Initialized
INFO - 2023-05-09 08:13:10 --> Router Class Initialized
INFO - 2023-05-09 08:13:10 --> Output Class Initialized
INFO - 2023-05-09 08:13:10 --> Security Class Initialized
INFO - 2023-05-09 08:13:10 --> Input Class Initialized
INFO - 2023-05-09 08:13:10 --> Language Class Initialized
INFO - 2023-05-09 08:13:10 --> Loader Class Initialized
INFO - 2023-05-09 08:13:10 --> Helper loaded: url_helper
INFO - 2023-05-09 08:13:10 --> Helper loaded: form_helper
INFO - 2023-05-09 08:13:10 --> Database Driver Class Initialized
INFO - 2023-05-09 08:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:13:10 --> Form Validation Class Initialized
INFO - 2023-05-09 08:13:10 --> Controller Class Initialized
INFO - 2023-05-09 08:13:10 --> Model "m_user" initialized
INFO - 2023-05-09 08:13:10 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:13:10 --> Final output sent to browser
INFO - 2023-05-09 08:14:05 --> Config Class Initialized
INFO - 2023-05-09 08:14:05 --> Hooks Class Initialized
INFO - 2023-05-09 08:14:05 --> Utf8 Class Initialized
INFO - 2023-05-09 08:14:05 --> URI Class Initialized
INFO - 2023-05-09 08:14:05 --> Router Class Initialized
INFO - 2023-05-09 08:14:05 --> Output Class Initialized
INFO - 2023-05-09 08:14:05 --> Security Class Initialized
INFO - 2023-05-09 08:14:05 --> Input Class Initialized
INFO - 2023-05-09 08:14:05 --> Language Class Initialized
INFO - 2023-05-09 08:14:05 --> Loader Class Initialized
INFO - 2023-05-09 08:14:05 --> Helper loaded: url_helper
INFO - 2023-05-09 08:14:05 --> Helper loaded: form_helper
INFO - 2023-05-09 08:14:05 --> Database Driver Class Initialized
INFO - 2023-05-09 08:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:14:05 --> Form Validation Class Initialized
INFO - 2023-05-09 08:14:05 --> Controller Class Initialized
INFO - 2023-05-09 08:14:05 --> Model "m_user" initialized
INFO - 2023-05-09 08:14:05 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:14:05 --> Final output sent to browser
INFO - 2023-05-09 08:14:16 --> Config Class Initialized
INFO - 2023-05-09 08:14:16 --> Hooks Class Initialized
INFO - 2023-05-09 08:14:16 --> Utf8 Class Initialized
INFO - 2023-05-09 08:14:16 --> URI Class Initialized
INFO - 2023-05-09 08:14:16 --> Router Class Initialized
INFO - 2023-05-09 08:14:16 --> Output Class Initialized
INFO - 2023-05-09 08:14:16 --> Security Class Initialized
INFO - 2023-05-09 08:14:16 --> Input Class Initialized
INFO - 2023-05-09 08:14:16 --> Language Class Initialized
INFO - 2023-05-09 08:14:16 --> Loader Class Initialized
INFO - 2023-05-09 08:14:16 --> Helper loaded: url_helper
INFO - 2023-05-09 08:14:16 --> Helper loaded: form_helper
INFO - 2023-05-09 08:14:16 --> Database Driver Class Initialized
INFO - 2023-05-09 08:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:14:16 --> Form Validation Class Initialized
INFO - 2023-05-09 08:14:16 --> Controller Class Initialized
INFO - 2023-05-09 08:14:16 --> Model "m_user" initialized
INFO - 2023-05-09 08:14:16 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:14:16 --> Final output sent to browser
INFO - 2023-05-09 08:14:55 --> Config Class Initialized
INFO - 2023-05-09 08:14:55 --> Hooks Class Initialized
INFO - 2023-05-09 08:14:55 --> Utf8 Class Initialized
INFO - 2023-05-09 08:14:55 --> URI Class Initialized
INFO - 2023-05-09 08:14:55 --> Router Class Initialized
INFO - 2023-05-09 08:14:55 --> Output Class Initialized
INFO - 2023-05-09 08:14:55 --> Security Class Initialized
INFO - 2023-05-09 08:14:55 --> Input Class Initialized
INFO - 2023-05-09 08:14:55 --> Language Class Initialized
INFO - 2023-05-09 08:14:55 --> Loader Class Initialized
INFO - 2023-05-09 08:14:55 --> Helper loaded: url_helper
INFO - 2023-05-09 08:14:55 --> Helper loaded: form_helper
INFO - 2023-05-09 08:14:55 --> Database Driver Class Initialized
INFO - 2023-05-09 08:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:14:55 --> Form Validation Class Initialized
INFO - 2023-05-09 08:14:55 --> Controller Class Initialized
INFO - 2023-05-09 08:14:55 --> Model "m_user" initialized
INFO - 2023-05-09 08:14:55 --> Model "m_datatrain" initialized
ERROR - 2023-05-09 08:14:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 21
ERROR - 2023-05-09 08:14:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 21
ERROR - 2023-05-09 08:14:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 21
ERROR - 2023-05-09 08:14:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 21
ERROR - 2023-05-09 08:14:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 21
ERROR - 2023-05-09 08:14:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 21
ERROR - 2023-05-09 08:14:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 21
ERROR - 2023-05-09 08:14:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 21
INFO - 2023-05-09 08:14:55 --> Final output sent to browser
INFO - 2023-05-09 08:15:10 --> Config Class Initialized
INFO - 2023-05-09 08:15:10 --> Hooks Class Initialized
INFO - 2023-05-09 08:15:10 --> Utf8 Class Initialized
INFO - 2023-05-09 08:15:10 --> URI Class Initialized
INFO - 2023-05-09 08:15:10 --> Router Class Initialized
INFO - 2023-05-09 08:15:10 --> Output Class Initialized
INFO - 2023-05-09 08:15:10 --> Security Class Initialized
INFO - 2023-05-09 08:15:10 --> Input Class Initialized
INFO - 2023-05-09 08:15:10 --> Language Class Initialized
INFO - 2023-05-09 08:15:10 --> Loader Class Initialized
INFO - 2023-05-09 08:15:10 --> Helper loaded: url_helper
INFO - 2023-05-09 08:15:10 --> Helper loaded: form_helper
INFO - 2023-05-09 08:15:10 --> Database Driver Class Initialized
INFO - 2023-05-09 08:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:15:10 --> Form Validation Class Initialized
INFO - 2023-05-09 08:15:10 --> Controller Class Initialized
INFO - 2023-05-09 08:15:10 --> Model "m_user" initialized
INFO - 2023-05-09 08:15:10 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:15:10 --> Final output sent to browser
INFO - 2023-05-09 08:15:28 --> Config Class Initialized
INFO - 2023-05-09 08:15:28 --> Hooks Class Initialized
INFO - 2023-05-09 08:15:28 --> Utf8 Class Initialized
INFO - 2023-05-09 08:15:28 --> URI Class Initialized
INFO - 2023-05-09 08:15:28 --> Router Class Initialized
INFO - 2023-05-09 08:15:28 --> Output Class Initialized
INFO - 2023-05-09 08:15:28 --> Security Class Initialized
INFO - 2023-05-09 08:15:28 --> Input Class Initialized
INFO - 2023-05-09 08:15:28 --> Language Class Initialized
ERROR - 2023-05-09 08:15:28 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 21
INFO - 2023-05-09 08:15:39 --> Config Class Initialized
INFO - 2023-05-09 08:15:39 --> Hooks Class Initialized
INFO - 2023-05-09 08:15:39 --> Utf8 Class Initialized
INFO - 2023-05-09 08:15:39 --> URI Class Initialized
INFO - 2023-05-09 08:15:39 --> Router Class Initialized
INFO - 2023-05-09 08:15:39 --> Output Class Initialized
INFO - 2023-05-09 08:15:39 --> Security Class Initialized
INFO - 2023-05-09 08:15:39 --> Input Class Initialized
INFO - 2023-05-09 08:15:39 --> Language Class Initialized
INFO - 2023-05-09 08:15:39 --> Loader Class Initialized
INFO - 2023-05-09 08:15:39 --> Helper loaded: url_helper
INFO - 2023-05-09 08:15:39 --> Helper loaded: form_helper
INFO - 2023-05-09 08:15:39 --> Database Driver Class Initialized
INFO - 2023-05-09 08:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:15:39 --> Form Validation Class Initialized
INFO - 2023-05-09 08:15:39 --> Controller Class Initialized
INFO - 2023-05-09 08:15:39 --> Model "m_user" initialized
INFO - 2023-05-09 08:15:39 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:15:39 --> Final output sent to browser
INFO - 2023-05-09 08:16:39 --> Config Class Initialized
INFO - 2023-05-09 08:16:39 --> Hooks Class Initialized
INFO - 2023-05-09 08:16:39 --> Utf8 Class Initialized
INFO - 2023-05-09 08:16:39 --> URI Class Initialized
INFO - 2023-05-09 08:16:39 --> Router Class Initialized
INFO - 2023-05-09 08:16:39 --> Output Class Initialized
INFO - 2023-05-09 08:16:39 --> Security Class Initialized
INFO - 2023-05-09 08:16:39 --> Input Class Initialized
INFO - 2023-05-09 08:16:39 --> Language Class Initialized
INFO - 2023-05-09 08:16:39 --> Loader Class Initialized
INFO - 2023-05-09 08:16:39 --> Helper loaded: url_helper
INFO - 2023-05-09 08:16:39 --> Helper loaded: form_helper
INFO - 2023-05-09 08:16:39 --> Database Driver Class Initialized
INFO - 2023-05-09 08:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-09 08:16:39 --> Form Validation Class Initialized
INFO - 2023-05-09 08:16:39 --> Controller Class Initialized
INFO - 2023-05-09 08:16:39 --> Model "m_user" initialized
INFO - 2023-05-09 08:16:39 --> Model "m_datatrain" initialized
INFO - 2023-05-09 08:16:39 --> Final output sent to browser
