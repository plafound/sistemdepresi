<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-21 20:10:46 --> Config Class Initialized
INFO - 2022-03-21 20:10:46 --> Hooks Class Initialized
INFO - 2022-03-21 20:10:46 --> Utf8 Class Initialized
INFO - 2022-03-21 20:10:46 --> URI Class Initialized
INFO - 2022-03-21 20:10:46 --> Router Class Initialized
INFO - 2022-03-21 20:10:46 --> Output Class Initialized
INFO - 2022-03-21 20:10:46 --> Security Class Initialized
INFO - 2022-03-21 20:10:46 --> Input Class Initialized
INFO - 2022-03-21 20:10:46 --> Language Class Initialized
INFO - 2022-03-21 20:10:46 --> Loader Class Initialized
INFO - 2022-03-21 20:10:46 --> Helper loaded: url_helper
INFO - 2022-03-21 20:10:46 --> Helper loaded: form_helper
INFO - 2022-03-21 20:10:47 --> Database Driver Class Initialized
INFO - 2022-03-21 20:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:10:47 --> Form Validation Class Initialized
INFO - 2022-03-21 20:10:47 --> Controller Class Initialized
INFO - 2022-03-21 20:10:47 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:10:47 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-21 20:10:47 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-21 20:10:47 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-21 20:10:47 --> Final output sent to browser
INFO - 2022-03-21 20:10:57 --> Config Class Initialized
INFO - 2022-03-21 20:10:57 --> Hooks Class Initialized
INFO - 2022-03-21 20:10:57 --> Utf8 Class Initialized
INFO - 2022-03-21 20:10:57 --> URI Class Initialized
INFO - 2022-03-21 20:10:57 --> Router Class Initialized
INFO - 2022-03-21 20:10:57 --> Output Class Initialized
INFO - 2022-03-21 20:10:57 --> Security Class Initialized
INFO - 2022-03-21 20:10:57 --> Input Class Initialized
INFO - 2022-03-21 20:10:57 --> Language Class Initialized
INFO - 2022-03-21 20:10:57 --> Loader Class Initialized
INFO - 2022-03-21 20:10:57 --> Helper loaded: url_helper
INFO - 2022-03-21 20:10:57 --> Helper loaded: form_helper
INFO - 2022-03-21 20:10:57 --> Database Driver Class Initialized
INFO - 2022-03-21 20:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:10:57 --> Form Validation Class Initialized
INFO - 2022-03-21 20:10:57 --> Controller Class Initialized
INFO - 2022-03-21 20:10:57 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:10:58 --> Config Class Initialized
INFO - 2022-03-21 20:10:58 --> Hooks Class Initialized
INFO - 2022-03-21 20:10:58 --> Utf8 Class Initialized
INFO - 2022-03-21 20:10:58 --> URI Class Initialized
INFO - 2022-03-21 20:10:58 --> Router Class Initialized
INFO - 2022-03-21 20:10:58 --> Output Class Initialized
INFO - 2022-03-21 20:10:58 --> Security Class Initialized
INFO - 2022-03-21 20:10:58 --> Input Class Initialized
INFO - 2022-03-21 20:10:58 --> Language Class Initialized
INFO - 2022-03-21 20:10:58 --> Loader Class Initialized
INFO - 2022-03-21 20:10:58 --> Helper loaded: url_helper
INFO - 2022-03-21 20:10:58 --> Helper loaded: form_helper
INFO - 2022-03-21 20:10:58 --> Database Driver Class Initialized
INFO - 2022-03-21 20:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:10:58 --> Form Validation Class Initialized
INFO - 2022-03-21 20:10:58 --> Controller Class Initialized
INFO - 2022-03-21 20:10:58 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:10:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:10:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:10:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:10:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:10:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:10:58 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:10:58 --> Final output sent to browser
INFO - 2022-03-21 20:12:25 --> Config Class Initialized
INFO - 2022-03-21 20:12:25 --> Hooks Class Initialized
INFO - 2022-03-21 20:12:25 --> Utf8 Class Initialized
INFO - 2022-03-21 20:12:26 --> URI Class Initialized
INFO - 2022-03-21 20:12:26 --> Router Class Initialized
INFO - 2022-03-21 20:12:26 --> Output Class Initialized
INFO - 2022-03-21 20:12:26 --> Security Class Initialized
INFO - 2022-03-21 20:12:26 --> Input Class Initialized
INFO - 2022-03-21 20:12:26 --> Language Class Initialized
INFO - 2022-03-21 20:12:26 --> Loader Class Initialized
INFO - 2022-03-21 20:12:26 --> Helper loaded: url_helper
INFO - 2022-03-21 20:12:26 --> Helper loaded: form_helper
INFO - 2022-03-21 20:12:26 --> Database Driver Class Initialized
INFO - 2022-03-21 20:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:12:26 --> Form Validation Class Initialized
INFO - 2022-03-21 20:12:26 --> Controller Class Initialized
INFO - 2022-03-21 20:12:27 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:12:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:12:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:12:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:12:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:12:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:12:27 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:12:27 --> Final output sent to browser
INFO - 2022-03-21 20:12:42 --> Config Class Initialized
INFO - 2022-03-21 20:12:42 --> Hooks Class Initialized
INFO - 2022-03-21 20:12:42 --> Utf8 Class Initialized
INFO - 2022-03-21 20:12:42 --> URI Class Initialized
INFO - 2022-03-21 20:12:42 --> Router Class Initialized
INFO - 2022-03-21 20:12:42 --> Output Class Initialized
INFO - 2022-03-21 20:12:42 --> Security Class Initialized
INFO - 2022-03-21 20:12:42 --> Input Class Initialized
INFO - 2022-03-21 20:12:42 --> Language Class Initialized
INFO - 2022-03-21 20:12:42 --> Loader Class Initialized
INFO - 2022-03-21 20:12:42 --> Helper loaded: url_helper
INFO - 2022-03-21 20:12:42 --> Helper loaded: form_helper
INFO - 2022-03-21 20:12:42 --> Database Driver Class Initialized
INFO - 2022-03-21 20:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:12:42 --> Form Validation Class Initialized
INFO - 2022-03-21 20:12:42 --> Controller Class Initialized
INFO - 2022-03-21 20:12:42 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:12:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:12:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:12:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:12:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:12:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:12:42 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:12:42 --> Final output sent to browser
INFO - 2022-03-21 20:14:48 --> Config Class Initialized
INFO - 2022-03-21 20:14:48 --> Hooks Class Initialized
INFO - 2022-03-21 20:14:48 --> Utf8 Class Initialized
INFO - 2022-03-21 20:14:48 --> URI Class Initialized
INFO - 2022-03-21 20:14:48 --> Router Class Initialized
INFO - 2022-03-21 20:14:48 --> Output Class Initialized
INFO - 2022-03-21 20:14:48 --> Security Class Initialized
INFO - 2022-03-21 20:14:48 --> Input Class Initialized
INFO - 2022-03-21 20:14:48 --> Language Class Initialized
INFO - 2022-03-21 20:14:48 --> Loader Class Initialized
INFO - 2022-03-21 20:14:48 --> Helper loaded: url_helper
INFO - 2022-03-21 20:14:48 --> Helper loaded: form_helper
INFO - 2022-03-21 20:14:48 --> Database Driver Class Initialized
INFO - 2022-03-21 20:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:14:48 --> Form Validation Class Initialized
INFO - 2022-03-21 20:14:48 --> Controller Class Initialized
INFO - 2022-03-21 20:14:48 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:14:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:14:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:14:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:14:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:14:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:14:48 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:14:48 --> Final output sent to browser
INFO - 2022-03-21 20:15:04 --> Config Class Initialized
INFO - 2022-03-21 20:15:04 --> Hooks Class Initialized
INFO - 2022-03-21 20:15:04 --> Utf8 Class Initialized
INFO - 2022-03-21 20:15:04 --> URI Class Initialized
INFO - 2022-03-21 20:15:04 --> Router Class Initialized
INFO - 2022-03-21 20:15:04 --> Output Class Initialized
INFO - 2022-03-21 20:15:04 --> Security Class Initialized
INFO - 2022-03-21 20:15:04 --> Input Class Initialized
INFO - 2022-03-21 20:15:04 --> Language Class Initialized
INFO - 2022-03-21 20:15:04 --> Loader Class Initialized
INFO - 2022-03-21 20:15:04 --> Helper loaded: url_helper
INFO - 2022-03-21 20:15:04 --> Helper loaded: form_helper
INFO - 2022-03-21 20:15:04 --> Database Driver Class Initialized
INFO - 2022-03-21 20:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:15:04 --> Form Validation Class Initialized
INFO - 2022-03-21 20:15:04 --> Controller Class Initialized
INFO - 2022-03-21 20:15:04 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:15:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:15:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:15:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:15:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:15:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:15:04 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:15:04 --> Final output sent to browser
INFO - 2022-03-21 20:15:14 --> Config Class Initialized
INFO - 2022-03-21 20:15:14 --> Hooks Class Initialized
INFO - 2022-03-21 20:15:14 --> Utf8 Class Initialized
INFO - 2022-03-21 20:15:14 --> URI Class Initialized
INFO - 2022-03-21 20:15:14 --> Router Class Initialized
INFO - 2022-03-21 20:15:14 --> Output Class Initialized
INFO - 2022-03-21 20:15:14 --> Security Class Initialized
INFO - 2022-03-21 20:15:14 --> Input Class Initialized
INFO - 2022-03-21 20:15:14 --> Language Class Initialized
INFO - 2022-03-21 20:15:14 --> Loader Class Initialized
INFO - 2022-03-21 20:15:14 --> Helper loaded: url_helper
INFO - 2022-03-21 20:15:14 --> Helper loaded: form_helper
INFO - 2022-03-21 20:15:14 --> Database Driver Class Initialized
INFO - 2022-03-21 20:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:15:14 --> Form Validation Class Initialized
INFO - 2022-03-21 20:15:14 --> Controller Class Initialized
INFO - 2022-03-21 20:15:14 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:15:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:15:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:15:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:15:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:15:14 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:15:14 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:15:14 --> Final output sent to browser
INFO - 2022-03-21 20:17:31 --> Config Class Initialized
INFO - 2022-03-21 20:17:31 --> Hooks Class Initialized
INFO - 2022-03-21 20:17:31 --> Utf8 Class Initialized
INFO - 2022-03-21 20:17:31 --> URI Class Initialized
INFO - 2022-03-21 20:17:31 --> Router Class Initialized
INFO - 2022-03-21 20:17:31 --> Output Class Initialized
INFO - 2022-03-21 20:17:31 --> Security Class Initialized
INFO - 2022-03-21 20:17:31 --> Input Class Initialized
INFO - 2022-03-21 20:17:31 --> Language Class Initialized
INFO - 2022-03-21 20:17:31 --> Loader Class Initialized
INFO - 2022-03-21 20:17:31 --> Helper loaded: url_helper
INFO - 2022-03-21 20:17:31 --> Helper loaded: form_helper
INFO - 2022-03-21 20:17:31 --> Database Driver Class Initialized
INFO - 2022-03-21 20:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:17:31 --> Form Validation Class Initialized
INFO - 2022-03-21 20:17:31 --> Controller Class Initialized
INFO - 2022-03-21 20:17:31 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:17:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:17:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:17:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:17:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:17:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:17:31 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:17:31 --> Final output sent to browser
INFO - 2022-03-21 20:18:50 --> Config Class Initialized
INFO - 2022-03-21 20:18:50 --> Hooks Class Initialized
INFO - 2022-03-21 20:18:50 --> Utf8 Class Initialized
INFO - 2022-03-21 20:18:50 --> URI Class Initialized
INFO - 2022-03-21 20:18:50 --> Router Class Initialized
INFO - 2022-03-21 20:18:50 --> Output Class Initialized
INFO - 2022-03-21 20:18:50 --> Security Class Initialized
INFO - 2022-03-21 20:18:50 --> Input Class Initialized
INFO - 2022-03-21 20:18:50 --> Language Class Initialized
INFO - 2022-03-21 20:18:50 --> Loader Class Initialized
INFO - 2022-03-21 20:18:50 --> Helper loaded: url_helper
INFO - 2022-03-21 20:18:50 --> Helper loaded: form_helper
INFO - 2022-03-21 20:18:50 --> Database Driver Class Initialized
INFO - 2022-03-21 20:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:18:50 --> Form Validation Class Initialized
INFO - 2022-03-21 20:18:50 --> Controller Class Initialized
INFO - 2022-03-21 20:18:50 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:18:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:18:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:18:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:18:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:18:50 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:18:50 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:18:50 --> Final output sent to browser
INFO - 2022-03-21 20:22:15 --> Config Class Initialized
INFO - 2022-03-21 20:22:15 --> Hooks Class Initialized
INFO - 2022-03-21 20:22:15 --> Utf8 Class Initialized
INFO - 2022-03-21 20:22:15 --> URI Class Initialized
INFO - 2022-03-21 20:22:15 --> Router Class Initialized
INFO - 2022-03-21 20:22:15 --> Output Class Initialized
INFO - 2022-03-21 20:22:15 --> Security Class Initialized
INFO - 2022-03-21 20:22:15 --> Input Class Initialized
INFO - 2022-03-21 20:22:15 --> Language Class Initialized
INFO - 2022-03-21 20:22:15 --> Loader Class Initialized
INFO - 2022-03-21 20:22:15 --> Helper loaded: url_helper
INFO - 2022-03-21 20:22:15 --> Helper loaded: form_helper
INFO - 2022-03-21 20:22:15 --> Database Driver Class Initialized
INFO - 2022-03-21 20:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:22:15 --> Form Validation Class Initialized
INFO - 2022-03-21 20:22:15 --> Controller Class Initialized
INFO - 2022-03-21 20:22:15 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:22:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:22:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:22:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:22:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:22:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:22:15 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:22:15 --> Final output sent to browser
INFO - 2022-03-21 20:22:26 --> Config Class Initialized
INFO - 2022-03-21 20:22:26 --> Hooks Class Initialized
INFO - 2022-03-21 20:22:26 --> Utf8 Class Initialized
INFO - 2022-03-21 20:22:26 --> URI Class Initialized
INFO - 2022-03-21 20:22:26 --> Router Class Initialized
INFO - 2022-03-21 20:22:26 --> Output Class Initialized
INFO - 2022-03-21 20:22:26 --> Security Class Initialized
INFO - 2022-03-21 20:22:26 --> Input Class Initialized
INFO - 2022-03-21 20:22:26 --> Language Class Initialized
INFO - 2022-03-21 20:22:26 --> Loader Class Initialized
INFO - 2022-03-21 20:22:26 --> Helper loaded: url_helper
INFO - 2022-03-21 20:22:26 --> Helper loaded: form_helper
INFO - 2022-03-21 20:22:26 --> Database Driver Class Initialized
INFO - 2022-03-21 20:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:22:26 --> Form Validation Class Initialized
INFO - 2022-03-21 20:22:26 --> Controller Class Initialized
INFO - 2022-03-21 20:22:26 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:22:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:22:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:22:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:22:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:22:26 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:22:26 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:22:26 --> Final output sent to browser
INFO - 2022-03-21 20:23:42 --> Config Class Initialized
INFO - 2022-03-21 20:23:42 --> Hooks Class Initialized
INFO - 2022-03-21 20:23:42 --> Utf8 Class Initialized
INFO - 2022-03-21 20:23:42 --> URI Class Initialized
INFO - 2022-03-21 20:23:42 --> Router Class Initialized
INFO - 2022-03-21 20:23:42 --> Output Class Initialized
INFO - 2022-03-21 20:23:42 --> Security Class Initialized
INFO - 2022-03-21 20:23:42 --> Input Class Initialized
INFO - 2022-03-21 20:23:42 --> Language Class Initialized
INFO - 2022-03-21 20:23:42 --> Loader Class Initialized
INFO - 2022-03-21 20:23:42 --> Helper loaded: url_helper
INFO - 2022-03-21 20:23:42 --> Helper loaded: form_helper
INFO - 2022-03-21 20:23:42 --> Database Driver Class Initialized
INFO - 2022-03-21 20:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:23:42 --> Form Validation Class Initialized
INFO - 2022-03-21 20:23:42 --> Controller Class Initialized
INFO - 2022-03-21 20:23:42 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:23:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:23:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:23:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:23:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:23:42 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:23:42 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:23:42 --> Final output sent to browser
INFO - 2022-03-21 20:24:04 --> Config Class Initialized
INFO - 2022-03-21 20:24:04 --> Hooks Class Initialized
INFO - 2022-03-21 20:24:04 --> Utf8 Class Initialized
INFO - 2022-03-21 20:24:04 --> URI Class Initialized
INFO - 2022-03-21 20:24:04 --> Router Class Initialized
INFO - 2022-03-21 20:24:04 --> Output Class Initialized
INFO - 2022-03-21 20:24:04 --> Security Class Initialized
INFO - 2022-03-21 20:24:04 --> Input Class Initialized
INFO - 2022-03-21 20:24:04 --> Language Class Initialized
INFO - 2022-03-21 20:24:04 --> Loader Class Initialized
INFO - 2022-03-21 20:24:04 --> Helper loaded: url_helper
INFO - 2022-03-21 20:24:04 --> Helper loaded: form_helper
INFO - 2022-03-21 20:24:04 --> Database Driver Class Initialized
INFO - 2022-03-21 20:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:24:04 --> Form Validation Class Initialized
INFO - 2022-03-21 20:24:04 --> Controller Class Initialized
INFO - 2022-03-21 20:24:04 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:24:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:24:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:24:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:24:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:24:05 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:24:05 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:24:05 --> Final output sent to browser
INFO - 2022-03-21 20:26:28 --> Config Class Initialized
INFO - 2022-03-21 20:26:28 --> Hooks Class Initialized
INFO - 2022-03-21 20:26:28 --> Utf8 Class Initialized
INFO - 2022-03-21 20:26:28 --> URI Class Initialized
INFO - 2022-03-21 20:26:28 --> Router Class Initialized
INFO - 2022-03-21 20:26:28 --> Output Class Initialized
INFO - 2022-03-21 20:26:28 --> Security Class Initialized
INFO - 2022-03-21 20:26:28 --> Input Class Initialized
INFO - 2022-03-21 20:26:28 --> Language Class Initialized
INFO - 2022-03-21 20:26:28 --> Loader Class Initialized
INFO - 2022-03-21 20:26:28 --> Helper loaded: url_helper
INFO - 2022-03-21 20:26:28 --> Helper loaded: form_helper
INFO - 2022-03-21 20:26:28 --> Database Driver Class Initialized
INFO - 2022-03-21 20:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:26:28 --> Form Validation Class Initialized
INFO - 2022-03-21 20:26:28 --> Controller Class Initialized
INFO - 2022-03-21 20:26:28 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:26:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:26:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:26:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:26:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:26:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:26:28 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:26:28 --> Final output sent to browser
INFO - 2022-03-21 20:29:01 --> Config Class Initialized
INFO - 2022-03-21 20:29:01 --> Hooks Class Initialized
INFO - 2022-03-21 20:29:01 --> Utf8 Class Initialized
INFO - 2022-03-21 20:29:01 --> URI Class Initialized
INFO - 2022-03-21 20:29:01 --> Router Class Initialized
INFO - 2022-03-21 20:29:01 --> Output Class Initialized
INFO - 2022-03-21 20:29:01 --> Security Class Initialized
INFO - 2022-03-21 20:29:01 --> Input Class Initialized
INFO - 2022-03-21 20:29:01 --> Language Class Initialized
INFO - 2022-03-21 20:29:01 --> Loader Class Initialized
INFO - 2022-03-21 20:29:01 --> Helper loaded: url_helper
INFO - 2022-03-21 20:29:01 --> Helper loaded: form_helper
INFO - 2022-03-21 20:29:01 --> Database Driver Class Initialized
INFO - 2022-03-21 20:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:29:01 --> Form Validation Class Initialized
INFO - 2022-03-21 20:29:01 --> Controller Class Initialized
INFO - 2022-03-21 20:29:01 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:29:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:29:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:29:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:29:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:29:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:29:01 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:29:01 --> Final output sent to browser
INFO - 2022-03-21 20:29:37 --> Config Class Initialized
INFO - 2022-03-21 20:29:37 --> Hooks Class Initialized
INFO - 2022-03-21 20:29:37 --> Utf8 Class Initialized
INFO - 2022-03-21 20:29:37 --> URI Class Initialized
INFO - 2022-03-21 20:29:37 --> Router Class Initialized
INFO - 2022-03-21 20:29:37 --> Output Class Initialized
INFO - 2022-03-21 20:29:37 --> Security Class Initialized
INFO - 2022-03-21 20:29:37 --> Input Class Initialized
INFO - 2022-03-21 20:29:37 --> Language Class Initialized
INFO - 2022-03-21 20:29:37 --> Loader Class Initialized
INFO - 2022-03-21 20:29:37 --> Helper loaded: url_helper
INFO - 2022-03-21 20:29:37 --> Helper loaded: form_helper
INFO - 2022-03-21 20:29:37 --> Database Driver Class Initialized
INFO - 2022-03-21 20:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:29:37 --> Form Validation Class Initialized
INFO - 2022-03-21 20:29:37 --> Controller Class Initialized
INFO - 2022-03-21 20:29:37 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:29:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:29:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:29:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:29:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:29:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:29:37 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:29:37 --> Final output sent to browser
INFO - 2022-03-21 20:30:41 --> Config Class Initialized
INFO - 2022-03-21 20:30:41 --> Hooks Class Initialized
INFO - 2022-03-21 20:30:41 --> Utf8 Class Initialized
INFO - 2022-03-21 20:30:41 --> URI Class Initialized
INFO - 2022-03-21 20:30:41 --> Router Class Initialized
INFO - 2022-03-21 20:30:41 --> Output Class Initialized
INFO - 2022-03-21 20:30:41 --> Security Class Initialized
INFO - 2022-03-21 20:30:41 --> Input Class Initialized
INFO - 2022-03-21 20:30:41 --> Language Class Initialized
INFO - 2022-03-21 20:30:41 --> Loader Class Initialized
INFO - 2022-03-21 20:30:41 --> Helper loaded: url_helper
INFO - 2022-03-21 20:30:41 --> Helper loaded: form_helper
INFO - 2022-03-21 20:30:41 --> Database Driver Class Initialized
INFO - 2022-03-21 20:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:30:41 --> Form Validation Class Initialized
INFO - 2022-03-21 20:30:41 --> Controller Class Initialized
INFO - 2022-03-21 20:30:41 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:30:41 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:30:41 --> Final output sent to browser
INFO - 2022-03-21 20:30:46 --> Config Class Initialized
INFO - 2022-03-21 20:30:46 --> Hooks Class Initialized
INFO - 2022-03-21 20:30:46 --> Utf8 Class Initialized
INFO - 2022-03-21 20:30:46 --> URI Class Initialized
INFO - 2022-03-21 20:30:46 --> Router Class Initialized
INFO - 2022-03-21 20:30:46 --> Output Class Initialized
INFO - 2022-03-21 20:30:46 --> Security Class Initialized
INFO - 2022-03-21 20:30:46 --> Input Class Initialized
INFO - 2022-03-21 20:30:46 --> Language Class Initialized
INFO - 2022-03-21 20:30:46 --> Loader Class Initialized
INFO - 2022-03-21 20:30:46 --> Helper loaded: url_helper
INFO - 2022-03-21 20:30:46 --> Helper loaded: form_helper
INFO - 2022-03-21 20:30:46 --> Database Driver Class Initialized
INFO - 2022-03-21 20:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:30:46 --> Form Validation Class Initialized
INFO - 2022-03-21 20:30:46 --> Controller Class Initialized
INFO - 2022-03-21 20:30:46 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:30:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:30:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:30:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:30:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:30:46 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:30:46 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:30:46 --> Final output sent to browser
INFO - 2022-03-21 20:30:57 --> Config Class Initialized
INFO - 2022-03-21 20:30:57 --> Hooks Class Initialized
INFO - 2022-03-21 20:30:57 --> Utf8 Class Initialized
INFO - 2022-03-21 20:30:57 --> URI Class Initialized
INFO - 2022-03-21 20:30:57 --> Router Class Initialized
INFO - 2022-03-21 20:30:57 --> Output Class Initialized
INFO - 2022-03-21 20:30:57 --> Security Class Initialized
INFO - 2022-03-21 20:30:57 --> Input Class Initialized
INFO - 2022-03-21 20:30:57 --> Language Class Initialized
INFO - 2022-03-21 20:30:57 --> Loader Class Initialized
INFO - 2022-03-21 20:30:57 --> Helper loaded: url_helper
INFO - 2022-03-21 20:30:57 --> Helper loaded: form_helper
INFO - 2022-03-21 20:30:57 --> Database Driver Class Initialized
INFO - 2022-03-21 20:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:30:57 --> Form Validation Class Initialized
INFO - 2022-03-21 20:30:57 --> Controller Class Initialized
INFO - 2022-03-21 20:30:57 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:30:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:30:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:30:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:30:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:30:57 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:30:57 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:30:57 --> Final output sent to browser
INFO - 2022-03-21 20:31:31 --> Config Class Initialized
INFO - 2022-03-21 20:31:31 --> Hooks Class Initialized
INFO - 2022-03-21 20:31:31 --> Utf8 Class Initialized
INFO - 2022-03-21 20:31:31 --> URI Class Initialized
INFO - 2022-03-21 20:31:31 --> Router Class Initialized
INFO - 2022-03-21 20:31:31 --> Output Class Initialized
INFO - 2022-03-21 20:31:31 --> Security Class Initialized
INFO - 2022-03-21 20:31:31 --> Input Class Initialized
INFO - 2022-03-21 20:31:31 --> Language Class Initialized
INFO - 2022-03-21 20:31:31 --> Loader Class Initialized
INFO - 2022-03-21 20:31:31 --> Helper loaded: url_helper
INFO - 2022-03-21 20:31:31 --> Helper loaded: form_helper
INFO - 2022-03-21 20:31:31 --> Database Driver Class Initialized
INFO - 2022-03-21 20:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:31:31 --> Form Validation Class Initialized
INFO - 2022-03-21 20:31:31 --> Controller Class Initialized
INFO - 2022-03-21 20:31:31 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:31:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:31:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:31:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:31:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:31:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:31:31 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:31:31 --> Final output sent to browser
INFO - 2022-03-21 20:33:06 --> Config Class Initialized
INFO - 2022-03-21 20:33:06 --> Hooks Class Initialized
INFO - 2022-03-21 20:33:06 --> Utf8 Class Initialized
INFO - 2022-03-21 20:33:06 --> URI Class Initialized
INFO - 2022-03-21 20:33:06 --> Router Class Initialized
INFO - 2022-03-21 20:33:06 --> Output Class Initialized
INFO - 2022-03-21 20:33:06 --> Security Class Initialized
INFO - 2022-03-21 20:33:06 --> Input Class Initialized
INFO - 2022-03-21 20:33:07 --> Language Class Initialized
INFO - 2022-03-21 20:33:07 --> Loader Class Initialized
INFO - 2022-03-21 20:33:07 --> Helper loaded: url_helper
INFO - 2022-03-21 20:33:07 --> Helper loaded: form_helper
INFO - 2022-03-21 20:33:07 --> Database Driver Class Initialized
INFO - 2022-03-21 20:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:33:07 --> Form Validation Class Initialized
INFO - 2022-03-21 20:33:07 --> Controller Class Initialized
INFO - 2022-03-21 20:33:07 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:33:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:33:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:33:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:33:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:33:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:33:07 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:33:07 --> Final output sent to browser
INFO - 2022-03-21 20:34:58 --> Config Class Initialized
INFO - 2022-03-21 20:34:58 --> Hooks Class Initialized
INFO - 2022-03-21 20:34:58 --> Utf8 Class Initialized
INFO - 2022-03-21 20:34:58 --> URI Class Initialized
INFO - 2022-03-21 20:34:58 --> Router Class Initialized
INFO - 2022-03-21 20:34:58 --> Output Class Initialized
INFO - 2022-03-21 20:34:58 --> Security Class Initialized
INFO - 2022-03-21 20:34:58 --> Input Class Initialized
INFO - 2022-03-21 20:34:58 --> Language Class Initialized
INFO - 2022-03-21 20:34:58 --> Loader Class Initialized
INFO - 2022-03-21 20:34:58 --> Helper loaded: url_helper
INFO - 2022-03-21 20:34:58 --> Helper loaded: form_helper
INFO - 2022-03-21 20:34:58 --> Database Driver Class Initialized
INFO - 2022-03-21 20:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:34:58 --> Form Validation Class Initialized
INFO - 2022-03-21 20:34:58 --> Controller Class Initialized
INFO - 2022-03-21 20:34:58 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:34:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:34:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:34:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:34:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:34:58 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:34:58 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:34:58 --> Final output sent to browser
INFO - 2022-03-21 20:40:23 --> Config Class Initialized
INFO - 2022-03-21 20:40:23 --> Hooks Class Initialized
INFO - 2022-03-21 20:40:23 --> Utf8 Class Initialized
INFO - 2022-03-21 20:40:23 --> URI Class Initialized
INFO - 2022-03-21 20:40:23 --> Router Class Initialized
INFO - 2022-03-21 20:40:23 --> Output Class Initialized
INFO - 2022-03-21 20:40:23 --> Security Class Initialized
INFO - 2022-03-21 20:40:23 --> Input Class Initialized
INFO - 2022-03-21 20:40:23 --> Language Class Initialized
INFO - 2022-03-21 20:40:23 --> Loader Class Initialized
INFO - 2022-03-21 20:40:23 --> Helper loaded: url_helper
INFO - 2022-03-21 20:40:23 --> Helper loaded: form_helper
INFO - 2022-03-21 20:40:23 --> Database Driver Class Initialized
INFO - 2022-03-21 20:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:40:23 --> Form Validation Class Initialized
INFO - 2022-03-21 20:40:23 --> Controller Class Initialized
INFO - 2022-03-21 20:40:23 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:40:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:40:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:40:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:40:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:40:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:40:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:40:23 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:40:23 --> Final output sent to browser
INFO - 2022-03-21 20:40:33 --> Config Class Initialized
INFO - 2022-03-21 20:40:33 --> Hooks Class Initialized
INFO - 2022-03-21 20:40:33 --> Utf8 Class Initialized
INFO - 2022-03-21 20:40:33 --> URI Class Initialized
INFO - 2022-03-21 20:40:33 --> Router Class Initialized
INFO - 2022-03-21 20:40:33 --> Output Class Initialized
INFO - 2022-03-21 20:40:33 --> Security Class Initialized
INFO - 2022-03-21 20:40:33 --> Input Class Initialized
INFO - 2022-03-21 20:40:33 --> Language Class Initialized
INFO - 2022-03-21 20:40:33 --> Loader Class Initialized
INFO - 2022-03-21 20:40:33 --> Helper loaded: url_helper
INFO - 2022-03-21 20:40:33 --> Helper loaded: form_helper
INFO - 2022-03-21 20:40:33 --> Database Driver Class Initialized
INFO - 2022-03-21 20:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:40:33 --> Form Validation Class Initialized
INFO - 2022-03-21 20:40:33 --> Controller Class Initialized
INFO - 2022-03-21 20:40:33 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:40:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:40:33 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:40:33 --> Final output sent to browser
INFO - 2022-03-21 20:41:08 --> Config Class Initialized
INFO - 2022-03-21 20:41:08 --> Hooks Class Initialized
INFO - 2022-03-21 20:41:08 --> Utf8 Class Initialized
INFO - 2022-03-21 20:41:08 --> URI Class Initialized
INFO - 2022-03-21 20:41:08 --> Router Class Initialized
INFO - 2022-03-21 20:41:08 --> Output Class Initialized
INFO - 2022-03-21 20:41:08 --> Security Class Initialized
INFO - 2022-03-21 20:41:08 --> Input Class Initialized
INFO - 2022-03-21 20:41:08 --> Language Class Initialized
INFO - 2022-03-21 20:41:08 --> Loader Class Initialized
INFO - 2022-03-21 20:41:08 --> Helper loaded: url_helper
INFO - 2022-03-21 20:41:08 --> Helper loaded: form_helper
INFO - 2022-03-21 20:41:08 --> Database Driver Class Initialized
INFO - 2022-03-21 20:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:41:08 --> Form Validation Class Initialized
INFO - 2022-03-21 20:41:08 --> Controller Class Initialized
INFO - 2022-03-21 20:41:08 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:41:08 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:41:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:41:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:41:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:41:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:41:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:41:08 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:41:08 --> Final output sent to browser
INFO - 2022-03-21 20:44:07 --> Config Class Initialized
INFO - 2022-03-21 20:44:07 --> Hooks Class Initialized
INFO - 2022-03-21 20:44:07 --> Utf8 Class Initialized
INFO - 2022-03-21 20:44:08 --> URI Class Initialized
INFO - 2022-03-21 20:44:08 --> Router Class Initialized
INFO - 2022-03-21 20:44:08 --> Output Class Initialized
INFO - 2022-03-21 20:44:08 --> Security Class Initialized
INFO - 2022-03-21 20:44:08 --> Input Class Initialized
INFO - 2022-03-21 20:44:08 --> Language Class Initialized
INFO - 2022-03-21 20:44:08 --> Loader Class Initialized
INFO - 2022-03-21 20:44:08 --> Helper loaded: url_helper
INFO - 2022-03-21 20:44:08 --> Helper loaded: form_helper
INFO - 2022-03-21 20:44:08 --> Database Driver Class Initialized
INFO - 2022-03-21 20:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:44:08 --> Form Validation Class Initialized
INFO - 2022-03-21 20:44:08 --> Controller Class Initialized
INFO - 2022-03-21 20:44:08 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:44:08 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:44:08 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:44:08 --> Final output sent to browser
INFO - 2022-03-21 20:44:23 --> Config Class Initialized
INFO - 2022-03-21 20:44:23 --> Hooks Class Initialized
INFO - 2022-03-21 20:44:23 --> Utf8 Class Initialized
INFO - 2022-03-21 20:44:23 --> URI Class Initialized
INFO - 2022-03-21 20:44:23 --> Router Class Initialized
INFO - 2022-03-21 20:44:23 --> Output Class Initialized
INFO - 2022-03-21 20:44:23 --> Security Class Initialized
INFO - 2022-03-21 20:44:23 --> Input Class Initialized
INFO - 2022-03-21 20:44:23 --> Language Class Initialized
INFO - 2022-03-21 20:44:23 --> Loader Class Initialized
INFO - 2022-03-21 20:44:23 --> Helper loaded: url_helper
INFO - 2022-03-21 20:44:23 --> Helper loaded: form_helper
INFO - 2022-03-21 20:44:23 --> Database Driver Class Initialized
INFO - 2022-03-21 20:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:44:23 --> Form Validation Class Initialized
INFO - 2022-03-21 20:44:23 --> Controller Class Initialized
INFO - 2022-03-21 20:44:23 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:44:23 --> Config Class Initialized
INFO - 2022-03-21 20:44:23 --> Hooks Class Initialized
INFO - 2022-03-21 20:44:23 --> Utf8 Class Initialized
INFO - 2022-03-21 20:44:23 --> URI Class Initialized
INFO - 2022-03-21 20:44:23 --> Router Class Initialized
INFO - 2022-03-21 20:44:23 --> Output Class Initialized
INFO - 2022-03-21 20:44:23 --> Security Class Initialized
INFO - 2022-03-21 20:44:23 --> Input Class Initialized
INFO - 2022-03-21 20:44:23 --> Language Class Initialized
INFO - 2022-03-21 20:44:23 --> Loader Class Initialized
INFO - 2022-03-21 20:44:23 --> Helper loaded: url_helper
INFO - 2022-03-21 20:44:23 --> Helper loaded: form_helper
INFO - 2022-03-21 20:44:23 --> Database Driver Class Initialized
INFO - 2022-03-21 20:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:44:23 --> Form Validation Class Initialized
INFO - 2022-03-21 20:44:23 --> Controller Class Initialized
INFO - 2022-03-21 20:44:23 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:44:23 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-21 20:44:23 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-21 20:44:23 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-21 20:44:23 --> Final output sent to browser
INFO - 2022-03-21 20:44:33 --> Config Class Initialized
INFO - 2022-03-21 20:44:33 --> Hooks Class Initialized
INFO - 2022-03-21 20:44:33 --> Utf8 Class Initialized
INFO - 2022-03-21 20:44:33 --> URI Class Initialized
INFO - 2022-03-21 20:44:33 --> Router Class Initialized
INFO - 2022-03-21 20:44:33 --> Output Class Initialized
INFO - 2022-03-21 20:44:33 --> Security Class Initialized
INFO - 2022-03-21 20:44:33 --> Input Class Initialized
INFO - 2022-03-21 20:44:33 --> Language Class Initialized
INFO - 2022-03-21 20:44:33 --> Loader Class Initialized
INFO - 2022-03-21 20:44:33 --> Helper loaded: url_helper
INFO - 2022-03-21 20:44:33 --> Helper loaded: form_helper
INFO - 2022-03-21 20:44:33 --> Database Driver Class Initialized
INFO - 2022-03-21 20:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:44:33 --> Form Validation Class Initialized
INFO - 2022-03-21 20:44:33 --> Controller Class Initialized
INFO - 2022-03-21 20:44:33 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:44:33 --> Config Class Initialized
INFO - 2022-03-21 20:44:33 --> Hooks Class Initialized
INFO - 2022-03-21 20:44:33 --> Utf8 Class Initialized
INFO - 2022-03-21 20:44:33 --> URI Class Initialized
INFO - 2022-03-21 20:44:33 --> Router Class Initialized
INFO - 2022-03-21 20:44:33 --> Output Class Initialized
INFO - 2022-03-21 20:44:33 --> Security Class Initialized
INFO - 2022-03-21 20:44:33 --> Input Class Initialized
INFO - 2022-03-21 20:44:33 --> Language Class Initialized
INFO - 2022-03-21 20:44:33 --> Loader Class Initialized
INFO - 2022-03-21 20:44:33 --> Helper loaded: url_helper
INFO - 2022-03-21 20:44:33 --> Helper loaded: form_helper
INFO - 2022-03-21 20:44:33 --> Database Driver Class Initialized
INFO - 2022-03-21 20:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:44:33 --> Form Validation Class Initialized
INFO - 2022-03-21 20:44:33 --> Controller Class Initialized
INFO - 2022-03-21 20:44:33 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:44:33 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-21 20:44:33 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-21 20:44:33 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-21 20:44:33 --> Final output sent to browser
INFO - 2022-03-21 20:44:48 --> Config Class Initialized
INFO - 2022-03-21 20:44:48 --> Hooks Class Initialized
INFO - 2022-03-21 20:44:48 --> Utf8 Class Initialized
INFO - 2022-03-21 20:44:48 --> URI Class Initialized
INFO - 2022-03-21 20:44:48 --> Router Class Initialized
INFO - 2022-03-21 20:44:48 --> Output Class Initialized
INFO - 2022-03-21 20:44:48 --> Security Class Initialized
INFO - 2022-03-21 20:44:48 --> Input Class Initialized
INFO - 2022-03-21 20:44:48 --> Language Class Initialized
INFO - 2022-03-21 20:44:48 --> Loader Class Initialized
INFO - 2022-03-21 20:44:48 --> Helper loaded: url_helper
INFO - 2022-03-21 20:44:48 --> Helper loaded: form_helper
INFO - 2022-03-21 20:44:48 --> Database Driver Class Initialized
INFO - 2022-03-21 20:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:44:48 --> Form Validation Class Initialized
INFO - 2022-03-21 20:44:48 --> Controller Class Initialized
INFO - 2022-03-21 20:44:48 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:44:48 --> Config Class Initialized
INFO - 2022-03-21 20:44:48 --> Hooks Class Initialized
INFO - 2022-03-21 20:44:48 --> Utf8 Class Initialized
INFO - 2022-03-21 20:44:48 --> URI Class Initialized
INFO - 2022-03-21 20:44:48 --> Router Class Initialized
INFO - 2022-03-21 20:44:48 --> Output Class Initialized
INFO - 2022-03-21 20:44:48 --> Security Class Initialized
INFO - 2022-03-21 20:44:48 --> Input Class Initialized
INFO - 2022-03-21 20:44:48 --> Language Class Initialized
INFO - 2022-03-21 20:44:48 --> Loader Class Initialized
INFO - 2022-03-21 20:44:48 --> Helper loaded: url_helper
INFO - 2022-03-21 20:44:48 --> Helper loaded: form_helper
INFO - 2022-03-21 20:44:48 --> Database Driver Class Initialized
INFO - 2022-03-21 20:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:44:48 --> Form Validation Class Initialized
INFO - 2022-03-21 20:44:48 --> Controller Class Initialized
INFO - 2022-03-21 20:44:48 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:44:48 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-21 20:44:48 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-21 20:44:48 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-21 20:44:48 --> Final output sent to browser
INFO - 2022-03-21 20:45:20 --> Config Class Initialized
INFO - 2022-03-21 20:45:20 --> Hooks Class Initialized
INFO - 2022-03-21 20:45:20 --> Utf8 Class Initialized
INFO - 2022-03-21 20:45:20 --> URI Class Initialized
INFO - 2022-03-21 20:45:20 --> Router Class Initialized
INFO - 2022-03-21 20:45:20 --> Output Class Initialized
INFO - 2022-03-21 20:45:20 --> Security Class Initialized
INFO - 2022-03-21 20:45:20 --> Input Class Initialized
INFO - 2022-03-21 20:45:20 --> Language Class Initialized
INFO - 2022-03-21 20:45:20 --> Loader Class Initialized
INFO - 2022-03-21 20:45:20 --> Helper loaded: url_helper
INFO - 2022-03-21 20:45:20 --> Helper loaded: form_helper
INFO - 2022-03-21 20:45:20 --> Database Driver Class Initialized
INFO - 2022-03-21 20:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:45:20 --> Form Validation Class Initialized
INFO - 2022-03-21 20:45:20 --> Controller Class Initialized
INFO - 2022-03-21 20:45:20 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:45:20 --> Config Class Initialized
INFO - 2022-03-21 20:45:20 --> Hooks Class Initialized
INFO - 2022-03-21 20:45:20 --> Utf8 Class Initialized
INFO - 2022-03-21 20:45:20 --> URI Class Initialized
INFO - 2022-03-21 20:45:20 --> Router Class Initialized
INFO - 2022-03-21 20:45:20 --> Output Class Initialized
INFO - 2022-03-21 20:45:20 --> Security Class Initialized
INFO - 2022-03-21 20:45:20 --> Input Class Initialized
INFO - 2022-03-21 20:45:20 --> Language Class Initialized
INFO - 2022-03-21 20:45:20 --> Loader Class Initialized
INFO - 2022-03-21 20:45:20 --> Helper loaded: url_helper
INFO - 2022-03-21 20:45:20 --> Helper loaded: form_helper
INFO - 2022-03-21 20:45:20 --> Database Driver Class Initialized
INFO - 2022-03-21 20:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:45:20 --> Form Validation Class Initialized
INFO - 2022-03-21 20:45:20 --> Controller Class Initialized
INFO - 2022-03-21 20:45:20 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:45:20 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:45:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:45:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:45:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:45:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:45:20 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:45:20 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:45:21 --> Final output sent to browser
INFO - 2022-03-21 20:45:48 --> Config Class Initialized
INFO - 2022-03-21 20:45:48 --> Hooks Class Initialized
INFO - 2022-03-21 20:45:48 --> Utf8 Class Initialized
INFO - 2022-03-21 20:45:48 --> URI Class Initialized
INFO - 2022-03-21 20:45:48 --> Router Class Initialized
INFO - 2022-03-21 20:45:48 --> Output Class Initialized
INFO - 2022-03-21 20:45:48 --> Security Class Initialized
INFO - 2022-03-21 20:45:48 --> Input Class Initialized
INFO - 2022-03-21 20:45:48 --> Language Class Initialized
INFO - 2022-03-21 20:45:48 --> Loader Class Initialized
INFO - 2022-03-21 20:45:48 --> Helper loaded: url_helper
INFO - 2022-03-21 20:45:48 --> Helper loaded: form_helper
INFO - 2022-03-21 20:45:48 --> Database Driver Class Initialized
INFO - 2022-03-21 20:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:45:48 --> Form Validation Class Initialized
INFO - 2022-03-21 20:45:48 --> Controller Class Initialized
INFO - 2022-03-21 20:45:48 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:45:48 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:45:48 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:45:48 --> Final output sent to browser
INFO - 2022-03-21 20:45:59 --> Config Class Initialized
INFO - 2022-03-21 20:45:59 --> Hooks Class Initialized
INFO - 2022-03-21 20:45:59 --> Utf8 Class Initialized
INFO - 2022-03-21 20:45:59 --> URI Class Initialized
INFO - 2022-03-21 20:45:59 --> Router Class Initialized
INFO - 2022-03-21 20:45:59 --> Output Class Initialized
INFO - 2022-03-21 20:45:59 --> Security Class Initialized
INFO - 2022-03-21 20:45:59 --> Input Class Initialized
INFO - 2022-03-21 20:45:59 --> Language Class Initialized
INFO - 2022-03-21 20:45:59 --> Loader Class Initialized
INFO - 2022-03-21 20:45:59 --> Helper loaded: url_helper
INFO - 2022-03-21 20:45:59 --> Helper loaded: form_helper
INFO - 2022-03-21 20:45:59 --> Database Driver Class Initialized
INFO - 2022-03-21 20:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:45:59 --> Form Validation Class Initialized
INFO - 2022-03-21 20:45:59 --> Controller Class Initialized
INFO - 2022-03-21 20:45:59 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:45:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:45:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:45:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:45:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:45:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:45:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:45:59 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:45:59 --> Final output sent to browser
INFO - 2022-03-21 20:46:08 --> Config Class Initialized
INFO - 2022-03-21 20:46:08 --> Hooks Class Initialized
INFO - 2022-03-21 20:46:08 --> Utf8 Class Initialized
INFO - 2022-03-21 20:46:08 --> URI Class Initialized
INFO - 2022-03-21 20:46:08 --> Router Class Initialized
INFO - 2022-03-21 20:46:08 --> Output Class Initialized
INFO - 2022-03-21 20:46:08 --> Security Class Initialized
INFO - 2022-03-21 20:46:08 --> Input Class Initialized
INFO - 2022-03-21 20:46:08 --> Language Class Initialized
INFO - 2022-03-21 20:46:08 --> Loader Class Initialized
INFO - 2022-03-21 20:46:08 --> Helper loaded: url_helper
INFO - 2022-03-21 20:46:08 --> Helper loaded: form_helper
INFO - 2022-03-21 20:46:08 --> Database Driver Class Initialized
INFO - 2022-03-21 20:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:46:08 --> Form Validation Class Initialized
INFO - 2022-03-21 20:46:08 --> Controller Class Initialized
INFO - 2022-03-21 20:46:08 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:46:08 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:46:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:46:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:46:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:46:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:46:08 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:46:08 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:46:08 --> Final output sent to browser
INFO - 2022-03-21 20:48:11 --> Config Class Initialized
INFO - 2022-03-21 20:48:11 --> Hooks Class Initialized
INFO - 2022-03-21 20:48:11 --> Utf8 Class Initialized
INFO - 2022-03-21 20:48:11 --> URI Class Initialized
INFO - 2022-03-21 20:48:11 --> Router Class Initialized
INFO - 2022-03-21 20:48:11 --> Output Class Initialized
INFO - 2022-03-21 20:48:12 --> Security Class Initialized
INFO - 2022-03-21 20:48:12 --> Input Class Initialized
INFO - 2022-03-21 20:48:12 --> Language Class Initialized
INFO - 2022-03-21 20:48:12 --> Loader Class Initialized
INFO - 2022-03-21 20:48:12 --> Helper loaded: url_helper
INFO - 2022-03-21 20:48:12 --> Helper loaded: form_helper
INFO - 2022-03-21 20:48:12 --> Database Driver Class Initialized
INFO - 2022-03-21 20:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:48:12 --> Form Validation Class Initialized
INFO - 2022-03-21 20:48:12 --> Controller Class Initialized
INFO - 2022-03-21 20:48:12 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:48:12 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:48:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:48:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:48:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:48:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:48:12 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:48:12 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:48:12 --> Final output sent to browser
INFO - 2022-03-21 20:48:30 --> Config Class Initialized
INFO - 2022-03-21 20:48:30 --> Hooks Class Initialized
INFO - 2022-03-21 20:48:30 --> Utf8 Class Initialized
INFO - 2022-03-21 20:48:31 --> URI Class Initialized
INFO - 2022-03-21 20:48:31 --> Router Class Initialized
INFO - 2022-03-21 20:48:31 --> Output Class Initialized
INFO - 2022-03-21 20:48:31 --> Security Class Initialized
INFO - 2022-03-21 20:48:31 --> Input Class Initialized
INFO - 2022-03-21 20:48:31 --> Language Class Initialized
INFO - 2022-03-21 20:48:31 --> Loader Class Initialized
INFO - 2022-03-21 20:48:31 --> Helper loaded: url_helper
INFO - 2022-03-21 20:48:31 --> Helper loaded: form_helper
INFO - 2022-03-21 20:48:31 --> Database Driver Class Initialized
INFO - 2022-03-21 20:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:48:31 --> Form Validation Class Initialized
INFO - 2022-03-21 20:48:31 --> Controller Class Initialized
INFO - 2022-03-21 20:48:31 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:48:31 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:48:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:48:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:48:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:48:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:48:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:48:31 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:48:31 --> Final output sent to browser
INFO - 2022-03-21 20:48:40 --> Config Class Initialized
INFO - 2022-03-21 20:48:40 --> Hooks Class Initialized
INFO - 2022-03-21 20:48:40 --> Utf8 Class Initialized
INFO - 2022-03-21 20:48:40 --> URI Class Initialized
INFO - 2022-03-21 20:48:40 --> Router Class Initialized
INFO - 2022-03-21 20:48:40 --> Output Class Initialized
INFO - 2022-03-21 20:48:40 --> Security Class Initialized
INFO - 2022-03-21 20:48:40 --> Input Class Initialized
INFO - 2022-03-21 20:48:40 --> Language Class Initialized
INFO - 2022-03-21 20:48:40 --> Loader Class Initialized
INFO - 2022-03-21 20:48:40 --> Helper loaded: url_helper
INFO - 2022-03-21 20:48:40 --> Helper loaded: form_helper
INFO - 2022-03-21 20:48:40 --> Database Driver Class Initialized
INFO - 2022-03-21 20:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:48:40 --> Form Validation Class Initialized
INFO - 2022-03-21 20:48:40 --> Controller Class Initialized
INFO - 2022-03-21 20:48:40 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:48:40 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:48:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:48:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:48:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:48:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:48:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:48:40 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:48:40 --> Final output sent to browser
INFO - 2022-03-21 20:49:28 --> Config Class Initialized
INFO - 2022-03-21 20:49:28 --> Hooks Class Initialized
INFO - 2022-03-21 20:49:28 --> Utf8 Class Initialized
INFO - 2022-03-21 20:49:28 --> URI Class Initialized
INFO - 2022-03-21 20:49:28 --> Router Class Initialized
INFO - 2022-03-21 20:49:28 --> Output Class Initialized
INFO - 2022-03-21 20:49:28 --> Security Class Initialized
INFO - 2022-03-21 20:49:28 --> Input Class Initialized
INFO - 2022-03-21 20:49:28 --> Language Class Initialized
INFO - 2022-03-21 20:49:28 --> Loader Class Initialized
INFO - 2022-03-21 20:49:28 --> Helper loaded: url_helper
INFO - 2022-03-21 20:49:28 --> Helper loaded: form_helper
INFO - 2022-03-21 20:49:28 --> Database Driver Class Initialized
INFO - 2022-03-21 20:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:49:28 --> Form Validation Class Initialized
INFO - 2022-03-21 20:49:28 --> Controller Class Initialized
INFO - 2022-03-21 20:49:28 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:49:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:49:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:49:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:49:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:49:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:49:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:49:28 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:49:28 --> Final output sent to browser
INFO - 2022-03-21 20:49:56 --> Config Class Initialized
INFO - 2022-03-21 20:49:56 --> Hooks Class Initialized
INFO - 2022-03-21 20:49:56 --> Utf8 Class Initialized
INFO - 2022-03-21 20:49:56 --> URI Class Initialized
INFO - 2022-03-21 20:49:56 --> Router Class Initialized
INFO - 2022-03-21 20:49:56 --> Output Class Initialized
INFO - 2022-03-21 20:49:56 --> Security Class Initialized
INFO - 2022-03-21 20:49:56 --> Input Class Initialized
INFO - 2022-03-21 20:49:56 --> Language Class Initialized
INFO - 2022-03-21 20:49:56 --> Loader Class Initialized
INFO - 2022-03-21 20:49:56 --> Helper loaded: url_helper
INFO - 2022-03-21 20:49:56 --> Helper loaded: form_helper
INFO - 2022-03-21 20:49:56 --> Database Driver Class Initialized
INFO - 2022-03-21 20:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:49:56 --> Form Validation Class Initialized
INFO - 2022-03-21 20:49:56 --> Controller Class Initialized
INFO - 2022-03-21 20:49:56 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:49:56 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:49:56 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:49:56 --> Final output sent to browser
INFO - 2022-03-21 20:51:11 --> Config Class Initialized
INFO - 2022-03-21 20:51:11 --> Hooks Class Initialized
INFO - 2022-03-21 20:51:11 --> Utf8 Class Initialized
INFO - 2022-03-21 20:51:11 --> URI Class Initialized
INFO - 2022-03-21 20:51:11 --> Router Class Initialized
INFO - 2022-03-21 20:51:11 --> Output Class Initialized
INFO - 2022-03-21 20:51:11 --> Security Class Initialized
INFO - 2022-03-21 20:51:11 --> Input Class Initialized
INFO - 2022-03-21 20:51:11 --> Language Class Initialized
INFO - 2022-03-21 20:51:11 --> Loader Class Initialized
INFO - 2022-03-21 20:51:11 --> Helper loaded: url_helper
INFO - 2022-03-21 20:51:11 --> Helper loaded: form_helper
INFO - 2022-03-21 20:51:11 --> Database Driver Class Initialized
INFO - 2022-03-21 20:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:51:11 --> Form Validation Class Initialized
INFO - 2022-03-21 20:51:11 --> Controller Class Initialized
INFO - 2022-03-21 20:51:11 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:51:11 --> Model "M_todo_group_ptk" initialized
ERROR - 2022-03-21 20:51:12 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\laragon\www\list-todo\application\views\home.php 89
INFO - 2022-03-21 20:51:12 --> Config Class Initialized
INFO - 2022-03-21 20:51:12 --> Hooks Class Initialized
INFO - 2022-03-21 20:51:12 --> Utf8 Class Initialized
INFO - 2022-03-21 20:51:12 --> URI Class Initialized
INFO - 2022-03-21 20:51:12 --> Router Class Initialized
INFO - 2022-03-21 20:51:12 --> Output Class Initialized
INFO - 2022-03-21 20:51:12 --> Security Class Initialized
INFO - 2022-03-21 20:51:12 --> Input Class Initialized
INFO - 2022-03-21 20:51:12 --> Language Class Initialized
ERROR - 2022-03-21 20:51:12 --> 404 Page Not Found: Faviconico/index
INFO - 2022-03-21 20:51:31 --> Config Class Initialized
INFO - 2022-03-21 20:51:31 --> Hooks Class Initialized
INFO - 2022-03-21 20:51:31 --> Utf8 Class Initialized
INFO - 2022-03-21 20:51:31 --> URI Class Initialized
INFO - 2022-03-21 20:51:31 --> Router Class Initialized
INFO - 2022-03-21 20:51:31 --> Output Class Initialized
INFO - 2022-03-21 20:51:31 --> Security Class Initialized
INFO - 2022-03-21 20:51:31 --> Input Class Initialized
INFO - 2022-03-21 20:51:31 --> Language Class Initialized
INFO - 2022-03-21 20:51:31 --> Loader Class Initialized
INFO - 2022-03-21 20:51:31 --> Helper loaded: url_helper
INFO - 2022-03-21 20:51:31 --> Helper loaded: form_helper
INFO - 2022-03-21 20:51:31 --> Database Driver Class Initialized
INFO - 2022-03-21 20:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:51:31 --> Form Validation Class Initialized
INFO - 2022-03-21 20:51:31 --> Controller Class Initialized
INFO - 2022-03-21 20:51:31 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:51:31 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:51:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:51:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:51:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:51:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:51:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:51:31 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:51:31 --> Final output sent to browser
INFO - 2022-03-21 20:52:15 --> Config Class Initialized
INFO - 2022-03-21 20:52:15 --> Hooks Class Initialized
INFO - 2022-03-21 20:52:15 --> Utf8 Class Initialized
INFO - 2022-03-21 20:52:15 --> URI Class Initialized
INFO - 2022-03-21 20:52:15 --> Router Class Initialized
INFO - 2022-03-21 20:52:15 --> Output Class Initialized
INFO - 2022-03-21 20:52:15 --> Security Class Initialized
INFO - 2022-03-21 20:52:15 --> Input Class Initialized
INFO - 2022-03-21 20:52:15 --> Language Class Initialized
INFO - 2022-03-21 20:52:15 --> Loader Class Initialized
INFO - 2022-03-21 20:52:15 --> Helper loaded: url_helper
INFO - 2022-03-21 20:52:15 --> Helper loaded: form_helper
INFO - 2022-03-21 20:52:15 --> Database Driver Class Initialized
INFO - 2022-03-21 20:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:52:15 --> Form Validation Class Initialized
INFO - 2022-03-21 20:52:15 --> Controller Class Initialized
INFO - 2022-03-21 20:52:15 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:52:15 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:52:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:52:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:52:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:52:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:52:15 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:52:15 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:52:15 --> Final output sent to browser
INFO - 2022-03-21 20:54:27 --> Config Class Initialized
INFO - 2022-03-21 20:54:27 --> Hooks Class Initialized
INFO - 2022-03-21 20:54:27 --> Utf8 Class Initialized
INFO - 2022-03-21 20:54:27 --> URI Class Initialized
INFO - 2022-03-21 20:54:27 --> Router Class Initialized
INFO - 2022-03-21 20:54:27 --> Output Class Initialized
INFO - 2022-03-21 20:54:27 --> Security Class Initialized
INFO - 2022-03-21 20:54:27 --> Input Class Initialized
INFO - 2022-03-21 20:54:27 --> Language Class Initialized
INFO - 2022-03-21 20:54:27 --> Loader Class Initialized
INFO - 2022-03-21 20:54:27 --> Helper loaded: url_helper
INFO - 2022-03-21 20:54:27 --> Helper loaded: form_helper
INFO - 2022-03-21 20:54:27 --> Database Driver Class Initialized
INFO - 2022-03-21 20:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:54:28 --> Form Validation Class Initialized
INFO - 2022-03-21 20:54:28 --> Controller Class Initialized
INFO - 2022-03-21 20:54:28 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:54:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:54:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:54:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:54:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:54:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:54:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:54:28 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:54:28 --> Final output sent to browser
INFO - 2022-03-21 20:54:40 --> Config Class Initialized
INFO - 2022-03-21 20:54:40 --> Hooks Class Initialized
INFO - 2022-03-21 20:54:40 --> Utf8 Class Initialized
INFO - 2022-03-21 20:54:40 --> URI Class Initialized
INFO - 2022-03-21 20:54:40 --> Router Class Initialized
INFO - 2022-03-21 20:54:40 --> Output Class Initialized
INFO - 2022-03-21 20:54:40 --> Security Class Initialized
INFO - 2022-03-21 20:54:40 --> Input Class Initialized
INFO - 2022-03-21 20:54:40 --> Language Class Initialized
INFO - 2022-03-21 20:54:40 --> Loader Class Initialized
INFO - 2022-03-21 20:54:40 --> Helper loaded: url_helper
INFO - 2022-03-21 20:54:40 --> Helper loaded: form_helper
INFO - 2022-03-21 20:54:40 --> Database Driver Class Initialized
INFO - 2022-03-21 20:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:54:40 --> Form Validation Class Initialized
INFO - 2022-03-21 20:54:40 --> Controller Class Initialized
INFO - 2022-03-21 20:54:40 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:54:40 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:54:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:54:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:54:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:54:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:54:40 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:54:40 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:54:40 --> Final output sent to browser
INFO - 2022-03-21 20:55:33 --> Config Class Initialized
INFO - 2022-03-21 20:55:33 --> Hooks Class Initialized
INFO - 2022-03-21 20:55:33 --> Utf8 Class Initialized
INFO - 2022-03-21 20:55:33 --> URI Class Initialized
INFO - 2022-03-21 20:55:33 --> Router Class Initialized
INFO - 2022-03-21 20:55:33 --> Output Class Initialized
INFO - 2022-03-21 20:55:33 --> Security Class Initialized
INFO - 2022-03-21 20:55:33 --> Input Class Initialized
INFO - 2022-03-21 20:55:33 --> Language Class Initialized
INFO - 2022-03-21 20:55:33 --> Loader Class Initialized
INFO - 2022-03-21 20:55:33 --> Helper loaded: url_helper
INFO - 2022-03-21 20:55:33 --> Helper loaded: form_helper
INFO - 2022-03-21 20:55:33 --> Database Driver Class Initialized
INFO - 2022-03-21 20:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:55:33 --> Form Validation Class Initialized
INFO - 2022-03-21 20:55:33 --> Controller Class Initialized
INFO - 2022-03-21 20:55:33 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:55:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:55:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:55:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:55:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:55:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:55:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:55:33 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:55:33 --> Final output sent to browser
INFO - 2022-03-21 20:55:56 --> Config Class Initialized
INFO - 2022-03-21 20:55:56 --> Hooks Class Initialized
INFO - 2022-03-21 20:55:56 --> Utf8 Class Initialized
INFO - 2022-03-21 20:55:56 --> URI Class Initialized
INFO - 2022-03-21 20:55:56 --> Router Class Initialized
INFO - 2022-03-21 20:55:56 --> Output Class Initialized
INFO - 2022-03-21 20:55:56 --> Security Class Initialized
INFO - 2022-03-21 20:55:56 --> Input Class Initialized
INFO - 2022-03-21 20:55:56 --> Language Class Initialized
INFO - 2022-03-21 20:55:56 --> Loader Class Initialized
INFO - 2022-03-21 20:55:56 --> Helper loaded: url_helper
INFO - 2022-03-21 20:55:56 --> Helper loaded: form_helper
INFO - 2022-03-21 20:55:56 --> Database Driver Class Initialized
INFO - 2022-03-21 20:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:55:56 --> Form Validation Class Initialized
INFO - 2022-03-21 20:55:56 --> Controller Class Initialized
INFO - 2022-03-21 20:55:56 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:55:56 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:55:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:55:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:55:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:55:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:55:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:55:56 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:55:56 --> Final output sent to browser
INFO - 2022-03-21 20:56:23 --> Config Class Initialized
INFO - 2022-03-21 20:56:23 --> Hooks Class Initialized
INFO - 2022-03-21 20:56:23 --> Utf8 Class Initialized
INFO - 2022-03-21 20:56:23 --> URI Class Initialized
INFO - 2022-03-21 20:56:23 --> Router Class Initialized
INFO - 2022-03-21 20:56:23 --> Output Class Initialized
INFO - 2022-03-21 20:56:23 --> Security Class Initialized
INFO - 2022-03-21 20:56:23 --> Input Class Initialized
INFO - 2022-03-21 20:56:23 --> Language Class Initialized
INFO - 2022-03-21 20:56:23 --> Loader Class Initialized
INFO - 2022-03-21 20:56:23 --> Helper loaded: url_helper
INFO - 2022-03-21 20:56:23 --> Helper loaded: form_helper
INFO - 2022-03-21 20:56:23 --> Database Driver Class Initialized
INFO - 2022-03-21 20:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 20:56:23 --> Form Validation Class Initialized
INFO - 2022-03-21 20:56:23 --> Controller Class Initialized
INFO - 2022-03-21 20:56:23 --> Model "M_tutor" initialized
INFO - 2022-03-21 20:56:23 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 20:56:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 20:56:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 20:56:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 20:56:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 20:56:23 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 20:56:23 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 20:56:23 --> Final output sent to browser
INFO - 2022-03-21 21:05:07 --> Config Class Initialized
INFO - 2022-03-21 21:05:07 --> Hooks Class Initialized
INFO - 2022-03-21 21:05:07 --> Utf8 Class Initialized
INFO - 2022-03-21 21:05:07 --> URI Class Initialized
INFO - 2022-03-21 21:05:07 --> Router Class Initialized
INFO - 2022-03-21 21:05:07 --> Output Class Initialized
INFO - 2022-03-21 21:05:07 --> Security Class Initialized
INFO - 2022-03-21 21:05:07 --> Input Class Initialized
INFO - 2022-03-21 21:05:07 --> Language Class Initialized
INFO - 2022-03-21 21:05:07 --> Loader Class Initialized
INFO - 2022-03-21 21:05:07 --> Helper loaded: url_helper
INFO - 2022-03-21 21:05:07 --> Helper loaded: form_helper
INFO - 2022-03-21 21:05:07 --> Database Driver Class Initialized
INFO - 2022-03-21 21:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:05:07 --> Form Validation Class Initialized
INFO - 2022-03-21 21:05:07 --> Controller Class Initialized
INFO - 2022-03-21 21:05:07 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:05:07 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:05:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:05:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:05:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:05:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:05:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:05:07 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:05:07 --> Final output sent to browser
INFO - 2022-03-21 21:05:30 --> Config Class Initialized
INFO - 2022-03-21 21:05:30 --> Hooks Class Initialized
INFO - 2022-03-21 21:05:30 --> Utf8 Class Initialized
INFO - 2022-03-21 21:05:30 --> URI Class Initialized
INFO - 2022-03-21 21:05:30 --> Router Class Initialized
INFO - 2022-03-21 21:05:30 --> Output Class Initialized
INFO - 2022-03-21 21:05:30 --> Security Class Initialized
INFO - 2022-03-21 21:05:30 --> Input Class Initialized
INFO - 2022-03-21 21:05:30 --> Language Class Initialized
INFO - 2022-03-21 21:05:30 --> Loader Class Initialized
INFO - 2022-03-21 21:05:30 --> Helper loaded: url_helper
INFO - 2022-03-21 21:05:30 --> Helper loaded: form_helper
INFO - 2022-03-21 21:05:30 --> Database Driver Class Initialized
INFO - 2022-03-21 21:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:05:30 --> Form Validation Class Initialized
INFO - 2022-03-21 21:05:30 --> Controller Class Initialized
INFO - 2022-03-21 21:05:30 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:05:30 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:05:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:05:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:05:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:05:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:05:30 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:05:30 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:05:30 --> Final output sent to browser
INFO - 2022-03-21 21:06:06 --> Config Class Initialized
INFO - 2022-03-21 21:06:06 --> Hooks Class Initialized
INFO - 2022-03-21 21:06:06 --> Utf8 Class Initialized
INFO - 2022-03-21 21:06:06 --> URI Class Initialized
INFO - 2022-03-21 21:06:06 --> Router Class Initialized
INFO - 2022-03-21 21:06:06 --> Output Class Initialized
INFO - 2022-03-21 21:06:06 --> Security Class Initialized
INFO - 2022-03-21 21:06:06 --> Input Class Initialized
INFO - 2022-03-21 21:06:06 --> Language Class Initialized
INFO - 2022-03-21 21:06:06 --> Loader Class Initialized
INFO - 2022-03-21 21:06:06 --> Helper loaded: url_helper
INFO - 2022-03-21 21:06:06 --> Helper loaded: form_helper
INFO - 2022-03-21 21:06:06 --> Database Driver Class Initialized
INFO - 2022-03-21 21:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:06:06 --> Form Validation Class Initialized
INFO - 2022-03-21 21:06:06 --> Controller Class Initialized
INFO - 2022-03-21 21:06:06 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:06:06 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:06:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:06:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:06:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:06:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:06:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:06:06 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:06:06 --> Final output sent to browser
INFO - 2022-03-21 21:25:28 --> Config Class Initialized
INFO - 2022-03-21 21:25:28 --> Hooks Class Initialized
INFO - 2022-03-21 21:25:28 --> Utf8 Class Initialized
INFO - 2022-03-21 21:25:28 --> URI Class Initialized
INFO - 2022-03-21 21:25:28 --> Router Class Initialized
INFO - 2022-03-21 21:25:28 --> Output Class Initialized
INFO - 2022-03-21 21:25:28 --> Security Class Initialized
INFO - 2022-03-21 21:25:28 --> Input Class Initialized
INFO - 2022-03-21 21:25:28 --> Language Class Initialized
INFO - 2022-03-21 21:25:28 --> Loader Class Initialized
INFO - 2022-03-21 21:25:28 --> Helper loaded: url_helper
INFO - 2022-03-21 21:25:28 --> Helper loaded: form_helper
INFO - 2022-03-21 21:25:28 --> Database Driver Class Initialized
INFO - 2022-03-21 21:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:25:28 --> Form Validation Class Initialized
INFO - 2022-03-21 21:25:28 --> Controller Class Initialized
INFO - 2022-03-21 21:25:28 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:25:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:25:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:25:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:25:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:25:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:25:28 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:25:28 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:25:28 --> Final output sent to browser
INFO - 2022-03-21 21:25:51 --> Config Class Initialized
INFO - 2022-03-21 21:25:51 --> Hooks Class Initialized
INFO - 2022-03-21 21:25:51 --> Utf8 Class Initialized
INFO - 2022-03-21 21:25:51 --> URI Class Initialized
INFO - 2022-03-21 21:25:51 --> Router Class Initialized
INFO - 2022-03-21 21:25:51 --> Output Class Initialized
INFO - 2022-03-21 21:25:51 --> Security Class Initialized
INFO - 2022-03-21 21:25:51 --> Input Class Initialized
INFO - 2022-03-21 21:25:51 --> Language Class Initialized
INFO - 2022-03-21 21:25:51 --> Loader Class Initialized
INFO - 2022-03-21 21:25:51 --> Helper loaded: url_helper
INFO - 2022-03-21 21:25:51 --> Helper loaded: form_helper
INFO - 2022-03-21 21:25:51 --> Database Driver Class Initialized
INFO - 2022-03-21 21:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:25:51 --> Form Validation Class Initialized
INFO - 2022-03-21 21:25:51 --> Controller Class Initialized
INFO - 2022-03-21 21:25:51 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:25:51 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:25:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:25:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:25:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:25:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:25:51 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:25:51 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:25:51 --> Final output sent to browser
INFO - 2022-03-21 21:25:56 --> Config Class Initialized
INFO - 2022-03-21 21:25:56 --> Hooks Class Initialized
INFO - 2022-03-21 21:25:56 --> Utf8 Class Initialized
INFO - 2022-03-21 21:25:56 --> URI Class Initialized
INFO - 2022-03-21 21:25:56 --> Router Class Initialized
INFO - 2022-03-21 21:25:56 --> Output Class Initialized
INFO - 2022-03-21 21:25:56 --> Security Class Initialized
INFO - 2022-03-21 21:25:56 --> Input Class Initialized
INFO - 2022-03-21 21:25:56 --> Language Class Initialized
INFO - 2022-03-21 21:25:56 --> Loader Class Initialized
INFO - 2022-03-21 21:25:56 --> Helper loaded: url_helper
INFO - 2022-03-21 21:25:56 --> Helper loaded: form_helper
INFO - 2022-03-21 21:25:56 --> Database Driver Class Initialized
INFO - 2022-03-21 21:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:25:56 --> Form Validation Class Initialized
INFO - 2022-03-21 21:25:56 --> Controller Class Initialized
INFO - 2022-03-21 21:25:56 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:25:56 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:25:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:25:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:25:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:25:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:25:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:25:56 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:25:56 --> Final output sent to browser
INFO - 2022-03-21 21:26:47 --> Config Class Initialized
INFO - 2022-03-21 21:26:47 --> Hooks Class Initialized
INFO - 2022-03-21 21:26:47 --> Utf8 Class Initialized
INFO - 2022-03-21 21:26:47 --> URI Class Initialized
INFO - 2022-03-21 21:26:47 --> Router Class Initialized
INFO - 2022-03-21 21:26:47 --> Output Class Initialized
INFO - 2022-03-21 21:26:47 --> Security Class Initialized
INFO - 2022-03-21 21:26:47 --> Input Class Initialized
INFO - 2022-03-21 21:26:47 --> Language Class Initialized
INFO - 2022-03-21 21:26:47 --> Loader Class Initialized
INFO - 2022-03-21 21:26:47 --> Helper loaded: url_helper
INFO - 2022-03-21 21:26:47 --> Helper loaded: form_helper
INFO - 2022-03-21 21:26:47 --> Database Driver Class Initialized
INFO - 2022-03-21 21:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:26:47 --> Form Validation Class Initialized
INFO - 2022-03-21 21:26:47 --> Controller Class Initialized
INFO - 2022-03-21 21:26:47 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:26:47 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:26:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:26:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:26:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:26:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:26:47 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:26:47 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:26:47 --> Final output sent to browser
INFO - 2022-03-21 21:26:59 --> Config Class Initialized
INFO - 2022-03-21 21:26:59 --> Hooks Class Initialized
INFO - 2022-03-21 21:26:59 --> Utf8 Class Initialized
INFO - 2022-03-21 21:26:59 --> URI Class Initialized
INFO - 2022-03-21 21:26:59 --> Router Class Initialized
INFO - 2022-03-21 21:26:59 --> Output Class Initialized
INFO - 2022-03-21 21:26:59 --> Security Class Initialized
INFO - 2022-03-21 21:26:59 --> Input Class Initialized
INFO - 2022-03-21 21:26:59 --> Language Class Initialized
INFO - 2022-03-21 21:26:59 --> Loader Class Initialized
INFO - 2022-03-21 21:26:59 --> Helper loaded: url_helper
INFO - 2022-03-21 21:26:59 --> Helper loaded: form_helper
INFO - 2022-03-21 21:26:59 --> Database Driver Class Initialized
INFO - 2022-03-21 21:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:26:59 --> Form Validation Class Initialized
INFO - 2022-03-21 21:26:59 --> Controller Class Initialized
INFO - 2022-03-21 21:26:59 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:26:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:26:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:26:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:26:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:26:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:26:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:26:59 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:26:59 --> Final output sent to browser
INFO - 2022-03-21 21:27:21 --> Config Class Initialized
INFO - 2022-03-21 21:27:21 --> Hooks Class Initialized
INFO - 2022-03-21 21:27:21 --> Utf8 Class Initialized
INFO - 2022-03-21 21:27:21 --> URI Class Initialized
INFO - 2022-03-21 21:27:21 --> Router Class Initialized
INFO - 2022-03-21 21:27:21 --> Output Class Initialized
INFO - 2022-03-21 21:27:21 --> Security Class Initialized
INFO - 2022-03-21 21:27:21 --> Input Class Initialized
INFO - 2022-03-21 21:27:21 --> Language Class Initialized
INFO - 2022-03-21 21:27:21 --> Loader Class Initialized
INFO - 2022-03-21 21:27:21 --> Helper loaded: url_helper
INFO - 2022-03-21 21:27:21 --> Helper loaded: form_helper
INFO - 2022-03-21 21:27:21 --> Database Driver Class Initialized
INFO - 2022-03-21 21:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:27:21 --> Form Validation Class Initialized
INFO - 2022-03-21 21:27:21 --> Controller Class Initialized
INFO - 2022-03-21 21:27:21 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:27:21 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:27:21 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:27:21 --> Final output sent to browser
INFO - 2022-03-21 21:27:59 --> Config Class Initialized
INFO - 2022-03-21 21:27:59 --> Hooks Class Initialized
INFO - 2022-03-21 21:27:59 --> Utf8 Class Initialized
INFO - 2022-03-21 21:27:59 --> URI Class Initialized
INFO - 2022-03-21 21:27:59 --> Router Class Initialized
INFO - 2022-03-21 21:27:59 --> Output Class Initialized
INFO - 2022-03-21 21:27:59 --> Security Class Initialized
INFO - 2022-03-21 21:27:59 --> Input Class Initialized
INFO - 2022-03-21 21:27:59 --> Language Class Initialized
INFO - 2022-03-21 21:27:59 --> Loader Class Initialized
INFO - 2022-03-21 21:27:59 --> Helper loaded: url_helper
INFO - 2022-03-21 21:27:59 --> Helper loaded: form_helper
INFO - 2022-03-21 21:27:59 --> Database Driver Class Initialized
INFO - 2022-03-21 21:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:27:59 --> Form Validation Class Initialized
INFO - 2022-03-21 21:27:59 --> Controller Class Initialized
INFO - 2022-03-21 21:27:59 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:27:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:27:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:27:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:27:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:27:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:27:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:27:59 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:27:59 --> Final output sent to browser
INFO - 2022-03-21 21:28:16 --> Config Class Initialized
INFO - 2022-03-21 21:28:16 --> Hooks Class Initialized
INFO - 2022-03-21 21:28:16 --> Utf8 Class Initialized
INFO - 2022-03-21 21:28:16 --> URI Class Initialized
INFO - 2022-03-21 21:28:16 --> Router Class Initialized
INFO - 2022-03-21 21:28:16 --> Output Class Initialized
INFO - 2022-03-21 21:28:16 --> Security Class Initialized
INFO - 2022-03-21 21:28:16 --> Input Class Initialized
INFO - 2022-03-21 21:28:16 --> Language Class Initialized
INFO - 2022-03-21 21:28:16 --> Loader Class Initialized
INFO - 2022-03-21 21:28:16 --> Helper loaded: url_helper
INFO - 2022-03-21 21:28:16 --> Helper loaded: form_helper
INFO - 2022-03-21 21:28:16 --> Database Driver Class Initialized
INFO - 2022-03-21 21:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:28:17 --> Form Validation Class Initialized
INFO - 2022-03-21 21:28:17 --> Controller Class Initialized
INFO - 2022-03-21 21:28:17 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:28:17 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:28:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:28:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:28:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:28:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:28:17 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:28:17 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:28:17 --> Final output sent to browser
INFO - 2022-03-21 21:28:39 --> Config Class Initialized
INFO - 2022-03-21 21:28:39 --> Hooks Class Initialized
INFO - 2022-03-21 21:28:39 --> Utf8 Class Initialized
INFO - 2022-03-21 21:28:39 --> URI Class Initialized
INFO - 2022-03-21 21:28:39 --> Router Class Initialized
INFO - 2022-03-21 21:28:39 --> Output Class Initialized
INFO - 2022-03-21 21:28:39 --> Security Class Initialized
INFO - 2022-03-21 21:28:39 --> Input Class Initialized
INFO - 2022-03-21 21:28:39 --> Language Class Initialized
INFO - 2022-03-21 21:28:39 --> Loader Class Initialized
INFO - 2022-03-21 21:28:39 --> Helper loaded: url_helper
INFO - 2022-03-21 21:28:39 --> Helper loaded: form_helper
INFO - 2022-03-21 21:28:39 --> Database Driver Class Initialized
INFO - 2022-03-21 21:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:28:39 --> Form Validation Class Initialized
INFO - 2022-03-21 21:28:39 --> Controller Class Initialized
INFO - 2022-03-21 21:28:39 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:28:39 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:28:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:28:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:28:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:28:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:28:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:28:39 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:28:39 --> Final output sent to browser
INFO - 2022-03-21 21:29:36 --> Config Class Initialized
INFO - 2022-03-21 21:29:36 --> Hooks Class Initialized
INFO - 2022-03-21 21:29:36 --> Utf8 Class Initialized
INFO - 2022-03-21 21:29:36 --> URI Class Initialized
INFO - 2022-03-21 21:29:36 --> Router Class Initialized
INFO - 2022-03-21 21:29:36 --> Output Class Initialized
INFO - 2022-03-21 21:29:36 --> Security Class Initialized
INFO - 2022-03-21 21:29:36 --> Input Class Initialized
INFO - 2022-03-21 21:29:36 --> Language Class Initialized
INFO - 2022-03-21 21:29:36 --> Loader Class Initialized
INFO - 2022-03-21 21:29:36 --> Helper loaded: url_helper
INFO - 2022-03-21 21:29:36 --> Helper loaded: form_helper
INFO - 2022-03-21 21:29:36 --> Database Driver Class Initialized
INFO - 2022-03-21 21:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:29:36 --> Form Validation Class Initialized
INFO - 2022-03-21 21:29:36 --> Controller Class Initialized
INFO - 2022-03-21 21:29:36 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:29:36 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:29:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:29:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:29:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:29:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:29:36 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:29:36 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:29:36 --> Final output sent to browser
INFO - 2022-03-21 21:29:43 --> Config Class Initialized
INFO - 2022-03-21 21:29:43 --> Hooks Class Initialized
INFO - 2022-03-21 21:29:43 --> Utf8 Class Initialized
INFO - 2022-03-21 21:29:43 --> URI Class Initialized
INFO - 2022-03-21 21:29:43 --> Router Class Initialized
INFO - 2022-03-21 21:29:43 --> Output Class Initialized
INFO - 2022-03-21 21:29:43 --> Security Class Initialized
INFO - 2022-03-21 21:29:43 --> Input Class Initialized
INFO - 2022-03-21 21:29:43 --> Language Class Initialized
INFO - 2022-03-21 21:29:43 --> Loader Class Initialized
INFO - 2022-03-21 21:29:43 --> Helper loaded: url_helper
INFO - 2022-03-21 21:29:43 --> Helper loaded: form_helper
INFO - 2022-03-21 21:29:43 --> Database Driver Class Initialized
INFO - 2022-03-21 21:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:29:43 --> Form Validation Class Initialized
INFO - 2022-03-21 21:29:43 --> Controller Class Initialized
INFO - 2022-03-21 21:29:43 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:29:43 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:29:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:29:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:29:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:29:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:29:43 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:29:43 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:29:43 --> Final output sent to browser
INFO - 2022-03-21 21:29:52 --> Config Class Initialized
INFO - 2022-03-21 21:29:52 --> Hooks Class Initialized
INFO - 2022-03-21 21:29:52 --> Utf8 Class Initialized
INFO - 2022-03-21 21:29:52 --> URI Class Initialized
INFO - 2022-03-21 21:29:52 --> Router Class Initialized
INFO - 2022-03-21 21:29:52 --> Output Class Initialized
INFO - 2022-03-21 21:29:52 --> Security Class Initialized
INFO - 2022-03-21 21:29:52 --> Input Class Initialized
INFO - 2022-03-21 21:29:52 --> Language Class Initialized
INFO - 2022-03-21 21:29:52 --> Loader Class Initialized
INFO - 2022-03-21 21:29:52 --> Helper loaded: url_helper
INFO - 2022-03-21 21:29:52 --> Helper loaded: form_helper
INFO - 2022-03-21 21:29:52 --> Database Driver Class Initialized
INFO - 2022-03-21 21:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:29:52 --> Form Validation Class Initialized
INFO - 2022-03-21 21:29:52 --> Controller Class Initialized
INFO - 2022-03-21 21:29:52 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:29:52 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:29:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:29:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:29:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:29:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:29:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:29:52 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:29:52 --> Final output sent to browser
INFO - 2022-03-21 21:30:00 --> Config Class Initialized
INFO - 2022-03-21 21:30:00 --> Hooks Class Initialized
INFO - 2022-03-21 21:30:00 --> Utf8 Class Initialized
INFO - 2022-03-21 21:30:00 --> URI Class Initialized
INFO - 2022-03-21 21:30:00 --> Router Class Initialized
INFO - 2022-03-21 21:30:00 --> Output Class Initialized
INFO - 2022-03-21 21:30:00 --> Security Class Initialized
INFO - 2022-03-21 21:30:00 --> Input Class Initialized
INFO - 2022-03-21 21:30:00 --> Language Class Initialized
INFO - 2022-03-21 21:30:00 --> Loader Class Initialized
INFO - 2022-03-21 21:30:00 --> Helper loaded: url_helper
INFO - 2022-03-21 21:30:00 --> Helper loaded: form_helper
INFO - 2022-03-21 21:30:00 --> Database Driver Class Initialized
INFO - 2022-03-21 21:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:30:00 --> Form Validation Class Initialized
INFO - 2022-03-21 21:30:00 --> Controller Class Initialized
INFO - 2022-03-21 21:30:00 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:30:00 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:30:00 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:30:00 --> Final output sent to browser
INFO - 2022-03-21 21:30:45 --> Config Class Initialized
INFO - 2022-03-21 21:30:45 --> Hooks Class Initialized
INFO - 2022-03-21 21:30:45 --> Utf8 Class Initialized
INFO - 2022-03-21 21:30:45 --> URI Class Initialized
INFO - 2022-03-21 21:30:45 --> Router Class Initialized
INFO - 2022-03-21 21:30:45 --> Output Class Initialized
INFO - 2022-03-21 21:30:45 --> Security Class Initialized
INFO - 2022-03-21 21:30:45 --> Input Class Initialized
INFO - 2022-03-21 21:30:45 --> Language Class Initialized
INFO - 2022-03-21 21:30:45 --> Loader Class Initialized
INFO - 2022-03-21 21:30:45 --> Helper loaded: url_helper
INFO - 2022-03-21 21:30:45 --> Helper loaded: form_helper
INFO - 2022-03-21 21:30:45 --> Database Driver Class Initialized
INFO - 2022-03-21 21:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:30:45 --> Form Validation Class Initialized
INFO - 2022-03-21 21:30:45 --> Controller Class Initialized
INFO - 2022-03-21 21:30:45 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:30:45 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:30:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:30:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:30:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:30:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:30:45 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:30:45 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:30:45 --> Final output sent to browser
INFO - 2022-03-21 21:35:04 --> Config Class Initialized
INFO - 2022-03-21 21:35:04 --> Hooks Class Initialized
INFO - 2022-03-21 21:35:04 --> Utf8 Class Initialized
INFO - 2022-03-21 21:35:04 --> URI Class Initialized
INFO - 2022-03-21 21:35:04 --> Router Class Initialized
INFO - 2022-03-21 21:35:04 --> Output Class Initialized
INFO - 2022-03-21 21:35:04 --> Security Class Initialized
INFO - 2022-03-21 21:35:04 --> Input Class Initialized
INFO - 2022-03-21 21:35:04 --> Language Class Initialized
INFO - 2022-03-21 21:35:04 --> Loader Class Initialized
INFO - 2022-03-21 21:35:04 --> Helper loaded: url_helper
INFO - 2022-03-21 21:35:04 --> Helper loaded: form_helper
INFO - 2022-03-21 21:35:04 --> Database Driver Class Initialized
INFO - 2022-03-21 21:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:35:04 --> Form Validation Class Initialized
INFO - 2022-03-21 21:35:04 --> Controller Class Initialized
INFO - 2022-03-21 21:35:04 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:35:04 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:35:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:35:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:35:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:35:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:35:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:35:04 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:35:04 --> Final output sent to browser
INFO - 2022-03-21 21:35:10 --> Config Class Initialized
INFO - 2022-03-21 21:35:10 --> Hooks Class Initialized
INFO - 2022-03-21 21:35:10 --> Utf8 Class Initialized
INFO - 2022-03-21 21:35:10 --> URI Class Initialized
INFO - 2022-03-21 21:35:10 --> Router Class Initialized
INFO - 2022-03-21 21:35:10 --> Output Class Initialized
INFO - 2022-03-21 21:35:10 --> Security Class Initialized
INFO - 2022-03-21 21:35:10 --> Input Class Initialized
INFO - 2022-03-21 21:35:10 --> Language Class Initialized
INFO - 2022-03-21 21:35:10 --> Loader Class Initialized
INFO - 2022-03-21 21:35:10 --> Helper loaded: url_helper
INFO - 2022-03-21 21:35:10 --> Helper loaded: form_helper
INFO - 2022-03-21 21:35:10 --> Database Driver Class Initialized
INFO - 2022-03-21 21:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 21:35:10 --> Form Validation Class Initialized
INFO - 2022-03-21 21:35:10 --> Controller Class Initialized
INFO - 2022-03-21 21:35:10 --> Model "M_tutor" initialized
INFO - 2022-03-21 21:35:10 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-21 21:35:10 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-21 21:35:10 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-21 21:35:10 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-21 21:35:10 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-21 21:35:10 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-21 21:35:10 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-21 21:35:10 --> Final output sent to browser
