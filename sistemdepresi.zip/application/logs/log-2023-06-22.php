<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-22 07:23:43 --> Config Class Initialized
INFO - 2023-06-22 07:23:43 --> Hooks Class Initialized
INFO - 2023-06-22 07:23:43 --> Utf8 Class Initialized
INFO - 2023-06-22 07:23:43 --> URI Class Initialized
INFO - 2023-06-22 07:23:43 --> Router Class Initialized
INFO - 2023-06-22 07:23:43 --> Output Class Initialized
INFO - 2023-06-22 07:23:43 --> Security Class Initialized
INFO - 2023-06-22 07:23:43 --> Input Class Initialized
INFO - 2023-06-22 07:23:43 --> Language Class Initialized
INFO - 2023-06-22 07:23:43 --> Loader Class Initialized
INFO - 2023-06-22 07:23:43 --> Helper loaded: url_helper
INFO - 2023-06-22 07:23:43 --> Helper loaded: form_helper
INFO - 2023-06-22 07:23:43 --> Database Driver Class Initialized
INFO - 2023-06-22 07:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:23:44 --> Form Validation Class Initialized
INFO - 2023-06-22 07:23:44 --> Controller Class Initialized
INFO - 2023-06-22 07:23:44 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\welcome_message.php
INFO - 2023-06-22 07:23:44 --> Final output sent to browser
INFO - 2023-06-22 07:23:46 --> Config Class Initialized
INFO - 2023-06-22 07:23:46 --> Hooks Class Initialized
INFO - 2023-06-22 07:23:46 --> Utf8 Class Initialized
INFO - 2023-06-22 07:23:46 --> URI Class Initialized
INFO - 2023-06-22 07:23:46 --> Router Class Initialized
INFO - 2023-06-22 07:23:46 --> Output Class Initialized
INFO - 2023-06-22 07:23:46 --> Security Class Initialized
INFO - 2023-06-22 07:23:46 --> Input Class Initialized
INFO - 2023-06-22 07:23:46 --> Language Class Initialized
INFO - 2023-06-22 07:23:46 --> Loader Class Initialized
INFO - 2023-06-22 07:23:46 --> Helper loaded: url_helper
INFO - 2023-06-22 07:23:46 --> Helper loaded: form_helper
INFO - 2023-06-22 07:23:46 --> Database Driver Class Initialized
INFO - 2023-06-22 07:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:23:46 --> Form Validation Class Initialized
INFO - 2023-06-22 07:23:46 --> Controller Class Initialized
INFO - 2023-06-22 07:23:46 --> Model "m_user" initialized
INFO - 2023-06-22 07:23:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:23:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:23:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:23:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:23:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:23:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:23:46 --> Final output sent to browser
INFO - 2023-06-22 07:24:09 --> Config Class Initialized
INFO - 2023-06-22 07:24:09 --> Hooks Class Initialized
INFO - 2023-06-22 07:24:09 --> Utf8 Class Initialized
INFO - 2023-06-22 07:24:09 --> URI Class Initialized
INFO - 2023-06-22 07:24:09 --> Router Class Initialized
INFO - 2023-06-22 07:24:09 --> Output Class Initialized
INFO - 2023-06-22 07:24:09 --> Security Class Initialized
INFO - 2023-06-22 07:24:09 --> Input Class Initialized
INFO - 2023-06-22 07:24:09 --> Language Class Initialized
INFO - 2023-06-22 07:24:09 --> Loader Class Initialized
INFO - 2023-06-22 07:24:09 --> Helper loaded: url_helper
INFO - 2023-06-22 07:24:09 --> Helper loaded: form_helper
INFO - 2023-06-22 07:24:09 --> Database Driver Class Initialized
INFO - 2023-06-22 07:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:24:09 --> Form Validation Class Initialized
INFO - 2023-06-22 07:24:09 --> Controller Class Initialized
INFO - 2023-06-22 07:24:09 --> Model "m_user" initialized
INFO - 2023-06-22 07:24:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:24:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:24:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:24:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:24:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:24:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:24:09 --> Final output sent to browser
INFO - 2023-06-22 07:26:50 --> Config Class Initialized
INFO - 2023-06-22 07:26:50 --> Hooks Class Initialized
INFO - 2023-06-22 07:26:50 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:50 --> URI Class Initialized
INFO - 2023-06-22 07:26:51 --> Router Class Initialized
INFO - 2023-06-22 07:26:51 --> Output Class Initialized
INFO - 2023-06-22 07:26:51 --> Security Class Initialized
INFO - 2023-06-22 07:26:51 --> Input Class Initialized
INFO - 2023-06-22 07:26:51 --> Language Class Initialized
INFO - 2023-06-22 07:26:51 --> Loader Class Initialized
INFO - 2023-06-22 07:26:51 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:51 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:51 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:51 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:51 --> Controller Class Initialized
INFO - 2023-06-22 07:26:51 --> Model "m_user" initialized
INFO - 2023-06-22 07:26:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:26:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:26:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:26:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:26:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:26:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:26:51 --> Final output sent to browser
INFO - 2023-06-22 07:27:39 --> Config Class Initialized
INFO - 2023-06-22 07:27:39 --> Hooks Class Initialized
INFO - 2023-06-22 07:27:39 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:39 --> URI Class Initialized
INFO - 2023-06-22 07:27:39 --> Router Class Initialized
INFO - 2023-06-22 07:27:39 --> Output Class Initialized
INFO - 2023-06-22 07:27:39 --> Security Class Initialized
INFO - 2023-06-22 07:27:39 --> Input Class Initialized
INFO - 2023-06-22 07:27:39 --> Language Class Initialized
INFO - 2023-06-22 07:27:39 --> Loader Class Initialized
INFO - 2023-06-22 07:27:39 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:39 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:39 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:39 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:39 --> Controller Class Initialized
INFO - 2023-06-22 07:27:39 --> Model "m_user" initialized
INFO - 2023-06-22 07:27:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:27:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:27:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:27:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:27:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:27:39 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:27:39 --> Final output sent to browser
INFO - 2023-06-22 07:27:59 --> Config Class Initialized
INFO - 2023-06-22 07:27:59 --> Hooks Class Initialized
INFO - 2023-06-22 07:27:59 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:59 --> URI Class Initialized
INFO - 2023-06-22 07:27:59 --> Router Class Initialized
INFO - 2023-06-22 07:27:59 --> Output Class Initialized
INFO - 2023-06-22 07:27:59 --> Security Class Initialized
INFO - 2023-06-22 07:27:59 --> Input Class Initialized
INFO - 2023-06-22 07:27:59 --> Language Class Initialized
INFO - 2023-06-22 07:27:59 --> Loader Class Initialized
INFO - 2023-06-22 07:27:59 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:59 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:59 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:59 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:59 --> Controller Class Initialized
INFO - 2023-06-22 07:27:59 --> Model "m_user" initialized
INFO - 2023-06-22 07:27:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:27:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:27:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:27:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:27:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:27:59 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:27:59 --> Final output sent to browser
INFO - 2023-06-22 07:28:25 --> Config Class Initialized
INFO - 2023-06-22 07:28:25 --> Hooks Class Initialized
INFO - 2023-06-22 07:28:25 --> Utf8 Class Initialized
INFO - 2023-06-22 07:28:25 --> URI Class Initialized
INFO - 2023-06-22 07:28:25 --> Router Class Initialized
INFO - 2023-06-22 07:28:25 --> Output Class Initialized
INFO - 2023-06-22 07:28:25 --> Security Class Initialized
INFO - 2023-06-22 07:28:25 --> Input Class Initialized
INFO - 2023-06-22 07:28:25 --> Language Class Initialized
INFO - 2023-06-22 07:28:25 --> Loader Class Initialized
INFO - 2023-06-22 07:28:25 --> Helper loaded: url_helper
INFO - 2023-06-22 07:28:25 --> Helper loaded: form_helper
INFO - 2023-06-22 07:28:25 --> Database Driver Class Initialized
INFO - 2023-06-22 07:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:28:25 --> Form Validation Class Initialized
INFO - 2023-06-22 07:28:25 --> Controller Class Initialized
INFO - 2023-06-22 07:28:25 --> Model "m_user" initialized
INFO - 2023-06-22 07:28:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:28:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:28:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:28:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:28:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:28:25 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:28:25 --> Final output sent to browser
INFO - 2023-06-22 07:29:03 --> Config Class Initialized
INFO - 2023-06-22 07:29:03 --> Hooks Class Initialized
INFO - 2023-06-22 07:29:03 --> Utf8 Class Initialized
INFO - 2023-06-22 07:29:03 --> URI Class Initialized
INFO - 2023-06-22 07:29:03 --> Router Class Initialized
INFO - 2023-06-22 07:29:03 --> Output Class Initialized
INFO - 2023-06-22 07:29:03 --> Security Class Initialized
INFO - 2023-06-22 07:29:03 --> Input Class Initialized
INFO - 2023-06-22 07:29:03 --> Language Class Initialized
INFO - 2023-06-22 07:29:03 --> Loader Class Initialized
INFO - 2023-06-22 07:29:03 --> Helper loaded: url_helper
INFO - 2023-06-22 07:29:03 --> Helper loaded: form_helper
INFO - 2023-06-22 07:29:03 --> Database Driver Class Initialized
INFO - 2023-06-22 07:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:29:03 --> Form Validation Class Initialized
INFO - 2023-06-22 07:29:03 --> Controller Class Initialized
INFO - 2023-06-22 07:29:03 --> Model "m_user" initialized
INFO - 2023-06-22 07:29:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:29:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:29:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:29:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:29:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:29:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:29:03 --> Final output sent to browser
INFO - 2023-06-22 07:29:22 --> Config Class Initialized
INFO - 2023-06-22 07:29:22 --> Hooks Class Initialized
INFO - 2023-06-22 07:29:22 --> Utf8 Class Initialized
INFO - 2023-06-22 07:29:22 --> URI Class Initialized
INFO - 2023-06-22 07:29:22 --> Router Class Initialized
INFO - 2023-06-22 07:29:22 --> Output Class Initialized
INFO - 2023-06-22 07:29:22 --> Security Class Initialized
INFO - 2023-06-22 07:29:22 --> Input Class Initialized
INFO - 2023-06-22 07:29:22 --> Language Class Initialized
INFO - 2023-06-22 07:29:22 --> Loader Class Initialized
INFO - 2023-06-22 07:29:22 --> Helper loaded: url_helper
INFO - 2023-06-22 07:29:22 --> Helper loaded: form_helper
INFO - 2023-06-22 07:29:22 --> Database Driver Class Initialized
INFO - 2023-06-22 07:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:29:22 --> Form Validation Class Initialized
INFO - 2023-06-22 07:29:22 --> Controller Class Initialized
INFO - 2023-06-22 07:29:22 --> Model "m_user" initialized
INFO - 2023-06-22 07:29:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:29:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:29:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:29:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:29:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:29:22 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:29:22 --> Final output sent to browser
INFO - 2023-06-22 07:31:04 --> Config Class Initialized
INFO - 2023-06-22 07:31:04 --> Hooks Class Initialized
INFO - 2023-06-22 07:31:04 --> Utf8 Class Initialized
INFO - 2023-06-22 07:31:04 --> URI Class Initialized
INFO - 2023-06-22 07:31:04 --> Router Class Initialized
INFO - 2023-06-22 07:31:04 --> Output Class Initialized
INFO - 2023-06-22 07:31:04 --> Security Class Initialized
INFO - 2023-06-22 07:31:04 --> Input Class Initialized
INFO - 2023-06-22 07:31:04 --> Language Class Initialized
INFO - 2023-06-22 07:31:04 --> Loader Class Initialized
INFO - 2023-06-22 07:31:04 --> Helper loaded: url_helper
INFO - 2023-06-22 07:31:04 --> Helper loaded: form_helper
INFO - 2023-06-22 07:31:04 --> Database Driver Class Initialized
INFO - 2023-06-22 07:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:31:05 --> Form Validation Class Initialized
INFO - 2023-06-22 07:31:05 --> Controller Class Initialized
INFO - 2023-06-22 07:31:05 --> Model "m_user" initialized
INFO - 2023-06-22 07:31:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:31:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:31:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:31:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:31:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:31:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:31:05 --> Final output sent to browser
INFO - 2023-06-22 07:31:13 --> Config Class Initialized
INFO - 2023-06-22 07:31:13 --> Hooks Class Initialized
INFO - 2023-06-22 07:31:13 --> Utf8 Class Initialized
INFO - 2023-06-22 07:31:13 --> URI Class Initialized
INFO - 2023-06-22 07:31:13 --> Router Class Initialized
INFO - 2023-06-22 07:31:13 --> Output Class Initialized
INFO - 2023-06-22 07:31:13 --> Security Class Initialized
INFO - 2023-06-22 07:31:13 --> Input Class Initialized
INFO - 2023-06-22 07:31:13 --> Language Class Initialized
INFO - 2023-06-22 07:31:13 --> Loader Class Initialized
INFO - 2023-06-22 07:31:13 --> Helper loaded: url_helper
INFO - 2023-06-22 07:31:13 --> Helper loaded: form_helper
INFO - 2023-06-22 07:31:13 --> Database Driver Class Initialized
INFO - 2023-06-22 07:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:31:13 --> Form Validation Class Initialized
INFO - 2023-06-22 07:31:13 --> Controller Class Initialized
INFO - 2023-06-22 07:31:13 --> Model "m_user" initialized
INFO - 2023-06-22 07:31:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:31:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:31:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:31:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:31:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:31:13 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:31:13 --> Final output sent to browser
INFO - 2023-06-22 07:31:24 --> Config Class Initialized
INFO - 2023-06-22 07:31:24 --> Hooks Class Initialized
INFO - 2023-06-22 07:31:24 --> Utf8 Class Initialized
INFO - 2023-06-22 07:31:24 --> URI Class Initialized
INFO - 2023-06-22 07:31:24 --> Router Class Initialized
INFO - 2023-06-22 07:31:24 --> Output Class Initialized
INFO - 2023-06-22 07:31:24 --> Security Class Initialized
INFO - 2023-06-22 07:31:24 --> Input Class Initialized
INFO - 2023-06-22 07:31:24 --> Language Class Initialized
INFO - 2023-06-22 07:31:24 --> Loader Class Initialized
INFO - 2023-06-22 07:31:24 --> Helper loaded: url_helper
INFO - 2023-06-22 07:31:24 --> Helper loaded: form_helper
INFO - 2023-06-22 07:31:24 --> Database Driver Class Initialized
INFO - 2023-06-22 07:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:31:24 --> Form Validation Class Initialized
INFO - 2023-06-22 07:31:24 --> Controller Class Initialized
INFO - 2023-06-22 07:31:24 --> Model "m_user" initialized
INFO - 2023-06-22 07:31:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:31:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:31:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:31:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:31:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:31:24 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:31:24 --> Final output sent to browser
INFO - 2023-06-22 07:31:43 --> Config Class Initialized
INFO - 2023-06-22 07:31:43 --> Hooks Class Initialized
INFO - 2023-06-22 07:31:43 --> Utf8 Class Initialized
INFO - 2023-06-22 07:31:43 --> URI Class Initialized
INFO - 2023-06-22 07:31:43 --> Router Class Initialized
INFO - 2023-06-22 07:31:43 --> Output Class Initialized
INFO - 2023-06-22 07:31:43 --> Security Class Initialized
INFO - 2023-06-22 07:31:43 --> Input Class Initialized
INFO - 2023-06-22 07:31:43 --> Language Class Initialized
INFO - 2023-06-22 07:31:43 --> Loader Class Initialized
INFO - 2023-06-22 07:31:43 --> Helper loaded: url_helper
INFO - 2023-06-22 07:31:43 --> Helper loaded: form_helper
INFO - 2023-06-22 07:31:43 --> Database Driver Class Initialized
INFO - 2023-06-22 07:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:31:43 --> Form Validation Class Initialized
INFO - 2023-06-22 07:31:43 --> Controller Class Initialized
INFO - 2023-06-22 07:31:43 --> Model "m_user" initialized
INFO - 2023-06-22 07:31:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:31:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:31:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:31:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:31:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:31:43 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:31:43 --> Final output sent to browser
INFO - 2023-06-22 07:33:27 --> Config Class Initialized
INFO - 2023-06-22 07:33:27 --> Hooks Class Initialized
INFO - 2023-06-22 07:33:27 --> Utf8 Class Initialized
INFO - 2023-06-22 07:33:27 --> URI Class Initialized
INFO - 2023-06-22 07:33:27 --> Router Class Initialized
INFO - 2023-06-22 07:33:27 --> Output Class Initialized
INFO - 2023-06-22 07:33:27 --> Security Class Initialized
INFO - 2023-06-22 07:33:27 --> Input Class Initialized
INFO - 2023-06-22 07:33:27 --> Language Class Initialized
INFO - 2023-06-22 07:33:27 --> Loader Class Initialized
INFO - 2023-06-22 07:33:27 --> Helper loaded: url_helper
INFO - 2023-06-22 07:33:27 --> Helper loaded: form_helper
INFO - 2023-06-22 07:33:27 --> Database Driver Class Initialized
INFO - 2023-06-22 07:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:33:27 --> Form Validation Class Initialized
INFO - 2023-06-22 07:33:27 --> Controller Class Initialized
INFO - 2023-06-22 07:33:27 --> Model "m_user" initialized
INFO - 2023-06-22 07:33:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:33:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:33:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:33:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:33:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:33:27 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:33:27 --> Final output sent to browser
INFO - 2023-06-22 07:33:45 --> Config Class Initialized
INFO - 2023-06-22 07:33:45 --> Hooks Class Initialized
INFO - 2023-06-22 07:33:45 --> Utf8 Class Initialized
INFO - 2023-06-22 07:33:45 --> URI Class Initialized
INFO - 2023-06-22 07:33:45 --> Router Class Initialized
INFO - 2023-06-22 07:33:45 --> Output Class Initialized
INFO - 2023-06-22 07:33:45 --> Security Class Initialized
INFO - 2023-06-22 07:33:45 --> Input Class Initialized
INFO - 2023-06-22 07:33:45 --> Language Class Initialized
INFO - 2023-06-22 07:33:45 --> Loader Class Initialized
INFO - 2023-06-22 07:33:45 --> Helper loaded: url_helper
INFO - 2023-06-22 07:33:45 --> Helper loaded: form_helper
INFO - 2023-06-22 07:33:45 --> Database Driver Class Initialized
INFO - 2023-06-22 07:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:33:45 --> Form Validation Class Initialized
INFO - 2023-06-22 07:33:45 --> Controller Class Initialized
INFO - 2023-06-22 07:33:45 --> Model "m_user" initialized
INFO - 2023-06-22 07:33:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:33:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:33:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:33:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:33:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:33:45 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:33:45 --> Final output sent to browser
INFO - 2023-06-22 07:34:08 --> Config Class Initialized
INFO - 2023-06-22 07:34:08 --> Hooks Class Initialized
INFO - 2023-06-22 07:34:08 --> Utf8 Class Initialized
INFO - 2023-06-22 07:34:08 --> URI Class Initialized
INFO - 2023-06-22 07:34:08 --> Router Class Initialized
INFO - 2023-06-22 07:34:08 --> Output Class Initialized
INFO - 2023-06-22 07:34:08 --> Security Class Initialized
INFO - 2023-06-22 07:34:08 --> Input Class Initialized
INFO - 2023-06-22 07:34:08 --> Language Class Initialized
INFO - 2023-06-22 07:34:08 --> Loader Class Initialized
INFO - 2023-06-22 07:34:08 --> Helper loaded: url_helper
INFO - 2023-06-22 07:34:08 --> Helper loaded: form_helper
INFO - 2023-06-22 07:34:08 --> Database Driver Class Initialized
INFO - 2023-06-22 07:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:34:08 --> Form Validation Class Initialized
INFO - 2023-06-22 07:34:08 --> Controller Class Initialized
INFO - 2023-06-22 07:34:08 --> Model "m_user" initialized
INFO - 2023-06-22 07:34:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:34:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:34:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:34:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:34:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:34:08 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:34:08 --> Final output sent to browser
INFO - 2023-06-22 07:34:50 --> Config Class Initialized
INFO - 2023-06-22 07:34:50 --> Hooks Class Initialized
INFO - 2023-06-22 07:34:50 --> Utf8 Class Initialized
INFO - 2023-06-22 07:34:50 --> URI Class Initialized
INFO - 2023-06-22 07:34:50 --> Router Class Initialized
INFO - 2023-06-22 07:34:50 --> Output Class Initialized
INFO - 2023-06-22 07:34:50 --> Security Class Initialized
INFO - 2023-06-22 07:34:50 --> Input Class Initialized
INFO - 2023-06-22 07:34:50 --> Language Class Initialized
INFO - 2023-06-22 07:34:50 --> Loader Class Initialized
INFO - 2023-06-22 07:34:50 --> Helper loaded: url_helper
INFO - 2023-06-22 07:34:50 --> Helper loaded: form_helper
INFO - 2023-06-22 07:34:50 --> Database Driver Class Initialized
INFO - 2023-06-22 07:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:34:50 --> Form Validation Class Initialized
INFO - 2023-06-22 07:34:50 --> Controller Class Initialized
INFO - 2023-06-22 07:34:50 --> Model "m_user" initialized
INFO - 2023-06-22 07:34:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:34:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:34:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:34:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:34:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:34:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:34:50 --> Final output sent to browser
INFO - 2023-06-22 07:38:36 --> Config Class Initialized
INFO - 2023-06-22 07:38:36 --> Hooks Class Initialized
INFO - 2023-06-22 07:38:36 --> Utf8 Class Initialized
INFO - 2023-06-22 07:38:36 --> URI Class Initialized
INFO - 2023-06-22 07:38:36 --> Router Class Initialized
INFO - 2023-06-22 07:38:36 --> Output Class Initialized
INFO - 2023-06-22 07:38:36 --> Security Class Initialized
INFO - 2023-06-22 07:38:36 --> Input Class Initialized
INFO - 2023-06-22 07:38:36 --> Language Class Initialized
INFO - 2023-06-22 07:38:36 --> Loader Class Initialized
INFO - 2023-06-22 07:38:36 --> Helper loaded: url_helper
INFO - 2023-06-22 07:38:36 --> Helper loaded: form_helper
INFO - 2023-06-22 07:38:36 --> Database Driver Class Initialized
INFO - 2023-06-22 07:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:38:36 --> Form Validation Class Initialized
INFO - 2023-06-22 07:38:36 --> Controller Class Initialized
INFO - 2023-06-22 07:38:36 --> Model "m_user" initialized
INFO - 2023-06-22 07:38:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:38:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:38:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:38:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:38:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:38:36 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:38:36 --> Final output sent to browser
INFO - 2023-06-22 07:39:18 --> Config Class Initialized
INFO - 2023-06-22 07:39:18 --> Hooks Class Initialized
INFO - 2023-06-22 07:39:18 --> Utf8 Class Initialized
INFO - 2023-06-22 07:39:18 --> URI Class Initialized
INFO - 2023-06-22 07:39:18 --> Router Class Initialized
INFO - 2023-06-22 07:39:18 --> Output Class Initialized
INFO - 2023-06-22 07:39:18 --> Security Class Initialized
INFO - 2023-06-22 07:39:18 --> Input Class Initialized
INFO - 2023-06-22 07:39:18 --> Language Class Initialized
INFO - 2023-06-22 07:39:18 --> Loader Class Initialized
INFO - 2023-06-22 07:39:18 --> Helper loaded: url_helper
INFO - 2023-06-22 07:39:18 --> Helper loaded: form_helper
INFO - 2023-06-22 07:39:18 --> Database Driver Class Initialized
INFO - 2023-06-22 07:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:39:18 --> Form Validation Class Initialized
INFO - 2023-06-22 07:39:18 --> Controller Class Initialized
INFO - 2023-06-22 07:39:18 --> Model "m_user" initialized
INFO - 2023-06-22 07:39:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:39:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:39:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:39:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:39:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:39:18 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:39:18 --> Final output sent to browser
INFO - 2023-06-22 07:39:31 --> Config Class Initialized
INFO - 2023-06-22 07:39:31 --> Hooks Class Initialized
INFO - 2023-06-22 07:39:31 --> Utf8 Class Initialized
INFO - 2023-06-22 07:39:31 --> URI Class Initialized
INFO - 2023-06-22 07:39:31 --> Router Class Initialized
INFO - 2023-06-22 07:39:31 --> Output Class Initialized
INFO - 2023-06-22 07:39:31 --> Security Class Initialized
INFO - 2023-06-22 07:39:31 --> Input Class Initialized
INFO - 2023-06-22 07:39:31 --> Language Class Initialized
INFO - 2023-06-22 07:39:31 --> Loader Class Initialized
INFO - 2023-06-22 07:39:31 --> Helper loaded: url_helper
INFO - 2023-06-22 07:39:31 --> Helper loaded: form_helper
INFO - 2023-06-22 07:39:31 --> Database Driver Class Initialized
INFO - 2023-06-22 07:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:39:31 --> Form Validation Class Initialized
INFO - 2023-06-22 07:39:31 --> Controller Class Initialized
INFO - 2023-06-22 07:39:31 --> Model "m_user" initialized
INFO - 2023-06-22 07:39:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:39:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:39:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:39:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:39:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:39:31 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:39:31 --> Final output sent to browser
INFO - 2023-06-22 07:40:50 --> Config Class Initialized
INFO - 2023-06-22 07:40:50 --> Hooks Class Initialized
INFO - 2023-06-22 07:40:50 --> Utf8 Class Initialized
INFO - 2023-06-22 07:40:50 --> URI Class Initialized
INFO - 2023-06-22 07:40:50 --> Router Class Initialized
INFO - 2023-06-22 07:40:50 --> Output Class Initialized
INFO - 2023-06-22 07:40:50 --> Security Class Initialized
INFO - 2023-06-22 07:40:50 --> Input Class Initialized
INFO - 2023-06-22 07:40:50 --> Language Class Initialized
INFO - 2023-06-22 07:40:50 --> Loader Class Initialized
INFO - 2023-06-22 07:40:50 --> Helper loaded: url_helper
INFO - 2023-06-22 07:40:50 --> Helper loaded: form_helper
INFO - 2023-06-22 07:40:50 --> Database Driver Class Initialized
INFO - 2023-06-22 07:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:40:50 --> Form Validation Class Initialized
INFO - 2023-06-22 07:40:50 --> Controller Class Initialized
INFO - 2023-06-22 07:40:50 --> Model "m_user" initialized
INFO - 2023-06-22 07:40:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:40:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:40:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:40:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:40:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:40:50 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:40:50 --> Final output sent to browser
INFO - 2023-06-22 07:41:09 --> Config Class Initialized
INFO - 2023-06-22 07:41:09 --> Hooks Class Initialized
INFO - 2023-06-22 07:41:09 --> Utf8 Class Initialized
INFO - 2023-06-22 07:41:09 --> URI Class Initialized
INFO - 2023-06-22 07:41:09 --> Router Class Initialized
INFO - 2023-06-22 07:41:09 --> Output Class Initialized
INFO - 2023-06-22 07:41:09 --> Security Class Initialized
INFO - 2023-06-22 07:41:09 --> Input Class Initialized
INFO - 2023-06-22 07:41:09 --> Language Class Initialized
INFO - 2023-06-22 07:41:09 --> Loader Class Initialized
INFO - 2023-06-22 07:41:09 --> Helper loaded: url_helper
INFO - 2023-06-22 07:41:09 --> Helper loaded: form_helper
INFO - 2023-06-22 07:41:09 --> Database Driver Class Initialized
INFO - 2023-06-22 07:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:41:09 --> Form Validation Class Initialized
INFO - 2023-06-22 07:41:09 --> Controller Class Initialized
INFO - 2023-06-22 07:41:09 --> Model "m_user" initialized
INFO - 2023-06-22 07:41:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:41:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:41:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:41:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:41:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:41:09 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:41:09 --> Final output sent to browser
INFO - 2023-06-22 07:41:35 --> Config Class Initialized
INFO - 2023-06-22 07:41:35 --> Hooks Class Initialized
INFO - 2023-06-22 07:41:35 --> Utf8 Class Initialized
INFO - 2023-06-22 07:41:35 --> URI Class Initialized
INFO - 2023-06-22 07:41:35 --> Router Class Initialized
INFO - 2023-06-22 07:41:35 --> Output Class Initialized
INFO - 2023-06-22 07:41:35 --> Security Class Initialized
INFO - 2023-06-22 07:41:35 --> Input Class Initialized
INFO - 2023-06-22 07:41:35 --> Language Class Initialized
INFO - 2023-06-22 07:41:35 --> Loader Class Initialized
INFO - 2023-06-22 07:41:35 --> Helper loaded: url_helper
INFO - 2023-06-22 07:41:35 --> Helper loaded: form_helper
INFO - 2023-06-22 07:41:35 --> Database Driver Class Initialized
INFO - 2023-06-22 07:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:41:35 --> Form Validation Class Initialized
INFO - 2023-06-22 07:41:35 --> Controller Class Initialized
INFO - 2023-06-22 07:41:35 --> Model "m_user" initialized
INFO - 2023-06-22 07:41:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:41:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:41:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:41:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:41:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:41:35 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:41:35 --> Final output sent to browser
INFO - 2023-06-22 07:41:44 --> Config Class Initialized
INFO - 2023-06-22 07:41:44 --> Hooks Class Initialized
INFO - 2023-06-22 07:41:44 --> Utf8 Class Initialized
INFO - 2023-06-22 07:41:44 --> URI Class Initialized
INFO - 2023-06-22 07:41:44 --> Router Class Initialized
INFO - 2023-06-22 07:41:44 --> Output Class Initialized
INFO - 2023-06-22 07:41:44 --> Security Class Initialized
INFO - 2023-06-22 07:41:44 --> Input Class Initialized
INFO - 2023-06-22 07:41:44 --> Language Class Initialized
INFO - 2023-06-22 07:41:44 --> Loader Class Initialized
INFO - 2023-06-22 07:41:44 --> Helper loaded: url_helper
INFO - 2023-06-22 07:41:44 --> Helper loaded: form_helper
INFO - 2023-06-22 07:41:44 --> Database Driver Class Initialized
INFO - 2023-06-22 07:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:41:44 --> Form Validation Class Initialized
INFO - 2023-06-22 07:41:44 --> Controller Class Initialized
INFO - 2023-06-22 07:41:44 --> Model "m_user" initialized
INFO - 2023-06-22 07:41:44 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:41:44 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:41:44 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:41:44 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:41:44 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:41:44 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:41:44 --> Final output sent to browser
INFO - 2023-06-22 07:42:03 --> Config Class Initialized
INFO - 2023-06-22 07:42:03 --> Hooks Class Initialized
INFO - 2023-06-22 07:42:03 --> Utf8 Class Initialized
INFO - 2023-06-22 07:42:03 --> URI Class Initialized
INFO - 2023-06-22 07:42:03 --> Router Class Initialized
INFO - 2023-06-22 07:42:03 --> Output Class Initialized
INFO - 2023-06-22 07:42:03 --> Security Class Initialized
INFO - 2023-06-22 07:42:03 --> Input Class Initialized
INFO - 2023-06-22 07:42:03 --> Language Class Initialized
INFO - 2023-06-22 07:42:03 --> Loader Class Initialized
INFO - 2023-06-22 07:42:03 --> Helper loaded: url_helper
INFO - 2023-06-22 07:42:03 --> Helper loaded: form_helper
INFO - 2023-06-22 07:42:03 --> Database Driver Class Initialized
INFO - 2023-06-22 07:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:42:03 --> Form Validation Class Initialized
INFO - 2023-06-22 07:42:03 --> Controller Class Initialized
INFO - 2023-06-22 07:42:03 --> Model "m_user" initialized
INFO - 2023-06-22 07:42:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:42:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:42:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:42:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:42:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:42:03 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:42:03 --> Final output sent to browser
INFO - 2023-06-22 07:44:23 --> Config Class Initialized
INFO - 2023-06-22 07:44:23 --> Hooks Class Initialized
INFO - 2023-06-22 07:44:23 --> Utf8 Class Initialized
INFO - 2023-06-22 07:44:23 --> URI Class Initialized
INFO - 2023-06-22 07:44:23 --> Router Class Initialized
INFO - 2023-06-22 07:44:23 --> Output Class Initialized
INFO - 2023-06-22 07:44:23 --> Security Class Initialized
INFO - 2023-06-22 07:44:23 --> Input Class Initialized
INFO - 2023-06-22 07:44:23 --> Language Class Initialized
INFO - 2023-06-22 07:44:23 --> Loader Class Initialized
INFO - 2023-06-22 07:44:23 --> Helper loaded: url_helper
INFO - 2023-06-22 07:44:23 --> Helper loaded: form_helper
INFO - 2023-06-22 07:44:23 --> Database Driver Class Initialized
INFO - 2023-06-22 07:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:44:23 --> Form Validation Class Initialized
INFO - 2023-06-22 07:44:23 --> Controller Class Initialized
INFO - 2023-06-22 07:44:23 --> Model "m_user" initialized
INFO - 2023-06-22 07:44:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:44:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:44:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:44:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:44:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:44:23 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:44:23 --> Final output sent to browser
INFO - 2023-06-22 07:44:51 --> Config Class Initialized
INFO - 2023-06-22 07:44:51 --> Hooks Class Initialized
INFO - 2023-06-22 07:44:51 --> Utf8 Class Initialized
INFO - 2023-06-22 07:44:51 --> URI Class Initialized
INFO - 2023-06-22 07:44:51 --> Router Class Initialized
INFO - 2023-06-22 07:44:51 --> Output Class Initialized
INFO - 2023-06-22 07:44:51 --> Security Class Initialized
INFO - 2023-06-22 07:44:51 --> Input Class Initialized
INFO - 2023-06-22 07:44:51 --> Language Class Initialized
INFO - 2023-06-22 07:44:51 --> Loader Class Initialized
INFO - 2023-06-22 07:44:51 --> Helper loaded: url_helper
INFO - 2023-06-22 07:44:51 --> Helper loaded: form_helper
INFO - 2023-06-22 07:44:51 --> Database Driver Class Initialized
INFO - 2023-06-22 07:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:44:51 --> Form Validation Class Initialized
INFO - 2023-06-22 07:44:51 --> Controller Class Initialized
INFO - 2023-06-22 07:44:51 --> Model "m_user" initialized
INFO - 2023-06-22 07:44:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:44:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:44:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:44:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:44:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:44:51 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:44:51 --> Final output sent to browser
INFO - 2023-06-22 07:45:46 --> Config Class Initialized
INFO - 2023-06-22 07:45:46 --> Hooks Class Initialized
INFO - 2023-06-22 07:45:46 --> Utf8 Class Initialized
INFO - 2023-06-22 07:45:46 --> URI Class Initialized
INFO - 2023-06-22 07:45:46 --> Router Class Initialized
INFO - 2023-06-22 07:45:46 --> Output Class Initialized
INFO - 2023-06-22 07:45:46 --> Security Class Initialized
INFO - 2023-06-22 07:45:46 --> Input Class Initialized
INFO - 2023-06-22 07:45:46 --> Language Class Initialized
INFO - 2023-06-22 07:45:46 --> Loader Class Initialized
INFO - 2023-06-22 07:45:46 --> Helper loaded: url_helper
INFO - 2023-06-22 07:45:46 --> Helper loaded: form_helper
INFO - 2023-06-22 07:45:46 --> Database Driver Class Initialized
INFO - 2023-06-22 07:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:45:46 --> Form Validation Class Initialized
INFO - 2023-06-22 07:45:46 --> Controller Class Initialized
INFO - 2023-06-22 07:45:46 --> Model "m_user" initialized
INFO - 2023-06-22 07:45:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:45:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:45:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:45:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:45:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:45:46 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:45:46 --> Final output sent to browser
INFO - 2023-06-22 07:46:05 --> Config Class Initialized
INFO - 2023-06-22 07:46:05 --> Hooks Class Initialized
INFO - 2023-06-22 07:46:05 --> Utf8 Class Initialized
INFO - 2023-06-22 07:46:05 --> URI Class Initialized
INFO - 2023-06-22 07:46:05 --> Router Class Initialized
INFO - 2023-06-22 07:46:05 --> Output Class Initialized
INFO - 2023-06-22 07:46:05 --> Security Class Initialized
INFO - 2023-06-22 07:46:05 --> Input Class Initialized
INFO - 2023-06-22 07:46:05 --> Language Class Initialized
INFO - 2023-06-22 07:46:05 --> Loader Class Initialized
INFO - 2023-06-22 07:46:05 --> Helper loaded: url_helper
INFO - 2023-06-22 07:46:05 --> Helper loaded: form_helper
INFO - 2023-06-22 07:46:05 --> Database Driver Class Initialized
INFO - 2023-06-22 07:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:46:05 --> Form Validation Class Initialized
INFO - 2023-06-22 07:46:05 --> Controller Class Initialized
INFO - 2023-06-22 07:46:05 --> Model "m_user" initialized
INFO - 2023-06-22 07:46:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 07:46:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 07:46:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 07:46:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 07:46:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 07:46:05 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 07:46:05 --> Final output sent to browser
INFO - 2023-06-22 08:07:42 --> Config Class Initialized
INFO - 2023-06-22 08:07:42 --> Hooks Class Initialized
INFO - 2023-06-22 08:07:42 --> Utf8 Class Initialized
INFO - 2023-06-22 08:07:42 --> URI Class Initialized
INFO - 2023-06-22 08:07:42 --> Router Class Initialized
INFO - 2023-06-22 08:07:42 --> Output Class Initialized
INFO - 2023-06-22 08:07:42 --> Security Class Initialized
INFO - 2023-06-22 08:07:42 --> Input Class Initialized
INFO - 2023-06-22 08:07:42 --> Language Class Initialized
INFO - 2023-06-22 08:07:42 --> Loader Class Initialized
INFO - 2023-06-22 08:07:42 --> Helper loaded: url_helper
INFO - 2023-06-22 08:07:42 --> Helper loaded: form_helper
INFO - 2023-06-22 08:07:42 --> Database Driver Class Initialized
INFO - 2023-06-22 08:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 08:07:42 --> Form Validation Class Initialized
INFO - 2023-06-22 08:07:42 --> Controller Class Initialized
INFO - 2023-06-22 08:07:42 --> Model "m_user" initialized
INFO - 2023-06-22 08:07:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 08:07:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 08:07:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 08:07:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 08:07:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 08:07:42 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\home/v_home_user.php
INFO - 2023-06-22 08:07:42 --> Final output sent to browser
INFO - 2023-06-22 08:10:21 --> Config Class Initialized
INFO - 2023-06-22 08:10:21 --> Hooks Class Initialized
INFO - 2023-06-22 08:10:21 --> Utf8 Class Initialized
INFO - 2023-06-22 08:10:21 --> URI Class Initialized
INFO - 2023-06-22 08:10:21 --> Router Class Initialized
INFO - 2023-06-22 08:10:21 --> Output Class Initialized
INFO - 2023-06-22 08:10:21 --> Security Class Initialized
INFO - 2023-06-22 08:10:21 --> Input Class Initialized
INFO - 2023-06-22 08:10:21 --> Language Class Initialized
INFO - 2023-06-22 08:10:21 --> Loader Class Initialized
INFO - 2023-06-22 08:10:21 --> Helper loaded: url_helper
INFO - 2023-06-22 08:10:21 --> Helper loaded: form_helper
INFO - 2023-06-22 08:10:21 --> Database Driver Class Initialized
INFO - 2023-06-22 08:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 08:10:21 --> Form Validation Class Initialized
INFO - 2023-06-22 08:10:21 --> Controller Class Initialized
INFO - 2023-06-22 08:10:21 --> Model "m_datatrain" initialized
INFO - 2023-06-22 08:10:21 --> Model "m_penghitungan" initialized
INFO - 2023-06-22 08:10:21 --> Model "m_datatest" initialized
INFO - 2023-06-22 08:10:21 --> Model "M_solusi" initialized
INFO - 2023-06-22 08:10:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/head.php
INFO - 2023-06-22 08:10:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/navbar.php
INFO - 2023-06-22 08:10:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-22 08:10:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/sidebar_user.php
INFO - 2023-06-22 08:10:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/footer.php
INFO - 2023-06-22 08:10:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\_partials/script.php
INFO - 2023-06-22 08:10:21 --> File loaded: C:\xampp\htdocs\sistemdepresi\application\views\template_user.php
INFO - 2023-06-22 08:10:21 --> Final output sent to browser
