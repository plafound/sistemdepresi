<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-26 06:01:48 --> Config Class Initialized
INFO - 2022-03-26 06:01:48 --> Hooks Class Initialized
INFO - 2022-03-26 06:01:48 --> Utf8 Class Initialized
INFO - 2022-03-26 06:01:49 --> URI Class Initialized
INFO - 2022-03-26 06:01:49 --> Router Class Initialized
INFO - 2022-03-26 06:01:49 --> Output Class Initialized
INFO - 2022-03-26 06:01:49 --> Security Class Initialized
INFO - 2022-03-26 06:01:49 --> Input Class Initialized
INFO - 2022-03-26 06:01:49 --> Language Class Initialized
INFO - 2022-03-26 06:01:49 --> Loader Class Initialized
INFO - 2022-03-26 06:01:49 --> Helper loaded: url_helper
INFO - 2022-03-26 06:01:49 --> Helper loaded: form_helper
INFO - 2022-03-26 06:01:49 --> Database Driver Class Initialized
INFO - 2022-03-26 06:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:01:49 --> Form Validation Class Initialized
INFO - 2022-03-26 06:01:49 --> Controller Class Initialized
INFO - 2022-03-26 06:01:50 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:01:50 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_header.php
INFO - 2022-03-26 06:01:50 --> File loaded: C:\laragon\www\list-todo\application\views\auth/login.php
INFO - 2022-03-26 06:01:50 --> File loaded: C:\laragon\www\list-todo\application\views\templates/auth_footer.php
INFO - 2022-03-26 06:01:50 --> Final output sent to browser
INFO - 2022-03-26 06:01:55 --> Config Class Initialized
INFO - 2022-03-26 06:01:55 --> Hooks Class Initialized
INFO - 2022-03-26 06:01:55 --> Utf8 Class Initialized
INFO - 2022-03-26 06:01:55 --> URI Class Initialized
INFO - 2022-03-26 06:01:55 --> Router Class Initialized
INFO - 2022-03-26 06:01:55 --> Output Class Initialized
INFO - 2022-03-26 06:01:55 --> Security Class Initialized
INFO - 2022-03-26 06:01:55 --> Input Class Initialized
INFO - 2022-03-26 06:01:55 --> Language Class Initialized
INFO - 2022-03-26 06:01:55 --> Loader Class Initialized
INFO - 2022-03-26 06:01:55 --> Helper loaded: url_helper
INFO - 2022-03-26 06:01:55 --> Helper loaded: form_helper
INFO - 2022-03-26 06:01:55 --> Database Driver Class Initialized
INFO - 2022-03-26 06:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:01:55 --> Form Validation Class Initialized
INFO - 2022-03-26 06:01:55 --> Controller Class Initialized
INFO - 2022-03-26 06:01:55 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:01:55 --> Config Class Initialized
INFO - 2022-03-26 06:01:55 --> Hooks Class Initialized
INFO - 2022-03-26 06:01:55 --> Utf8 Class Initialized
INFO - 2022-03-26 06:01:55 --> URI Class Initialized
INFO - 2022-03-26 06:01:55 --> Router Class Initialized
INFO - 2022-03-26 06:01:55 --> Output Class Initialized
INFO - 2022-03-26 06:01:55 --> Security Class Initialized
INFO - 2022-03-26 06:01:55 --> Input Class Initialized
INFO - 2022-03-26 06:01:55 --> Language Class Initialized
INFO - 2022-03-26 06:01:55 --> Loader Class Initialized
INFO - 2022-03-26 06:01:55 --> Helper loaded: url_helper
INFO - 2022-03-26 06:01:55 --> Helper loaded: form_helper
INFO - 2022-03-26 06:01:55 --> Database Driver Class Initialized
INFO - 2022-03-26 06:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:01:55 --> Form Validation Class Initialized
INFO - 2022-03-26 06:01:55 --> Controller Class Initialized
INFO - 2022-03-26 06:01:55 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:01:56 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:01:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:01:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:01:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:01:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:01:56 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:01:56 --> File loaded: C:\laragon\www\list-todo\application\views\home.php
INFO - 2022-03-26 06:01:56 --> Final output sent to browser
INFO - 2022-03-26 06:02:02 --> Config Class Initialized
INFO - 2022-03-26 06:02:02 --> Hooks Class Initialized
INFO - 2022-03-26 06:02:02 --> Utf8 Class Initialized
INFO - 2022-03-26 06:02:02 --> URI Class Initialized
INFO - 2022-03-26 06:02:02 --> Router Class Initialized
INFO - 2022-03-26 06:02:02 --> Output Class Initialized
INFO - 2022-03-26 06:02:02 --> Security Class Initialized
INFO - 2022-03-26 06:02:02 --> Input Class Initialized
INFO - 2022-03-26 06:02:02 --> Language Class Initialized
INFO - 2022-03-26 06:02:02 --> Loader Class Initialized
INFO - 2022-03-26 06:02:02 --> Helper loaded: url_helper
INFO - 2022-03-26 06:02:02 --> Helper loaded: form_helper
INFO - 2022-03-26 06:02:02 --> Database Driver Class Initialized
INFO - 2022-03-26 06:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:02:02 --> Form Validation Class Initialized
INFO - 2022-03-26 06:02:02 --> Controller Class Initialized
INFO - 2022-03-26 06:02:02 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:02:02 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:02:02 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:02:02 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:02:02 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:02:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:02:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:02:02 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:02:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:02:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:02:02 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:02:02 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:02:02 --> Final output sent to browser
INFO - 2022-03-26 06:04:33 --> Config Class Initialized
INFO - 2022-03-26 06:04:33 --> Hooks Class Initialized
INFO - 2022-03-26 06:04:33 --> Utf8 Class Initialized
INFO - 2022-03-26 06:04:33 --> URI Class Initialized
INFO - 2022-03-26 06:04:33 --> Router Class Initialized
INFO - 2022-03-26 06:04:33 --> Output Class Initialized
INFO - 2022-03-26 06:04:33 --> Security Class Initialized
INFO - 2022-03-26 06:04:33 --> Input Class Initialized
INFO - 2022-03-26 06:04:33 --> Language Class Initialized
INFO - 2022-03-26 06:04:33 --> Loader Class Initialized
INFO - 2022-03-26 06:04:33 --> Helper loaded: url_helper
INFO - 2022-03-26 06:04:33 --> Helper loaded: form_helper
INFO - 2022-03-26 06:04:33 --> Database Driver Class Initialized
INFO - 2022-03-26 06:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:04:33 --> Form Validation Class Initialized
INFO - 2022-03-26 06:04:33 --> Controller Class Initialized
INFO - 2022-03-26 06:04:33 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:04:33 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:04:33 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:04:33 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:04:33 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:04:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:04:33 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-26 06:04:33 --> Severity: Error --> Call to undefined function today() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 71
INFO - 2022-03-26 06:06:59 --> Config Class Initialized
INFO - 2022-03-26 06:06:59 --> Hooks Class Initialized
INFO - 2022-03-26 06:06:59 --> Utf8 Class Initialized
INFO - 2022-03-26 06:06:59 --> URI Class Initialized
INFO - 2022-03-26 06:06:59 --> Router Class Initialized
INFO - 2022-03-26 06:06:59 --> Output Class Initialized
INFO - 2022-03-26 06:06:59 --> Security Class Initialized
INFO - 2022-03-26 06:06:59 --> Input Class Initialized
INFO - 2022-03-26 06:06:59 --> Language Class Initialized
INFO - 2022-03-26 06:06:59 --> Loader Class Initialized
INFO - 2022-03-26 06:06:59 --> Helper loaded: url_helper
INFO - 2022-03-26 06:06:59 --> Helper loaded: form_helper
INFO - 2022-03-26 06:06:59 --> Database Driver Class Initialized
INFO - 2022-03-26 06:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:06:59 --> Form Validation Class Initialized
INFO - 2022-03-26 06:06:59 --> Controller Class Initialized
INFO - 2022-03-26 06:06:59 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:06:59 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:06:59 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:06:59 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:06:59 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:06:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:06:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:06:59 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:06:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:06:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:06:59 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:06:59 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:06:59 --> Final output sent to browser
INFO - 2022-03-26 06:07:39 --> Config Class Initialized
INFO - 2022-03-26 06:07:39 --> Hooks Class Initialized
INFO - 2022-03-26 06:07:39 --> Utf8 Class Initialized
INFO - 2022-03-26 06:07:39 --> URI Class Initialized
INFO - 2022-03-26 06:07:39 --> Router Class Initialized
INFO - 2022-03-26 06:07:39 --> Output Class Initialized
INFO - 2022-03-26 06:07:39 --> Security Class Initialized
INFO - 2022-03-26 06:07:39 --> Input Class Initialized
INFO - 2022-03-26 06:07:39 --> Language Class Initialized
INFO - 2022-03-26 06:07:39 --> Loader Class Initialized
INFO - 2022-03-26 06:07:39 --> Helper loaded: url_helper
INFO - 2022-03-26 06:07:39 --> Helper loaded: form_helper
INFO - 2022-03-26 06:07:39 --> Database Driver Class Initialized
INFO - 2022-03-26 06:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:07:39 --> Form Validation Class Initialized
INFO - 2022-03-26 06:07:39 --> Controller Class Initialized
INFO - 2022-03-26 06:07:39 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:07:39 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:07:39 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:07:39 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:07:39 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:07:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:07:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:07:39 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:07:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:07:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:07:39 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:07:39 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:07:39 --> Final output sent to browser
INFO - 2022-03-26 06:08:06 --> Config Class Initialized
INFO - 2022-03-26 06:08:06 --> Hooks Class Initialized
INFO - 2022-03-26 06:08:06 --> Utf8 Class Initialized
INFO - 2022-03-26 06:08:06 --> URI Class Initialized
INFO - 2022-03-26 06:08:06 --> Router Class Initialized
INFO - 2022-03-26 06:08:06 --> Output Class Initialized
INFO - 2022-03-26 06:08:06 --> Security Class Initialized
INFO - 2022-03-26 06:08:06 --> Input Class Initialized
INFO - 2022-03-26 06:08:06 --> Language Class Initialized
INFO - 2022-03-26 06:08:06 --> Loader Class Initialized
INFO - 2022-03-26 06:08:06 --> Helper loaded: url_helper
INFO - 2022-03-26 06:08:06 --> Helper loaded: form_helper
INFO - 2022-03-26 06:08:06 --> Database Driver Class Initialized
INFO - 2022-03-26 06:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:08:06 --> Form Validation Class Initialized
INFO - 2022-03-26 06:08:06 --> Controller Class Initialized
INFO - 2022-03-26 06:08:06 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:08:06 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:08:06 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:08:06 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:08:06 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:08:06 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:08:06 --> Final output sent to browser
INFO - 2022-03-26 06:08:31 --> Config Class Initialized
INFO - 2022-03-26 06:08:31 --> Hooks Class Initialized
INFO - 2022-03-26 06:08:31 --> Utf8 Class Initialized
INFO - 2022-03-26 06:08:31 --> URI Class Initialized
INFO - 2022-03-26 06:08:31 --> Router Class Initialized
INFO - 2022-03-26 06:08:31 --> Output Class Initialized
INFO - 2022-03-26 06:08:31 --> Security Class Initialized
INFO - 2022-03-26 06:08:31 --> Input Class Initialized
INFO - 2022-03-26 06:08:31 --> Language Class Initialized
INFO - 2022-03-26 06:08:31 --> Loader Class Initialized
INFO - 2022-03-26 06:08:31 --> Helper loaded: url_helper
INFO - 2022-03-26 06:08:31 --> Helper loaded: form_helper
INFO - 2022-03-26 06:08:31 --> Database Driver Class Initialized
INFO - 2022-03-26 06:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:08:31 --> Form Validation Class Initialized
INFO - 2022-03-26 06:08:31 --> Controller Class Initialized
INFO - 2022-03-26 06:08:31 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:08:31 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:08:31 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:08:31 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:08:31 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:08:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:08:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:08:31 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:08:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:08:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:08:31 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:08:31 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:08:31 --> Final output sent to browser
INFO - 2022-03-26 06:10:05 --> Config Class Initialized
INFO - 2022-03-26 06:10:05 --> Hooks Class Initialized
INFO - 2022-03-26 06:10:05 --> Utf8 Class Initialized
INFO - 2022-03-26 06:10:05 --> URI Class Initialized
INFO - 2022-03-26 06:10:05 --> Router Class Initialized
INFO - 2022-03-26 06:10:05 --> Output Class Initialized
INFO - 2022-03-26 06:10:05 --> Security Class Initialized
INFO - 2022-03-26 06:10:05 --> Input Class Initialized
INFO - 2022-03-26 06:10:05 --> Language Class Initialized
ERROR - 2022-03-26 06:10:05 --> 404 Page Not Found: C_todo_list/4
INFO - 2022-03-26 06:10:09 --> Config Class Initialized
INFO - 2022-03-26 06:10:09 --> Hooks Class Initialized
INFO - 2022-03-26 06:10:09 --> Utf8 Class Initialized
INFO - 2022-03-26 06:10:09 --> URI Class Initialized
INFO - 2022-03-26 06:10:09 --> Router Class Initialized
INFO - 2022-03-26 06:10:09 --> Output Class Initialized
INFO - 2022-03-26 06:10:09 --> Security Class Initialized
INFO - 2022-03-26 06:10:09 --> Input Class Initialized
INFO - 2022-03-26 06:10:09 --> Language Class Initialized
INFO - 2022-03-26 06:10:09 --> Loader Class Initialized
INFO - 2022-03-26 06:10:09 --> Helper loaded: url_helper
INFO - 2022-03-26 06:10:09 --> Helper loaded: form_helper
INFO - 2022-03-26 06:10:09 --> Database Driver Class Initialized
INFO - 2022-03-26 06:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:10:09 --> Form Validation Class Initialized
INFO - 2022-03-26 06:10:09 --> Controller Class Initialized
INFO - 2022-03-26 06:10:09 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:10:09 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:10:09 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:10:09 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:10:09 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:10:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:10:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:10:09 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:10:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:10:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:10:09 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:10:09 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:10:09 --> Final output sent to browser
INFO - 2022-03-26 06:11:04 --> Config Class Initialized
INFO - 2022-03-26 06:11:04 --> Hooks Class Initialized
INFO - 2022-03-26 06:11:04 --> Utf8 Class Initialized
INFO - 2022-03-26 06:11:04 --> URI Class Initialized
INFO - 2022-03-26 06:11:04 --> Router Class Initialized
INFO - 2022-03-26 06:11:04 --> Output Class Initialized
INFO - 2022-03-26 06:11:04 --> Security Class Initialized
INFO - 2022-03-26 06:11:04 --> Input Class Initialized
INFO - 2022-03-26 06:11:04 --> Language Class Initialized
INFO - 2022-03-26 06:11:04 --> Loader Class Initialized
INFO - 2022-03-26 06:11:04 --> Helper loaded: url_helper
INFO - 2022-03-26 06:11:04 --> Helper loaded: form_helper
INFO - 2022-03-26 06:11:04 --> Database Driver Class Initialized
INFO - 2022-03-26 06:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:11:04 --> Form Validation Class Initialized
INFO - 2022-03-26 06:11:04 --> Controller Class Initialized
INFO - 2022-03-26 06:11:04 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:11:04 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:11:04 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:11:04 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:11:04 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:11:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:11:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:11:04 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:11:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:11:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:11:04 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:11:04 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:11:04 --> Final output sent to browser
INFO - 2022-03-26 06:11:11 --> Config Class Initialized
INFO - 2022-03-26 06:11:11 --> Hooks Class Initialized
INFO - 2022-03-26 06:11:11 --> Utf8 Class Initialized
INFO - 2022-03-26 06:11:11 --> URI Class Initialized
INFO - 2022-03-26 06:11:11 --> Router Class Initialized
INFO - 2022-03-26 06:11:11 --> Output Class Initialized
INFO - 2022-03-26 06:11:11 --> Security Class Initialized
INFO - 2022-03-26 06:11:11 --> Input Class Initialized
INFO - 2022-03-26 06:11:11 --> Language Class Initialized
INFO - 2022-03-26 06:11:11 --> Loader Class Initialized
INFO - 2022-03-26 06:11:11 --> Helper loaded: url_helper
INFO - 2022-03-26 06:11:11 --> Helper loaded: form_helper
INFO - 2022-03-26 06:11:11 --> Database Driver Class Initialized
INFO - 2022-03-26 06:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:11:11 --> Form Validation Class Initialized
INFO - 2022-03-26 06:11:11 --> Controller Class Initialized
INFO - 2022-03-26 06:11:11 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:11:11 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:11:11 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:11:11 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:11:11 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:11:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:11:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:11:11 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_todo_task.php
INFO - 2022-03-26 06:11:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:11:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:11:11 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:11:11 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:11:11 --> Final output sent to browser
INFO - 2022-03-26 06:15:27 --> Config Class Initialized
INFO - 2022-03-26 06:15:27 --> Hooks Class Initialized
INFO - 2022-03-26 06:15:27 --> Utf8 Class Initialized
INFO - 2022-03-26 06:15:27 --> URI Class Initialized
INFO - 2022-03-26 06:15:27 --> Router Class Initialized
INFO - 2022-03-26 06:15:27 --> Output Class Initialized
INFO - 2022-03-26 06:15:27 --> Security Class Initialized
INFO - 2022-03-26 06:15:27 --> Input Class Initialized
INFO - 2022-03-26 06:15:27 --> Language Class Initialized
INFO - 2022-03-26 06:15:27 --> Loader Class Initialized
INFO - 2022-03-26 06:15:27 --> Helper loaded: url_helper
INFO - 2022-03-26 06:15:27 --> Helper loaded: form_helper
INFO - 2022-03-26 06:15:27 --> Database Driver Class Initialized
INFO - 2022-03-26 06:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:15:27 --> Form Validation Class Initialized
INFO - 2022-03-26 06:15:27 --> Controller Class Initialized
INFO - 2022-03-26 06:15:27 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:15:27 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:15:27 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:15:27 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:15:27 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:15:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:15:27 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
ERROR - 2022-03-26 06:15:27 --> Severity: Error --> Call to undefined function shortdate_indo() C:\laragon\www\list-todo\application\views\todo_list\v_index.php 102
INFO - 2022-03-26 06:15:52 --> Config Class Initialized
INFO - 2022-03-26 06:15:52 --> Hooks Class Initialized
INFO - 2022-03-26 06:15:52 --> Utf8 Class Initialized
INFO - 2022-03-26 06:15:52 --> URI Class Initialized
INFO - 2022-03-26 06:15:52 --> Router Class Initialized
INFO - 2022-03-26 06:15:52 --> Output Class Initialized
INFO - 2022-03-26 06:15:52 --> Security Class Initialized
INFO - 2022-03-26 06:15:52 --> Input Class Initialized
INFO - 2022-03-26 06:15:52 --> Language Class Initialized
INFO - 2022-03-26 06:15:52 --> Loader Class Initialized
INFO - 2022-03-26 06:15:52 --> Helper loaded: url_helper
INFO - 2022-03-26 06:15:52 --> Helper loaded: form_helper
INFO - 2022-03-26 06:15:52 --> Database Driver Class Initialized
INFO - 2022-03-26 06:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:15:52 --> Form Validation Class Initialized
INFO - 2022-03-26 06:15:52 --> Controller Class Initialized
INFO - 2022-03-26 06:15:52 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:15:52 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:15:52 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:15:52 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:15:52 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:15:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:15:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:15:52 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:15:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:15:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:15:52 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:15:52 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:15:52 --> Final output sent to browser
INFO - 2022-03-26 06:16:28 --> Config Class Initialized
INFO - 2022-03-26 06:16:28 --> Hooks Class Initialized
INFO - 2022-03-26 06:16:28 --> Utf8 Class Initialized
INFO - 2022-03-26 06:16:28 --> URI Class Initialized
INFO - 2022-03-26 06:16:28 --> Router Class Initialized
INFO - 2022-03-26 06:16:28 --> Output Class Initialized
INFO - 2022-03-26 06:16:28 --> Security Class Initialized
INFO - 2022-03-26 06:16:28 --> Input Class Initialized
INFO - 2022-03-26 06:16:28 --> Language Class Initialized
INFO - 2022-03-26 06:16:28 --> Loader Class Initialized
INFO - 2022-03-26 06:16:28 --> Helper loaded: url_helper
INFO - 2022-03-26 06:16:28 --> Helper loaded: form_helper
INFO - 2022-03-26 06:16:28 --> Database Driver Class Initialized
INFO - 2022-03-26 06:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:16:28 --> Form Validation Class Initialized
INFO - 2022-03-26 06:16:28 --> Controller Class Initialized
INFO - 2022-03-26 06:16:28 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:16:28 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:16:28 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:16:28 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:16:28 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:16:28 --> Config Class Initialized
INFO - 2022-03-26 06:16:28 --> Hooks Class Initialized
INFO - 2022-03-26 06:16:28 --> Utf8 Class Initialized
INFO - 2022-03-26 06:16:28 --> URI Class Initialized
INFO - 2022-03-26 06:16:28 --> Router Class Initialized
INFO - 2022-03-26 06:16:28 --> Output Class Initialized
INFO - 2022-03-26 06:16:28 --> Security Class Initialized
INFO - 2022-03-26 06:16:28 --> Input Class Initialized
INFO - 2022-03-26 06:16:28 --> Language Class Initialized
INFO - 2022-03-26 06:16:28 --> Loader Class Initialized
INFO - 2022-03-26 06:16:28 --> Helper loaded: url_helper
INFO - 2022-03-26 06:16:29 --> Helper loaded: form_helper
INFO - 2022-03-26 06:16:29 --> Database Driver Class Initialized
INFO - 2022-03-26 06:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:16:29 --> Form Validation Class Initialized
INFO - 2022-03-26 06:16:29 --> Controller Class Initialized
INFO - 2022-03-26 06:16:29 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:16:29 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:16:29 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:16:29 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:16:29 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:16:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:16:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:16:29 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:16:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:16:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:16:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:16:29 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:16:29 --> Final output sent to browser
INFO - 2022-03-26 06:17:01 --> Config Class Initialized
INFO - 2022-03-26 06:17:01 --> Hooks Class Initialized
INFO - 2022-03-26 06:17:01 --> Utf8 Class Initialized
INFO - 2022-03-26 06:17:01 --> URI Class Initialized
INFO - 2022-03-26 06:17:01 --> Router Class Initialized
INFO - 2022-03-26 06:17:01 --> Output Class Initialized
INFO - 2022-03-26 06:17:01 --> Security Class Initialized
INFO - 2022-03-26 06:17:01 --> Input Class Initialized
INFO - 2022-03-26 06:17:01 --> Language Class Initialized
INFO - 2022-03-26 06:17:01 --> Loader Class Initialized
INFO - 2022-03-26 06:17:01 --> Helper loaded: url_helper
INFO - 2022-03-26 06:17:01 --> Helper loaded: form_helper
INFO - 2022-03-26 06:17:01 --> Database Driver Class Initialized
INFO - 2022-03-26 06:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:17:01 --> Form Validation Class Initialized
INFO - 2022-03-26 06:17:01 --> Controller Class Initialized
INFO - 2022-03-26 06:17:01 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:17:01 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:17:01 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:17:01 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:17:01 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:17:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:17:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:17:01 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:17:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:17:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:17:01 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:17:01 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:17:01 --> Final output sent to browser
INFO - 2022-03-26 06:20:29 --> Config Class Initialized
INFO - 2022-03-26 06:20:29 --> Hooks Class Initialized
INFO - 2022-03-26 06:20:29 --> Utf8 Class Initialized
INFO - 2022-03-26 06:20:29 --> URI Class Initialized
INFO - 2022-03-26 06:20:29 --> Router Class Initialized
INFO - 2022-03-26 06:20:29 --> Output Class Initialized
INFO - 2022-03-26 06:20:29 --> Security Class Initialized
INFO - 2022-03-26 06:20:29 --> Input Class Initialized
INFO - 2022-03-26 06:20:29 --> Language Class Initialized
INFO - 2022-03-26 06:20:29 --> Loader Class Initialized
INFO - 2022-03-26 06:20:29 --> Helper loaded: url_helper
INFO - 2022-03-26 06:20:29 --> Helper loaded: form_helper
INFO - 2022-03-26 06:20:29 --> Database Driver Class Initialized
INFO - 2022-03-26 06:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:20:29 --> Form Validation Class Initialized
INFO - 2022-03-26 06:20:29 --> Controller Class Initialized
INFO - 2022-03-26 06:20:29 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:20:29 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:20:29 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:20:29 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:20:29 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:20:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:20:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:20:29 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:20:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:20:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:20:29 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:20:29 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:20:29 --> Final output sent to browser
INFO - 2022-03-26 06:20:37 --> Config Class Initialized
INFO - 2022-03-26 06:20:37 --> Hooks Class Initialized
INFO - 2022-03-26 06:20:37 --> Utf8 Class Initialized
INFO - 2022-03-26 06:20:37 --> URI Class Initialized
INFO - 2022-03-26 06:20:37 --> Router Class Initialized
INFO - 2022-03-26 06:20:37 --> Output Class Initialized
INFO - 2022-03-26 06:20:37 --> Security Class Initialized
INFO - 2022-03-26 06:20:37 --> Input Class Initialized
INFO - 2022-03-26 06:20:37 --> Language Class Initialized
INFO - 2022-03-26 06:20:37 --> Loader Class Initialized
INFO - 2022-03-26 06:20:37 --> Helper loaded: url_helper
INFO - 2022-03-26 06:20:37 --> Helper loaded: form_helper
INFO - 2022-03-26 06:20:37 --> Database Driver Class Initialized
INFO - 2022-03-26 06:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:20:37 --> Form Validation Class Initialized
INFO - 2022-03-26 06:20:37 --> Controller Class Initialized
INFO - 2022-03-26 06:20:37 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:20:37 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:20:37 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:20:37 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:20:37 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:20:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:20:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:20:37 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:20:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:20:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:20:37 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:20:37 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:20:37 --> Final output sent to browser
INFO - 2022-03-26 06:20:49 --> Config Class Initialized
INFO - 2022-03-26 06:20:49 --> Hooks Class Initialized
INFO - 2022-03-26 06:20:49 --> Utf8 Class Initialized
INFO - 2022-03-26 06:20:49 --> URI Class Initialized
INFO - 2022-03-26 06:20:49 --> Router Class Initialized
INFO - 2022-03-26 06:20:49 --> Output Class Initialized
INFO - 2022-03-26 06:20:49 --> Security Class Initialized
INFO - 2022-03-26 06:20:49 --> Input Class Initialized
INFO - 2022-03-26 06:20:49 --> Language Class Initialized
INFO - 2022-03-26 06:20:49 --> Loader Class Initialized
INFO - 2022-03-26 06:20:49 --> Helper loaded: url_helper
INFO - 2022-03-26 06:20:49 --> Helper loaded: form_helper
INFO - 2022-03-26 06:20:49 --> Database Driver Class Initialized
INFO - 2022-03-26 06:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:20:49 --> Form Validation Class Initialized
INFO - 2022-03-26 06:20:49 --> Controller Class Initialized
INFO - 2022-03-26 06:20:49 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:20:49 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:20:49 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:20:49 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:20:49 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:20:49 --> Config Class Initialized
INFO - 2022-03-26 06:20:49 --> Hooks Class Initialized
INFO - 2022-03-26 06:20:49 --> Utf8 Class Initialized
INFO - 2022-03-26 06:20:49 --> URI Class Initialized
INFO - 2022-03-26 06:20:49 --> Router Class Initialized
INFO - 2022-03-26 06:20:49 --> Output Class Initialized
INFO - 2022-03-26 06:20:49 --> Security Class Initialized
INFO - 2022-03-26 06:20:49 --> Input Class Initialized
INFO - 2022-03-26 06:20:49 --> Language Class Initialized
INFO - 2022-03-26 06:20:49 --> Loader Class Initialized
INFO - 2022-03-26 06:20:49 --> Helper loaded: url_helper
INFO - 2022-03-26 06:20:49 --> Helper loaded: form_helper
INFO - 2022-03-26 06:20:49 --> Database Driver Class Initialized
INFO - 2022-03-26 06:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:20:49 --> Form Validation Class Initialized
INFO - 2022-03-26 06:20:49 --> Controller Class Initialized
INFO - 2022-03-26 06:20:49 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:20:49 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:20:49 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:20:49 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:20:49 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:20:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:20:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:20:49 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:20:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:20:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:20:49 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:20:49 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:20:49 --> Final output sent to browser
INFO - 2022-03-26 06:21:07 --> Config Class Initialized
INFO - 2022-03-26 06:21:07 --> Hooks Class Initialized
INFO - 2022-03-26 06:21:07 --> Utf8 Class Initialized
INFO - 2022-03-26 06:21:07 --> URI Class Initialized
INFO - 2022-03-26 06:21:07 --> Router Class Initialized
INFO - 2022-03-26 06:21:07 --> Output Class Initialized
INFO - 2022-03-26 06:21:07 --> Security Class Initialized
INFO - 2022-03-26 06:21:07 --> Input Class Initialized
INFO - 2022-03-26 06:21:07 --> Language Class Initialized
INFO - 2022-03-26 06:21:07 --> Loader Class Initialized
INFO - 2022-03-26 06:21:07 --> Helper loaded: url_helper
INFO - 2022-03-26 06:21:07 --> Helper loaded: form_helper
INFO - 2022-03-26 06:21:07 --> Database Driver Class Initialized
INFO - 2022-03-26 06:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 06:21:07 --> Form Validation Class Initialized
INFO - 2022-03-26 06:21:07 --> Controller Class Initialized
INFO - 2022-03-26 06:21:07 --> Model "M_todo_list" initialized
INFO - 2022-03-26 06:21:07 --> Model "M_todo_group_ptk" initialized
INFO - 2022-03-26 06:21:07 --> Model "M_todo_group" initialized
INFO - 2022-03-26 06:21:07 --> Model "M_todo_task" initialized
INFO - 2022-03-26 06:21:07 --> Model "M_tutor" initialized
INFO - 2022-03-26 06:21:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/head.php
INFO - 2022-03-26 06:21:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/navbar.php
INFO - 2022-03-26 06:21:07 --> File loaded: C:\laragon\www\list-todo\application\views\todo_list/v_index.php
INFO - 2022-03-26 06:21:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/sidebar.php
INFO - 2022-03-26 06:21:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/footer.php
INFO - 2022-03-26 06:21:07 --> File loaded: C:\laragon\www\list-todo\application\views\_partials/script.php
INFO - 2022-03-26 06:21:07 --> File loaded: C:\laragon\www\list-todo\application\views\template.php
INFO - 2022-03-26 06:21:07 --> Final output sent to browser
