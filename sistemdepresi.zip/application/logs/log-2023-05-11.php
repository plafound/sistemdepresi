<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-11 16:27:36 --> Config Class Initialized
INFO - 2023-05-11 16:27:36 --> Hooks Class Initialized
INFO - 2023-05-11 16:27:36 --> Utf8 Class Initialized
INFO - 2023-05-11 16:27:36 --> URI Class Initialized
INFO - 2023-05-11 16:27:36 --> Router Class Initialized
INFO - 2023-05-11 16:27:36 --> Output Class Initialized
INFO - 2023-05-11 16:27:36 --> Security Class Initialized
INFO - 2023-05-11 16:27:36 --> Input Class Initialized
INFO - 2023-05-11 16:27:36 --> Language Class Initialized
INFO - 2023-05-11 16:27:36 --> Loader Class Initialized
INFO - 2023-05-11 16:27:36 --> Helper loaded: url_helper
INFO - 2023-05-11 16:27:36 --> Helper loaded: form_helper
INFO - 2023-05-11 16:27:36 --> Database Driver Class Initialized
INFO - 2023-05-11 16:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:27:36 --> Form Validation Class Initialized
INFO - 2023-05-11 16:27:36 --> Controller Class Initialized
INFO - 2023-05-11 16:27:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-11 16:27:36 --> Final output sent to browser
INFO - 2023-05-11 16:27:39 --> Config Class Initialized
INFO - 2023-05-11 16:27:39 --> Hooks Class Initialized
INFO - 2023-05-11 16:27:39 --> Utf8 Class Initialized
INFO - 2023-05-11 16:27:39 --> URI Class Initialized
INFO - 2023-05-11 16:27:39 --> Router Class Initialized
INFO - 2023-05-11 16:27:39 --> Output Class Initialized
INFO - 2023-05-11 16:27:39 --> Security Class Initialized
INFO - 2023-05-11 16:27:39 --> Input Class Initialized
INFO - 2023-05-11 16:27:39 --> Language Class Initialized
INFO - 2023-05-11 16:27:39 --> Loader Class Initialized
INFO - 2023-05-11 16:27:39 --> Helper loaded: url_helper
INFO - 2023-05-11 16:27:39 --> Helper loaded: form_helper
INFO - 2023-05-11 16:27:39 --> Database Driver Class Initialized
INFO - 2023-05-11 16:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:27:39 --> Form Validation Class Initialized
INFO - 2023-05-11 16:27:39 --> Controller Class Initialized
INFO - 2023-05-11 16:27:39 --> Model "m_user" initialized
INFO - 2023-05-11 16:27:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:27:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:27:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:27:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:27:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:27:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-11 16:27:40 --> Final output sent to browser
INFO - 2023-05-11 16:27:42 --> Config Class Initialized
INFO - 2023-05-11 16:27:42 --> Hooks Class Initialized
INFO - 2023-05-11 16:27:42 --> Utf8 Class Initialized
INFO - 2023-05-11 16:27:42 --> URI Class Initialized
INFO - 2023-05-11 16:27:42 --> Router Class Initialized
INFO - 2023-05-11 16:27:42 --> Output Class Initialized
INFO - 2023-05-11 16:27:42 --> Security Class Initialized
INFO - 2023-05-11 16:27:42 --> Input Class Initialized
INFO - 2023-05-11 16:27:42 --> Language Class Initialized
INFO - 2023-05-11 16:27:42 --> Loader Class Initialized
INFO - 2023-05-11 16:27:42 --> Helper loaded: url_helper
INFO - 2023-05-11 16:27:42 --> Helper loaded: form_helper
INFO - 2023-05-11 16:27:42 --> Database Driver Class Initialized
INFO - 2023-05-11 16:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:27:42 --> Form Validation Class Initialized
INFO - 2023-05-11 16:27:42 --> Controller Class Initialized
INFO - 2023-05-11 16:27:42 --> Model "m_user" initialized
INFO - 2023-05-11 16:27:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:27:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:27:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:27:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:27:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:27:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-11 16:27:42 --> Final output sent to browser
INFO - 2023-05-11 16:28:57 --> Config Class Initialized
INFO - 2023-05-11 16:28:57 --> Hooks Class Initialized
INFO - 2023-05-11 16:28:57 --> Utf8 Class Initialized
INFO - 2023-05-11 16:28:57 --> URI Class Initialized
INFO - 2023-05-11 16:28:57 --> Router Class Initialized
INFO - 2023-05-11 16:28:57 --> Output Class Initialized
INFO - 2023-05-11 16:28:57 --> Security Class Initialized
INFO - 2023-05-11 16:28:57 --> Input Class Initialized
INFO - 2023-05-11 16:28:57 --> Language Class Initialized
INFO - 2023-05-11 16:28:57 --> Loader Class Initialized
INFO - 2023-05-11 16:28:57 --> Helper loaded: url_helper
INFO - 2023-05-11 16:28:57 --> Helper loaded: form_helper
INFO - 2023-05-11 16:28:57 --> Database Driver Class Initialized
INFO - 2023-05-11 16:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:28:57 --> Form Validation Class Initialized
INFO - 2023-05-11 16:28:57 --> Controller Class Initialized
INFO - 2023-05-11 16:28:57 --> Model "m_user" initialized
INFO - 2023-05-11 16:28:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:28:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:28:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:28:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:28:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:28:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-11 16:28:57 --> Final output sent to browser
INFO - 2023-05-11 16:28:59 --> Config Class Initialized
INFO - 2023-05-11 16:28:59 --> Hooks Class Initialized
INFO - 2023-05-11 16:28:59 --> Utf8 Class Initialized
INFO - 2023-05-11 16:28:59 --> URI Class Initialized
INFO - 2023-05-11 16:28:59 --> Router Class Initialized
INFO - 2023-05-11 16:28:59 --> Output Class Initialized
INFO - 2023-05-11 16:28:59 --> Security Class Initialized
INFO - 2023-05-11 16:28:59 --> Input Class Initialized
INFO - 2023-05-11 16:28:59 --> Language Class Initialized
INFO - 2023-05-11 16:28:59 --> Loader Class Initialized
INFO - 2023-05-11 16:28:59 --> Helper loaded: url_helper
INFO - 2023-05-11 16:28:59 --> Helper loaded: form_helper
INFO - 2023-05-11 16:28:59 --> Database Driver Class Initialized
INFO - 2023-05-11 16:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:28:59 --> Form Validation Class Initialized
INFO - 2023-05-11 16:28:59 --> Controller Class Initialized
INFO - 2023-05-11 16:28:59 --> Model "m_datatrain" initialized
INFO - 2023-05-11 16:28:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:28:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:28:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-11 16:28:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:28:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:28:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:28:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-11 16:28:59 --> Final output sent to browser
INFO - 2023-05-11 16:29:36 --> Config Class Initialized
INFO - 2023-05-11 16:29:36 --> Hooks Class Initialized
INFO - 2023-05-11 16:29:36 --> Utf8 Class Initialized
INFO - 2023-05-11 16:29:36 --> URI Class Initialized
INFO - 2023-05-11 16:29:36 --> Router Class Initialized
INFO - 2023-05-11 16:29:36 --> Output Class Initialized
INFO - 2023-05-11 16:29:36 --> Security Class Initialized
INFO - 2023-05-11 16:29:36 --> Input Class Initialized
INFO - 2023-05-11 16:29:36 --> Language Class Initialized
INFO - 2023-05-11 16:29:36 --> Loader Class Initialized
INFO - 2023-05-11 16:29:36 --> Helper loaded: url_helper
INFO - 2023-05-11 16:29:36 --> Helper loaded: form_helper
INFO - 2023-05-11 16:29:36 --> Database Driver Class Initialized
INFO - 2023-05-11 16:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:29:36 --> Form Validation Class Initialized
INFO - 2023-05-11 16:29:36 --> Controller Class Initialized
INFO - 2023-05-11 16:29:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-11 16:29:36 --> Final output sent to browser
INFO - 2023-05-11 16:29:42 --> Config Class Initialized
INFO - 2023-05-11 16:29:42 --> Hooks Class Initialized
INFO - 2023-05-11 16:29:42 --> Utf8 Class Initialized
INFO - 2023-05-11 16:29:42 --> URI Class Initialized
INFO - 2023-05-11 16:29:42 --> Router Class Initialized
INFO - 2023-05-11 16:29:42 --> Output Class Initialized
INFO - 2023-05-11 16:29:42 --> Security Class Initialized
INFO - 2023-05-11 16:29:42 --> Input Class Initialized
INFO - 2023-05-11 16:29:42 --> Language Class Initialized
INFO - 2023-05-11 16:29:42 --> Loader Class Initialized
INFO - 2023-05-11 16:29:42 --> Helper loaded: url_helper
INFO - 2023-05-11 16:29:42 --> Helper loaded: form_helper
INFO - 2023-05-11 16:29:42 --> Database Driver Class Initialized
INFO - 2023-05-11 16:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:29:42 --> Form Validation Class Initialized
INFO - 2023-05-11 16:29:42 --> Controller Class Initialized
INFO - 2023-05-11 16:29:42 --> Model "m_user" initialized
INFO - 2023-05-11 16:29:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:29:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:29:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:29:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:29:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:29:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-11 16:29:42 --> Final output sent to browser
INFO - 2023-05-11 16:29:49 --> Config Class Initialized
INFO - 2023-05-11 16:29:49 --> Hooks Class Initialized
INFO - 2023-05-11 16:29:49 --> Utf8 Class Initialized
INFO - 2023-05-11 16:29:49 --> URI Class Initialized
INFO - 2023-05-11 16:29:49 --> Router Class Initialized
INFO - 2023-05-11 16:29:49 --> Output Class Initialized
INFO - 2023-05-11 16:29:49 --> Security Class Initialized
INFO - 2023-05-11 16:29:49 --> Input Class Initialized
INFO - 2023-05-11 16:29:49 --> Language Class Initialized
INFO - 2023-05-11 16:29:49 --> Loader Class Initialized
INFO - 2023-05-11 16:29:49 --> Helper loaded: url_helper
INFO - 2023-05-11 16:29:49 --> Helper loaded: form_helper
INFO - 2023-05-11 16:29:49 --> Database Driver Class Initialized
INFO - 2023-05-11 16:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:29:49 --> Form Validation Class Initialized
INFO - 2023-05-11 16:29:49 --> Controller Class Initialized
INFO - 2023-05-11 16:29:49 --> Model "m_datatrain" initialized
INFO - 2023-05-11 16:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-11 16:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:29:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-11 16:29:49 --> Final output sent to browser
INFO - 2023-05-11 16:29:54 --> Config Class Initialized
INFO - 2023-05-11 16:29:54 --> Hooks Class Initialized
INFO - 2023-05-11 16:29:54 --> Utf8 Class Initialized
INFO - 2023-05-11 16:29:54 --> URI Class Initialized
INFO - 2023-05-11 16:29:54 --> Router Class Initialized
INFO - 2023-05-11 16:29:54 --> Output Class Initialized
INFO - 2023-05-11 16:29:54 --> Security Class Initialized
INFO - 2023-05-11 16:29:54 --> Input Class Initialized
INFO - 2023-05-11 16:29:54 --> Language Class Initialized
INFO - 2023-05-11 16:29:54 --> Loader Class Initialized
INFO - 2023-05-11 16:29:54 --> Helper loaded: url_helper
INFO - 2023-05-11 16:29:54 --> Helper loaded: form_helper
INFO - 2023-05-11 16:29:54 --> Database Driver Class Initialized
INFO - 2023-05-11 16:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:29:54 --> Form Validation Class Initialized
INFO - 2023-05-11 16:29:54 --> Controller Class Initialized
INFO - 2023-05-11 16:29:54 --> Model "m_datatrain" initialized
INFO - 2023-05-11 16:29:54 --> Final output sent to browser
INFO - 2023-05-11 16:52:44 --> Config Class Initialized
INFO - 2023-05-11 16:52:44 --> Hooks Class Initialized
INFO - 2023-05-11 16:52:44 --> Utf8 Class Initialized
INFO - 2023-05-11 16:52:44 --> URI Class Initialized
INFO - 2023-05-11 16:52:44 --> Router Class Initialized
INFO - 2023-05-11 16:52:44 --> Output Class Initialized
INFO - 2023-05-11 16:52:44 --> Security Class Initialized
INFO - 2023-05-11 16:52:44 --> Input Class Initialized
INFO - 2023-05-11 16:52:44 --> Language Class Initialized
INFO - 2023-05-11 16:52:44 --> Loader Class Initialized
INFO - 2023-05-11 16:52:44 --> Helper loaded: url_helper
INFO - 2023-05-11 16:52:44 --> Helper loaded: form_helper
INFO - 2023-05-11 16:52:44 --> Database Driver Class Initialized
INFO - 2023-05-11 16:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:52:45 --> Form Validation Class Initialized
INFO - 2023-05-11 16:52:45 --> Controller Class Initialized
INFO - 2023-05-11 16:52:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-11 16:52:45 --> Final output sent to browser
INFO - 2023-05-11 16:52:47 --> Config Class Initialized
INFO - 2023-05-11 16:52:47 --> Hooks Class Initialized
INFO - 2023-05-11 16:52:47 --> Utf8 Class Initialized
INFO - 2023-05-11 16:52:47 --> URI Class Initialized
INFO - 2023-05-11 16:52:47 --> Router Class Initialized
INFO - 2023-05-11 16:52:47 --> Output Class Initialized
INFO - 2023-05-11 16:52:47 --> Security Class Initialized
INFO - 2023-05-11 16:52:47 --> Input Class Initialized
INFO - 2023-05-11 16:52:47 --> Language Class Initialized
INFO - 2023-05-11 16:52:47 --> Loader Class Initialized
INFO - 2023-05-11 16:52:47 --> Helper loaded: url_helper
INFO - 2023-05-11 16:52:47 --> Helper loaded: form_helper
INFO - 2023-05-11 16:52:47 --> Database Driver Class Initialized
INFO - 2023-05-11 16:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:52:47 --> Form Validation Class Initialized
INFO - 2023-05-11 16:52:47 --> Controller Class Initialized
INFO - 2023-05-11 16:52:47 --> Model "m_user" initialized
INFO - 2023-05-11 16:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:52:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-11 16:52:47 --> Final output sent to browser
INFO - 2023-05-11 16:52:49 --> Config Class Initialized
INFO - 2023-05-11 16:52:49 --> Hooks Class Initialized
INFO - 2023-05-11 16:52:49 --> Utf8 Class Initialized
INFO - 2023-05-11 16:52:49 --> URI Class Initialized
INFO - 2023-05-11 16:52:49 --> Router Class Initialized
INFO - 2023-05-11 16:52:49 --> Output Class Initialized
INFO - 2023-05-11 16:52:49 --> Security Class Initialized
INFO - 2023-05-11 16:52:49 --> Input Class Initialized
INFO - 2023-05-11 16:52:49 --> Language Class Initialized
INFO - 2023-05-11 16:52:49 --> Loader Class Initialized
INFO - 2023-05-11 16:52:49 --> Helper loaded: url_helper
INFO - 2023-05-11 16:52:49 --> Helper loaded: form_helper
INFO - 2023-05-11 16:52:49 --> Database Driver Class Initialized
INFO - 2023-05-11 16:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:52:49 --> Form Validation Class Initialized
INFO - 2023-05-11 16:52:49 --> Controller Class Initialized
INFO - 2023-05-11 16:52:49 --> Model "m_datatrain" initialized
INFO - 2023-05-11 16:52:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:52:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:52:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-11 16:52:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:52:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:52:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:52:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-11 16:52:49 --> Final output sent to browser
INFO - 2023-05-11 16:56:44 --> Config Class Initialized
INFO - 2023-05-11 16:56:44 --> Hooks Class Initialized
INFO - 2023-05-11 16:56:44 --> Utf8 Class Initialized
INFO - 2023-05-11 16:56:44 --> URI Class Initialized
INFO - 2023-05-11 16:56:44 --> Router Class Initialized
INFO - 2023-05-11 16:56:44 --> Output Class Initialized
INFO - 2023-05-11 16:56:44 --> Security Class Initialized
INFO - 2023-05-11 16:56:44 --> Input Class Initialized
INFO - 2023-05-11 16:56:44 --> Language Class Initialized
INFO - 2023-05-11 16:56:44 --> Loader Class Initialized
INFO - 2023-05-11 16:56:44 --> Helper loaded: url_helper
INFO - 2023-05-11 16:56:44 --> Helper loaded: form_helper
INFO - 2023-05-11 16:56:44 --> Database Driver Class Initialized
INFO - 2023-05-11 16:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:56:44 --> Form Validation Class Initialized
INFO - 2023-05-11 16:56:44 --> Controller Class Initialized
INFO - 2023-05-11 16:56:44 --> Model "m_datatrain" initialized
INFO - 2023-05-11 16:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-11 16:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:56:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-11 16:56:44 --> Final output sent to browser
INFO - 2023-05-11 16:56:56 --> Config Class Initialized
INFO - 2023-05-11 16:56:56 --> Hooks Class Initialized
INFO - 2023-05-11 16:56:56 --> Utf8 Class Initialized
INFO - 2023-05-11 16:56:56 --> URI Class Initialized
INFO - 2023-05-11 16:56:56 --> Router Class Initialized
INFO - 2023-05-11 16:56:56 --> Output Class Initialized
INFO - 2023-05-11 16:56:56 --> Security Class Initialized
INFO - 2023-05-11 16:56:56 --> Input Class Initialized
INFO - 2023-05-11 16:56:56 --> Language Class Initialized
INFO - 2023-05-11 16:56:56 --> Loader Class Initialized
INFO - 2023-05-11 16:56:56 --> Helper loaded: url_helper
INFO - 2023-05-11 16:56:56 --> Helper loaded: form_helper
INFO - 2023-05-11 16:56:56 --> Database Driver Class Initialized
INFO - 2023-05-11 16:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:56:56 --> Form Validation Class Initialized
INFO - 2023-05-11 16:56:56 --> Controller Class Initialized
INFO - 2023-05-11 16:56:56 --> Model "m_datatrain" initialized
INFO - 2023-05-11 16:56:56 --> Final output sent to browser
INFO - 2023-05-11 16:57:01 --> Config Class Initialized
INFO - 2023-05-11 16:57:01 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:01 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:01 --> URI Class Initialized
INFO - 2023-05-11 16:57:01 --> Router Class Initialized
INFO - 2023-05-11 16:57:01 --> Output Class Initialized
INFO - 2023-05-11 16:57:01 --> Security Class Initialized
INFO - 2023-05-11 16:57:01 --> Input Class Initialized
INFO - 2023-05-11 16:57:01 --> Language Class Initialized
INFO - 2023-05-11 16:57:01 --> Loader Class Initialized
INFO - 2023-05-11 16:57:01 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:01 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:01 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:57:01 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:01 --> Controller Class Initialized
INFO - 2023-05-11 16:57:01 --> Model "m_datatrain" initialized
INFO - 2023-05-11 16:57:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:57:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:57:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-11 16:57:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:57:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:57:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:57:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-11 16:57:01 --> Final output sent to browser
INFO - 2023-05-11 16:57:02 --> Config Class Initialized
INFO - 2023-05-11 16:57:02 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:02 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:02 --> URI Class Initialized
INFO - 2023-05-11 16:57:02 --> Router Class Initialized
INFO - 2023-05-11 16:57:02 --> Output Class Initialized
INFO - 2023-05-11 16:57:02 --> Security Class Initialized
INFO - 2023-05-11 16:57:02 --> Input Class Initialized
INFO - 2023-05-11 16:57:02 --> Language Class Initialized
INFO - 2023-05-11 16:57:02 --> Loader Class Initialized
INFO - 2023-05-11 16:57:02 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:03 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:03 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:03 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:03 --> Controller Class Initialized
INFO - 2023-05-11 16:57:03 --> Model "m_user" initialized
INFO - 2023-05-11 16:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-11 16:57:03 --> Final output sent to browser
INFO - 2023-05-11 16:57:05 --> Config Class Initialized
INFO - 2023-05-11 16:57:05 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:05 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:05 --> URI Class Initialized
INFO - 2023-05-11 16:57:05 --> Router Class Initialized
INFO - 2023-05-11 16:57:05 --> Output Class Initialized
INFO - 2023-05-11 16:57:05 --> Security Class Initialized
INFO - 2023-05-11 16:57:05 --> Input Class Initialized
INFO - 2023-05-11 16:57:05 --> Language Class Initialized
INFO - 2023-05-11 16:57:05 --> Loader Class Initialized
INFO - 2023-05-11 16:57:05 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:05 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:05 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:57:06 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:06 --> Controller Class Initialized
INFO - 2023-05-11 16:57:06 --> Model "m_user" initialized
INFO - 2023-05-11 16:57:06 --> Config Class Initialized
INFO - 2023-05-11 16:57:06 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:06 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:06 --> URI Class Initialized
INFO - 2023-05-11 16:57:06 --> Router Class Initialized
INFO - 2023-05-11 16:57:06 --> Output Class Initialized
INFO - 2023-05-11 16:57:06 --> Security Class Initialized
INFO - 2023-05-11 16:57:06 --> Input Class Initialized
INFO - 2023-05-11 16:57:06 --> Language Class Initialized
INFO - 2023-05-11 16:57:06 --> Loader Class Initialized
INFO - 2023-05-11 16:57:06 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:06 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:06 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:57:06 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:06 --> Controller Class Initialized
INFO - 2023-05-11 16:57:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-11 16:57:06 --> Final output sent to browser
INFO - 2023-05-11 16:57:07 --> Config Class Initialized
INFO - 2023-05-11 16:57:07 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:07 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:07 --> URI Class Initialized
INFO - 2023-05-11 16:57:07 --> Router Class Initialized
INFO - 2023-05-11 16:57:07 --> Output Class Initialized
INFO - 2023-05-11 16:57:07 --> Security Class Initialized
INFO - 2023-05-11 16:57:07 --> Input Class Initialized
INFO - 2023-05-11 16:57:07 --> Language Class Initialized
INFO - 2023-05-11 16:57:07 --> Loader Class Initialized
INFO - 2023-05-11 16:57:07 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:07 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:07 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:57:07 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:07 --> Controller Class Initialized
INFO - 2023-05-11 16:57:07 --> Model "m_user" initialized
INFO - 2023-05-11 16:57:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-11 16:57:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-11 16:57:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-11 16:57:07 --> Final output sent to browser
INFO - 2023-05-11 16:57:10 --> Config Class Initialized
INFO - 2023-05-11 16:57:10 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:10 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:10 --> URI Class Initialized
INFO - 2023-05-11 16:57:10 --> Router Class Initialized
INFO - 2023-05-11 16:57:10 --> Output Class Initialized
INFO - 2023-05-11 16:57:10 --> Security Class Initialized
INFO - 2023-05-11 16:57:10 --> Input Class Initialized
INFO - 2023-05-11 16:57:10 --> Language Class Initialized
INFO - 2023-05-11 16:57:10 --> Loader Class Initialized
INFO - 2023-05-11 16:57:10 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:10 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:10 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:57:10 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:10 --> Controller Class Initialized
INFO - 2023-05-11 16:57:10 --> Model "m_user" initialized
INFO - 2023-05-11 16:57:11 --> Config Class Initialized
INFO - 2023-05-11 16:57:11 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:11 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:11 --> URI Class Initialized
INFO - 2023-05-11 16:57:11 --> Router Class Initialized
INFO - 2023-05-11 16:57:11 --> Output Class Initialized
INFO - 2023-05-11 16:57:11 --> Security Class Initialized
INFO - 2023-05-11 16:57:11 --> Input Class Initialized
INFO - 2023-05-11 16:57:11 --> Language Class Initialized
INFO - 2023-05-11 16:57:11 --> Loader Class Initialized
INFO - 2023-05-11 16:57:11 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:11 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:11 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:57:11 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:11 --> Controller Class Initialized
INFO - 2023-05-11 16:57:11 --> Model "m_user" initialized
INFO - 2023-05-11 16:57:11 --> Model "m_datatrain" initialized
INFO - 2023-05-11 16:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-11 16:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:57:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-11 16:57:11 --> Final output sent to browser
INFO - 2023-05-11 16:57:14 --> Config Class Initialized
INFO - 2023-05-11 16:57:14 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:14 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:14 --> URI Class Initialized
INFO - 2023-05-11 16:57:14 --> Router Class Initialized
INFO - 2023-05-11 16:57:14 --> Output Class Initialized
INFO - 2023-05-11 16:57:14 --> Security Class Initialized
INFO - 2023-05-11 16:57:14 --> Input Class Initialized
INFO - 2023-05-11 16:57:14 --> Language Class Initialized
INFO - 2023-05-11 16:57:14 --> Loader Class Initialized
INFO - 2023-05-11 16:57:14 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:14 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:14 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:57:14 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:14 --> Controller Class Initialized
INFO - 2023-05-11 16:57:14 --> Model "m_datatrain" initialized
INFO - 2023-05-11 16:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-11 16:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-11 16:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-11 16:57:14 --> Final output sent to browser
INFO - 2023-05-11 16:57:21 --> Config Class Initialized
INFO - 2023-05-11 16:57:21 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:21 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:21 --> URI Class Initialized
INFO - 2023-05-11 16:57:21 --> Router Class Initialized
INFO - 2023-05-11 16:57:21 --> Output Class Initialized
INFO - 2023-05-11 16:57:21 --> Security Class Initialized
INFO - 2023-05-11 16:57:21 --> Input Class Initialized
INFO - 2023-05-11 16:57:21 --> Language Class Initialized
INFO - 2023-05-11 16:57:21 --> Loader Class Initialized
INFO - 2023-05-11 16:57:21 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:21 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:21 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:57:21 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:21 --> Controller Class Initialized
INFO - 2023-05-11 16:57:21 --> Model "m_user" initialized
INFO - 2023-05-11 16:57:21 --> Config Class Initialized
INFO - 2023-05-11 16:57:21 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:21 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:21 --> URI Class Initialized
INFO - 2023-05-11 16:57:21 --> Router Class Initialized
INFO - 2023-05-11 16:57:21 --> Output Class Initialized
INFO - 2023-05-11 16:57:21 --> Security Class Initialized
INFO - 2023-05-11 16:57:21 --> Input Class Initialized
INFO - 2023-05-11 16:57:21 --> Language Class Initialized
INFO - 2023-05-11 16:57:21 --> Loader Class Initialized
INFO - 2023-05-11 16:57:21 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:21 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:21 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:57:21 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:21 --> Controller Class Initialized
INFO - 2023-05-11 16:57:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-11 16:57:21 --> Final output sent to browser
INFO - 2023-05-11 16:57:22 --> Config Class Initialized
INFO - 2023-05-11 16:57:22 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:22 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:22 --> URI Class Initialized
INFO - 2023-05-11 16:57:22 --> Router Class Initialized
INFO - 2023-05-11 16:57:22 --> Output Class Initialized
INFO - 2023-05-11 16:57:22 --> Security Class Initialized
INFO - 2023-05-11 16:57:22 --> Input Class Initialized
INFO - 2023-05-11 16:57:22 --> Language Class Initialized
INFO - 2023-05-11 16:57:22 --> Loader Class Initialized
INFO - 2023-05-11 16:57:22 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:22 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:22 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:57:22 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:22 --> Controller Class Initialized
INFO - 2023-05-11 16:57:22 --> Model "m_user" initialized
INFO - 2023-05-11 16:57:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:57:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:57:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:57:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:57:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:57:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-11 16:57:22 --> Final output sent to browser
INFO - 2023-05-11 16:57:49 --> Config Class Initialized
INFO - 2023-05-11 16:57:49 --> Hooks Class Initialized
INFO - 2023-05-11 16:57:49 --> Utf8 Class Initialized
INFO - 2023-05-11 16:57:49 --> URI Class Initialized
INFO - 2023-05-11 16:57:49 --> Router Class Initialized
INFO - 2023-05-11 16:57:49 --> Output Class Initialized
INFO - 2023-05-11 16:57:49 --> Security Class Initialized
INFO - 2023-05-11 16:57:49 --> Input Class Initialized
INFO - 2023-05-11 16:57:49 --> Language Class Initialized
INFO - 2023-05-11 16:57:49 --> Loader Class Initialized
INFO - 2023-05-11 16:57:49 --> Helper loaded: url_helper
INFO - 2023-05-11 16:57:49 --> Helper loaded: form_helper
INFO - 2023-05-11 16:57:49 --> Database Driver Class Initialized
INFO - 2023-05-11 16:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:57:49 --> Form Validation Class Initialized
INFO - 2023-05-11 16:57:49 --> Controller Class Initialized
INFO - 2023-05-11 16:57:49 --> Model "m_datatrain" initialized
INFO - 2023-05-11 16:57:49 --> Final output sent to browser
INFO - 2023-05-11 16:58:28 --> Config Class Initialized
INFO - 2023-05-11 16:58:28 --> Hooks Class Initialized
INFO - 2023-05-11 16:58:28 --> Utf8 Class Initialized
INFO - 2023-05-11 16:58:28 --> URI Class Initialized
INFO - 2023-05-11 16:58:28 --> Router Class Initialized
INFO - 2023-05-11 16:58:28 --> Output Class Initialized
INFO - 2023-05-11 16:58:28 --> Security Class Initialized
INFO - 2023-05-11 16:58:28 --> Input Class Initialized
INFO - 2023-05-11 16:58:28 --> Language Class Initialized
INFO - 2023-05-11 16:58:28 --> Loader Class Initialized
INFO - 2023-05-11 16:58:28 --> Helper loaded: url_helper
INFO - 2023-05-11 16:58:28 --> Helper loaded: form_helper
INFO - 2023-05-11 16:58:28 --> Database Driver Class Initialized
INFO - 2023-05-11 16:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 16:58:28 --> Form Validation Class Initialized
INFO - 2023-05-11 16:58:28 --> Controller Class Initialized
INFO - 2023-05-11 16:58:28 --> Model "m_datatrain" initialized
INFO - 2023-05-11 16:58:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 16:58:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 16:58:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-11 16:58:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 16:58:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 16:58:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 16:58:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-11 16:58:28 --> Final output sent to browser
INFO - 2023-05-11 17:01:56 --> Config Class Initialized
INFO - 2023-05-11 17:01:56 --> Hooks Class Initialized
INFO - 2023-05-11 17:01:56 --> Utf8 Class Initialized
INFO - 2023-05-11 17:01:56 --> URI Class Initialized
INFO - 2023-05-11 17:01:56 --> Router Class Initialized
INFO - 2023-05-11 17:01:56 --> Output Class Initialized
INFO - 2023-05-11 17:01:56 --> Security Class Initialized
INFO - 2023-05-11 17:01:56 --> Input Class Initialized
INFO - 2023-05-11 17:01:56 --> Language Class Initialized
INFO - 2023-05-11 17:01:56 --> Loader Class Initialized
INFO - 2023-05-11 17:01:56 --> Helper loaded: url_helper
INFO - 2023-05-11 17:01:56 --> Helper loaded: form_helper
INFO - 2023-05-11 17:01:56 --> Database Driver Class Initialized
INFO - 2023-05-11 17:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:01:56 --> Form Validation Class Initialized
INFO - 2023-05-11 17:01:56 --> Controller Class Initialized
INFO - 2023-05-11 17:01:56 --> Model "m_user" initialized
INFO - 2023-05-11 17:01:56 --> Config Class Initialized
INFO - 2023-05-11 17:01:56 --> Hooks Class Initialized
INFO - 2023-05-11 17:01:56 --> Utf8 Class Initialized
INFO - 2023-05-11 17:01:56 --> URI Class Initialized
INFO - 2023-05-11 17:01:56 --> Router Class Initialized
INFO - 2023-05-11 17:01:56 --> Output Class Initialized
INFO - 2023-05-11 17:01:56 --> Security Class Initialized
INFO - 2023-05-11 17:01:56 --> Input Class Initialized
INFO - 2023-05-11 17:01:56 --> Language Class Initialized
INFO - 2023-05-11 17:01:56 --> Loader Class Initialized
INFO - 2023-05-11 17:01:56 --> Helper loaded: url_helper
INFO - 2023-05-11 17:01:56 --> Helper loaded: form_helper
INFO - 2023-05-11 17:01:56 --> Database Driver Class Initialized
INFO - 2023-05-11 17:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:01:56 --> Form Validation Class Initialized
INFO - 2023-05-11 17:01:56 --> Controller Class Initialized
INFO - 2023-05-11 17:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-11 17:01:56 --> Final output sent to browser
INFO - 2023-05-11 17:01:58 --> Config Class Initialized
INFO - 2023-05-11 17:01:58 --> Hooks Class Initialized
INFO - 2023-05-11 17:01:58 --> Utf8 Class Initialized
INFO - 2023-05-11 17:01:58 --> URI Class Initialized
INFO - 2023-05-11 17:01:58 --> Router Class Initialized
INFO - 2023-05-11 17:01:58 --> Output Class Initialized
INFO - 2023-05-11 17:01:58 --> Security Class Initialized
INFO - 2023-05-11 17:01:58 --> Input Class Initialized
INFO - 2023-05-11 17:01:58 --> Language Class Initialized
INFO - 2023-05-11 17:01:58 --> Loader Class Initialized
INFO - 2023-05-11 17:01:58 --> Helper loaded: url_helper
INFO - 2023-05-11 17:01:58 --> Helper loaded: form_helper
INFO - 2023-05-11 17:01:58 --> Database Driver Class Initialized
INFO - 2023-05-11 17:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:01:58 --> Form Validation Class Initialized
INFO - 2023-05-11 17:01:58 --> Controller Class Initialized
INFO - 2023-05-11 17:01:58 --> Model "m_user" initialized
INFO - 2023-05-11 17:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-11 17:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-11 17:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-11 17:01:58 --> Final output sent to browser
INFO - 2023-05-11 17:02:02 --> Config Class Initialized
INFO - 2023-05-11 17:02:02 --> Hooks Class Initialized
INFO - 2023-05-11 17:02:02 --> Utf8 Class Initialized
INFO - 2023-05-11 17:02:02 --> URI Class Initialized
INFO - 2023-05-11 17:02:02 --> Router Class Initialized
INFO - 2023-05-11 17:02:02 --> Output Class Initialized
INFO - 2023-05-11 17:02:02 --> Security Class Initialized
INFO - 2023-05-11 17:02:02 --> Input Class Initialized
INFO - 2023-05-11 17:02:02 --> Language Class Initialized
INFO - 2023-05-11 17:02:02 --> Loader Class Initialized
INFO - 2023-05-11 17:02:02 --> Helper loaded: url_helper
INFO - 2023-05-11 17:02:02 --> Helper loaded: form_helper
INFO - 2023-05-11 17:02:02 --> Database Driver Class Initialized
INFO - 2023-05-11 17:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:02:02 --> Form Validation Class Initialized
INFO - 2023-05-11 17:02:02 --> Controller Class Initialized
INFO - 2023-05-11 17:02:02 --> Model "m_user" initialized
INFO - 2023-05-11 17:02:02 --> Config Class Initialized
INFO - 2023-05-11 17:02:02 --> Hooks Class Initialized
INFO - 2023-05-11 17:02:02 --> Utf8 Class Initialized
INFO - 2023-05-11 17:02:02 --> URI Class Initialized
INFO - 2023-05-11 17:02:02 --> Router Class Initialized
INFO - 2023-05-11 17:02:02 --> Output Class Initialized
INFO - 2023-05-11 17:02:02 --> Security Class Initialized
INFO - 2023-05-11 17:02:02 --> Input Class Initialized
INFO - 2023-05-11 17:02:02 --> Language Class Initialized
INFO - 2023-05-11 17:02:02 --> Loader Class Initialized
INFO - 2023-05-11 17:02:02 --> Helper loaded: url_helper
INFO - 2023-05-11 17:02:02 --> Helper loaded: form_helper
INFO - 2023-05-11 17:02:02 --> Database Driver Class Initialized
INFO - 2023-05-11 17:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:02:02 --> Form Validation Class Initialized
INFO - 2023-05-11 17:02:02 --> Controller Class Initialized
INFO - 2023-05-11 17:02:02 --> Model "m_user" initialized
INFO - 2023-05-11 17:02:02 --> Model "m_datatrain" initialized
INFO - 2023-05-11 17:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 17:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 17:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-11 17:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 17:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 17:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-11 17:02:02 --> Final output sent to browser
INFO - 2023-05-11 17:02:04 --> Config Class Initialized
INFO - 2023-05-11 17:02:04 --> Hooks Class Initialized
INFO - 2023-05-11 17:02:04 --> Utf8 Class Initialized
INFO - 2023-05-11 17:02:04 --> URI Class Initialized
INFO - 2023-05-11 17:02:04 --> Router Class Initialized
INFO - 2023-05-11 17:02:04 --> Output Class Initialized
INFO - 2023-05-11 17:02:04 --> Security Class Initialized
INFO - 2023-05-11 17:02:04 --> Input Class Initialized
INFO - 2023-05-11 17:02:04 --> Language Class Initialized
INFO - 2023-05-11 17:02:04 --> Loader Class Initialized
INFO - 2023-05-11 17:02:04 --> Helper loaded: url_helper
INFO - 2023-05-11 17:02:04 --> Helper loaded: form_helper
INFO - 2023-05-11 17:02:04 --> Database Driver Class Initialized
INFO - 2023-05-11 17:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:02:04 --> Form Validation Class Initialized
INFO - 2023-05-11 17:02:04 --> Controller Class Initialized
INFO - 2023-05-11 17:02:04 --> Model "m_datatrain" initialized
INFO - 2023-05-11 17:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 17:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 17:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-11 17:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-11 17:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 17:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 17:02:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-11 17:02:04 --> Final output sent to browser
INFO - 2023-05-11 17:03:09 --> Config Class Initialized
INFO - 2023-05-11 17:03:09 --> Hooks Class Initialized
INFO - 2023-05-11 17:03:09 --> Utf8 Class Initialized
INFO - 2023-05-11 17:03:09 --> URI Class Initialized
INFO - 2023-05-11 17:03:09 --> Router Class Initialized
INFO - 2023-05-11 17:03:09 --> Output Class Initialized
INFO - 2023-05-11 17:03:09 --> Security Class Initialized
INFO - 2023-05-11 17:03:09 --> Input Class Initialized
INFO - 2023-05-11 17:03:09 --> Language Class Initialized
INFO - 2023-05-11 17:03:09 --> Loader Class Initialized
INFO - 2023-05-11 17:03:09 --> Helper loaded: url_helper
INFO - 2023-05-11 17:03:09 --> Helper loaded: form_helper
INFO - 2023-05-11 17:03:09 --> Database Driver Class Initialized
INFO - 2023-05-11 17:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:03:09 --> Form Validation Class Initialized
INFO - 2023-05-11 17:03:09 --> Controller Class Initialized
INFO - 2023-05-11 17:03:09 --> Model "m_user" initialized
INFO - 2023-05-11 17:03:09 --> Config Class Initialized
INFO - 2023-05-11 17:03:09 --> Hooks Class Initialized
INFO - 2023-05-11 17:03:09 --> Utf8 Class Initialized
INFO - 2023-05-11 17:03:09 --> URI Class Initialized
INFO - 2023-05-11 17:03:09 --> Router Class Initialized
INFO - 2023-05-11 17:03:09 --> Output Class Initialized
INFO - 2023-05-11 17:03:09 --> Security Class Initialized
INFO - 2023-05-11 17:03:09 --> Input Class Initialized
INFO - 2023-05-11 17:03:09 --> Language Class Initialized
INFO - 2023-05-11 17:03:09 --> Loader Class Initialized
INFO - 2023-05-11 17:03:09 --> Helper loaded: url_helper
INFO - 2023-05-11 17:03:09 --> Helper loaded: form_helper
INFO - 2023-05-11 17:03:09 --> Database Driver Class Initialized
INFO - 2023-05-11 17:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:03:09 --> Form Validation Class Initialized
INFO - 2023-05-11 17:03:09 --> Controller Class Initialized
INFO - 2023-05-11 17:03:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-11 17:03:09 --> Final output sent to browser
INFO - 2023-05-11 17:03:10 --> Config Class Initialized
INFO - 2023-05-11 17:03:10 --> Hooks Class Initialized
INFO - 2023-05-11 17:03:10 --> Utf8 Class Initialized
INFO - 2023-05-11 17:03:10 --> URI Class Initialized
INFO - 2023-05-11 17:03:10 --> Router Class Initialized
INFO - 2023-05-11 17:03:10 --> Output Class Initialized
INFO - 2023-05-11 17:03:10 --> Security Class Initialized
INFO - 2023-05-11 17:03:10 --> Input Class Initialized
INFO - 2023-05-11 17:03:10 --> Language Class Initialized
INFO - 2023-05-11 17:03:10 --> Loader Class Initialized
INFO - 2023-05-11 17:03:10 --> Helper loaded: url_helper
INFO - 2023-05-11 17:03:10 --> Helper loaded: form_helper
INFO - 2023-05-11 17:03:10 --> Database Driver Class Initialized
INFO - 2023-05-11 17:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:03:10 --> Form Validation Class Initialized
INFO - 2023-05-11 17:03:10 --> Controller Class Initialized
INFO - 2023-05-11 17:03:10 --> Model "m_user" initialized
INFO - 2023-05-11 17:03:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 17:03:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 17:03:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 17:03:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 17:03:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 17:03:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-11 17:03:10 --> Final output sent to browser
INFO - 2023-05-11 17:03:14 --> Config Class Initialized
INFO - 2023-05-11 17:03:14 --> Hooks Class Initialized
INFO - 2023-05-11 17:03:14 --> Utf8 Class Initialized
INFO - 2023-05-11 17:03:14 --> URI Class Initialized
INFO - 2023-05-11 17:03:14 --> Router Class Initialized
INFO - 2023-05-11 17:03:14 --> Output Class Initialized
INFO - 2023-05-11 17:03:14 --> Security Class Initialized
INFO - 2023-05-11 17:03:14 --> Input Class Initialized
INFO - 2023-05-11 17:03:14 --> Language Class Initialized
INFO - 2023-05-11 17:03:14 --> Loader Class Initialized
INFO - 2023-05-11 17:03:14 --> Helper loaded: url_helper
INFO - 2023-05-11 17:03:14 --> Helper loaded: form_helper
INFO - 2023-05-11 17:03:14 --> Database Driver Class Initialized
INFO - 2023-05-11 17:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:03:14 --> Form Validation Class Initialized
INFO - 2023-05-11 17:03:14 --> Controller Class Initialized
INFO - 2023-05-11 17:03:14 --> Model "m_user" initialized
INFO - 2023-05-11 17:03:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 17:03:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 17:03:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 17:03:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 17:03:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 17:03:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-11 17:03:14 --> Final output sent to browser
INFO - 2023-05-11 17:03:15 --> Config Class Initialized
INFO - 2023-05-11 17:03:15 --> Hooks Class Initialized
INFO - 2023-05-11 17:03:15 --> Utf8 Class Initialized
INFO - 2023-05-11 17:03:15 --> URI Class Initialized
INFO - 2023-05-11 17:03:15 --> Router Class Initialized
INFO - 2023-05-11 17:03:15 --> Output Class Initialized
INFO - 2023-05-11 17:03:15 --> Security Class Initialized
INFO - 2023-05-11 17:03:15 --> Input Class Initialized
INFO - 2023-05-11 17:03:15 --> Language Class Initialized
INFO - 2023-05-11 17:03:15 --> Loader Class Initialized
INFO - 2023-05-11 17:03:15 --> Helper loaded: url_helper
INFO - 2023-05-11 17:03:15 --> Helper loaded: form_helper
INFO - 2023-05-11 17:03:15 --> Database Driver Class Initialized
INFO - 2023-05-11 17:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:03:15 --> Form Validation Class Initialized
INFO - 2023-05-11 17:03:15 --> Controller Class Initialized
INFO - 2023-05-11 17:03:15 --> Model "m_datatrain" initialized
INFO - 2023-05-11 17:03:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 17:03:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 17:03:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-11 17:03:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 17:03:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 17:03:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 17:03:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-11 17:03:15 --> Final output sent to browser
INFO - 2023-05-11 17:22:02 --> Config Class Initialized
INFO - 2023-05-11 17:22:02 --> Hooks Class Initialized
INFO - 2023-05-11 17:22:02 --> Utf8 Class Initialized
INFO - 2023-05-11 17:22:02 --> URI Class Initialized
INFO - 2023-05-11 17:22:02 --> Router Class Initialized
INFO - 2023-05-11 17:22:02 --> Output Class Initialized
INFO - 2023-05-11 17:22:02 --> Security Class Initialized
INFO - 2023-05-11 17:22:02 --> Input Class Initialized
INFO - 2023-05-11 17:22:02 --> Language Class Initialized
INFO - 2023-05-11 17:22:02 --> Loader Class Initialized
INFO - 2023-05-11 17:22:02 --> Helper loaded: url_helper
INFO - 2023-05-11 17:22:02 --> Helper loaded: form_helper
INFO - 2023-05-11 17:22:02 --> Database Driver Class Initialized
INFO - 2023-05-11 17:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:22:02 --> Form Validation Class Initialized
INFO - 2023-05-11 17:22:02 --> Controller Class Initialized
INFO - 2023-05-11 17:22:02 --> Model "m_user" initialized
INFO - 2023-05-11 17:22:02 --> Config Class Initialized
INFO - 2023-05-11 17:22:02 --> Hooks Class Initialized
INFO - 2023-05-11 17:22:02 --> Utf8 Class Initialized
INFO - 2023-05-11 17:22:02 --> URI Class Initialized
INFO - 2023-05-11 17:22:02 --> Router Class Initialized
INFO - 2023-05-11 17:22:02 --> Output Class Initialized
INFO - 2023-05-11 17:22:02 --> Security Class Initialized
INFO - 2023-05-11 17:22:02 --> Input Class Initialized
INFO - 2023-05-11 17:22:02 --> Language Class Initialized
INFO - 2023-05-11 17:22:02 --> Loader Class Initialized
INFO - 2023-05-11 17:22:02 --> Helper loaded: url_helper
INFO - 2023-05-11 17:22:02 --> Helper loaded: form_helper
INFO - 2023-05-11 17:22:02 --> Database Driver Class Initialized
INFO - 2023-05-11 17:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:22:02 --> Form Validation Class Initialized
INFO - 2023-05-11 17:22:02 --> Controller Class Initialized
INFO - 2023-05-11 17:22:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-11 17:22:02 --> Final output sent to browser
INFO - 2023-05-11 17:22:04 --> Config Class Initialized
INFO - 2023-05-11 17:22:04 --> Hooks Class Initialized
INFO - 2023-05-11 17:22:04 --> Utf8 Class Initialized
INFO - 2023-05-11 17:22:04 --> URI Class Initialized
INFO - 2023-05-11 17:22:04 --> Router Class Initialized
INFO - 2023-05-11 17:22:04 --> Output Class Initialized
INFO - 2023-05-11 17:22:04 --> Security Class Initialized
INFO - 2023-05-11 17:22:04 --> Input Class Initialized
INFO - 2023-05-11 17:22:04 --> Language Class Initialized
INFO - 2023-05-11 17:22:04 --> Loader Class Initialized
INFO - 2023-05-11 17:22:04 --> Helper loaded: url_helper
INFO - 2023-05-11 17:22:04 --> Helper loaded: form_helper
INFO - 2023-05-11 17:22:04 --> Database Driver Class Initialized
INFO - 2023-05-11 17:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:22:04 --> Form Validation Class Initialized
INFO - 2023-05-11 17:22:04 --> Controller Class Initialized
INFO - 2023-05-11 17:22:04 --> Model "m_user" initialized
INFO - 2023-05-11 17:22:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-11 17:22:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-11 17:22:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-11 17:22:04 --> Final output sent to browser
INFO - 2023-05-11 17:22:22 --> Config Class Initialized
INFO - 2023-05-11 17:22:22 --> Hooks Class Initialized
INFO - 2023-05-11 17:22:22 --> Utf8 Class Initialized
INFO - 2023-05-11 17:22:22 --> URI Class Initialized
INFO - 2023-05-11 17:22:22 --> Router Class Initialized
INFO - 2023-05-11 17:22:22 --> Output Class Initialized
INFO - 2023-05-11 17:22:22 --> Security Class Initialized
INFO - 2023-05-11 17:22:22 --> Input Class Initialized
INFO - 2023-05-11 17:22:22 --> Language Class Initialized
INFO - 2023-05-11 17:22:22 --> Loader Class Initialized
INFO - 2023-05-11 17:22:22 --> Helper loaded: url_helper
INFO - 2023-05-11 17:22:22 --> Helper loaded: form_helper
INFO - 2023-05-11 17:22:22 --> Database Driver Class Initialized
INFO - 2023-05-11 17:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:22:22 --> Form Validation Class Initialized
INFO - 2023-05-11 17:22:22 --> Controller Class Initialized
INFO - 2023-05-11 17:22:22 --> Model "m_user" initialized
INFO - 2023-05-11 17:22:22 --> Config Class Initialized
INFO - 2023-05-11 17:22:22 --> Hooks Class Initialized
INFO - 2023-05-11 17:22:22 --> Utf8 Class Initialized
INFO - 2023-05-11 17:22:22 --> URI Class Initialized
INFO - 2023-05-11 17:22:22 --> Router Class Initialized
INFO - 2023-05-11 17:22:22 --> Output Class Initialized
INFO - 2023-05-11 17:22:22 --> Security Class Initialized
INFO - 2023-05-11 17:22:22 --> Input Class Initialized
INFO - 2023-05-11 17:22:22 --> Language Class Initialized
INFO - 2023-05-11 17:22:22 --> Loader Class Initialized
INFO - 2023-05-11 17:22:22 --> Helper loaded: url_helper
INFO - 2023-05-11 17:22:22 --> Helper loaded: form_helper
INFO - 2023-05-11 17:22:22 --> Database Driver Class Initialized
INFO - 2023-05-11 17:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:22:22 --> Form Validation Class Initialized
INFO - 2023-05-11 17:22:22 --> Controller Class Initialized
INFO - 2023-05-11 17:22:22 --> Model "m_user" initialized
INFO - 2023-05-11 17:22:22 --> Model "m_datatrain" initialized
INFO - 2023-05-11 17:22:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 17:22:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 17:22:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-11 17:22:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 17:22:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 17:22:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-11 17:22:22 --> Final output sent to browser
INFO - 2023-05-11 17:22:26 --> Config Class Initialized
INFO - 2023-05-11 17:22:26 --> Hooks Class Initialized
INFO - 2023-05-11 17:22:26 --> Utf8 Class Initialized
INFO - 2023-05-11 17:22:26 --> URI Class Initialized
INFO - 2023-05-11 17:22:26 --> Router Class Initialized
INFO - 2023-05-11 17:22:26 --> Output Class Initialized
INFO - 2023-05-11 17:22:26 --> Security Class Initialized
INFO - 2023-05-11 17:22:26 --> Input Class Initialized
INFO - 2023-05-11 17:22:26 --> Language Class Initialized
INFO - 2023-05-11 17:22:26 --> Loader Class Initialized
INFO - 2023-05-11 17:22:26 --> Helper loaded: url_helper
INFO - 2023-05-11 17:22:26 --> Helper loaded: form_helper
INFO - 2023-05-11 17:22:26 --> Database Driver Class Initialized
INFO - 2023-05-11 17:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:22:26 --> Form Validation Class Initialized
INFO - 2023-05-11 17:22:26 --> Controller Class Initialized
INFO - 2023-05-11 17:22:26 --> Model "m_datatrain" initialized
INFO - 2023-05-11 17:22:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 17:22:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 17:22:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-11 17:22:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-11 17:22:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 17:22:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 17:22:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-11 17:22:26 --> Final output sent to browser
INFO - 2023-05-11 17:22:30 --> Config Class Initialized
INFO - 2023-05-11 17:22:30 --> Hooks Class Initialized
INFO - 2023-05-11 17:22:30 --> Utf8 Class Initialized
INFO - 2023-05-11 17:22:30 --> URI Class Initialized
INFO - 2023-05-11 17:22:30 --> Router Class Initialized
INFO - 2023-05-11 17:22:30 --> Output Class Initialized
INFO - 2023-05-11 17:22:30 --> Security Class Initialized
INFO - 2023-05-11 17:22:30 --> Input Class Initialized
INFO - 2023-05-11 17:22:30 --> Language Class Initialized
INFO - 2023-05-11 17:22:30 --> Loader Class Initialized
INFO - 2023-05-11 17:22:30 --> Helper loaded: url_helper
INFO - 2023-05-11 17:22:30 --> Helper loaded: form_helper
INFO - 2023-05-11 17:22:30 --> Database Driver Class Initialized
INFO - 2023-05-11 17:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:22:30 --> Form Validation Class Initialized
INFO - 2023-05-11 17:22:30 --> Controller Class Initialized
INFO - 2023-05-11 17:22:30 --> Model "m_user" initialized
INFO - 2023-05-11 17:22:30 --> Config Class Initialized
INFO - 2023-05-11 17:22:30 --> Hooks Class Initialized
INFO - 2023-05-11 17:22:30 --> Utf8 Class Initialized
INFO - 2023-05-11 17:22:30 --> URI Class Initialized
INFO - 2023-05-11 17:22:30 --> Router Class Initialized
INFO - 2023-05-11 17:22:30 --> Output Class Initialized
INFO - 2023-05-11 17:22:30 --> Security Class Initialized
INFO - 2023-05-11 17:22:30 --> Input Class Initialized
INFO - 2023-05-11 17:22:30 --> Language Class Initialized
INFO - 2023-05-11 17:22:30 --> Loader Class Initialized
INFO - 2023-05-11 17:22:30 --> Helper loaded: url_helper
INFO - 2023-05-11 17:22:30 --> Helper loaded: form_helper
INFO - 2023-05-11 17:22:30 --> Database Driver Class Initialized
INFO - 2023-05-11 17:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:22:30 --> Form Validation Class Initialized
INFO - 2023-05-11 17:22:30 --> Controller Class Initialized
INFO - 2023-05-11 17:22:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-11 17:22:30 --> Final output sent to browser
INFO - 2023-05-11 17:44:29 --> Config Class Initialized
INFO - 2023-05-11 17:44:29 --> Hooks Class Initialized
INFO - 2023-05-11 17:44:29 --> Utf8 Class Initialized
INFO - 2023-05-11 17:44:29 --> URI Class Initialized
INFO - 2023-05-11 17:44:29 --> Router Class Initialized
INFO - 2023-05-11 17:44:29 --> Output Class Initialized
INFO - 2023-05-11 17:44:29 --> Security Class Initialized
INFO - 2023-05-11 17:44:29 --> Input Class Initialized
INFO - 2023-05-11 17:44:29 --> Language Class Initialized
INFO - 2023-05-11 17:44:29 --> Loader Class Initialized
INFO - 2023-05-11 17:44:29 --> Helper loaded: url_helper
INFO - 2023-05-11 17:44:29 --> Helper loaded: form_helper
INFO - 2023-05-11 17:44:29 --> Database Driver Class Initialized
INFO - 2023-05-11 17:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:44:29 --> Form Validation Class Initialized
INFO - 2023-05-11 17:44:29 --> Controller Class Initialized
INFO - 2023-05-11 17:44:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-11 17:44:29 --> Final output sent to browser
INFO - 2023-05-11 17:44:31 --> Config Class Initialized
INFO - 2023-05-11 17:44:31 --> Hooks Class Initialized
INFO - 2023-05-11 17:44:31 --> Utf8 Class Initialized
INFO - 2023-05-11 17:44:31 --> URI Class Initialized
INFO - 2023-05-11 17:44:31 --> Router Class Initialized
INFO - 2023-05-11 17:44:31 --> Output Class Initialized
INFO - 2023-05-11 17:44:31 --> Security Class Initialized
INFO - 2023-05-11 17:44:31 --> Input Class Initialized
INFO - 2023-05-11 17:44:31 --> Language Class Initialized
INFO - 2023-05-11 17:44:31 --> Loader Class Initialized
INFO - 2023-05-11 17:44:31 --> Helper loaded: url_helper
INFO - 2023-05-11 17:44:31 --> Helper loaded: form_helper
INFO - 2023-05-11 17:44:31 --> Database Driver Class Initialized
INFO - 2023-05-11 17:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:44:31 --> Form Validation Class Initialized
INFO - 2023-05-11 17:44:31 --> Controller Class Initialized
INFO - 2023-05-11 17:44:31 --> Model "m_user" initialized
INFO - 2023-05-11 17:44:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 17:44:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 17:44:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 17:44:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 17:44:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 17:44:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-11 17:44:31 --> Final output sent to browser
INFO - 2023-05-11 17:44:33 --> Config Class Initialized
INFO - 2023-05-11 17:44:33 --> Hooks Class Initialized
INFO - 2023-05-11 17:44:33 --> Utf8 Class Initialized
INFO - 2023-05-11 17:44:33 --> URI Class Initialized
INFO - 2023-05-11 17:44:33 --> Router Class Initialized
INFO - 2023-05-11 17:44:33 --> Output Class Initialized
INFO - 2023-05-11 17:44:33 --> Security Class Initialized
INFO - 2023-05-11 17:44:33 --> Input Class Initialized
INFO - 2023-05-11 17:44:33 --> Language Class Initialized
INFO - 2023-05-11 17:44:33 --> Loader Class Initialized
INFO - 2023-05-11 17:44:33 --> Helper loaded: url_helper
INFO - 2023-05-11 17:44:33 --> Helper loaded: form_helper
INFO - 2023-05-11 17:44:33 --> Database Driver Class Initialized
INFO - 2023-05-11 17:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:44:33 --> Form Validation Class Initialized
INFO - 2023-05-11 17:44:33 --> Controller Class Initialized
INFO - 2023-05-11 17:44:33 --> Model "m_datatrain" initialized
INFO - 2023-05-11 17:44:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-11 17:44:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-11 17:44:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-11 17:44:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-11 17:44:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-11 17:44:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-11 17:44:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-11 17:44:33 --> Final output sent to browser
INFO - 2023-05-11 17:48:12 --> Config Class Initialized
INFO - 2023-05-11 17:48:12 --> Hooks Class Initialized
INFO - 2023-05-11 17:48:12 --> Utf8 Class Initialized
INFO - 2023-05-11 17:48:12 --> URI Class Initialized
INFO - 2023-05-11 17:48:12 --> Router Class Initialized
INFO - 2023-05-11 17:48:12 --> Output Class Initialized
INFO - 2023-05-11 17:48:12 --> Security Class Initialized
INFO - 2023-05-11 17:48:12 --> Input Class Initialized
INFO - 2023-05-11 17:48:12 --> Language Class Initialized
INFO - 2023-05-11 17:48:12 --> Loader Class Initialized
INFO - 2023-05-11 17:48:12 --> Helper loaded: url_helper
INFO - 2023-05-11 17:48:12 --> Helper loaded: form_helper
INFO - 2023-05-11 17:48:12 --> Database Driver Class Initialized
INFO - 2023-05-11 17:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 17:48:12 --> Form Validation Class Initialized
INFO - 2023-05-11 17:48:12 --> Controller Class Initialized
INFO - 2023-05-11 17:48:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-11 17:48:12 --> Final output sent to browser
