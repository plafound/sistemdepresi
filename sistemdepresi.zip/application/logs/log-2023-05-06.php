<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-06 07:12:10 --> Config Class Initialized
INFO - 2023-05-06 07:12:10 --> Hooks Class Initialized
INFO - 2023-05-06 07:12:10 --> Utf8 Class Initialized
INFO - 2023-05-06 07:12:10 --> URI Class Initialized
INFO - 2023-05-06 07:12:10 --> Router Class Initialized
INFO - 2023-05-06 07:12:10 --> Output Class Initialized
INFO - 2023-05-06 07:12:10 --> Security Class Initialized
INFO - 2023-05-06 07:12:10 --> Input Class Initialized
INFO - 2023-05-06 07:12:10 --> Language Class Initialized
INFO - 2023-05-06 07:12:10 --> Loader Class Initialized
INFO - 2023-05-06 07:12:10 --> Helper loaded: url_helper
INFO - 2023-05-06 07:12:10 --> Helper loaded: form_helper
INFO - 2023-05-06 07:12:10 --> Database Driver Class Initialized
INFO - 2023-05-06 07:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:12:10 --> Form Validation Class Initialized
INFO - 2023-05-06 07:12:10 --> Controller Class Initialized
INFO - 2023-05-06 07:12:10 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:12:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:12:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:12:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:12:10 --> Final output sent to browser
INFO - 2023-05-06 07:12:11 --> Config Class Initialized
INFO - 2023-05-06 07:12:11 --> Hooks Class Initialized
INFO - 2023-05-06 07:12:11 --> Utf8 Class Initialized
INFO - 2023-05-06 07:12:11 --> URI Class Initialized
INFO - 2023-05-06 07:12:11 --> Router Class Initialized
INFO - 2023-05-06 07:12:11 --> Output Class Initialized
INFO - 2023-05-06 07:12:11 --> Security Class Initialized
INFO - 2023-05-06 07:12:11 --> Input Class Initialized
INFO - 2023-05-06 07:12:11 --> Language Class Initialized
INFO - 2023-05-06 07:12:11 --> Loader Class Initialized
INFO - 2023-05-06 07:12:11 --> Helper loaded: url_helper
INFO - 2023-05-06 07:12:11 --> Helper loaded: form_helper
INFO - 2023-05-06 07:12:11 --> Database Driver Class Initialized
INFO - 2023-05-06 07:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:12:11 --> Form Validation Class Initialized
INFO - 2023-05-06 07:12:11 --> Controller Class Initialized
INFO - 2023-05-06 07:12:11 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:12:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:12:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:12:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:12:11 --> Final output sent to browser
INFO - 2023-05-06 07:12:16 --> Config Class Initialized
INFO - 2023-05-06 07:12:16 --> Hooks Class Initialized
INFO - 2023-05-06 07:12:16 --> Utf8 Class Initialized
INFO - 2023-05-06 07:12:16 --> URI Class Initialized
INFO - 2023-05-06 07:12:16 --> Router Class Initialized
INFO - 2023-05-06 07:12:16 --> Output Class Initialized
INFO - 2023-05-06 07:12:16 --> Security Class Initialized
INFO - 2023-05-06 07:12:16 --> Input Class Initialized
INFO - 2023-05-06 07:12:16 --> Language Class Initialized
INFO - 2023-05-06 07:12:16 --> Loader Class Initialized
INFO - 2023-05-06 07:12:16 --> Helper loaded: url_helper
INFO - 2023-05-06 07:12:16 --> Helper loaded: form_helper
INFO - 2023-05-06 07:12:16 --> Database Driver Class Initialized
INFO - 2023-05-06 07:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:12:16 --> Form Validation Class Initialized
INFO - 2023-05-06 07:12:16 --> Controller Class Initialized
INFO - 2023-05-06 07:12:16 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:12:16 --> Config Class Initialized
INFO - 2023-05-06 07:12:16 --> Hooks Class Initialized
INFO - 2023-05-06 07:12:16 --> Utf8 Class Initialized
INFO - 2023-05-06 07:12:16 --> URI Class Initialized
INFO - 2023-05-06 07:12:16 --> Router Class Initialized
INFO - 2023-05-06 07:12:16 --> Output Class Initialized
INFO - 2023-05-06 07:12:16 --> Security Class Initialized
INFO - 2023-05-06 07:12:16 --> Input Class Initialized
INFO - 2023-05-06 07:12:16 --> Language Class Initialized
INFO - 2023-05-06 07:12:16 --> Loader Class Initialized
INFO - 2023-05-06 07:12:16 --> Helper loaded: url_helper
INFO - 2023-05-06 07:12:16 --> Helper loaded: form_helper
INFO - 2023-05-06 07:12:16 --> Database Driver Class Initialized
INFO - 2023-05-06 07:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:12:16 --> Form Validation Class Initialized
INFO - 2023-05-06 07:12:16 --> Controller Class Initialized
INFO - 2023-05-06 07:12:16 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:12:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:12:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:12:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:12:16 --> Final output sent to browser
INFO - 2023-05-06 07:12:22 --> Config Class Initialized
INFO - 2023-05-06 07:12:22 --> Hooks Class Initialized
INFO - 2023-05-06 07:12:22 --> Utf8 Class Initialized
INFO - 2023-05-06 07:12:22 --> URI Class Initialized
INFO - 2023-05-06 07:12:22 --> Router Class Initialized
INFO - 2023-05-06 07:12:22 --> Output Class Initialized
INFO - 2023-05-06 07:12:22 --> Security Class Initialized
INFO - 2023-05-06 07:12:22 --> Input Class Initialized
INFO - 2023-05-06 07:12:22 --> Language Class Initialized
INFO - 2023-05-06 07:12:22 --> Loader Class Initialized
INFO - 2023-05-06 07:12:22 --> Helper loaded: url_helper
INFO - 2023-05-06 07:12:22 --> Helper loaded: form_helper
INFO - 2023-05-06 07:12:22 --> Database Driver Class Initialized
INFO - 2023-05-06 07:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:12:22 --> Form Validation Class Initialized
INFO - 2023-05-06 07:12:22 --> Controller Class Initialized
INFO - 2023-05-06 07:12:22 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:12:22 --> Config Class Initialized
INFO - 2023-05-06 07:12:22 --> Hooks Class Initialized
INFO - 2023-05-06 07:12:22 --> Utf8 Class Initialized
INFO - 2023-05-06 07:12:22 --> URI Class Initialized
INFO - 2023-05-06 07:12:22 --> Router Class Initialized
INFO - 2023-05-06 07:12:22 --> Output Class Initialized
INFO - 2023-05-06 07:12:22 --> Security Class Initialized
INFO - 2023-05-06 07:12:22 --> Input Class Initialized
INFO - 2023-05-06 07:12:22 --> Language Class Initialized
INFO - 2023-05-06 07:12:22 --> Loader Class Initialized
INFO - 2023-05-06 07:12:22 --> Helper loaded: url_helper
INFO - 2023-05-06 07:12:22 --> Helper loaded: form_helper
INFO - 2023-05-06 07:12:22 --> Database Driver Class Initialized
INFO - 2023-05-06 07:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:12:22 --> Form Validation Class Initialized
INFO - 2023-05-06 07:12:22 --> Controller Class Initialized
INFO - 2023-05-06 07:12:22 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:12:22 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:12:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:12:22 --> Final output sent to browser
INFO - 2023-05-06 07:12:34 --> Config Class Initialized
INFO - 2023-05-06 07:12:34 --> Hooks Class Initialized
INFO - 2023-05-06 07:12:34 --> Utf8 Class Initialized
INFO - 2023-05-06 07:12:34 --> URI Class Initialized
INFO - 2023-05-06 07:12:34 --> Router Class Initialized
INFO - 2023-05-06 07:12:34 --> Output Class Initialized
INFO - 2023-05-06 07:12:34 --> Security Class Initialized
INFO - 2023-05-06 07:12:34 --> Input Class Initialized
INFO - 2023-05-06 07:12:34 --> Language Class Initialized
INFO - 2023-05-06 07:12:34 --> Loader Class Initialized
INFO - 2023-05-06 07:12:34 --> Helper loaded: url_helper
INFO - 2023-05-06 07:12:34 --> Helper loaded: form_helper
INFO - 2023-05-06 07:12:34 --> Database Driver Class Initialized
INFO - 2023-05-06 07:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:12:34 --> Form Validation Class Initialized
INFO - 2023-05-06 07:12:34 --> Controller Class Initialized
INFO - 2023-05-06 07:12:34 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:12:34 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:12:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:12:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:12:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:12:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:12:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:12:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:12:34 --> Final output sent to browser
INFO - 2023-05-06 07:15:31 --> Config Class Initialized
INFO - 2023-05-06 07:15:31 --> Hooks Class Initialized
INFO - 2023-05-06 07:15:31 --> Utf8 Class Initialized
INFO - 2023-05-06 07:15:31 --> URI Class Initialized
INFO - 2023-05-06 07:15:31 --> Router Class Initialized
INFO - 2023-05-06 07:15:31 --> Output Class Initialized
INFO - 2023-05-06 07:15:31 --> Security Class Initialized
INFO - 2023-05-06 07:15:31 --> Input Class Initialized
INFO - 2023-05-06 07:15:31 --> Language Class Initialized
INFO - 2023-05-06 07:15:31 --> Loader Class Initialized
INFO - 2023-05-06 07:15:31 --> Helper loaded: url_helper
INFO - 2023-05-06 07:15:31 --> Helper loaded: form_helper
INFO - 2023-05-06 07:15:31 --> Database Driver Class Initialized
INFO - 2023-05-06 07:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:15:31 --> Form Validation Class Initialized
INFO - 2023-05-06 07:15:31 --> Controller Class Initialized
INFO - 2023-05-06 07:15:31 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:15:31 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:15:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:15:31 --> Final output sent to browser
INFO - 2023-05-06 07:18:02 --> Config Class Initialized
INFO - 2023-05-06 07:18:02 --> Hooks Class Initialized
INFO - 2023-05-06 07:18:02 --> Utf8 Class Initialized
INFO - 2023-05-06 07:18:02 --> URI Class Initialized
INFO - 2023-05-06 07:18:02 --> Router Class Initialized
INFO - 2023-05-06 07:18:02 --> Output Class Initialized
INFO - 2023-05-06 07:18:02 --> Security Class Initialized
INFO - 2023-05-06 07:18:02 --> Input Class Initialized
INFO - 2023-05-06 07:18:02 --> Language Class Initialized
INFO - 2023-05-06 07:18:02 --> Loader Class Initialized
INFO - 2023-05-06 07:18:02 --> Helper loaded: url_helper
INFO - 2023-05-06 07:18:02 --> Helper loaded: form_helper
INFO - 2023-05-06 07:18:02 --> Database Driver Class Initialized
INFO - 2023-05-06 07:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:18:02 --> Form Validation Class Initialized
INFO - 2023-05-06 07:18:02 --> Controller Class Initialized
INFO - 2023-05-06 07:18:02 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:18:02 --> Config Class Initialized
INFO - 2023-05-06 07:18:02 --> Hooks Class Initialized
INFO - 2023-05-06 07:18:02 --> Utf8 Class Initialized
INFO - 2023-05-06 07:18:02 --> URI Class Initialized
INFO - 2023-05-06 07:18:02 --> Router Class Initialized
INFO - 2023-05-06 07:18:02 --> Output Class Initialized
INFO - 2023-05-06 07:18:02 --> Security Class Initialized
INFO - 2023-05-06 07:18:02 --> Input Class Initialized
INFO - 2023-05-06 07:18:02 --> Language Class Initialized
INFO - 2023-05-06 07:18:02 --> Loader Class Initialized
INFO - 2023-05-06 07:18:02 --> Helper loaded: url_helper
INFO - 2023-05-06 07:18:02 --> Helper loaded: form_helper
INFO - 2023-05-06 07:18:02 --> Database Driver Class Initialized
INFO - 2023-05-06 07:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:18:02 --> Form Validation Class Initialized
INFO - 2023-05-06 07:18:02 --> Controller Class Initialized
INFO - 2023-05-06 07:18:02 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:18:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:18:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:18:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:18:02 --> Final output sent to browser
INFO - 2023-05-06 07:18:06 --> Config Class Initialized
INFO - 2023-05-06 07:18:06 --> Hooks Class Initialized
INFO - 2023-05-06 07:18:06 --> Utf8 Class Initialized
INFO - 2023-05-06 07:18:06 --> URI Class Initialized
INFO - 2023-05-06 07:18:06 --> Router Class Initialized
INFO - 2023-05-06 07:18:06 --> Output Class Initialized
INFO - 2023-05-06 07:18:06 --> Security Class Initialized
INFO - 2023-05-06 07:18:06 --> Input Class Initialized
INFO - 2023-05-06 07:18:06 --> Language Class Initialized
INFO - 2023-05-06 07:18:06 --> Loader Class Initialized
INFO - 2023-05-06 07:18:06 --> Helper loaded: url_helper
INFO - 2023-05-06 07:18:06 --> Helper loaded: form_helper
INFO - 2023-05-06 07:18:06 --> Database Driver Class Initialized
INFO - 2023-05-06 07:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:18:06 --> Form Validation Class Initialized
INFO - 2023-05-06 07:18:06 --> Controller Class Initialized
INFO - 2023-05-06 07:18:06 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:18:06 --> Config Class Initialized
INFO - 2023-05-06 07:18:06 --> Hooks Class Initialized
INFO - 2023-05-06 07:18:06 --> Utf8 Class Initialized
INFO - 2023-05-06 07:18:06 --> URI Class Initialized
INFO - 2023-05-06 07:18:06 --> Router Class Initialized
INFO - 2023-05-06 07:18:06 --> Output Class Initialized
INFO - 2023-05-06 07:18:06 --> Security Class Initialized
INFO - 2023-05-06 07:18:06 --> Input Class Initialized
INFO - 2023-05-06 07:18:06 --> Language Class Initialized
INFO - 2023-05-06 07:18:06 --> Loader Class Initialized
INFO - 2023-05-06 07:18:06 --> Helper loaded: url_helper
INFO - 2023-05-06 07:18:06 --> Helper loaded: form_helper
INFO - 2023-05-06 07:18:06 --> Database Driver Class Initialized
INFO - 2023-05-06 07:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:18:06 --> Form Validation Class Initialized
INFO - 2023-05-06 07:18:06 --> Controller Class Initialized
INFO - 2023-05-06 07:18:06 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:18:06 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:18:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:18:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:18:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:18:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:18:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:18:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:18:06 --> Final output sent to browser
INFO - 2023-05-06 07:18:11 --> Config Class Initialized
INFO - 2023-05-06 07:18:11 --> Hooks Class Initialized
INFO - 2023-05-06 07:18:11 --> Utf8 Class Initialized
INFO - 2023-05-06 07:18:11 --> URI Class Initialized
INFO - 2023-05-06 07:18:11 --> Router Class Initialized
INFO - 2023-05-06 07:18:11 --> Output Class Initialized
INFO - 2023-05-06 07:18:11 --> Security Class Initialized
INFO - 2023-05-06 07:18:11 --> Input Class Initialized
INFO - 2023-05-06 07:18:11 --> Language Class Initialized
INFO - 2023-05-06 07:18:11 --> Loader Class Initialized
INFO - 2023-05-06 07:18:11 --> Helper loaded: url_helper
INFO - 2023-05-06 07:18:11 --> Helper loaded: form_helper
INFO - 2023-05-06 07:18:11 --> Database Driver Class Initialized
INFO - 2023-05-06 07:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:18:11 --> Form Validation Class Initialized
INFO - 2023-05-06 07:18:11 --> Controller Class Initialized
INFO - 2023-05-06 07:18:11 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:18:11 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:18:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:18:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:18:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:18:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:18:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:18:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:18:11 --> Final output sent to browser
INFO - 2023-05-06 07:18:17 --> Config Class Initialized
INFO - 2023-05-06 07:18:17 --> Hooks Class Initialized
INFO - 2023-05-06 07:18:17 --> Utf8 Class Initialized
INFO - 2023-05-06 07:18:17 --> URI Class Initialized
INFO - 2023-05-06 07:18:17 --> Router Class Initialized
INFO - 2023-05-06 07:18:17 --> Output Class Initialized
INFO - 2023-05-06 07:18:17 --> Security Class Initialized
INFO - 2023-05-06 07:18:17 --> Input Class Initialized
INFO - 2023-05-06 07:18:17 --> Language Class Initialized
INFO - 2023-05-06 07:18:17 --> Loader Class Initialized
INFO - 2023-05-06 07:18:17 --> Helper loaded: url_helper
INFO - 2023-05-06 07:18:17 --> Helper loaded: form_helper
INFO - 2023-05-06 07:18:17 --> Database Driver Class Initialized
INFO - 2023-05-06 07:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:18:17 --> Form Validation Class Initialized
INFO - 2023-05-06 07:18:17 --> Controller Class Initialized
INFO - 2023-05-06 07:18:17 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:18:17 --> Config Class Initialized
INFO - 2023-05-06 07:18:17 --> Hooks Class Initialized
INFO - 2023-05-06 07:18:17 --> Utf8 Class Initialized
INFO - 2023-05-06 07:18:17 --> URI Class Initialized
INFO - 2023-05-06 07:18:17 --> Router Class Initialized
INFO - 2023-05-06 07:18:17 --> Output Class Initialized
INFO - 2023-05-06 07:18:17 --> Security Class Initialized
INFO - 2023-05-06 07:18:17 --> Input Class Initialized
INFO - 2023-05-06 07:18:17 --> Language Class Initialized
INFO - 2023-05-06 07:18:17 --> Loader Class Initialized
INFO - 2023-05-06 07:18:17 --> Helper loaded: url_helper
INFO - 2023-05-06 07:18:17 --> Helper loaded: form_helper
INFO - 2023-05-06 07:18:17 --> Database Driver Class Initialized
INFO - 2023-05-06 07:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:18:17 --> Form Validation Class Initialized
INFO - 2023-05-06 07:18:17 --> Controller Class Initialized
INFO - 2023-05-06 07:18:17 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:18:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:18:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:18:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:18:17 --> Final output sent to browser
INFO - 2023-05-06 07:23:03 --> Config Class Initialized
INFO - 2023-05-06 07:23:03 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:03 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:03 --> URI Class Initialized
INFO - 2023-05-06 07:23:03 --> Router Class Initialized
INFO - 2023-05-06 07:23:03 --> Output Class Initialized
INFO - 2023-05-06 07:23:03 --> Security Class Initialized
INFO - 2023-05-06 07:23:03 --> Input Class Initialized
INFO - 2023-05-06 07:23:03 --> Language Class Initialized
INFO - 2023-05-06 07:23:03 --> Loader Class Initialized
INFO - 2023-05-06 07:23:03 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:03 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:03 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:03 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:03 --> Controller Class Initialized
INFO - 2023-05-06 07:23:03 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:03 --> Config Class Initialized
INFO - 2023-05-06 07:23:03 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:03 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:03 --> URI Class Initialized
INFO - 2023-05-06 07:23:03 --> Router Class Initialized
INFO - 2023-05-06 07:23:03 --> Output Class Initialized
INFO - 2023-05-06 07:23:03 --> Security Class Initialized
INFO - 2023-05-06 07:23:03 --> Input Class Initialized
INFO - 2023-05-06 07:23:03 --> Language Class Initialized
INFO - 2023-05-06 07:23:03 --> Loader Class Initialized
INFO - 2023-05-06 07:23:03 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:03 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:03 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:03 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:03 --> Controller Class Initialized
INFO - 2023-05-06 07:23:03 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:03 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:23:04 --> Final output sent to browser
INFO - 2023-05-06 07:23:10 --> Config Class Initialized
INFO - 2023-05-06 07:23:10 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:10 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:10 --> URI Class Initialized
INFO - 2023-05-06 07:23:10 --> Router Class Initialized
INFO - 2023-05-06 07:23:10 --> Output Class Initialized
INFO - 2023-05-06 07:23:10 --> Security Class Initialized
INFO - 2023-05-06 07:23:10 --> Input Class Initialized
INFO - 2023-05-06 07:23:10 --> Language Class Initialized
INFO - 2023-05-06 07:23:10 --> Loader Class Initialized
INFO - 2023-05-06 07:23:10 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:10 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:10 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:10 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:10 --> Controller Class Initialized
INFO - 2023-05-06 07:23:10 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:10 --> Config Class Initialized
INFO - 2023-05-06 07:23:10 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:10 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:10 --> URI Class Initialized
INFO - 2023-05-06 07:23:10 --> Router Class Initialized
INFO - 2023-05-06 07:23:10 --> Output Class Initialized
INFO - 2023-05-06 07:23:10 --> Security Class Initialized
INFO - 2023-05-06 07:23:10 --> Input Class Initialized
INFO - 2023-05-06 07:23:10 --> Language Class Initialized
INFO - 2023-05-06 07:23:10 --> Loader Class Initialized
INFO - 2023-05-06 07:23:10 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:10 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:10 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:10 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:10 --> Controller Class Initialized
INFO - 2023-05-06 07:23:10 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:23:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:23:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:23:10 --> Final output sent to browser
INFO - 2023-05-06 07:23:16 --> Config Class Initialized
INFO - 2023-05-06 07:23:16 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:16 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:16 --> URI Class Initialized
INFO - 2023-05-06 07:23:16 --> Router Class Initialized
INFO - 2023-05-06 07:23:16 --> Output Class Initialized
INFO - 2023-05-06 07:23:16 --> Security Class Initialized
INFO - 2023-05-06 07:23:16 --> Input Class Initialized
INFO - 2023-05-06 07:23:16 --> Language Class Initialized
INFO - 2023-05-06 07:23:16 --> Loader Class Initialized
INFO - 2023-05-06 07:23:16 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:16 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:16 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:16 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:16 --> Controller Class Initialized
INFO - 2023-05-06 07:23:16 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:23:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:23:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:23:16 --> Final output sent to browser
INFO - 2023-05-06 07:23:17 --> Config Class Initialized
INFO - 2023-05-06 07:23:17 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:17 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:17 --> URI Class Initialized
INFO - 2023-05-06 07:23:17 --> Router Class Initialized
INFO - 2023-05-06 07:23:17 --> Output Class Initialized
INFO - 2023-05-06 07:23:17 --> Security Class Initialized
INFO - 2023-05-06 07:23:17 --> Input Class Initialized
INFO - 2023-05-06 07:23:17 --> Language Class Initialized
INFO - 2023-05-06 07:23:17 --> Loader Class Initialized
INFO - 2023-05-06 07:23:17 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:17 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:17 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:17 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:17 --> Controller Class Initialized
INFO - 2023-05-06 07:23:17 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:23:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:23:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:23:17 --> Final output sent to browser
INFO - 2023-05-06 07:23:21 --> Config Class Initialized
INFO - 2023-05-06 07:23:21 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:21 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:21 --> URI Class Initialized
INFO - 2023-05-06 07:23:21 --> Router Class Initialized
INFO - 2023-05-06 07:23:21 --> Output Class Initialized
INFO - 2023-05-06 07:23:21 --> Security Class Initialized
INFO - 2023-05-06 07:23:21 --> Input Class Initialized
INFO - 2023-05-06 07:23:21 --> Language Class Initialized
INFO - 2023-05-06 07:23:21 --> Loader Class Initialized
INFO - 2023-05-06 07:23:21 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:21 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:21 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:21 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:21 --> Controller Class Initialized
INFO - 2023-05-06 07:23:21 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:21 --> Config Class Initialized
INFO - 2023-05-06 07:23:21 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:21 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:21 --> URI Class Initialized
INFO - 2023-05-06 07:23:21 --> Router Class Initialized
INFO - 2023-05-06 07:23:21 --> Output Class Initialized
INFO - 2023-05-06 07:23:21 --> Security Class Initialized
INFO - 2023-05-06 07:23:21 --> Input Class Initialized
INFO - 2023-05-06 07:23:21 --> Language Class Initialized
INFO - 2023-05-06 07:23:21 --> Loader Class Initialized
INFO - 2023-05-06 07:23:21 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:21 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:21 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:21 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:21 --> Controller Class Initialized
INFO - 2023-05-06 07:23:21 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:21 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:23:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:23:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:23:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:23:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:23:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:23:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:23:21 --> Final output sent to browser
INFO - 2023-05-06 07:23:34 --> Config Class Initialized
INFO - 2023-05-06 07:23:34 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:34 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:34 --> URI Class Initialized
INFO - 2023-05-06 07:23:34 --> Router Class Initialized
INFO - 2023-05-06 07:23:34 --> Output Class Initialized
INFO - 2023-05-06 07:23:34 --> Security Class Initialized
INFO - 2023-05-06 07:23:34 --> Input Class Initialized
INFO - 2023-05-06 07:23:34 --> Language Class Initialized
INFO - 2023-05-06 07:23:34 --> Loader Class Initialized
INFO - 2023-05-06 07:23:34 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:34 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:34 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:34 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:34 --> Controller Class Initialized
INFO - 2023-05-06 07:23:34 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:35 --> Config Class Initialized
INFO - 2023-05-06 07:23:35 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:35 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:35 --> URI Class Initialized
INFO - 2023-05-06 07:23:35 --> Router Class Initialized
INFO - 2023-05-06 07:23:35 --> Output Class Initialized
INFO - 2023-05-06 07:23:35 --> Security Class Initialized
INFO - 2023-05-06 07:23:35 --> Input Class Initialized
INFO - 2023-05-06 07:23:35 --> Language Class Initialized
INFO - 2023-05-06 07:23:35 --> Loader Class Initialized
INFO - 2023-05-06 07:23:35 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:35 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:35 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:35 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:35 --> Controller Class Initialized
INFO - 2023-05-06 07:23:35 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:23:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:23:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:23:35 --> Final output sent to browser
INFO - 2023-05-06 07:23:39 --> Config Class Initialized
INFO - 2023-05-06 07:23:39 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:39 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:39 --> URI Class Initialized
INFO - 2023-05-06 07:23:39 --> Router Class Initialized
INFO - 2023-05-06 07:23:39 --> Output Class Initialized
INFO - 2023-05-06 07:23:39 --> Security Class Initialized
INFO - 2023-05-06 07:23:39 --> Input Class Initialized
INFO - 2023-05-06 07:23:39 --> Language Class Initialized
INFO - 2023-05-06 07:23:39 --> Loader Class Initialized
INFO - 2023-05-06 07:23:39 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:39 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:39 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:39 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:39 --> Controller Class Initialized
INFO - 2023-05-06 07:23:39 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:39 --> Config Class Initialized
INFO - 2023-05-06 07:23:39 --> Hooks Class Initialized
INFO - 2023-05-06 07:23:39 --> Utf8 Class Initialized
INFO - 2023-05-06 07:23:39 --> URI Class Initialized
INFO - 2023-05-06 07:23:39 --> Router Class Initialized
INFO - 2023-05-06 07:23:39 --> Output Class Initialized
INFO - 2023-05-06 07:23:39 --> Security Class Initialized
INFO - 2023-05-06 07:23:39 --> Input Class Initialized
INFO - 2023-05-06 07:23:39 --> Language Class Initialized
INFO - 2023-05-06 07:23:39 --> Loader Class Initialized
INFO - 2023-05-06 07:23:39 --> Helper loaded: url_helper
INFO - 2023-05-06 07:23:39 --> Helper loaded: form_helper
INFO - 2023-05-06 07:23:39 --> Database Driver Class Initialized
INFO - 2023-05-06 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:23:39 --> Form Validation Class Initialized
INFO - 2023-05-06 07:23:39 --> Controller Class Initialized
INFO - 2023-05-06 07:23:39 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:23:39 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:23:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:23:39 --> Final output sent to browser
INFO - 2023-05-06 07:26:35 --> Config Class Initialized
INFO - 2023-05-06 07:26:35 --> Hooks Class Initialized
INFO - 2023-05-06 07:26:35 --> Utf8 Class Initialized
INFO - 2023-05-06 07:26:35 --> URI Class Initialized
INFO - 2023-05-06 07:26:35 --> Router Class Initialized
INFO - 2023-05-06 07:26:35 --> Output Class Initialized
INFO - 2023-05-06 07:26:35 --> Security Class Initialized
INFO - 2023-05-06 07:26:35 --> Input Class Initialized
INFO - 2023-05-06 07:26:35 --> Language Class Initialized
INFO - 2023-05-06 07:26:35 --> Loader Class Initialized
INFO - 2023-05-06 07:26:35 --> Helper loaded: url_helper
INFO - 2023-05-06 07:26:35 --> Helper loaded: form_helper
INFO - 2023-05-06 07:26:35 --> Database Driver Class Initialized
INFO - 2023-05-06 07:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:26:35 --> Form Validation Class Initialized
INFO - 2023-05-06 07:26:35 --> Controller Class Initialized
INFO - 2023-05-06 07:26:35 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:26:35 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:26:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:26:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:26:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:26:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:26:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:26:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:26:35 --> Final output sent to browser
INFO - 2023-05-06 07:26:38 --> Config Class Initialized
INFO - 2023-05-06 07:26:38 --> Hooks Class Initialized
INFO - 2023-05-06 07:26:38 --> Utf8 Class Initialized
INFO - 2023-05-06 07:26:38 --> URI Class Initialized
INFO - 2023-05-06 07:26:38 --> Router Class Initialized
INFO - 2023-05-06 07:26:38 --> Output Class Initialized
INFO - 2023-05-06 07:26:38 --> Security Class Initialized
INFO - 2023-05-06 07:26:38 --> Input Class Initialized
INFO - 2023-05-06 07:26:38 --> Language Class Initialized
INFO - 2023-05-06 07:26:38 --> Loader Class Initialized
INFO - 2023-05-06 07:26:38 --> Helper loaded: url_helper
INFO - 2023-05-06 07:26:38 --> Helper loaded: form_helper
INFO - 2023-05-06 07:26:38 --> Database Driver Class Initialized
INFO - 2023-05-06 07:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:26:38 --> Form Validation Class Initialized
INFO - 2023-05-06 07:26:38 --> Controller Class Initialized
INFO - 2023-05-06 07:26:38 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:26:38 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:26:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:26:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:26:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:26:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:26:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:26:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:26:38 --> Final output sent to browser
INFO - 2023-05-06 07:26:55 --> Config Class Initialized
INFO - 2023-05-06 07:26:55 --> Hooks Class Initialized
INFO - 2023-05-06 07:26:55 --> Utf8 Class Initialized
INFO - 2023-05-06 07:26:55 --> URI Class Initialized
INFO - 2023-05-06 07:26:55 --> Router Class Initialized
INFO - 2023-05-06 07:26:55 --> Output Class Initialized
INFO - 2023-05-06 07:26:55 --> Security Class Initialized
INFO - 2023-05-06 07:26:55 --> Input Class Initialized
INFO - 2023-05-06 07:26:55 --> Language Class Initialized
INFO - 2023-05-06 07:26:55 --> Loader Class Initialized
INFO - 2023-05-06 07:26:55 --> Helper loaded: url_helper
INFO - 2023-05-06 07:26:55 --> Helper loaded: form_helper
INFO - 2023-05-06 07:26:55 --> Database Driver Class Initialized
INFO - 2023-05-06 07:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:26:55 --> Form Validation Class Initialized
INFO - 2023-05-06 07:26:55 --> Controller Class Initialized
INFO - 2023-05-06 07:26:55 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:26:55 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:26:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:26:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:26:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:26:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:26:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:26:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:26:55 --> Final output sent to browser
INFO - 2023-05-06 07:26:56 --> Config Class Initialized
INFO - 2023-05-06 07:26:56 --> Hooks Class Initialized
INFO - 2023-05-06 07:26:56 --> Utf8 Class Initialized
INFO - 2023-05-06 07:26:56 --> URI Class Initialized
INFO - 2023-05-06 07:26:56 --> Router Class Initialized
INFO - 2023-05-06 07:26:56 --> Output Class Initialized
INFO - 2023-05-06 07:26:56 --> Security Class Initialized
INFO - 2023-05-06 07:26:56 --> Input Class Initialized
INFO - 2023-05-06 07:26:56 --> Language Class Initialized
INFO - 2023-05-06 07:26:56 --> Loader Class Initialized
INFO - 2023-05-06 07:26:56 --> Helper loaded: url_helper
INFO - 2023-05-06 07:26:56 --> Helper loaded: form_helper
INFO - 2023-05-06 07:26:56 --> Database Driver Class Initialized
INFO - 2023-05-06 07:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:26:56 --> Form Validation Class Initialized
INFO - 2023-05-06 07:26:56 --> Controller Class Initialized
INFO - 2023-05-06 07:26:56 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:26:56 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:26:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:26:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:26:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:26:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:26:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:26:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:26:56 --> Final output sent to browser
INFO - 2023-05-06 07:26:57 --> Config Class Initialized
INFO - 2023-05-06 07:26:57 --> Hooks Class Initialized
INFO - 2023-05-06 07:26:57 --> Utf8 Class Initialized
INFO - 2023-05-06 07:26:57 --> URI Class Initialized
INFO - 2023-05-06 07:26:57 --> Router Class Initialized
INFO - 2023-05-06 07:26:57 --> Output Class Initialized
INFO - 2023-05-06 07:26:57 --> Security Class Initialized
INFO - 2023-05-06 07:26:57 --> Input Class Initialized
INFO - 2023-05-06 07:26:57 --> Language Class Initialized
INFO - 2023-05-06 07:26:57 --> Loader Class Initialized
INFO - 2023-05-06 07:26:57 --> Helper loaded: url_helper
INFO - 2023-05-06 07:26:57 --> Helper loaded: form_helper
INFO - 2023-05-06 07:26:57 --> Database Driver Class Initialized
INFO - 2023-05-06 07:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:26:57 --> Form Validation Class Initialized
INFO - 2023-05-06 07:26:57 --> Controller Class Initialized
INFO - 2023-05-06 07:26:57 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:26:57 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:26:57 --> Final output sent to browser
INFO - 2023-05-06 07:26:58 --> Config Class Initialized
INFO - 2023-05-06 07:26:58 --> Hooks Class Initialized
INFO - 2023-05-06 07:26:58 --> Utf8 Class Initialized
INFO - 2023-05-06 07:26:58 --> URI Class Initialized
INFO - 2023-05-06 07:26:58 --> Router Class Initialized
INFO - 2023-05-06 07:26:58 --> Output Class Initialized
INFO - 2023-05-06 07:26:58 --> Security Class Initialized
INFO - 2023-05-06 07:26:58 --> Input Class Initialized
INFO - 2023-05-06 07:26:58 --> Language Class Initialized
INFO - 2023-05-06 07:26:58 --> Loader Class Initialized
INFO - 2023-05-06 07:26:58 --> Helper loaded: url_helper
INFO - 2023-05-06 07:26:58 --> Helper loaded: form_helper
INFO - 2023-05-06 07:26:58 --> Database Driver Class Initialized
INFO - 2023-05-06 07:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:26:58 --> Form Validation Class Initialized
INFO - 2023-05-06 07:26:58 --> Controller Class Initialized
INFO - 2023-05-06 07:26:58 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:26:58 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:26:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:26:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:26:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:26:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:26:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:26:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:26:58 --> Final output sent to browser
INFO - 2023-05-06 07:27:02 --> Config Class Initialized
INFO - 2023-05-06 07:27:02 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:02 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:02 --> URI Class Initialized
INFO - 2023-05-06 07:27:02 --> Router Class Initialized
INFO - 2023-05-06 07:27:02 --> Output Class Initialized
INFO - 2023-05-06 07:27:02 --> Security Class Initialized
INFO - 2023-05-06 07:27:02 --> Input Class Initialized
INFO - 2023-05-06 07:27:02 --> Language Class Initialized
INFO - 2023-05-06 07:27:02 --> Loader Class Initialized
INFO - 2023-05-06 07:27:02 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:02 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:02 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:02 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:02 --> Controller Class Initialized
INFO - 2023-05-06 07:27:02 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:02 --> Config Class Initialized
INFO - 2023-05-06 07:27:02 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:02 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:02 --> URI Class Initialized
INFO - 2023-05-06 07:27:02 --> Router Class Initialized
INFO - 2023-05-06 07:27:02 --> Output Class Initialized
INFO - 2023-05-06 07:27:02 --> Security Class Initialized
INFO - 2023-05-06 07:27:02 --> Input Class Initialized
INFO - 2023-05-06 07:27:02 --> Language Class Initialized
INFO - 2023-05-06 07:27:02 --> Loader Class Initialized
INFO - 2023-05-06 07:27:02 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:02 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:02 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:02 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:02 --> Controller Class Initialized
INFO - 2023-05-06 07:27:02 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:27:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:27:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:27:02 --> Final output sent to browser
INFO - 2023-05-06 07:27:06 --> Config Class Initialized
INFO - 2023-05-06 07:27:06 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:06 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:06 --> URI Class Initialized
INFO - 2023-05-06 07:27:06 --> Router Class Initialized
INFO - 2023-05-06 07:27:06 --> Output Class Initialized
INFO - 2023-05-06 07:27:06 --> Security Class Initialized
INFO - 2023-05-06 07:27:06 --> Input Class Initialized
INFO - 2023-05-06 07:27:06 --> Language Class Initialized
INFO - 2023-05-06 07:27:06 --> Loader Class Initialized
INFO - 2023-05-06 07:27:06 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:06 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:06 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:07 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:07 --> Controller Class Initialized
INFO - 2023-05-06 07:27:07 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:07 --> Config Class Initialized
INFO - 2023-05-06 07:27:07 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:07 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:07 --> URI Class Initialized
INFO - 2023-05-06 07:27:07 --> Router Class Initialized
INFO - 2023-05-06 07:27:07 --> Output Class Initialized
INFO - 2023-05-06 07:27:07 --> Security Class Initialized
INFO - 2023-05-06 07:27:07 --> Input Class Initialized
INFO - 2023-05-06 07:27:07 --> Language Class Initialized
INFO - 2023-05-06 07:27:07 --> Loader Class Initialized
INFO - 2023-05-06 07:27:07 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:07 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:07 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:07 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:07 --> Controller Class Initialized
INFO - 2023-05-06 07:27:07 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:27:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:27:07 --> Final output sent to browser
INFO - 2023-05-06 07:27:14 --> Config Class Initialized
INFO - 2023-05-06 07:27:14 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:14 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:14 --> URI Class Initialized
INFO - 2023-05-06 07:27:14 --> Router Class Initialized
INFO - 2023-05-06 07:27:14 --> Output Class Initialized
INFO - 2023-05-06 07:27:14 --> Security Class Initialized
INFO - 2023-05-06 07:27:14 --> Input Class Initialized
INFO - 2023-05-06 07:27:14 --> Language Class Initialized
INFO - 2023-05-06 07:27:14 --> Loader Class Initialized
INFO - 2023-05-06 07:27:14 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:14 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:14 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:14 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:14 --> Controller Class Initialized
INFO - 2023-05-06 07:27:14 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:14 --> Config Class Initialized
INFO - 2023-05-06 07:27:14 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:14 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:14 --> URI Class Initialized
INFO - 2023-05-06 07:27:14 --> Router Class Initialized
INFO - 2023-05-06 07:27:14 --> Output Class Initialized
INFO - 2023-05-06 07:27:14 --> Security Class Initialized
INFO - 2023-05-06 07:27:14 --> Input Class Initialized
INFO - 2023-05-06 07:27:14 --> Language Class Initialized
INFO - 2023-05-06 07:27:14 --> Loader Class Initialized
INFO - 2023-05-06 07:27:14 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:14 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:14 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:14 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:14 --> Controller Class Initialized
INFO - 2023-05-06 07:27:14 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:14 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:27:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:27:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:27:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:27:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:27:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:27:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:27:14 --> Final output sent to browser
INFO - 2023-05-06 07:27:18 --> Config Class Initialized
INFO - 2023-05-06 07:27:18 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:18 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:18 --> URI Class Initialized
INFO - 2023-05-06 07:27:18 --> Router Class Initialized
INFO - 2023-05-06 07:27:18 --> Output Class Initialized
INFO - 2023-05-06 07:27:18 --> Security Class Initialized
INFO - 2023-05-06 07:27:18 --> Input Class Initialized
INFO - 2023-05-06 07:27:18 --> Language Class Initialized
INFO - 2023-05-06 07:27:18 --> Loader Class Initialized
INFO - 2023-05-06 07:27:18 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:18 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:18 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:18 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:18 --> Controller Class Initialized
INFO - 2023-05-06 07:27:18 --> Model "M_todo_group" initialized
INFO - 2023-05-06 07:27:18 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:27:18 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:27:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:27:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_group/v_index.php
INFO - 2023-05-06 07:27:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:27:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:27:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:27:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 07:27:18 --> Final output sent to browser
INFO - 2023-05-06 07:27:32 --> Config Class Initialized
INFO - 2023-05-06 07:27:32 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:32 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:32 --> URI Class Initialized
INFO - 2023-05-06 07:27:32 --> Router Class Initialized
INFO - 2023-05-06 07:27:32 --> Output Class Initialized
INFO - 2023-05-06 07:27:32 --> Security Class Initialized
INFO - 2023-05-06 07:27:32 --> Input Class Initialized
INFO - 2023-05-06 07:27:32 --> Language Class Initialized
INFO - 2023-05-06 07:27:32 --> Loader Class Initialized
INFO - 2023-05-06 07:27:32 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:32 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:32 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:32 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:32 --> Controller Class Initialized
INFO - 2023-05-06 07:27:32 --> Model "M_todo_group" initialized
INFO - 2023-05-06 07:27:32 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:27:32 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:27:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:27:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_group/v_index.php
INFO - 2023-05-06 07:27:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:27:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:27:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:27:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 07:27:32 --> Final output sent to browser
INFO - 2023-05-06 07:27:33 --> Config Class Initialized
INFO - 2023-05-06 07:27:33 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:33 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:33 --> URI Class Initialized
INFO - 2023-05-06 07:27:33 --> Router Class Initialized
INFO - 2023-05-06 07:27:33 --> Output Class Initialized
INFO - 2023-05-06 07:27:33 --> Security Class Initialized
INFO - 2023-05-06 07:27:33 --> Input Class Initialized
INFO - 2023-05-06 07:27:33 --> Language Class Initialized
INFO - 2023-05-06 07:27:33 --> Loader Class Initialized
INFO - 2023-05-06 07:27:33 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:33 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:33 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:33 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:33 --> Controller Class Initialized
INFO - 2023-05-06 07:27:33 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:33 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:27:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:27:33 --> Final output sent to browser
INFO - 2023-05-06 07:27:44 --> Config Class Initialized
INFO - 2023-05-06 07:27:44 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:44 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:44 --> URI Class Initialized
INFO - 2023-05-06 07:27:44 --> Router Class Initialized
INFO - 2023-05-06 07:27:44 --> Output Class Initialized
INFO - 2023-05-06 07:27:44 --> Security Class Initialized
INFO - 2023-05-06 07:27:44 --> Input Class Initialized
INFO - 2023-05-06 07:27:44 --> Language Class Initialized
INFO - 2023-05-06 07:27:44 --> Loader Class Initialized
INFO - 2023-05-06 07:27:44 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:44 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:44 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:44 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:44 --> Controller Class Initialized
INFO - 2023-05-06 07:27:44 --> Model "M_todo_group" initialized
INFO - 2023-05-06 07:27:44 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:27:44 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:27:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:27:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_group/v_index.php
INFO - 2023-05-06 07:27:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:27:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:27:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:27:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 07:27:44 --> Final output sent to browser
INFO - 2023-05-06 07:27:46 --> Config Class Initialized
INFO - 2023-05-06 07:27:46 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:46 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:46 --> URI Class Initialized
INFO - 2023-05-06 07:27:46 --> Router Class Initialized
INFO - 2023-05-06 07:27:46 --> Output Class Initialized
INFO - 2023-05-06 07:27:46 --> Security Class Initialized
INFO - 2023-05-06 07:27:46 --> Input Class Initialized
INFO - 2023-05-06 07:27:46 --> Language Class Initialized
INFO - 2023-05-06 07:27:46 --> Loader Class Initialized
INFO - 2023-05-06 07:27:46 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:46 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:46 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:46 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:46 --> Controller Class Initialized
INFO - 2023-05-06 07:27:46 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:46 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:27:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:27:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:27:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_tutor/v_index.php
INFO - 2023-05-06 07:27:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:27:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:27:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:27:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 07:27:46 --> Final output sent to browser
INFO - 2023-05-06 07:27:47 --> Config Class Initialized
INFO - 2023-05-06 07:27:47 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:47 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:47 --> URI Class Initialized
INFO - 2023-05-06 07:27:47 --> Router Class Initialized
INFO - 2023-05-06 07:27:47 --> Output Class Initialized
INFO - 2023-05-06 07:27:47 --> Security Class Initialized
INFO - 2023-05-06 07:27:47 --> Input Class Initialized
INFO - 2023-05-06 07:27:47 --> Language Class Initialized
INFO - 2023-05-06 07:27:47 --> Loader Class Initialized
INFO - 2023-05-06 07:27:47 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:47 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:47 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:47 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:47 --> Controller Class Initialized
INFO - 2023-05-06 07:27:47 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:47 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:27:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:27:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:27:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:27:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:27:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:27:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:27:47 --> Final output sent to browser
INFO - 2023-05-06 07:27:48 --> Config Class Initialized
INFO - 2023-05-06 07:27:48 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:48 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:48 --> URI Class Initialized
INFO - 2023-05-06 07:27:48 --> Router Class Initialized
INFO - 2023-05-06 07:27:48 --> Output Class Initialized
INFO - 2023-05-06 07:27:48 --> Security Class Initialized
INFO - 2023-05-06 07:27:48 --> Input Class Initialized
INFO - 2023-05-06 07:27:48 --> Language Class Initialized
INFO - 2023-05-06 07:27:48 --> Loader Class Initialized
INFO - 2023-05-06 07:27:48 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:48 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:48 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:48 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:48 --> Controller Class Initialized
INFO - 2023-05-06 07:27:48 --> Model "M_todo_list" initialized
INFO - 2023-05-06 07:27:48 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:27:48 --> Model "M_todo_group" initialized
INFO - 2023-05-06 07:27:48 --> Model "M_todo_task" initialized
INFO - 2023-05-06 07:27:48 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_list/v_index.php
INFO - 2023-05-06 07:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:27:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 07:27:48 --> Final output sent to browser
INFO - 2023-05-06 07:27:50 --> Config Class Initialized
INFO - 2023-05-06 07:27:50 --> Hooks Class Initialized
INFO - 2023-05-06 07:27:50 --> Utf8 Class Initialized
INFO - 2023-05-06 07:27:50 --> URI Class Initialized
INFO - 2023-05-06 07:27:50 --> Router Class Initialized
INFO - 2023-05-06 07:27:50 --> Output Class Initialized
INFO - 2023-05-06 07:27:50 --> Security Class Initialized
INFO - 2023-05-06 07:27:50 --> Input Class Initialized
INFO - 2023-05-06 07:27:50 --> Language Class Initialized
INFO - 2023-05-06 07:27:50 --> Loader Class Initialized
INFO - 2023-05-06 07:27:50 --> Helper loaded: url_helper
INFO - 2023-05-06 07:27:50 --> Helper loaded: form_helper
INFO - 2023-05-06 07:27:50 --> Database Driver Class Initialized
INFO - 2023-05-06 07:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:27:50 --> Form Validation Class Initialized
INFO - 2023-05-06 07:27:50 --> Controller Class Initialized
INFO - 2023-05-06 07:27:50 --> Model "M_todo_group" initialized
INFO - 2023-05-06 07:27:50 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:27:50 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:27:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:27:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:27:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_group/v_index.php
INFO - 2023-05-06 07:27:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:27:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:27:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:27:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 07:27:50 --> Final output sent to browser
INFO - 2023-05-06 07:28:05 --> Config Class Initialized
INFO - 2023-05-06 07:28:05 --> Hooks Class Initialized
INFO - 2023-05-06 07:28:05 --> Utf8 Class Initialized
INFO - 2023-05-06 07:28:05 --> URI Class Initialized
INFO - 2023-05-06 07:28:05 --> Router Class Initialized
INFO - 2023-05-06 07:28:05 --> Output Class Initialized
INFO - 2023-05-06 07:28:05 --> Security Class Initialized
INFO - 2023-05-06 07:28:05 --> Input Class Initialized
INFO - 2023-05-06 07:28:05 --> Language Class Initialized
INFO - 2023-05-06 07:28:05 --> Loader Class Initialized
INFO - 2023-05-06 07:28:05 --> Helper loaded: url_helper
INFO - 2023-05-06 07:28:05 --> Helper loaded: form_helper
INFO - 2023-05-06 07:28:05 --> Database Driver Class Initialized
INFO - 2023-05-06 07:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:28:05 --> Form Validation Class Initialized
INFO - 2023-05-06 07:28:05 --> Controller Class Initialized
INFO - 2023-05-06 07:28:05 --> Model "M_todo_group" initialized
INFO - 2023-05-06 07:28:05 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:28:05 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:28:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:28:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:28:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_group/v_index.php
INFO - 2023-05-06 07:28:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:28:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:28:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:28:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 07:28:05 --> Final output sent to browser
INFO - 2023-05-06 07:28:21 --> Config Class Initialized
INFO - 2023-05-06 07:28:21 --> Hooks Class Initialized
INFO - 2023-05-06 07:28:21 --> Utf8 Class Initialized
INFO - 2023-05-06 07:28:21 --> URI Class Initialized
INFO - 2023-05-06 07:28:21 --> Router Class Initialized
INFO - 2023-05-06 07:28:21 --> Output Class Initialized
INFO - 2023-05-06 07:28:21 --> Security Class Initialized
INFO - 2023-05-06 07:28:21 --> Input Class Initialized
INFO - 2023-05-06 07:28:21 --> Language Class Initialized
INFO - 2023-05-06 07:28:21 --> Loader Class Initialized
INFO - 2023-05-06 07:28:21 --> Helper loaded: url_helper
INFO - 2023-05-06 07:28:21 --> Helper loaded: form_helper
INFO - 2023-05-06 07:28:21 --> Database Driver Class Initialized
INFO - 2023-05-06 07:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:28:21 --> Form Validation Class Initialized
INFO - 2023-05-06 07:28:21 --> Controller Class Initialized
INFO - 2023-05-06 07:28:21 --> Model "M_todo_group" initialized
INFO - 2023-05-06 07:28:21 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:28:21 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:28:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:28:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:28:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_group/v_tambah.php
INFO - 2023-05-06 07:28:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:28:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:28:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:28:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 07:28:21 --> Final output sent to browser
INFO - 2023-05-06 07:28:23 --> Config Class Initialized
INFO - 2023-05-06 07:28:23 --> Hooks Class Initialized
INFO - 2023-05-06 07:28:23 --> Utf8 Class Initialized
INFO - 2023-05-06 07:28:23 --> URI Class Initialized
INFO - 2023-05-06 07:28:23 --> Router Class Initialized
INFO - 2023-05-06 07:28:23 --> Output Class Initialized
INFO - 2023-05-06 07:28:23 --> Security Class Initialized
INFO - 2023-05-06 07:28:23 --> Input Class Initialized
INFO - 2023-05-06 07:28:23 --> Language Class Initialized
INFO - 2023-05-06 07:28:23 --> Loader Class Initialized
INFO - 2023-05-06 07:28:23 --> Helper loaded: url_helper
INFO - 2023-05-06 07:28:23 --> Helper loaded: form_helper
INFO - 2023-05-06 07:28:23 --> Database Driver Class Initialized
INFO - 2023-05-06 07:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:28:23 --> Form Validation Class Initialized
INFO - 2023-05-06 07:28:23 --> Controller Class Initialized
INFO - 2023-05-06 07:28:23 --> Model "M_todo_group" initialized
INFO - 2023-05-06 07:28:23 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:28:23 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\todo_group/v_index.php
INFO - 2023-05-06 07:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:28:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 07:28:23 --> Final output sent to browser
INFO - 2023-05-06 07:28:28 --> Config Class Initialized
INFO - 2023-05-06 07:28:28 --> Hooks Class Initialized
INFO - 2023-05-06 07:28:28 --> Utf8 Class Initialized
INFO - 2023-05-06 07:28:28 --> URI Class Initialized
INFO - 2023-05-06 07:28:28 --> Router Class Initialized
INFO - 2023-05-06 07:28:28 --> Output Class Initialized
INFO - 2023-05-06 07:28:28 --> Security Class Initialized
INFO - 2023-05-06 07:28:28 --> Input Class Initialized
INFO - 2023-05-06 07:28:28 --> Language Class Initialized
INFO - 2023-05-06 07:28:28 --> Loader Class Initialized
INFO - 2023-05-06 07:28:28 --> Helper loaded: url_helper
INFO - 2023-05-06 07:28:28 --> Helper loaded: form_helper
INFO - 2023-05-06 07:28:28 --> Database Driver Class Initialized
INFO - 2023-05-06 07:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:28:28 --> Form Validation Class Initialized
INFO - 2023-05-06 07:28:28 --> Controller Class Initialized
INFO - 2023-05-06 07:28:28 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:28:28 --> Config Class Initialized
INFO - 2023-05-06 07:28:28 --> Hooks Class Initialized
INFO - 2023-05-06 07:28:28 --> Utf8 Class Initialized
INFO - 2023-05-06 07:28:28 --> URI Class Initialized
INFO - 2023-05-06 07:28:28 --> Router Class Initialized
INFO - 2023-05-06 07:28:28 --> Output Class Initialized
INFO - 2023-05-06 07:28:28 --> Security Class Initialized
INFO - 2023-05-06 07:28:28 --> Input Class Initialized
INFO - 2023-05-06 07:28:28 --> Language Class Initialized
INFO - 2023-05-06 07:28:28 --> Loader Class Initialized
INFO - 2023-05-06 07:28:28 --> Helper loaded: url_helper
INFO - 2023-05-06 07:28:28 --> Helper loaded: form_helper
INFO - 2023-05-06 07:28:28 --> Database Driver Class Initialized
INFO - 2023-05-06 07:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:28:28 --> Form Validation Class Initialized
INFO - 2023-05-06 07:28:28 --> Controller Class Initialized
INFO - 2023-05-06 07:28:28 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:28:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:28:28 --> Final output sent to browser
INFO - 2023-05-06 07:28:36 --> Config Class Initialized
INFO - 2023-05-06 07:28:36 --> Hooks Class Initialized
INFO - 2023-05-06 07:28:36 --> Utf8 Class Initialized
INFO - 2023-05-06 07:28:36 --> URI Class Initialized
INFO - 2023-05-06 07:28:36 --> Router Class Initialized
INFO - 2023-05-06 07:28:36 --> Output Class Initialized
INFO - 2023-05-06 07:28:36 --> Security Class Initialized
INFO - 2023-05-06 07:28:36 --> Input Class Initialized
INFO - 2023-05-06 07:28:36 --> Language Class Initialized
INFO - 2023-05-06 07:28:36 --> Loader Class Initialized
INFO - 2023-05-06 07:28:36 --> Helper loaded: url_helper
INFO - 2023-05-06 07:28:36 --> Helper loaded: form_helper
INFO - 2023-05-06 07:28:36 --> Database Driver Class Initialized
INFO - 2023-05-06 07:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:28:36 --> Form Validation Class Initialized
INFO - 2023-05-06 07:28:36 --> Controller Class Initialized
INFO - 2023-05-06 07:28:36 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:28:36 --> Config Class Initialized
INFO - 2023-05-06 07:28:36 --> Hooks Class Initialized
INFO - 2023-05-06 07:28:36 --> Utf8 Class Initialized
INFO - 2023-05-06 07:28:36 --> URI Class Initialized
INFO - 2023-05-06 07:28:36 --> Router Class Initialized
INFO - 2023-05-06 07:28:36 --> Output Class Initialized
INFO - 2023-05-06 07:28:36 --> Security Class Initialized
INFO - 2023-05-06 07:28:36 --> Input Class Initialized
INFO - 2023-05-06 07:28:36 --> Language Class Initialized
INFO - 2023-05-06 07:28:36 --> Loader Class Initialized
INFO - 2023-05-06 07:28:36 --> Helper loaded: url_helper
INFO - 2023-05-06 07:28:36 --> Helper loaded: form_helper
INFO - 2023-05-06 07:28:36 --> Database Driver Class Initialized
INFO - 2023-05-06 07:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:28:36 --> Form Validation Class Initialized
INFO - 2023-05-06 07:28:36 --> Controller Class Initialized
INFO - 2023-05-06 07:28:36 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:28:36 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:28:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:28:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:28:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:28:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:28:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:28:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:28:36 --> Final output sent to browser
INFO - 2023-05-06 07:28:43 --> Config Class Initialized
INFO - 2023-05-06 07:28:43 --> Hooks Class Initialized
INFO - 2023-05-06 07:28:43 --> Utf8 Class Initialized
INFO - 2023-05-06 07:28:43 --> URI Class Initialized
INFO - 2023-05-06 07:28:43 --> Router Class Initialized
INFO - 2023-05-06 07:28:43 --> Output Class Initialized
INFO - 2023-05-06 07:28:43 --> Security Class Initialized
INFO - 2023-05-06 07:28:43 --> Input Class Initialized
INFO - 2023-05-06 07:28:43 --> Language Class Initialized
INFO - 2023-05-06 07:28:43 --> Loader Class Initialized
INFO - 2023-05-06 07:28:43 --> Helper loaded: url_helper
INFO - 2023-05-06 07:28:43 --> Helper loaded: form_helper
INFO - 2023-05-06 07:28:43 --> Database Driver Class Initialized
INFO - 2023-05-06 07:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:28:43 --> Form Validation Class Initialized
INFO - 2023-05-06 07:28:43 --> Controller Class Initialized
INFO - 2023-05-06 07:28:43 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:28:43 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:28:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:28:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:28:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:28:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:28:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:28:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:28:43 --> Final output sent to browser
INFO - 2023-05-06 07:28:49 --> Config Class Initialized
INFO - 2023-05-06 07:28:49 --> Hooks Class Initialized
INFO - 2023-05-06 07:28:49 --> Utf8 Class Initialized
INFO - 2023-05-06 07:28:49 --> URI Class Initialized
INFO - 2023-05-06 07:28:49 --> Router Class Initialized
INFO - 2023-05-06 07:28:49 --> Output Class Initialized
INFO - 2023-05-06 07:28:49 --> Security Class Initialized
INFO - 2023-05-06 07:28:49 --> Input Class Initialized
INFO - 2023-05-06 07:28:49 --> Language Class Initialized
INFO - 2023-05-06 07:28:49 --> Loader Class Initialized
INFO - 2023-05-06 07:28:49 --> Helper loaded: url_helper
INFO - 2023-05-06 07:28:49 --> Helper loaded: form_helper
INFO - 2023-05-06 07:28:49 --> Database Driver Class Initialized
INFO - 2023-05-06 07:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:28:49 --> Form Validation Class Initialized
INFO - 2023-05-06 07:28:49 --> Controller Class Initialized
INFO - 2023-05-06 07:28:49 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:28:49 --> Model "M_todo_group_ptk" initialized
INFO - 2023-05-06 07:28:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:28:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:28:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:28:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:28:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:28:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:28:49 --> Final output sent to browser
INFO - 2023-05-06 07:29:29 --> Config Class Initialized
INFO - 2023-05-06 07:29:29 --> Hooks Class Initialized
INFO - 2023-05-06 07:29:29 --> Utf8 Class Initialized
INFO - 2023-05-06 07:29:29 --> URI Class Initialized
INFO - 2023-05-06 07:29:29 --> Router Class Initialized
INFO - 2023-05-06 07:29:29 --> Output Class Initialized
INFO - 2023-05-06 07:29:29 --> Security Class Initialized
INFO - 2023-05-06 07:29:29 --> Input Class Initialized
INFO - 2023-05-06 07:29:29 --> Language Class Initialized
INFO - 2023-05-06 07:29:29 --> Loader Class Initialized
INFO - 2023-05-06 07:29:29 --> Helper loaded: url_helper
INFO - 2023-05-06 07:29:29 --> Helper loaded: form_helper
INFO - 2023-05-06 07:29:29 --> Database Driver Class Initialized
INFO - 2023-05-06 07:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:29:29 --> Form Validation Class Initialized
INFO - 2023-05-06 07:29:29 --> Controller Class Initialized
INFO - 2023-05-06 07:29:29 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:29:29 --> Config Class Initialized
INFO - 2023-05-06 07:29:29 --> Hooks Class Initialized
INFO - 2023-05-06 07:29:29 --> Utf8 Class Initialized
INFO - 2023-05-06 07:29:29 --> URI Class Initialized
INFO - 2023-05-06 07:29:29 --> Router Class Initialized
INFO - 2023-05-06 07:29:29 --> Output Class Initialized
INFO - 2023-05-06 07:29:29 --> Security Class Initialized
INFO - 2023-05-06 07:29:29 --> Input Class Initialized
INFO - 2023-05-06 07:29:29 --> Language Class Initialized
INFO - 2023-05-06 07:29:29 --> Loader Class Initialized
INFO - 2023-05-06 07:29:29 --> Helper loaded: url_helper
INFO - 2023-05-06 07:29:29 --> Helper loaded: form_helper
INFO - 2023-05-06 07:29:29 --> Database Driver Class Initialized
INFO - 2023-05-06 07:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:29:29 --> Form Validation Class Initialized
INFO - 2023-05-06 07:29:29 --> Controller Class Initialized
INFO - 2023-05-06 07:29:29 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:29:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:29:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:29:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:29:29 --> Final output sent to browser
INFO - 2023-05-06 07:29:31 --> Config Class Initialized
INFO - 2023-05-06 07:29:31 --> Hooks Class Initialized
INFO - 2023-05-06 07:29:31 --> Utf8 Class Initialized
INFO - 2023-05-06 07:29:31 --> URI Class Initialized
INFO - 2023-05-06 07:29:31 --> Router Class Initialized
INFO - 2023-05-06 07:29:31 --> Output Class Initialized
INFO - 2023-05-06 07:29:31 --> Security Class Initialized
INFO - 2023-05-06 07:29:31 --> Input Class Initialized
INFO - 2023-05-06 07:29:31 --> Language Class Initialized
INFO - 2023-05-06 07:29:31 --> Loader Class Initialized
INFO - 2023-05-06 07:29:31 --> Helper loaded: url_helper
INFO - 2023-05-06 07:29:31 --> Helper loaded: form_helper
INFO - 2023-05-06 07:29:31 --> Database Driver Class Initialized
INFO - 2023-05-06 07:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:29:31 --> Form Validation Class Initialized
INFO - 2023-05-06 07:29:31 --> Controller Class Initialized
INFO - 2023-05-06 07:29:31 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:29:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:29:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:29:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:29:31 --> Final output sent to browser
INFO - 2023-05-06 07:29:34 --> Config Class Initialized
INFO - 2023-05-06 07:29:34 --> Hooks Class Initialized
INFO - 2023-05-06 07:29:34 --> Utf8 Class Initialized
INFO - 2023-05-06 07:29:34 --> URI Class Initialized
INFO - 2023-05-06 07:29:34 --> Router Class Initialized
INFO - 2023-05-06 07:29:34 --> Output Class Initialized
INFO - 2023-05-06 07:29:34 --> Security Class Initialized
INFO - 2023-05-06 07:29:34 --> Input Class Initialized
INFO - 2023-05-06 07:29:34 --> Language Class Initialized
INFO - 2023-05-06 07:29:34 --> Loader Class Initialized
INFO - 2023-05-06 07:29:34 --> Helper loaded: url_helper
INFO - 2023-05-06 07:29:34 --> Helper loaded: form_helper
INFO - 2023-05-06 07:29:34 --> Database Driver Class Initialized
INFO - 2023-05-06 07:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:29:34 --> Form Validation Class Initialized
INFO - 2023-05-06 07:29:34 --> Controller Class Initialized
INFO - 2023-05-06 07:29:34 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:29:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:29:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:29:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:29:34 --> Final output sent to browser
INFO - 2023-05-06 07:30:28 --> Config Class Initialized
INFO - 2023-05-06 07:30:28 --> Hooks Class Initialized
INFO - 2023-05-06 07:30:28 --> Utf8 Class Initialized
INFO - 2023-05-06 07:30:28 --> URI Class Initialized
INFO - 2023-05-06 07:30:28 --> Router Class Initialized
INFO - 2023-05-06 07:30:28 --> Output Class Initialized
INFO - 2023-05-06 07:30:28 --> Security Class Initialized
INFO - 2023-05-06 07:30:28 --> Input Class Initialized
INFO - 2023-05-06 07:30:28 --> Language Class Initialized
INFO - 2023-05-06 07:30:28 --> Loader Class Initialized
INFO - 2023-05-06 07:30:28 --> Helper loaded: url_helper
INFO - 2023-05-06 07:30:28 --> Helper loaded: form_helper
INFO - 2023-05-06 07:30:28 --> Database Driver Class Initialized
INFO - 2023-05-06 07:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:30:28 --> Form Validation Class Initialized
INFO - 2023-05-06 07:30:28 --> Controller Class Initialized
INFO - 2023-05-06 07:30:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:30:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:30:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:30:28 --> Final output sent to browser
INFO - 2023-05-06 07:30:29 --> Config Class Initialized
INFO - 2023-05-06 07:30:29 --> Hooks Class Initialized
INFO - 2023-05-06 07:30:29 --> Utf8 Class Initialized
INFO - 2023-05-06 07:30:29 --> URI Class Initialized
INFO - 2023-05-06 07:30:29 --> Router Class Initialized
INFO - 2023-05-06 07:30:29 --> Output Class Initialized
INFO - 2023-05-06 07:30:29 --> Security Class Initialized
INFO - 2023-05-06 07:30:29 --> Input Class Initialized
INFO - 2023-05-06 07:30:29 --> Language Class Initialized
INFO - 2023-05-06 07:30:29 --> Loader Class Initialized
INFO - 2023-05-06 07:30:29 --> Helper loaded: url_helper
INFO - 2023-05-06 07:30:29 --> Helper loaded: form_helper
INFO - 2023-05-06 07:30:29 --> Database Driver Class Initialized
INFO - 2023-05-06 07:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:30:29 --> Form Validation Class Initialized
INFO - 2023-05-06 07:30:29 --> Controller Class Initialized
INFO - 2023-05-06 07:30:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:30:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:30:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:30:29 --> Final output sent to browser
INFO - 2023-05-06 07:30:30 --> Config Class Initialized
INFO - 2023-05-06 07:30:30 --> Hooks Class Initialized
INFO - 2023-05-06 07:30:30 --> Utf8 Class Initialized
INFO - 2023-05-06 07:30:30 --> URI Class Initialized
INFO - 2023-05-06 07:30:30 --> Router Class Initialized
INFO - 2023-05-06 07:30:30 --> Output Class Initialized
INFO - 2023-05-06 07:30:30 --> Security Class Initialized
INFO - 2023-05-06 07:30:30 --> Input Class Initialized
INFO - 2023-05-06 07:30:30 --> Language Class Initialized
INFO - 2023-05-06 07:30:30 --> Loader Class Initialized
INFO - 2023-05-06 07:30:30 --> Helper loaded: url_helper
INFO - 2023-05-06 07:30:30 --> Helper loaded: form_helper
INFO - 2023-05-06 07:30:30 --> Database Driver Class Initialized
INFO - 2023-05-06 07:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:30:30 --> Form Validation Class Initialized
INFO - 2023-05-06 07:30:30 --> Controller Class Initialized
INFO - 2023-05-06 07:30:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:30:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:30:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:30:30 --> Final output sent to browser
INFO - 2023-05-06 07:30:33 --> Config Class Initialized
INFO - 2023-05-06 07:30:33 --> Hooks Class Initialized
INFO - 2023-05-06 07:30:33 --> Utf8 Class Initialized
INFO - 2023-05-06 07:30:33 --> URI Class Initialized
INFO - 2023-05-06 07:30:33 --> Router Class Initialized
INFO - 2023-05-06 07:30:33 --> Output Class Initialized
INFO - 2023-05-06 07:30:33 --> Security Class Initialized
INFO - 2023-05-06 07:30:33 --> Input Class Initialized
INFO - 2023-05-06 07:30:33 --> Language Class Initialized
INFO - 2023-05-06 07:30:33 --> Loader Class Initialized
INFO - 2023-05-06 07:30:33 --> Helper loaded: url_helper
INFO - 2023-05-06 07:30:33 --> Helper loaded: form_helper
INFO - 2023-05-06 07:30:33 --> Database Driver Class Initialized
INFO - 2023-05-06 07:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:30:33 --> Form Validation Class Initialized
INFO - 2023-05-06 07:30:33 --> Controller Class Initialized
ERROR - 2023-05-06 07:30:33 --> Severity: Notice --> Undefined property: C_login::$m_tutor C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_login.php 27
ERROR - 2023-05-06 07:30:33 --> Severity: Error --> Call to a member function login_user() on null C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_login.php 27
INFO - 2023-05-06 07:30:37 --> Config Class Initialized
INFO - 2023-05-06 07:30:37 --> Hooks Class Initialized
INFO - 2023-05-06 07:30:37 --> Utf8 Class Initialized
INFO - 2023-05-06 07:30:37 --> URI Class Initialized
INFO - 2023-05-06 07:30:37 --> Router Class Initialized
INFO - 2023-05-06 07:30:37 --> Output Class Initialized
INFO - 2023-05-06 07:30:37 --> Security Class Initialized
INFO - 2023-05-06 07:30:37 --> Input Class Initialized
INFO - 2023-05-06 07:30:37 --> Language Class Initialized
INFO - 2023-05-06 07:30:37 --> Loader Class Initialized
INFO - 2023-05-06 07:30:37 --> Helper loaded: url_helper
INFO - 2023-05-06 07:30:37 --> Helper loaded: form_helper
INFO - 2023-05-06 07:30:37 --> Database Driver Class Initialized
INFO - 2023-05-06 07:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:30:37 --> Form Validation Class Initialized
INFO - 2023-05-06 07:30:37 --> Controller Class Initialized
INFO - 2023-05-06 07:30:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:30:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:30:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:30:37 --> Final output sent to browser
INFO - 2023-05-06 07:34:30 --> Config Class Initialized
INFO - 2023-05-06 07:34:30 --> Hooks Class Initialized
INFO - 2023-05-06 07:34:30 --> Utf8 Class Initialized
INFO - 2023-05-06 07:34:30 --> URI Class Initialized
INFO - 2023-05-06 07:34:30 --> Router Class Initialized
INFO - 2023-05-06 07:34:30 --> Output Class Initialized
INFO - 2023-05-06 07:34:30 --> Security Class Initialized
INFO - 2023-05-06 07:34:30 --> Input Class Initialized
INFO - 2023-05-06 07:34:30 --> Language Class Initialized
INFO - 2023-05-06 07:34:30 --> Loader Class Initialized
INFO - 2023-05-06 07:34:30 --> Helper loaded: url_helper
INFO - 2023-05-06 07:34:30 --> Helper loaded: form_helper
INFO - 2023-05-06 07:34:30 --> Database Driver Class Initialized
INFO - 2023-05-06 07:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:34:30 --> Form Validation Class Initialized
INFO - 2023-05-06 07:34:30 --> Controller Class Initialized
INFO - 2023-05-06 07:34:30 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:34:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:34:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:34:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:34:30 --> Final output sent to browser
INFO - 2023-05-06 07:34:35 --> Config Class Initialized
INFO - 2023-05-06 07:34:35 --> Hooks Class Initialized
INFO - 2023-05-06 07:34:35 --> Utf8 Class Initialized
INFO - 2023-05-06 07:34:35 --> URI Class Initialized
INFO - 2023-05-06 07:34:35 --> Router Class Initialized
INFO - 2023-05-06 07:34:35 --> Output Class Initialized
INFO - 2023-05-06 07:34:35 --> Security Class Initialized
INFO - 2023-05-06 07:34:35 --> Input Class Initialized
INFO - 2023-05-06 07:34:35 --> Language Class Initialized
INFO - 2023-05-06 07:34:35 --> Loader Class Initialized
INFO - 2023-05-06 07:34:35 --> Helper loaded: url_helper
INFO - 2023-05-06 07:34:35 --> Helper loaded: form_helper
INFO - 2023-05-06 07:34:35 --> Database Driver Class Initialized
INFO - 2023-05-06 07:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:34:35 --> Form Validation Class Initialized
INFO - 2023-05-06 07:34:35 --> Controller Class Initialized
INFO - 2023-05-06 07:34:35 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:34:36 --> Config Class Initialized
INFO - 2023-05-06 07:34:36 --> Hooks Class Initialized
INFO - 2023-05-06 07:34:36 --> Utf8 Class Initialized
INFO - 2023-05-06 07:34:36 --> URI Class Initialized
INFO - 2023-05-06 07:34:36 --> Router Class Initialized
INFO - 2023-05-06 07:34:36 --> Output Class Initialized
INFO - 2023-05-06 07:34:36 --> Security Class Initialized
INFO - 2023-05-06 07:34:36 --> Input Class Initialized
INFO - 2023-05-06 07:34:36 --> Language Class Initialized
INFO - 2023-05-06 07:34:36 --> Loader Class Initialized
INFO - 2023-05-06 07:34:36 --> Helper loaded: url_helper
INFO - 2023-05-06 07:34:36 --> Helper loaded: form_helper
INFO - 2023-05-06 07:34:36 --> Database Driver Class Initialized
INFO - 2023-05-06 07:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:34:36 --> Form Validation Class Initialized
INFO - 2023-05-06 07:34:36 --> Controller Class Initialized
INFO - 2023-05-06 07:34:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:34:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:34:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:34:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:34:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:34:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:34:36 --> Final output sent to browser
INFO - 2023-05-06 07:34:42 --> Config Class Initialized
INFO - 2023-05-06 07:34:42 --> Hooks Class Initialized
INFO - 2023-05-06 07:34:42 --> Utf8 Class Initialized
INFO - 2023-05-06 07:34:42 --> URI Class Initialized
INFO - 2023-05-06 07:34:42 --> Router Class Initialized
INFO - 2023-05-06 07:34:42 --> Output Class Initialized
INFO - 2023-05-06 07:34:42 --> Security Class Initialized
INFO - 2023-05-06 07:34:42 --> Input Class Initialized
INFO - 2023-05-06 07:34:42 --> Language Class Initialized
INFO - 2023-05-06 07:34:42 --> Loader Class Initialized
INFO - 2023-05-06 07:34:42 --> Helper loaded: url_helper
INFO - 2023-05-06 07:34:42 --> Helper loaded: form_helper
INFO - 2023-05-06 07:34:42 --> Database Driver Class Initialized
INFO - 2023-05-06 07:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:34:42 --> Form Validation Class Initialized
INFO - 2023-05-06 07:34:42 --> Controller Class Initialized
INFO - 2023-05-06 07:34:42 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:34:42 --> Config Class Initialized
INFO - 2023-05-06 07:34:42 --> Hooks Class Initialized
INFO - 2023-05-06 07:34:42 --> Utf8 Class Initialized
INFO - 2023-05-06 07:34:42 --> URI Class Initialized
INFO - 2023-05-06 07:34:42 --> Router Class Initialized
INFO - 2023-05-06 07:34:42 --> Output Class Initialized
INFO - 2023-05-06 07:34:42 --> Security Class Initialized
INFO - 2023-05-06 07:34:42 --> Input Class Initialized
INFO - 2023-05-06 07:34:42 --> Language Class Initialized
INFO - 2023-05-06 07:34:42 --> Loader Class Initialized
INFO - 2023-05-06 07:34:42 --> Helper loaded: url_helper
INFO - 2023-05-06 07:34:42 --> Helper loaded: form_helper
INFO - 2023-05-06 07:34:42 --> Database Driver Class Initialized
INFO - 2023-05-06 07:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:34:42 --> Form Validation Class Initialized
INFO - 2023-05-06 07:34:42 --> Controller Class Initialized
INFO - 2023-05-06 07:34:42 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:34:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:34:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:34:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:34:42 --> Final output sent to browser
INFO - 2023-05-06 07:34:46 --> Config Class Initialized
INFO - 2023-05-06 07:34:46 --> Hooks Class Initialized
INFO - 2023-05-06 07:34:46 --> Utf8 Class Initialized
INFO - 2023-05-06 07:34:46 --> URI Class Initialized
INFO - 2023-05-06 07:34:46 --> Router Class Initialized
INFO - 2023-05-06 07:34:46 --> Output Class Initialized
INFO - 2023-05-06 07:34:46 --> Security Class Initialized
INFO - 2023-05-06 07:34:46 --> Input Class Initialized
INFO - 2023-05-06 07:34:46 --> Language Class Initialized
INFO - 2023-05-06 07:34:46 --> Loader Class Initialized
INFO - 2023-05-06 07:34:46 --> Helper loaded: url_helper
INFO - 2023-05-06 07:34:46 --> Helper loaded: form_helper
INFO - 2023-05-06 07:34:46 --> Database Driver Class Initialized
INFO - 2023-05-06 07:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:34:46 --> Form Validation Class Initialized
INFO - 2023-05-06 07:34:46 --> Controller Class Initialized
INFO - 2023-05-06 07:34:46 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:34:46 --> Config Class Initialized
INFO - 2023-05-06 07:34:46 --> Hooks Class Initialized
INFO - 2023-05-06 07:34:46 --> Utf8 Class Initialized
INFO - 2023-05-06 07:34:46 --> URI Class Initialized
INFO - 2023-05-06 07:34:46 --> Router Class Initialized
INFO - 2023-05-06 07:34:46 --> Output Class Initialized
INFO - 2023-05-06 07:34:46 --> Security Class Initialized
INFO - 2023-05-06 07:34:46 --> Input Class Initialized
INFO - 2023-05-06 07:34:46 --> Language Class Initialized
INFO - 2023-05-06 07:34:46 --> Loader Class Initialized
INFO - 2023-05-06 07:34:46 --> Helper loaded: url_helper
INFO - 2023-05-06 07:34:46 --> Helper loaded: form_helper
INFO - 2023-05-06 07:34:46 --> Database Driver Class Initialized
INFO - 2023-05-06 07:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:34:46 --> Form Validation Class Initialized
INFO - 2023-05-06 07:34:46 --> Controller Class Initialized
INFO - 2023-05-06 07:34:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 07:34:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 07:34:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 07:34:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 07:34:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 07:34:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 07:34:46 --> Final output sent to browser
INFO - 2023-05-06 07:34:54 --> Config Class Initialized
INFO - 2023-05-06 07:34:54 --> Hooks Class Initialized
INFO - 2023-05-06 07:34:54 --> Utf8 Class Initialized
INFO - 2023-05-06 07:34:54 --> URI Class Initialized
INFO - 2023-05-06 07:34:54 --> Router Class Initialized
INFO - 2023-05-06 07:34:54 --> Output Class Initialized
INFO - 2023-05-06 07:34:54 --> Security Class Initialized
INFO - 2023-05-06 07:34:54 --> Input Class Initialized
INFO - 2023-05-06 07:34:54 --> Language Class Initialized
INFO - 2023-05-06 07:34:54 --> Loader Class Initialized
INFO - 2023-05-06 07:34:54 --> Helper loaded: url_helper
INFO - 2023-05-06 07:34:54 --> Helper loaded: form_helper
INFO - 2023-05-06 07:34:54 --> Database Driver Class Initialized
INFO - 2023-05-06 07:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:34:54 --> Form Validation Class Initialized
INFO - 2023-05-06 07:34:54 --> Controller Class Initialized
INFO - 2023-05-06 07:34:54 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:34:54 --> Config Class Initialized
INFO - 2023-05-06 07:34:54 --> Hooks Class Initialized
INFO - 2023-05-06 07:34:54 --> Utf8 Class Initialized
INFO - 2023-05-06 07:34:54 --> URI Class Initialized
INFO - 2023-05-06 07:34:54 --> Router Class Initialized
INFO - 2023-05-06 07:34:54 --> Output Class Initialized
INFO - 2023-05-06 07:34:54 --> Security Class Initialized
INFO - 2023-05-06 07:34:54 --> Input Class Initialized
INFO - 2023-05-06 07:34:54 --> Language Class Initialized
INFO - 2023-05-06 07:34:54 --> Loader Class Initialized
INFO - 2023-05-06 07:34:54 --> Helper loaded: url_helper
INFO - 2023-05-06 07:34:54 --> Helper loaded: form_helper
INFO - 2023-05-06 07:34:54 --> Database Driver Class Initialized
INFO - 2023-05-06 07:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:34:54 --> Form Validation Class Initialized
INFO - 2023-05-06 07:34:54 --> Controller Class Initialized
INFO - 2023-05-06 07:34:54 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:34:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:34:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:34:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:34:54 --> Final output sent to browser
INFO - 2023-05-06 07:34:57 --> Config Class Initialized
INFO - 2023-05-06 07:34:57 --> Hooks Class Initialized
INFO - 2023-05-06 07:34:57 --> Utf8 Class Initialized
INFO - 2023-05-06 07:34:57 --> URI Class Initialized
INFO - 2023-05-06 07:34:57 --> Router Class Initialized
INFO - 2023-05-06 07:34:57 --> Output Class Initialized
INFO - 2023-05-06 07:34:57 --> Security Class Initialized
INFO - 2023-05-06 07:34:57 --> Input Class Initialized
INFO - 2023-05-06 07:34:57 --> Language Class Initialized
INFO - 2023-05-06 07:34:57 --> Loader Class Initialized
INFO - 2023-05-06 07:34:57 --> Helper loaded: url_helper
INFO - 2023-05-06 07:34:57 --> Helper loaded: form_helper
INFO - 2023-05-06 07:34:57 --> Database Driver Class Initialized
INFO - 2023-05-06 07:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:34:57 --> Form Validation Class Initialized
INFO - 2023-05-06 07:34:57 --> Controller Class Initialized
INFO - 2023-05-06 07:34:57 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:34:57 --> Config Class Initialized
INFO - 2023-05-06 07:34:57 --> Hooks Class Initialized
INFO - 2023-05-06 07:34:57 --> Utf8 Class Initialized
INFO - 2023-05-06 07:34:57 --> URI Class Initialized
INFO - 2023-05-06 07:34:57 --> Router Class Initialized
INFO - 2023-05-06 07:34:57 --> Output Class Initialized
INFO - 2023-05-06 07:34:57 --> Security Class Initialized
INFO - 2023-05-06 07:34:57 --> Input Class Initialized
INFO - 2023-05-06 07:34:57 --> Language Class Initialized
INFO - 2023-05-06 07:34:57 --> Loader Class Initialized
INFO - 2023-05-06 07:34:57 --> Helper loaded: url_helper
INFO - 2023-05-06 07:34:57 --> Helper loaded: form_helper
INFO - 2023-05-06 07:34:57 --> Database Driver Class Initialized
INFO - 2023-05-06 07:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 07:34:57 --> Form Validation Class Initialized
INFO - 2023-05-06 07:34:57 --> Controller Class Initialized
INFO - 2023-05-06 07:34:57 --> Model "M_tutor" initialized
INFO - 2023-05-06 07:34:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 07:34:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 07:34:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 07:34:57 --> Final output sent to browser
INFO - 2023-05-06 08:09:23 --> Config Class Initialized
INFO - 2023-05-06 08:09:23 --> Hooks Class Initialized
INFO - 2023-05-06 08:09:23 --> Utf8 Class Initialized
INFO - 2023-05-06 08:09:23 --> URI Class Initialized
INFO - 2023-05-06 08:09:23 --> Router Class Initialized
INFO - 2023-05-06 08:09:23 --> Output Class Initialized
INFO - 2023-05-06 08:09:23 --> Security Class Initialized
INFO - 2023-05-06 08:09:23 --> Input Class Initialized
INFO - 2023-05-06 08:09:23 --> Language Class Initialized
INFO - 2023-05-06 08:09:23 --> Loader Class Initialized
INFO - 2023-05-06 08:09:23 --> Helper loaded: url_helper
INFO - 2023-05-06 08:09:23 --> Helper loaded: form_helper
INFO - 2023-05-06 08:09:23 --> Database Driver Class Initialized
INFO - 2023-05-06 08:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:09:23 --> Form Validation Class Initialized
INFO - 2023-05-06 08:09:23 --> Controller Class Initialized
INFO - 2023-05-06 08:09:23 --> Model "M_tutor" initialized
INFO - 2023-05-06 08:09:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 08:09:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 08:09:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 08:09:23 --> Final output sent to browser
INFO - 2023-05-06 08:34:01 --> Config Class Initialized
INFO - 2023-05-06 08:34:01 --> Hooks Class Initialized
INFO - 2023-05-06 08:34:01 --> Utf8 Class Initialized
INFO - 2023-05-06 08:34:01 --> URI Class Initialized
INFO - 2023-05-06 08:34:01 --> Router Class Initialized
INFO - 2023-05-06 08:34:01 --> Output Class Initialized
INFO - 2023-05-06 08:34:01 --> Security Class Initialized
INFO - 2023-05-06 08:34:01 --> Input Class Initialized
INFO - 2023-05-06 08:34:01 --> Language Class Initialized
INFO - 2023-05-06 08:34:01 --> Loader Class Initialized
INFO - 2023-05-06 08:34:01 --> Helper loaded: url_helper
INFO - 2023-05-06 08:34:01 --> Helper loaded: form_helper
INFO - 2023-05-06 08:34:01 --> Database Driver Class Initialized
INFO - 2023-05-06 08:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:34:02 --> Form Validation Class Initialized
INFO - 2023-05-06 08:34:02 --> Controller Class Initialized
INFO - 2023-05-06 08:34:02 --> Model "M_tutor" initialized
INFO - 2023-05-06 08:34:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 08:34:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 08:34:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 08:34:02 --> Final output sent to browser
INFO - 2023-05-06 08:34:06 --> Config Class Initialized
INFO - 2023-05-06 08:34:06 --> Hooks Class Initialized
INFO - 2023-05-06 08:34:06 --> Utf8 Class Initialized
INFO - 2023-05-06 08:34:06 --> URI Class Initialized
INFO - 2023-05-06 08:34:06 --> Router Class Initialized
INFO - 2023-05-06 08:34:06 --> Output Class Initialized
INFO - 2023-05-06 08:34:06 --> Security Class Initialized
INFO - 2023-05-06 08:34:06 --> Input Class Initialized
INFO - 2023-05-06 08:34:06 --> Language Class Initialized
INFO - 2023-05-06 08:34:07 --> Loader Class Initialized
INFO - 2023-05-06 08:34:07 --> Helper loaded: url_helper
INFO - 2023-05-06 08:34:07 --> Helper loaded: form_helper
INFO - 2023-05-06 08:34:07 --> Database Driver Class Initialized
INFO - 2023-05-06 08:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:34:07 --> Form Validation Class Initialized
INFO - 2023-05-06 08:34:07 --> Controller Class Initialized
INFO - 2023-05-06 08:34:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:34:07 --> Final output sent to browser
INFO - 2023-05-06 08:34:07 --> Config Class Initialized
INFO - 2023-05-06 08:34:07 --> Hooks Class Initialized
INFO - 2023-05-06 08:34:07 --> Utf8 Class Initialized
INFO - 2023-05-06 08:34:07 --> URI Class Initialized
INFO - 2023-05-06 08:34:07 --> Router Class Initialized
INFO - 2023-05-06 08:34:07 --> Output Class Initialized
INFO - 2023-05-06 08:34:07 --> Security Class Initialized
INFO - 2023-05-06 08:34:07 --> Input Class Initialized
INFO - 2023-05-06 08:34:07 --> Language Class Initialized
ERROR - 2023-05-06 08:34:07 --> 404 Page Not Found: Css/styles.css
INFO - 2023-05-06 08:34:07 --> Config Class Initialized
INFO - 2023-05-06 08:34:07 --> Hooks Class Initialized
INFO - 2023-05-06 08:34:07 --> Config Class Initialized
INFO - 2023-05-06 08:34:07 --> Hooks Class Initialized
INFO - 2023-05-06 08:34:07 --> Config Class Initialized
INFO - 2023-05-06 08:34:07 --> Hooks Class Initialized
INFO - 2023-05-06 08:34:07 --> Config Class Initialized
INFO - 2023-05-06 08:34:07 --> Hooks Class Initialized
INFO - 2023-05-06 08:34:07 --> Config Class Initialized
INFO - 2023-05-06 08:34:07 --> Utf8 Class Initialized
INFO - 2023-05-06 08:34:07 --> Hooks Class Initialized
INFO - 2023-05-06 08:34:07 --> Utf8 Class Initialized
INFO - 2023-05-06 08:34:07 --> URI Class Initialized
INFO - 2023-05-06 08:34:07 --> URI Class Initialized
INFO - 2023-05-06 08:34:07 --> Router Class Initialized
INFO - 2023-05-06 08:34:07 --> Utf8 Class Initialized
INFO - 2023-05-06 08:34:07 --> Utf8 Class Initialized
INFO - 2023-05-06 08:34:07 --> Utf8 Class Initialized
INFO - 2023-05-06 08:34:07 --> URI Class Initialized
INFO - 2023-05-06 08:34:07 --> Router Class Initialized
INFO - 2023-05-06 08:34:07 --> URI Class Initialized
INFO - 2023-05-06 08:34:07 --> URI Class Initialized
INFO - 2023-05-06 08:34:07 --> Output Class Initialized
INFO - 2023-05-06 08:34:07 --> Router Class Initialized
INFO - 2023-05-06 08:34:07 --> Router Class Initialized
INFO - 2023-05-06 08:34:07 --> Output Class Initialized
INFO - 2023-05-06 08:34:07 --> Router Class Initialized
INFO - 2023-05-06 08:34:07 --> Security Class Initialized
INFO - 2023-05-06 08:34:07 --> Security Class Initialized
INFO - 2023-05-06 08:34:07 --> Output Class Initialized
INFO - 2023-05-06 08:34:07 --> Output Class Initialized
INFO - 2023-05-06 08:34:07 --> Input Class Initialized
INFO - 2023-05-06 08:34:07 --> Output Class Initialized
INFO - 2023-05-06 08:34:07 --> Language Class Initialized
INFO - 2023-05-06 08:34:07 --> Input Class Initialized
INFO - 2023-05-06 08:34:07 --> Security Class Initialized
INFO - 2023-05-06 08:34:07 --> Security Class Initialized
INFO - 2023-05-06 08:34:07 --> Language Class Initialized
INFO - 2023-05-06 08:34:07 --> Security Class Initialized
ERROR - 2023-05-06 08:34:07 --> 404 Page Not Found: Js/scripts.js
INFO - 2023-05-06 08:34:07 --> Input Class Initialized
INFO - 2023-05-06 08:34:07 --> Input Class Initialized
INFO - 2023-05-06 08:34:07 --> Language Class Initialized
ERROR - 2023-05-06 08:34:07 --> 404 Page Not Found: Assets/img
INFO - 2023-05-06 08:34:07 --> Language Class Initialized
INFO - 2023-05-06 08:34:07 --> Input Class Initialized
INFO - 2023-05-06 08:34:07 --> Language Class Initialized
ERROR - 2023-05-06 08:34:07 --> 404 Page Not Found: Assets/img
ERROR - 2023-05-06 08:34:07 --> 404 Page Not Found: Assets/img
ERROR - 2023-05-06 08:34:07 --> 404 Page Not Found: Assets/img
INFO - 2023-05-06 08:34:12 --> Config Class Initialized
INFO - 2023-05-06 08:34:12 --> Hooks Class Initialized
INFO - 2023-05-06 08:34:12 --> Utf8 Class Initialized
INFO - 2023-05-06 08:34:12 --> URI Class Initialized
INFO - 2023-05-06 08:34:12 --> Router Class Initialized
INFO - 2023-05-06 08:34:12 --> Output Class Initialized
INFO - 2023-05-06 08:34:12 --> Security Class Initialized
INFO - 2023-05-06 08:34:12 --> Input Class Initialized
INFO - 2023-05-06 08:34:12 --> Language Class Initialized
ERROR - 2023-05-06 08:34:12 --> 404 Page Not Found: Assets/favicon.ico
INFO - 2023-05-06 08:36:21 --> Config Class Initialized
INFO - 2023-05-06 08:36:21 --> Hooks Class Initialized
INFO - 2023-05-06 08:36:21 --> Utf8 Class Initialized
INFO - 2023-05-06 08:36:21 --> URI Class Initialized
INFO - 2023-05-06 08:36:21 --> Router Class Initialized
INFO - 2023-05-06 08:36:21 --> Output Class Initialized
INFO - 2023-05-06 08:36:21 --> Security Class Initialized
INFO - 2023-05-06 08:36:21 --> Input Class Initialized
INFO - 2023-05-06 08:36:21 --> Language Class Initialized
INFO - 2023-05-06 08:36:21 --> Loader Class Initialized
INFO - 2023-05-06 08:36:21 --> Helper loaded: url_helper
INFO - 2023-05-06 08:36:21 --> Helper loaded: form_helper
INFO - 2023-05-06 08:36:21 --> Database Driver Class Initialized
INFO - 2023-05-06 08:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:36:21 --> Form Validation Class Initialized
INFO - 2023-05-06 08:36:21 --> Controller Class Initialized
INFO - 2023-05-06 08:36:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:36:21 --> Final output sent to browser
INFO - 2023-05-06 08:36:21 --> Config Class Initialized
INFO - 2023-05-06 08:36:21 --> Hooks Class Initialized
INFO - 2023-05-06 08:36:21 --> Utf8 Class Initialized
INFO - 2023-05-06 08:36:21 --> URI Class Initialized
INFO - 2023-05-06 08:36:21 --> Router Class Initialized
INFO - 2023-05-06 08:36:21 --> Output Class Initialized
INFO - 2023-05-06 08:36:21 --> Security Class Initialized
INFO - 2023-05-06 08:36:21 --> Input Class Initialized
INFO - 2023-05-06 08:36:21 --> Language Class Initialized
ERROR - 2023-05-06 08:36:21 --> 404 Page Not Found: Js/scripts.js
INFO - 2023-05-06 08:36:21 --> Config Class Initialized
INFO - 2023-05-06 08:36:21 --> Hooks Class Initialized
INFO - 2023-05-06 08:36:21 --> Config Class Initialized
INFO - 2023-05-06 08:36:21 --> Hooks Class Initialized
INFO - 2023-05-06 08:36:21 --> Config Class Initialized
INFO - 2023-05-06 08:36:21 --> Hooks Class Initialized
INFO - 2023-05-06 08:36:21 --> Utf8 Class Initialized
INFO - 2023-05-06 08:36:21 --> Config Class Initialized
INFO - 2023-05-06 08:36:21 --> URI Class Initialized
INFO - 2023-05-06 08:36:21 --> Hooks Class Initialized
INFO - 2023-05-06 08:36:21 --> Utf8 Class Initialized
INFO - 2023-05-06 08:36:21 --> Utf8 Class Initialized
INFO - 2023-05-06 08:36:21 --> Router Class Initialized
INFO - 2023-05-06 08:36:21 --> URI Class Initialized
INFO - 2023-05-06 08:36:21 --> URI Class Initialized
INFO - 2023-05-06 08:36:21 --> Output Class Initialized
INFO - 2023-05-06 08:36:21 --> Router Class Initialized
INFO - 2023-05-06 08:36:21 --> Router Class Initialized
INFO - 2023-05-06 08:36:21 --> Utf8 Class Initialized
INFO - 2023-05-06 08:36:21 --> Security Class Initialized
INFO - 2023-05-06 08:36:21 --> URI Class Initialized
INFO - 2023-05-06 08:36:21 --> Output Class Initialized
INFO - 2023-05-06 08:36:21 --> Output Class Initialized
INFO - 2023-05-06 08:36:21 --> Input Class Initialized
INFO - 2023-05-06 08:36:21 --> Router Class Initialized
INFO - 2023-05-06 08:36:21 --> Security Class Initialized
INFO - 2023-05-06 08:36:21 --> Language Class Initialized
INFO - 2023-05-06 08:36:21 --> Security Class Initialized
ERROR - 2023-05-06 08:36:21 --> 404 Page Not Found: Assets/img
INFO - 2023-05-06 08:36:21 --> Input Class Initialized
INFO - 2023-05-06 08:36:21 --> Output Class Initialized
INFO - 2023-05-06 08:36:21 --> Input Class Initialized
INFO - 2023-05-06 08:36:21 --> Language Class Initialized
INFO - 2023-05-06 08:36:21 --> Language Class Initialized
INFO - 2023-05-06 08:36:21 --> Security Class Initialized
ERROR - 2023-05-06 08:36:21 --> 404 Page Not Found: Assets/img
ERROR - 2023-05-06 08:36:21 --> 404 Page Not Found: Assets/img
INFO - 2023-05-06 08:36:21 --> Input Class Initialized
INFO - 2023-05-06 08:36:21 --> Language Class Initialized
ERROR - 2023-05-06 08:36:21 --> 404 Page Not Found: Assets/img
INFO - 2023-05-06 08:36:21 --> Config Class Initialized
INFO - 2023-05-06 08:36:21 --> Hooks Class Initialized
INFO - 2023-05-06 08:36:21 --> Utf8 Class Initialized
INFO - 2023-05-06 08:36:21 --> URI Class Initialized
INFO - 2023-05-06 08:36:21 --> Router Class Initialized
INFO - 2023-05-06 08:36:21 --> Output Class Initialized
INFO - 2023-05-06 08:36:21 --> Security Class Initialized
INFO - 2023-05-06 08:36:21 --> Input Class Initialized
INFO - 2023-05-06 08:36:21 --> Language Class Initialized
ERROR - 2023-05-06 08:36:21 --> 404 Page Not Found: Js/scripts.js
INFO - 2023-05-06 08:41:04 --> Config Class Initialized
INFO - 2023-05-06 08:41:04 --> Hooks Class Initialized
INFO - 2023-05-06 08:41:04 --> Utf8 Class Initialized
INFO - 2023-05-06 08:41:04 --> URI Class Initialized
INFO - 2023-05-06 08:41:04 --> Router Class Initialized
INFO - 2023-05-06 08:41:04 --> Output Class Initialized
INFO - 2023-05-06 08:41:04 --> Security Class Initialized
INFO - 2023-05-06 08:41:04 --> Input Class Initialized
INFO - 2023-05-06 08:41:04 --> Language Class Initialized
INFO - 2023-05-06 08:41:04 --> Loader Class Initialized
INFO - 2023-05-06 08:41:04 --> Helper loaded: url_helper
INFO - 2023-05-06 08:41:04 --> Helper loaded: form_helper
INFO - 2023-05-06 08:41:04 --> Database Driver Class Initialized
INFO - 2023-05-06 08:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:41:04 --> Form Validation Class Initialized
INFO - 2023-05-06 08:41:04 --> Controller Class Initialized
INFO - 2023-05-06 08:41:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:41:04 --> Final output sent to browser
INFO - 2023-05-06 08:41:05 --> Config Class Initialized
INFO - 2023-05-06 08:41:05 --> Hooks Class Initialized
INFO - 2023-05-06 08:41:05 --> Utf8 Class Initialized
INFO - 2023-05-06 08:41:05 --> URI Class Initialized
INFO - 2023-05-06 08:41:05 --> Router Class Initialized
INFO - 2023-05-06 08:41:05 --> Output Class Initialized
INFO - 2023-05-06 08:41:05 --> Security Class Initialized
INFO - 2023-05-06 08:41:05 --> Input Class Initialized
INFO - 2023-05-06 08:41:05 --> Language Class Initialized
ERROR - 2023-05-06 08:41:05 --> 404 Page Not Found: Js/scripts.js
INFO - 2023-05-06 08:51:33 --> Config Class Initialized
INFO - 2023-05-06 08:51:33 --> Hooks Class Initialized
INFO - 2023-05-06 08:51:33 --> Utf8 Class Initialized
INFO - 2023-05-06 08:51:33 --> URI Class Initialized
INFO - 2023-05-06 08:51:33 --> Router Class Initialized
INFO - 2023-05-06 08:51:33 --> Output Class Initialized
INFO - 2023-05-06 08:51:33 --> Security Class Initialized
INFO - 2023-05-06 08:51:33 --> Input Class Initialized
INFO - 2023-05-06 08:51:33 --> Language Class Initialized
INFO - 2023-05-06 08:51:33 --> Loader Class Initialized
INFO - 2023-05-06 08:51:33 --> Helper loaded: url_helper
INFO - 2023-05-06 08:51:33 --> Helper loaded: form_helper
INFO - 2023-05-06 08:51:33 --> Database Driver Class Initialized
INFO - 2023-05-06 08:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:51:33 --> Form Validation Class Initialized
INFO - 2023-05-06 08:51:33 --> Controller Class Initialized
INFO - 2023-05-06 08:51:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:51:33 --> Final output sent to browser
INFO - 2023-05-06 08:51:33 --> Config Class Initialized
INFO - 2023-05-06 08:51:33 --> Hooks Class Initialized
INFO - 2023-05-06 08:51:33 --> Utf8 Class Initialized
INFO - 2023-05-06 08:51:33 --> URI Class Initialized
INFO - 2023-05-06 08:51:33 --> Router Class Initialized
INFO - 2023-05-06 08:51:33 --> Output Class Initialized
INFO - 2023-05-06 08:51:33 --> Security Class Initialized
INFO - 2023-05-06 08:51:33 --> Input Class Initialized
INFO - 2023-05-06 08:51:33 --> Language Class Initialized
ERROR - 2023-05-06 08:51:33 --> 404 Page Not Found: Js/scripts.js
INFO - 2023-05-06 08:51:35 --> Config Class Initialized
INFO - 2023-05-06 08:51:35 --> Hooks Class Initialized
INFO - 2023-05-06 08:51:35 --> Utf8 Class Initialized
INFO - 2023-05-06 08:51:35 --> URI Class Initialized
INFO - 2023-05-06 08:51:35 --> Router Class Initialized
INFO - 2023-05-06 08:51:35 --> Output Class Initialized
INFO - 2023-05-06 08:51:35 --> Security Class Initialized
INFO - 2023-05-06 08:51:35 --> Input Class Initialized
INFO - 2023-05-06 08:51:35 --> Language Class Initialized
INFO - 2023-05-06 08:51:35 --> Loader Class Initialized
INFO - 2023-05-06 08:51:35 --> Helper loaded: url_helper
INFO - 2023-05-06 08:51:35 --> Helper loaded: form_helper
INFO - 2023-05-06 08:51:35 --> Database Driver Class Initialized
INFO - 2023-05-06 08:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:51:36 --> Form Validation Class Initialized
INFO - 2023-05-06 08:51:36 --> Controller Class Initialized
INFO - 2023-05-06 08:51:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:51:36 --> Final output sent to browser
INFO - 2023-05-06 08:51:36 --> Config Class Initialized
INFO - 2023-05-06 08:51:36 --> Hooks Class Initialized
INFO - 2023-05-06 08:51:36 --> Utf8 Class Initialized
INFO - 2023-05-06 08:51:36 --> URI Class Initialized
INFO - 2023-05-06 08:51:36 --> Router Class Initialized
INFO - 2023-05-06 08:51:36 --> Output Class Initialized
INFO - 2023-05-06 08:51:36 --> Security Class Initialized
INFO - 2023-05-06 08:51:36 --> Input Class Initialized
INFO - 2023-05-06 08:51:36 --> Language Class Initialized
ERROR - 2023-05-06 08:51:36 --> 404 Page Not Found: Js/scripts.js
INFO - 2023-05-06 08:52:22 --> Config Class Initialized
INFO - 2023-05-06 08:52:22 --> Hooks Class Initialized
INFO - 2023-05-06 08:52:22 --> Utf8 Class Initialized
INFO - 2023-05-06 08:52:22 --> URI Class Initialized
INFO - 2023-05-06 08:52:22 --> Router Class Initialized
INFO - 2023-05-06 08:52:22 --> Output Class Initialized
INFO - 2023-05-06 08:52:22 --> Security Class Initialized
INFO - 2023-05-06 08:52:22 --> Input Class Initialized
INFO - 2023-05-06 08:52:22 --> Language Class Initialized
INFO - 2023-05-06 08:52:22 --> Loader Class Initialized
INFO - 2023-05-06 08:52:22 --> Helper loaded: url_helper
INFO - 2023-05-06 08:52:22 --> Helper loaded: form_helper
INFO - 2023-05-06 08:52:22 --> Database Driver Class Initialized
INFO - 2023-05-06 08:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:52:22 --> Form Validation Class Initialized
INFO - 2023-05-06 08:52:22 --> Controller Class Initialized
INFO - 2023-05-06 08:52:22 --> Model "M_tutor" initialized
INFO - 2023-05-06 08:52:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 08:52:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 08:52:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 08:52:22 --> Final output sent to browser
INFO - 2023-05-06 08:52:27 --> Config Class Initialized
INFO - 2023-05-06 08:52:27 --> Hooks Class Initialized
INFO - 2023-05-06 08:52:27 --> Utf8 Class Initialized
INFO - 2023-05-06 08:52:27 --> URI Class Initialized
INFO - 2023-05-06 08:52:27 --> Router Class Initialized
INFO - 2023-05-06 08:52:27 --> Output Class Initialized
INFO - 2023-05-06 08:52:27 --> Security Class Initialized
INFO - 2023-05-06 08:52:27 --> Input Class Initialized
INFO - 2023-05-06 08:52:27 --> Language Class Initialized
INFO - 2023-05-06 08:52:27 --> Loader Class Initialized
INFO - 2023-05-06 08:52:27 --> Helper loaded: url_helper
INFO - 2023-05-06 08:52:27 --> Helper loaded: form_helper
INFO - 2023-05-06 08:52:27 --> Database Driver Class Initialized
INFO - 2023-05-06 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:52:27 --> Form Validation Class Initialized
INFO - 2023-05-06 08:52:27 --> Controller Class Initialized
INFO - 2023-05-06 08:52:27 --> Model "M_tutor" initialized
INFO - 2023-05-06 08:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 08:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 08:52:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 08:52:27 --> Final output sent to browser
INFO - 2023-05-06 08:52:31 --> Config Class Initialized
INFO - 2023-05-06 08:52:31 --> Hooks Class Initialized
INFO - 2023-05-06 08:52:31 --> Utf8 Class Initialized
INFO - 2023-05-06 08:52:31 --> URI Class Initialized
INFO - 2023-05-06 08:52:31 --> Router Class Initialized
INFO - 2023-05-06 08:52:31 --> Output Class Initialized
INFO - 2023-05-06 08:52:31 --> Security Class Initialized
INFO - 2023-05-06 08:52:31 --> Input Class Initialized
INFO - 2023-05-06 08:52:31 --> Language Class Initialized
INFO - 2023-05-06 08:52:31 --> Loader Class Initialized
INFO - 2023-05-06 08:52:31 --> Helper loaded: url_helper
INFO - 2023-05-06 08:52:31 --> Helper loaded: form_helper
INFO - 2023-05-06 08:52:31 --> Database Driver Class Initialized
INFO - 2023-05-06 08:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:52:31 --> Form Validation Class Initialized
INFO - 2023-05-06 08:52:31 --> Controller Class Initialized
INFO - 2023-05-06 08:52:31 --> Model "M_tutor" initialized
INFO - 2023-05-06 08:52:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 08:52:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 08:52:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 08:52:31 --> Final output sent to browser
INFO - 2023-05-06 08:52:35 --> Config Class Initialized
INFO - 2023-05-06 08:52:35 --> Hooks Class Initialized
INFO - 2023-05-06 08:52:35 --> Utf8 Class Initialized
INFO - 2023-05-06 08:52:35 --> URI Class Initialized
INFO - 2023-05-06 08:52:35 --> Router Class Initialized
INFO - 2023-05-06 08:52:35 --> Output Class Initialized
INFO - 2023-05-06 08:52:35 --> Security Class Initialized
INFO - 2023-05-06 08:52:35 --> Input Class Initialized
INFO - 2023-05-06 08:52:35 --> Language Class Initialized
INFO - 2023-05-06 08:52:35 --> Loader Class Initialized
INFO - 2023-05-06 08:52:35 --> Helper loaded: url_helper
INFO - 2023-05-06 08:52:35 --> Helper loaded: form_helper
INFO - 2023-05-06 08:52:35 --> Database Driver Class Initialized
INFO - 2023-05-06 08:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:52:35 --> Form Validation Class Initialized
INFO - 2023-05-06 08:52:35 --> Controller Class Initialized
INFO - 2023-05-06 08:52:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:52:35 --> Final output sent to browser
INFO - 2023-05-06 08:52:35 --> Config Class Initialized
INFO - 2023-05-06 08:52:35 --> Hooks Class Initialized
INFO - 2023-05-06 08:52:35 --> Utf8 Class Initialized
INFO - 2023-05-06 08:52:35 --> URI Class Initialized
INFO - 2023-05-06 08:52:35 --> Router Class Initialized
INFO - 2023-05-06 08:52:35 --> Output Class Initialized
INFO - 2023-05-06 08:52:35 --> Security Class Initialized
INFO - 2023-05-06 08:52:35 --> Input Class Initialized
INFO - 2023-05-06 08:52:35 --> Language Class Initialized
ERROR - 2023-05-06 08:52:35 --> 404 Page Not Found: Js/scripts.js
INFO - 2023-05-06 08:55:08 --> Config Class Initialized
INFO - 2023-05-06 08:55:08 --> Hooks Class Initialized
INFO - 2023-05-06 08:55:08 --> Utf8 Class Initialized
INFO - 2023-05-06 08:55:08 --> URI Class Initialized
INFO - 2023-05-06 08:55:08 --> Router Class Initialized
INFO - 2023-05-06 08:55:08 --> Output Class Initialized
INFO - 2023-05-06 08:55:08 --> Security Class Initialized
INFO - 2023-05-06 08:55:08 --> Input Class Initialized
INFO - 2023-05-06 08:55:08 --> Language Class Initialized
INFO - 2023-05-06 08:55:08 --> Loader Class Initialized
INFO - 2023-05-06 08:55:08 --> Helper loaded: url_helper
INFO - 2023-05-06 08:55:08 --> Helper loaded: form_helper
INFO - 2023-05-06 08:55:08 --> Database Driver Class Initialized
INFO - 2023-05-06 08:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:55:08 --> Form Validation Class Initialized
INFO - 2023-05-06 08:55:08 --> Controller Class Initialized
INFO - 2023-05-06 08:55:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:55:08 --> Final output sent to browser
INFO - 2023-05-06 08:55:09 --> Config Class Initialized
INFO - 2023-05-06 08:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 08:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 08:55:09 --> URI Class Initialized
INFO - 2023-05-06 08:55:09 --> Router Class Initialized
INFO - 2023-05-06 08:55:09 --> Output Class Initialized
INFO - 2023-05-06 08:55:09 --> Security Class Initialized
INFO - 2023-05-06 08:55:09 --> Input Class Initialized
INFO - 2023-05-06 08:55:09 --> Language Class Initialized
ERROR - 2023-05-06 08:55:09 --> 404 Page Not Found: Js/scripts.js
INFO - 2023-05-06 08:55:13 --> Config Class Initialized
INFO - 2023-05-06 08:55:13 --> Hooks Class Initialized
INFO - 2023-05-06 08:55:13 --> Utf8 Class Initialized
INFO - 2023-05-06 08:55:13 --> URI Class Initialized
INFO - 2023-05-06 08:55:13 --> Router Class Initialized
INFO - 2023-05-06 08:55:13 --> Output Class Initialized
INFO - 2023-05-06 08:55:13 --> Security Class Initialized
INFO - 2023-05-06 08:55:13 --> Input Class Initialized
INFO - 2023-05-06 08:55:13 --> Language Class Initialized
INFO - 2023-05-06 08:55:13 --> Loader Class Initialized
INFO - 2023-05-06 08:55:13 --> Helper loaded: url_helper
INFO - 2023-05-06 08:55:13 --> Helper loaded: form_helper
INFO - 2023-05-06 08:55:13 --> Database Driver Class Initialized
INFO - 2023-05-06 08:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:55:13 --> Form Validation Class Initialized
INFO - 2023-05-06 08:55:13 --> Controller Class Initialized
INFO - 2023-05-06 08:55:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:55:13 --> Final output sent to browser
INFO - 2023-05-06 08:55:14 --> Config Class Initialized
INFO - 2023-05-06 08:55:14 --> Hooks Class Initialized
INFO - 2023-05-06 08:55:14 --> Utf8 Class Initialized
INFO - 2023-05-06 08:55:14 --> URI Class Initialized
INFO - 2023-05-06 08:55:14 --> Router Class Initialized
INFO - 2023-05-06 08:55:14 --> Output Class Initialized
INFO - 2023-05-06 08:55:14 --> Security Class Initialized
INFO - 2023-05-06 08:55:14 --> Input Class Initialized
INFO - 2023-05-06 08:55:14 --> Language Class Initialized
ERROR - 2023-05-06 08:55:14 --> 404 Page Not Found: Js/scripts.js
INFO - 2023-05-06 08:56:47 --> Config Class Initialized
INFO - 2023-05-06 08:56:47 --> Hooks Class Initialized
INFO - 2023-05-06 08:56:47 --> Utf8 Class Initialized
INFO - 2023-05-06 08:56:47 --> URI Class Initialized
INFO - 2023-05-06 08:56:47 --> Router Class Initialized
INFO - 2023-05-06 08:56:47 --> Output Class Initialized
INFO - 2023-05-06 08:56:47 --> Security Class Initialized
INFO - 2023-05-06 08:56:47 --> Input Class Initialized
INFO - 2023-05-06 08:56:47 --> Language Class Initialized
INFO - 2023-05-06 08:56:47 --> Loader Class Initialized
INFO - 2023-05-06 08:56:47 --> Helper loaded: url_helper
INFO - 2023-05-06 08:56:47 --> Helper loaded: form_helper
INFO - 2023-05-06 08:56:48 --> Database Driver Class Initialized
INFO - 2023-05-06 08:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:56:48 --> Form Validation Class Initialized
INFO - 2023-05-06 08:56:48 --> Controller Class Initialized
INFO - 2023-05-06 08:56:48 --> Model "M_tutor" initialized
INFO - 2023-05-06 08:56:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 08:56:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 08:56:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 08:56:48 --> Final output sent to browser
INFO - 2023-05-06 08:56:53 --> Config Class Initialized
INFO - 2023-05-06 08:56:53 --> Hooks Class Initialized
INFO - 2023-05-06 08:56:53 --> Utf8 Class Initialized
INFO - 2023-05-06 08:56:53 --> URI Class Initialized
INFO - 2023-05-06 08:56:53 --> Router Class Initialized
INFO - 2023-05-06 08:56:53 --> Output Class Initialized
INFO - 2023-05-06 08:56:53 --> Security Class Initialized
INFO - 2023-05-06 08:56:53 --> Input Class Initialized
INFO - 2023-05-06 08:56:53 --> Language Class Initialized
INFO - 2023-05-06 08:56:53 --> Loader Class Initialized
INFO - 2023-05-06 08:56:53 --> Helper loaded: url_helper
INFO - 2023-05-06 08:56:53 --> Helper loaded: form_helper
INFO - 2023-05-06 08:56:53 --> Database Driver Class Initialized
INFO - 2023-05-06 08:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:56:53 --> Form Validation Class Initialized
INFO - 2023-05-06 08:56:53 --> Controller Class Initialized
ERROR - 2023-05-06 08:56:53 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php 12
INFO - 2023-05-06 08:56:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:56:53 --> Final output sent to browser
INFO - 2023-05-06 08:56:54 --> Config Class Initialized
INFO - 2023-05-06 08:56:54 --> Hooks Class Initialized
INFO - 2023-05-06 08:56:54 --> Utf8 Class Initialized
INFO - 2023-05-06 08:56:54 --> URI Class Initialized
INFO - 2023-05-06 08:56:54 --> Router Class Initialized
INFO - 2023-05-06 08:56:54 --> Output Class Initialized
INFO - 2023-05-06 08:56:54 --> Security Class Initialized
INFO - 2023-05-06 08:56:54 --> Input Class Initialized
INFO - 2023-05-06 08:56:54 --> Language Class Initialized
INFO - 2023-05-06 08:56:54 --> Loader Class Initialized
INFO - 2023-05-06 08:56:54 --> Helper loaded: url_helper
INFO - 2023-05-06 08:56:54 --> Helper loaded: form_helper
INFO - 2023-05-06 08:56:54 --> Database Driver Class Initialized
INFO - 2023-05-06 08:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:56:54 --> Form Validation Class Initialized
INFO - 2023-05-06 08:56:54 --> Controller Class Initialized
ERROR - 2023-05-06 08:56:54 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php 12
INFO - 2023-05-06 08:56:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:56:54 --> Final output sent to browser
INFO - 2023-05-06 08:57:00 --> Config Class Initialized
INFO - 2023-05-06 08:57:00 --> Hooks Class Initialized
INFO - 2023-05-06 08:57:00 --> Utf8 Class Initialized
INFO - 2023-05-06 08:57:00 --> URI Class Initialized
INFO - 2023-05-06 08:57:00 --> Router Class Initialized
INFO - 2023-05-06 08:57:00 --> Output Class Initialized
INFO - 2023-05-06 08:57:00 --> Security Class Initialized
INFO - 2023-05-06 08:57:00 --> Input Class Initialized
INFO - 2023-05-06 08:57:00 --> Language Class Initialized
INFO - 2023-05-06 08:57:00 --> Loader Class Initialized
INFO - 2023-05-06 08:57:00 --> Helper loaded: url_helper
INFO - 2023-05-06 08:57:00 --> Helper loaded: form_helper
INFO - 2023-05-06 08:57:00 --> Database Driver Class Initialized
INFO - 2023-05-06 08:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:57:00 --> Form Validation Class Initialized
INFO - 2023-05-06 08:57:00 --> Controller Class Initialized
ERROR - 2023-05-06 08:57:00 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php 12
INFO - 2023-05-06 08:57:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:57:00 --> Final output sent to browser
INFO - 2023-05-06 08:58:21 --> Config Class Initialized
INFO - 2023-05-06 08:58:21 --> Hooks Class Initialized
INFO - 2023-05-06 08:58:21 --> Utf8 Class Initialized
INFO - 2023-05-06 08:58:21 --> URI Class Initialized
INFO - 2023-05-06 08:58:21 --> Router Class Initialized
INFO - 2023-05-06 08:58:21 --> Output Class Initialized
INFO - 2023-05-06 08:58:21 --> Security Class Initialized
INFO - 2023-05-06 08:58:21 --> Input Class Initialized
INFO - 2023-05-06 08:58:21 --> Language Class Initialized
INFO - 2023-05-06 08:58:21 --> Loader Class Initialized
INFO - 2023-05-06 08:58:21 --> Helper loaded: url_helper
INFO - 2023-05-06 08:58:21 --> Helper loaded: form_helper
INFO - 2023-05-06 08:58:21 --> Database Driver Class Initialized
INFO - 2023-05-06 08:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:58:21 --> Form Validation Class Initialized
INFO - 2023-05-06 08:58:21 --> Controller Class Initialized
ERROR - 2023-05-06 08:58:21 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php 12
INFO - 2023-05-06 08:58:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:58:21 --> Final output sent to browser
INFO - 2023-05-06 08:58:32 --> Config Class Initialized
INFO - 2023-05-06 08:58:32 --> Hooks Class Initialized
INFO - 2023-05-06 08:58:32 --> Utf8 Class Initialized
INFO - 2023-05-06 08:58:32 --> URI Class Initialized
INFO - 2023-05-06 08:58:32 --> Router Class Initialized
INFO - 2023-05-06 08:58:32 --> Output Class Initialized
INFO - 2023-05-06 08:58:32 --> Security Class Initialized
INFO - 2023-05-06 08:58:32 --> Input Class Initialized
INFO - 2023-05-06 08:58:32 --> Language Class Initialized
INFO - 2023-05-06 08:58:32 --> Loader Class Initialized
INFO - 2023-05-06 08:58:32 --> Helper loaded: url_helper
INFO - 2023-05-06 08:58:32 --> Helper loaded: form_helper
INFO - 2023-05-06 08:58:32 --> Database Driver Class Initialized
INFO - 2023-05-06 08:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:58:32 --> Form Validation Class Initialized
INFO - 2023-05-06 08:58:32 --> Controller Class Initialized
ERROR - 2023-05-06 08:58:32 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php 12
INFO - 2023-05-06 08:58:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:58:32 --> Final output sent to browser
INFO - 2023-05-06 08:58:54 --> Config Class Initialized
INFO - 2023-05-06 08:58:54 --> Hooks Class Initialized
INFO - 2023-05-06 08:58:54 --> Utf8 Class Initialized
INFO - 2023-05-06 08:58:54 --> URI Class Initialized
INFO - 2023-05-06 08:58:54 --> Router Class Initialized
INFO - 2023-05-06 08:58:54 --> Output Class Initialized
INFO - 2023-05-06 08:58:54 --> Security Class Initialized
INFO - 2023-05-06 08:58:54 --> Input Class Initialized
INFO - 2023-05-06 08:58:54 --> Language Class Initialized
INFO - 2023-05-06 08:58:54 --> Loader Class Initialized
INFO - 2023-05-06 08:58:54 --> Helper loaded: url_helper
INFO - 2023-05-06 08:58:54 --> Helper loaded: form_helper
INFO - 2023-05-06 08:58:54 --> Database Driver Class Initialized
INFO - 2023-05-06 08:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:58:54 --> Form Validation Class Initialized
INFO - 2023-05-06 08:58:54 --> Controller Class Initialized
ERROR - 2023-05-06 08:58:54 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php 12
INFO - 2023-05-06 08:58:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:58:54 --> Final output sent to browser
INFO - 2023-05-06 08:59:40 --> Config Class Initialized
INFO - 2023-05-06 08:59:40 --> Hooks Class Initialized
INFO - 2023-05-06 08:59:40 --> Utf8 Class Initialized
INFO - 2023-05-06 08:59:40 --> URI Class Initialized
INFO - 2023-05-06 08:59:40 --> Router Class Initialized
INFO - 2023-05-06 08:59:40 --> Output Class Initialized
INFO - 2023-05-06 08:59:40 --> Security Class Initialized
INFO - 2023-05-06 08:59:40 --> Input Class Initialized
INFO - 2023-05-06 08:59:40 --> Language Class Initialized
INFO - 2023-05-06 08:59:40 --> Loader Class Initialized
INFO - 2023-05-06 08:59:40 --> Helper loaded: url_helper
INFO - 2023-05-06 08:59:40 --> Helper loaded: form_helper
INFO - 2023-05-06 08:59:40 --> Database Driver Class Initialized
INFO - 2023-05-06 08:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 08:59:40 --> Form Validation Class Initialized
INFO - 2023-05-06 08:59:40 --> Controller Class Initialized
INFO - 2023-05-06 08:59:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 08:59:40 --> Final output sent to browser
INFO - 2023-05-06 09:00:13 --> Config Class Initialized
INFO - 2023-05-06 09:00:13 --> Hooks Class Initialized
INFO - 2023-05-06 09:00:13 --> Utf8 Class Initialized
INFO - 2023-05-06 09:00:13 --> URI Class Initialized
INFO - 2023-05-06 09:00:13 --> Router Class Initialized
INFO - 2023-05-06 09:00:13 --> Output Class Initialized
INFO - 2023-05-06 09:00:13 --> Security Class Initialized
INFO - 2023-05-06 09:00:13 --> Input Class Initialized
INFO - 2023-05-06 09:00:13 --> Language Class Initialized
INFO - 2023-05-06 09:00:13 --> Loader Class Initialized
INFO - 2023-05-06 09:00:13 --> Helper loaded: url_helper
INFO - 2023-05-06 09:00:13 --> Helper loaded: form_helper
INFO - 2023-05-06 09:00:13 --> Database Driver Class Initialized
INFO - 2023-05-06 09:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:00:13 --> Form Validation Class Initialized
INFO - 2023-05-06 09:00:13 --> Controller Class Initialized
INFO - 2023-05-06 09:00:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 09:00:13 --> Final output sent to browser
INFO - 2023-05-06 09:00:14 --> Config Class Initialized
INFO - 2023-05-06 09:00:14 --> Hooks Class Initialized
INFO - 2023-05-06 09:00:14 --> Utf8 Class Initialized
INFO - 2023-05-06 09:00:14 --> URI Class Initialized
INFO - 2023-05-06 09:00:14 --> Router Class Initialized
INFO - 2023-05-06 09:00:14 --> Output Class Initialized
INFO - 2023-05-06 09:00:14 --> Security Class Initialized
INFO - 2023-05-06 09:00:14 --> Input Class Initialized
INFO - 2023-05-06 09:00:14 --> Language Class Initialized
INFO - 2023-05-06 09:00:14 --> Loader Class Initialized
INFO - 2023-05-06 09:00:14 --> Helper loaded: url_helper
INFO - 2023-05-06 09:00:14 --> Helper loaded: form_helper
INFO - 2023-05-06 09:00:14 --> Database Driver Class Initialized
INFO - 2023-05-06 09:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:00:15 --> Form Validation Class Initialized
INFO - 2023-05-06 09:00:15 --> Controller Class Initialized
INFO - 2023-05-06 09:00:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 09:00:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 09:00:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 09:00:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 09:00:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 09:00:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 09:00:15 --> Final output sent to browser
INFO - 2023-05-06 09:00:26 --> Config Class Initialized
INFO - 2023-05-06 09:00:26 --> Hooks Class Initialized
INFO - 2023-05-06 09:00:26 --> Utf8 Class Initialized
INFO - 2023-05-06 09:00:26 --> URI Class Initialized
INFO - 2023-05-06 09:00:26 --> Router Class Initialized
INFO - 2023-05-06 09:00:26 --> Output Class Initialized
INFO - 2023-05-06 09:00:26 --> Security Class Initialized
INFO - 2023-05-06 09:00:26 --> Input Class Initialized
INFO - 2023-05-06 09:00:26 --> Language Class Initialized
INFO - 2023-05-06 09:00:26 --> Loader Class Initialized
INFO - 2023-05-06 09:00:26 --> Helper loaded: url_helper
INFO - 2023-05-06 09:00:26 --> Helper loaded: form_helper
INFO - 2023-05-06 09:00:26 --> Database Driver Class Initialized
INFO - 2023-05-06 09:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:00:26 --> Form Validation Class Initialized
INFO - 2023-05-06 09:00:26 --> Controller Class Initialized
INFO - 2023-05-06 09:00:26 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:00:26 --> Config Class Initialized
INFO - 2023-05-06 09:00:26 --> Hooks Class Initialized
INFO - 2023-05-06 09:00:26 --> Utf8 Class Initialized
INFO - 2023-05-06 09:00:26 --> URI Class Initialized
INFO - 2023-05-06 09:00:26 --> Router Class Initialized
INFO - 2023-05-06 09:00:26 --> Output Class Initialized
INFO - 2023-05-06 09:00:26 --> Security Class Initialized
INFO - 2023-05-06 09:00:26 --> Input Class Initialized
INFO - 2023-05-06 09:00:26 --> Language Class Initialized
INFO - 2023-05-06 09:00:26 --> Loader Class Initialized
INFO - 2023-05-06 09:00:26 --> Helper loaded: url_helper
INFO - 2023-05-06 09:00:26 --> Helper loaded: form_helper
INFO - 2023-05-06 09:00:26 --> Database Driver Class Initialized
INFO - 2023-05-06 09:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:00:26 --> Form Validation Class Initialized
INFO - 2023-05-06 09:00:26 --> Controller Class Initialized
INFO - 2023-05-06 09:00:26 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:00:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 09:00:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 09:00:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 09:00:26 --> Final output sent to browser
INFO - 2023-05-06 09:02:25 --> Config Class Initialized
INFO - 2023-05-06 09:02:25 --> Hooks Class Initialized
INFO - 2023-05-06 09:02:25 --> Utf8 Class Initialized
INFO - 2023-05-06 09:02:25 --> URI Class Initialized
ERROR - 2023-05-06 09:02:25 --> Severity: Parsing Error --> syntax error, unexpected '$route' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\config\routes.php 57
INFO - 2023-05-06 09:02:32 --> Config Class Initialized
INFO - 2023-05-06 09:02:32 --> Hooks Class Initialized
INFO - 2023-05-06 09:02:32 --> Utf8 Class Initialized
INFO - 2023-05-06 09:02:32 --> URI Class Initialized
ERROR - 2023-05-06 09:02:32 --> Severity: Parsing Error --> syntax error, unexpected '$route' (T_VARIABLE) C:\xampp\htdocs\sistemdiagnosa\application\config\routes.php 57
INFO - 2023-05-06 09:02:50 --> Config Class Initialized
INFO - 2023-05-06 09:02:50 --> Hooks Class Initialized
INFO - 2023-05-06 09:02:50 --> Utf8 Class Initialized
INFO - 2023-05-06 09:02:50 --> URI Class Initialized
INFO - 2023-05-06 09:02:50 --> Router Class Initialized
INFO - 2023-05-06 09:02:50 --> Output Class Initialized
INFO - 2023-05-06 09:02:50 --> Security Class Initialized
INFO - 2023-05-06 09:02:50 --> Input Class Initialized
INFO - 2023-05-06 09:02:50 --> Language Class Initialized
INFO - 2023-05-06 09:02:50 --> Loader Class Initialized
INFO - 2023-05-06 09:02:50 --> Helper loaded: url_helper
INFO - 2023-05-06 09:02:50 --> Helper loaded: form_helper
INFO - 2023-05-06 09:02:50 --> Database Driver Class Initialized
INFO - 2023-05-06 09:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:02:50 --> Form Validation Class Initialized
INFO - 2023-05-06 09:02:50 --> Controller Class Initialized
INFO - 2023-05-06 09:02:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 09:02:50 --> Final output sent to browser
INFO - 2023-05-06 09:02:52 --> Config Class Initialized
INFO - 2023-05-06 09:02:52 --> Hooks Class Initialized
INFO - 2023-05-06 09:02:52 --> Utf8 Class Initialized
INFO - 2023-05-06 09:02:52 --> URI Class Initialized
INFO - 2023-05-06 09:02:52 --> Router Class Initialized
INFO - 2023-05-06 09:02:52 --> Output Class Initialized
INFO - 2023-05-06 09:02:52 --> Security Class Initialized
INFO - 2023-05-06 09:02:52 --> Input Class Initialized
INFO - 2023-05-06 09:02:52 --> Language Class Initialized
INFO - 2023-05-06 09:02:52 --> Loader Class Initialized
INFO - 2023-05-06 09:02:52 --> Helper loaded: url_helper
INFO - 2023-05-06 09:02:52 --> Helper loaded: form_helper
INFO - 2023-05-06 09:02:52 --> Database Driver Class Initialized
INFO - 2023-05-06 09:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:02:52 --> Form Validation Class Initialized
INFO - 2023-05-06 09:02:52 --> Controller Class Initialized
INFO - 2023-05-06 09:02:52 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:02:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 09:02:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 09:02:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 09:02:52 --> Final output sent to browser
INFO - 2023-05-06 09:02:56 --> Config Class Initialized
INFO - 2023-05-06 09:02:56 --> Hooks Class Initialized
INFO - 2023-05-06 09:02:56 --> Utf8 Class Initialized
INFO - 2023-05-06 09:02:56 --> URI Class Initialized
INFO - 2023-05-06 09:02:56 --> Router Class Initialized
INFO - 2023-05-06 09:02:56 --> Output Class Initialized
INFO - 2023-05-06 09:02:56 --> Security Class Initialized
INFO - 2023-05-06 09:02:56 --> Input Class Initialized
INFO - 2023-05-06 09:02:56 --> Language Class Initialized
INFO - 2023-05-06 09:02:56 --> Loader Class Initialized
INFO - 2023-05-06 09:02:56 --> Helper loaded: url_helper
INFO - 2023-05-06 09:02:56 --> Helper loaded: form_helper
INFO - 2023-05-06 09:02:56 --> Database Driver Class Initialized
INFO - 2023-05-06 09:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:02:56 --> Form Validation Class Initialized
INFO - 2023-05-06 09:02:56 --> Controller Class Initialized
INFO - 2023-05-06 09:02:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 09:02:56 --> Final output sent to browser
INFO - 2023-05-06 09:03:38 --> Config Class Initialized
INFO - 2023-05-06 09:03:38 --> Hooks Class Initialized
INFO - 2023-05-06 09:03:38 --> Utf8 Class Initialized
INFO - 2023-05-06 09:03:38 --> URI Class Initialized
INFO - 2023-05-06 09:03:38 --> Router Class Initialized
INFO - 2023-05-06 09:03:38 --> Output Class Initialized
INFO - 2023-05-06 09:03:38 --> Security Class Initialized
INFO - 2023-05-06 09:03:38 --> Input Class Initialized
INFO - 2023-05-06 09:03:38 --> Language Class Initialized
INFO - 2023-05-06 09:03:38 --> Loader Class Initialized
INFO - 2023-05-06 09:03:38 --> Helper loaded: url_helper
INFO - 2023-05-06 09:03:38 --> Helper loaded: form_helper
INFO - 2023-05-06 09:03:38 --> Database Driver Class Initialized
INFO - 2023-05-06 09:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:03:38 --> Form Validation Class Initialized
INFO - 2023-05-06 09:03:38 --> Controller Class Initialized
INFO - 2023-05-06 09:03:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 09:03:38 --> Final output sent to browser
INFO - 2023-05-06 09:06:45 --> Config Class Initialized
INFO - 2023-05-06 09:06:45 --> Hooks Class Initialized
INFO - 2023-05-06 09:06:45 --> Utf8 Class Initialized
INFO - 2023-05-06 09:06:45 --> URI Class Initialized
INFO - 2023-05-06 09:06:45 --> Router Class Initialized
INFO - 2023-05-06 09:06:45 --> Output Class Initialized
INFO - 2023-05-06 09:06:45 --> Security Class Initialized
INFO - 2023-05-06 09:06:45 --> Input Class Initialized
INFO - 2023-05-06 09:06:45 --> Language Class Initialized
INFO - 2023-05-06 09:06:45 --> Loader Class Initialized
INFO - 2023-05-06 09:06:45 --> Helper loaded: url_helper
INFO - 2023-05-06 09:06:45 --> Helper loaded: form_helper
INFO - 2023-05-06 09:06:45 --> Database Driver Class Initialized
INFO - 2023-05-06 09:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:06:45 --> Form Validation Class Initialized
INFO - 2023-05-06 09:06:45 --> Controller Class Initialized
INFO - 2023-05-06 09:06:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 09:06:45 --> Final output sent to browser
INFO - 2023-05-06 09:06:50 --> Config Class Initialized
INFO - 2023-05-06 09:06:50 --> Hooks Class Initialized
INFO - 2023-05-06 09:06:50 --> Utf8 Class Initialized
INFO - 2023-05-06 09:06:50 --> URI Class Initialized
INFO - 2023-05-06 09:06:50 --> Router Class Initialized
INFO - 2023-05-06 09:06:50 --> Output Class Initialized
INFO - 2023-05-06 09:06:50 --> Security Class Initialized
INFO - 2023-05-06 09:06:50 --> Input Class Initialized
INFO - 2023-05-06 09:06:50 --> Language Class Initialized
INFO - 2023-05-06 09:06:50 --> Loader Class Initialized
INFO - 2023-05-06 09:06:50 --> Helper loaded: url_helper
INFO - 2023-05-06 09:06:50 --> Helper loaded: form_helper
INFO - 2023-05-06 09:06:50 --> Database Driver Class Initialized
INFO - 2023-05-06 09:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:06:50 --> Form Validation Class Initialized
INFO - 2023-05-06 09:06:50 --> Controller Class Initialized
INFO - 2023-05-06 09:06:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 09:06:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-06 09:06:50 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\xampp\htdocs\sistemdiagnosa\application\views\_partials\sidebar.php 89
INFO - 2023-05-06 09:07:22 --> Config Class Initialized
INFO - 2023-05-06 09:07:22 --> Hooks Class Initialized
INFO - 2023-05-06 09:07:22 --> Utf8 Class Initialized
INFO - 2023-05-06 09:07:22 --> URI Class Initialized
INFO - 2023-05-06 09:07:22 --> Router Class Initialized
INFO - 2023-05-06 09:07:22 --> Output Class Initialized
INFO - 2023-05-06 09:07:22 --> Security Class Initialized
INFO - 2023-05-06 09:07:22 --> Input Class Initialized
INFO - 2023-05-06 09:07:22 --> Language Class Initialized
INFO - 2023-05-06 09:07:22 --> Loader Class Initialized
INFO - 2023-05-06 09:07:22 --> Helper loaded: url_helper
INFO - 2023-05-06 09:07:22 --> Helper loaded: form_helper
INFO - 2023-05-06 09:07:22 --> Database Driver Class Initialized
INFO - 2023-05-06 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:07:22 --> Form Validation Class Initialized
INFO - 2023-05-06 09:07:22 --> Controller Class Initialized
INFO - 2023-05-06 09:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 09:07:22 --> Final output sent to browser
INFO - 2023-05-06 09:07:25 --> Config Class Initialized
INFO - 2023-05-06 09:07:25 --> Hooks Class Initialized
INFO - 2023-05-06 09:07:25 --> Utf8 Class Initialized
INFO - 2023-05-06 09:07:25 --> URI Class Initialized
INFO - 2023-05-06 09:07:25 --> Router Class Initialized
INFO - 2023-05-06 09:07:25 --> Output Class Initialized
INFO - 2023-05-06 09:07:25 --> Security Class Initialized
INFO - 2023-05-06 09:07:25 --> Input Class Initialized
INFO - 2023-05-06 09:07:25 --> Language Class Initialized
INFO - 2023-05-06 09:07:25 --> Loader Class Initialized
INFO - 2023-05-06 09:07:25 --> Helper loaded: url_helper
INFO - 2023-05-06 09:07:25 --> Helper loaded: form_helper
INFO - 2023-05-06 09:07:25 --> Database Driver Class Initialized
INFO - 2023-05-06 09:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:07:25 --> Form Validation Class Initialized
INFO - 2023-05-06 09:07:25 --> Controller Class Initialized
INFO - 2023-05-06 09:07:25 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:07:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 09:07:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 09:07:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 09:07:25 --> Final output sent to browser
INFO - 2023-05-06 09:09:01 --> Config Class Initialized
INFO - 2023-05-06 09:09:01 --> Hooks Class Initialized
INFO - 2023-05-06 09:09:01 --> Utf8 Class Initialized
INFO - 2023-05-06 09:09:01 --> URI Class Initialized
INFO - 2023-05-06 09:09:01 --> Router Class Initialized
INFO - 2023-05-06 09:09:01 --> Output Class Initialized
INFO - 2023-05-06 09:09:01 --> Security Class Initialized
INFO - 2023-05-06 09:09:01 --> Input Class Initialized
INFO - 2023-05-06 09:09:01 --> Language Class Initialized
INFO - 2023-05-06 09:09:01 --> Loader Class Initialized
INFO - 2023-05-06 09:09:01 --> Helper loaded: url_helper
INFO - 2023-05-06 09:09:01 --> Helper loaded: form_helper
INFO - 2023-05-06 09:09:01 --> Database Driver Class Initialized
INFO - 2023-05-06 09:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:09:01 --> Form Validation Class Initialized
INFO - 2023-05-06 09:09:01 --> Controller Class Initialized
INFO - 2023-05-06 09:09:01 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:09:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 09:09:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 09:09:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 09:09:01 --> Final output sent to browser
INFO - 2023-05-06 09:09:04 --> Config Class Initialized
INFO - 2023-05-06 09:09:04 --> Hooks Class Initialized
INFO - 2023-05-06 09:09:04 --> Utf8 Class Initialized
INFO - 2023-05-06 09:09:04 --> URI Class Initialized
INFO - 2023-05-06 09:09:04 --> Router Class Initialized
INFO - 2023-05-06 09:09:04 --> Output Class Initialized
INFO - 2023-05-06 09:09:04 --> Security Class Initialized
INFO - 2023-05-06 09:09:04 --> Input Class Initialized
INFO - 2023-05-06 09:09:04 --> Language Class Initialized
INFO - 2023-05-06 09:09:04 --> Loader Class Initialized
INFO - 2023-05-06 09:09:04 --> Helper loaded: url_helper
INFO - 2023-05-06 09:09:04 --> Helper loaded: form_helper
INFO - 2023-05-06 09:09:04 --> Database Driver Class Initialized
INFO - 2023-05-06 09:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:09:04 --> Form Validation Class Initialized
INFO - 2023-05-06 09:09:04 --> Controller Class Initialized
INFO - 2023-05-06 09:09:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 09:09:04 --> Final output sent to browser
INFO - 2023-05-06 09:09:05 --> Config Class Initialized
INFO - 2023-05-06 09:09:05 --> Hooks Class Initialized
INFO - 2023-05-06 09:09:05 --> Utf8 Class Initialized
INFO - 2023-05-06 09:09:05 --> URI Class Initialized
INFO - 2023-05-06 09:09:05 --> Router Class Initialized
INFO - 2023-05-06 09:09:05 --> Output Class Initialized
INFO - 2023-05-06 09:09:05 --> Security Class Initialized
INFO - 2023-05-06 09:09:05 --> Input Class Initialized
INFO - 2023-05-06 09:09:05 --> Language Class Initialized
INFO - 2023-05-06 09:09:05 --> Loader Class Initialized
INFO - 2023-05-06 09:09:05 --> Helper loaded: url_helper
INFO - 2023-05-06 09:09:05 --> Helper loaded: form_helper
INFO - 2023-05-06 09:09:05 --> Database Driver Class Initialized
INFO - 2023-05-06 09:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:09:05 --> Form Validation Class Initialized
INFO - 2023-05-06 09:09:05 --> Controller Class Initialized
INFO - 2023-05-06 09:09:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 09:09:05 --> Final output sent to browser
INFO - 2023-05-06 09:09:07 --> Config Class Initialized
INFO - 2023-05-06 09:09:07 --> Hooks Class Initialized
INFO - 2023-05-06 09:09:07 --> Utf8 Class Initialized
INFO - 2023-05-06 09:09:07 --> URI Class Initialized
INFO - 2023-05-06 09:09:07 --> Router Class Initialized
INFO - 2023-05-06 09:09:07 --> Output Class Initialized
INFO - 2023-05-06 09:09:07 --> Security Class Initialized
INFO - 2023-05-06 09:09:07 --> Input Class Initialized
INFO - 2023-05-06 09:09:07 --> Language Class Initialized
ERROR - 2023-05-06 09:09:07 --> 404 Page Not Found: Login/proses
INFO - 2023-05-06 09:12:49 --> Config Class Initialized
INFO - 2023-05-06 09:12:49 --> Hooks Class Initialized
INFO - 2023-05-06 09:12:49 --> Utf8 Class Initialized
INFO - 2023-05-06 09:12:49 --> URI Class Initialized
INFO - 2023-05-06 09:12:49 --> Router Class Initialized
INFO - 2023-05-06 09:12:49 --> Output Class Initialized
INFO - 2023-05-06 09:12:49 --> Security Class Initialized
INFO - 2023-05-06 09:12:49 --> Input Class Initialized
INFO - 2023-05-06 09:12:49 --> Language Class Initialized
INFO - 2023-05-06 09:12:49 --> Loader Class Initialized
INFO - 2023-05-06 09:12:49 --> Helper loaded: url_helper
INFO - 2023-05-06 09:12:49 --> Helper loaded: form_helper
INFO - 2023-05-06 09:12:49 --> Database Driver Class Initialized
INFO - 2023-05-06 09:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:12:49 --> Form Validation Class Initialized
INFO - 2023-05-06 09:12:49 --> Controller Class Initialized
INFO - 2023-05-06 09:12:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 09:12:49 --> Final output sent to browser
INFO - 2023-05-06 09:12:53 --> Config Class Initialized
INFO - 2023-05-06 09:12:53 --> Hooks Class Initialized
INFO - 2023-05-06 09:12:53 --> Utf8 Class Initialized
INFO - 2023-05-06 09:12:53 --> URI Class Initialized
INFO - 2023-05-06 09:12:53 --> Router Class Initialized
INFO - 2023-05-06 09:12:53 --> Output Class Initialized
INFO - 2023-05-06 09:12:53 --> Security Class Initialized
INFO - 2023-05-06 09:12:53 --> Input Class Initialized
INFO - 2023-05-06 09:12:53 --> Language Class Initialized
INFO - 2023-05-06 09:12:53 --> Loader Class Initialized
INFO - 2023-05-06 09:12:53 --> Helper loaded: url_helper
INFO - 2023-05-06 09:12:53 --> Helper loaded: form_helper
INFO - 2023-05-06 09:12:53 --> Database Driver Class Initialized
INFO - 2023-05-06 09:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:12:53 --> Form Validation Class Initialized
INFO - 2023-05-06 09:12:53 --> Controller Class Initialized
ERROR - 2023-05-06 09:12:53 --> Severity: Notice --> Undefined property: Welcome::$m_tutor C:\xampp\htdocs\sistemdiagnosa\application\controllers\Welcome.php 30
ERROR - 2023-05-06 09:12:53 --> Severity: Error --> Call to a member function login_user() on null C:\xampp\htdocs\sistemdiagnosa\application\controllers\Welcome.php 30
INFO - 2023-05-06 09:12:59 --> Config Class Initialized
INFO - 2023-05-06 09:12:59 --> Hooks Class Initialized
INFO - 2023-05-06 09:12:59 --> Utf8 Class Initialized
INFO - 2023-05-06 09:12:59 --> URI Class Initialized
INFO - 2023-05-06 09:12:59 --> Router Class Initialized
INFO - 2023-05-06 09:12:59 --> Output Class Initialized
INFO - 2023-05-06 09:12:59 --> Security Class Initialized
INFO - 2023-05-06 09:12:59 --> Input Class Initialized
INFO - 2023-05-06 09:12:59 --> Language Class Initialized
INFO - 2023-05-06 09:12:59 --> Loader Class Initialized
INFO - 2023-05-06 09:12:59 --> Helper loaded: url_helper
INFO - 2023-05-06 09:12:59 --> Helper loaded: form_helper
INFO - 2023-05-06 09:12:59 --> Database Driver Class Initialized
INFO - 2023-05-06 09:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:12:59 --> Form Validation Class Initialized
INFO - 2023-05-06 09:12:59 --> Controller Class Initialized
INFO - 2023-05-06 09:12:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 09:12:59 --> Final output sent to browser
INFO - 2023-05-06 09:18:29 --> Config Class Initialized
INFO - 2023-05-06 09:18:29 --> Hooks Class Initialized
INFO - 2023-05-06 09:18:29 --> Utf8 Class Initialized
INFO - 2023-05-06 09:18:29 --> URI Class Initialized
INFO - 2023-05-06 09:18:29 --> Router Class Initialized
INFO - 2023-05-06 09:18:29 --> Output Class Initialized
INFO - 2023-05-06 09:18:29 --> Security Class Initialized
INFO - 2023-05-06 09:18:29 --> Input Class Initialized
INFO - 2023-05-06 09:18:29 --> Language Class Initialized
INFO - 2023-05-06 09:18:29 --> Loader Class Initialized
INFO - 2023-05-06 09:18:29 --> Helper loaded: url_helper
INFO - 2023-05-06 09:18:29 --> Helper loaded: form_helper
INFO - 2023-05-06 09:18:29 --> Database Driver Class Initialized
INFO - 2023-05-06 09:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:18:29 --> Form Validation Class Initialized
INFO - 2023-05-06 09:18:29 --> Controller Class Initialized
ERROR - 2023-05-06 09:18:29 --> Severity: Notice --> Undefined property: C_home::$m_tutor C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 7
ERROR - 2023-05-06 09:18:29 --> Severity: Error --> Call to a member function cek_login() on null C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 7
INFO - 2023-05-06 09:18:39 --> Config Class Initialized
INFO - 2023-05-06 09:18:39 --> Hooks Class Initialized
INFO - 2023-05-06 09:18:39 --> Utf8 Class Initialized
INFO - 2023-05-06 09:18:39 --> URI Class Initialized
INFO - 2023-05-06 09:18:39 --> Router Class Initialized
INFO - 2023-05-06 09:18:39 --> Output Class Initialized
INFO - 2023-05-06 09:18:39 --> Security Class Initialized
INFO - 2023-05-06 09:18:39 --> Input Class Initialized
INFO - 2023-05-06 09:18:39 --> Language Class Initialized
INFO - 2023-05-06 09:18:39 --> Loader Class Initialized
INFO - 2023-05-06 09:18:39 --> Helper loaded: url_helper
INFO - 2023-05-06 09:18:39 --> Helper loaded: form_helper
INFO - 2023-05-06 09:18:39 --> Database Driver Class Initialized
INFO - 2023-05-06 09:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:18:39 --> Form Validation Class Initialized
INFO - 2023-05-06 09:18:39 --> Controller Class Initialized
INFO - 2023-05-06 09:18:39 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:18:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 09:18:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 09:18:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 09:18:39 --> Final output sent to browser
INFO - 2023-05-06 09:18:47 --> Config Class Initialized
INFO - 2023-05-06 09:18:47 --> Hooks Class Initialized
INFO - 2023-05-06 09:18:47 --> Utf8 Class Initialized
INFO - 2023-05-06 09:18:47 --> URI Class Initialized
INFO - 2023-05-06 09:18:47 --> Router Class Initialized
INFO - 2023-05-06 09:18:47 --> Output Class Initialized
INFO - 2023-05-06 09:18:47 --> Security Class Initialized
INFO - 2023-05-06 09:18:47 --> Input Class Initialized
INFO - 2023-05-06 09:18:47 --> Language Class Initialized
INFO - 2023-05-06 09:18:47 --> Loader Class Initialized
INFO - 2023-05-06 09:18:47 --> Helper loaded: url_helper
INFO - 2023-05-06 09:18:47 --> Helper loaded: form_helper
INFO - 2023-05-06 09:18:47 --> Database Driver Class Initialized
INFO - 2023-05-06 09:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:18:47 --> Form Validation Class Initialized
INFO - 2023-05-06 09:18:47 --> Controller Class Initialized
INFO - 2023-05-06 09:18:47 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:18:47 --> Config Class Initialized
INFO - 2023-05-06 09:18:47 --> Hooks Class Initialized
INFO - 2023-05-06 09:18:47 --> Utf8 Class Initialized
INFO - 2023-05-06 09:18:47 --> URI Class Initialized
INFO - 2023-05-06 09:18:47 --> Router Class Initialized
INFO - 2023-05-06 09:18:47 --> Output Class Initialized
INFO - 2023-05-06 09:18:47 --> Security Class Initialized
INFO - 2023-05-06 09:18:47 --> Input Class Initialized
INFO - 2023-05-06 09:18:47 --> Language Class Initialized
INFO - 2023-05-06 09:18:47 --> Loader Class Initialized
INFO - 2023-05-06 09:18:47 --> Helper loaded: url_helper
INFO - 2023-05-06 09:18:47 --> Helper loaded: form_helper
INFO - 2023-05-06 09:18:47 --> Database Driver Class Initialized
INFO - 2023-05-06 09:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:18:47 --> Form Validation Class Initialized
INFO - 2023-05-06 09:18:47 --> Controller Class Initialized
ERROR - 2023-05-06 09:18:47 --> Severity: Notice --> Undefined property: C_home::$m_tutor C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 7
ERROR - 2023-05-06 09:18:47 --> Severity: Error --> Call to a member function cek_login() on null C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_home.php 7
INFO - 2023-05-06 09:19:33 --> Config Class Initialized
INFO - 2023-05-06 09:19:33 --> Hooks Class Initialized
INFO - 2023-05-06 09:19:33 --> Utf8 Class Initialized
INFO - 2023-05-06 09:19:33 --> URI Class Initialized
INFO - 2023-05-06 09:19:33 --> Router Class Initialized
INFO - 2023-05-06 09:19:33 --> Output Class Initialized
INFO - 2023-05-06 09:19:33 --> Security Class Initialized
INFO - 2023-05-06 09:19:33 --> Input Class Initialized
INFO - 2023-05-06 09:19:33 --> Language Class Initialized
INFO - 2023-05-06 09:19:33 --> Loader Class Initialized
INFO - 2023-05-06 09:19:33 --> Helper loaded: url_helper
INFO - 2023-05-06 09:19:33 --> Helper loaded: form_helper
INFO - 2023-05-06 09:19:33 --> Database Driver Class Initialized
INFO - 2023-05-06 09:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:19:33 --> Form Validation Class Initialized
INFO - 2023-05-06 09:19:33 --> Controller Class Initialized
INFO - 2023-05-06 09:19:33 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:19:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 09:19:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 09:19:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 09:19:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 09:19:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 09:19:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 09:19:33 --> Final output sent to browser
INFO - 2023-05-06 09:19:37 --> Config Class Initialized
INFO - 2023-05-06 09:19:37 --> Hooks Class Initialized
INFO - 2023-05-06 09:19:37 --> Utf8 Class Initialized
INFO - 2023-05-06 09:19:37 --> URI Class Initialized
INFO - 2023-05-06 09:19:37 --> Router Class Initialized
INFO - 2023-05-06 09:19:37 --> Output Class Initialized
INFO - 2023-05-06 09:19:37 --> Security Class Initialized
INFO - 2023-05-06 09:19:37 --> Input Class Initialized
INFO - 2023-05-06 09:19:37 --> Language Class Initialized
INFO - 2023-05-06 09:19:37 --> Loader Class Initialized
INFO - 2023-05-06 09:19:38 --> Helper loaded: url_helper
INFO - 2023-05-06 09:19:38 --> Helper loaded: form_helper
INFO - 2023-05-06 09:19:38 --> Database Driver Class Initialized
INFO - 2023-05-06 09:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:19:38 --> Form Validation Class Initialized
INFO - 2023-05-06 09:19:38 --> Controller Class Initialized
INFO - 2023-05-06 09:19:38 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:19:38 --> Config Class Initialized
INFO - 2023-05-06 09:19:38 --> Hooks Class Initialized
INFO - 2023-05-06 09:19:38 --> Utf8 Class Initialized
INFO - 2023-05-06 09:19:38 --> URI Class Initialized
INFO - 2023-05-06 09:19:38 --> Router Class Initialized
INFO - 2023-05-06 09:19:38 --> Output Class Initialized
INFO - 2023-05-06 09:19:38 --> Security Class Initialized
INFO - 2023-05-06 09:19:38 --> Input Class Initialized
INFO - 2023-05-06 09:19:38 --> Language Class Initialized
INFO - 2023-05-06 09:19:38 --> Loader Class Initialized
INFO - 2023-05-06 09:19:38 --> Helper loaded: url_helper
INFO - 2023-05-06 09:19:38 --> Helper loaded: form_helper
INFO - 2023-05-06 09:19:38 --> Database Driver Class Initialized
INFO - 2023-05-06 09:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:19:38 --> Form Validation Class Initialized
INFO - 2023-05-06 09:19:38 --> Controller Class Initialized
INFO - 2023-05-06 09:19:38 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:19:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 09:19:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 09:19:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 09:19:38 --> Final output sent to browser
INFO - 2023-05-06 09:19:46 --> Config Class Initialized
INFO - 2023-05-06 09:19:46 --> Hooks Class Initialized
INFO - 2023-05-06 09:19:46 --> Utf8 Class Initialized
INFO - 2023-05-06 09:19:46 --> URI Class Initialized
INFO - 2023-05-06 09:19:46 --> Router Class Initialized
INFO - 2023-05-06 09:19:46 --> Output Class Initialized
INFO - 2023-05-06 09:19:46 --> Security Class Initialized
INFO - 2023-05-06 09:19:46 --> Input Class Initialized
INFO - 2023-05-06 09:19:46 --> Language Class Initialized
ERROR - 2023-05-06 09:19:46 --> 404 Page Not Found: Homr/index
INFO - 2023-05-06 09:19:50 --> Config Class Initialized
INFO - 2023-05-06 09:19:50 --> Hooks Class Initialized
INFO - 2023-05-06 09:19:50 --> Utf8 Class Initialized
INFO - 2023-05-06 09:19:50 --> URI Class Initialized
INFO - 2023-05-06 09:19:50 --> Router Class Initialized
INFO - 2023-05-06 09:19:50 --> Output Class Initialized
INFO - 2023-05-06 09:19:50 --> Security Class Initialized
INFO - 2023-05-06 09:19:50 --> Input Class Initialized
INFO - 2023-05-06 09:19:50 --> Language Class Initialized
INFO - 2023-05-06 09:19:50 --> Loader Class Initialized
INFO - 2023-05-06 09:19:50 --> Helper loaded: url_helper
INFO - 2023-05-06 09:19:50 --> Helper loaded: form_helper
INFO - 2023-05-06 09:19:50 --> Database Driver Class Initialized
INFO - 2023-05-06 09:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:19:50 --> Form Validation Class Initialized
INFO - 2023-05-06 09:19:50 --> Controller Class Initialized
INFO - 2023-05-06 09:19:50 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:19:50 --> Config Class Initialized
INFO - 2023-05-06 09:19:50 --> Hooks Class Initialized
INFO - 2023-05-06 09:19:50 --> Utf8 Class Initialized
INFO - 2023-05-06 09:19:50 --> URI Class Initialized
INFO - 2023-05-06 09:19:50 --> Router Class Initialized
INFO - 2023-05-06 09:19:50 --> Output Class Initialized
INFO - 2023-05-06 09:19:50 --> Security Class Initialized
INFO - 2023-05-06 09:19:50 --> Input Class Initialized
INFO - 2023-05-06 09:19:50 --> Language Class Initialized
INFO - 2023-05-06 09:19:50 --> Loader Class Initialized
INFO - 2023-05-06 09:19:50 --> Helper loaded: url_helper
INFO - 2023-05-06 09:19:50 --> Helper loaded: form_helper
INFO - 2023-05-06 09:19:50 --> Database Driver Class Initialized
INFO - 2023-05-06 09:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:19:50 --> Form Validation Class Initialized
INFO - 2023-05-06 09:19:50 --> Controller Class Initialized
INFO - 2023-05-06 09:19:50 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:19:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 09:19:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 09:19:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 09:19:50 --> Final output sent to browser
INFO - 2023-05-06 09:36:51 --> Config Class Initialized
INFO - 2023-05-06 09:36:51 --> Hooks Class Initialized
INFO - 2023-05-06 09:36:51 --> Utf8 Class Initialized
INFO - 2023-05-06 09:36:51 --> URI Class Initialized
INFO - 2023-05-06 09:36:51 --> Router Class Initialized
INFO - 2023-05-06 09:36:51 --> Output Class Initialized
INFO - 2023-05-06 09:36:51 --> Security Class Initialized
INFO - 2023-05-06 09:36:51 --> Input Class Initialized
INFO - 2023-05-06 09:36:52 --> Language Class Initialized
INFO - 2023-05-06 09:36:52 --> Loader Class Initialized
INFO - 2023-05-06 09:36:52 --> Helper loaded: url_helper
INFO - 2023-05-06 09:36:52 --> Helper loaded: form_helper
INFO - 2023-05-06 09:36:52 --> Database Driver Class Initialized
INFO - 2023-05-06 09:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:36:52 --> Form Validation Class Initialized
INFO - 2023-05-06 09:36:52 --> Controller Class Initialized
INFO - 2023-05-06 09:36:52 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:36:52 --> Config Class Initialized
INFO - 2023-05-06 09:36:52 --> Hooks Class Initialized
INFO - 2023-05-06 09:36:52 --> Utf8 Class Initialized
INFO - 2023-05-06 09:36:52 --> URI Class Initialized
INFO - 2023-05-06 09:36:52 --> Router Class Initialized
INFO - 2023-05-06 09:36:52 --> Output Class Initialized
INFO - 2023-05-06 09:36:52 --> Security Class Initialized
INFO - 2023-05-06 09:36:52 --> Input Class Initialized
INFO - 2023-05-06 09:36:52 --> Language Class Initialized
INFO - 2023-05-06 09:36:52 --> Loader Class Initialized
INFO - 2023-05-06 09:36:52 --> Helper loaded: url_helper
INFO - 2023-05-06 09:36:52 --> Helper loaded: form_helper
INFO - 2023-05-06 09:36:52 --> Database Driver Class Initialized
INFO - 2023-05-06 09:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:36:52 --> Form Validation Class Initialized
INFO - 2023-05-06 09:36:52 --> Controller Class Initialized
INFO - 2023-05-06 09:36:52 --> Model "M_tutor" initialized
INFO - 2023-05-06 09:36:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 09:36:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 09:36:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 09:36:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 09:36:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 09:36:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 09:36:52 --> Final output sent to browser
INFO - 2023-05-06 09:57:24 --> Config Class Initialized
INFO - 2023-05-06 09:57:24 --> Hooks Class Initialized
INFO - 2023-05-06 09:57:24 --> Utf8 Class Initialized
INFO - 2023-05-06 09:57:24 --> URI Class Initialized
INFO - 2023-05-06 09:57:24 --> Router Class Initialized
INFO - 2023-05-06 09:57:24 --> Output Class Initialized
INFO - 2023-05-06 09:57:24 --> Security Class Initialized
INFO - 2023-05-06 09:57:24 --> Input Class Initialized
INFO - 2023-05-06 09:57:24 --> Language Class Initialized
INFO - 2023-05-06 09:57:24 --> Loader Class Initialized
INFO - 2023-05-06 09:57:24 --> Helper loaded: url_helper
INFO - 2023-05-06 09:57:24 --> Helper loaded: form_helper
INFO - 2023-05-06 09:57:24 --> Database Driver Class Initialized
INFO - 2023-05-06 09:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:57:24 --> Form Validation Class Initialized
INFO - 2023-05-06 09:57:24 --> Controller Class Initialized
INFO - 2023-05-06 09:57:24 --> Model "m_user" initialized
INFO - 2023-05-06 09:57:24 --> Config Class Initialized
INFO - 2023-05-06 09:57:24 --> Hooks Class Initialized
INFO - 2023-05-06 09:57:24 --> Utf8 Class Initialized
INFO - 2023-05-06 09:57:24 --> URI Class Initialized
INFO - 2023-05-06 09:57:24 --> Router Class Initialized
INFO - 2023-05-06 09:57:24 --> Output Class Initialized
INFO - 2023-05-06 09:57:24 --> Security Class Initialized
INFO - 2023-05-06 09:57:24 --> Input Class Initialized
INFO - 2023-05-06 09:57:24 --> Language Class Initialized
INFO - 2023-05-06 09:57:24 --> Loader Class Initialized
INFO - 2023-05-06 09:57:24 --> Helper loaded: url_helper
INFO - 2023-05-06 09:57:24 --> Helper loaded: form_helper
INFO - 2023-05-06 09:57:24 --> Database Driver Class Initialized
INFO - 2023-05-06 09:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:57:24 --> Form Validation Class Initialized
INFO - 2023-05-06 09:57:24 --> Controller Class Initialized
INFO - 2023-05-06 09:57:24 --> Model "m_user" initialized
INFO - 2023-05-06 09:57:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 09:57:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 09:57:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 09:57:24 --> Final output sent to browser
INFO - 2023-05-06 09:57:29 --> Config Class Initialized
INFO - 2023-05-06 09:57:29 --> Hooks Class Initialized
INFO - 2023-05-06 09:57:29 --> Utf8 Class Initialized
INFO - 2023-05-06 09:57:29 --> URI Class Initialized
INFO - 2023-05-06 09:57:29 --> Router Class Initialized
INFO - 2023-05-06 09:57:29 --> Output Class Initialized
INFO - 2023-05-06 09:57:29 --> Security Class Initialized
INFO - 2023-05-06 09:57:29 --> Input Class Initialized
INFO - 2023-05-06 09:57:29 --> Language Class Initialized
INFO - 2023-05-06 09:57:29 --> Loader Class Initialized
INFO - 2023-05-06 09:57:29 --> Helper loaded: url_helper
INFO - 2023-05-06 09:57:29 --> Helper loaded: form_helper
INFO - 2023-05-06 09:57:29 --> Database Driver Class Initialized
INFO - 2023-05-06 09:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:57:29 --> Form Validation Class Initialized
INFO - 2023-05-06 09:57:29 --> Controller Class Initialized
INFO - 2023-05-06 09:57:29 --> Model "m_user" initialized
INFO - 2023-05-06 09:57:29 --> Config Class Initialized
INFO - 2023-05-06 09:57:29 --> Hooks Class Initialized
INFO - 2023-05-06 09:57:29 --> Utf8 Class Initialized
INFO - 2023-05-06 09:57:29 --> URI Class Initialized
INFO - 2023-05-06 09:57:29 --> Router Class Initialized
INFO - 2023-05-06 09:57:29 --> Output Class Initialized
INFO - 2023-05-06 09:57:29 --> Security Class Initialized
INFO - 2023-05-06 09:57:29 --> Input Class Initialized
INFO - 2023-05-06 09:57:29 --> Language Class Initialized
INFO - 2023-05-06 09:57:29 --> Loader Class Initialized
INFO - 2023-05-06 09:57:29 --> Helper loaded: url_helper
INFO - 2023-05-06 09:57:29 --> Helper loaded: form_helper
INFO - 2023-05-06 09:57:29 --> Database Driver Class Initialized
INFO - 2023-05-06 09:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 09:57:29 --> Form Validation Class Initialized
INFO - 2023-05-06 09:57:29 --> Controller Class Initialized
INFO - 2023-05-06 09:57:29 --> Model "m_user" initialized
INFO - 2023-05-06 09:57:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 09:57:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 09:57:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 09:57:29 --> Final output sent to browser
INFO - 2023-05-06 10:03:13 --> Config Class Initialized
INFO - 2023-05-06 10:03:13 --> Hooks Class Initialized
INFO - 2023-05-06 10:03:13 --> Utf8 Class Initialized
INFO - 2023-05-06 10:03:13 --> URI Class Initialized
INFO - 2023-05-06 10:03:13 --> Router Class Initialized
INFO - 2023-05-06 10:03:13 --> Output Class Initialized
INFO - 2023-05-06 10:03:13 --> Security Class Initialized
INFO - 2023-05-06 10:03:13 --> Input Class Initialized
INFO - 2023-05-06 10:03:13 --> Language Class Initialized
INFO - 2023-05-06 10:03:13 --> Loader Class Initialized
INFO - 2023-05-06 10:03:13 --> Helper loaded: url_helper
INFO - 2023-05-06 10:03:13 --> Helper loaded: form_helper
INFO - 2023-05-06 10:03:13 --> Database Driver Class Initialized
INFO - 2023-05-06 10:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:03:13 --> Form Validation Class Initialized
INFO - 2023-05-06 10:03:13 --> Controller Class Initialized
INFO - 2023-05-06 10:03:13 --> Model "m_user" initialized
INFO - 2023-05-06 10:03:13 --> Config Class Initialized
INFO - 2023-05-06 10:03:13 --> Hooks Class Initialized
INFO - 2023-05-06 10:03:13 --> Utf8 Class Initialized
INFO - 2023-05-06 10:03:13 --> URI Class Initialized
INFO - 2023-05-06 10:03:13 --> Router Class Initialized
INFO - 2023-05-06 10:03:13 --> Output Class Initialized
INFO - 2023-05-06 10:03:13 --> Security Class Initialized
INFO - 2023-05-06 10:03:13 --> Input Class Initialized
INFO - 2023-05-06 10:03:13 --> Language Class Initialized
INFO - 2023-05-06 10:03:13 --> Loader Class Initialized
INFO - 2023-05-06 10:03:13 --> Helper loaded: url_helper
INFO - 2023-05-06 10:03:13 --> Helper loaded: form_helper
INFO - 2023-05-06 10:03:13 --> Database Driver Class Initialized
INFO - 2023-05-06 10:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:03:13 --> Form Validation Class Initialized
INFO - 2023-05-06 10:03:13 --> Controller Class Initialized
ERROR - 2023-05-06 10:03:13 --> Severity: error --> Exception: Unable to locate the model you have specified: M_tutor C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 348
INFO - 2023-05-06 10:03:18 --> Config Class Initialized
INFO - 2023-05-06 10:03:18 --> Hooks Class Initialized
INFO - 2023-05-06 10:03:18 --> Utf8 Class Initialized
INFO - 2023-05-06 10:03:18 --> URI Class Initialized
INFO - 2023-05-06 10:03:18 --> Router Class Initialized
INFO - 2023-05-06 10:03:18 --> Output Class Initialized
INFO - 2023-05-06 10:03:18 --> Security Class Initialized
INFO - 2023-05-06 10:03:18 --> Input Class Initialized
INFO - 2023-05-06 10:03:18 --> Language Class Initialized
INFO - 2023-05-06 10:03:18 --> Loader Class Initialized
INFO - 2023-05-06 10:03:18 --> Helper loaded: url_helper
INFO - 2023-05-06 10:03:18 --> Helper loaded: form_helper
INFO - 2023-05-06 10:03:18 --> Database Driver Class Initialized
INFO - 2023-05-06 10:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:03:18 --> Form Validation Class Initialized
INFO - 2023-05-06 10:03:18 --> Controller Class Initialized
INFO - 2023-05-06 10:03:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 10:03:18 --> Final output sent to browser
INFO - 2023-05-06 10:03:19 --> Config Class Initialized
INFO - 2023-05-06 10:03:19 --> Hooks Class Initialized
INFO - 2023-05-06 10:03:19 --> Utf8 Class Initialized
INFO - 2023-05-06 10:03:19 --> URI Class Initialized
INFO - 2023-05-06 10:03:19 --> Router Class Initialized
INFO - 2023-05-06 10:03:19 --> Output Class Initialized
INFO - 2023-05-06 10:03:19 --> Security Class Initialized
INFO - 2023-05-06 10:03:19 --> Input Class Initialized
INFO - 2023-05-06 10:03:19 --> Language Class Initialized
INFO - 2023-05-06 10:03:19 --> Loader Class Initialized
INFO - 2023-05-06 10:03:19 --> Helper loaded: url_helper
INFO - 2023-05-06 10:03:19 --> Helper loaded: form_helper
INFO - 2023-05-06 10:03:19 --> Database Driver Class Initialized
INFO - 2023-05-06 10:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:03:19 --> Form Validation Class Initialized
INFO - 2023-05-06 10:03:19 --> Controller Class Initialized
INFO - 2023-05-06 10:03:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 10:03:19 --> Final output sent to browser
INFO - 2023-05-06 10:03:21 --> Config Class Initialized
INFO - 2023-05-06 10:03:21 --> Hooks Class Initialized
INFO - 2023-05-06 10:03:21 --> Utf8 Class Initialized
INFO - 2023-05-06 10:03:21 --> URI Class Initialized
INFO - 2023-05-06 10:03:21 --> Router Class Initialized
INFO - 2023-05-06 10:03:21 --> Output Class Initialized
INFO - 2023-05-06 10:03:21 --> Security Class Initialized
INFO - 2023-05-06 10:03:21 --> Input Class Initialized
INFO - 2023-05-06 10:03:21 --> Language Class Initialized
INFO - 2023-05-06 10:03:21 --> Loader Class Initialized
INFO - 2023-05-06 10:03:21 --> Helper loaded: url_helper
INFO - 2023-05-06 10:03:21 --> Helper loaded: form_helper
INFO - 2023-05-06 10:03:21 --> Database Driver Class Initialized
INFO - 2023-05-06 10:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:03:21 --> Form Validation Class Initialized
INFO - 2023-05-06 10:03:21 --> Controller Class Initialized
INFO - 2023-05-06 10:03:21 --> Model "m_user" initialized
INFO - 2023-05-06 10:03:21 --> Config Class Initialized
INFO - 2023-05-06 10:03:21 --> Hooks Class Initialized
INFO - 2023-05-06 10:03:21 --> Utf8 Class Initialized
INFO - 2023-05-06 10:03:21 --> URI Class Initialized
INFO - 2023-05-06 10:03:21 --> Router Class Initialized
INFO - 2023-05-06 10:03:21 --> Output Class Initialized
INFO - 2023-05-06 10:03:21 --> Security Class Initialized
INFO - 2023-05-06 10:03:21 --> Input Class Initialized
INFO - 2023-05-06 10:03:21 --> Language Class Initialized
INFO - 2023-05-06 10:03:21 --> Loader Class Initialized
INFO - 2023-05-06 10:03:21 --> Helper loaded: url_helper
INFO - 2023-05-06 10:03:21 --> Helper loaded: form_helper
INFO - 2023-05-06 10:03:22 --> Database Driver Class Initialized
INFO - 2023-05-06 10:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:03:22 --> Form Validation Class Initialized
INFO - 2023-05-06 10:03:22 --> Controller Class Initialized
ERROR - 2023-05-06 10:03:22 --> Severity: error --> Exception: Unable to locate the model you have specified: M_tutor C:\xampp\htdocs\sistemdiagnosa\system\core\Loader.php 348
INFO - 2023-05-06 10:03:41 --> Config Class Initialized
INFO - 2023-05-06 10:03:41 --> Hooks Class Initialized
INFO - 2023-05-06 10:03:41 --> Utf8 Class Initialized
INFO - 2023-05-06 10:03:41 --> URI Class Initialized
INFO - 2023-05-06 10:03:41 --> Router Class Initialized
INFO - 2023-05-06 10:03:41 --> Output Class Initialized
INFO - 2023-05-06 10:03:41 --> Security Class Initialized
INFO - 2023-05-06 10:03:41 --> Input Class Initialized
INFO - 2023-05-06 10:03:41 --> Language Class Initialized
INFO - 2023-05-06 10:03:41 --> Loader Class Initialized
INFO - 2023-05-06 10:03:41 --> Helper loaded: url_helper
INFO - 2023-05-06 10:03:41 --> Helper loaded: form_helper
INFO - 2023-05-06 10:03:41 --> Database Driver Class Initialized
INFO - 2023-05-06 10:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:03:41 --> Form Validation Class Initialized
INFO - 2023-05-06 10:03:41 --> Controller Class Initialized
INFO - 2023-05-06 10:03:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 10:03:41 --> Final output sent to browser
INFO - 2023-05-06 10:04:21 --> Config Class Initialized
INFO - 2023-05-06 10:04:21 --> Hooks Class Initialized
INFO - 2023-05-06 10:04:21 --> Utf8 Class Initialized
INFO - 2023-05-06 10:04:21 --> URI Class Initialized
INFO - 2023-05-06 10:04:21 --> Router Class Initialized
INFO - 2023-05-06 10:04:21 --> Output Class Initialized
INFO - 2023-05-06 10:04:21 --> Security Class Initialized
INFO - 2023-05-06 10:04:21 --> Input Class Initialized
INFO - 2023-05-06 10:04:21 --> Language Class Initialized
INFO - 2023-05-06 10:04:21 --> Loader Class Initialized
INFO - 2023-05-06 10:04:21 --> Helper loaded: url_helper
INFO - 2023-05-06 10:04:21 --> Helper loaded: form_helper
INFO - 2023-05-06 10:04:21 --> Database Driver Class Initialized
INFO - 2023-05-06 10:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:04:21 --> Form Validation Class Initialized
INFO - 2023-05-06 10:04:21 --> Controller Class Initialized
INFO - 2023-05-06 10:04:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 10:04:21 --> Final output sent to browser
INFO - 2023-05-06 10:04:22 --> Config Class Initialized
INFO - 2023-05-06 10:04:22 --> Hooks Class Initialized
INFO - 2023-05-06 10:04:22 --> Utf8 Class Initialized
INFO - 2023-05-06 10:04:22 --> URI Class Initialized
INFO - 2023-05-06 10:04:22 --> Router Class Initialized
INFO - 2023-05-06 10:04:22 --> Output Class Initialized
INFO - 2023-05-06 10:04:22 --> Security Class Initialized
INFO - 2023-05-06 10:04:22 --> Input Class Initialized
INFO - 2023-05-06 10:04:22 --> Language Class Initialized
INFO - 2023-05-06 10:04:22 --> Loader Class Initialized
INFO - 2023-05-06 10:04:22 --> Helper loaded: url_helper
INFO - 2023-05-06 10:04:22 --> Helper loaded: form_helper
INFO - 2023-05-06 10:04:22 --> Database Driver Class Initialized
INFO - 2023-05-06 10:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:04:22 --> Form Validation Class Initialized
INFO - 2023-05-06 10:04:22 --> Controller Class Initialized
INFO - 2023-05-06 10:04:22 --> Model "m_user" initialized
INFO - 2023-05-06 10:04:22 --> Config Class Initialized
INFO - 2023-05-06 10:04:22 --> Hooks Class Initialized
INFO - 2023-05-06 10:04:22 --> Utf8 Class Initialized
INFO - 2023-05-06 10:04:22 --> URI Class Initialized
INFO - 2023-05-06 10:04:22 --> Router Class Initialized
INFO - 2023-05-06 10:04:22 --> Output Class Initialized
INFO - 2023-05-06 10:04:22 --> Security Class Initialized
INFO - 2023-05-06 10:04:22 --> Input Class Initialized
INFO - 2023-05-06 10:04:22 --> Language Class Initialized
INFO - 2023-05-06 10:04:22 --> Loader Class Initialized
INFO - 2023-05-06 10:04:22 --> Helper loaded: url_helper
INFO - 2023-05-06 10:04:22 --> Helper loaded: form_helper
INFO - 2023-05-06 10:04:22 --> Database Driver Class Initialized
INFO - 2023-05-06 10:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:04:22 --> Form Validation Class Initialized
INFO - 2023-05-06 10:04:22 --> Controller Class Initialized
INFO - 2023-05-06 10:04:22 --> Model "m_user" initialized
INFO - 2023-05-06 10:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 10:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 10:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 10:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 10:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 10:04:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 10:04:22 --> Final output sent to browser
INFO - 2023-05-06 10:04:33 --> Config Class Initialized
INFO - 2023-05-06 10:04:33 --> Hooks Class Initialized
INFO - 2023-05-06 10:04:33 --> Utf8 Class Initialized
INFO - 2023-05-06 10:04:33 --> URI Class Initialized
INFO - 2023-05-06 10:04:33 --> Router Class Initialized
INFO - 2023-05-06 10:04:33 --> Output Class Initialized
INFO - 2023-05-06 10:04:33 --> Security Class Initialized
INFO - 2023-05-06 10:04:33 --> Input Class Initialized
INFO - 2023-05-06 10:04:33 --> Language Class Initialized
INFO - 2023-05-06 10:04:33 --> Loader Class Initialized
INFO - 2023-05-06 10:04:33 --> Helper loaded: url_helper
INFO - 2023-05-06 10:04:33 --> Helper loaded: form_helper
INFO - 2023-05-06 10:04:33 --> Database Driver Class Initialized
INFO - 2023-05-06 10:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:04:33 --> Form Validation Class Initialized
INFO - 2023-05-06 10:04:33 --> Controller Class Initialized
INFO - 2023-05-06 10:04:33 --> Model "m_user" initialized
INFO - 2023-05-06 10:04:33 --> Config Class Initialized
INFO - 2023-05-06 10:04:33 --> Hooks Class Initialized
INFO - 2023-05-06 10:04:33 --> Utf8 Class Initialized
INFO - 2023-05-06 10:04:33 --> URI Class Initialized
INFO - 2023-05-06 10:04:33 --> Router Class Initialized
INFO - 2023-05-06 10:04:33 --> Output Class Initialized
INFO - 2023-05-06 10:04:33 --> Security Class Initialized
INFO - 2023-05-06 10:04:33 --> Input Class Initialized
INFO - 2023-05-06 10:04:33 --> Language Class Initialized
INFO - 2023-05-06 10:04:33 --> Loader Class Initialized
INFO - 2023-05-06 10:04:33 --> Helper loaded: url_helper
INFO - 2023-05-06 10:04:33 --> Helper loaded: form_helper
INFO - 2023-05-06 10:04:33 --> Database Driver Class Initialized
INFO - 2023-05-06 10:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:04:33 --> Form Validation Class Initialized
INFO - 2023-05-06 10:04:33 --> Controller Class Initialized
INFO - 2023-05-06 10:04:33 --> Model "m_user" initialized
INFO - 2023-05-06 10:04:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 10:04:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 10:04:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 10:04:33 --> Final output sent to browser
INFO - 2023-05-06 10:04:38 --> Config Class Initialized
INFO - 2023-05-06 10:04:38 --> Hooks Class Initialized
INFO - 2023-05-06 10:04:38 --> Utf8 Class Initialized
INFO - 2023-05-06 10:04:38 --> URI Class Initialized
INFO - 2023-05-06 10:04:38 --> Router Class Initialized
INFO - 2023-05-06 10:04:38 --> Output Class Initialized
INFO - 2023-05-06 10:04:38 --> Security Class Initialized
INFO - 2023-05-06 10:04:38 --> Input Class Initialized
INFO - 2023-05-06 10:04:38 --> Language Class Initialized
INFO - 2023-05-06 10:04:38 --> Loader Class Initialized
INFO - 2023-05-06 10:04:38 --> Helper loaded: url_helper
INFO - 2023-05-06 10:04:38 --> Helper loaded: form_helper
INFO - 2023-05-06 10:04:38 --> Database Driver Class Initialized
INFO - 2023-05-06 10:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:04:38 --> Form Validation Class Initialized
INFO - 2023-05-06 10:04:38 --> Controller Class Initialized
INFO - 2023-05-06 10:04:38 --> Model "m_user" initialized
INFO - 2023-05-06 10:04:38 --> Config Class Initialized
INFO - 2023-05-06 10:04:38 --> Hooks Class Initialized
INFO - 2023-05-06 10:04:38 --> Utf8 Class Initialized
INFO - 2023-05-06 10:04:38 --> URI Class Initialized
INFO - 2023-05-06 10:04:38 --> Router Class Initialized
INFO - 2023-05-06 10:04:38 --> Output Class Initialized
INFO - 2023-05-06 10:04:38 --> Security Class Initialized
INFO - 2023-05-06 10:04:38 --> Input Class Initialized
INFO - 2023-05-06 10:04:38 --> Language Class Initialized
INFO - 2023-05-06 10:04:38 --> Loader Class Initialized
INFO - 2023-05-06 10:04:38 --> Helper loaded: url_helper
INFO - 2023-05-06 10:04:38 --> Helper loaded: form_helper
INFO - 2023-05-06 10:04:39 --> Database Driver Class Initialized
INFO - 2023-05-06 10:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:04:39 --> Form Validation Class Initialized
INFO - 2023-05-06 10:04:39 --> Controller Class Initialized
INFO - 2023-05-06 10:04:39 --> Model "m_user" initialized
INFO - 2023-05-06 10:04:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 10:04:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 10:04:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 10:04:39 --> Final output sent to browser
INFO - 2023-05-06 10:04:50 --> Config Class Initialized
INFO - 2023-05-06 10:04:50 --> Hooks Class Initialized
INFO - 2023-05-06 10:04:50 --> Utf8 Class Initialized
INFO - 2023-05-06 10:04:50 --> URI Class Initialized
INFO - 2023-05-06 10:04:50 --> Router Class Initialized
INFO - 2023-05-06 10:04:50 --> Output Class Initialized
INFO - 2023-05-06 10:04:50 --> Security Class Initialized
INFO - 2023-05-06 10:04:50 --> Input Class Initialized
INFO - 2023-05-06 10:04:50 --> Language Class Initialized
INFO - 2023-05-06 10:04:50 --> Loader Class Initialized
INFO - 2023-05-06 10:04:50 --> Helper loaded: url_helper
INFO - 2023-05-06 10:04:50 --> Helper loaded: form_helper
INFO - 2023-05-06 10:04:50 --> Database Driver Class Initialized
INFO - 2023-05-06 10:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:04:50 --> Form Validation Class Initialized
INFO - 2023-05-06 10:04:50 --> Controller Class Initialized
INFO - 2023-05-06 10:04:50 --> Model "m_user" initialized
INFO - 2023-05-06 10:04:50 --> Config Class Initialized
INFO - 2023-05-06 10:04:50 --> Hooks Class Initialized
INFO - 2023-05-06 10:04:50 --> Utf8 Class Initialized
INFO - 2023-05-06 10:04:50 --> URI Class Initialized
INFO - 2023-05-06 10:04:50 --> Router Class Initialized
INFO - 2023-05-06 10:04:50 --> Output Class Initialized
INFO - 2023-05-06 10:04:50 --> Security Class Initialized
INFO - 2023-05-06 10:04:50 --> Input Class Initialized
INFO - 2023-05-06 10:04:50 --> Language Class Initialized
INFO - 2023-05-06 10:04:50 --> Loader Class Initialized
INFO - 2023-05-06 10:04:50 --> Helper loaded: url_helper
INFO - 2023-05-06 10:04:50 --> Helper loaded: form_helper
INFO - 2023-05-06 10:04:50 --> Database Driver Class Initialized
INFO - 2023-05-06 10:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:04:50 --> Form Validation Class Initialized
INFO - 2023-05-06 10:04:50 --> Controller Class Initialized
INFO - 2023-05-06 10:04:50 --> Model "m_user" initialized
INFO - 2023-05-06 10:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 10:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 10:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 10:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 10:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 10:04:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 10:04:50 --> Final output sent to browser
INFO - 2023-05-06 10:04:59 --> Config Class Initialized
INFO - 2023-05-06 10:04:59 --> Hooks Class Initialized
INFO - 2023-05-06 10:04:59 --> Utf8 Class Initialized
INFO - 2023-05-06 10:04:59 --> URI Class Initialized
INFO - 2023-05-06 10:04:59 --> Router Class Initialized
INFO - 2023-05-06 10:04:59 --> Output Class Initialized
INFO - 2023-05-06 10:04:59 --> Security Class Initialized
INFO - 2023-05-06 10:04:59 --> Input Class Initialized
INFO - 2023-05-06 10:04:59 --> Language Class Initialized
INFO - 2023-05-06 10:04:59 --> Loader Class Initialized
INFO - 2023-05-06 10:04:59 --> Helper loaded: url_helper
INFO - 2023-05-06 10:04:59 --> Helper loaded: form_helper
INFO - 2023-05-06 10:04:59 --> Database Driver Class Initialized
INFO - 2023-05-06 10:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:04:59 --> Form Validation Class Initialized
INFO - 2023-05-06 10:04:59 --> Controller Class Initialized
INFO - 2023-05-06 10:04:59 --> Model "m_user" initialized
INFO - 2023-05-06 10:04:59 --> Config Class Initialized
INFO - 2023-05-06 10:04:59 --> Hooks Class Initialized
INFO - 2023-05-06 10:04:59 --> Utf8 Class Initialized
INFO - 2023-05-06 10:04:59 --> URI Class Initialized
INFO - 2023-05-06 10:04:59 --> Router Class Initialized
INFO - 2023-05-06 10:04:59 --> Output Class Initialized
INFO - 2023-05-06 10:04:59 --> Security Class Initialized
INFO - 2023-05-06 10:04:59 --> Input Class Initialized
INFO - 2023-05-06 10:04:59 --> Language Class Initialized
INFO - 2023-05-06 10:04:59 --> Loader Class Initialized
INFO - 2023-05-06 10:04:59 --> Helper loaded: url_helper
INFO - 2023-05-06 10:04:59 --> Helper loaded: form_helper
INFO - 2023-05-06 10:04:59 --> Database Driver Class Initialized
INFO - 2023-05-06 10:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:04:59 --> Form Validation Class Initialized
INFO - 2023-05-06 10:04:59 --> Controller Class Initialized
INFO - 2023-05-06 10:04:59 --> Model "m_user" initialized
INFO - 2023-05-06 10:04:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 10:04:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 10:04:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 10:04:59 --> Final output sent to browser
INFO - 2023-05-06 10:05:21 --> Config Class Initialized
INFO - 2023-05-06 10:05:21 --> Hooks Class Initialized
INFO - 2023-05-06 10:05:21 --> Utf8 Class Initialized
INFO - 2023-05-06 10:05:21 --> URI Class Initialized
INFO - 2023-05-06 10:05:21 --> Router Class Initialized
INFO - 2023-05-06 10:05:21 --> Output Class Initialized
INFO - 2023-05-06 10:05:21 --> Security Class Initialized
INFO - 2023-05-06 10:05:21 --> Input Class Initialized
INFO - 2023-05-06 10:05:21 --> Language Class Initialized
INFO - 2023-05-06 10:05:21 --> Loader Class Initialized
INFO - 2023-05-06 10:05:21 --> Helper loaded: url_helper
INFO - 2023-05-06 10:05:21 --> Helper loaded: form_helper
INFO - 2023-05-06 10:05:21 --> Database Driver Class Initialized
INFO - 2023-05-06 10:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:05:22 --> Form Validation Class Initialized
INFO - 2023-05-06 10:05:22 --> Controller Class Initialized
INFO - 2023-05-06 10:05:22 --> Model "m_user" initialized
INFO - 2023-05-06 10:05:22 --> Config Class Initialized
INFO - 2023-05-06 10:05:22 --> Hooks Class Initialized
INFO - 2023-05-06 10:05:22 --> Utf8 Class Initialized
INFO - 2023-05-06 10:05:22 --> URI Class Initialized
INFO - 2023-05-06 10:05:22 --> Router Class Initialized
INFO - 2023-05-06 10:05:22 --> Output Class Initialized
INFO - 2023-05-06 10:05:22 --> Security Class Initialized
INFO - 2023-05-06 10:05:22 --> Input Class Initialized
INFO - 2023-05-06 10:05:22 --> Language Class Initialized
INFO - 2023-05-06 10:05:22 --> Loader Class Initialized
INFO - 2023-05-06 10:05:22 --> Helper loaded: url_helper
INFO - 2023-05-06 10:05:22 --> Helper loaded: form_helper
INFO - 2023-05-06 10:05:22 --> Database Driver Class Initialized
INFO - 2023-05-06 10:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:05:22 --> Form Validation Class Initialized
INFO - 2023-05-06 10:05:22 --> Controller Class Initialized
INFO - 2023-05-06 10:05:22 --> Model "m_user" initialized
INFO - 2023-05-06 10:05:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 10:05:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 10:05:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 10:05:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 10:05:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 10:05:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 10:05:22 --> Final output sent to browser
INFO - 2023-05-06 10:05:33 --> Config Class Initialized
INFO - 2023-05-06 10:05:33 --> Hooks Class Initialized
INFO - 2023-05-06 10:05:33 --> Utf8 Class Initialized
INFO - 2023-05-06 10:05:33 --> URI Class Initialized
INFO - 2023-05-06 10:05:33 --> Router Class Initialized
INFO - 2023-05-06 10:05:33 --> Output Class Initialized
INFO - 2023-05-06 10:05:33 --> Security Class Initialized
INFO - 2023-05-06 10:05:33 --> Input Class Initialized
INFO - 2023-05-06 10:05:33 --> Language Class Initialized
INFO - 2023-05-06 10:05:33 --> Loader Class Initialized
INFO - 2023-05-06 10:05:33 --> Helper loaded: url_helper
INFO - 2023-05-06 10:05:33 --> Helper loaded: form_helper
INFO - 2023-05-06 10:05:33 --> Database Driver Class Initialized
INFO - 2023-05-06 10:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:05:33 --> Form Validation Class Initialized
INFO - 2023-05-06 10:05:33 --> Controller Class Initialized
INFO - 2023-05-06 10:05:33 --> Model "m_user" initialized
INFO - 2023-05-06 10:05:33 --> Config Class Initialized
INFO - 2023-05-06 10:05:33 --> Hooks Class Initialized
INFO - 2023-05-06 10:05:33 --> Utf8 Class Initialized
INFO - 2023-05-06 10:05:33 --> URI Class Initialized
INFO - 2023-05-06 10:05:33 --> Router Class Initialized
INFO - 2023-05-06 10:05:33 --> Output Class Initialized
INFO - 2023-05-06 10:05:33 --> Security Class Initialized
INFO - 2023-05-06 10:05:33 --> Input Class Initialized
INFO - 2023-05-06 10:05:33 --> Language Class Initialized
INFO - 2023-05-06 10:05:33 --> Loader Class Initialized
INFO - 2023-05-06 10:05:33 --> Helper loaded: url_helper
INFO - 2023-05-06 10:05:33 --> Helper loaded: form_helper
INFO - 2023-05-06 10:05:33 --> Database Driver Class Initialized
INFO - 2023-05-06 10:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:05:33 --> Form Validation Class Initialized
INFO - 2023-05-06 10:05:33 --> Controller Class Initialized
INFO - 2023-05-06 10:05:33 --> Model "m_user" initialized
INFO - 2023-05-06 10:05:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 10:05:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 10:05:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 10:05:33 --> Final output sent to browser
INFO - 2023-05-06 10:05:54 --> Config Class Initialized
INFO - 2023-05-06 10:05:54 --> Hooks Class Initialized
INFO - 2023-05-06 10:05:54 --> Utf8 Class Initialized
INFO - 2023-05-06 10:05:54 --> URI Class Initialized
INFO - 2023-05-06 10:05:54 --> Router Class Initialized
INFO - 2023-05-06 10:05:54 --> Output Class Initialized
INFO - 2023-05-06 10:05:54 --> Security Class Initialized
INFO - 2023-05-06 10:05:54 --> Input Class Initialized
INFO - 2023-05-06 10:05:54 --> Language Class Initialized
INFO - 2023-05-06 10:05:54 --> Loader Class Initialized
INFO - 2023-05-06 10:05:54 --> Helper loaded: url_helper
INFO - 2023-05-06 10:05:54 --> Helper loaded: form_helper
INFO - 2023-05-06 10:05:54 --> Database Driver Class Initialized
INFO - 2023-05-06 10:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:05:54 --> Form Validation Class Initialized
INFO - 2023-05-06 10:05:54 --> Controller Class Initialized
INFO - 2023-05-06 10:05:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 10:05:54 --> Final output sent to browser
INFO - 2023-05-06 10:05:56 --> Config Class Initialized
INFO - 2023-05-06 10:05:56 --> Hooks Class Initialized
INFO - 2023-05-06 10:05:56 --> Utf8 Class Initialized
INFO - 2023-05-06 10:05:56 --> URI Class Initialized
INFO - 2023-05-06 10:05:56 --> Router Class Initialized
INFO - 2023-05-06 10:05:56 --> Output Class Initialized
INFO - 2023-05-06 10:05:56 --> Security Class Initialized
INFO - 2023-05-06 10:05:56 --> Input Class Initialized
INFO - 2023-05-06 10:05:56 --> Language Class Initialized
INFO - 2023-05-06 10:05:56 --> Loader Class Initialized
INFO - 2023-05-06 10:05:56 --> Helper loaded: url_helper
INFO - 2023-05-06 10:05:56 --> Helper loaded: form_helper
INFO - 2023-05-06 10:05:56 --> Database Driver Class Initialized
INFO - 2023-05-06 10:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:05:56 --> Form Validation Class Initialized
INFO - 2023-05-06 10:05:56 --> Controller Class Initialized
INFO - 2023-05-06 10:05:56 --> Model "m_user" initialized
INFO - 2023-05-06 10:05:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 10:05:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 10:05:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 10:05:56 --> Final output sent to browser
INFO - 2023-05-06 10:05:58 --> Config Class Initialized
INFO - 2023-05-06 10:05:58 --> Hooks Class Initialized
INFO - 2023-05-06 10:05:58 --> Utf8 Class Initialized
INFO - 2023-05-06 10:05:58 --> URI Class Initialized
INFO - 2023-05-06 10:05:58 --> Router Class Initialized
INFO - 2023-05-06 10:05:58 --> Output Class Initialized
INFO - 2023-05-06 10:05:58 --> Security Class Initialized
INFO - 2023-05-06 10:05:58 --> Input Class Initialized
INFO - 2023-05-06 10:05:58 --> Language Class Initialized
INFO - 2023-05-06 10:05:58 --> Loader Class Initialized
INFO - 2023-05-06 10:05:58 --> Helper loaded: url_helper
INFO - 2023-05-06 10:05:58 --> Helper loaded: form_helper
INFO - 2023-05-06 10:05:58 --> Database Driver Class Initialized
INFO - 2023-05-06 10:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:05:58 --> Form Validation Class Initialized
INFO - 2023-05-06 10:05:58 --> Controller Class Initialized
INFO - 2023-05-06 10:05:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 10:05:58 --> Final output sent to browser
INFO - 2023-05-06 10:06:00 --> Config Class Initialized
INFO - 2023-05-06 10:06:00 --> Hooks Class Initialized
INFO - 2023-05-06 10:06:00 --> Utf8 Class Initialized
INFO - 2023-05-06 10:06:00 --> URI Class Initialized
INFO - 2023-05-06 10:06:00 --> Router Class Initialized
INFO - 2023-05-06 10:06:00 --> Output Class Initialized
INFO - 2023-05-06 10:06:00 --> Security Class Initialized
INFO - 2023-05-06 10:06:00 --> Input Class Initialized
INFO - 2023-05-06 10:06:00 --> Language Class Initialized
INFO - 2023-05-06 10:06:00 --> Loader Class Initialized
INFO - 2023-05-06 10:06:00 --> Helper loaded: url_helper
INFO - 2023-05-06 10:06:00 --> Helper loaded: form_helper
INFO - 2023-05-06 10:06:00 --> Database Driver Class Initialized
INFO - 2023-05-06 10:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:06:00 --> Form Validation Class Initialized
INFO - 2023-05-06 10:06:00 --> Controller Class Initialized
INFO - 2023-05-06 10:06:00 --> Model "m_user" initialized
INFO - 2023-05-06 10:06:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 10:06:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 10:06:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 10:06:00 --> Final output sent to browser
INFO - 2023-05-06 10:06:02 --> Config Class Initialized
INFO - 2023-05-06 10:06:02 --> Hooks Class Initialized
INFO - 2023-05-06 10:06:02 --> Utf8 Class Initialized
INFO - 2023-05-06 10:06:02 --> URI Class Initialized
INFO - 2023-05-06 10:06:02 --> Router Class Initialized
INFO - 2023-05-06 10:06:02 --> Output Class Initialized
INFO - 2023-05-06 10:06:02 --> Security Class Initialized
INFO - 2023-05-06 10:06:02 --> Input Class Initialized
INFO - 2023-05-06 10:06:02 --> Language Class Initialized
INFO - 2023-05-06 10:06:02 --> Loader Class Initialized
INFO - 2023-05-06 10:06:02 --> Helper loaded: url_helper
INFO - 2023-05-06 10:06:02 --> Helper loaded: form_helper
INFO - 2023-05-06 10:06:02 --> Database Driver Class Initialized
INFO - 2023-05-06 10:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:06:02 --> Form Validation Class Initialized
INFO - 2023-05-06 10:06:02 --> Controller Class Initialized
INFO - 2023-05-06 10:06:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 10:06:02 --> Final output sent to browser
INFO - 2023-05-06 10:06:06 --> Config Class Initialized
INFO - 2023-05-06 10:06:06 --> Hooks Class Initialized
INFO - 2023-05-06 10:06:06 --> Utf8 Class Initialized
INFO - 2023-05-06 10:06:06 --> URI Class Initialized
INFO - 2023-05-06 10:06:06 --> Router Class Initialized
INFO - 2023-05-06 10:06:06 --> Output Class Initialized
INFO - 2023-05-06 10:06:06 --> Security Class Initialized
INFO - 2023-05-06 10:06:06 --> Input Class Initialized
INFO - 2023-05-06 10:06:06 --> Language Class Initialized
INFO - 2023-05-06 10:06:06 --> Loader Class Initialized
INFO - 2023-05-06 10:06:06 --> Helper loaded: url_helper
INFO - 2023-05-06 10:06:06 --> Helper loaded: form_helper
INFO - 2023-05-06 10:06:06 --> Database Driver Class Initialized
INFO - 2023-05-06 10:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:06:06 --> Form Validation Class Initialized
INFO - 2023-05-06 10:06:06 --> Controller Class Initialized
INFO - 2023-05-06 10:06:06 --> Model "m_user" initialized
INFO - 2023-05-06 10:06:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 10:06:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 10:06:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 10:06:06 --> Final output sent to browser
INFO - 2023-05-06 10:06:12 --> Config Class Initialized
INFO - 2023-05-06 10:06:12 --> Hooks Class Initialized
INFO - 2023-05-06 10:06:12 --> Utf8 Class Initialized
INFO - 2023-05-06 10:06:12 --> URI Class Initialized
INFO - 2023-05-06 10:06:12 --> Router Class Initialized
INFO - 2023-05-06 10:06:12 --> Output Class Initialized
INFO - 2023-05-06 10:06:12 --> Security Class Initialized
INFO - 2023-05-06 10:06:12 --> Input Class Initialized
INFO - 2023-05-06 10:06:12 --> Language Class Initialized
INFO - 2023-05-06 10:06:12 --> Loader Class Initialized
INFO - 2023-05-06 10:06:12 --> Helper loaded: url_helper
INFO - 2023-05-06 10:06:12 --> Helper loaded: form_helper
INFO - 2023-05-06 10:06:12 --> Database Driver Class Initialized
INFO - 2023-05-06 10:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:06:12 --> Form Validation Class Initialized
INFO - 2023-05-06 10:06:12 --> Controller Class Initialized
INFO - 2023-05-06 10:06:12 --> Model "m_user" initialized
INFO - 2023-05-06 10:06:12 --> Config Class Initialized
INFO - 2023-05-06 10:06:12 --> Hooks Class Initialized
INFO - 2023-05-06 10:06:12 --> Utf8 Class Initialized
INFO - 2023-05-06 10:06:12 --> URI Class Initialized
INFO - 2023-05-06 10:06:12 --> Router Class Initialized
INFO - 2023-05-06 10:06:12 --> Output Class Initialized
INFO - 2023-05-06 10:06:12 --> Security Class Initialized
INFO - 2023-05-06 10:06:12 --> Input Class Initialized
INFO - 2023-05-06 10:06:12 --> Language Class Initialized
INFO - 2023-05-06 10:06:12 --> Loader Class Initialized
INFO - 2023-05-06 10:06:12 --> Helper loaded: url_helper
INFO - 2023-05-06 10:06:12 --> Helper loaded: form_helper
INFO - 2023-05-06 10:06:12 --> Database Driver Class Initialized
INFO - 2023-05-06 10:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:06:12 --> Form Validation Class Initialized
INFO - 2023-05-06 10:06:12 --> Controller Class Initialized
INFO - 2023-05-06 10:06:12 --> Model "m_user" initialized
INFO - 2023-05-06 10:06:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 10:06:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 10:06:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 10:06:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 10:06:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 10:06:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 10:06:12 --> Final output sent to browser
INFO - 2023-05-06 10:06:24 --> Config Class Initialized
INFO - 2023-05-06 10:06:24 --> Hooks Class Initialized
INFO - 2023-05-06 10:06:24 --> Utf8 Class Initialized
INFO - 2023-05-06 10:06:24 --> URI Class Initialized
INFO - 2023-05-06 10:06:24 --> Router Class Initialized
INFO - 2023-05-06 10:06:24 --> Output Class Initialized
INFO - 2023-05-06 10:06:24 --> Security Class Initialized
INFO - 2023-05-06 10:06:24 --> Input Class Initialized
INFO - 2023-05-06 10:06:24 --> Language Class Initialized
INFO - 2023-05-06 10:06:24 --> Loader Class Initialized
INFO - 2023-05-06 10:06:24 --> Helper loaded: url_helper
INFO - 2023-05-06 10:06:24 --> Helper loaded: form_helper
INFO - 2023-05-06 10:06:25 --> Database Driver Class Initialized
INFO - 2023-05-06 10:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:06:25 --> Form Validation Class Initialized
INFO - 2023-05-06 10:06:25 --> Controller Class Initialized
INFO - 2023-05-06 10:06:25 --> Model "m_user" initialized
INFO - 2023-05-06 10:06:25 --> Config Class Initialized
INFO - 2023-05-06 10:06:25 --> Hooks Class Initialized
INFO - 2023-05-06 10:06:25 --> Utf8 Class Initialized
INFO - 2023-05-06 10:06:25 --> URI Class Initialized
INFO - 2023-05-06 10:06:25 --> Router Class Initialized
INFO - 2023-05-06 10:06:25 --> Output Class Initialized
INFO - 2023-05-06 10:06:25 --> Security Class Initialized
INFO - 2023-05-06 10:06:25 --> Input Class Initialized
INFO - 2023-05-06 10:06:25 --> Language Class Initialized
INFO - 2023-05-06 10:06:25 --> Loader Class Initialized
INFO - 2023-05-06 10:06:25 --> Helper loaded: url_helper
INFO - 2023-05-06 10:06:25 --> Helper loaded: form_helper
INFO - 2023-05-06 10:06:25 --> Database Driver Class Initialized
INFO - 2023-05-06 10:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:06:25 --> Form Validation Class Initialized
INFO - 2023-05-06 10:06:25 --> Controller Class Initialized
INFO - 2023-05-06 10:06:25 --> Model "m_user" initialized
INFO - 2023-05-06 10:06:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 10:06:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 10:06:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 10:06:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 10:06:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 10:06:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 10:06:25 --> Final output sent to browser
INFO - 2023-05-06 10:06:27 --> Config Class Initialized
INFO - 2023-05-06 10:06:27 --> Hooks Class Initialized
INFO - 2023-05-06 10:06:27 --> Utf8 Class Initialized
INFO - 2023-05-06 10:06:27 --> URI Class Initialized
INFO - 2023-05-06 10:06:27 --> Router Class Initialized
INFO - 2023-05-06 10:06:27 --> Output Class Initialized
INFO - 2023-05-06 10:06:27 --> Security Class Initialized
INFO - 2023-05-06 10:06:27 --> Input Class Initialized
INFO - 2023-05-06 10:06:27 --> Language Class Initialized
INFO - 2023-05-06 10:06:27 --> Loader Class Initialized
INFO - 2023-05-06 10:06:27 --> Helper loaded: url_helper
INFO - 2023-05-06 10:06:27 --> Helper loaded: form_helper
INFO - 2023-05-06 10:06:27 --> Database Driver Class Initialized
INFO - 2023-05-06 10:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:06:27 --> Form Validation Class Initialized
INFO - 2023-05-06 10:06:27 --> Controller Class Initialized
INFO - 2023-05-06 10:06:27 --> Model "m_user" initialized
INFO - 2023-05-06 10:06:27 --> Config Class Initialized
INFO - 2023-05-06 10:06:27 --> Hooks Class Initialized
INFO - 2023-05-06 10:06:27 --> Utf8 Class Initialized
INFO - 2023-05-06 10:06:27 --> URI Class Initialized
INFO - 2023-05-06 10:06:27 --> Router Class Initialized
INFO - 2023-05-06 10:06:27 --> Output Class Initialized
INFO - 2023-05-06 10:06:27 --> Security Class Initialized
INFO - 2023-05-06 10:06:27 --> Input Class Initialized
INFO - 2023-05-06 10:06:27 --> Language Class Initialized
INFO - 2023-05-06 10:06:27 --> Loader Class Initialized
INFO - 2023-05-06 10:06:27 --> Helper loaded: url_helper
INFO - 2023-05-06 10:06:27 --> Helper loaded: form_helper
INFO - 2023-05-06 10:06:27 --> Database Driver Class Initialized
INFO - 2023-05-06 10:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:06:27 --> Form Validation Class Initialized
INFO - 2023-05-06 10:06:27 --> Controller Class Initialized
INFO - 2023-05-06 10:06:27 --> Model "m_user" initialized
INFO - 2023-05-06 10:06:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 10:06:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 10:06:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 10:06:27 --> Final output sent to browser
INFO - 2023-05-06 10:07:04 --> Config Class Initialized
INFO - 2023-05-06 10:07:04 --> Hooks Class Initialized
INFO - 2023-05-06 10:07:04 --> Utf8 Class Initialized
INFO - 2023-05-06 10:07:04 --> URI Class Initialized
INFO - 2023-05-06 10:07:04 --> Router Class Initialized
INFO - 2023-05-06 10:07:04 --> Output Class Initialized
INFO - 2023-05-06 10:07:04 --> Security Class Initialized
INFO - 2023-05-06 10:07:04 --> Input Class Initialized
INFO - 2023-05-06 10:07:04 --> Language Class Initialized
INFO - 2023-05-06 10:07:04 --> Loader Class Initialized
INFO - 2023-05-06 10:07:04 --> Helper loaded: url_helper
INFO - 2023-05-06 10:07:04 --> Helper loaded: form_helper
INFO - 2023-05-06 10:07:04 --> Database Driver Class Initialized
INFO - 2023-05-06 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:07:04 --> Form Validation Class Initialized
INFO - 2023-05-06 10:07:04 --> Controller Class Initialized
INFO - 2023-05-06 10:07:04 --> Model "m_user" initialized
INFO - 2023-05-06 10:07:04 --> Config Class Initialized
INFO - 2023-05-06 10:07:04 --> Hooks Class Initialized
INFO - 2023-05-06 10:07:04 --> Utf8 Class Initialized
INFO - 2023-05-06 10:07:04 --> URI Class Initialized
INFO - 2023-05-06 10:07:04 --> Router Class Initialized
INFO - 2023-05-06 10:07:04 --> Output Class Initialized
INFO - 2023-05-06 10:07:04 --> Security Class Initialized
INFO - 2023-05-06 10:07:04 --> Input Class Initialized
INFO - 2023-05-06 10:07:04 --> Language Class Initialized
INFO - 2023-05-06 10:07:04 --> Loader Class Initialized
INFO - 2023-05-06 10:07:04 --> Helper loaded: url_helper
INFO - 2023-05-06 10:07:04 --> Helper loaded: form_helper
INFO - 2023-05-06 10:07:04 --> Database Driver Class Initialized
INFO - 2023-05-06 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:07:04 --> Form Validation Class Initialized
INFO - 2023-05-06 10:07:04 --> Controller Class Initialized
INFO - 2023-05-06 10:07:04 --> Model "m_user" initialized
INFO - 2023-05-06 10:07:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 10:07:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 10:07:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 10:07:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 10:07:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 10:07:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 10:07:04 --> Final output sent to browser
INFO - 2023-05-06 10:07:10 --> Config Class Initialized
INFO - 2023-05-06 10:07:10 --> Hooks Class Initialized
INFO - 2023-05-06 10:07:10 --> Utf8 Class Initialized
INFO - 2023-05-06 10:07:10 --> URI Class Initialized
INFO - 2023-05-06 10:07:10 --> Router Class Initialized
INFO - 2023-05-06 10:07:10 --> Output Class Initialized
INFO - 2023-05-06 10:07:10 --> Security Class Initialized
INFO - 2023-05-06 10:07:10 --> Input Class Initialized
INFO - 2023-05-06 10:07:10 --> Language Class Initialized
INFO - 2023-05-06 10:07:10 --> Loader Class Initialized
INFO - 2023-05-06 10:07:10 --> Helper loaded: url_helper
INFO - 2023-05-06 10:07:10 --> Helper loaded: form_helper
INFO - 2023-05-06 10:07:10 --> Database Driver Class Initialized
INFO - 2023-05-06 10:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:07:10 --> Form Validation Class Initialized
INFO - 2023-05-06 10:07:10 --> Controller Class Initialized
INFO - 2023-05-06 10:07:10 --> Model "m_user" initialized
INFO - 2023-05-06 10:07:10 --> Config Class Initialized
INFO - 2023-05-06 10:07:10 --> Hooks Class Initialized
INFO - 2023-05-06 10:07:10 --> Utf8 Class Initialized
INFO - 2023-05-06 10:07:10 --> URI Class Initialized
INFO - 2023-05-06 10:07:10 --> Router Class Initialized
INFO - 2023-05-06 10:07:10 --> Output Class Initialized
INFO - 2023-05-06 10:07:10 --> Security Class Initialized
INFO - 2023-05-06 10:07:10 --> Input Class Initialized
INFO - 2023-05-06 10:07:10 --> Language Class Initialized
INFO - 2023-05-06 10:07:10 --> Loader Class Initialized
INFO - 2023-05-06 10:07:10 --> Helper loaded: url_helper
INFO - 2023-05-06 10:07:10 --> Helper loaded: form_helper
INFO - 2023-05-06 10:07:10 --> Database Driver Class Initialized
INFO - 2023-05-06 10:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:07:10 --> Form Validation Class Initialized
INFO - 2023-05-06 10:07:10 --> Controller Class Initialized
INFO - 2023-05-06 10:07:10 --> Model "m_user" initialized
INFO - 2023-05-06 10:07:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 10:07:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 10:07:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 10:07:10 --> Final output sent to browser
INFO - 2023-05-06 10:07:16 --> Config Class Initialized
INFO - 2023-05-06 10:07:16 --> Hooks Class Initialized
INFO - 2023-05-06 10:07:16 --> Utf8 Class Initialized
INFO - 2023-05-06 10:07:16 --> URI Class Initialized
INFO - 2023-05-06 10:07:16 --> Router Class Initialized
INFO - 2023-05-06 10:07:16 --> Output Class Initialized
INFO - 2023-05-06 10:07:16 --> Security Class Initialized
INFO - 2023-05-06 10:07:16 --> Input Class Initialized
INFO - 2023-05-06 10:07:16 --> Language Class Initialized
INFO - 2023-05-06 10:07:16 --> Loader Class Initialized
INFO - 2023-05-06 10:07:16 --> Helper loaded: url_helper
INFO - 2023-05-06 10:07:16 --> Helper loaded: form_helper
INFO - 2023-05-06 10:07:16 --> Database Driver Class Initialized
INFO - 2023-05-06 10:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:07:16 --> Form Validation Class Initialized
INFO - 2023-05-06 10:07:16 --> Controller Class Initialized
INFO - 2023-05-06 10:07:16 --> Model "m_user" initialized
INFO - 2023-05-06 10:07:16 --> Config Class Initialized
INFO - 2023-05-06 10:07:16 --> Hooks Class Initialized
INFO - 2023-05-06 10:07:16 --> Utf8 Class Initialized
INFO - 2023-05-06 10:07:16 --> URI Class Initialized
INFO - 2023-05-06 10:07:16 --> Router Class Initialized
INFO - 2023-05-06 10:07:16 --> Output Class Initialized
INFO - 2023-05-06 10:07:16 --> Security Class Initialized
INFO - 2023-05-06 10:07:16 --> Input Class Initialized
INFO - 2023-05-06 10:07:16 --> Language Class Initialized
INFO - 2023-05-06 10:07:16 --> Loader Class Initialized
INFO - 2023-05-06 10:07:16 --> Helper loaded: url_helper
INFO - 2023-05-06 10:07:16 --> Helper loaded: form_helper
INFO - 2023-05-06 10:07:16 --> Database Driver Class Initialized
INFO - 2023-05-06 10:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:07:16 --> Form Validation Class Initialized
INFO - 2023-05-06 10:07:16 --> Controller Class Initialized
INFO - 2023-05-06 10:07:16 --> Model "m_user" initialized
INFO - 2023-05-06 10:07:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 10:07:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 10:07:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 10:07:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 10:07:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 10:07:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 10:07:16 --> Final output sent to browser
INFO - 2023-05-06 10:07:22 --> Config Class Initialized
INFO - 2023-05-06 10:07:22 --> Hooks Class Initialized
INFO - 2023-05-06 10:07:22 --> Utf8 Class Initialized
INFO - 2023-05-06 10:07:22 --> URI Class Initialized
INFO - 2023-05-06 10:07:22 --> Router Class Initialized
INFO - 2023-05-06 10:07:22 --> Output Class Initialized
INFO - 2023-05-06 10:07:22 --> Security Class Initialized
INFO - 2023-05-06 10:07:22 --> Input Class Initialized
INFO - 2023-05-06 10:07:22 --> Language Class Initialized
INFO - 2023-05-06 10:07:22 --> Loader Class Initialized
INFO - 2023-05-06 10:07:22 --> Helper loaded: url_helper
INFO - 2023-05-06 10:07:22 --> Helper loaded: form_helper
INFO - 2023-05-06 10:07:22 --> Database Driver Class Initialized
INFO - 2023-05-06 10:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:07:22 --> Form Validation Class Initialized
INFO - 2023-05-06 10:07:22 --> Controller Class Initialized
INFO - 2023-05-06 10:07:22 --> Model "m_user" initialized
INFO - 2023-05-06 10:07:22 --> Config Class Initialized
INFO - 2023-05-06 10:07:22 --> Hooks Class Initialized
INFO - 2023-05-06 10:07:22 --> Utf8 Class Initialized
INFO - 2023-05-06 10:07:22 --> URI Class Initialized
INFO - 2023-05-06 10:07:22 --> Router Class Initialized
INFO - 2023-05-06 10:07:22 --> Output Class Initialized
INFO - 2023-05-06 10:07:22 --> Security Class Initialized
INFO - 2023-05-06 10:07:22 --> Input Class Initialized
INFO - 2023-05-06 10:07:22 --> Language Class Initialized
INFO - 2023-05-06 10:07:22 --> Loader Class Initialized
INFO - 2023-05-06 10:07:22 --> Helper loaded: url_helper
INFO - 2023-05-06 10:07:22 --> Helper loaded: form_helper
INFO - 2023-05-06 10:07:22 --> Database Driver Class Initialized
INFO - 2023-05-06 10:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 10:07:22 --> Form Validation Class Initialized
INFO - 2023-05-06 10:07:22 --> Controller Class Initialized
INFO - 2023-05-06 10:07:22 --> Model "m_user" initialized
INFO - 2023-05-06 10:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 10:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 10:07:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 10:07:22 --> Final output sent to browser
INFO - 2023-05-06 13:32:17 --> Config Class Initialized
INFO - 2023-05-06 13:32:17 --> Hooks Class Initialized
INFO - 2023-05-06 13:32:17 --> Utf8 Class Initialized
INFO - 2023-05-06 13:32:17 --> URI Class Initialized
INFO - 2023-05-06 13:32:18 --> Router Class Initialized
INFO - 2023-05-06 13:32:18 --> Output Class Initialized
INFO - 2023-05-06 13:32:18 --> Security Class Initialized
INFO - 2023-05-06 13:32:18 --> Input Class Initialized
INFO - 2023-05-06 13:32:18 --> Language Class Initialized
INFO - 2023-05-06 13:32:18 --> Loader Class Initialized
INFO - 2023-05-06 13:32:18 --> Helper loaded: url_helper
INFO - 2023-05-06 13:32:18 --> Helper loaded: form_helper
INFO - 2023-05-06 13:32:18 --> Database Driver Class Initialized
INFO - 2023-05-06 13:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:32:18 --> Form Validation Class Initialized
INFO - 2023-05-06 13:32:18 --> Controller Class Initialized
INFO - 2023-05-06 13:32:18 --> Model "m_user" initialized
INFO - 2023-05-06 13:32:18 --> Config Class Initialized
INFO - 2023-05-06 13:32:18 --> Hooks Class Initialized
INFO - 2023-05-06 13:32:18 --> Utf8 Class Initialized
INFO - 2023-05-06 13:32:18 --> URI Class Initialized
INFO - 2023-05-06 13:32:18 --> Router Class Initialized
INFO - 2023-05-06 13:32:18 --> Output Class Initialized
INFO - 2023-05-06 13:32:18 --> Security Class Initialized
INFO - 2023-05-06 13:32:18 --> Input Class Initialized
INFO - 2023-05-06 13:32:18 --> Language Class Initialized
INFO - 2023-05-06 13:32:18 --> Loader Class Initialized
INFO - 2023-05-06 13:32:18 --> Helper loaded: url_helper
INFO - 2023-05-06 13:32:18 --> Helper loaded: form_helper
INFO - 2023-05-06 13:32:18 --> Database Driver Class Initialized
INFO - 2023-05-06 13:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:32:18 --> Form Validation Class Initialized
INFO - 2023-05-06 13:32:18 --> Controller Class Initialized
INFO - 2023-05-06 13:32:18 --> Model "m_user" initialized
INFO - 2023-05-06 13:32:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 13:32:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 13:32:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 13:32:18 --> Final output sent to browser
INFO - 2023-05-06 13:32:22 --> Config Class Initialized
INFO - 2023-05-06 13:32:22 --> Hooks Class Initialized
INFO - 2023-05-06 13:32:22 --> Utf8 Class Initialized
INFO - 2023-05-06 13:32:22 --> URI Class Initialized
INFO - 2023-05-06 13:32:22 --> Router Class Initialized
INFO - 2023-05-06 13:32:22 --> Output Class Initialized
INFO - 2023-05-06 13:32:22 --> Security Class Initialized
INFO - 2023-05-06 13:32:22 --> Input Class Initialized
INFO - 2023-05-06 13:32:22 --> Language Class Initialized
INFO - 2023-05-06 13:32:22 --> Loader Class Initialized
INFO - 2023-05-06 13:32:22 --> Helper loaded: url_helper
INFO - 2023-05-06 13:32:22 --> Helper loaded: form_helper
INFO - 2023-05-06 13:32:22 --> Database Driver Class Initialized
INFO - 2023-05-06 13:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:32:22 --> Form Validation Class Initialized
INFO - 2023-05-06 13:32:22 --> Controller Class Initialized
INFO - 2023-05-06 13:32:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 13:32:22 --> Final output sent to browser
INFO - 2023-05-06 13:32:23 --> Config Class Initialized
INFO - 2023-05-06 13:32:23 --> Hooks Class Initialized
INFO - 2023-05-06 13:32:23 --> Utf8 Class Initialized
INFO - 2023-05-06 13:32:23 --> URI Class Initialized
INFO - 2023-05-06 13:32:23 --> Router Class Initialized
INFO - 2023-05-06 13:32:23 --> Output Class Initialized
INFO - 2023-05-06 13:32:23 --> Security Class Initialized
INFO - 2023-05-06 13:32:23 --> Input Class Initialized
INFO - 2023-05-06 13:32:23 --> Language Class Initialized
INFO - 2023-05-06 13:32:23 --> Loader Class Initialized
INFO - 2023-05-06 13:32:23 --> Helper loaded: url_helper
INFO - 2023-05-06 13:32:23 --> Helper loaded: form_helper
INFO - 2023-05-06 13:32:23 --> Database Driver Class Initialized
INFO - 2023-05-06 13:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:32:23 --> Form Validation Class Initialized
INFO - 2023-05-06 13:32:23 --> Controller Class Initialized
INFO - 2023-05-06 13:32:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 13:32:23 --> Final output sent to browser
INFO - 2023-05-06 13:32:55 --> Config Class Initialized
INFO - 2023-05-06 13:32:55 --> Hooks Class Initialized
INFO - 2023-05-06 13:32:55 --> Utf8 Class Initialized
INFO - 2023-05-06 13:32:55 --> URI Class Initialized
INFO - 2023-05-06 13:32:55 --> Router Class Initialized
INFO - 2023-05-06 13:32:55 --> Output Class Initialized
INFO - 2023-05-06 13:32:55 --> Security Class Initialized
INFO - 2023-05-06 13:32:55 --> Input Class Initialized
INFO - 2023-05-06 13:32:55 --> Language Class Initialized
INFO - 2023-05-06 13:32:55 --> Loader Class Initialized
INFO - 2023-05-06 13:32:55 --> Helper loaded: url_helper
INFO - 2023-05-06 13:32:55 --> Helper loaded: form_helper
INFO - 2023-05-06 13:32:55 --> Database Driver Class Initialized
INFO - 2023-05-06 13:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:32:55 --> Form Validation Class Initialized
INFO - 2023-05-06 13:32:55 --> Controller Class Initialized
INFO - 2023-05-06 13:32:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-06 13:32:55 --> Final output sent to browser
INFO - 2023-05-06 13:37:16 --> Config Class Initialized
INFO - 2023-05-06 13:37:16 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:16 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:16 --> URI Class Initialized
INFO - 2023-05-06 13:37:16 --> Router Class Initialized
INFO - 2023-05-06 13:37:16 --> Output Class Initialized
INFO - 2023-05-06 13:37:16 --> Security Class Initialized
INFO - 2023-05-06 13:37:16 --> Input Class Initialized
INFO - 2023-05-06 13:37:16 --> Language Class Initialized
INFO - 2023-05-06 13:37:16 --> Loader Class Initialized
INFO - 2023-05-06 13:37:16 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:16 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:16 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:16 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:16 --> Controller Class Initialized
INFO - 2023-05-06 13:37:16 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 13:37:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 13:37:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 13:37:16 --> Final output sent to browser
INFO - 2023-05-06 13:37:22 --> Config Class Initialized
INFO - 2023-05-06 13:37:22 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:22 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:22 --> URI Class Initialized
INFO - 2023-05-06 13:37:22 --> Router Class Initialized
INFO - 2023-05-06 13:37:22 --> Output Class Initialized
INFO - 2023-05-06 13:37:22 --> Security Class Initialized
INFO - 2023-05-06 13:37:22 --> Input Class Initialized
INFO - 2023-05-06 13:37:22 --> Language Class Initialized
INFO - 2023-05-06 13:37:22 --> Loader Class Initialized
INFO - 2023-05-06 13:37:22 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:22 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:22 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:22 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:22 --> Controller Class Initialized
INFO - 2023-05-06 13:37:22 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:22 --> Config Class Initialized
INFO - 2023-05-06 13:37:22 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:22 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:22 --> URI Class Initialized
INFO - 2023-05-06 13:37:22 --> Router Class Initialized
INFO - 2023-05-06 13:37:22 --> Output Class Initialized
INFO - 2023-05-06 13:37:22 --> Security Class Initialized
INFO - 2023-05-06 13:37:22 --> Input Class Initialized
INFO - 2023-05-06 13:37:22 --> Language Class Initialized
INFO - 2023-05-06 13:37:22 --> Loader Class Initialized
INFO - 2023-05-06 13:37:22 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:22 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:22 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:22 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:22 --> Controller Class Initialized
INFO - 2023-05-06 13:37:22 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 13:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 13:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 13:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 13:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 13:37:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 13:37:22 --> Final output sent to browser
INFO - 2023-05-06 13:37:29 --> Config Class Initialized
INFO - 2023-05-06 13:37:29 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:29 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:29 --> URI Class Initialized
INFO - 2023-05-06 13:37:29 --> Router Class Initialized
INFO - 2023-05-06 13:37:29 --> Output Class Initialized
INFO - 2023-05-06 13:37:29 --> Security Class Initialized
INFO - 2023-05-06 13:37:29 --> Input Class Initialized
INFO - 2023-05-06 13:37:29 --> Language Class Initialized
INFO - 2023-05-06 13:37:29 --> Loader Class Initialized
INFO - 2023-05-06 13:37:29 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:29 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:29 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:29 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:29 --> Controller Class Initialized
INFO - 2023-05-06 13:37:29 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 13:37:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 13:37:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 13:37:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 13:37:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 13:37:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 13:37:29 --> Final output sent to browser
INFO - 2023-05-06 13:37:30 --> Config Class Initialized
INFO - 2023-05-06 13:37:30 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:30 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:30 --> URI Class Initialized
INFO - 2023-05-06 13:37:30 --> Router Class Initialized
INFO - 2023-05-06 13:37:30 --> Output Class Initialized
INFO - 2023-05-06 13:37:30 --> Security Class Initialized
INFO - 2023-05-06 13:37:30 --> Input Class Initialized
INFO - 2023-05-06 13:37:30 --> Language Class Initialized
INFO - 2023-05-06 13:37:30 --> Loader Class Initialized
INFO - 2023-05-06 13:37:30 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:30 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:30 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:30 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:30 --> Controller Class Initialized
INFO - 2023-05-06 13:37:30 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 13:37:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 13:37:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 13:37:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 13:37:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 13:37:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 13:37:30 --> Final output sent to browser
INFO - 2023-05-06 13:37:32 --> Config Class Initialized
INFO - 2023-05-06 13:37:32 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:32 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:32 --> URI Class Initialized
INFO - 2023-05-06 13:37:32 --> Router Class Initialized
INFO - 2023-05-06 13:37:32 --> Output Class Initialized
INFO - 2023-05-06 13:37:32 --> Security Class Initialized
INFO - 2023-05-06 13:37:32 --> Input Class Initialized
INFO - 2023-05-06 13:37:32 --> Language Class Initialized
INFO - 2023-05-06 13:37:32 --> Loader Class Initialized
INFO - 2023-05-06 13:37:32 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:32 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:32 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:32 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:32 --> Controller Class Initialized
INFO - 2023-05-06 13:37:32 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 13:37:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 13:37:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 13:37:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 13:37:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 13:37:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 13:37:32 --> Final output sent to browser
INFO - 2023-05-06 13:37:34 --> Config Class Initialized
INFO - 2023-05-06 13:37:34 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:34 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:34 --> URI Class Initialized
INFO - 2023-05-06 13:37:34 --> Router Class Initialized
INFO - 2023-05-06 13:37:34 --> Output Class Initialized
INFO - 2023-05-06 13:37:34 --> Security Class Initialized
INFO - 2023-05-06 13:37:34 --> Input Class Initialized
INFO - 2023-05-06 13:37:34 --> Language Class Initialized
INFO - 2023-05-06 13:37:34 --> Loader Class Initialized
INFO - 2023-05-06 13:37:34 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:34 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:34 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:34 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:34 --> Controller Class Initialized
INFO - 2023-05-06 13:37:34 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 13:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 13:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 13:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 13:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 13:37:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 13:37:34 --> Final output sent to browser
INFO - 2023-05-06 13:37:35 --> Config Class Initialized
INFO - 2023-05-06 13:37:35 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:35 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:35 --> URI Class Initialized
INFO - 2023-05-06 13:37:35 --> Router Class Initialized
INFO - 2023-05-06 13:37:35 --> Output Class Initialized
INFO - 2023-05-06 13:37:35 --> Security Class Initialized
INFO - 2023-05-06 13:37:35 --> Input Class Initialized
INFO - 2023-05-06 13:37:35 --> Language Class Initialized
INFO - 2023-05-06 13:37:35 --> Loader Class Initialized
INFO - 2023-05-06 13:37:35 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:35 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:35 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:35 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:35 --> Controller Class Initialized
INFO - 2023-05-06 13:37:35 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 13:37:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 13:37:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 13:37:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 13:37:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 13:37:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 13:37:35 --> Final output sent to browser
INFO - 2023-05-06 13:37:38 --> Config Class Initialized
INFO - 2023-05-06 13:37:38 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:39 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:39 --> URI Class Initialized
INFO - 2023-05-06 13:37:39 --> Router Class Initialized
INFO - 2023-05-06 13:37:39 --> Output Class Initialized
INFO - 2023-05-06 13:37:39 --> Security Class Initialized
INFO - 2023-05-06 13:37:39 --> Input Class Initialized
INFO - 2023-05-06 13:37:39 --> Language Class Initialized
ERROR - 2023-05-06 13:37:39 --> 404 Page Not Found: C_tutor/form_ubah
INFO - 2023-05-06 13:37:40 --> Config Class Initialized
INFO - 2023-05-06 13:37:40 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:40 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:40 --> URI Class Initialized
INFO - 2023-05-06 13:37:40 --> Router Class Initialized
INFO - 2023-05-06 13:37:40 --> Output Class Initialized
INFO - 2023-05-06 13:37:40 --> Security Class Initialized
INFO - 2023-05-06 13:37:40 --> Input Class Initialized
INFO - 2023-05-06 13:37:40 --> Language Class Initialized
INFO - 2023-05-06 13:37:40 --> Loader Class Initialized
INFO - 2023-05-06 13:37:40 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:40 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:40 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:40 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:40 --> Controller Class Initialized
INFO - 2023-05-06 13:37:40 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 13:37:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 13:37:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 13:37:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 13:37:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 13:37:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 13:37:40 --> Final output sent to browser
INFO - 2023-05-06 13:37:42 --> Config Class Initialized
INFO - 2023-05-06 13:37:42 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:42 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:42 --> URI Class Initialized
INFO - 2023-05-06 13:37:42 --> Router Class Initialized
INFO - 2023-05-06 13:37:42 --> Output Class Initialized
INFO - 2023-05-06 13:37:42 --> Security Class Initialized
INFO - 2023-05-06 13:37:42 --> Input Class Initialized
INFO - 2023-05-06 13:37:42 --> Language Class Initialized
INFO - 2023-05-06 13:37:42 --> Loader Class Initialized
INFO - 2023-05-06 13:37:42 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:42 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:42 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:42 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:42 --> Controller Class Initialized
INFO - 2023-05-06 13:37:42 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:42 --> Config Class Initialized
INFO - 2023-05-06 13:37:42 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:42 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:42 --> URI Class Initialized
INFO - 2023-05-06 13:37:42 --> Router Class Initialized
INFO - 2023-05-06 13:37:42 --> Output Class Initialized
INFO - 2023-05-06 13:37:42 --> Security Class Initialized
INFO - 2023-05-06 13:37:42 --> Input Class Initialized
INFO - 2023-05-06 13:37:42 --> Language Class Initialized
INFO - 2023-05-06 13:37:42 --> Loader Class Initialized
INFO - 2023-05-06 13:37:42 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:42 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:42 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:42 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:42 --> Controller Class Initialized
INFO - 2023-05-06 13:37:42 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 13:37:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 13:37:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 13:37:42 --> Final output sent to browser
INFO - 2023-05-06 13:37:46 --> Config Class Initialized
INFO - 2023-05-06 13:37:46 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:46 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:46 --> URI Class Initialized
INFO - 2023-05-06 13:37:46 --> Router Class Initialized
INFO - 2023-05-06 13:37:46 --> Output Class Initialized
INFO - 2023-05-06 13:37:46 --> Security Class Initialized
INFO - 2023-05-06 13:37:46 --> Input Class Initialized
INFO - 2023-05-06 13:37:46 --> Language Class Initialized
INFO - 2023-05-06 13:37:46 --> Loader Class Initialized
INFO - 2023-05-06 13:37:46 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:46 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:46 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:46 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:46 --> Controller Class Initialized
INFO - 2023-05-06 13:37:46 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:47 --> Config Class Initialized
INFO - 2023-05-06 13:37:47 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:47 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:47 --> URI Class Initialized
INFO - 2023-05-06 13:37:47 --> Router Class Initialized
INFO - 2023-05-06 13:37:47 --> Output Class Initialized
INFO - 2023-05-06 13:37:47 --> Security Class Initialized
INFO - 2023-05-06 13:37:47 --> Input Class Initialized
INFO - 2023-05-06 13:37:47 --> Language Class Initialized
INFO - 2023-05-06 13:37:47 --> Loader Class Initialized
INFO - 2023-05-06 13:37:47 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:47 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:47 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:47 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:47 --> Controller Class Initialized
INFO - 2023-05-06 13:37:47 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 13:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 13:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 13:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 13:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 13:37:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 13:37:47 --> Final output sent to browser
INFO - 2023-05-06 13:37:54 --> Config Class Initialized
INFO - 2023-05-06 13:37:54 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:54 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:54 --> URI Class Initialized
INFO - 2023-05-06 13:37:54 --> Router Class Initialized
INFO - 2023-05-06 13:37:54 --> Output Class Initialized
INFO - 2023-05-06 13:37:54 --> Security Class Initialized
INFO - 2023-05-06 13:37:54 --> Input Class Initialized
INFO - 2023-05-06 13:37:54 --> Language Class Initialized
ERROR - 2023-05-06 13:37:54 --> 404 Page Not Found: Group/index
INFO - 2023-05-06 13:37:56 --> Config Class Initialized
INFO - 2023-05-06 13:37:56 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:56 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:56 --> URI Class Initialized
INFO - 2023-05-06 13:37:56 --> Router Class Initialized
INFO - 2023-05-06 13:37:56 --> Output Class Initialized
INFO - 2023-05-06 13:37:56 --> Security Class Initialized
INFO - 2023-05-06 13:37:56 --> Input Class Initialized
INFO - 2023-05-06 13:37:56 --> Language Class Initialized
INFO - 2023-05-06 13:37:56 --> Loader Class Initialized
INFO - 2023-05-06 13:37:56 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:56 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:56 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:56 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:56 --> Controller Class Initialized
INFO - 2023-05-06 13:37:56 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 13:37:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 13:37:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 13:37:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 13:37:57 --> Config Class Initialized
INFO - 2023-05-06 13:37:57 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:57 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:57 --> URI Class Initialized
INFO - 2023-05-06 13:37:57 --> Router Class Initialized
INFO - 2023-05-06 13:37:58 --> Output Class Initialized
INFO - 2023-05-06 13:37:58 --> Security Class Initialized
INFO - 2023-05-06 13:37:58 --> Input Class Initialized
INFO - 2023-05-06 13:37:58 --> Language Class Initialized
ERROR - 2023-05-06 13:37:58 --> 404 Page Not Found: Tutor/index
INFO - 2023-05-06 13:37:59 --> Config Class Initialized
INFO - 2023-05-06 13:37:59 --> Hooks Class Initialized
INFO - 2023-05-06 13:37:59 --> Utf8 Class Initialized
INFO - 2023-05-06 13:37:59 --> URI Class Initialized
INFO - 2023-05-06 13:37:59 --> Router Class Initialized
INFO - 2023-05-06 13:37:59 --> Output Class Initialized
INFO - 2023-05-06 13:37:59 --> Security Class Initialized
INFO - 2023-05-06 13:37:59 --> Input Class Initialized
INFO - 2023-05-06 13:37:59 --> Language Class Initialized
INFO - 2023-05-06 13:37:59 --> Loader Class Initialized
INFO - 2023-05-06 13:37:59 --> Helper loaded: url_helper
INFO - 2023-05-06 13:37:59 --> Helper loaded: form_helper
INFO - 2023-05-06 13:37:59 --> Database Driver Class Initialized
INFO - 2023-05-06 13:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:37:59 --> Form Validation Class Initialized
INFO - 2023-05-06 13:37:59 --> Controller Class Initialized
INFO - 2023-05-06 13:37:59 --> Model "m_user" initialized
INFO - 2023-05-06 13:37:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 13:37:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 13:37:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 13:37:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 13:37:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 13:37:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 13:37:59 --> Final output sent to browser
INFO - 2023-05-06 13:38:02 --> Config Class Initialized
INFO - 2023-05-06 13:38:02 --> Hooks Class Initialized
INFO - 2023-05-06 13:38:02 --> Utf8 Class Initialized
INFO - 2023-05-06 13:38:02 --> URI Class Initialized
INFO - 2023-05-06 13:38:02 --> Router Class Initialized
INFO - 2023-05-06 13:38:02 --> Output Class Initialized
INFO - 2023-05-06 13:38:02 --> Security Class Initialized
INFO - 2023-05-06 13:38:03 --> Input Class Initialized
INFO - 2023-05-06 13:38:03 --> Language Class Initialized
INFO - 2023-05-06 13:38:03 --> Loader Class Initialized
INFO - 2023-05-06 13:38:03 --> Helper loaded: url_helper
INFO - 2023-05-06 13:38:03 --> Helper loaded: form_helper
INFO - 2023-05-06 13:38:03 --> Database Driver Class Initialized
INFO - 2023-05-06 13:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:38:03 --> Form Validation Class Initialized
INFO - 2023-05-06 13:38:03 --> Controller Class Initialized
INFO - 2023-05-06 13:38:03 --> Model "m_user" initialized
INFO - 2023-05-06 13:38:03 --> Config Class Initialized
INFO - 2023-05-06 13:38:03 --> Hooks Class Initialized
INFO - 2023-05-06 13:38:03 --> Utf8 Class Initialized
INFO - 2023-05-06 13:38:03 --> URI Class Initialized
INFO - 2023-05-06 13:38:03 --> Router Class Initialized
INFO - 2023-05-06 13:38:03 --> Output Class Initialized
INFO - 2023-05-06 13:38:03 --> Security Class Initialized
INFO - 2023-05-06 13:38:03 --> Input Class Initialized
INFO - 2023-05-06 13:38:03 --> Language Class Initialized
INFO - 2023-05-06 13:38:03 --> Loader Class Initialized
INFO - 2023-05-06 13:38:03 --> Helper loaded: url_helper
INFO - 2023-05-06 13:38:03 --> Helper loaded: form_helper
INFO - 2023-05-06 13:38:03 --> Database Driver Class Initialized
INFO - 2023-05-06 13:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:38:03 --> Form Validation Class Initialized
INFO - 2023-05-06 13:38:03 --> Controller Class Initialized
INFO - 2023-05-06 13:38:03 --> Model "m_user" initialized
INFO - 2023-05-06 13:38:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 13:38:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 13:38:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 13:38:03 --> Final output sent to browser
INFO - 2023-05-06 13:38:16 --> Config Class Initialized
INFO - 2023-05-06 13:38:16 --> Hooks Class Initialized
INFO - 2023-05-06 13:38:16 --> Utf8 Class Initialized
INFO - 2023-05-06 13:38:16 --> URI Class Initialized
INFO - 2023-05-06 13:38:16 --> Router Class Initialized
INFO - 2023-05-06 13:38:16 --> Output Class Initialized
INFO - 2023-05-06 13:38:16 --> Security Class Initialized
INFO - 2023-05-06 13:38:16 --> Input Class Initialized
INFO - 2023-05-06 13:38:16 --> Language Class Initialized
INFO - 2023-05-06 13:38:16 --> Loader Class Initialized
INFO - 2023-05-06 13:38:16 --> Helper loaded: url_helper
INFO - 2023-05-06 13:38:16 --> Helper loaded: form_helper
INFO - 2023-05-06 13:38:16 --> Database Driver Class Initialized
INFO - 2023-05-06 13:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:38:16 --> Form Validation Class Initialized
INFO - 2023-05-06 13:38:16 --> Controller Class Initialized
INFO - 2023-05-06 13:38:16 --> Model "m_user" initialized
INFO - 2023-05-06 13:38:16 --> Config Class Initialized
INFO - 2023-05-06 13:38:16 --> Hooks Class Initialized
INFO - 2023-05-06 13:38:16 --> Utf8 Class Initialized
INFO - 2023-05-06 13:38:16 --> URI Class Initialized
INFO - 2023-05-06 13:38:16 --> Router Class Initialized
INFO - 2023-05-06 13:38:16 --> Output Class Initialized
INFO - 2023-05-06 13:38:16 --> Security Class Initialized
INFO - 2023-05-06 13:38:16 --> Input Class Initialized
INFO - 2023-05-06 13:38:16 --> Language Class Initialized
INFO - 2023-05-06 13:38:16 --> Loader Class Initialized
INFO - 2023-05-06 13:38:16 --> Helper loaded: url_helper
INFO - 2023-05-06 13:38:16 --> Helper loaded: form_helper
INFO - 2023-05-06 13:38:16 --> Database Driver Class Initialized
INFO - 2023-05-06 13:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:38:16 --> Form Validation Class Initialized
INFO - 2023-05-06 13:38:16 --> Controller Class Initialized
INFO - 2023-05-06 13:38:16 --> Model "m_user" initialized
INFO - 2023-05-06 13:38:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 13:38:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 13:38:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 13:38:16 --> Final output sent to browser
INFO - 2023-05-06 13:38:25 --> Config Class Initialized
INFO - 2023-05-06 13:38:25 --> Hooks Class Initialized
INFO - 2023-05-06 13:38:25 --> Utf8 Class Initialized
INFO - 2023-05-06 13:38:25 --> URI Class Initialized
INFO - 2023-05-06 13:38:25 --> Router Class Initialized
INFO - 2023-05-06 13:38:25 --> Output Class Initialized
INFO - 2023-05-06 13:38:25 --> Security Class Initialized
INFO - 2023-05-06 13:38:25 --> Input Class Initialized
INFO - 2023-05-06 13:38:25 --> Language Class Initialized
INFO - 2023-05-06 13:38:25 --> Loader Class Initialized
INFO - 2023-05-06 13:38:25 --> Helper loaded: url_helper
INFO - 2023-05-06 13:38:25 --> Helper loaded: form_helper
INFO - 2023-05-06 13:38:25 --> Database Driver Class Initialized
INFO - 2023-05-06 13:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:38:25 --> Form Validation Class Initialized
INFO - 2023-05-06 13:38:25 --> Controller Class Initialized
INFO - 2023-05-06 13:38:25 --> Model "m_user" initialized
INFO - 2023-05-06 13:38:25 --> Config Class Initialized
INFO - 2023-05-06 13:38:25 --> Hooks Class Initialized
INFO - 2023-05-06 13:38:25 --> Utf8 Class Initialized
INFO - 2023-05-06 13:38:25 --> URI Class Initialized
INFO - 2023-05-06 13:38:25 --> Router Class Initialized
INFO - 2023-05-06 13:38:25 --> Output Class Initialized
INFO - 2023-05-06 13:38:25 --> Security Class Initialized
INFO - 2023-05-06 13:38:25 --> Input Class Initialized
INFO - 2023-05-06 13:38:25 --> Language Class Initialized
INFO - 2023-05-06 13:38:25 --> Loader Class Initialized
INFO - 2023-05-06 13:38:25 --> Helper loaded: url_helper
INFO - 2023-05-06 13:38:25 --> Helper loaded: form_helper
INFO - 2023-05-06 13:38:25 --> Database Driver Class Initialized
INFO - 2023-05-06 13:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 13:38:25 --> Form Validation Class Initialized
INFO - 2023-05-06 13:38:25 --> Controller Class Initialized
INFO - 2023-05-06 13:38:25 --> Model "m_user" initialized
INFO - 2023-05-06 13:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 13:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 13:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 13:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 13:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 13:38:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 13:38:25 --> Final output sent to browser
INFO - 2023-05-06 14:40:50 --> Config Class Initialized
INFO - 2023-05-06 14:40:50 --> Hooks Class Initialized
INFO - 2023-05-06 14:40:50 --> Utf8 Class Initialized
INFO - 2023-05-06 14:40:50 --> URI Class Initialized
INFO - 2023-05-06 14:40:50 --> Router Class Initialized
INFO - 2023-05-06 14:40:50 --> Output Class Initialized
INFO - 2023-05-06 14:40:50 --> Security Class Initialized
INFO - 2023-05-06 14:40:50 --> Input Class Initialized
INFO - 2023-05-06 14:40:50 --> Language Class Initialized
INFO - 2023-05-06 14:40:50 --> Loader Class Initialized
INFO - 2023-05-06 14:40:50 --> Helper loaded: url_helper
INFO - 2023-05-06 14:40:50 --> Helper loaded: form_helper
INFO - 2023-05-06 14:40:50 --> Database Driver Class Initialized
INFO - 2023-05-06 14:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:40:50 --> Form Validation Class Initialized
INFO - 2023-05-06 14:40:50 --> Controller Class Initialized
INFO - 2023-05-06 14:40:50 --> Model "m_user" initialized
INFO - 2023-05-06 14:40:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 14:40:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 14:40:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 14:40:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 14:40:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 14:40:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 14:40:50 --> Final output sent to browser
INFO - 2023-05-06 14:40:58 --> Config Class Initialized
INFO - 2023-05-06 14:40:58 --> Hooks Class Initialized
INFO - 2023-05-06 14:40:58 --> Utf8 Class Initialized
INFO - 2023-05-06 14:40:58 --> URI Class Initialized
INFO - 2023-05-06 14:40:58 --> Router Class Initialized
INFO - 2023-05-06 14:40:58 --> Output Class Initialized
INFO - 2023-05-06 14:40:58 --> Security Class Initialized
INFO - 2023-05-06 14:40:58 --> Input Class Initialized
INFO - 2023-05-06 14:40:58 --> Language Class Initialized
INFO - 2023-05-06 14:40:58 --> Loader Class Initialized
INFO - 2023-05-06 14:40:58 --> Helper loaded: url_helper
INFO - 2023-05-06 14:40:58 --> Helper loaded: form_helper
INFO - 2023-05-06 14:40:59 --> Database Driver Class Initialized
INFO - 2023-05-06 14:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:40:59 --> Form Validation Class Initialized
INFO - 2023-05-06 14:40:59 --> Controller Class Initialized
INFO - 2023-05-06 14:40:59 --> Model "m_user" initialized
INFO - 2023-05-06 14:40:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 14:40:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 14:40:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 14:40:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 14:40:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 14:40:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 14:40:59 --> Final output sent to browser
INFO - 2023-05-06 14:41:00 --> Config Class Initialized
INFO - 2023-05-06 14:41:00 --> Hooks Class Initialized
INFO - 2023-05-06 14:41:00 --> Utf8 Class Initialized
INFO - 2023-05-06 14:41:00 --> URI Class Initialized
INFO - 2023-05-06 14:41:00 --> Router Class Initialized
INFO - 2023-05-06 14:41:00 --> Output Class Initialized
INFO - 2023-05-06 14:41:00 --> Security Class Initialized
INFO - 2023-05-06 14:41:00 --> Input Class Initialized
INFO - 2023-05-06 14:41:00 --> Language Class Initialized
INFO - 2023-05-06 14:41:00 --> Loader Class Initialized
INFO - 2023-05-06 14:41:00 --> Helper loaded: url_helper
INFO - 2023-05-06 14:41:00 --> Helper loaded: form_helper
INFO - 2023-05-06 14:41:00 --> Database Driver Class Initialized
INFO - 2023-05-06 14:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:41:00 --> Form Validation Class Initialized
INFO - 2023-05-06 14:41:00 --> Controller Class Initialized
INFO - 2023-05-06 14:41:00 --> Model "m_user" initialized
INFO - 2023-05-06 14:41:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 14:41:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 14:41:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 14:41:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 14:41:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 14:41:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 14:41:00 --> Final output sent to browser
INFO - 2023-05-06 14:41:03 --> Config Class Initialized
INFO - 2023-05-06 14:41:03 --> Hooks Class Initialized
INFO - 2023-05-06 14:41:03 --> Utf8 Class Initialized
INFO - 2023-05-06 14:41:03 --> URI Class Initialized
INFO - 2023-05-06 14:41:03 --> Router Class Initialized
INFO - 2023-05-06 14:41:03 --> Output Class Initialized
INFO - 2023-05-06 14:41:03 --> Security Class Initialized
INFO - 2023-05-06 14:41:03 --> Input Class Initialized
INFO - 2023-05-06 14:41:03 --> Language Class Initialized
INFO - 2023-05-06 14:41:03 --> Loader Class Initialized
INFO - 2023-05-06 14:41:03 --> Helper loaded: url_helper
INFO - 2023-05-06 14:41:03 --> Helper loaded: form_helper
INFO - 2023-05-06 14:41:03 --> Database Driver Class Initialized
INFO - 2023-05-06 14:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:41:03 --> Form Validation Class Initialized
INFO - 2023-05-06 14:41:03 --> Controller Class Initialized
INFO - 2023-05-06 14:41:03 --> Model "m_user" initialized
INFO - 2023-05-06 14:41:03 --> Config Class Initialized
INFO - 2023-05-06 14:41:03 --> Hooks Class Initialized
INFO - 2023-05-06 14:41:03 --> Utf8 Class Initialized
INFO - 2023-05-06 14:41:03 --> URI Class Initialized
INFO - 2023-05-06 14:41:03 --> Router Class Initialized
INFO - 2023-05-06 14:41:03 --> Output Class Initialized
INFO - 2023-05-06 14:41:03 --> Security Class Initialized
INFO - 2023-05-06 14:41:03 --> Input Class Initialized
INFO - 2023-05-06 14:41:03 --> Language Class Initialized
INFO - 2023-05-06 14:41:03 --> Loader Class Initialized
INFO - 2023-05-06 14:41:03 --> Helper loaded: url_helper
INFO - 2023-05-06 14:41:03 --> Helper loaded: form_helper
INFO - 2023-05-06 14:41:03 --> Database Driver Class Initialized
INFO - 2023-05-06 14:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:41:04 --> Form Validation Class Initialized
INFO - 2023-05-06 14:41:04 --> Controller Class Initialized
INFO - 2023-05-06 14:41:04 --> Model "m_user" initialized
INFO - 2023-05-06 14:41:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 14:41:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 14:41:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 14:41:04 --> Final output sent to browser
INFO - 2023-05-06 14:41:10 --> Config Class Initialized
INFO - 2023-05-06 14:41:10 --> Hooks Class Initialized
INFO - 2023-05-06 14:41:10 --> Utf8 Class Initialized
INFO - 2023-05-06 14:41:10 --> URI Class Initialized
INFO - 2023-05-06 14:41:10 --> Router Class Initialized
INFO - 2023-05-06 14:41:10 --> Output Class Initialized
INFO - 2023-05-06 14:41:10 --> Security Class Initialized
INFO - 2023-05-06 14:41:10 --> Input Class Initialized
INFO - 2023-05-06 14:41:10 --> Language Class Initialized
INFO - 2023-05-06 14:41:10 --> Loader Class Initialized
INFO - 2023-05-06 14:41:10 --> Helper loaded: url_helper
INFO - 2023-05-06 14:41:10 --> Helper loaded: form_helper
INFO - 2023-05-06 14:41:10 --> Database Driver Class Initialized
INFO - 2023-05-06 14:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:41:10 --> Form Validation Class Initialized
INFO - 2023-05-06 14:41:10 --> Controller Class Initialized
INFO - 2023-05-06 14:41:10 --> Model "m_user" initialized
INFO - 2023-05-06 14:41:10 --> Config Class Initialized
INFO - 2023-05-06 14:41:10 --> Hooks Class Initialized
INFO - 2023-05-06 14:41:10 --> Utf8 Class Initialized
INFO - 2023-05-06 14:41:10 --> URI Class Initialized
INFO - 2023-05-06 14:41:10 --> Router Class Initialized
INFO - 2023-05-06 14:41:10 --> Output Class Initialized
INFO - 2023-05-06 14:41:10 --> Security Class Initialized
INFO - 2023-05-06 14:41:10 --> Input Class Initialized
INFO - 2023-05-06 14:41:10 --> Language Class Initialized
INFO - 2023-05-06 14:41:10 --> Loader Class Initialized
INFO - 2023-05-06 14:41:10 --> Helper loaded: url_helper
INFO - 2023-05-06 14:41:10 --> Helper loaded: form_helper
INFO - 2023-05-06 14:41:10 --> Database Driver Class Initialized
INFO - 2023-05-06 14:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:41:10 --> Form Validation Class Initialized
INFO - 2023-05-06 14:41:10 --> Controller Class Initialized
INFO - 2023-05-06 14:41:10 --> Model "m_user" initialized
INFO - 2023-05-06 14:41:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 14:41:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 14:41:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 14:41:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 14:41:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 14:41:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 14:41:10 --> Final output sent to browser
INFO - 2023-05-06 14:41:19 --> Config Class Initialized
INFO - 2023-05-06 14:41:19 --> Hooks Class Initialized
INFO - 2023-05-06 14:41:19 --> Utf8 Class Initialized
INFO - 2023-05-06 14:41:19 --> URI Class Initialized
INFO - 2023-05-06 14:41:19 --> Router Class Initialized
INFO - 2023-05-06 14:41:19 --> Output Class Initialized
INFO - 2023-05-06 14:41:19 --> Security Class Initialized
INFO - 2023-05-06 14:41:19 --> Input Class Initialized
INFO - 2023-05-06 14:41:19 --> Language Class Initialized
ERROR - 2023-05-06 14:41:19 --> 404 Page Not Found: Group/index
INFO - 2023-05-06 14:41:21 --> Config Class Initialized
INFO - 2023-05-06 14:41:21 --> Hooks Class Initialized
INFO - 2023-05-06 14:41:21 --> Utf8 Class Initialized
INFO - 2023-05-06 14:41:21 --> URI Class Initialized
INFO - 2023-05-06 14:41:21 --> Router Class Initialized
INFO - 2023-05-06 14:41:21 --> Output Class Initialized
INFO - 2023-05-06 14:41:21 --> Security Class Initialized
INFO - 2023-05-06 14:41:21 --> Input Class Initialized
INFO - 2023-05-06 14:41:21 --> Language Class Initialized
INFO - 2023-05-06 14:41:21 --> Loader Class Initialized
INFO - 2023-05-06 14:41:21 --> Helper loaded: url_helper
INFO - 2023-05-06 14:41:21 --> Helper loaded: form_helper
INFO - 2023-05-06 14:41:21 --> Database Driver Class Initialized
INFO - 2023-05-06 14:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:41:21 --> Form Validation Class Initialized
INFO - 2023-05-06 14:41:21 --> Controller Class Initialized
INFO - 2023-05-06 14:41:21 --> Model "m_user" initialized
INFO - 2023-05-06 14:41:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 14:41:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 14:41:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 14:41:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 14:41:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 14:41:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home.php
INFO - 2023-05-06 14:41:21 --> Final output sent to browser
INFO - 2023-05-06 14:41:24 --> Config Class Initialized
INFO - 2023-05-06 14:41:24 --> Hooks Class Initialized
INFO - 2023-05-06 14:41:24 --> Utf8 Class Initialized
INFO - 2023-05-06 14:41:24 --> URI Class Initialized
INFO - 2023-05-06 14:41:24 --> Router Class Initialized
INFO - 2023-05-06 14:41:24 --> Output Class Initialized
INFO - 2023-05-06 14:41:24 --> Security Class Initialized
INFO - 2023-05-06 14:41:24 --> Input Class Initialized
INFO - 2023-05-06 14:41:24 --> Language Class Initialized
INFO - 2023-05-06 14:41:24 --> Loader Class Initialized
INFO - 2023-05-06 14:41:24 --> Helper loaded: url_helper
INFO - 2023-05-06 14:41:24 --> Helper loaded: form_helper
INFO - 2023-05-06 14:41:24 --> Database Driver Class Initialized
INFO - 2023-05-06 14:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:41:24 --> Form Validation Class Initialized
INFO - 2023-05-06 14:41:24 --> Controller Class Initialized
INFO - 2023-05-06 14:41:24 --> Model "m_user" initialized
INFO - 2023-05-06 14:41:24 --> Config Class Initialized
INFO - 2023-05-06 14:41:24 --> Hooks Class Initialized
INFO - 2023-05-06 14:41:24 --> Utf8 Class Initialized
INFO - 2023-05-06 14:41:24 --> URI Class Initialized
INFO - 2023-05-06 14:41:24 --> Router Class Initialized
INFO - 2023-05-06 14:41:24 --> Output Class Initialized
INFO - 2023-05-06 14:41:24 --> Security Class Initialized
INFO - 2023-05-06 14:41:24 --> Input Class Initialized
INFO - 2023-05-06 14:41:24 --> Language Class Initialized
INFO - 2023-05-06 14:41:24 --> Loader Class Initialized
INFO - 2023-05-06 14:41:24 --> Helper loaded: url_helper
INFO - 2023-05-06 14:41:24 --> Helper loaded: form_helper
INFO - 2023-05-06 14:41:24 --> Database Driver Class Initialized
INFO - 2023-05-06 14:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:41:24 --> Form Validation Class Initialized
INFO - 2023-05-06 14:41:24 --> Controller Class Initialized
INFO - 2023-05-06 14:41:24 --> Model "m_user" initialized
INFO - 2023-05-06 14:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 14:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 14:41:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 14:41:24 --> Final output sent to browser
INFO - 2023-05-06 14:45:33 --> Config Class Initialized
INFO - 2023-05-06 14:45:33 --> Hooks Class Initialized
INFO - 2023-05-06 14:45:33 --> Utf8 Class Initialized
INFO - 2023-05-06 14:45:33 --> URI Class Initialized
INFO - 2023-05-06 14:45:33 --> Router Class Initialized
INFO - 2023-05-06 14:45:33 --> Output Class Initialized
INFO - 2023-05-06 14:45:33 --> Security Class Initialized
INFO - 2023-05-06 14:45:33 --> Input Class Initialized
INFO - 2023-05-06 14:45:33 --> Language Class Initialized
INFO - 2023-05-06 14:45:33 --> Loader Class Initialized
INFO - 2023-05-06 14:45:33 --> Helper loaded: url_helper
INFO - 2023-05-06 14:45:33 --> Helper loaded: form_helper
INFO - 2023-05-06 14:45:33 --> Database Driver Class Initialized
INFO - 2023-05-06 14:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:45:33 --> Form Validation Class Initialized
INFO - 2023-05-06 14:45:33 --> Controller Class Initialized
INFO - 2023-05-06 14:45:33 --> Model "m_user" initialized
INFO - 2023-05-06 14:45:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 14:45:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 14:45:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 14:45:33 --> Final output sent to browser
INFO - 2023-05-06 14:50:48 --> Config Class Initialized
INFO - 2023-05-06 14:50:48 --> Hooks Class Initialized
INFO - 2023-05-06 14:50:48 --> Utf8 Class Initialized
INFO - 2023-05-06 14:50:48 --> URI Class Initialized
INFO - 2023-05-06 14:50:48 --> Router Class Initialized
INFO - 2023-05-06 14:50:48 --> Output Class Initialized
INFO - 2023-05-06 14:50:48 --> Security Class Initialized
INFO - 2023-05-06 14:50:48 --> Input Class Initialized
INFO - 2023-05-06 14:50:48 --> Language Class Initialized
INFO - 2023-05-06 14:50:48 --> Loader Class Initialized
INFO - 2023-05-06 14:50:48 --> Helper loaded: url_helper
INFO - 2023-05-06 14:50:48 --> Helper loaded: form_helper
INFO - 2023-05-06 14:50:48 --> Database Driver Class Initialized
INFO - 2023-05-06 14:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:50:48 --> Form Validation Class Initialized
INFO - 2023-05-06 14:50:48 --> Controller Class Initialized
INFO - 2023-05-06 14:50:48 --> Model "m_user" initialized
INFO - 2023-05-06 14:50:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 14:50:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 14:50:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 14:50:48 --> Final output sent to browser
INFO - 2023-05-06 14:55:07 --> Config Class Initialized
INFO - 2023-05-06 14:55:07 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:07 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:07 --> URI Class Initialized
INFO - 2023-05-06 14:55:07 --> Router Class Initialized
INFO - 2023-05-06 14:55:07 --> Output Class Initialized
INFO - 2023-05-06 14:55:07 --> Security Class Initialized
INFO - 2023-05-06 14:55:07 --> Input Class Initialized
INFO - 2023-05-06 14:55:07 --> Language Class Initialized
INFO - 2023-05-06 14:55:07 --> Loader Class Initialized
INFO - 2023-05-06 14:55:07 --> Helper loaded: url_helper
INFO - 2023-05-06 14:55:07 --> Helper loaded: form_helper
INFO - 2023-05-06 14:55:07 --> Database Driver Class Initialized
INFO - 2023-05-06 14:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:55:07 --> Form Validation Class Initialized
INFO - 2023-05-06 14:55:07 --> Controller Class Initialized
INFO - 2023-05-06 14:55:07 --> Model "m_user" initialized
INFO - 2023-05-06 14:55:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 14:55:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 14:55:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 14:55:07 --> Final output sent to browser
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
INFO - 2023-05-06 14:55:09 --> Loader Class Initialized
INFO - 2023-05-06 14:55:09 --> Helper loaded: url_helper
INFO - 2023-05-06 14:55:09 --> Helper loaded: form_helper
INFO - 2023-05-06 14:55:09 --> Database Driver Class Initialized
INFO - 2023-05-06 14:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:55:09 --> Form Validation Class Initialized
INFO - 2023-05-06 14:55:09 --> Controller Class Initialized
INFO - 2023-05-06 14:55:09 --> Model "m_user" initialized
INFO - 2023-05-06 14:55:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 14:55:09 --> Final output sent to browser
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Assets/font-awesome
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Assets/fontawesome-free
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Assets/jquery
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Assets/datatables
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Assets/bootstrap
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Css/sb-admin.css
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Assets/jquery-easing
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Assets/chart.js
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
INFO - 2023-05-06 14:55:09 --> Config Class Initialized
INFO - 2023-05-06 14:55:09 --> Hooks Class Initialized
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Assets/chart.js
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
INFO - 2023-05-06 14:55:09 --> URI Class Initialized
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Assets/datatables
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Router Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Js/sb-admin.min.js
INFO - 2023-05-06 14:55:09 --> Output Class Initialized
INFO - 2023-05-06 14:55:09 --> Security Class Initialized
INFO - 2023-05-06 14:55:09 --> Input Class Initialized
INFO - 2023-05-06 14:55:09 --> Language Class Initialized
ERROR - 2023-05-06 14:55:09 --> 404 Page Not Found: Js/demo
INFO - 2023-05-06 14:55:32 --> Config Class Initialized
INFO - 2023-05-06 14:55:32 --> Hooks Class Initialized
INFO - 2023-05-06 14:55:32 --> Utf8 Class Initialized
INFO - 2023-05-06 14:55:32 --> URI Class Initialized
INFO - 2023-05-06 14:55:32 --> Router Class Initialized
INFO - 2023-05-06 14:55:32 --> Output Class Initialized
INFO - 2023-05-06 14:55:32 --> Security Class Initialized
INFO - 2023-05-06 14:55:32 --> Input Class Initialized
INFO - 2023-05-06 14:55:32 --> Language Class Initialized
INFO - 2023-05-06 14:55:32 --> Loader Class Initialized
INFO - 2023-05-06 14:55:32 --> Helper loaded: url_helper
INFO - 2023-05-06 14:55:32 --> Helper loaded: form_helper
INFO - 2023-05-06 14:55:32 --> Database Driver Class Initialized
INFO - 2023-05-06 14:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:55:32 --> Form Validation Class Initialized
INFO - 2023-05-06 14:55:32 --> Controller Class Initialized
INFO - 2023-05-06 14:55:32 --> Model "m_user" initialized
INFO - 2023-05-06 14:55:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 14:55:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 14:55:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 14:55:32 --> Final output sent to browser
INFO - 2023-05-06 14:59:10 --> Config Class Initialized
INFO - 2023-05-06 14:59:10 --> Hooks Class Initialized
INFO - 2023-05-06 14:59:10 --> Utf8 Class Initialized
INFO - 2023-05-06 14:59:10 --> URI Class Initialized
INFO - 2023-05-06 14:59:10 --> Router Class Initialized
INFO - 2023-05-06 14:59:10 --> Output Class Initialized
INFO - 2023-05-06 14:59:10 --> Security Class Initialized
INFO - 2023-05-06 14:59:10 --> Input Class Initialized
INFO - 2023-05-06 14:59:10 --> Language Class Initialized
INFO - 2023-05-06 14:59:10 --> Loader Class Initialized
INFO - 2023-05-06 14:59:10 --> Helper loaded: url_helper
INFO - 2023-05-06 14:59:10 --> Helper loaded: form_helper
INFO - 2023-05-06 14:59:10 --> Database Driver Class Initialized
INFO - 2023-05-06 14:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:59:10 --> Form Validation Class Initialized
INFO - 2023-05-06 14:59:10 --> Controller Class Initialized
INFO - 2023-05-06 14:59:10 --> Model "m_user" initialized
INFO - 2023-05-06 14:59:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 14:59:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 14:59:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 14:59:10 --> Final output sent to browser
INFO - 2023-05-06 14:59:12 --> Config Class Initialized
INFO - 2023-05-06 14:59:12 --> Hooks Class Initialized
INFO - 2023-05-06 14:59:12 --> Utf8 Class Initialized
INFO - 2023-05-06 14:59:12 --> URI Class Initialized
INFO - 2023-05-06 14:59:12 --> Router Class Initialized
INFO - 2023-05-06 14:59:12 --> Output Class Initialized
INFO - 2023-05-06 14:59:12 --> Security Class Initialized
INFO - 2023-05-06 14:59:12 --> Input Class Initialized
INFO - 2023-05-06 14:59:12 --> Language Class Initialized
ERROR - 2023-05-06 14:59:12 --> 404 Page Not Found: C_login/register
INFO - 2023-05-06 14:59:15 --> Config Class Initialized
INFO - 2023-05-06 14:59:15 --> Hooks Class Initialized
INFO - 2023-05-06 14:59:15 --> Utf8 Class Initialized
INFO - 2023-05-06 14:59:15 --> URI Class Initialized
INFO - 2023-05-06 14:59:15 --> Router Class Initialized
INFO - 2023-05-06 14:59:15 --> Output Class Initialized
INFO - 2023-05-06 14:59:15 --> Security Class Initialized
INFO - 2023-05-06 14:59:15 --> Input Class Initialized
INFO - 2023-05-06 14:59:15 --> Language Class Initialized
INFO - 2023-05-06 14:59:15 --> Loader Class Initialized
INFO - 2023-05-06 14:59:15 --> Helper loaded: url_helper
INFO - 2023-05-06 14:59:15 --> Helper loaded: form_helper
INFO - 2023-05-06 14:59:15 --> Database Driver Class Initialized
INFO - 2023-05-06 14:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:59:15 --> Form Validation Class Initialized
INFO - 2023-05-06 14:59:15 --> Controller Class Initialized
INFO - 2023-05-06 14:59:15 --> Model "m_user" initialized
INFO - 2023-05-06 14:59:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 14:59:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 14:59:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 14:59:15 --> Final output sent to browser
INFO - 2023-05-06 14:59:52 --> Config Class Initialized
INFO - 2023-05-06 14:59:52 --> Hooks Class Initialized
INFO - 2023-05-06 14:59:52 --> Utf8 Class Initialized
INFO - 2023-05-06 14:59:52 --> URI Class Initialized
INFO - 2023-05-06 14:59:52 --> Router Class Initialized
INFO - 2023-05-06 14:59:52 --> Output Class Initialized
INFO - 2023-05-06 14:59:52 --> Security Class Initialized
INFO - 2023-05-06 14:59:52 --> Input Class Initialized
INFO - 2023-05-06 14:59:52 --> Language Class Initialized
INFO - 2023-05-06 14:59:52 --> Loader Class Initialized
INFO - 2023-05-06 14:59:52 --> Helper loaded: url_helper
INFO - 2023-05-06 14:59:52 --> Helper loaded: form_helper
INFO - 2023-05-06 14:59:52 --> Database Driver Class Initialized
INFO - 2023-05-06 14:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:59:52 --> Form Validation Class Initialized
INFO - 2023-05-06 14:59:52 --> Controller Class Initialized
INFO - 2023-05-06 14:59:52 --> Model "m_user" initialized
INFO - 2023-05-06 14:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 14:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 14:59:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 14:59:52 --> Final output sent to browser
INFO - 2023-05-06 14:59:54 --> Config Class Initialized
INFO - 2023-05-06 14:59:54 --> Hooks Class Initialized
INFO - 2023-05-06 14:59:54 --> Utf8 Class Initialized
INFO - 2023-05-06 14:59:54 --> URI Class Initialized
INFO - 2023-05-06 14:59:54 --> Router Class Initialized
INFO - 2023-05-06 14:59:54 --> Output Class Initialized
INFO - 2023-05-06 14:59:54 --> Security Class Initialized
INFO - 2023-05-06 14:59:54 --> Input Class Initialized
INFO - 2023-05-06 14:59:54 --> Language Class Initialized
INFO - 2023-05-06 14:59:54 --> Loader Class Initialized
INFO - 2023-05-06 14:59:54 --> Helper loaded: url_helper
INFO - 2023-05-06 14:59:54 --> Helper loaded: form_helper
INFO - 2023-05-06 14:59:54 --> Database Driver Class Initialized
INFO - 2023-05-06 14:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:59:54 --> Form Validation Class Initialized
INFO - 2023-05-06 14:59:54 --> Controller Class Initialized
INFO - 2023-05-06 14:59:54 --> Model "m_user" initialized
INFO - 2023-05-06 14:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 14:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 14:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 14:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 14:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 14:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 14:59:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 14:59:54 --> Final output sent to browser
INFO - 2023-05-06 14:59:57 --> Config Class Initialized
INFO - 2023-05-06 14:59:57 --> Hooks Class Initialized
INFO - 2023-05-06 14:59:57 --> Utf8 Class Initialized
INFO - 2023-05-06 14:59:57 --> URI Class Initialized
INFO - 2023-05-06 14:59:57 --> Router Class Initialized
INFO - 2023-05-06 14:59:57 --> Output Class Initialized
INFO - 2023-05-06 14:59:57 --> Security Class Initialized
INFO - 2023-05-06 14:59:57 --> Input Class Initialized
INFO - 2023-05-06 14:59:57 --> Language Class Initialized
ERROR - 2023-05-06 14:59:57 --> 404 Page Not Found: C_admin/index
INFO - 2023-05-06 14:59:59 --> Config Class Initialized
INFO - 2023-05-06 14:59:59 --> Hooks Class Initialized
INFO - 2023-05-06 14:59:59 --> Utf8 Class Initialized
INFO - 2023-05-06 14:59:59 --> URI Class Initialized
INFO - 2023-05-06 14:59:59 --> Router Class Initialized
INFO - 2023-05-06 14:59:59 --> Output Class Initialized
INFO - 2023-05-06 14:59:59 --> Security Class Initialized
INFO - 2023-05-06 14:59:59 --> Input Class Initialized
INFO - 2023-05-06 14:59:59 --> Language Class Initialized
INFO - 2023-05-06 14:59:59 --> Loader Class Initialized
INFO - 2023-05-06 14:59:59 --> Helper loaded: url_helper
INFO - 2023-05-06 14:59:59 --> Helper loaded: form_helper
INFO - 2023-05-06 14:59:59 --> Database Driver Class Initialized
INFO - 2023-05-06 14:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 14:59:59 --> Form Validation Class Initialized
INFO - 2023-05-06 14:59:59 --> Controller Class Initialized
INFO - 2023-05-06 14:59:59 --> Model "m_user" initialized
INFO - 2023-05-06 14:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 14:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 14:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 14:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 14:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 14:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 14:59:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 14:59:59 --> Final output sent to browser
INFO - 2023-05-06 15:03:03 --> Config Class Initialized
INFO - 2023-05-06 15:03:03 --> Hooks Class Initialized
INFO - 2023-05-06 15:03:03 --> Utf8 Class Initialized
INFO - 2023-05-06 15:03:03 --> URI Class Initialized
INFO - 2023-05-06 15:03:03 --> Router Class Initialized
INFO - 2023-05-06 15:03:03 --> Output Class Initialized
INFO - 2023-05-06 15:03:03 --> Security Class Initialized
INFO - 2023-05-06 15:03:03 --> Input Class Initialized
INFO - 2023-05-06 15:03:03 --> Language Class Initialized
ERROR - 2023-05-06 15:03:03 --> 404 Page Not Found: C_admin/tambah
INFO - 2023-05-06 15:03:05 --> Config Class Initialized
INFO - 2023-05-06 15:03:05 --> Hooks Class Initialized
INFO - 2023-05-06 15:03:05 --> Utf8 Class Initialized
INFO - 2023-05-06 15:03:05 --> URI Class Initialized
INFO - 2023-05-06 15:03:05 --> Router Class Initialized
INFO - 2023-05-06 15:03:05 --> Output Class Initialized
INFO - 2023-05-06 15:03:05 --> Security Class Initialized
INFO - 2023-05-06 15:03:05 --> Input Class Initialized
INFO - 2023-05-06 15:03:05 --> Language Class Initialized
INFO - 2023-05-06 15:03:05 --> Loader Class Initialized
INFO - 2023-05-06 15:03:05 --> Helper loaded: url_helper
INFO - 2023-05-06 15:03:05 --> Helper loaded: form_helper
INFO - 2023-05-06 15:03:05 --> Database Driver Class Initialized
INFO - 2023-05-06 15:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:03:05 --> Form Validation Class Initialized
INFO - 2023-05-06 15:03:05 --> Controller Class Initialized
INFO - 2023-05-06 15:03:05 --> Model "m_user" initialized
INFO - 2023-05-06 15:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 15:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 15:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 15:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 15:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 15:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 15:03:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 15:03:05 --> Final output sent to browser
INFO - 2023-05-06 15:04:31 --> Config Class Initialized
INFO - 2023-05-06 15:04:31 --> Hooks Class Initialized
INFO - 2023-05-06 15:04:31 --> Utf8 Class Initialized
INFO - 2023-05-06 15:04:31 --> URI Class Initialized
INFO - 2023-05-06 15:04:31 --> Router Class Initialized
INFO - 2023-05-06 15:04:31 --> Output Class Initialized
INFO - 2023-05-06 15:04:31 --> Security Class Initialized
INFO - 2023-05-06 15:04:31 --> Input Class Initialized
INFO - 2023-05-06 15:04:31 --> Language Class Initialized
INFO - 2023-05-06 15:04:31 --> Loader Class Initialized
INFO - 2023-05-06 15:04:31 --> Helper loaded: url_helper
INFO - 2023-05-06 15:04:31 --> Helper loaded: form_helper
INFO - 2023-05-06 15:04:31 --> Database Driver Class Initialized
INFO - 2023-05-06 15:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:04:31 --> Form Validation Class Initialized
INFO - 2023-05-06 15:04:31 --> Controller Class Initialized
INFO - 2023-05-06 15:04:31 --> Model "m_user" initialized
INFO - 2023-05-06 15:04:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 15:04:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 15:04:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 15:04:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 15:04:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 15:04:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 15:04:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 15:04:31 --> Final output sent to browser
INFO - 2023-05-06 15:04:34 --> Config Class Initialized
INFO - 2023-05-06 15:04:34 --> Hooks Class Initialized
INFO - 2023-05-06 15:04:34 --> Utf8 Class Initialized
INFO - 2023-05-06 15:04:34 --> URI Class Initialized
INFO - 2023-05-06 15:04:34 --> Router Class Initialized
INFO - 2023-05-06 15:04:34 --> Output Class Initialized
INFO - 2023-05-06 15:04:34 --> Security Class Initialized
INFO - 2023-05-06 15:04:34 --> Input Class Initialized
INFO - 2023-05-06 15:04:34 --> Language Class Initialized
INFO - 2023-05-06 15:04:34 --> Loader Class Initialized
INFO - 2023-05-06 15:04:34 --> Helper loaded: url_helper
INFO - 2023-05-06 15:04:34 --> Helper loaded: form_helper
INFO - 2023-05-06 15:04:34 --> Database Driver Class Initialized
INFO - 2023-05-06 15:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:04:34 --> Form Validation Class Initialized
INFO - 2023-05-06 15:04:34 --> Controller Class Initialized
INFO - 2023-05-06 15:04:34 --> Model "m_user" initialized
INFO - 2023-05-06 15:04:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 15:04:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 15:04:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 15:04:34 --> Final output sent to browser
INFO - 2023-05-06 15:04:37 --> Config Class Initialized
INFO - 2023-05-06 15:04:37 --> Hooks Class Initialized
INFO - 2023-05-06 15:04:37 --> Utf8 Class Initialized
INFO - 2023-05-06 15:04:37 --> URI Class Initialized
INFO - 2023-05-06 15:04:37 --> Router Class Initialized
INFO - 2023-05-06 15:04:37 --> Output Class Initialized
INFO - 2023-05-06 15:04:37 --> Security Class Initialized
INFO - 2023-05-06 15:04:37 --> Input Class Initialized
INFO - 2023-05-06 15:04:37 --> Language Class Initialized
INFO - 2023-05-06 15:04:37 --> Loader Class Initialized
INFO - 2023-05-06 15:04:37 --> Helper loaded: url_helper
INFO - 2023-05-06 15:04:37 --> Helper loaded: form_helper
INFO - 2023-05-06 15:04:37 --> Database Driver Class Initialized
INFO - 2023-05-06 15:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:04:37 --> Form Validation Class Initialized
INFO - 2023-05-06 15:04:37 --> Controller Class Initialized
INFO - 2023-05-06 15:04:37 --> Model "m_user" initialized
INFO - 2023-05-06 15:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 15:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 15:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 15:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 15:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 15:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 15:04:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 15:04:37 --> Final output sent to browser
INFO - 2023-05-06 15:07:13 --> Config Class Initialized
INFO - 2023-05-06 15:07:13 --> Hooks Class Initialized
INFO - 2023-05-06 15:07:13 --> Utf8 Class Initialized
INFO - 2023-05-06 15:07:13 --> URI Class Initialized
INFO - 2023-05-06 15:07:13 --> Router Class Initialized
INFO - 2023-05-06 15:07:13 --> Output Class Initialized
INFO - 2023-05-06 15:07:13 --> Security Class Initialized
INFO - 2023-05-06 15:07:13 --> Input Class Initialized
INFO - 2023-05-06 15:07:13 --> Language Class Initialized
INFO - 2023-05-06 15:07:13 --> Loader Class Initialized
INFO - 2023-05-06 15:07:13 --> Helper loaded: url_helper
INFO - 2023-05-06 15:07:13 --> Helper loaded: form_helper
INFO - 2023-05-06 15:07:13 --> Database Driver Class Initialized
INFO - 2023-05-06 15:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:07:13 --> Form Validation Class Initialized
INFO - 2023-05-06 15:07:13 --> Controller Class Initialized
INFO - 2023-05-06 15:07:13 --> Model "m_user" initialized
INFO - 2023-05-06 15:07:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 15:07:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 15:07:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 15:07:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 15:07:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 15:07:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 15:07:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 15:07:13 --> Final output sent to browser
INFO - 2023-05-06 15:07:15 --> Config Class Initialized
INFO - 2023-05-06 15:07:15 --> Hooks Class Initialized
INFO - 2023-05-06 15:07:15 --> Utf8 Class Initialized
INFO - 2023-05-06 15:07:15 --> URI Class Initialized
INFO - 2023-05-06 15:07:15 --> Router Class Initialized
INFO - 2023-05-06 15:07:15 --> Output Class Initialized
INFO - 2023-05-06 15:07:15 --> Security Class Initialized
INFO - 2023-05-06 15:07:15 --> Input Class Initialized
INFO - 2023-05-06 15:07:15 --> Language Class Initialized
INFO - 2023-05-06 15:07:15 --> Loader Class Initialized
INFO - 2023-05-06 15:07:15 --> Helper loaded: url_helper
INFO - 2023-05-06 15:07:15 --> Helper loaded: form_helper
INFO - 2023-05-06 15:07:15 --> Database Driver Class Initialized
INFO - 2023-05-06 15:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:07:15 --> Form Validation Class Initialized
INFO - 2023-05-06 15:07:15 --> Controller Class Initialized
INFO - 2023-05-06 15:07:15 --> Model "m_user" initialized
INFO - 2023-05-06 15:07:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 15:07:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 15:07:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 15:07:15 --> Final output sent to browser
INFO - 2023-05-06 15:07:17 --> Config Class Initialized
INFO - 2023-05-06 15:07:17 --> Hooks Class Initialized
INFO - 2023-05-06 15:07:17 --> Utf8 Class Initialized
INFO - 2023-05-06 15:07:17 --> URI Class Initialized
INFO - 2023-05-06 15:07:17 --> Router Class Initialized
INFO - 2023-05-06 15:07:17 --> Output Class Initialized
INFO - 2023-05-06 15:07:17 --> Security Class Initialized
INFO - 2023-05-06 15:07:17 --> Input Class Initialized
INFO - 2023-05-06 15:07:17 --> Language Class Initialized
INFO - 2023-05-06 15:07:17 --> Loader Class Initialized
INFO - 2023-05-06 15:07:17 --> Helper loaded: url_helper
INFO - 2023-05-06 15:07:17 --> Helper loaded: form_helper
INFO - 2023-05-06 15:07:17 --> Database Driver Class Initialized
INFO - 2023-05-06 15:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:07:17 --> Form Validation Class Initialized
INFO - 2023-05-06 15:07:17 --> Controller Class Initialized
INFO - 2023-05-06 15:07:17 --> Model "m_user" initialized
INFO - 2023-05-06 15:07:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 15:07:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 15:07:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 15:07:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 15:07:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 15:07:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 15:07:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 15:07:17 --> Final output sent to browser
INFO - 2023-05-06 15:07:26 --> Config Class Initialized
INFO - 2023-05-06 15:07:26 --> Hooks Class Initialized
INFO - 2023-05-06 15:07:26 --> Utf8 Class Initialized
INFO - 2023-05-06 15:07:26 --> URI Class Initialized
INFO - 2023-05-06 15:07:26 --> Router Class Initialized
INFO - 2023-05-06 15:07:26 --> Output Class Initialized
INFO - 2023-05-06 15:07:26 --> Security Class Initialized
INFO - 2023-05-06 15:07:26 --> Input Class Initialized
INFO - 2023-05-06 15:07:26 --> Language Class Initialized
INFO - 2023-05-06 15:07:26 --> Loader Class Initialized
INFO - 2023-05-06 15:07:26 --> Helper loaded: url_helper
INFO - 2023-05-06 15:07:26 --> Helper loaded: form_helper
INFO - 2023-05-06 15:07:26 --> Database Driver Class Initialized
INFO - 2023-05-06 15:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:07:26 --> Form Validation Class Initialized
INFO - 2023-05-06 15:07:26 --> Controller Class Initialized
INFO - 2023-05-06 15:07:26 --> Model "m_user" initialized
ERROR - 2023-05-06 15:07:26 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_login.php 49
INFO - 2023-05-06 15:07:26 --> Config Class Initialized
INFO - 2023-05-06 15:07:26 --> Hooks Class Initialized
INFO - 2023-05-06 15:07:26 --> Utf8 Class Initialized
INFO - 2023-05-06 15:07:26 --> URI Class Initialized
INFO - 2023-05-06 15:07:26 --> Router Class Initialized
INFO - 2023-05-06 15:07:26 --> Output Class Initialized
INFO - 2023-05-06 15:07:26 --> Security Class Initialized
INFO - 2023-05-06 15:07:26 --> Input Class Initialized
INFO - 2023-05-06 15:07:26 --> Language Class Initialized
INFO - 2023-05-06 15:07:26 --> Loader Class Initialized
INFO - 2023-05-06 15:07:26 --> Helper loaded: url_helper
INFO - 2023-05-06 15:07:26 --> Helper loaded: form_helper
INFO - 2023-05-06 15:07:26 --> Database Driver Class Initialized
INFO - 2023-05-06 15:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:07:26 --> Form Validation Class Initialized
INFO - 2023-05-06 15:07:26 --> Controller Class Initialized
INFO - 2023-05-06 15:07:26 --> Model "m_user" initialized
INFO - 2023-05-06 15:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 15:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 15:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 15:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 15:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 15:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 15:07:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 15:07:26 --> Final output sent to browser
INFO - 2023-05-06 15:08:40 --> Config Class Initialized
INFO - 2023-05-06 15:08:40 --> Hooks Class Initialized
INFO - 2023-05-06 15:08:40 --> Utf8 Class Initialized
INFO - 2023-05-06 15:08:40 --> URI Class Initialized
INFO - 2023-05-06 15:08:40 --> Router Class Initialized
INFO - 2023-05-06 15:08:40 --> Output Class Initialized
INFO - 2023-05-06 15:08:40 --> Security Class Initialized
INFO - 2023-05-06 15:08:40 --> Input Class Initialized
INFO - 2023-05-06 15:08:40 --> Language Class Initialized
INFO - 2023-05-06 15:08:40 --> Loader Class Initialized
INFO - 2023-05-06 15:08:40 --> Helper loaded: url_helper
INFO - 2023-05-06 15:08:40 --> Helper loaded: form_helper
INFO - 2023-05-06 15:08:41 --> Database Driver Class Initialized
INFO - 2023-05-06 15:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:08:41 --> Form Validation Class Initialized
INFO - 2023-05-06 15:08:41 --> Controller Class Initialized
INFO - 2023-05-06 15:08:41 --> Model "m_user" initialized
INFO - 2023-05-06 15:08:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 15:08:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 15:08:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 15:08:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 15:08:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 15:08:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 15:08:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 15:08:41 --> Final output sent to browser
INFO - 2023-05-06 15:08:47 --> Config Class Initialized
INFO - 2023-05-06 15:08:47 --> Hooks Class Initialized
INFO - 2023-05-06 15:08:47 --> Utf8 Class Initialized
INFO - 2023-05-06 15:08:47 --> URI Class Initialized
INFO - 2023-05-06 15:08:47 --> Router Class Initialized
INFO - 2023-05-06 15:08:47 --> Output Class Initialized
INFO - 2023-05-06 15:08:47 --> Security Class Initialized
INFO - 2023-05-06 15:08:47 --> Input Class Initialized
INFO - 2023-05-06 15:08:47 --> Language Class Initialized
INFO - 2023-05-06 15:08:47 --> Loader Class Initialized
INFO - 2023-05-06 15:08:47 --> Helper loaded: url_helper
INFO - 2023-05-06 15:08:47 --> Helper loaded: form_helper
INFO - 2023-05-06 15:08:47 --> Database Driver Class Initialized
INFO - 2023-05-06 15:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:08:47 --> Form Validation Class Initialized
INFO - 2023-05-06 15:08:47 --> Controller Class Initialized
INFO - 2023-05-06 15:08:47 --> Model "m_user" initialized
ERROR - 2023-05-06 15:08:47 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_login.php 49
INFO - 2023-05-06 15:08:47 --> Config Class Initialized
INFO - 2023-05-06 15:08:47 --> Hooks Class Initialized
INFO - 2023-05-06 15:08:47 --> Utf8 Class Initialized
INFO - 2023-05-06 15:08:47 --> URI Class Initialized
INFO - 2023-05-06 15:08:47 --> Router Class Initialized
INFO - 2023-05-06 15:08:47 --> Output Class Initialized
INFO - 2023-05-06 15:08:47 --> Security Class Initialized
INFO - 2023-05-06 15:08:47 --> Input Class Initialized
INFO - 2023-05-06 15:08:47 --> Language Class Initialized
INFO - 2023-05-06 15:08:47 --> Loader Class Initialized
INFO - 2023-05-06 15:08:47 --> Helper loaded: url_helper
INFO - 2023-05-06 15:08:47 --> Helper loaded: form_helper
INFO - 2023-05-06 15:08:47 --> Database Driver Class Initialized
INFO - 2023-05-06 15:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:08:47 --> Form Validation Class Initialized
INFO - 2023-05-06 15:08:47 --> Controller Class Initialized
INFO - 2023-05-06 15:08:47 --> Model "m_user" initialized
INFO - 2023-05-06 15:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 15:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 15:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 15:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 15:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 15:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 15:08:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 15:08:47 --> Final output sent to browser
INFO - 2023-05-06 15:13:51 --> Config Class Initialized
INFO - 2023-05-06 15:13:51 --> Hooks Class Initialized
INFO - 2023-05-06 15:13:51 --> Utf8 Class Initialized
INFO - 2023-05-06 15:13:51 --> URI Class Initialized
INFO - 2023-05-06 15:13:51 --> Router Class Initialized
INFO - 2023-05-06 15:13:51 --> Output Class Initialized
INFO - 2023-05-06 15:13:51 --> Security Class Initialized
INFO - 2023-05-06 15:13:51 --> Input Class Initialized
INFO - 2023-05-06 15:13:51 --> Language Class Initialized
INFO - 2023-05-06 15:13:51 --> Loader Class Initialized
INFO - 2023-05-06 15:13:51 --> Helper loaded: url_helper
INFO - 2023-05-06 15:13:51 --> Helper loaded: form_helper
INFO - 2023-05-06 15:13:51 --> Database Driver Class Initialized
INFO - 2023-05-06 15:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:13:51 --> Form Validation Class Initialized
INFO - 2023-05-06 15:13:51 --> Controller Class Initialized
INFO - 2023-05-06 15:13:51 --> Model "m_user" initialized
INFO - 2023-05-06 15:13:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 15:13:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 15:13:51 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 15:13:51 --> Final output sent to browser
INFO - 2023-05-06 15:13:56 --> Config Class Initialized
INFO - 2023-05-06 15:13:56 --> Hooks Class Initialized
INFO - 2023-05-06 15:13:56 --> Utf8 Class Initialized
INFO - 2023-05-06 15:13:56 --> URI Class Initialized
INFO - 2023-05-06 15:13:56 --> Router Class Initialized
INFO - 2023-05-06 15:13:56 --> Output Class Initialized
INFO - 2023-05-06 15:13:56 --> Security Class Initialized
INFO - 2023-05-06 15:13:56 --> Input Class Initialized
INFO - 2023-05-06 15:13:56 --> Language Class Initialized
INFO - 2023-05-06 15:13:56 --> Loader Class Initialized
INFO - 2023-05-06 15:13:56 --> Helper loaded: url_helper
INFO - 2023-05-06 15:13:56 --> Helper loaded: form_helper
INFO - 2023-05-06 15:13:56 --> Database Driver Class Initialized
INFO - 2023-05-06 15:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:13:56 --> Form Validation Class Initialized
INFO - 2023-05-06 15:13:56 --> Controller Class Initialized
INFO - 2023-05-06 15:13:56 --> Model "m_user" initialized
INFO - 2023-05-06 15:13:56 --> Config Class Initialized
INFO - 2023-05-06 15:13:56 --> Hooks Class Initialized
INFO - 2023-05-06 15:13:56 --> Utf8 Class Initialized
INFO - 2023-05-06 15:13:56 --> URI Class Initialized
INFO - 2023-05-06 15:13:56 --> Router Class Initialized
INFO - 2023-05-06 15:13:56 --> Output Class Initialized
INFO - 2023-05-06 15:13:56 --> Security Class Initialized
INFO - 2023-05-06 15:13:56 --> Input Class Initialized
INFO - 2023-05-06 15:13:56 --> Language Class Initialized
INFO - 2023-05-06 15:13:56 --> Loader Class Initialized
INFO - 2023-05-06 15:13:56 --> Helper loaded: url_helper
INFO - 2023-05-06 15:13:56 --> Helper loaded: form_helper
INFO - 2023-05-06 15:13:56 --> Database Driver Class Initialized
INFO - 2023-05-06 15:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:13:56 --> Form Validation Class Initialized
INFO - 2023-05-06 15:13:56 --> Controller Class Initialized
INFO - 2023-05-06 15:13:56 --> Model "m_user" initialized
INFO - 2023-05-06 15:13:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 15:13:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 15:13:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 15:13:56 --> Final output sent to browser
INFO - 2023-05-06 15:13:58 --> Config Class Initialized
INFO - 2023-05-06 15:13:58 --> Hooks Class Initialized
INFO - 2023-05-06 15:13:58 --> Utf8 Class Initialized
INFO - 2023-05-06 15:13:58 --> URI Class Initialized
INFO - 2023-05-06 15:13:58 --> Router Class Initialized
INFO - 2023-05-06 15:13:58 --> Output Class Initialized
INFO - 2023-05-06 15:13:58 --> Security Class Initialized
INFO - 2023-05-06 15:13:58 --> Input Class Initialized
INFO - 2023-05-06 15:13:58 --> Language Class Initialized
INFO - 2023-05-06 15:13:58 --> Loader Class Initialized
INFO - 2023-05-06 15:13:58 --> Helper loaded: url_helper
INFO - 2023-05-06 15:13:58 --> Helper loaded: form_helper
INFO - 2023-05-06 15:13:58 --> Database Driver Class Initialized
INFO - 2023-05-06 15:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:13:58 --> Form Validation Class Initialized
INFO - 2023-05-06 15:13:58 --> Controller Class Initialized
INFO - 2023-05-06 15:13:58 --> Model "m_user" initialized
INFO - 2023-05-06 15:13:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 15:13:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 15:13:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 15:13:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 15:13:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 15:13:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 15:13:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 15:13:58 --> Final output sent to browser
INFO - 2023-05-06 15:14:11 --> Config Class Initialized
INFO - 2023-05-06 15:14:11 --> Hooks Class Initialized
INFO - 2023-05-06 15:14:11 --> Utf8 Class Initialized
INFO - 2023-05-06 15:14:11 --> URI Class Initialized
INFO - 2023-05-06 15:14:11 --> Router Class Initialized
INFO - 2023-05-06 15:14:11 --> Output Class Initialized
INFO - 2023-05-06 15:14:11 --> Security Class Initialized
INFO - 2023-05-06 15:14:11 --> Input Class Initialized
INFO - 2023-05-06 15:14:11 --> Language Class Initialized
INFO - 2023-05-06 15:14:11 --> Loader Class Initialized
INFO - 2023-05-06 15:14:11 --> Helper loaded: url_helper
INFO - 2023-05-06 15:14:11 --> Helper loaded: form_helper
INFO - 2023-05-06 15:14:11 --> Database Driver Class Initialized
INFO - 2023-05-06 15:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:14:11 --> Form Validation Class Initialized
INFO - 2023-05-06 15:14:11 --> Controller Class Initialized
INFO - 2023-05-06 15:14:11 --> Model "m_user" initialized
ERROR - 2023-05-06 15:14:11 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_login.php 49
INFO - 2023-05-06 15:14:11 --> Config Class Initialized
INFO - 2023-05-06 15:14:11 --> Hooks Class Initialized
INFO - 2023-05-06 15:14:11 --> Utf8 Class Initialized
INFO - 2023-05-06 15:14:11 --> URI Class Initialized
INFO - 2023-05-06 15:14:11 --> Router Class Initialized
INFO - 2023-05-06 15:14:11 --> Output Class Initialized
INFO - 2023-05-06 15:14:11 --> Security Class Initialized
INFO - 2023-05-06 15:14:11 --> Input Class Initialized
INFO - 2023-05-06 15:14:11 --> Language Class Initialized
INFO - 2023-05-06 15:14:11 --> Loader Class Initialized
INFO - 2023-05-06 15:14:11 --> Helper loaded: url_helper
INFO - 2023-05-06 15:14:11 --> Helper loaded: form_helper
INFO - 2023-05-06 15:14:11 --> Database Driver Class Initialized
INFO - 2023-05-06 15:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:14:11 --> Form Validation Class Initialized
INFO - 2023-05-06 15:14:11 --> Controller Class Initialized
INFO - 2023-05-06 15:14:11 --> Model "m_user" initialized
INFO - 2023-05-06 15:14:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-06 15:14:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-06 15:14:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/register.php
INFO - 2023-05-06 15:14:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-06 15:14:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-06 15:14:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-06 15:14:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-06 15:14:11 --> Final output sent to browser
INFO - 2023-05-06 15:14:15 --> Config Class Initialized
INFO - 2023-05-06 15:14:15 --> Hooks Class Initialized
INFO - 2023-05-06 15:14:15 --> Utf8 Class Initialized
INFO - 2023-05-06 15:14:15 --> URI Class Initialized
INFO - 2023-05-06 15:14:15 --> Router Class Initialized
INFO - 2023-05-06 15:14:15 --> Output Class Initialized
INFO - 2023-05-06 15:14:15 --> Security Class Initialized
INFO - 2023-05-06 15:14:15 --> Input Class Initialized
INFO - 2023-05-06 15:14:15 --> Language Class Initialized
INFO - 2023-05-06 15:14:15 --> Loader Class Initialized
INFO - 2023-05-06 15:14:15 --> Helper loaded: url_helper
INFO - 2023-05-06 15:14:15 --> Helper loaded: form_helper
INFO - 2023-05-06 15:14:15 --> Database Driver Class Initialized
INFO - 2023-05-06 15:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:14:15 --> Form Validation Class Initialized
INFO - 2023-05-06 15:14:15 --> Controller Class Initialized
INFO - 2023-05-06 15:14:15 --> Model "m_user" initialized
INFO - 2023-05-06 15:14:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 15:14:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 15:14:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 15:14:15 --> Final output sent to browser
INFO - 2023-05-06 15:14:19 --> Config Class Initialized
INFO - 2023-05-06 15:14:19 --> Hooks Class Initialized
INFO - 2023-05-06 15:14:19 --> Utf8 Class Initialized
INFO - 2023-05-06 15:14:19 --> URI Class Initialized
INFO - 2023-05-06 15:14:19 --> Router Class Initialized
INFO - 2023-05-06 15:14:19 --> Output Class Initialized
INFO - 2023-05-06 15:14:19 --> Security Class Initialized
INFO - 2023-05-06 15:14:20 --> Input Class Initialized
INFO - 2023-05-06 15:14:20 --> Language Class Initialized
INFO - 2023-05-06 15:14:20 --> Loader Class Initialized
INFO - 2023-05-06 15:14:20 --> Helper loaded: url_helper
INFO - 2023-05-06 15:14:20 --> Helper loaded: form_helper
INFO - 2023-05-06 15:14:20 --> Database Driver Class Initialized
INFO - 2023-05-06 15:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:14:20 --> Form Validation Class Initialized
INFO - 2023-05-06 15:14:20 --> Controller Class Initialized
INFO - 2023-05-06 15:14:20 --> Model "m_user" initialized
INFO - 2023-05-06 15:14:20 --> Config Class Initialized
INFO - 2023-05-06 15:14:20 --> Hooks Class Initialized
INFO - 2023-05-06 15:14:20 --> Utf8 Class Initialized
INFO - 2023-05-06 15:14:20 --> URI Class Initialized
INFO - 2023-05-06 15:14:20 --> Router Class Initialized
INFO - 2023-05-06 15:14:20 --> Output Class Initialized
INFO - 2023-05-06 15:14:20 --> Security Class Initialized
INFO - 2023-05-06 15:14:20 --> Input Class Initialized
INFO - 2023-05-06 15:14:20 --> Language Class Initialized
INFO - 2023-05-06 15:14:20 --> Loader Class Initialized
INFO - 2023-05-06 15:14:20 --> Helper loaded: url_helper
INFO - 2023-05-06 15:14:20 --> Helper loaded: form_helper
INFO - 2023-05-06 15:14:20 --> Database Driver Class Initialized
INFO - 2023-05-06 15:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-06 15:14:20 --> Form Validation Class Initialized
INFO - 2023-05-06 15:14:20 --> Controller Class Initialized
INFO - 2023-05-06 15:14:20 --> Model "m_user" initialized
INFO - 2023-05-06 15:14:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-06 15:14:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-06 15:14:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-06 15:14:20 --> Final output sent to browser
