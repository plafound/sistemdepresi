<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-31 06:48:43 --> Config Class Initialized
INFO - 2023-05-31 06:48:43 --> Hooks Class Initialized
INFO - 2023-05-31 06:48:43 --> Utf8 Class Initialized
INFO - 2023-05-31 06:48:43 --> URI Class Initialized
INFO - 2023-05-31 06:48:43 --> Router Class Initialized
INFO - 2023-05-31 06:48:43 --> Output Class Initialized
INFO - 2023-05-31 06:48:43 --> Security Class Initialized
INFO - 2023-05-31 06:48:43 --> Input Class Initialized
INFO - 2023-05-31 06:48:43 --> Language Class Initialized
INFO - 2023-05-31 06:48:43 --> Loader Class Initialized
INFO - 2023-05-31 06:48:43 --> Helper loaded: url_helper
INFO - 2023-05-31 06:48:43 --> Helper loaded: form_helper
INFO - 2023-05-31 06:48:44 --> Database Driver Class Initialized
INFO - 2023-05-31 06:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 06:48:44 --> Form Validation Class Initialized
INFO - 2023-05-31 06:48:44 --> Controller Class Initialized
INFO - 2023-05-31 06:48:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-31 06:48:44 --> Final output sent to browser
INFO - 2023-05-31 07:01:32 --> Config Class Initialized
INFO - 2023-05-31 07:01:32 --> Hooks Class Initialized
INFO - 2023-05-31 07:01:32 --> Utf8 Class Initialized
INFO - 2023-05-31 07:01:32 --> URI Class Initialized
INFO - 2023-05-31 07:01:32 --> Router Class Initialized
INFO - 2023-05-31 07:01:32 --> Output Class Initialized
INFO - 2023-05-31 07:01:32 --> Security Class Initialized
INFO - 2023-05-31 07:01:32 --> Input Class Initialized
INFO - 2023-05-31 07:01:32 --> Language Class Initialized
INFO - 2023-05-31 07:01:32 --> Loader Class Initialized
INFO - 2023-05-31 07:01:32 --> Helper loaded: url_helper
INFO - 2023-05-31 07:01:32 --> Helper loaded: form_helper
INFO - 2023-05-31 07:01:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:01:32 --> Form Validation Class Initialized
INFO - 2023-05-31 07:01:32 --> Controller Class Initialized
INFO - 2023-05-31 07:01:32 --> Model "m_user" initialized
INFO - 2023-05-31 07:01:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:01:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:01:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:01:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:01:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:01:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-31 07:01:33 --> Final output sent to browser
INFO - 2023-05-31 07:01:41 --> Config Class Initialized
INFO - 2023-05-31 07:01:41 --> Hooks Class Initialized
INFO - 2023-05-31 07:01:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:01:41 --> URI Class Initialized
INFO - 2023-05-31 07:01:41 --> Router Class Initialized
INFO - 2023-05-31 07:01:41 --> Output Class Initialized
INFO - 2023-05-31 07:01:41 --> Security Class Initialized
INFO - 2023-05-31 07:01:41 --> Input Class Initialized
INFO - 2023-05-31 07:01:41 --> Language Class Initialized
INFO - 2023-05-31 07:01:41 --> Loader Class Initialized
INFO - 2023-05-31 07:01:41 --> Helper loaded: url_helper
INFO - 2023-05-31 07:01:41 --> Helper loaded: form_helper
INFO - 2023-05-31 07:01:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:01:41 --> Form Validation Class Initialized
INFO - 2023-05-31 07:01:41 --> Controller Class Initialized
INFO - 2023-05-31 07:01:41 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:01:41 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:01:41 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:01:41 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:01:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:01:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:01:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-31 07:01:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:01:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:01:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:01:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:01:41 --> Final output sent to browser
INFO - 2023-05-31 07:01:43 --> Config Class Initialized
INFO - 2023-05-31 07:01:43 --> Hooks Class Initialized
INFO - 2023-05-31 07:01:43 --> Utf8 Class Initialized
INFO - 2023-05-31 07:01:43 --> URI Class Initialized
INFO - 2023-05-31 07:01:43 --> Router Class Initialized
INFO - 2023-05-31 07:01:43 --> Output Class Initialized
INFO - 2023-05-31 07:01:43 --> Security Class Initialized
INFO - 2023-05-31 07:01:43 --> Input Class Initialized
INFO - 2023-05-31 07:01:43 --> Language Class Initialized
INFO - 2023-05-31 07:01:43 --> Loader Class Initialized
INFO - 2023-05-31 07:01:43 --> Helper loaded: url_helper
INFO - 2023-05-31 07:01:43 --> Helper loaded: form_helper
INFO - 2023-05-31 07:01:43 --> Database Driver Class Initialized
INFO - 2023-05-31 07:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:01:43 --> Form Validation Class Initialized
INFO - 2023-05-31 07:01:43 --> Controller Class Initialized
INFO - 2023-05-31 07:01:43 --> Model "m_user" initialized
INFO - 2023-05-31 07:01:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:01:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:01:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:01:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:01:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:01:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-31 07:01:43 --> Final output sent to browser
INFO - 2023-05-31 07:01:56 --> Config Class Initialized
INFO - 2023-05-31 07:01:56 --> Hooks Class Initialized
INFO - 2023-05-31 07:01:56 --> Utf8 Class Initialized
INFO - 2023-05-31 07:01:56 --> URI Class Initialized
INFO - 2023-05-31 07:01:56 --> Router Class Initialized
INFO - 2023-05-31 07:01:56 --> Output Class Initialized
INFO - 2023-05-31 07:01:56 --> Security Class Initialized
INFO - 2023-05-31 07:01:56 --> Input Class Initialized
INFO - 2023-05-31 07:01:56 --> Language Class Initialized
INFO - 2023-05-31 07:01:56 --> Loader Class Initialized
INFO - 2023-05-31 07:01:56 --> Helper loaded: url_helper
INFO - 2023-05-31 07:01:56 --> Helper loaded: form_helper
INFO - 2023-05-31 07:01:56 --> Database Driver Class Initialized
INFO - 2023-05-31 07:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:01:56 --> Form Validation Class Initialized
INFO - 2023-05-31 07:01:56 --> Controller Class Initialized
INFO - 2023-05-31 07:01:56 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:01:56 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:01:56 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:01:56 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-31 07:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:01:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:01:56 --> Final output sent to browser
INFO - 2023-05-31 07:02:02 --> Config Class Initialized
INFO - 2023-05-31 07:02:02 --> Hooks Class Initialized
INFO - 2023-05-31 07:02:02 --> Utf8 Class Initialized
INFO - 2023-05-31 07:02:02 --> URI Class Initialized
INFO - 2023-05-31 07:02:02 --> Router Class Initialized
INFO - 2023-05-31 07:02:02 --> Output Class Initialized
INFO - 2023-05-31 07:02:02 --> Security Class Initialized
INFO - 2023-05-31 07:02:02 --> Input Class Initialized
INFO - 2023-05-31 07:02:02 --> Language Class Initialized
INFO - 2023-05-31 07:02:02 --> Loader Class Initialized
INFO - 2023-05-31 07:02:02 --> Helper loaded: url_helper
INFO - 2023-05-31 07:02:02 --> Helper loaded: form_helper
INFO - 2023-05-31 07:02:02 --> Database Driver Class Initialized
INFO - 2023-05-31 07:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:02:02 --> Form Validation Class Initialized
INFO - 2023-05-31 07:02:02 --> Controller Class Initialized
INFO - 2023-05-31 07:02:02 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:02:02 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:02:02 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:02:02 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:02:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:02:02 --> Final output sent to browser
INFO - 2023-05-31 07:10:13 --> Config Class Initialized
INFO - 2023-05-31 07:10:13 --> Hooks Class Initialized
INFO - 2023-05-31 07:10:13 --> Utf8 Class Initialized
INFO - 2023-05-31 07:10:13 --> URI Class Initialized
INFO - 2023-05-31 07:10:13 --> Router Class Initialized
INFO - 2023-05-31 07:10:13 --> Output Class Initialized
INFO - 2023-05-31 07:10:13 --> Security Class Initialized
INFO - 2023-05-31 07:10:13 --> Input Class Initialized
INFO - 2023-05-31 07:10:13 --> Language Class Initialized
INFO - 2023-05-31 07:10:13 --> Loader Class Initialized
INFO - 2023-05-31 07:10:13 --> Helper loaded: url_helper
INFO - 2023-05-31 07:10:13 --> Helper loaded: form_helper
INFO - 2023-05-31 07:10:13 --> Database Driver Class Initialized
INFO - 2023-05-31 07:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:10:13 --> Form Validation Class Initialized
INFO - 2023-05-31 07:10:13 --> Controller Class Initialized
INFO - 2023-05-31 07:10:13 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:10:13 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:10:13 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:10:13 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:10:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:10:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-31 07:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 27
ERROR - 2023-05-31 07:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 28
INFO - 2023-05-31 07:10:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:10:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:10:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:10:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:10:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:10:14 --> Final output sent to browser
INFO - 2023-05-31 07:11:08 --> Config Class Initialized
INFO - 2023-05-31 07:11:08 --> Hooks Class Initialized
INFO - 2023-05-31 07:11:08 --> Utf8 Class Initialized
INFO - 2023-05-31 07:11:08 --> URI Class Initialized
INFO - 2023-05-31 07:11:08 --> Router Class Initialized
INFO - 2023-05-31 07:11:08 --> Output Class Initialized
INFO - 2023-05-31 07:11:08 --> Security Class Initialized
INFO - 2023-05-31 07:11:08 --> Input Class Initialized
INFO - 2023-05-31 07:11:08 --> Language Class Initialized
INFO - 2023-05-31 07:11:08 --> Loader Class Initialized
INFO - 2023-05-31 07:11:08 --> Helper loaded: url_helper
INFO - 2023-05-31 07:11:08 --> Helper loaded: form_helper
INFO - 2023-05-31 07:11:08 --> Database Driver Class Initialized
INFO - 2023-05-31 07:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:11:08 --> Form Validation Class Initialized
INFO - 2023-05-31 07:11:08 --> Controller Class Initialized
INFO - 2023-05-31 07:11:08 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:11:08 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:11:08 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:11:08 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:11:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:11:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-31 07:11:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 27
ERROR - 2023-05-31 07:11:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 28
INFO - 2023-05-31 07:11:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:11:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:11:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:11:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:11:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:11:08 --> Final output sent to browser
INFO - 2023-05-31 07:18:44 --> Config Class Initialized
INFO - 2023-05-31 07:18:44 --> Hooks Class Initialized
INFO - 2023-05-31 07:18:44 --> Utf8 Class Initialized
INFO - 2023-05-31 07:18:44 --> URI Class Initialized
INFO - 2023-05-31 07:18:44 --> Router Class Initialized
INFO - 2023-05-31 07:18:44 --> Output Class Initialized
INFO - 2023-05-31 07:18:44 --> Security Class Initialized
INFO - 2023-05-31 07:18:44 --> Input Class Initialized
INFO - 2023-05-31 07:18:44 --> Language Class Initialized
INFO - 2023-05-31 07:18:44 --> Loader Class Initialized
INFO - 2023-05-31 07:18:44 --> Helper loaded: url_helper
INFO - 2023-05-31 07:18:44 --> Helper loaded: form_helper
INFO - 2023-05-31 07:18:44 --> Database Driver Class Initialized
INFO - 2023-05-31 07:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:18:44 --> Form Validation Class Initialized
INFO - 2023-05-31 07:18:44 --> Controller Class Initialized
INFO - 2023-05-31 07:18:44 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:18:44 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:18:44 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:18:44 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:18:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:18:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-31 07:18:44 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 30
INFO - 2023-05-31 07:19:39 --> Config Class Initialized
INFO - 2023-05-31 07:19:39 --> Hooks Class Initialized
INFO - 2023-05-31 07:19:39 --> Utf8 Class Initialized
INFO - 2023-05-31 07:19:39 --> URI Class Initialized
INFO - 2023-05-31 07:19:39 --> Router Class Initialized
INFO - 2023-05-31 07:19:39 --> Output Class Initialized
INFO - 2023-05-31 07:19:39 --> Security Class Initialized
INFO - 2023-05-31 07:19:39 --> Input Class Initialized
INFO - 2023-05-31 07:19:39 --> Language Class Initialized
INFO - 2023-05-31 07:19:39 --> Loader Class Initialized
INFO - 2023-05-31 07:19:39 --> Helper loaded: url_helper
INFO - 2023-05-31 07:19:39 --> Helper loaded: form_helper
INFO - 2023-05-31 07:19:39 --> Database Driver Class Initialized
INFO - 2023-05-31 07:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:19:39 --> Form Validation Class Initialized
INFO - 2023-05-31 07:19:39 --> Controller Class Initialized
INFO - 2023-05-31 07:19:39 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:19:39 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:19:39 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:19:39 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:19:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:19:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:19:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:19:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:19:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:19:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:19:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:19:39 --> Final output sent to browser
INFO - 2023-05-31 07:20:26 --> Config Class Initialized
INFO - 2023-05-31 07:20:26 --> Hooks Class Initialized
INFO - 2023-05-31 07:20:26 --> Utf8 Class Initialized
INFO - 2023-05-31 07:20:26 --> URI Class Initialized
INFO - 2023-05-31 07:20:26 --> Router Class Initialized
INFO - 2023-05-31 07:20:26 --> Output Class Initialized
INFO - 2023-05-31 07:20:26 --> Security Class Initialized
INFO - 2023-05-31 07:20:26 --> Input Class Initialized
INFO - 2023-05-31 07:20:26 --> Language Class Initialized
INFO - 2023-05-31 07:20:26 --> Loader Class Initialized
INFO - 2023-05-31 07:20:26 --> Helper loaded: url_helper
INFO - 2023-05-31 07:20:26 --> Helper loaded: form_helper
INFO - 2023-05-31 07:20:26 --> Database Driver Class Initialized
INFO - 2023-05-31 07:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:20:26 --> Form Validation Class Initialized
INFO - 2023-05-31 07:20:26 --> Controller Class Initialized
INFO - 2023-05-31 07:20:26 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:20:26 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:20:26 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:20:26 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:20:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:20:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:20:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:20:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:20:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:20:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:20:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:20:26 --> Final output sent to browser
INFO - 2023-05-31 07:21:08 --> Config Class Initialized
INFO - 2023-05-31 07:21:08 --> Hooks Class Initialized
INFO - 2023-05-31 07:21:08 --> Utf8 Class Initialized
INFO - 2023-05-31 07:21:08 --> URI Class Initialized
INFO - 2023-05-31 07:21:08 --> Router Class Initialized
INFO - 2023-05-31 07:21:08 --> Output Class Initialized
INFO - 2023-05-31 07:21:08 --> Security Class Initialized
INFO - 2023-05-31 07:21:08 --> Input Class Initialized
INFO - 2023-05-31 07:21:08 --> Language Class Initialized
INFO - 2023-05-31 07:21:08 --> Loader Class Initialized
INFO - 2023-05-31 07:21:08 --> Helper loaded: url_helper
INFO - 2023-05-31 07:21:08 --> Helper loaded: form_helper
INFO - 2023-05-31 07:21:08 --> Database Driver Class Initialized
INFO - 2023-05-31 07:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:21:08 --> Form Validation Class Initialized
INFO - 2023-05-31 07:21:08 --> Controller Class Initialized
INFO - 2023-05-31 07:21:08 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:21:08 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:21:08 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:21:08 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:21:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:21:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:21:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:21:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:21:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:21:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:21:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:21:08 --> Final output sent to browser
INFO - 2023-05-31 07:21:31 --> Config Class Initialized
INFO - 2023-05-31 07:21:31 --> Hooks Class Initialized
INFO - 2023-05-31 07:21:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:21:31 --> URI Class Initialized
INFO - 2023-05-31 07:21:31 --> Router Class Initialized
INFO - 2023-05-31 07:21:31 --> Output Class Initialized
INFO - 2023-05-31 07:21:31 --> Security Class Initialized
INFO - 2023-05-31 07:21:31 --> Input Class Initialized
INFO - 2023-05-31 07:21:31 --> Language Class Initialized
INFO - 2023-05-31 07:21:31 --> Loader Class Initialized
INFO - 2023-05-31 07:21:31 --> Helper loaded: url_helper
INFO - 2023-05-31 07:21:31 --> Helper loaded: form_helper
INFO - 2023-05-31 07:21:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:21:31 --> Form Validation Class Initialized
INFO - 2023-05-31 07:21:31 --> Controller Class Initialized
INFO - 2023-05-31 07:21:31 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:21:31 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:21:31 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:21:31 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:21:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:21:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:21:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:21:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:21:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:21:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:21:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:21:31 --> Final output sent to browser
INFO - 2023-05-31 07:23:06 --> Config Class Initialized
INFO - 2023-05-31 07:23:06 --> Hooks Class Initialized
INFO - 2023-05-31 07:23:06 --> Utf8 Class Initialized
INFO - 2023-05-31 07:23:06 --> URI Class Initialized
INFO - 2023-05-31 07:23:06 --> Router Class Initialized
INFO - 2023-05-31 07:23:06 --> Output Class Initialized
INFO - 2023-05-31 07:23:06 --> Security Class Initialized
INFO - 2023-05-31 07:23:06 --> Input Class Initialized
INFO - 2023-05-31 07:23:06 --> Language Class Initialized
INFO - 2023-05-31 07:23:06 --> Loader Class Initialized
INFO - 2023-05-31 07:23:06 --> Helper loaded: url_helper
INFO - 2023-05-31 07:23:06 --> Helper loaded: form_helper
INFO - 2023-05-31 07:23:06 --> Database Driver Class Initialized
INFO - 2023-05-31 07:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:23:06 --> Form Validation Class Initialized
INFO - 2023-05-31 07:23:06 --> Controller Class Initialized
INFO - 2023-05-31 07:23:06 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:23:06 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:23:06 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:23:06 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:23:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:23:06 --> Final output sent to browser
INFO - 2023-05-31 07:23:20 --> Config Class Initialized
INFO - 2023-05-31 07:23:20 --> Hooks Class Initialized
INFO - 2023-05-31 07:23:20 --> Utf8 Class Initialized
INFO - 2023-05-31 07:23:20 --> URI Class Initialized
INFO - 2023-05-31 07:23:20 --> Router Class Initialized
INFO - 2023-05-31 07:23:20 --> Output Class Initialized
INFO - 2023-05-31 07:23:20 --> Security Class Initialized
INFO - 2023-05-31 07:23:20 --> Input Class Initialized
INFO - 2023-05-31 07:23:20 --> Language Class Initialized
INFO - 2023-05-31 07:23:20 --> Loader Class Initialized
INFO - 2023-05-31 07:23:20 --> Helper loaded: url_helper
INFO - 2023-05-31 07:23:20 --> Helper loaded: form_helper
INFO - 2023-05-31 07:23:20 --> Database Driver Class Initialized
INFO - 2023-05-31 07:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:23:20 --> Form Validation Class Initialized
INFO - 2023-05-31 07:23:20 --> Controller Class Initialized
INFO - 2023-05-31 07:23:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-31 07:23:20 --> Final output sent to browser
INFO - 2023-05-31 07:39:01 --> Config Class Initialized
INFO - 2023-05-31 07:39:01 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:01 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:01 --> URI Class Initialized
INFO - 2023-05-31 07:39:01 --> Router Class Initialized
INFO - 2023-05-31 07:39:01 --> Output Class Initialized
INFO - 2023-05-31 07:39:01 --> Security Class Initialized
INFO - 2023-05-31 07:39:01 --> Input Class Initialized
INFO - 2023-05-31 07:39:01 --> Language Class Initialized
INFO - 2023-05-31 07:39:01 --> Loader Class Initialized
INFO - 2023-05-31 07:39:01 --> Helper loaded: url_helper
INFO - 2023-05-31 07:39:01 --> Helper loaded: form_helper
INFO - 2023-05-31 07:39:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:39:01 --> Form Validation Class Initialized
INFO - 2023-05-31 07:39:01 --> Controller Class Initialized
INFO - 2023-05-31 07:39:01 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:39:01 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:39:01 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:39:01 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:39:01 --> Final output sent to browser
INFO - 2023-05-31 07:39:25 --> Config Class Initialized
INFO - 2023-05-31 07:39:25 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:25 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:25 --> URI Class Initialized
INFO - 2023-05-31 07:39:25 --> Router Class Initialized
INFO - 2023-05-31 07:39:25 --> Output Class Initialized
INFO - 2023-05-31 07:39:25 --> Security Class Initialized
INFO - 2023-05-31 07:39:25 --> Input Class Initialized
INFO - 2023-05-31 07:39:25 --> Language Class Initialized
INFO - 2023-05-31 07:39:25 --> Loader Class Initialized
INFO - 2023-05-31 07:39:25 --> Helper loaded: url_helper
INFO - 2023-05-31 07:39:25 --> Helper loaded: form_helper
INFO - 2023-05-31 07:39:25 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:39:25 --> Form Validation Class Initialized
INFO - 2023-05-31 07:39:25 --> Controller Class Initialized
INFO - 2023-05-31 07:39:25 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:39:25 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:39:25 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:39:25 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:39:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:39:25 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-31 07:39:25 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 54
INFO - 2023-05-31 07:39:36 --> Config Class Initialized
INFO - 2023-05-31 07:39:36 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:36 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:36 --> URI Class Initialized
INFO - 2023-05-31 07:39:36 --> Router Class Initialized
INFO - 2023-05-31 07:39:36 --> Output Class Initialized
INFO - 2023-05-31 07:39:36 --> Security Class Initialized
INFO - 2023-05-31 07:39:36 --> Input Class Initialized
INFO - 2023-05-31 07:39:36 --> Language Class Initialized
INFO - 2023-05-31 07:39:36 --> Loader Class Initialized
INFO - 2023-05-31 07:39:36 --> Helper loaded: url_helper
INFO - 2023-05-31 07:39:36 --> Helper loaded: form_helper
INFO - 2023-05-31 07:39:36 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:39:36 --> Form Validation Class Initialized
INFO - 2023-05-31 07:39:36 --> Controller Class Initialized
INFO - 2023-05-31 07:39:36 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:39:36 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:39:36 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:39:36 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:39:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:39:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:39:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:39:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:39:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:39:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:39:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:39:36 --> Final output sent to browser
INFO - 2023-05-31 07:52:00 --> Config Class Initialized
INFO - 2023-05-31 07:52:00 --> Hooks Class Initialized
INFO - 2023-05-31 07:52:00 --> Utf8 Class Initialized
INFO - 2023-05-31 07:52:00 --> URI Class Initialized
INFO - 2023-05-31 07:52:00 --> Router Class Initialized
INFO - 2023-05-31 07:52:00 --> Output Class Initialized
INFO - 2023-05-31 07:52:00 --> Security Class Initialized
INFO - 2023-05-31 07:52:00 --> Input Class Initialized
INFO - 2023-05-31 07:52:00 --> Language Class Initialized
INFO - 2023-05-31 07:52:00 --> Loader Class Initialized
INFO - 2023-05-31 07:52:00 --> Helper loaded: url_helper
INFO - 2023-05-31 07:52:00 --> Helper loaded: form_helper
INFO - 2023-05-31 07:52:00 --> Database Driver Class Initialized
INFO - 2023-05-31 07:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:52:00 --> Form Validation Class Initialized
INFO - 2023-05-31 07:52:00 --> Controller Class Initialized
INFO - 2023-05-31 07:52:00 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:52:00 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:52:00 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:52:00 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:52:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:52:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:52:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:52:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:52:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:52:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:52:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:52:00 --> Final output sent to browser
INFO - 2023-05-31 07:52:23 --> Config Class Initialized
INFO - 2023-05-31 07:52:23 --> Hooks Class Initialized
INFO - 2023-05-31 07:52:23 --> Utf8 Class Initialized
INFO - 2023-05-31 07:52:23 --> URI Class Initialized
INFO - 2023-05-31 07:52:23 --> Router Class Initialized
INFO - 2023-05-31 07:52:23 --> Output Class Initialized
INFO - 2023-05-31 07:52:23 --> Security Class Initialized
INFO - 2023-05-31 07:52:23 --> Input Class Initialized
INFO - 2023-05-31 07:52:23 --> Language Class Initialized
INFO - 2023-05-31 07:52:23 --> Loader Class Initialized
INFO - 2023-05-31 07:52:23 --> Helper loaded: url_helper
INFO - 2023-05-31 07:52:23 --> Helper loaded: form_helper
INFO - 2023-05-31 07:52:23 --> Database Driver Class Initialized
INFO - 2023-05-31 07:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:52:23 --> Form Validation Class Initialized
INFO - 2023-05-31 07:52:23 --> Controller Class Initialized
INFO - 2023-05-31 07:52:23 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:52:23 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:52:23 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:52:23 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:52:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:52:23 --> Final output sent to browser
INFO - 2023-05-31 07:52:46 --> Config Class Initialized
INFO - 2023-05-31 07:52:46 --> Hooks Class Initialized
INFO - 2023-05-31 07:52:46 --> Utf8 Class Initialized
INFO - 2023-05-31 07:52:46 --> URI Class Initialized
INFO - 2023-05-31 07:52:46 --> Router Class Initialized
INFO - 2023-05-31 07:52:46 --> Output Class Initialized
INFO - 2023-05-31 07:52:46 --> Security Class Initialized
INFO - 2023-05-31 07:52:46 --> Input Class Initialized
INFO - 2023-05-31 07:52:46 --> Language Class Initialized
INFO - 2023-05-31 07:52:46 --> Loader Class Initialized
INFO - 2023-05-31 07:52:46 --> Helper loaded: url_helper
INFO - 2023-05-31 07:52:46 --> Helper loaded: form_helper
INFO - 2023-05-31 07:52:46 --> Database Driver Class Initialized
INFO - 2023-05-31 07:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:52:46 --> Form Validation Class Initialized
INFO - 2023-05-31 07:52:46 --> Controller Class Initialized
INFO - 2023-05-31 07:52:46 --> Model "m_datatrain" initialized
INFO - 2023-05-31 07:52:46 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 07:52:46 --> Model "m_datatest" initialized
INFO - 2023-05-31 07:52:46 --> Model "M_solusi" initialized
INFO - 2023-05-31 07:52:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 07:52:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 07:52:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 07:52:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 07:52:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 07:52:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 07:52:46 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 07:52:46 --> Final output sent to browser
INFO - 2023-05-31 08:03:08 --> Config Class Initialized
INFO - 2023-05-31 08:03:08 --> Hooks Class Initialized
INFO - 2023-05-31 08:03:08 --> Utf8 Class Initialized
INFO - 2023-05-31 08:03:08 --> URI Class Initialized
INFO - 2023-05-31 08:03:08 --> Router Class Initialized
INFO - 2023-05-31 08:03:08 --> Output Class Initialized
INFO - 2023-05-31 08:03:08 --> Security Class Initialized
INFO - 2023-05-31 08:03:08 --> Input Class Initialized
INFO - 2023-05-31 08:03:08 --> Language Class Initialized
INFO - 2023-05-31 08:03:08 --> Loader Class Initialized
INFO - 2023-05-31 08:03:08 --> Helper loaded: url_helper
INFO - 2023-05-31 08:03:08 --> Helper loaded: form_helper
INFO - 2023-05-31 08:03:08 --> Database Driver Class Initialized
INFO - 2023-05-31 08:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:03:08 --> Form Validation Class Initialized
INFO - 2023-05-31 08:03:08 --> Controller Class Initialized
INFO - 2023-05-31 08:03:08 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:03:08 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:03:08 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:03:08 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:03:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:03:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:03:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:03:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:03:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:03:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:03:08 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:03:08 --> Final output sent to browser
INFO - 2023-05-31 08:03:32 --> Config Class Initialized
INFO - 2023-05-31 08:03:32 --> Hooks Class Initialized
INFO - 2023-05-31 08:03:32 --> Utf8 Class Initialized
INFO - 2023-05-31 08:03:32 --> URI Class Initialized
INFO - 2023-05-31 08:03:32 --> Router Class Initialized
INFO - 2023-05-31 08:03:32 --> Output Class Initialized
INFO - 2023-05-31 08:03:32 --> Security Class Initialized
INFO - 2023-05-31 08:03:32 --> Input Class Initialized
INFO - 2023-05-31 08:03:32 --> Language Class Initialized
INFO - 2023-05-31 08:03:32 --> Loader Class Initialized
INFO - 2023-05-31 08:03:32 --> Helper loaded: url_helper
INFO - 2023-05-31 08:03:32 --> Helper loaded: form_helper
INFO - 2023-05-31 08:03:32 --> Database Driver Class Initialized
INFO - 2023-05-31 08:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:03:32 --> Form Validation Class Initialized
INFO - 2023-05-31 08:03:32 --> Controller Class Initialized
INFO - 2023-05-31 08:03:32 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:03:32 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:03:32 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:03:32 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:03:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:03:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:03:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:03:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:03:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:03:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:03:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:03:32 --> Final output sent to browser
INFO - 2023-05-31 08:06:11 --> Config Class Initialized
INFO - 2023-05-31 08:06:11 --> Hooks Class Initialized
INFO - 2023-05-31 08:06:11 --> Utf8 Class Initialized
INFO - 2023-05-31 08:06:11 --> URI Class Initialized
INFO - 2023-05-31 08:06:11 --> Router Class Initialized
INFO - 2023-05-31 08:06:11 --> Output Class Initialized
INFO - 2023-05-31 08:06:11 --> Security Class Initialized
INFO - 2023-05-31 08:06:11 --> Input Class Initialized
INFO - 2023-05-31 08:06:11 --> Language Class Initialized
INFO - 2023-05-31 08:06:11 --> Loader Class Initialized
INFO - 2023-05-31 08:06:11 --> Helper loaded: url_helper
INFO - 2023-05-31 08:06:11 --> Helper loaded: form_helper
INFO - 2023-05-31 08:06:11 --> Database Driver Class Initialized
INFO - 2023-05-31 08:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:06:11 --> Form Validation Class Initialized
INFO - 2023-05-31 08:06:11 --> Controller Class Initialized
INFO - 2023-05-31 08:06:11 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:06:11 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:06:11 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:06:11 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:06:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:06:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:06:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:06:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:06:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:06:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:06:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:06:11 --> Final output sent to browser
INFO - 2023-05-31 08:08:32 --> Config Class Initialized
INFO - 2023-05-31 08:08:32 --> Hooks Class Initialized
INFO - 2023-05-31 08:08:32 --> Utf8 Class Initialized
INFO - 2023-05-31 08:08:32 --> URI Class Initialized
INFO - 2023-05-31 08:08:32 --> Router Class Initialized
INFO - 2023-05-31 08:08:32 --> Output Class Initialized
INFO - 2023-05-31 08:08:32 --> Security Class Initialized
INFO - 2023-05-31 08:08:32 --> Input Class Initialized
INFO - 2023-05-31 08:08:32 --> Language Class Initialized
INFO - 2023-05-31 08:08:32 --> Loader Class Initialized
INFO - 2023-05-31 08:08:32 --> Helper loaded: url_helper
INFO - 2023-05-31 08:08:32 --> Helper loaded: form_helper
INFO - 2023-05-31 08:08:32 --> Database Driver Class Initialized
INFO - 2023-05-31 08:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:08:32 --> Form Validation Class Initialized
INFO - 2023-05-31 08:08:32 --> Controller Class Initialized
INFO - 2023-05-31 08:08:32 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:08:32 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:08:32 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:08:32 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:08:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:08:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:08:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:08:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:08:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:08:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:08:32 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:08:32 --> Final output sent to browser
INFO - 2023-05-31 08:09:29 --> Config Class Initialized
INFO - 2023-05-31 08:09:29 --> Hooks Class Initialized
INFO - 2023-05-31 08:09:29 --> Utf8 Class Initialized
INFO - 2023-05-31 08:09:29 --> URI Class Initialized
INFO - 2023-05-31 08:09:29 --> Router Class Initialized
INFO - 2023-05-31 08:09:29 --> Output Class Initialized
INFO - 2023-05-31 08:09:29 --> Security Class Initialized
INFO - 2023-05-31 08:09:29 --> Input Class Initialized
INFO - 2023-05-31 08:09:29 --> Language Class Initialized
INFO - 2023-05-31 08:09:29 --> Loader Class Initialized
INFO - 2023-05-31 08:09:29 --> Helper loaded: url_helper
INFO - 2023-05-31 08:09:29 --> Helper loaded: form_helper
INFO - 2023-05-31 08:09:29 --> Database Driver Class Initialized
INFO - 2023-05-31 08:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:09:29 --> Form Validation Class Initialized
INFO - 2023-05-31 08:09:29 --> Controller Class Initialized
INFO - 2023-05-31 08:09:29 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:09:29 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:09:29 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:09:29 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:09:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:09:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:09:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:09:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:09:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:09:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:09:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:09:29 --> Final output sent to browser
INFO - 2023-05-31 08:10:12 --> Config Class Initialized
INFO - 2023-05-31 08:10:12 --> Hooks Class Initialized
INFO - 2023-05-31 08:10:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:10:12 --> URI Class Initialized
INFO - 2023-05-31 08:10:12 --> Router Class Initialized
INFO - 2023-05-31 08:10:12 --> Output Class Initialized
INFO - 2023-05-31 08:10:12 --> Security Class Initialized
INFO - 2023-05-31 08:10:12 --> Input Class Initialized
INFO - 2023-05-31 08:10:12 --> Language Class Initialized
INFO - 2023-05-31 08:10:12 --> Loader Class Initialized
INFO - 2023-05-31 08:10:12 --> Helper loaded: url_helper
INFO - 2023-05-31 08:10:12 --> Helper loaded: form_helper
INFO - 2023-05-31 08:10:12 --> Database Driver Class Initialized
INFO - 2023-05-31 08:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:10:12 --> Form Validation Class Initialized
INFO - 2023-05-31 08:10:12 --> Controller Class Initialized
INFO - 2023-05-31 08:10:12 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:10:12 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:10:12 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:10:12 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:10:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:10:12 --> Final output sent to browser
INFO - 2023-05-31 08:11:30 --> Config Class Initialized
INFO - 2023-05-31 08:11:30 --> Hooks Class Initialized
INFO - 2023-05-31 08:11:30 --> Utf8 Class Initialized
INFO - 2023-05-31 08:11:30 --> URI Class Initialized
INFO - 2023-05-31 08:11:30 --> Router Class Initialized
INFO - 2023-05-31 08:11:30 --> Output Class Initialized
INFO - 2023-05-31 08:11:30 --> Security Class Initialized
INFO - 2023-05-31 08:11:30 --> Input Class Initialized
INFO - 2023-05-31 08:11:30 --> Language Class Initialized
INFO - 2023-05-31 08:11:30 --> Loader Class Initialized
INFO - 2023-05-31 08:11:30 --> Helper loaded: url_helper
INFO - 2023-05-31 08:11:30 --> Helper loaded: form_helper
INFO - 2023-05-31 08:11:30 --> Database Driver Class Initialized
INFO - 2023-05-31 08:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:11:30 --> Form Validation Class Initialized
INFO - 2023-05-31 08:11:30 --> Controller Class Initialized
INFO - 2023-05-31 08:11:30 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:11:30 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:11:30 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:11:30 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:11:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:11:30 --> Final output sent to browser
INFO - 2023-05-31 08:11:50 --> Config Class Initialized
INFO - 2023-05-31 08:11:50 --> Hooks Class Initialized
INFO - 2023-05-31 08:11:50 --> Utf8 Class Initialized
INFO - 2023-05-31 08:11:50 --> URI Class Initialized
INFO - 2023-05-31 08:11:50 --> Router Class Initialized
INFO - 2023-05-31 08:11:50 --> Output Class Initialized
INFO - 2023-05-31 08:11:50 --> Security Class Initialized
INFO - 2023-05-31 08:11:50 --> Input Class Initialized
INFO - 2023-05-31 08:11:50 --> Language Class Initialized
INFO - 2023-05-31 08:11:50 --> Loader Class Initialized
INFO - 2023-05-31 08:11:50 --> Helper loaded: url_helper
INFO - 2023-05-31 08:11:50 --> Helper loaded: form_helper
INFO - 2023-05-31 08:11:50 --> Database Driver Class Initialized
INFO - 2023-05-31 08:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:11:50 --> Form Validation Class Initialized
INFO - 2023-05-31 08:11:50 --> Controller Class Initialized
INFO - 2023-05-31 08:11:50 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:11:50 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:11:50 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:11:50 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:11:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:11:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:11:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:11:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:11:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:11:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:11:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:11:50 --> Final output sent to browser
INFO - 2023-05-31 08:12:20 --> Config Class Initialized
INFO - 2023-05-31 08:12:20 --> Hooks Class Initialized
INFO - 2023-05-31 08:12:20 --> Utf8 Class Initialized
INFO - 2023-05-31 08:12:20 --> URI Class Initialized
INFO - 2023-05-31 08:12:20 --> Router Class Initialized
INFO - 2023-05-31 08:12:20 --> Output Class Initialized
INFO - 2023-05-31 08:12:20 --> Security Class Initialized
INFO - 2023-05-31 08:12:20 --> Input Class Initialized
INFO - 2023-05-31 08:12:20 --> Language Class Initialized
INFO - 2023-05-31 08:12:20 --> Loader Class Initialized
INFO - 2023-05-31 08:12:20 --> Helper loaded: url_helper
INFO - 2023-05-31 08:12:20 --> Helper loaded: form_helper
INFO - 2023-05-31 08:12:20 --> Database Driver Class Initialized
INFO - 2023-05-31 08:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:12:20 --> Form Validation Class Initialized
INFO - 2023-05-31 08:12:20 --> Controller Class Initialized
INFO - 2023-05-31 08:12:20 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:12:20 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:12:20 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:12:20 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:12:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:12:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:12:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:12:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:12:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:12:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:12:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:12:20 --> Final output sent to browser
INFO - 2023-05-31 08:13:01 --> Config Class Initialized
INFO - 2023-05-31 08:13:01 --> Hooks Class Initialized
INFO - 2023-05-31 08:13:01 --> Utf8 Class Initialized
INFO - 2023-05-31 08:13:01 --> URI Class Initialized
INFO - 2023-05-31 08:13:01 --> Router Class Initialized
INFO - 2023-05-31 08:13:01 --> Output Class Initialized
INFO - 2023-05-31 08:13:01 --> Security Class Initialized
INFO - 2023-05-31 08:13:01 --> Input Class Initialized
INFO - 2023-05-31 08:13:01 --> Language Class Initialized
INFO - 2023-05-31 08:13:01 --> Loader Class Initialized
INFO - 2023-05-31 08:13:01 --> Helper loaded: url_helper
INFO - 2023-05-31 08:13:01 --> Helper loaded: form_helper
INFO - 2023-05-31 08:13:01 --> Database Driver Class Initialized
INFO - 2023-05-31 08:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:13:01 --> Form Validation Class Initialized
INFO - 2023-05-31 08:13:01 --> Controller Class Initialized
INFO - 2023-05-31 08:13:01 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:13:01 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:13:01 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:13:01 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:13:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:13:02 --> Final output sent to browser
INFO - 2023-05-31 08:13:34 --> Config Class Initialized
INFO - 2023-05-31 08:13:34 --> Hooks Class Initialized
INFO - 2023-05-31 08:13:34 --> Utf8 Class Initialized
INFO - 2023-05-31 08:13:34 --> URI Class Initialized
INFO - 2023-05-31 08:13:34 --> Router Class Initialized
INFO - 2023-05-31 08:13:34 --> Output Class Initialized
INFO - 2023-05-31 08:13:34 --> Security Class Initialized
INFO - 2023-05-31 08:13:34 --> Input Class Initialized
INFO - 2023-05-31 08:13:34 --> Language Class Initialized
INFO - 2023-05-31 08:13:34 --> Loader Class Initialized
INFO - 2023-05-31 08:13:34 --> Helper loaded: url_helper
INFO - 2023-05-31 08:13:34 --> Helper loaded: form_helper
INFO - 2023-05-31 08:13:34 --> Database Driver Class Initialized
INFO - 2023-05-31 08:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:13:35 --> Form Validation Class Initialized
INFO - 2023-05-31 08:13:35 --> Controller Class Initialized
INFO - 2023-05-31 08:13:35 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:13:35 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:13:35 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:13:35 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:13:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:13:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:13:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:13:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:13:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:13:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:13:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:13:35 --> Final output sent to browser
INFO - 2023-05-31 08:14:39 --> Config Class Initialized
INFO - 2023-05-31 08:14:39 --> Hooks Class Initialized
INFO - 2023-05-31 08:14:39 --> Utf8 Class Initialized
INFO - 2023-05-31 08:14:39 --> URI Class Initialized
INFO - 2023-05-31 08:14:39 --> Router Class Initialized
INFO - 2023-05-31 08:14:39 --> Output Class Initialized
INFO - 2023-05-31 08:14:39 --> Security Class Initialized
INFO - 2023-05-31 08:14:39 --> Input Class Initialized
INFO - 2023-05-31 08:14:39 --> Language Class Initialized
INFO - 2023-05-31 08:14:39 --> Loader Class Initialized
INFO - 2023-05-31 08:14:39 --> Helper loaded: url_helper
INFO - 2023-05-31 08:14:39 --> Helper loaded: form_helper
INFO - 2023-05-31 08:14:39 --> Database Driver Class Initialized
INFO - 2023-05-31 08:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:14:40 --> Form Validation Class Initialized
INFO - 2023-05-31 08:14:40 --> Controller Class Initialized
INFO - 2023-05-31 08:14:40 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:14:40 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:14:40 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:14:40 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:14:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:14:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:14:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:14:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:14:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:14:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:14:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:14:40 --> Final output sent to browser
INFO - 2023-05-31 08:15:17 --> Config Class Initialized
INFO - 2023-05-31 08:15:17 --> Hooks Class Initialized
INFO - 2023-05-31 08:15:17 --> Utf8 Class Initialized
INFO - 2023-05-31 08:15:17 --> URI Class Initialized
INFO - 2023-05-31 08:15:17 --> Router Class Initialized
INFO - 2023-05-31 08:15:17 --> Output Class Initialized
INFO - 2023-05-31 08:15:17 --> Security Class Initialized
INFO - 2023-05-31 08:15:17 --> Input Class Initialized
INFO - 2023-05-31 08:15:17 --> Language Class Initialized
INFO - 2023-05-31 08:15:17 --> Loader Class Initialized
INFO - 2023-05-31 08:15:17 --> Helper loaded: url_helper
INFO - 2023-05-31 08:15:17 --> Helper loaded: form_helper
INFO - 2023-05-31 08:15:17 --> Database Driver Class Initialized
INFO - 2023-05-31 08:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:15:17 --> Form Validation Class Initialized
INFO - 2023-05-31 08:15:17 --> Controller Class Initialized
INFO - 2023-05-31 08:15:17 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:15:17 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:15:17 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:15:17 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:15:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:15:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:15:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:15:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:15:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:15:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:15:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:15:17 --> Final output sent to browser
INFO - 2023-05-31 08:18:59 --> Config Class Initialized
INFO - 2023-05-31 08:18:59 --> Hooks Class Initialized
INFO - 2023-05-31 08:18:59 --> Utf8 Class Initialized
INFO - 2023-05-31 08:18:59 --> URI Class Initialized
INFO - 2023-05-31 08:18:59 --> Router Class Initialized
INFO - 2023-05-31 08:18:59 --> Output Class Initialized
INFO - 2023-05-31 08:18:59 --> Security Class Initialized
INFO - 2023-05-31 08:18:59 --> Input Class Initialized
INFO - 2023-05-31 08:18:59 --> Language Class Initialized
INFO - 2023-05-31 08:18:59 --> Loader Class Initialized
INFO - 2023-05-31 08:18:59 --> Helper loaded: url_helper
INFO - 2023-05-31 08:18:59 --> Helper loaded: form_helper
INFO - 2023-05-31 08:18:59 --> Database Driver Class Initialized
INFO - 2023-05-31 08:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:18:59 --> Form Validation Class Initialized
INFO - 2023-05-31 08:18:59 --> Controller Class Initialized
INFO - 2023-05-31 08:18:59 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:18:59 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:18:59 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:18:59 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:18:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:18:59 --> Final output sent to browser
INFO - 2023-05-31 08:19:20 --> Config Class Initialized
INFO - 2023-05-31 08:19:20 --> Hooks Class Initialized
INFO - 2023-05-31 08:19:20 --> Utf8 Class Initialized
INFO - 2023-05-31 08:19:20 --> URI Class Initialized
INFO - 2023-05-31 08:19:20 --> Router Class Initialized
INFO - 2023-05-31 08:19:20 --> Output Class Initialized
INFO - 2023-05-31 08:19:20 --> Security Class Initialized
INFO - 2023-05-31 08:19:20 --> Input Class Initialized
INFO - 2023-05-31 08:19:20 --> Language Class Initialized
INFO - 2023-05-31 08:19:20 --> Loader Class Initialized
INFO - 2023-05-31 08:19:20 --> Helper loaded: url_helper
INFO - 2023-05-31 08:19:20 --> Helper loaded: form_helper
INFO - 2023-05-31 08:19:20 --> Database Driver Class Initialized
INFO - 2023-05-31 08:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:19:20 --> Form Validation Class Initialized
INFO - 2023-05-31 08:19:20 --> Controller Class Initialized
INFO - 2023-05-31 08:19:20 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:19:20 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:19:20 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:19:20 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:19:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:19:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:19:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:19:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:19:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:19:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:19:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:19:20 --> Final output sent to browser
INFO - 2023-05-31 08:19:38 --> Config Class Initialized
INFO - 2023-05-31 08:19:38 --> Hooks Class Initialized
INFO - 2023-05-31 08:19:38 --> Utf8 Class Initialized
INFO - 2023-05-31 08:19:38 --> URI Class Initialized
INFO - 2023-05-31 08:19:38 --> Router Class Initialized
INFO - 2023-05-31 08:19:38 --> Output Class Initialized
INFO - 2023-05-31 08:19:38 --> Security Class Initialized
INFO - 2023-05-31 08:19:38 --> Input Class Initialized
INFO - 2023-05-31 08:19:38 --> Language Class Initialized
INFO - 2023-05-31 08:19:38 --> Loader Class Initialized
INFO - 2023-05-31 08:19:38 --> Helper loaded: url_helper
INFO - 2023-05-31 08:19:38 --> Helper loaded: form_helper
INFO - 2023-05-31 08:19:38 --> Database Driver Class Initialized
INFO - 2023-05-31 08:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:19:38 --> Form Validation Class Initialized
INFO - 2023-05-31 08:19:38 --> Controller Class Initialized
INFO - 2023-05-31 08:19:38 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:19:38 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:19:38 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:19:38 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:19:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:19:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:19:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:19:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:19:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:19:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:19:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:19:38 --> Final output sent to browser
INFO - 2023-05-31 08:22:44 --> Config Class Initialized
INFO - 2023-05-31 08:22:44 --> Hooks Class Initialized
INFO - 2023-05-31 08:22:44 --> Utf8 Class Initialized
INFO - 2023-05-31 08:22:44 --> URI Class Initialized
INFO - 2023-05-31 08:22:44 --> Router Class Initialized
INFO - 2023-05-31 08:22:44 --> Output Class Initialized
INFO - 2023-05-31 08:22:44 --> Security Class Initialized
INFO - 2023-05-31 08:22:44 --> Input Class Initialized
INFO - 2023-05-31 08:22:44 --> Language Class Initialized
INFO - 2023-05-31 08:22:44 --> Loader Class Initialized
INFO - 2023-05-31 08:22:44 --> Helper loaded: url_helper
INFO - 2023-05-31 08:22:44 --> Helper loaded: form_helper
INFO - 2023-05-31 08:22:44 --> Database Driver Class Initialized
INFO - 2023-05-31 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:22:44 --> Form Validation Class Initialized
INFO - 2023-05-31 08:22:44 --> Controller Class Initialized
INFO - 2023-05-31 08:22:44 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:22:44 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:22:44 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:22:44 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:22:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:22:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:22:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:22:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:22:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:22:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:22:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:22:44 --> Final output sent to browser
INFO - 2023-05-31 08:23:04 --> Config Class Initialized
INFO - 2023-05-31 08:23:04 --> Hooks Class Initialized
INFO - 2023-05-31 08:23:04 --> Utf8 Class Initialized
INFO - 2023-05-31 08:23:04 --> URI Class Initialized
INFO - 2023-05-31 08:23:04 --> Router Class Initialized
INFO - 2023-05-31 08:23:04 --> Output Class Initialized
INFO - 2023-05-31 08:23:04 --> Security Class Initialized
INFO - 2023-05-31 08:23:04 --> Input Class Initialized
INFO - 2023-05-31 08:23:04 --> Language Class Initialized
INFO - 2023-05-31 08:23:04 --> Loader Class Initialized
INFO - 2023-05-31 08:23:04 --> Helper loaded: url_helper
INFO - 2023-05-31 08:23:04 --> Helper loaded: form_helper
INFO - 2023-05-31 08:23:04 --> Database Driver Class Initialized
INFO - 2023-05-31 08:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:23:04 --> Form Validation Class Initialized
INFO - 2023-05-31 08:23:04 --> Controller Class Initialized
INFO - 2023-05-31 08:23:04 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:23:04 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:23:04 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:23:04 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:23:04 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:23:04 --> Final output sent to browser
INFO - 2023-05-31 08:30:56 --> Config Class Initialized
INFO - 2023-05-31 08:30:56 --> Hooks Class Initialized
INFO - 2023-05-31 08:30:56 --> Utf8 Class Initialized
INFO - 2023-05-31 08:30:56 --> URI Class Initialized
INFO - 2023-05-31 08:30:56 --> Router Class Initialized
INFO - 2023-05-31 08:30:56 --> Output Class Initialized
INFO - 2023-05-31 08:30:56 --> Security Class Initialized
INFO - 2023-05-31 08:30:56 --> Input Class Initialized
INFO - 2023-05-31 08:30:56 --> Language Class Initialized
INFO - 2023-05-31 08:30:56 --> Loader Class Initialized
INFO - 2023-05-31 08:30:56 --> Helper loaded: url_helper
INFO - 2023-05-31 08:30:56 --> Helper loaded: form_helper
INFO - 2023-05-31 08:30:56 --> Database Driver Class Initialized
INFO - 2023-05-31 08:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:30:56 --> Form Validation Class Initialized
INFO - 2023-05-31 08:30:56 --> Controller Class Initialized
INFO - 2023-05-31 08:30:56 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:30:56 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:30:56 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:30:56 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:30:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:30:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:30:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:30:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:30:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:30:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:30:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:30:56 --> Final output sent to browser
INFO - 2023-05-31 08:39:22 --> Config Class Initialized
INFO - 2023-05-31 08:39:22 --> Hooks Class Initialized
INFO - 2023-05-31 08:39:22 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:22 --> URI Class Initialized
INFO - 2023-05-31 08:39:22 --> Router Class Initialized
INFO - 2023-05-31 08:39:22 --> Output Class Initialized
INFO - 2023-05-31 08:39:22 --> Security Class Initialized
INFO - 2023-05-31 08:39:22 --> Input Class Initialized
INFO - 2023-05-31 08:39:22 --> Language Class Initialized
INFO - 2023-05-31 08:39:22 --> Loader Class Initialized
INFO - 2023-05-31 08:39:22 --> Helper loaded: url_helper
INFO - 2023-05-31 08:39:22 --> Helper loaded: form_helper
INFO - 2023-05-31 08:39:22 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:39:22 --> Form Validation Class Initialized
INFO - 2023-05-31 08:39:22 --> Controller Class Initialized
INFO - 2023-05-31 08:39:22 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:39:22 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:39:22 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:39:22 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:39:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:39:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-31 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 30
ERROR - 2023-05-31 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-31 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 88
ERROR - 2023-05-31 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 135
INFO - 2023-05-31 08:39:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:39:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:39:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:39:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:39:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:39:22 --> Final output sent to browser
INFO - 2023-05-31 08:39:52 --> Config Class Initialized
INFO - 2023-05-31 08:39:52 --> Hooks Class Initialized
INFO - 2023-05-31 08:39:52 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:52 --> URI Class Initialized
INFO - 2023-05-31 08:39:52 --> Router Class Initialized
INFO - 2023-05-31 08:39:52 --> Output Class Initialized
INFO - 2023-05-31 08:39:52 --> Security Class Initialized
INFO - 2023-05-31 08:39:52 --> Input Class Initialized
INFO - 2023-05-31 08:39:52 --> Language Class Initialized
INFO - 2023-05-31 08:39:52 --> Loader Class Initialized
INFO - 2023-05-31 08:39:52 --> Helper loaded: url_helper
INFO - 2023-05-31 08:39:52 --> Helper loaded: form_helper
INFO - 2023-05-31 08:39:52 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:39:52 --> Form Validation Class Initialized
INFO - 2023-05-31 08:39:52 --> Controller Class Initialized
INFO - 2023-05-31 08:39:52 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:39:52 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:39:52 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:39:52 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:39:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:39:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-31 08:39:52 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-31 08:39:52 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 88
ERROR - 2023-05-31 08:39:52 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 135
INFO - 2023-05-31 08:39:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:39:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:39:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:39:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:39:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:39:52 --> Final output sent to browser
INFO - 2023-05-31 08:41:06 --> Config Class Initialized
INFO - 2023-05-31 08:41:06 --> Hooks Class Initialized
INFO - 2023-05-31 08:41:07 --> Utf8 Class Initialized
INFO - 2023-05-31 08:41:07 --> URI Class Initialized
INFO - 2023-05-31 08:41:07 --> Router Class Initialized
INFO - 2023-05-31 08:41:07 --> Output Class Initialized
INFO - 2023-05-31 08:41:07 --> Security Class Initialized
INFO - 2023-05-31 08:41:07 --> Input Class Initialized
INFO - 2023-05-31 08:41:07 --> Language Class Initialized
INFO - 2023-05-31 08:41:07 --> Loader Class Initialized
INFO - 2023-05-31 08:41:07 --> Helper loaded: url_helper
INFO - 2023-05-31 08:41:07 --> Helper loaded: form_helper
INFO - 2023-05-31 08:41:07 --> Database Driver Class Initialized
INFO - 2023-05-31 08:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:41:07 --> Form Validation Class Initialized
INFO - 2023-05-31 08:41:07 --> Controller Class Initialized
INFO - 2023-05-31 08:41:07 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:41:07 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:41:07 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:41:07 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-31 08:41:07 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-31 08:41:07 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 88
ERROR - 2023-05-31 08:41:07 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 135
INFO - 2023-05-31 08:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:41:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:41:07 --> Final output sent to browser
INFO - 2023-05-31 08:45:51 --> Config Class Initialized
INFO - 2023-05-31 08:45:51 --> Hooks Class Initialized
INFO - 2023-05-31 08:45:51 --> Utf8 Class Initialized
INFO - 2023-05-31 08:45:51 --> URI Class Initialized
INFO - 2023-05-31 08:45:51 --> Router Class Initialized
INFO - 2023-05-31 08:45:51 --> Output Class Initialized
INFO - 2023-05-31 08:45:51 --> Security Class Initialized
INFO - 2023-05-31 08:45:51 --> Input Class Initialized
INFO - 2023-05-31 08:45:51 --> Language Class Initialized
INFO - 2023-05-31 08:45:51 --> Loader Class Initialized
INFO - 2023-05-31 08:45:51 --> Helper loaded: url_helper
INFO - 2023-05-31 08:45:51 --> Helper loaded: form_helper
INFO - 2023-05-31 08:45:51 --> Database Driver Class Initialized
INFO - 2023-05-31 08:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:45:52 --> Form Validation Class Initialized
INFO - 2023-05-31 08:45:52 --> Controller Class Initialized
INFO - 2023-05-31 08:45:52 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:45:52 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:45:52 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:45:52 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:45:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:45:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-31 08:45:52 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 28
INFO - 2023-05-31 08:46:05 --> Config Class Initialized
INFO - 2023-05-31 08:46:05 --> Hooks Class Initialized
INFO - 2023-05-31 08:46:05 --> Utf8 Class Initialized
INFO - 2023-05-31 08:46:05 --> URI Class Initialized
INFO - 2023-05-31 08:46:05 --> Router Class Initialized
INFO - 2023-05-31 08:46:05 --> Output Class Initialized
INFO - 2023-05-31 08:46:05 --> Security Class Initialized
INFO - 2023-05-31 08:46:05 --> Input Class Initialized
INFO - 2023-05-31 08:46:05 --> Language Class Initialized
INFO - 2023-05-31 08:46:05 --> Loader Class Initialized
INFO - 2023-05-31 08:46:05 --> Helper loaded: url_helper
INFO - 2023-05-31 08:46:05 --> Helper loaded: form_helper
INFO - 2023-05-31 08:46:05 --> Database Driver Class Initialized
INFO - 2023-05-31 08:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:46:05 --> Form Validation Class Initialized
INFO - 2023-05-31 08:46:05 --> Controller Class Initialized
INFO - 2023-05-31 08:46:05 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:46:05 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:46:05 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:46:05 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:46:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:46:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-31 08:46:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 27
ERROR - 2023-05-31 08:46:05 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 57
ERROR - 2023-05-31 08:46:05 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 89
ERROR - 2023-05-31 08:46:05 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 136
INFO - 2023-05-31 08:46:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:46:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:46:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:46:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:46:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:46:05 --> Final output sent to browser
INFO - 2023-05-31 08:47:06 --> Config Class Initialized
INFO - 2023-05-31 08:47:06 --> Hooks Class Initialized
INFO - 2023-05-31 08:47:06 --> Utf8 Class Initialized
INFO - 2023-05-31 08:47:06 --> URI Class Initialized
INFO - 2023-05-31 08:47:06 --> Router Class Initialized
INFO - 2023-05-31 08:47:06 --> Output Class Initialized
INFO - 2023-05-31 08:47:06 --> Security Class Initialized
INFO - 2023-05-31 08:47:06 --> Input Class Initialized
INFO - 2023-05-31 08:47:06 --> Language Class Initialized
INFO - 2023-05-31 08:47:06 --> Loader Class Initialized
INFO - 2023-05-31 08:47:06 --> Helper loaded: url_helper
INFO - 2023-05-31 08:47:06 --> Helper loaded: form_helper
INFO - 2023-05-31 08:47:06 --> Database Driver Class Initialized
INFO - 2023-05-31 08:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:47:06 --> Form Validation Class Initialized
INFO - 2023-05-31 08:47:06 --> Controller Class Initialized
INFO - 2023-05-31 08:47:06 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:47:06 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:47:06 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:47:06 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:47:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:47:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-31 08:47:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 27
ERROR - 2023-05-31 08:47:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 28
ERROR - 2023-05-31 08:47:06 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 57
ERROR - 2023-05-31 08:47:06 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 89
ERROR - 2023-05-31 08:47:06 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 136
INFO - 2023-05-31 08:47:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:47:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:47:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:47:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:47:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:47:06 --> Final output sent to browser
INFO - 2023-05-31 08:56:20 --> Config Class Initialized
INFO - 2023-05-31 08:56:20 --> Hooks Class Initialized
INFO - 2023-05-31 08:56:20 --> Utf8 Class Initialized
INFO - 2023-05-31 08:56:20 --> URI Class Initialized
INFO - 2023-05-31 08:56:20 --> Router Class Initialized
INFO - 2023-05-31 08:56:20 --> Output Class Initialized
INFO - 2023-05-31 08:56:20 --> Security Class Initialized
INFO - 2023-05-31 08:56:20 --> Input Class Initialized
INFO - 2023-05-31 08:56:20 --> Language Class Initialized
INFO - 2023-05-31 08:56:20 --> Loader Class Initialized
INFO - 2023-05-31 08:56:20 --> Helper loaded: url_helper
INFO - 2023-05-31 08:56:20 --> Helper loaded: form_helper
INFO - 2023-05-31 08:56:20 --> Database Driver Class Initialized
INFO - 2023-05-31 08:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:56:20 --> Form Validation Class Initialized
INFO - 2023-05-31 08:56:20 --> Controller Class Initialized
INFO - 2023-05-31 08:56:20 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:56:20 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:56:20 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:56:20 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:56:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:56:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-05-31 08:56:20 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 30
ERROR - 2023-05-31 08:56:20 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 56
ERROR - 2023-05-31 08:56:20 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 88
ERROR - 2023-05-31 08:56:20 --> Severity: Notice --> Undefined property: stdClass::$solusi1 C:\xampp\htdocs\sistemdiagnosa\application\views\test.php 135
INFO - 2023-05-31 08:56:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:56:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:56:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:56:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:56:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:56:20 --> Final output sent to browser
INFO - 2023-05-31 08:57:02 --> Config Class Initialized
INFO - 2023-05-31 08:57:02 --> Hooks Class Initialized
INFO - 2023-05-31 08:57:02 --> Utf8 Class Initialized
INFO - 2023-05-31 08:57:02 --> URI Class Initialized
INFO - 2023-05-31 08:57:02 --> Router Class Initialized
INFO - 2023-05-31 08:57:02 --> Output Class Initialized
INFO - 2023-05-31 08:57:02 --> Security Class Initialized
INFO - 2023-05-31 08:57:02 --> Input Class Initialized
INFO - 2023-05-31 08:57:02 --> Language Class Initialized
INFO - 2023-05-31 08:57:02 --> Loader Class Initialized
INFO - 2023-05-31 08:57:02 --> Helper loaded: url_helper
INFO - 2023-05-31 08:57:02 --> Helper loaded: form_helper
INFO - 2023-05-31 08:57:02 --> Database Driver Class Initialized
INFO - 2023-05-31 08:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 08:57:02 --> Form Validation Class Initialized
INFO - 2023-05-31 08:57:02 --> Controller Class Initialized
INFO - 2023-05-31 08:57:02 --> Model "m_datatrain" initialized
INFO - 2023-05-31 08:57:02 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 08:57:02 --> Model "m_datatest" initialized
INFO - 2023-05-31 08:57:02 --> Model "M_solusi" initialized
INFO - 2023-05-31 08:57:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 08:57:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 08:57:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 08:57:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 08:57:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 08:57:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 08:57:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 08:57:02 --> Final output sent to browser
INFO - 2023-05-31 13:47:00 --> Config Class Initialized
INFO - 2023-05-31 13:47:00 --> Hooks Class Initialized
INFO - 2023-05-31 13:47:00 --> Utf8 Class Initialized
INFO - 2023-05-31 13:47:00 --> URI Class Initialized
INFO - 2023-05-31 13:47:00 --> Router Class Initialized
INFO - 2023-05-31 13:47:00 --> Output Class Initialized
INFO - 2023-05-31 13:47:00 --> Security Class Initialized
INFO - 2023-05-31 13:47:00 --> Input Class Initialized
INFO - 2023-05-31 13:47:00 --> Language Class Initialized
INFO - 2023-05-31 13:47:00 --> Loader Class Initialized
INFO - 2023-05-31 13:47:00 --> Helper loaded: url_helper
INFO - 2023-05-31 13:47:00 --> Helper loaded: form_helper
INFO - 2023-05-31 13:47:00 --> Database Driver Class Initialized
INFO - 2023-05-31 13:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 13:47:00 --> Form Validation Class Initialized
INFO - 2023-05-31 13:47:00 --> Controller Class Initialized
INFO - 2023-05-31 13:47:00 --> Model "m_datatrain" initialized
INFO - 2023-05-31 13:47:00 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 13:47:00 --> Model "m_datatest" initialized
INFO - 2023-05-31 13:47:00 --> Model "M_solusi" initialized
INFO - 2023-05-31 13:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 13:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 13:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 13:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 13:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 13:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 13:47:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 13:47:00 --> Final output sent to browser
INFO - 2023-05-31 13:47:43 --> Config Class Initialized
INFO - 2023-05-31 13:47:43 --> Hooks Class Initialized
INFO - 2023-05-31 13:47:43 --> Utf8 Class Initialized
INFO - 2023-05-31 13:47:43 --> URI Class Initialized
INFO - 2023-05-31 13:47:43 --> Router Class Initialized
INFO - 2023-05-31 13:47:43 --> Output Class Initialized
INFO - 2023-05-31 13:47:43 --> Security Class Initialized
INFO - 2023-05-31 13:47:43 --> Input Class Initialized
INFO - 2023-05-31 13:47:43 --> Language Class Initialized
INFO - 2023-05-31 13:47:43 --> Loader Class Initialized
INFO - 2023-05-31 13:47:43 --> Helper loaded: url_helper
INFO - 2023-05-31 13:47:43 --> Helper loaded: form_helper
INFO - 2023-05-31 13:47:43 --> Database Driver Class Initialized
INFO - 2023-05-31 13:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 13:47:43 --> Form Validation Class Initialized
INFO - 2023-05-31 13:47:43 --> Controller Class Initialized
INFO - 2023-05-31 13:47:43 --> Model "m_datatrain" initialized
INFO - 2023-05-31 13:47:43 --> Model "m_penghitungan" initialized
INFO - 2023-05-31 13:47:43 --> Model "m_datatest" initialized
INFO - 2023-05-31 13:47:43 --> Model "M_solusi" initialized
INFO - 2023-05-31 13:47:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-31 13:47:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-31 13:47:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\test.php
INFO - 2023-05-31 13:47:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-31 13:47:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-31 13:47:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-31 13:47:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-31 13:47:43 --> Final output sent to browser
