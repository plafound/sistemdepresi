<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-12 06:24:35 --> Config Class Initialized
INFO - 2023-05-12 06:24:35 --> Hooks Class Initialized
INFO - 2023-05-12 06:24:35 --> Utf8 Class Initialized
INFO - 2023-05-12 06:24:35 --> URI Class Initialized
INFO - 2023-05-12 06:24:35 --> Router Class Initialized
INFO - 2023-05-12 06:24:35 --> Output Class Initialized
INFO - 2023-05-12 06:24:35 --> Security Class Initialized
INFO - 2023-05-12 06:24:35 --> Input Class Initialized
INFO - 2023-05-12 06:24:35 --> Language Class Initialized
INFO - 2023-05-12 06:24:35 --> Loader Class Initialized
INFO - 2023-05-12 06:24:35 --> Helper loaded: url_helper
INFO - 2023-05-12 06:24:35 --> Helper loaded: form_helper
INFO - 2023-05-12 06:24:36 --> Database Driver Class Initialized
INFO - 2023-05-12 06:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:24:36 --> Form Validation Class Initialized
INFO - 2023-05-12 06:24:36 --> Controller Class Initialized
INFO - 2023-05-12 06:24:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-12 06:24:36 --> Final output sent to browser
INFO - 2023-05-12 06:24:52 --> Config Class Initialized
INFO - 2023-05-12 06:24:52 --> Hooks Class Initialized
INFO - 2023-05-12 06:24:52 --> Utf8 Class Initialized
INFO - 2023-05-12 06:24:52 --> URI Class Initialized
INFO - 2023-05-12 06:24:52 --> Router Class Initialized
INFO - 2023-05-12 06:24:52 --> Output Class Initialized
INFO - 2023-05-12 06:24:52 --> Security Class Initialized
INFO - 2023-05-12 06:24:52 --> Input Class Initialized
INFO - 2023-05-12 06:24:52 --> Language Class Initialized
INFO - 2023-05-12 06:24:52 --> Loader Class Initialized
INFO - 2023-05-12 06:24:52 --> Helper loaded: url_helper
INFO - 2023-05-12 06:24:52 --> Helper loaded: form_helper
INFO - 2023-05-12 06:24:52 --> Database Driver Class Initialized
INFO - 2023-05-12 06:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:24:52 --> Form Validation Class Initialized
INFO - 2023-05-12 06:24:52 --> Controller Class Initialized
INFO - 2023-05-12 06:24:52 --> Model "m_user" initialized
INFO - 2023-05-12 06:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-12 06:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-12 06:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-12 06:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-12 06:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-12 06:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-12 06:24:52 --> Final output sent to browser
INFO - 2023-05-12 06:25:19 --> Config Class Initialized
INFO - 2023-05-12 06:25:19 --> Hooks Class Initialized
INFO - 2023-05-12 06:25:19 --> Utf8 Class Initialized
INFO - 2023-05-12 06:25:20 --> URI Class Initialized
INFO - 2023-05-12 06:25:20 --> Router Class Initialized
INFO - 2023-05-12 06:25:20 --> Output Class Initialized
INFO - 2023-05-12 06:25:20 --> Security Class Initialized
INFO - 2023-05-12 06:25:20 --> Input Class Initialized
INFO - 2023-05-12 06:25:20 --> Language Class Initialized
INFO - 2023-05-12 06:25:20 --> Loader Class Initialized
INFO - 2023-05-12 06:25:20 --> Helper loaded: url_helper
INFO - 2023-05-12 06:25:20 --> Helper loaded: form_helper
INFO - 2023-05-12 06:25:20 --> Database Driver Class Initialized
INFO - 2023-05-12 06:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:25:20 --> Form Validation Class Initialized
INFO - 2023-05-12 06:25:20 --> Controller Class Initialized
INFO - 2023-05-12 06:25:20 --> Model "m_datatrain" initialized
INFO - 2023-05-12 06:25:20 --> Model "m_datatest" initialized
INFO - 2023-05-12 06:25:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-12 06:25:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-12 06:25:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-12 06:25:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-12 06:25:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-12 06:25:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-12 06:25:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-12 06:25:20 --> Final output sent to browser
INFO - 2023-05-12 06:26:10 --> Config Class Initialized
INFO - 2023-05-12 06:26:10 --> Hooks Class Initialized
INFO - 2023-05-12 06:26:10 --> Utf8 Class Initialized
INFO - 2023-05-12 06:26:10 --> URI Class Initialized
INFO - 2023-05-12 06:26:10 --> Router Class Initialized
INFO - 2023-05-12 06:26:10 --> Output Class Initialized
INFO - 2023-05-12 06:26:10 --> Security Class Initialized
INFO - 2023-05-12 06:26:10 --> Input Class Initialized
INFO - 2023-05-12 06:26:10 --> Language Class Initialized
INFO - 2023-05-12 06:26:10 --> Loader Class Initialized
INFO - 2023-05-12 06:26:10 --> Helper loaded: url_helper
INFO - 2023-05-12 06:26:10 --> Helper loaded: form_helper
INFO - 2023-05-12 06:26:10 --> Database Driver Class Initialized
INFO - 2023-05-12 06:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:26:10 --> Form Validation Class Initialized
INFO - 2023-05-12 06:26:10 --> Controller Class Initialized
INFO - 2023-05-12 06:26:10 --> Model "m_user" initialized
INFO - 2023-05-12 06:26:10 --> Model "m_datatrain" initialized
INFO - 2023-05-12 06:26:10 --> Config Class Initialized
INFO - 2023-05-12 06:26:10 --> Hooks Class Initialized
INFO - 2023-05-12 06:26:10 --> Utf8 Class Initialized
INFO - 2023-05-12 06:26:10 --> URI Class Initialized
INFO - 2023-05-12 06:26:10 --> Router Class Initialized
INFO - 2023-05-12 06:26:10 --> Output Class Initialized
INFO - 2023-05-12 06:26:10 --> Security Class Initialized
INFO - 2023-05-12 06:26:10 --> Input Class Initialized
INFO - 2023-05-12 06:26:10 --> Language Class Initialized
INFO - 2023-05-12 06:26:10 --> Loader Class Initialized
INFO - 2023-05-12 06:26:10 --> Helper loaded: url_helper
INFO - 2023-05-12 06:26:10 --> Helper loaded: form_helper
INFO - 2023-05-12 06:26:10 --> Database Driver Class Initialized
INFO - 2023-05-12 06:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:26:10 --> Form Validation Class Initialized
INFO - 2023-05-12 06:26:10 --> Controller Class Initialized
INFO - 2023-05-12 06:26:10 --> Model "m_user" initialized
INFO - 2023-05-12 06:26:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-12 06:26:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-12 06:26:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-12 06:26:10 --> Final output sent to browser
INFO - 2023-05-12 06:26:18 --> Config Class Initialized
INFO - 2023-05-12 06:26:18 --> Hooks Class Initialized
INFO - 2023-05-12 06:26:18 --> Utf8 Class Initialized
INFO - 2023-05-12 06:26:18 --> URI Class Initialized
INFO - 2023-05-12 06:26:18 --> Router Class Initialized
INFO - 2023-05-12 06:26:18 --> Output Class Initialized
INFO - 2023-05-12 06:26:18 --> Security Class Initialized
INFO - 2023-05-12 06:26:18 --> Input Class Initialized
INFO - 2023-05-12 06:26:18 --> Language Class Initialized
INFO - 2023-05-12 06:26:18 --> Loader Class Initialized
INFO - 2023-05-12 06:26:18 --> Helper loaded: url_helper
INFO - 2023-05-12 06:26:18 --> Helper loaded: form_helper
INFO - 2023-05-12 06:26:18 --> Database Driver Class Initialized
INFO - 2023-05-12 06:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:26:18 --> Form Validation Class Initialized
INFO - 2023-05-12 06:26:18 --> Controller Class Initialized
INFO - 2023-05-12 06:26:18 --> Model "m_user" initialized
INFO - 2023-05-12 06:26:18 --> Config Class Initialized
INFO - 2023-05-12 06:26:18 --> Hooks Class Initialized
INFO - 2023-05-12 06:26:18 --> Utf8 Class Initialized
INFO - 2023-05-12 06:26:18 --> URI Class Initialized
INFO - 2023-05-12 06:26:18 --> Router Class Initialized
INFO - 2023-05-12 06:26:18 --> Output Class Initialized
INFO - 2023-05-12 06:26:18 --> Security Class Initialized
INFO - 2023-05-12 06:26:18 --> Input Class Initialized
INFO - 2023-05-12 06:26:18 --> Language Class Initialized
INFO - 2023-05-12 06:26:18 --> Loader Class Initialized
INFO - 2023-05-12 06:26:18 --> Helper loaded: url_helper
INFO - 2023-05-12 06:26:18 --> Helper loaded: form_helper
INFO - 2023-05-12 06:26:18 --> Database Driver Class Initialized
INFO - 2023-05-12 06:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:26:18 --> Form Validation Class Initialized
INFO - 2023-05-12 06:26:18 --> Controller Class Initialized
INFO - 2023-05-12 06:26:18 --> Model "m_user" initialized
INFO - 2023-05-12 06:26:18 --> Model "m_datatrain" initialized
INFO - 2023-05-12 06:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-12 06:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-12 06:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-12 06:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-12 06:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-12 06:26:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-12 06:26:18 --> Final output sent to browser
INFO - 2023-05-12 06:26:22 --> Config Class Initialized
INFO - 2023-05-12 06:26:22 --> Hooks Class Initialized
INFO - 2023-05-12 06:26:22 --> Utf8 Class Initialized
INFO - 2023-05-12 06:26:22 --> URI Class Initialized
INFO - 2023-05-12 06:26:22 --> Router Class Initialized
INFO - 2023-05-12 06:26:22 --> Output Class Initialized
INFO - 2023-05-12 06:26:22 --> Security Class Initialized
INFO - 2023-05-12 06:26:22 --> Input Class Initialized
INFO - 2023-05-12 06:26:22 --> Language Class Initialized
INFO - 2023-05-12 06:26:22 --> Loader Class Initialized
INFO - 2023-05-12 06:26:22 --> Helper loaded: url_helper
INFO - 2023-05-12 06:26:22 --> Helper loaded: form_helper
INFO - 2023-05-12 06:26:22 --> Database Driver Class Initialized
INFO - 2023-05-12 06:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:26:22 --> Form Validation Class Initialized
INFO - 2023-05-12 06:26:22 --> Controller Class Initialized
INFO - 2023-05-12 06:26:22 --> Model "m_datatrain" initialized
INFO - 2023-05-12 06:26:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-12 06:26:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-12 06:26:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-12 06:26:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-12 06:26:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-12 06:26:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-12 06:26:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-12 06:26:22 --> Final output sent to browser
INFO - 2023-05-12 06:26:26 --> Config Class Initialized
INFO - 2023-05-12 06:26:26 --> Hooks Class Initialized
INFO - 2023-05-12 06:26:26 --> Utf8 Class Initialized
INFO - 2023-05-12 06:26:26 --> URI Class Initialized
INFO - 2023-05-12 06:26:26 --> Router Class Initialized
INFO - 2023-05-12 06:26:26 --> Output Class Initialized
INFO - 2023-05-12 06:26:26 --> Security Class Initialized
INFO - 2023-05-12 06:26:26 --> Input Class Initialized
INFO - 2023-05-12 06:26:26 --> Language Class Initialized
INFO - 2023-05-12 06:26:26 --> Loader Class Initialized
INFO - 2023-05-12 06:26:26 --> Helper loaded: url_helper
INFO - 2023-05-12 06:26:26 --> Helper loaded: form_helper
INFO - 2023-05-12 06:26:26 --> Database Driver Class Initialized
INFO - 2023-05-12 06:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:26:26 --> Form Validation Class Initialized
INFO - 2023-05-12 06:26:26 --> Controller Class Initialized
INFO - 2023-05-12 06:26:27 --> Model "m_datatrain" initialized
INFO - 2023-05-12 06:26:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-12 06:26:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-12 06:26:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-05-12 06:26:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-12 06:26:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-12 06:26:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-12 06:26:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-05-12 06:26:27 --> Final output sent to browser
INFO - 2023-05-12 06:26:40 --> Config Class Initialized
INFO - 2023-05-12 06:26:40 --> Hooks Class Initialized
INFO - 2023-05-12 06:26:40 --> Utf8 Class Initialized
INFO - 2023-05-12 06:26:40 --> URI Class Initialized
INFO - 2023-05-12 06:26:40 --> Router Class Initialized
INFO - 2023-05-12 06:26:40 --> Output Class Initialized
INFO - 2023-05-12 06:26:40 --> Security Class Initialized
INFO - 2023-05-12 06:26:40 --> Input Class Initialized
INFO - 2023-05-12 06:26:40 --> Language Class Initialized
INFO - 2023-05-12 06:26:40 --> Loader Class Initialized
INFO - 2023-05-12 06:26:40 --> Helper loaded: url_helper
INFO - 2023-05-12 06:26:40 --> Helper loaded: form_helper
INFO - 2023-05-12 06:26:40 --> Database Driver Class Initialized
INFO - 2023-05-12 06:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:26:40 --> Form Validation Class Initialized
INFO - 2023-05-12 06:26:40 --> Controller Class Initialized
INFO - 2023-05-12 06:26:40 --> Model "m_user" initialized
INFO - 2023-05-12 06:26:40 --> Config Class Initialized
INFO - 2023-05-12 06:26:40 --> Hooks Class Initialized
INFO - 2023-05-12 06:26:40 --> Utf8 Class Initialized
INFO - 2023-05-12 06:26:40 --> URI Class Initialized
INFO - 2023-05-12 06:26:40 --> Router Class Initialized
INFO - 2023-05-12 06:26:40 --> Output Class Initialized
INFO - 2023-05-12 06:26:40 --> Security Class Initialized
INFO - 2023-05-12 06:26:40 --> Input Class Initialized
INFO - 2023-05-12 06:26:40 --> Language Class Initialized
INFO - 2023-05-12 06:26:40 --> Loader Class Initialized
INFO - 2023-05-12 06:26:40 --> Helper loaded: url_helper
INFO - 2023-05-12 06:26:40 --> Helper loaded: form_helper
INFO - 2023-05-12 06:26:40 --> Database Driver Class Initialized
INFO - 2023-05-12 06:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:26:40 --> Form Validation Class Initialized
INFO - 2023-05-12 06:26:40 --> Controller Class Initialized
INFO - 2023-05-12 06:26:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-12 06:26:40 --> Final output sent to browser
INFO - 2023-05-12 06:28:37 --> Config Class Initialized
INFO - 2023-05-12 06:28:37 --> Hooks Class Initialized
INFO - 2023-05-12 06:28:37 --> Utf8 Class Initialized
INFO - 2023-05-12 06:28:37 --> URI Class Initialized
INFO - 2023-05-12 06:28:37 --> Router Class Initialized
INFO - 2023-05-12 06:28:37 --> Output Class Initialized
INFO - 2023-05-12 06:28:37 --> Security Class Initialized
INFO - 2023-05-12 06:28:37 --> Input Class Initialized
INFO - 2023-05-12 06:28:37 --> Language Class Initialized
INFO - 2023-05-12 06:28:37 --> Loader Class Initialized
INFO - 2023-05-12 06:28:37 --> Helper loaded: url_helper
INFO - 2023-05-12 06:28:37 --> Helper loaded: form_helper
INFO - 2023-05-12 06:28:37 --> Database Driver Class Initialized
INFO - 2023-05-12 06:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:28:37 --> Form Validation Class Initialized
INFO - 2023-05-12 06:28:37 --> Controller Class Initialized
INFO - 2023-05-12 06:28:37 --> Model "m_user" initialized
INFO - 2023-05-12 06:28:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-12 06:28:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-12 06:28:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-12 06:28:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-12 06:28:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-12 06:28:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-05-12 06:28:37 --> Final output sent to browser
INFO - 2023-05-12 06:28:50 --> Config Class Initialized
INFO - 2023-05-12 06:28:50 --> Hooks Class Initialized
INFO - 2023-05-12 06:28:50 --> Utf8 Class Initialized
INFO - 2023-05-12 06:28:50 --> URI Class Initialized
INFO - 2023-05-12 06:28:50 --> Router Class Initialized
INFO - 2023-05-12 06:28:50 --> Output Class Initialized
INFO - 2023-05-12 06:28:50 --> Security Class Initialized
INFO - 2023-05-12 06:28:50 --> Input Class Initialized
INFO - 2023-05-12 06:28:50 --> Language Class Initialized
INFO - 2023-05-12 06:28:50 --> Loader Class Initialized
INFO - 2023-05-12 06:28:50 --> Helper loaded: url_helper
INFO - 2023-05-12 06:28:50 --> Helper loaded: form_helper
INFO - 2023-05-12 06:28:50 --> Database Driver Class Initialized
INFO - 2023-05-12 06:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:28:50 --> Form Validation Class Initialized
INFO - 2023-05-12 06:28:50 --> Controller Class Initialized
INFO - 2023-05-12 06:28:50 --> Model "m_datatrain" initialized
INFO - 2023-05-12 06:28:50 --> Model "m_datatest" initialized
INFO - 2023-05-12 06:28:50 --> Final output sent to browser
INFO - 2023-05-12 06:29:16 --> Config Class Initialized
INFO - 2023-05-12 06:29:16 --> Hooks Class Initialized
INFO - 2023-05-12 06:29:16 --> Utf8 Class Initialized
INFO - 2023-05-12 06:29:16 --> URI Class Initialized
INFO - 2023-05-12 06:29:16 --> Router Class Initialized
INFO - 2023-05-12 06:29:16 --> Output Class Initialized
INFO - 2023-05-12 06:29:16 --> Security Class Initialized
INFO - 2023-05-12 06:29:16 --> Input Class Initialized
INFO - 2023-05-12 06:29:16 --> Language Class Initialized
INFO - 2023-05-12 06:29:16 --> Loader Class Initialized
INFO - 2023-05-12 06:29:16 --> Helper loaded: url_helper
INFO - 2023-05-12 06:29:16 --> Helper loaded: form_helper
INFO - 2023-05-12 06:29:16 --> Database Driver Class Initialized
INFO - 2023-05-12 06:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:29:16 --> Form Validation Class Initialized
INFO - 2023-05-12 06:29:16 --> Controller Class Initialized
INFO - 2023-05-12 06:29:16 --> Model "m_datatrain" initialized
INFO - 2023-05-12 06:29:16 --> Model "m_datatest" initialized
INFO - 2023-05-12 06:29:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-12 06:29:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-12 06:29:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-05-12 06:29:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-05-12 06:29:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-12 06:29:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-12 06:29:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-05-12 06:29:16 --> Final output sent to browser
INFO - 2023-05-12 06:29:31 --> Config Class Initialized
INFO - 2023-05-12 06:29:31 --> Hooks Class Initialized
INFO - 2023-05-12 06:29:31 --> Utf8 Class Initialized
INFO - 2023-05-12 06:29:31 --> URI Class Initialized
INFO - 2023-05-12 06:29:31 --> Router Class Initialized
INFO - 2023-05-12 06:29:31 --> Output Class Initialized
INFO - 2023-05-12 06:29:31 --> Security Class Initialized
INFO - 2023-05-12 06:29:31 --> Input Class Initialized
INFO - 2023-05-12 06:29:31 --> Language Class Initialized
INFO - 2023-05-12 06:29:31 --> Loader Class Initialized
INFO - 2023-05-12 06:29:31 --> Helper loaded: url_helper
INFO - 2023-05-12 06:29:31 --> Helper loaded: form_helper
INFO - 2023-05-12 06:29:31 --> Database Driver Class Initialized
INFO - 2023-05-12 06:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:29:31 --> Form Validation Class Initialized
INFO - 2023-05-12 06:29:31 --> Controller Class Initialized
INFO - 2023-05-12 06:29:31 --> Model "m_user" initialized
INFO - 2023-05-12 06:29:31 --> Config Class Initialized
INFO - 2023-05-12 06:29:31 --> Hooks Class Initialized
INFO - 2023-05-12 06:29:31 --> Utf8 Class Initialized
INFO - 2023-05-12 06:29:31 --> URI Class Initialized
INFO - 2023-05-12 06:29:31 --> Router Class Initialized
INFO - 2023-05-12 06:29:31 --> Output Class Initialized
INFO - 2023-05-12 06:29:31 --> Security Class Initialized
INFO - 2023-05-12 06:29:31 --> Input Class Initialized
INFO - 2023-05-12 06:29:31 --> Language Class Initialized
INFO - 2023-05-12 06:29:31 --> Loader Class Initialized
INFO - 2023-05-12 06:29:31 --> Helper loaded: url_helper
INFO - 2023-05-12 06:29:31 --> Helper loaded: form_helper
INFO - 2023-05-12 06:29:31 --> Database Driver Class Initialized
INFO - 2023-05-12 06:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:29:31 --> Form Validation Class Initialized
INFO - 2023-05-12 06:29:31 --> Controller Class Initialized
INFO - 2023-05-12 06:29:31 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-12 06:29:31 --> Final output sent to browser
INFO - 2023-05-12 06:29:35 --> Config Class Initialized
INFO - 2023-05-12 06:29:35 --> Hooks Class Initialized
INFO - 2023-05-12 06:29:35 --> Utf8 Class Initialized
INFO - 2023-05-12 06:29:35 --> URI Class Initialized
INFO - 2023-05-12 06:29:35 --> Router Class Initialized
INFO - 2023-05-12 06:29:35 --> Output Class Initialized
INFO - 2023-05-12 06:29:35 --> Security Class Initialized
INFO - 2023-05-12 06:29:35 --> Input Class Initialized
INFO - 2023-05-12 06:29:35 --> Language Class Initialized
INFO - 2023-05-12 06:29:35 --> Loader Class Initialized
INFO - 2023-05-12 06:29:35 --> Helper loaded: url_helper
INFO - 2023-05-12 06:29:35 --> Helper loaded: form_helper
INFO - 2023-05-12 06:29:35 --> Database Driver Class Initialized
INFO - 2023-05-12 06:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:29:35 --> Form Validation Class Initialized
INFO - 2023-05-12 06:29:35 --> Controller Class Initialized
INFO - 2023-05-12 06:29:35 --> Model "m_user" initialized
INFO - 2023-05-12 06:29:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-05-12 06:29:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-05-12 06:29:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-05-12 06:29:35 --> Final output sent to browser
INFO - 2023-05-12 06:29:40 --> Config Class Initialized
INFO - 2023-05-12 06:29:40 --> Hooks Class Initialized
INFO - 2023-05-12 06:29:40 --> Utf8 Class Initialized
INFO - 2023-05-12 06:29:40 --> URI Class Initialized
INFO - 2023-05-12 06:29:40 --> Router Class Initialized
INFO - 2023-05-12 06:29:40 --> Output Class Initialized
INFO - 2023-05-12 06:29:40 --> Security Class Initialized
INFO - 2023-05-12 06:29:40 --> Input Class Initialized
INFO - 2023-05-12 06:29:40 --> Language Class Initialized
INFO - 2023-05-12 06:29:40 --> Loader Class Initialized
INFO - 2023-05-12 06:29:40 --> Helper loaded: url_helper
INFO - 2023-05-12 06:29:40 --> Helper loaded: form_helper
INFO - 2023-05-12 06:29:40 --> Database Driver Class Initialized
INFO - 2023-05-12 06:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:29:40 --> Form Validation Class Initialized
INFO - 2023-05-12 06:29:40 --> Controller Class Initialized
INFO - 2023-05-12 06:29:40 --> Model "m_user" initialized
INFO - 2023-05-12 06:29:40 --> Config Class Initialized
INFO - 2023-05-12 06:29:40 --> Hooks Class Initialized
INFO - 2023-05-12 06:29:40 --> Utf8 Class Initialized
INFO - 2023-05-12 06:29:40 --> URI Class Initialized
INFO - 2023-05-12 06:29:40 --> Router Class Initialized
INFO - 2023-05-12 06:29:40 --> Output Class Initialized
INFO - 2023-05-12 06:29:40 --> Security Class Initialized
INFO - 2023-05-12 06:29:40 --> Input Class Initialized
INFO - 2023-05-12 06:29:40 --> Language Class Initialized
INFO - 2023-05-12 06:29:40 --> Loader Class Initialized
INFO - 2023-05-12 06:29:40 --> Helper loaded: url_helper
INFO - 2023-05-12 06:29:40 --> Helper loaded: form_helper
INFO - 2023-05-12 06:29:40 --> Database Driver Class Initialized
INFO - 2023-05-12 06:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:29:40 --> Form Validation Class Initialized
INFO - 2023-05-12 06:29:40 --> Controller Class Initialized
INFO - 2023-05-12 06:29:40 --> Model "m_user" initialized
INFO - 2023-05-12 06:29:40 --> Model "m_datatrain" initialized
INFO - 2023-05-12 06:29:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-05-12 06:29:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-05-12 06:29:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-05-12 06:29:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-05-12 06:29:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-05-12 06:29:40 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-05-12 06:29:40 --> Final output sent to browser
INFO - 2023-05-12 06:30:05 --> Config Class Initialized
INFO - 2023-05-12 06:30:05 --> Hooks Class Initialized
INFO - 2023-05-12 06:30:05 --> Utf8 Class Initialized
INFO - 2023-05-12 06:30:05 --> URI Class Initialized
INFO - 2023-05-12 06:30:05 --> Router Class Initialized
INFO - 2023-05-12 06:30:05 --> Output Class Initialized
INFO - 2023-05-12 06:30:05 --> Security Class Initialized
INFO - 2023-05-12 06:30:05 --> Input Class Initialized
INFO - 2023-05-12 06:30:05 --> Language Class Initialized
INFO - 2023-05-12 06:30:05 --> Loader Class Initialized
INFO - 2023-05-12 06:30:05 --> Helper loaded: url_helper
INFO - 2023-05-12 06:30:05 --> Helper loaded: form_helper
INFO - 2023-05-12 06:30:05 --> Database Driver Class Initialized
INFO - 2023-05-12 06:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:30:05 --> Form Validation Class Initialized
INFO - 2023-05-12 06:30:05 --> Controller Class Initialized
INFO - 2023-05-12 06:30:05 --> Model "m_user" initialized
INFO - 2023-05-12 06:30:05 --> Config Class Initialized
INFO - 2023-05-12 06:30:05 --> Hooks Class Initialized
INFO - 2023-05-12 06:30:05 --> Utf8 Class Initialized
INFO - 2023-05-12 06:30:05 --> URI Class Initialized
INFO - 2023-05-12 06:30:05 --> Router Class Initialized
INFO - 2023-05-12 06:30:05 --> Output Class Initialized
INFO - 2023-05-12 06:30:05 --> Security Class Initialized
INFO - 2023-05-12 06:30:05 --> Input Class Initialized
INFO - 2023-05-12 06:30:05 --> Language Class Initialized
INFO - 2023-05-12 06:30:05 --> Loader Class Initialized
INFO - 2023-05-12 06:30:05 --> Helper loaded: url_helper
INFO - 2023-05-12 06:30:05 --> Helper loaded: form_helper
INFO - 2023-05-12 06:30:05 --> Database Driver Class Initialized
INFO - 2023-05-12 06:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-12 06:30:05 --> Form Validation Class Initialized
INFO - 2023-05-12 06:30:05 --> Controller Class Initialized
INFO - 2023-05-12 06:30:05 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-05-12 06:30:05 --> Final output sent to browser
