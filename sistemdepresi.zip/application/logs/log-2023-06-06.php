<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-06 08:56:37 --> Config Class Initialized
INFO - 2023-06-06 08:56:37 --> Hooks Class Initialized
INFO - 2023-06-06 08:56:37 --> Utf8 Class Initialized
INFO - 2023-06-06 08:56:37 --> URI Class Initialized
INFO - 2023-06-06 08:56:37 --> Router Class Initialized
INFO - 2023-06-06 08:56:37 --> Output Class Initialized
INFO - 2023-06-06 08:56:37 --> Security Class Initialized
INFO - 2023-06-06 08:56:37 --> Input Class Initialized
INFO - 2023-06-06 08:56:37 --> Language Class Initialized
INFO - 2023-06-06 08:56:37 --> Loader Class Initialized
INFO - 2023-06-06 08:56:37 --> Helper loaded: url_helper
INFO - 2023-06-06 08:56:38 --> Helper loaded: form_helper
INFO - 2023-06-06 08:56:38 --> Database Driver Class Initialized
INFO - 2023-06-06 08:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 08:56:38 --> Form Validation Class Initialized
INFO - 2023-06-06 08:56:38 --> Controller Class Initialized
INFO - 2023-06-06 08:56:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-06 08:56:38 --> Final output sent to browser
INFO - 2023-06-06 09:10:41 --> Config Class Initialized
INFO - 2023-06-06 09:10:41 --> Hooks Class Initialized
INFO - 2023-06-06 09:10:41 --> Utf8 Class Initialized
INFO - 2023-06-06 09:10:41 --> URI Class Initialized
INFO - 2023-06-06 09:10:41 --> Router Class Initialized
INFO - 2023-06-06 09:10:41 --> Output Class Initialized
INFO - 2023-06-06 09:10:41 --> Security Class Initialized
INFO - 2023-06-06 09:10:41 --> Input Class Initialized
INFO - 2023-06-06 09:10:41 --> Language Class Initialized
INFO - 2023-06-06 09:10:41 --> Loader Class Initialized
INFO - 2023-06-06 09:10:41 --> Helper loaded: url_helper
INFO - 2023-06-06 09:10:41 --> Helper loaded: form_helper
INFO - 2023-06-06 09:10:41 --> Database Driver Class Initialized
INFO - 2023-06-06 09:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:10:41 --> Form Validation Class Initialized
INFO - 2023-06-06 09:10:41 --> Controller Class Initialized
INFO - 2023-06-06 09:10:41 --> Model "m_user" initialized
INFO - 2023-06-06 09:10:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-06 09:10:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-06 09:10:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-06 09:10:41 --> Final output sent to browser
INFO - 2023-06-06 09:10:44 --> Config Class Initialized
INFO - 2023-06-06 09:10:44 --> Hooks Class Initialized
INFO - 2023-06-06 09:10:44 --> Utf8 Class Initialized
INFO - 2023-06-06 09:10:44 --> URI Class Initialized
INFO - 2023-06-06 09:10:44 --> Router Class Initialized
INFO - 2023-06-06 09:10:44 --> Output Class Initialized
INFO - 2023-06-06 09:10:44 --> Security Class Initialized
INFO - 2023-06-06 09:10:44 --> Input Class Initialized
INFO - 2023-06-06 09:10:44 --> Language Class Initialized
INFO - 2023-06-06 09:10:44 --> Loader Class Initialized
INFO - 2023-06-06 09:10:44 --> Helper loaded: url_helper
INFO - 2023-06-06 09:10:44 --> Helper loaded: form_helper
INFO - 2023-06-06 09:10:44 --> Database Driver Class Initialized
INFO - 2023-06-06 09:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:10:44 --> Form Validation Class Initialized
INFO - 2023-06-06 09:10:44 --> Controller Class Initialized
INFO - 2023-06-06 09:10:44 --> Model "m_user" initialized
INFO - 2023-06-06 09:10:45 --> Config Class Initialized
INFO - 2023-06-06 09:10:45 --> Hooks Class Initialized
INFO - 2023-06-06 09:10:45 --> Utf8 Class Initialized
INFO - 2023-06-06 09:10:45 --> URI Class Initialized
INFO - 2023-06-06 09:10:45 --> Router Class Initialized
INFO - 2023-06-06 09:10:45 --> Output Class Initialized
INFO - 2023-06-06 09:10:45 --> Security Class Initialized
INFO - 2023-06-06 09:10:45 --> Input Class Initialized
INFO - 2023-06-06 09:10:45 --> Language Class Initialized
INFO - 2023-06-06 09:10:45 --> Loader Class Initialized
INFO - 2023-06-06 09:10:45 --> Helper loaded: url_helper
INFO - 2023-06-06 09:10:45 --> Helper loaded: form_helper
INFO - 2023-06-06 09:10:45 --> Database Driver Class Initialized
INFO - 2023-06-06 09:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:10:45 --> Form Validation Class Initialized
INFO - 2023-06-06 09:10:45 --> Controller Class Initialized
INFO - 2023-06-06 09:10:45 --> Model "m_user" initialized
INFO - 2023-06-06 09:10:45 --> Model "m_datatrain" initialized
INFO - 2023-06-06 09:10:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:10:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:10:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:10:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:10:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:10:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-06 09:10:45 --> Final output sent to browser
INFO - 2023-06-06 09:10:47 --> Config Class Initialized
INFO - 2023-06-06 09:10:47 --> Hooks Class Initialized
INFO - 2023-06-06 09:10:47 --> Utf8 Class Initialized
INFO - 2023-06-06 09:10:47 --> URI Class Initialized
INFO - 2023-06-06 09:10:47 --> Router Class Initialized
INFO - 2023-06-06 09:10:47 --> Output Class Initialized
INFO - 2023-06-06 09:10:47 --> Security Class Initialized
INFO - 2023-06-06 09:10:47 --> Input Class Initialized
INFO - 2023-06-06 09:10:47 --> Language Class Initialized
INFO - 2023-06-06 09:10:47 --> Loader Class Initialized
INFO - 2023-06-06 09:10:47 --> Helper loaded: url_helper
INFO - 2023-06-06 09:10:47 --> Helper loaded: form_helper
INFO - 2023-06-06 09:10:47 --> Database Driver Class Initialized
INFO - 2023-06-06 09:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:10:47 --> Form Validation Class Initialized
INFO - 2023-06-06 09:10:47 --> Controller Class Initialized
INFO - 2023-06-06 09:10:47 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:10:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:10:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:10:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:10:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:10:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:10:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:10:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:10:47 --> Final output sent to browser
INFO - 2023-06-06 09:10:49 --> Config Class Initialized
INFO - 2023-06-06 09:10:49 --> Hooks Class Initialized
INFO - 2023-06-06 09:10:49 --> Utf8 Class Initialized
INFO - 2023-06-06 09:10:49 --> URI Class Initialized
INFO - 2023-06-06 09:10:49 --> Router Class Initialized
INFO - 2023-06-06 09:10:49 --> Output Class Initialized
INFO - 2023-06-06 09:10:49 --> Security Class Initialized
INFO - 2023-06-06 09:10:49 --> Input Class Initialized
INFO - 2023-06-06 09:10:49 --> Language Class Initialized
INFO - 2023-06-06 09:10:49 --> Loader Class Initialized
INFO - 2023-06-06 09:10:49 --> Helper loaded: url_helper
INFO - 2023-06-06 09:10:49 --> Helper loaded: form_helper
INFO - 2023-06-06 09:10:49 --> Database Driver Class Initialized
INFO - 2023-06-06 09:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:10:49 --> Form Validation Class Initialized
INFO - 2023-06-06 09:10:49 --> Controller Class Initialized
INFO - 2023-06-06 09:10:49 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:10:49 --> Config Class Initialized
INFO - 2023-06-06 09:10:49 --> Hooks Class Initialized
INFO - 2023-06-06 09:10:49 --> Utf8 Class Initialized
INFO - 2023-06-06 09:10:49 --> URI Class Initialized
INFO - 2023-06-06 09:10:49 --> Router Class Initialized
INFO - 2023-06-06 09:10:49 --> Output Class Initialized
INFO - 2023-06-06 09:10:49 --> Security Class Initialized
INFO - 2023-06-06 09:10:49 --> Input Class Initialized
INFO - 2023-06-06 09:10:49 --> Language Class Initialized
INFO - 2023-06-06 09:10:49 --> Loader Class Initialized
INFO - 2023-06-06 09:10:49 --> Helper loaded: url_helper
INFO - 2023-06-06 09:10:49 --> Helper loaded: form_helper
INFO - 2023-06-06 09:10:49 --> Database Driver Class Initialized
INFO - 2023-06-06 09:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:10:49 --> Form Validation Class Initialized
INFO - 2023-06-06 09:10:49 --> Controller Class Initialized
INFO - 2023-06-06 09:10:49 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:10:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:10:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:10:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:10:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:10:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:10:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:10:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:10:50 --> Final output sent to browser
INFO - 2023-06-06 09:10:53 --> Config Class Initialized
INFO - 2023-06-06 09:10:53 --> Hooks Class Initialized
INFO - 2023-06-06 09:10:53 --> Utf8 Class Initialized
INFO - 2023-06-06 09:10:53 --> URI Class Initialized
INFO - 2023-06-06 09:10:53 --> Router Class Initialized
INFO - 2023-06-06 09:10:53 --> Output Class Initialized
INFO - 2023-06-06 09:10:53 --> Security Class Initialized
INFO - 2023-06-06 09:10:53 --> Input Class Initialized
INFO - 2023-06-06 09:10:53 --> Language Class Initialized
INFO - 2023-06-06 09:10:53 --> Loader Class Initialized
INFO - 2023-06-06 09:10:53 --> Helper loaded: url_helper
INFO - 2023-06-06 09:10:53 --> Helper loaded: form_helper
INFO - 2023-06-06 09:10:53 --> Database Driver Class Initialized
INFO - 2023-06-06 09:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:10:53 --> Form Validation Class Initialized
INFO - 2023-06-06 09:10:53 --> Controller Class Initialized
INFO - 2023-06-06 09:10:53 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:10:53 --> Config Class Initialized
INFO - 2023-06-06 09:10:53 --> Hooks Class Initialized
INFO - 2023-06-06 09:10:53 --> Utf8 Class Initialized
INFO - 2023-06-06 09:10:53 --> URI Class Initialized
INFO - 2023-06-06 09:10:53 --> Router Class Initialized
INFO - 2023-06-06 09:10:53 --> Output Class Initialized
INFO - 2023-06-06 09:10:53 --> Security Class Initialized
INFO - 2023-06-06 09:10:53 --> Input Class Initialized
INFO - 2023-06-06 09:10:53 --> Language Class Initialized
INFO - 2023-06-06 09:10:53 --> Loader Class Initialized
INFO - 2023-06-06 09:10:53 --> Helper loaded: url_helper
INFO - 2023-06-06 09:10:53 --> Helper loaded: form_helper
INFO - 2023-06-06 09:10:53 --> Database Driver Class Initialized
INFO - 2023-06-06 09:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:10:53 --> Form Validation Class Initialized
INFO - 2023-06-06 09:10:53 --> Controller Class Initialized
INFO - 2023-06-06 09:10:53 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:10:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:10:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:10:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:10:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:10:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:10:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:10:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:10:53 --> Final output sent to browser
INFO - 2023-06-06 09:11:07 --> Config Class Initialized
INFO - 2023-06-06 09:11:07 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:07 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:07 --> URI Class Initialized
INFO - 2023-06-06 09:11:07 --> Router Class Initialized
INFO - 2023-06-06 09:11:07 --> Output Class Initialized
INFO - 2023-06-06 09:11:07 --> Security Class Initialized
INFO - 2023-06-06 09:11:07 --> Input Class Initialized
INFO - 2023-06-06 09:11:07 --> Language Class Initialized
INFO - 2023-06-06 09:11:07 --> Loader Class Initialized
INFO - 2023-06-06 09:11:07 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:07 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:07 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:07 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:07 --> Controller Class Initialized
INFO - 2023-06-06 09:11:07 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:07 --> Config Class Initialized
INFO - 2023-06-06 09:11:07 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:07 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:07 --> URI Class Initialized
INFO - 2023-06-06 09:11:07 --> Router Class Initialized
INFO - 2023-06-06 09:11:07 --> Output Class Initialized
INFO - 2023-06-06 09:11:07 --> Security Class Initialized
INFO - 2023-06-06 09:11:07 --> Input Class Initialized
INFO - 2023-06-06 09:11:07 --> Language Class Initialized
INFO - 2023-06-06 09:11:07 --> Loader Class Initialized
INFO - 2023-06-06 09:11:07 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:07 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:07 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:07 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:07 --> Controller Class Initialized
INFO - 2023-06-06 09:11:07 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:11:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:11:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:11:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:11:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:11:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:11:07 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:11:07 --> Final output sent to browser
INFO - 2023-06-06 09:11:09 --> Config Class Initialized
INFO - 2023-06-06 09:11:09 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:09 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:09 --> URI Class Initialized
INFO - 2023-06-06 09:11:09 --> Router Class Initialized
INFO - 2023-06-06 09:11:09 --> Output Class Initialized
INFO - 2023-06-06 09:11:09 --> Security Class Initialized
INFO - 2023-06-06 09:11:09 --> Input Class Initialized
INFO - 2023-06-06 09:11:09 --> Language Class Initialized
INFO - 2023-06-06 09:11:09 --> Loader Class Initialized
INFO - 2023-06-06 09:11:09 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:09 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:09 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:09 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:09 --> Controller Class Initialized
INFO - 2023-06-06 09:11:09 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:09 --> Config Class Initialized
INFO - 2023-06-06 09:11:09 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:09 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:09 --> URI Class Initialized
INFO - 2023-06-06 09:11:09 --> Router Class Initialized
INFO - 2023-06-06 09:11:09 --> Output Class Initialized
INFO - 2023-06-06 09:11:09 --> Security Class Initialized
INFO - 2023-06-06 09:11:09 --> Input Class Initialized
INFO - 2023-06-06 09:11:09 --> Language Class Initialized
INFO - 2023-06-06 09:11:09 --> Loader Class Initialized
INFO - 2023-06-06 09:11:09 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:09 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:09 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:09 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:09 --> Controller Class Initialized
INFO - 2023-06-06 09:11:09 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:11:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:11:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:11:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:11:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:11:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:11:09 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:11:09 --> Final output sent to browser
INFO - 2023-06-06 09:11:11 --> Config Class Initialized
INFO - 2023-06-06 09:11:11 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:11 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:11 --> URI Class Initialized
INFO - 2023-06-06 09:11:11 --> Router Class Initialized
INFO - 2023-06-06 09:11:11 --> Output Class Initialized
INFO - 2023-06-06 09:11:11 --> Security Class Initialized
INFO - 2023-06-06 09:11:11 --> Input Class Initialized
INFO - 2023-06-06 09:11:11 --> Language Class Initialized
INFO - 2023-06-06 09:11:11 --> Loader Class Initialized
INFO - 2023-06-06 09:11:11 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:11 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:11 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:11 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:11 --> Controller Class Initialized
INFO - 2023-06-06 09:11:11 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:11 --> Config Class Initialized
INFO - 2023-06-06 09:11:11 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:11 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:11 --> URI Class Initialized
INFO - 2023-06-06 09:11:11 --> Router Class Initialized
INFO - 2023-06-06 09:11:11 --> Output Class Initialized
INFO - 2023-06-06 09:11:11 --> Security Class Initialized
INFO - 2023-06-06 09:11:11 --> Input Class Initialized
INFO - 2023-06-06 09:11:11 --> Language Class Initialized
INFO - 2023-06-06 09:11:11 --> Loader Class Initialized
INFO - 2023-06-06 09:11:11 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:11 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:11 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:11 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:11 --> Controller Class Initialized
INFO - 2023-06-06 09:11:11 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:11:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:11:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:11:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:11:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:11:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:11:11 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:11:11 --> Final output sent to browser
INFO - 2023-06-06 09:11:12 --> Config Class Initialized
INFO - 2023-06-06 09:11:12 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:12 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:12 --> URI Class Initialized
INFO - 2023-06-06 09:11:12 --> Router Class Initialized
INFO - 2023-06-06 09:11:12 --> Output Class Initialized
INFO - 2023-06-06 09:11:12 --> Security Class Initialized
INFO - 2023-06-06 09:11:12 --> Input Class Initialized
INFO - 2023-06-06 09:11:12 --> Language Class Initialized
INFO - 2023-06-06 09:11:12 --> Loader Class Initialized
INFO - 2023-06-06 09:11:12 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:12 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:12 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:12 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:12 --> Controller Class Initialized
INFO - 2023-06-06 09:11:12 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:12 --> Config Class Initialized
INFO - 2023-06-06 09:11:12 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:12 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:12 --> URI Class Initialized
INFO - 2023-06-06 09:11:12 --> Router Class Initialized
INFO - 2023-06-06 09:11:12 --> Output Class Initialized
INFO - 2023-06-06 09:11:12 --> Security Class Initialized
INFO - 2023-06-06 09:11:12 --> Input Class Initialized
INFO - 2023-06-06 09:11:12 --> Language Class Initialized
INFO - 2023-06-06 09:11:12 --> Loader Class Initialized
INFO - 2023-06-06 09:11:12 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:12 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:12 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:12 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:12 --> Controller Class Initialized
INFO - 2023-06-06 09:11:12 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:11:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:11:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:11:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:11:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:11:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:11:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:11:12 --> Final output sent to browser
INFO - 2023-06-06 09:11:14 --> Config Class Initialized
INFO - 2023-06-06 09:11:14 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:14 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:14 --> URI Class Initialized
INFO - 2023-06-06 09:11:14 --> Router Class Initialized
INFO - 2023-06-06 09:11:14 --> Output Class Initialized
INFO - 2023-06-06 09:11:14 --> Security Class Initialized
INFO - 2023-06-06 09:11:14 --> Input Class Initialized
INFO - 2023-06-06 09:11:14 --> Language Class Initialized
INFO - 2023-06-06 09:11:14 --> Loader Class Initialized
INFO - 2023-06-06 09:11:14 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:14 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:14 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:14 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:14 --> Controller Class Initialized
INFO - 2023-06-06 09:11:14 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:14 --> Config Class Initialized
INFO - 2023-06-06 09:11:14 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:14 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:14 --> URI Class Initialized
INFO - 2023-06-06 09:11:14 --> Router Class Initialized
INFO - 2023-06-06 09:11:14 --> Output Class Initialized
INFO - 2023-06-06 09:11:14 --> Security Class Initialized
INFO - 2023-06-06 09:11:14 --> Input Class Initialized
INFO - 2023-06-06 09:11:14 --> Language Class Initialized
INFO - 2023-06-06 09:11:14 --> Loader Class Initialized
INFO - 2023-06-06 09:11:14 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:14 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:14 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:14 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:14 --> Controller Class Initialized
INFO - 2023-06-06 09:11:14 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:11:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:11:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:11:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:11:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:11:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:11:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:11:14 --> Final output sent to browser
INFO - 2023-06-06 09:11:16 --> Config Class Initialized
INFO - 2023-06-06 09:11:16 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:16 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:16 --> URI Class Initialized
INFO - 2023-06-06 09:11:16 --> Router Class Initialized
INFO - 2023-06-06 09:11:16 --> Output Class Initialized
INFO - 2023-06-06 09:11:16 --> Security Class Initialized
INFO - 2023-06-06 09:11:16 --> Input Class Initialized
INFO - 2023-06-06 09:11:16 --> Language Class Initialized
INFO - 2023-06-06 09:11:16 --> Loader Class Initialized
INFO - 2023-06-06 09:11:16 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:16 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:16 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:16 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:16 --> Controller Class Initialized
INFO - 2023-06-06 09:11:16 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:16 --> Config Class Initialized
INFO - 2023-06-06 09:11:16 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:16 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:16 --> URI Class Initialized
INFO - 2023-06-06 09:11:16 --> Router Class Initialized
INFO - 2023-06-06 09:11:16 --> Output Class Initialized
INFO - 2023-06-06 09:11:16 --> Security Class Initialized
INFO - 2023-06-06 09:11:16 --> Input Class Initialized
INFO - 2023-06-06 09:11:16 --> Language Class Initialized
INFO - 2023-06-06 09:11:16 --> Loader Class Initialized
INFO - 2023-06-06 09:11:16 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:16 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:16 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:16 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:16 --> Controller Class Initialized
INFO - 2023-06-06 09:11:16 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:11:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:11:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:11:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:11:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:11:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:11:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:11:16 --> Final output sent to browser
INFO - 2023-06-06 09:11:18 --> Config Class Initialized
INFO - 2023-06-06 09:11:18 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:18 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:18 --> URI Class Initialized
INFO - 2023-06-06 09:11:18 --> Router Class Initialized
INFO - 2023-06-06 09:11:18 --> Output Class Initialized
INFO - 2023-06-06 09:11:18 --> Security Class Initialized
INFO - 2023-06-06 09:11:18 --> Input Class Initialized
INFO - 2023-06-06 09:11:18 --> Language Class Initialized
INFO - 2023-06-06 09:11:18 --> Loader Class Initialized
INFO - 2023-06-06 09:11:18 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:18 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:18 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:18 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:18 --> Controller Class Initialized
INFO - 2023-06-06 09:11:18 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:18 --> Config Class Initialized
INFO - 2023-06-06 09:11:18 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:18 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:18 --> URI Class Initialized
INFO - 2023-06-06 09:11:18 --> Router Class Initialized
INFO - 2023-06-06 09:11:18 --> Output Class Initialized
INFO - 2023-06-06 09:11:18 --> Security Class Initialized
INFO - 2023-06-06 09:11:18 --> Input Class Initialized
INFO - 2023-06-06 09:11:18 --> Language Class Initialized
INFO - 2023-06-06 09:11:18 --> Loader Class Initialized
INFO - 2023-06-06 09:11:18 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:18 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:18 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:18 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:18 --> Controller Class Initialized
INFO - 2023-06-06 09:11:18 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:11:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:11:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:11:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:11:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:11:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:11:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:11:18 --> Final output sent to browser
INFO - 2023-06-06 09:11:19 --> Config Class Initialized
INFO - 2023-06-06 09:11:19 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:19 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:19 --> URI Class Initialized
INFO - 2023-06-06 09:11:19 --> Router Class Initialized
INFO - 2023-06-06 09:11:19 --> Output Class Initialized
INFO - 2023-06-06 09:11:19 --> Security Class Initialized
INFO - 2023-06-06 09:11:19 --> Input Class Initialized
INFO - 2023-06-06 09:11:19 --> Language Class Initialized
INFO - 2023-06-06 09:11:19 --> Loader Class Initialized
INFO - 2023-06-06 09:11:19 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:20 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:20 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:20 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:20 --> Controller Class Initialized
INFO - 2023-06-06 09:11:20 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:20 --> Config Class Initialized
INFO - 2023-06-06 09:11:20 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:20 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:20 --> URI Class Initialized
INFO - 2023-06-06 09:11:20 --> Router Class Initialized
INFO - 2023-06-06 09:11:20 --> Output Class Initialized
INFO - 2023-06-06 09:11:20 --> Security Class Initialized
INFO - 2023-06-06 09:11:20 --> Input Class Initialized
INFO - 2023-06-06 09:11:20 --> Language Class Initialized
INFO - 2023-06-06 09:11:20 --> Loader Class Initialized
INFO - 2023-06-06 09:11:20 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:20 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:20 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:20 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:20 --> Controller Class Initialized
INFO - 2023-06-06 09:11:20 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:11:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:11:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:11:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:11:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:11:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:11:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:11:20 --> Final output sent to browser
INFO - 2023-06-06 09:11:21 --> Config Class Initialized
INFO - 2023-06-06 09:11:21 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:21 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:21 --> URI Class Initialized
INFO - 2023-06-06 09:11:21 --> Router Class Initialized
INFO - 2023-06-06 09:11:21 --> Output Class Initialized
INFO - 2023-06-06 09:11:21 --> Security Class Initialized
INFO - 2023-06-06 09:11:21 --> Input Class Initialized
INFO - 2023-06-06 09:11:21 --> Language Class Initialized
INFO - 2023-06-06 09:11:21 --> Loader Class Initialized
INFO - 2023-06-06 09:11:21 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:21 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:21 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:21 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:21 --> Controller Class Initialized
INFO - 2023-06-06 09:11:21 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:21 --> Config Class Initialized
INFO - 2023-06-06 09:11:21 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:21 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:21 --> URI Class Initialized
INFO - 2023-06-06 09:11:21 --> Router Class Initialized
INFO - 2023-06-06 09:11:21 --> Output Class Initialized
INFO - 2023-06-06 09:11:21 --> Security Class Initialized
INFO - 2023-06-06 09:11:21 --> Input Class Initialized
INFO - 2023-06-06 09:11:21 --> Language Class Initialized
INFO - 2023-06-06 09:11:21 --> Loader Class Initialized
INFO - 2023-06-06 09:11:21 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:21 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:21 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:21 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:21 --> Controller Class Initialized
INFO - 2023-06-06 09:11:21 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:11:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:11:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:11:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:11:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:11:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:11:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:11:21 --> Final output sent to browser
INFO - 2023-06-06 09:11:23 --> Config Class Initialized
INFO - 2023-06-06 09:11:23 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:23 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:23 --> URI Class Initialized
INFO - 2023-06-06 09:11:23 --> Router Class Initialized
INFO - 2023-06-06 09:11:23 --> Output Class Initialized
INFO - 2023-06-06 09:11:23 --> Security Class Initialized
INFO - 2023-06-06 09:11:23 --> Input Class Initialized
INFO - 2023-06-06 09:11:23 --> Language Class Initialized
INFO - 2023-06-06 09:11:23 --> Loader Class Initialized
INFO - 2023-06-06 09:11:23 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:23 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:23 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:23 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:23 --> Controller Class Initialized
INFO - 2023-06-06 09:11:23 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:23 --> Config Class Initialized
INFO - 2023-06-06 09:11:23 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:23 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:23 --> URI Class Initialized
INFO - 2023-06-06 09:11:23 --> Router Class Initialized
INFO - 2023-06-06 09:11:23 --> Output Class Initialized
INFO - 2023-06-06 09:11:23 --> Security Class Initialized
INFO - 2023-06-06 09:11:23 --> Input Class Initialized
INFO - 2023-06-06 09:11:23 --> Language Class Initialized
INFO - 2023-06-06 09:11:23 --> Loader Class Initialized
INFO - 2023-06-06 09:11:23 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:23 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:23 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:23 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:23 --> Controller Class Initialized
INFO - 2023-06-06 09:11:23 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:11:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:11:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:11:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:11:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:11:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:11:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:11:23 --> Final output sent to browser
INFO - 2023-06-06 09:11:27 --> Config Class Initialized
INFO - 2023-06-06 09:11:27 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:27 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:27 --> URI Class Initialized
INFO - 2023-06-06 09:11:27 --> Router Class Initialized
INFO - 2023-06-06 09:11:27 --> Output Class Initialized
INFO - 2023-06-06 09:11:27 --> Security Class Initialized
INFO - 2023-06-06 09:11:27 --> Input Class Initialized
INFO - 2023-06-06 09:11:27 --> Language Class Initialized
ERROR - 2023-06-06 09:11:27 --> 404 Page Not Found: C_datatest/penghitungan
INFO - 2023-06-06 09:11:28 --> Config Class Initialized
INFO - 2023-06-06 09:11:28 --> Hooks Class Initialized
INFO - 2023-06-06 09:11:28 --> Utf8 Class Initialized
INFO - 2023-06-06 09:11:28 --> URI Class Initialized
INFO - 2023-06-06 09:11:28 --> Router Class Initialized
INFO - 2023-06-06 09:11:28 --> Output Class Initialized
INFO - 2023-06-06 09:11:28 --> Security Class Initialized
INFO - 2023-06-06 09:11:28 --> Input Class Initialized
INFO - 2023-06-06 09:11:28 --> Language Class Initialized
INFO - 2023-06-06 09:11:28 --> Loader Class Initialized
INFO - 2023-06-06 09:11:28 --> Helper loaded: url_helper
INFO - 2023-06-06 09:11:28 --> Helper loaded: form_helper
INFO - 2023-06-06 09:11:28 --> Database Driver Class Initialized
INFO - 2023-06-06 09:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:11:28 --> Form Validation Class Initialized
INFO - 2023-06-06 09:11:28 --> Controller Class Initialized
INFO - 2023-06-06 09:11:28 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:11:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:11:28 --> Final output sent to browser
INFO - 2023-06-06 09:39:39 --> Config Class Initialized
INFO - 2023-06-06 09:39:39 --> Hooks Class Initialized
INFO - 2023-06-06 09:39:39 --> Utf8 Class Initialized
INFO - 2023-06-06 09:39:39 --> URI Class Initialized
INFO - 2023-06-06 09:39:39 --> Router Class Initialized
INFO - 2023-06-06 09:39:39 --> Output Class Initialized
INFO - 2023-06-06 09:39:39 --> Security Class Initialized
INFO - 2023-06-06 09:39:39 --> Input Class Initialized
INFO - 2023-06-06 09:39:39 --> Language Class Initialized
INFO - 2023-06-06 09:39:40 --> Loader Class Initialized
INFO - 2023-06-06 09:39:40 --> Helper loaded: url_helper
INFO - 2023-06-06 09:39:40 --> Helper loaded: form_helper
INFO - 2023-06-06 09:39:40 --> Database Driver Class Initialized
INFO - 2023-06-06 09:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:39:40 --> Form Validation Class Initialized
INFO - 2023-06-06 09:39:40 --> Controller Class Initialized
INFO - 2023-06-06 09:39:40 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:39:40 --> Final output sent to browser
INFO - 2023-06-06 09:39:54 --> Config Class Initialized
INFO - 2023-06-06 09:39:54 --> Hooks Class Initialized
INFO - 2023-06-06 09:39:54 --> Utf8 Class Initialized
INFO - 2023-06-06 09:39:54 --> URI Class Initialized
INFO - 2023-06-06 09:39:54 --> Router Class Initialized
INFO - 2023-06-06 09:39:54 --> Output Class Initialized
INFO - 2023-06-06 09:39:54 --> Security Class Initialized
INFO - 2023-06-06 09:39:54 --> Input Class Initialized
INFO - 2023-06-06 09:39:54 --> Language Class Initialized
INFO - 2023-06-06 09:39:54 --> Loader Class Initialized
INFO - 2023-06-06 09:39:54 --> Helper loaded: url_helper
INFO - 2023-06-06 09:39:54 --> Helper loaded: form_helper
INFO - 2023-06-06 09:39:54 --> Database Driver Class Initialized
INFO - 2023-06-06 09:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:39:54 --> Form Validation Class Initialized
INFO - 2023-06-06 09:39:54 --> Controller Class Initialized
INFO - 2023-06-06 09:39:54 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:39:54 --> Final output sent to browser
INFO - 2023-06-06 09:41:59 --> Config Class Initialized
INFO - 2023-06-06 09:41:59 --> Hooks Class Initialized
INFO - 2023-06-06 09:41:59 --> Utf8 Class Initialized
INFO - 2023-06-06 09:41:59 --> URI Class Initialized
INFO - 2023-06-06 09:41:59 --> Router Class Initialized
INFO - 2023-06-06 09:41:59 --> Output Class Initialized
INFO - 2023-06-06 09:41:59 --> Security Class Initialized
INFO - 2023-06-06 09:41:59 --> Input Class Initialized
INFO - 2023-06-06 09:41:59 --> Language Class Initialized
INFO - 2023-06-06 09:41:59 --> Loader Class Initialized
INFO - 2023-06-06 09:41:59 --> Helper loaded: url_helper
INFO - 2023-06-06 09:41:59 --> Helper loaded: form_helper
INFO - 2023-06-06 09:41:59 --> Database Driver Class Initialized
INFO - 2023-06-06 09:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:41:59 --> Form Validation Class Initialized
INFO - 2023-06-06 09:41:59 --> Controller Class Initialized
INFO - 2023-06-06 09:41:59 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:41:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:41:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:41:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:41:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:41:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:41:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:41:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:41:59 --> Final output sent to browser
INFO - 2023-06-06 09:42:13 --> Config Class Initialized
INFO - 2023-06-06 09:42:13 --> Hooks Class Initialized
INFO - 2023-06-06 09:42:13 --> Utf8 Class Initialized
INFO - 2023-06-06 09:42:13 --> URI Class Initialized
INFO - 2023-06-06 09:42:13 --> Router Class Initialized
INFO - 2023-06-06 09:42:13 --> Output Class Initialized
INFO - 2023-06-06 09:42:13 --> Security Class Initialized
INFO - 2023-06-06 09:42:13 --> Input Class Initialized
INFO - 2023-06-06 09:42:13 --> Language Class Initialized
INFO - 2023-06-06 09:42:13 --> Loader Class Initialized
INFO - 2023-06-06 09:42:13 --> Helper loaded: url_helper
INFO - 2023-06-06 09:42:13 --> Helper loaded: form_helper
INFO - 2023-06-06 09:42:13 --> Database Driver Class Initialized
INFO - 2023-06-06 09:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:42:13 --> Form Validation Class Initialized
INFO - 2023-06-06 09:42:13 --> Controller Class Initialized
INFO - 2023-06-06 09:42:13 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:42:13 --> Final output sent to browser
INFO - 2023-06-06 09:43:09 --> Config Class Initialized
INFO - 2023-06-06 09:43:09 --> Hooks Class Initialized
INFO - 2023-06-06 09:43:09 --> Utf8 Class Initialized
INFO - 2023-06-06 09:43:09 --> URI Class Initialized
INFO - 2023-06-06 09:43:09 --> Router Class Initialized
INFO - 2023-06-06 09:43:09 --> Output Class Initialized
INFO - 2023-06-06 09:43:09 --> Security Class Initialized
INFO - 2023-06-06 09:43:09 --> Input Class Initialized
INFO - 2023-06-06 09:43:09 --> Language Class Initialized
INFO - 2023-06-06 09:43:09 --> Loader Class Initialized
INFO - 2023-06-06 09:43:09 --> Helper loaded: url_helper
INFO - 2023-06-06 09:43:09 --> Helper loaded: form_helper
INFO - 2023-06-06 09:43:09 --> Database Driver Class Initialized
INFO - 2023-06-06 09:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:43:09 --> Form Validation Class Initialized
INFO - 2023-06-06 09:43:09 --> Controller Class Initialized
INFO - 2023-06-06 09:43:09 --> Model "m_datatest" initialized
ERROR - 2023-06-06 09:43:09 --> Severity: Notice --> Undefined variable: nama C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 47
ERROR - 2023-06-06 09:43:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 47
INFO - 2023-06-06 09:43:09 --> Final output sent to browser
INFO - 2023-06-06 09:43:19 --> Config Class Initialized
INFO - 2023-06-06 09:43:19 --> Hooks Class Initialized
INFO - 2023-06-06 09:43:19 --> Utf8 Class Initialized
INFO - 2023-06-06 09:43:19 --> URI Class Initialized
INFO - 2023-06-06 09:43:19 --> Router Class Initialized
INFO - 2023-06-06 09:43:19 --> Output Class Initialized
INFO - 2023-06-06 09:43:19 --> Security Class Initialized
INFO - 2023-06-06 09:43:19 --> Input Class Initialized
INFO - 2023-06-06 09:43:19 --> Language Class Initialized
INFO - 2023-06-06 09:43:19 --> Loader Class Initialized
INFO - 2023-06-06 09:43:19 --> Helper loaded: url_helper
INFO - 2023-06-06 09:43:19 --> Helper loaded: form_helper
INFO - 2023-06-06 09:43:19 --> Database Driver Class Initialized
INFO - 2023-06-06 09:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:43:19 --> Form Validation Class Initialized
INFO - 2023-06-06 09:43:19 --> Controller Class Initialized
INFO - 2023-06-06 09:43:19 --> Model "m_datatest" initialized
ERROR - 2023-06-06 09:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 47
INFO - 2023-06-06 09:43:19 --> Final output sent to browser
INFO - 2023-06-06 09:44:45 --> Config Class Initialized
INFO - 2023-06-06 09:44:45 --> Hooks Class Initialized
INFO - 2023-06-06 09:44:45 --> Utf8 Class Initialized
INFO - 2023-06-06 09:44:45 --> URI Class Initialized
INFO - 2023-06-06 09:44:45 --> Router Class Initialized
INFO - 2023-06-06 09:44:45 --> Output Class Initialized
INFO - 2023-06-06 09:44:45 --> Security Class Initialized
INFO - 2023-06-06 09:44:45 --> Input Class Initialized
INFO - 2023-06-06 09:44:45 --> Language Class Initialized
INFO - 2023-06-06 09:44:45 --> Loader Class Initialized
INFO - 2023-06-06 09:44:45 --> Helper loaded: url_helper
INFO - 2023-06-06 09:44:45 --> Helper loaded: form_helper
INFO - 2023-06-06 09:44:45 --> Database Driver Class Initialized
INFO - 2023-06-06 09:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:44:45 --> Form Validation Class Initialized
INFO - 2023-06-06 09:44:45 --> Controller Class Initialized
INFO - 2023-06-06 09:44:45 --> Model "m_datatest" initialized
ERROR - 2023-06-06 09:44:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 47
INFO - 2023-06-06 09:44:45 --> Final output sent to browser
INFO - 2023-06-06 09:44:46 --> Config Class Initialized
INFO - 2023-06-06 09:44:46 --> Hooks Class Initialized
INFO - 2023-06-06 09:44:46 --> Utf8 Class Initialized
INFO - 2023-06-06 09:44:46 --> URI Class Initialized
INFO - 2023-06-06 09:44:46 --> Router Class Initialized
INFO - 2023-06-06 09:44:46 --> Output Class Initialized
INFO - 2023-06-06 09:44:46 --> Security Class Initialized
INFO - 2023-06-06 09:44:46 --> Input Class Initialized
INFO - 2023-06-06 09:44:46 --> Language Class Initialized
INFO - 2023-06-06 09:44:46 --> Loader Class Initialized
INFO - 2023-06-06 09:44:46 --> Helper loaded: url_helper
INFO - 2023-06-06 09:44:46 --> Helper loaded: form_helper
INFO - 2023-06-06 09:44:46 --> Database Driver Class Initialized
INFO - 2023-06-06 09:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:44:46 --> Form Validation Class Initialized
INFO - 2023-06-06 09:44:46 --> Controller Class Initialized
INFO - 2023-06-06 09:44:46 --> Model "m_datatest" initialized
ERROR - 2023-06-06 09:44:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 47
INFO - 2023-06-06 09:44:46 --> Final output sent to browser
INFO - 2023-06-06 09:44:47 --> Config Class Initialized
INFO - 2023-06-06 09:44:47 --> Hooks Class Initialized
INFO - 2023-06-06 09:44:47 --> Utf8 Class Initialized
INFO - 2023-06-06 09:44:47 --> URI Class Initialized
INFO - 2023-06-06 09:44:47 --> Router Class Initialized
INFO - 2023-06-06 09:44:47 --> Output Class Initialized
INFO - 2023-06-06 09:44:47 --> Security Class Initialized
INFO - 2023-06-06 09:44:47 --> Input Class Initialized
INFO - 2023-06-06 09:44:47 --> Language Class Initialized
INFO - 2023-06-06 09:44:47 --> Loader Class Initialized
INFO - 2023-06-06 09:44:47 --> Helper loaded: url_helper
INFO - 2023-06-06 09:44:47 --> Helper loaded: form_helper
INFO - 2023-06-06 09:44:47 --> Database Driver Class Initialized
INFO - 2023-06-06 09:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:44:47 --> Form Validation Class Initialized
INFO - 2023-06-06 09:44:47 --> Controller Class Initialized
INFO - 2023-06-06 09:44:47 --> Model "m_datatest" initialized
ERROR - 2023-06-06 09:44:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 47
INFO - 2023-06-06 09:44:47 --> Final output sent to browser
INFO - 2023-06-06 09:44:49 --> Config Class Initialized
INFO - 2023-06-06 09:44:49 --> Hooks Class Initialized
INFO - 2023-06-06 09:44:49 --> Utf8 Class Initialized
INFO - 2023-06-06 09:44:49 --> URI Class Initialized
INFO - 2023-06-06 09:44:49 --> Router Class Initialized
INFO - 2023-06-06 09:44:49 --> Output Class Initialized
INFO - 2023-06-06 09:44:49 --> Security Class Initialized
INFO - 2023-06-06 09:44:49 --> Input Class Initialized
INFO - 2023-06-06 09:44:49 --> Language Class Initialized
INFO - 2023-06-06 09:44:49 --> Loader Class Initialized
INFO - 2023-06-06 09:44:49 --> Helper loaded: url_helper
INFO - 2023-06-06 09:44:49 --> Helper loaded: form_helper
INFO - 2023-06-06 09:44:49 --> Database Driver Class Initialized
INFO - 2023-06-06 09:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:44:49 --> Form Validation Class Initialized
INFO - 2023-06-06 09:44:49 --> Controller Class Initialized
INFO - 2023-06-06 09:44:49 --> Model "m_datatest" initialized
INFO - 2023-06-06 09:44:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 09:44:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 09:44:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 09:44:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 09:44:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 09:44:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 09:44:49 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 09:44:49 --> Final output sent to browser
INFO - 2023-06-06 09:44:51 --> Config Class Initialized
INFO - 2023-06-06 09:44:51 --> Hooks Class Initialized
INFO - 2023-06-06 09:44:51 --> Utf8 Class Initialized
INFO - 2023-06-06 09:44:51 --> URI Class Initialized
INFO - 2023-06-06 09:44:51 --> Router Class Initialized
INFO - 2023-06-06 09:44:51 --> Output Class Initialized
INFO - 2023-06-06 09:44:51 --> Security Class Initialized
INFO - 2023-06-06 09:44:51 --> Input Class Initialized
INFO - 2023-06-06 09:44:51 --> Language Class Initialized
INFO - 2023-06-06 09:44:51 --> Loader Class Initialized
INFO - 2023-06-06 09:44:51 --> Helper loaded: url_helper
INFO - 2023-06-06 09:44:51 --> Helper loaded: form_helper
INFO - 2023-06-06 09:44:51 --> Database Driver Class Initialized
INFO - 2023-06-06 09:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:44:51 --> Form Validation Class Initialized
INFO - 2023-06-06 09:44:51 --> Controller Class Initialized
INFO - 2023-06-06 09:44:51 --> Model "m_datatest" initialized
ERROR - 2023-06-06 09:44:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 47
INFO - 2023-06-06 09:44:51 --> Final output sent to browser
INFO - 2023-06-06 09:45:04 --> Config Class Initialized
INFO - 2023-06-06 09:45:04 --> Hooks Class Initialized
INFO - 2023-06-06 09:45:04 --> Utf8 Class Initialized
INFO - 2023-06-06 09:45:04 --> URI Class Initialized
INFO - 2023-06-06 09:45:04 --> Router Class Initialized
INFO - 2023-06-06 09:45:04 --> Output Class Initialized
INFO - 2023-06-06 09:45:04 --> Security Class Initialized
INFO - 2023-06-06 09:45:04 --> Input Class Initialized
INFO - 2023-06-06 09:45:04 --> Language Class Initialized
INFO - 2023-06-06 09:45:04 --> Loader Class Initialized
INFO - 2023-06-06 09:45:04 --> Helper loaded: url_helper
INFO - 2023-06-06 09:45:04 --> Helper loaded: form_helper
INFO - 2023-06-06 09:45:04 --> Database Driver Class Initialized
INFO - 2023-06-06 09:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:45:04 --> Form Validation Class Initialized
INFO - 2023-06-06 09:45:04 --> Controller Class Initialized
INFO - 2023-06-06 09:45:04 --> Model "m_datatest" initialized
ERROR - 2023-06-06 09:45:04 --> Severity: Notice --> Undefined variable: nama C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 47
ERROR - 2023-06-06 09:45:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 47
INFO - 2023-06-06 09:45:04 --> Final output sent to browser
INFO - 2023-06-06 10:01:58 --> Config Class Initialized
INFO - 2023-06-06 10:01:58 --> Hooks Class Initialized
INFO - 2023-06-06 10:01:58 --> Utf8 Class Initialized
INFO - 2023-06-06 10:01:58 --> URI Class Initialized
INFO - 2023-06-06 10:01:58 --> Router Class Initialized
INFO - 2023-06-06 10:01:58 --> Output Class Initialized
INFO - 2023-06-06 10:01:58 --> Security Class Initialized
INFO - 2023-06-06 10:01:58 --> Input Class Initialized
INFO - 2023-06-06 10:01:58 --> Language Class Initialized
INFO - 2023-06-06 10:01:58 --> Loader Class Initialized
INFO - 2023-06-06 10:01:58 --> Helper loaded: url_helper
INFO - 2023-06-06 10:01:58 --> Helper loaded: form_helper
INFO - 2023-06-06 10:01:58 --> Database Driver Class Initialized
INFO - 2023-06-06 10:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:01:58 --> Form Validation Class Initialized
INFO - 2023-06-06 10:01:58 --> Controller Class Initialized
INFO - 2023-06-06 10:01:58 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:01:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:01:58 --> Final output sent to browser
INFO - 2023-06-06 10:02:10 --> Config Class Initialized
INFO - 2023-06-06 10:02:10 --> Hooks Class Initialized
INFO - 2023-06-06 10:02:10 --> Utf8 Class Initialized
INFO - 2023-06-06 10:02:10 --> URI Class Initialized
INFO - 2023-06-06 10:02:10 --> Router Class Initialized
INFO - 2023-06-06 10:02:10 --> Output Class Initialized
INFO - 2023-06-06 10:02:10 --> Security Class Initialized
INFO - 2023-06-06 10:02:10 --> Input Class Initialized
INFO - 2023-06-06 10:02:10 --> Language Class Initialized
INFO - 2023-06-06 10:02:10 --> Loader Class Initialized
INFO - 2023-06-06 10:02:10 --> Helper loaded: url_helper
INFO - 2023-06-06 10:02:10 --> Helper loaded: form_helper
INFO - 2023-06-06 10:02:10 --> Database Driver Class Initialized
INFO - 2023-06-06 10:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:02:10 --> Form Validation Class Initialized
INFO - 2023-06-06 10:02:10 --> Controller Class Initialized
INFO - 2023-06-06 10:02:10 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:02:10 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:02:10 --> Final output sent to browser
INFO - 2023-06-06 10:02:12 --> Config Class Initialized
INFO - 2023-06-06 10:02:12 --> Hooks Class Initialized
INFO - 2023-06-06 10:02:12 --> Utf8 Class Initialized
INFO - 2023-06-06 10:02:12 --> URI Class Initialized
INFO - 2023-06-06 10:02:12 --> Router Class Initialized
INFO - 2023-06-06 10:02:12 --> Output Class Initialized
INFO - 2023-06-06 10:02:12 --> Security Class Initialized
INFO - 2023-06-06 10:02:12 --> Input Class Initialized
INFO - 2023-06-06 10:02:12 --> Language Class Initialized
INFO - 2023-06-06 10:02:12 --> Loader Class Initialized
INFO - 2023-06-06 10:02:12 --> Helper loaded: url_helper
INFO - 2023-06-06 10:02:12 --> Helper loaded: form_helper
INFO - 2023-06-06 10:02:12 --> Database Driver Class Initialized
INFO - 2023-06-06 10:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:02:12 --> Form Validation Class Initialized
INFO - 2023-06-06 10:02:12 --> Controller Class Initialized
INFO - 2023-06-06 10:02:12 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:02:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:02:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:02:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:02:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:02:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:02:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:02:12 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:02:12 --> Final output sent to browser
INFO - 2023-06-06 10:02:14 --> Config Class Initialized
INFO - 2023-06-06 10:02:14 --> Hooks Class Initialized
INFO - 2023-06-06 10:02:14 --> Utf8 Class Initialized
INFO - 2023-06-06 10:02:14 --> URI Class Initialized
INFO - 2023-06-06 10:02:14 --> Router Class Initialized
INFO - 2023-06-06 10:02:14 --> Output Class Initialized
INFO - 2023-06-06 10:02:14 --> Security Class Initialized
INFO - 2023-06-06 10:02:14 --> Input Class Initialized
INFO - 2023-06-06 10:02:14 --> Language Class Initialized
INFO - 2023-06-06 10:02:14 --> Loader Class Initialized
INFO - 2023-06-06 10:02:14 --> Helper loaded: url_helper
INFO - 2023-06-06 10:02:14 --> Helper loaded: form_helper
INFO - 2023-06-06 10:02:14 --> Database Driver Class Initialized
INFO - 2023-06-06 10:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:02:14 --> Form Validation Class Initialized
INFO - 2023-06-06 10:02:14 --> Controller Class Initialized
INFO - 2023-06-06 10:02:14 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:02:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:02:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:02:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 10:02:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:02:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:02:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:02:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:02:14 --> Final output sent to browser
INFO - 2023-06-06 10:02:25 --> Config Class Initialized
INFO - 2023-06-06 10:02:25 --> Hooks Class Initialized
INFO - 2023-06-06 10:02:25 --> Utf8 Class Initialized
INFO - 2023-06-06 10:02:25 --> URI Class Initialized
INFO - 2023-06-06 10:02:25 --> Router Class Initialized
INFO - 2023-06-06 10:02:25 --> Output Class Initialized
INFO - 2023-06-06 10:02:25 --> Security Class Initialized
INFO - 2023-06-06 10:02:25 --> Input Class Initialized
INFO - 2023-06-06 10:02:25 --> Language Class Initialized
INFO - 2023-06-06 10:02:25 --> Loader Class Initialized
INFO - 2023-06-06 10:02:25 --> Helper loaded: url_helper
INFO - 2023-06-06 10:02:25 --> Helper loaded: form_helper
INFO - 2023-06-06 10:02:25 --> Database Driver Class Initialized
INFO - 2023-06-06 10:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:02:25 --> Form Validation Class Initialized
INFO - 2023-06-06 10:02:25 --> Controller Class Initialized
INFO - 2023-06-06 10:02:25 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:02:25 --> Final output sent to browser
INFO - 2023-06-06 10:03:28 --> Config Class Initialized
INFO - 2023-06-06 10:03:28 --> Hooks Class Initialized
INFO - 2023-06-06 10:03:28 --> Utf8 Class Initialized
INFO - 2023-06-06 10:03:28 --> URI Class Initialized
INFO - 2023-06-06 10:03:28 --> Router Class Initialized
INFO - 2023-06-06 10:03:28 --> Output Class Initialized
INFO - 2023-06-06 10:03:28 --> Security Class Initialized
INFO - 2023-06-06 10:03:28 --> Input Class Initialized
INFO - 2023-06-06 10:03:28 --> Language Class Initialized
INFO - 2023-06-06 10:03:28 --> Loader Class Initialized
INFO - 2023-06-06 10:03:28 --> Helper loaded: url_helper
INFO - 2023-06-06 10:03:28 --> Helper loaded: form_helper
INFO - 2023-06-06 10:03:28 --> Database Driver Class Initialized
INFO - 2023-06-06 10:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:03:28 --> Form Validation Class Initialized
INFO - 2023-06-06 10:03:28 --> Controller Class Initialized
INFO - 2023-06-06 10:03:28 --> Model "m_datatest" initialized
ERROR - 2023-06-06 10:03:28 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 47
ERROR - 2023-06-06 10:03:28 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 47
INFO - 2023-06-06 10:03:28 --> Final output sent to browser
INFO - 2023-06-06 10:03:57 --> Config Class Initialized
INFO - 2023-06-06 10:03:57 --> Hooks Class Initialized
INFO - 2023-06-06 10:03:57 --> Utf8 Class Initialized
INFO - 2023-06-06 10:03:57 --> URI Class Initialized
INFO - 2023-06-06 10:03:57 --> Router Class Initialized
INFO - 2023-06-06 10:03:57 --> Output Class Initialized
INFO - 2023-06-06 10:03:57 --> Security Class Initialized
INFO - 2023-06-06 10:03:57 --> Input Class Initialized
INFO - 2023-06-06 10:03:57 --> Language Class Initialized
INFO - 2023-06-06 10:03:57 --> Loader Class Initialized
INFO - 2023-06-06 10:03:57 --> Helper loaded: url_helper
INFO - 2023-06-06 10:03:57 --> Helper loaded: form_helper
INFO - 2023-06-06 10:03:57 --> Database Driver Class Initialized
INFO - 2023-06-06 10:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:03:57 --> Form Validation Class Initialized
INFO - 2023-06-06 10:03:57 --> Controller Class Initialized
INFO - 2023-06-06 10:03:57 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:03:57 --> Final output sent to browser
INFO - 2023-06-06 10:20:09 --> Config Class Initialized
INFO - 2023-06-06 10:20:09 --> Hooks Class Initialized
INFO - 2023-06-06 10:20:09 --> Utf8 Class Initialized
INFO - 2023-06-06 10:20:09 --> URI Class Initialized
INFO - 2023-06-06 10:20:09 --> Router Class Initialized
INFO - 2023-06-06 10:20:09 --> Output Class Initialized
INFO - 2023-06-06 10:20:09 --> Security Class Initialized
INFO - 2023-06-06 10:20:09 --> Input Class Initialized
INFO - 2023-06-06 10:20:09 --> Language Class Initialized
ERROR - 2023-06-06 10:20:09 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 11
INFO - 2023-06-06 10:20:17 --> Config Class Initialized
INFO - 2023-06-06 10:20:17 --> Hooks Class Initialized
INFO - 2023-06-06 10:20:17 --> Utf8 Class Initialized
INFO - 2023-06-06 10:20:17 --> URI Class Initialized
INFO - 2023-06-06 10:20:17 --> Router Class Initialized
INFO - 2023-06-06 10:20:17 --> Output Class Initialized
INFO - 2023-06-06 10:20:17 --> Security Class Initialized
INFO - 2023-06-06 10:20:17 --> Input Class Initialized
INFO - 2023-06-06 10:20:17 --> Language Class Initialized
INFO - 2023-06-06 10:20:17 --> Loader Class Initialized
INFO - 2023-06-06 10:20:17 --> Helper loaded: url_helper
INFO - 2023-06-06 10:20:17 --> Helper loaded: form_helper
INFO - 2023-06-06 10:20:17 --> Database Driver Class Initialized
INFO - 2023-06-06 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:20:17 --> Form Validation Class Initialized
INFO - 2023-06-06 10:20:17 --> Controller Class Initialized
INFO - 2023-06-06 10:20:17 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-06 10:20:17 --> Final output sent to browser
INFO - 2023-06-06 10:20:20 --> Config Class Initialized
INFO - 2023-06-06 10:20:20 --> Hooks Class Initialized
INFO - 2023-06-06 10:20:20 --> Utf8 Class Initialized
INFO - 2023-06-06 10:20:20 --> URI Class Initialized
INFO - 2023-06-06 10:20:20 --> Router Class Initialized
INFO - 2023-06-06 10:20:20 --> Output Class Initialized
INFO - 2023-06-06 10:20:20 --> Security Class Initialized
INFO - 2023-06-06 10:20:20 --> Input Class Initialized
INFO - 2023-06-06 10:20:20 --> Language Class Initialized
INFO - 2023-06-06 10:20:20 --> Loader Class Initialized
INFO - 2023-06-06 10:20:20 --> Helper loaded: url_helper
INFO - 2023-06-06 10:20:20 --> Helper loaded: form_helper
INFO - 2023-06-06 10:20:20 --> Database Driver Class Initialized
INFO - 2023-06-06 10:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:20:20 --> Form Validation Class Initialized
INFO - 2023-06-06 10:20:20 --> Controller Class Initialized
INFO - 2023-06-06 10:20:20 --> Model "m_user" initialized
INFO - 2023-06-06 10:20:20 --> Config Class Initialized
INFO - 2023-06-06 10:20:20 --> Hooks Class Initialized
INFO - 2023-06-06 10:20:20 --> Utf8 Class Initialized
INFO - 2023-06-06 10:20:20 --> URI Class Initialized
INFO - 2023-06-06 10:20:20 --> Router Class Initialized
INFO - 2023-06-06 10:20:20 --> Output Class Initialized
INFO - 2023-06-06 10:20:20 --> Security Class Initialized
INFO - 2023-06-06 10:20:20 --> Input Class Initialized
INFO - 2023-06-06 10:20:20 --> Language Class Initialized
INFO - 2023-06-06 10:20:20 --> Loader Class Initialized
INFO - 2023-06-06 10:20:20 --> Helper loaded: url_helper
INFO - 2023-06-06 10:20:20 --> Helper loaded: form_helper
INFO - 2023-06-06 10:20:20 --> Database Driver Class Initialized
INFO - 2023-06-06 10:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:20:20 --> Form Validation Class Initialized
INFO - 2023-06-06 10:20:20 --> Controller Class Initialized
INFO - 2023-06-06 10:20:20 --> Model "m_user" initialized
INFO - 2023-06-06 10:20:20 --> Model "m_datatrain" initialized
INFO - 2023-06-06 10:20:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:20:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:20:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:20:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:20:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:20:20 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-06 10:20:20 --> Final output sent to browser
INFO - 2023-06-06 10:20:23 --> Config Class Initialized
INFO - 2023-06-06 10:20:23 --> Hooks Class Initialized
INFO - 2023-06-06 10:20:23 --> Utf8 Class Initialized
INFO - 2023-06-06 10:20:23 --> URI Class Initialized
INFO - 2023-06-06 10:20:23 --> Router Class Initialized
INFO - 2023-06-06 10:20:23 --> Output Class Initialized
INFO - 2023-06-06 10:20:23 --> Security Class Initialized
INFO - 2023-06-06 10:20:23 --> Input Class Initialized
INFO - 2023-06-06 10:20:23 --> Language Class Initialized
INFO - 2023-06-06 10:20:23 --> Loader Class Initialized
INFO - 2023-06-06 10:20:23 --> Helper loaded: url_helper
INFO - 2023-06-06 10:20:23 --> Helper loaded: form_helper
INFO - 2023-06-06 10:20:23 --> Database Driver Class Initialized
INFO - 2023-06-06 10:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:20:23 --> Form Validation Class Initialized
INFO - 2023-06-06 10:20:23 --> Controller Class Initialized
INFO - 2023-06-06 10:20:23 --> Model "m_user" initialized
INFO - 2023-06-06 10:20:23 --> Config Class Initialized
INFO - 2023-06-06 10:20:23 --> Hooks Class Initialized
INFO - 2023-06-06 10:20:23 --> Utf8 Class Initialized
INFO - 2023-06-06 10:20:23 --> URI Class Initialized
INFO - 2023-06-06 10:20:23 --> Router Class Initialized
INFO - 2023-06-06 10:20:23 --> Output Class Initialized
INFO - 2023-06-06 10:20:23 --> Security Class Initialized
INFO - 2023-06-06 10:20:23 --> Input Class Initialized
INFO - 2023-06-06 10:20:23 --> Language Class Initialized
INFO - 2023-06-06 10:20:23 --> Loader Class Initialized
INFO - 2023-06-06 10:20:23 --> Helper loaded: url_helper
INFO - 2023-06-06 10:20:23 --> Helper loaded: form_helper
INFO - 2023-06-06 10:20:23 --> Database Driver Class Initialized
INFO - 2023-06-06 10:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:20:23 --> Form Validation Class Initialized
INFO - 2023-06-06 10:20:23 --> Controller Class Initialized
INFO - 2023-06-06 10:20:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-06 10:20:23 --> Final output sent to browser
INFO - 2023-06-06 10:20:24 --> Config Class Initialized
INFO - 2023-06-06 10:20:24 --> Hooks Class Initialized
INFO - 2023-06-06 10:20:24 --> Utf8 Class Initialized
INFO - 2023-06-06 10:20:24 --> URI Class Initialized
INFO - 2023-06-06 10:20:24 --> Router Class Initialized
INFO - 2023-06-06 10:20:24 --> Output Class Initialized
INFO - 2023-06-06 10:20:24 --> Security Class Initialized
INFO - 2023-06-06 10:20:24 --> Input Class Initialized
INFO - 2023-06-06 10:20:24 --> Language Class Initialized
INFO - 2023-06-06 10:20:24 --> Loader Class Initialized
INFO - 2023-06-06 10:20:24 --> Helper loaded: url_helper
INFO - 2023-06-06 10:20:24 --> Helper loaded: form_helper
INFO - 2023-06-06 10:20:24 --> Database Driver Class Initialized
INFO - 2023-06-06 10:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:20:24 --> Form Validation Class Initialized
INFO - 2023-06-06 10:20:24 --> Controller Class Initialized
INFO - 2023-06-06 10:20:24 --> Model "m_user" initialized
INFO - 2023-06-06 10:20:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-06 10:20:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-06 10:20:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-06 10:20:24 --> Final output sent to browser
INFO - 2023-06-06 10:20:26 --> Config Class Initialized
INFO - 2023-06-06 10:20:26 --> Hooks Class Initialized
INFO - 2023-06-06 10:20:26 --> Utf8 Class Initialized
INFO - 2023-06-06 10:20:26 --> URI Class Initialized
INFO - 2023-06-06 10:20:26 --> Router Class Initialized
INFO - 2023-06-06 10:20:26 --> Output Class Initialized
INFO - 2023-06-06 10:20:26 --> Security Class Initialized
INFO - 2023-06-06 10:20:26 --> Input Class Initialized
INFO - 2023-06-06 10:20:26 --> Language Class Initialized
INFO - 2023-06-06 10:20:26 --> Loader Class Initialized
INFO - 2023-06-06 10:20:26 --> Helper loaded: url_helper
INFO - 2023-06-06 10:20:26 --> Helper loaded: form_helper
INFO - 2023-06-06 10:20:26 --> Database Driver Class Initialized
INFO - 2023-06-06 10:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:20:26 --> Form Validation Class Initialized
INFO - 2023-06-06 10:20:26 --> Controller Class Initialized
INFO - 2023-06-06 10:20:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-06 10:20:26 --> Final output sent to browser
INFO - 2023-06-06 10:20:28 --> Config Class Initialized
INFO - 2023-06-06 10:20:28 --> Hooks Class Initialized
INFO - 2023-06-06 10:20:28 --> Utf8 Class Initialized
INFO - 2023-06-06 10:20:28 --> URI Class Initialized
INFO - 2023-06-06 10:20:28 --> Router Class Initialized
INFO - 2023-06-06 10:20:28 --> Output Class Initialized
INFO - 2023-06-06 10:20:28 --> Security Class Initialized
INFO - 2023-06-06 10:20:28 --> Input Class Initialized
INFO - 2023-06-06 10:20:28 --> Language Class Initialized
INFO - 2023-06-06 10:20:28 --> Loader Class Initialized
INFO - 2023-06-06 10:20:28 --> Helper loaded: url_helper
INFO - 2023-06-06 10:20:28 --> Helper loaded: form_helper
INFO - 2023-06-06 10:20:28 --> Database Driver Class Initialized
INFO - 2023-06-06 10:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:20:28 --> Form Validation Class Initialized
INFO - 2023-06-06 10:20:28 --> Controller Class Initialized
INFO - 2023-06-06 10:20:28 --> Model "m_user" initialized
INFO - 2023-06-06 10:20:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:20:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:20:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-06 10:20:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:20:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:20:28 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-06 10:20:28 --> Final output sent to browser
INFO - 2023-06-06 10:20:29 --> Config Class Initialized
INFO - 2023-06-06 10:20:29 --> Hooks Class Initialized
INFO - 2023-06-06 10:20:29 --> Utf8 Class Initialized
INFO - 2023-06-06 10:20:29 --> URI Class Initialized
INFO - 2023-06-06 10:20:29 --> Router Class Initialized
INFO - 2023-06-06 10:20:29 --> Output Class Initialized
INFO - 2023-06-06 10:20:29 --> Security Class Initialized
INFO - 2023-06-06 10:20:29 --> Input Class Initialized
INFO - 2023-06-06 10:20:29 --> Language Class Initialized
INFO - 2023-06-06 10:20:29 --> Loader Class Initialized
INFO - 2023-06-06 10:20:29 --> Helper loaded: url_helper
INFO - 2023-06-06 10:20:29 --> Helper loaded: form_helper
INFO - 2023-06-06 10:20:29 --> Database Driver Class Initialized
INFO - 2023-06-06 10:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:20:29 --> Form Validation Class Initialized
INFO - 2023-06-06 10:20:29 --> Controller Class Initialized
INFO - 2023-06-06 10:20:29 --> Model "m_datatrain" initialized
INFO - 2023-06-06 10:20:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:20:29 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:20:29 --> Model "M_solusi" initialized
INFO - 2023-06-06 10:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-06 10:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-06 10:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:20:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-06 10:20:29 --> Final output sent to browser
INFO - 2023-06-06 10:24:23 --> Config Class Initialized
INFO - 2023-06-06 10:24:23 --> Hooks Class Initialized
INFO - 2023-06-06 10:24:23 --> Utf8 Class Initialized
INFO - 2023-06-06 10:24:23 --> URI Class Initialized
INFO - 2023-06-06 10:24:23 --> Router Class Initialized
INFO - 2023-06-06 10:24:23 --> Output Class Initialized
INFO - 2023-06-06 10:24:23 --> Security Class Initialized
INFO - 2023-06-06 10:24:23 --> Input Class Initialized
INFO - 2023-06-06 10:24:23 --> Language Class Initialized
INFO - 2023-06-06 10:24:23 --> Loader Class Initialized
INFO - 2023-06-06 10:24:23 --> Helper loaded: url_helper
INFO - 2023-06-06 10:24:23 --> Helper loaded: form_helper
INFO - 2023-06-06 10:24:23 --> Database Driver Class Initialized
INFO - 2023-06-06 10:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:24:23 --> Form Validation Class Initialized
INFO - 2023-06-06 10:24:23 --> Controller Class Initialized
INFO - 2023-06-06 10:24:23 --> Model "m_user" initialized
INFO - 2023-06-06 10:24:23 --> Config Class Initialized
INFO - 2023-06-06 10:24:23 --> Hooks Class Initialized
INFO - 2023-06-06 10:24:23 --> Utf8 Class Initialized
INFO - 2023-06-06 10:24:23 --> URI Class Initialized
INFO - 2023-06-06 10:24:23 --> Router Class Initialized
INFO - 2023-06-06 10:24:23 --> Output Class Initialized
INFO - 2023-06-06 10:24:23 --> Security Class Initialized
INFO - 2023-06-06 10:24:23 --> Input Class Initialized
INFO - 2023-06-06 10:24:23 --> Language Class Initialized
INFO - 2023-06-06 10:24:23 --> Loader Class Initialized
INFO - 2023-06-06 10:24:23 --> Helper loaded: url_helper
INFO - 2023-06-06 10:24:23 --> Helper loaded: form_helper
INFO - 2023-06-06 10:24:23 --> Database Driver Class Initialized
INFO - 2023-06-06 10:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:24:23 --> Form Validation Class Initialized
INFO - 2023-06-06 10:24:23 --> Controller Class Initialized
INFO - 2023-06-06 10:24:23 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-06 10:24:23 --> Final output sent to browser
INFO - 2023-06-06 10:24:24 --> Config Class Initialized
INFO - 2023-06-06 10:24:24 --> Hooks Class Initialized
INFO - 2023-06-06 10:24:24 --> Utf8 Class Initialized
INFO - 2023-06-06 10:24:24 --> URI Class Initialized
INFO - 2023-06-06 10:24:24 --> Router Class Initialized
INFO - 2023-06-06 10:24:24 --> Output Class Initialized
INFO - 2023-06-06 10:24:24 --> Security Class Initialized
INFO - 2023-06-06 10:24:24 --> Input Class Initialized
INFO - 2023-06-06 10:24:24 --> Language Class Initialized
INFO - 2023-06-06 10:24:24 --> Loader Class Initialized
INFO - 2023-06-06 10:24:24 --> Helper loaded: url_helper
INFO - 2023-06-06 10:24:24 --> Helper loaded: form_helper
INFO - 2023-06-06 10:24:24 --> Database Driver Class Initialized
INFO - 2023-06-06 10:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:24:24 --> Form Validation Class Initialized
INFO - 2023-06-06 10:24:24 --> Controller Class Initialized
INFO - 2023-06-06 10:24:24 --> Model "m_user" initialized
INFO - 2023-06-06 10:24:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-06 10:24:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-06 10:24:24 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-06 10:24:24 --> Final output sent to browser
INFO - 2023-06-06 10:24:27 --> Config Class Initialized
INFO - 2023-06-06 10:24:27 --> Hooks Class Initialized
INFO - 2023-06-06 10:24:27 --> Utf8 Class Initialized
INFO - 2023-06-06 10:24:27 --> URI Class Initialized
INFO - 2023-06-06 10:24:27 --> Router Class Initialized
INFO - 2023-06-06 10:24:27 --> Output Class Initialized
INFO - 2023-06-06 10:24:27 --> Security Class Initialized
INFO - 2023-06-06 10:24:27 --> Input Class Initialized
INFO - 2023-06-06 10:24:27 --> Language Class Initialized
INFO - 2023-06-06 10:24:27 --> Loader Class Initialized
INFO - 2023-06-06 10:24:27 --> Helper loaded: url_helper
INFO - 2023-06-06 10:24:27 --> Helper loaded: form_helper
INFO - 2023-06-06 10:24:27 --> Database Driver Class Initialized
INFO - 2023-06-06 10:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:24:27 --> Form Validation Class Initialized
INFO - 2023-06-06 10:24:27 --> Controller Class Initialized
INFO - 2023-06-06 10:24:27 --> Model "m_user" initialized
INFO - 2023-06-06 10:24:27 --> Config Class Initialized
INFO - 2023-06-06 10:24:27 --> Hooks Class Initialized
INFO - 2023-06-06 10:24:27 --> Utf8 Class Initialized
INFO - 2023-06-06 10:24:27 --> URI Class Initialized
INFO - 2023-06-06 10:24:27 --> Router Class Initialized
INFO - 2023-06-06 10:24:27 --> Output Class Initialized
INFO - 2023-06-06 10:24:27 --> Security Class Initialized
INFO - 2023-06-06 10:24:27 --> Input Class Initialized
INFO - 2023-06-06 10:24:27 --> Language Class Initialized
INFO - 2023-06-06 10:24:27 --> Loader Class Initialized
INFO - 2023-06-06 10:24:27 --> Helper loaded: url_helper
INFO - 2023-06-06 10:24:27 --> Helper loaded: form_helper
INFO - 2023-06-06 10:24:27 --> Database Driver Class Initialized
INFO - 2023-06-06 10:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:24:27 --> Form Validation Class Initialized
INFO - 2023-06-06 10:24:27 --> Controller Class Initialized
INFO - 2023-06-06 10:24:27 --> Model "m_user" initialized
INFO - 2023-06-06 10:24:27 --> Model "m_datatrain" initialized
INFO - 2023-06-06 10:24:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:24:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:24:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:24:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:24:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:24:27 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-06 10:24:27 --> Final output sent to browser
INFO - 2023-06-06 10:24:29 --> Config Class Initialized
INFO - 2023-06-06 10:24:29 --> Hooks Class Initialized
INFO - 2023-06-06 10:24:29 --> Utf8 Class Initialized
INFO - 2023-06-06 10:24:29 --> URI Class Initialized
INFO - 2023-06-06 10:24:29 --> Router Class Initialized
INFO - 2023-06-06 10:24:29 --> Output Class Initialized
INFO - 2023-06-06 10:24:29 --> Security Class Initialized
INFO - 2023-06-06 10:24:29 --> Input Class Initialized
INFO - 2023-06-06 10:24:29 --> Language Class Initialized
ERROR - 2023-06-06 10:24:29 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\sistemdiagnosa\application\controllers\C_datatest.php 11
INFO - 2023-06-06 10:24:48 --> Config Class Initialized
INFO - 2023-06-06 10:24:48 --> Hooks Class Initialized
INFO - 2023-06-06 10:24:48 --> Utf8 Class Initialized
INFO - 2023-06-06 10:24:48 --> URI Class Initialized
INFO - 2023-06-06 10:24:48 --> Router Class Initialized
INFO - 2023-06-06 10:24:48 --> Output Class Initialized
INFO - 2023-06-06 10:24:48 --> Security Class Initialized
INFO - 2023-06-06 10:24:48 --> Input Class Initialized
INFO - 2023-06-06 10:24:48 --> Language Class Initialized
INFO - 2023-06-06 10:24:48 --> Loader Class Initialized
INFO - 2023-06-06 10:24:48 --> Helper loaded: url_helper
INFO - 2023-06-06 10:24:48 --> Helper loaded: form_helper
INFO - 2023-06-06 10:24:48 --> Database Driver Class Initialized
INFO - 2023-06-06 10:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:24:48 --> Form Validation Class Initialized
INFO - 2023-06-06 10:24:48 --> Controller Class Initialized
INFO - 2023-06-06 10:24:48 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:24:48 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 10:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:24:48 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:24:48 --> Final output sent to browser
INFO - 2023-06-06 10:24:51 --> Config Class Initialized
INFO - 2023-06-06 10:24:51 --> Hooks Class Initialized
INFO - 2023-06-06 10:24:51 --> Utf8 Class Initialized
INFO - 2023-06-06 10:24:51 --> URI Class Initialized
INFO - 2023-06-06 10:24:52 --> Router Class Initialized
INFO - 2023-06-06 10:24:52 --> Output Class Initialized
INFO - 2023-06-06 10:24:52 --> Security Class Initialized
INFO - 2023-06-06 10:24:52 --> Input Class Initialized
INFO - 2023-06-06 10:24:52 --> Language Class Initialized
INFO - 2023-06-06 10:24:52 --> Loader Class Initialized
INFO - 2023-06-06 10:24:52 --> Helper loaded: url_helper
INFO - 2023-06-06 10:24:52 --> Helper loaded: form_helper
INFO - 2023-06-06 10:24:52 --> Database Driver Class Initialized
INFO - 2023-06-06 10:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:24:52 --> Form Validation Class Initialized
INFO - 2023-06-06 10:24:52 --> Controller Class Initialized
INFO - 2023-06-06 10:24:52 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:24:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:24:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:24:52 --> Final output sent to browser
INFO - 2023-06-06 10:26:57 --> Config Class Initialized
INFO - 2023-06-06 10:26:57 --> Hooks Class Initialized
INFO - 2023-06-06 10:26:57 --> Utf8 Class Initialized
INFO - 2023-06-06 10:26:57 --> URI Class Initialized
INFO - 2023-06-06 10:26:57 --> Router Class Initialized
INFO - 2023-06-06 10:26:57 --> Output Class Initialized
INFO - 2023-06-06 10:26:57 --> Security Class Initialized
INFO - 2023-06-06 10:26:57 --> Input Class Initialized
INFO - 2023-06-06 10:26:57 --> Language Class Initialized
INFO - 2023-06-06 10:26:57 --> Loader Class Initialized
INFO - 2023-06-06 10:26:57 --> Helper loaded: url_helper
INFO - 2023-06-06 10:26:57 --> Helper loaded: form_helper
INFO - 2023-06-06 10:26:57 --> Database Driver Class Initialized
INFO - 2023-06-06 10:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:26:57 --> Form Validation Class Initialized
INFO - 2023-06-06 10:26:57 --> Controller Class Initialized
INFO - 2023-06-06 10:26:57 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:26:57 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:26:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:26:57 --> Final output sent to browser
INFO - 2023-06-06 10:28:00 --> Config Class Initialized
INFO - 2023-06-06 10:28:00 --> Hooks Class Initialized
INFO - 2023-06-06 10:28:00 --> Utf8 Class Initialized
INFO - 2023-06-06 10:28:00 --> URI Class Initialized
INFO - 2023-06-06 10:28:00 --> Router Class Initialized
INFO - 2023-06-06 10:28:00 --> Output Class Initialized
INFO - 2023-06-06 10:28:00 --> Security Class Initialized
INFO - 2023-06-06 10:28:00 --> Input Class Initialized
INFO - 2023-06-06 10:28:00 --> Language Class Initialized
INFO - 2023-06-06 10:28:00 --> Loader Class Initialized
INFO - 2023-06-06 10:28:00 --> Helper loaded: url_helper
INFO - 2023-06-06 10:28:00 --> Helper loaded: form_helper
INFO - 2023-06-06 10:28:00 --> Database Driver Class Initialized
INFO - 2023-06-06 10:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:28:00 --> Form Validation Class Initialized
INFO - 2023-06-06 10:28:00 --> Controller Class Initialized
INFO - 2023-06-06 10:28:00 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:28:00 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:28:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:28:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:28:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 10:28:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:28:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:28:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:28:00 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:28:00 --> Final output sent to browser
INFO - 2023-06-06 10:28:44 --> Config Class Initialized
INFO - 2023-06-06 10:28:44 --> Hooks Class Initialized
INFO - 2023-06-06 10:28:44 --> Utf8 Class Initialized
INFO - 2023-06-06 10:28:44 --> URI Class Initialized
INFO - 2023-06-06 10:28:44 --> Router Class Initialized
INFO - 2023-06-06 10:28:44 --> Output Class Initialized
INFO - 2023-06-06 10:28:44 --> Security Class Initialized
INFO - 2023-06-06 10:28:44 --> Input Class Initialized
INFO - 2023-06-06 10:28:44 --> Language Class Initialized
INFO - 2023-06-06 10:28:44 --> Loader Class Initialized
INFO - 2023-06-06 10:28:44 --> Helper loaded: url_helper
INFO - 2023-06-06 10:28:44 --> Helper loaded: form_helper
INFO - 2023-06-06 10:28:44 --> Database Driver Class Initialized
INFO - 2023-06-06 10:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:28:44 --> Form Validation Class Initialized
INFO - 2023-06-06 10:28:44 --> Controller Class Initialized
INFO - 2023-06-06 10:28:44 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:28:44 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:28:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:28:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:28:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:28:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:28:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:28:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:28:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:28:45 --> Final output sent to browser
INFO - 2023-06-06 10:30:06 --> Config Class Initialized
INFO - 2023-06-06 10:30:06 --> Hooks Class Initialized
INFO - 2023-06-06 10:30:06 --> Utf8 Class Initialized
INFO - 2023-06-06 10:30:06 --> URI Class Initialized
INFO - 2023-06-06 10:30:06 --> Router Class Initialized
INFO - 2023-06-06 10:30:06 --> Output Class Initialized
INFO - 2023-06-06 10:30:06 --> Security Class Initialized
INFO - 2023-06-06 10:30:06 --> Input Class Initialized
INFO - 2023-06-06 10:30:06 --> Language Class Initialized
INFO - 2023-06-06 10:30:06 --> Loader Class Initialized
INFO - 2023-06-06 10:30:06 --> Helper loaded: url_helper
INFO - 2023-06-06 10:30:06 --> Helper loaded: form_helper
INFO - 2023-06-06 10:30:06 --> Database Driver Class Initialized
INFO - 2023-06-06 10:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:30:06 --> Form Validation Class Initialized
INFO - 2023-06-06 10:30:06 --> Controller Class Initialized
INFO - 2023-06-06 10:30:06 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:30:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:30:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:30:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:30:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 10:30:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:30:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:30:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:30:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:30:06 --> Final output sent to browser
INFO - 2023-06-06 10:31:21 --> Config Class Initialized
INFO - 2023-06-06 10:31:21 --> Hooks Class Initialized
INFO - 2023-06-06 10:31:21 --> Utf8 Class Initialized
INFO - 2023-06-06 10:31:21 --> URI Class Initialized
INFO - 2023-06-06 10:31:21 --> Router Class Initialized
INFO - 2023-06-06 10:31:21 --> Output Class Initialized
INFO - 2023-06-06 10:31:21 --> Security Class Initialized
INFO - 2023-06-06 10:31:21 --> Input Class Initialized
INFO - 2023-06-06 10:31:21 --> Language Class Initialized
INFO - 2023-06-06 10:31:21 --> Loader Class Initialized
INFO - 2023-06-06 10:31:21 --> Helper loaded: url_helper
INFO - 2023-06-06 10:31:21 --> Helper loaded: form_helper
INFO - 2023-06-06 10:31:21 --> Database Driver Class Initialized
INFO - 2023-06-06 10:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:31:21 --> Form Validation Class Initialized
INFO - 2023-06-06 10:31:21 --> Controller Class Initialized
INFO - 2023-06-06 10:31:21 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:31:21 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:31:21 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:31:21 --> Final output sent to browser
INFO - 2023-06-06 10:31:34 --> Config Class Initialized
INFO - 2023-06-06 10:31:34 --> Hooks Class Initialized
INFO - 2023-06-06 10:31:34 --> Utf8 Class Initialized
INFO - 2023-06-06 10:31:34 --> URI Class Initialized
INFO - 2023-06-06 10:31:34 --> Router Class Initialized
INFO - 2023-06-06 10:31:34 --> Output Class Initialized
INFO - 2023-06-06 10:31:34 --> Security Class Initialized
INFO - 2023-06-06 10:31:34 --> Input Class Initialized
INFO - 2023-06-06 10:31:34 --> Language Class Initialized
INFO - 2023-06-06 10:31:34 --> Loader Class Initialized
INFO - 2023-06-06 10:31:34 --> Helper loaded: url_helper
INFO - 2023-06-06 10:31:34 --> Helper loaded: form_helper
INFO - 2023-06-06 10:31:34 --> Database Driver Class Initialized
INFO - 2023-06-06 10:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:31:34 --> Form Validation Class Initialized
INFO - 2023-06-06 10:31:34 --> Controller Class Initialized
INFO - 2023-06-06 10:31:34 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:31:34 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:31:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:31:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:31:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 10:31:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:31:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:31:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:31:34 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:31:34 --> Final output sent to browser
INFO - 2023-06-06 10:33:35 --> Config Class Initialized
INFO - 2023-06-06 10:33:35 --> Hooks Class Initialized
INFO - 2023-06-06 10:33:35 --> Utf8 Class Initialized
INFO - 2023-06-06 10:33:35 --> URI Class Initialized
INFO - 2023-06-06 10:33:35 --> Router Class Initialized
INFO - 2023-06-06 10:33:35 --> Output Class Initialized
INFO - 2023-06-06 10:33:35 --> Security Class Initialized
INFO - 2023-06-06 10:33:35 --> Input Class Initialized
INFO - 2023-06-06 10:33:35 --> Language Class Initialized
INFO - 2023-06-06 10:33:35 --> Loader Class Initialized
INFO - 2023-06-06 10:33:35 --> Helper loaded: url_helper
INFO - 2023-06-06 10:33:35 --> Helper loaded: form_helper
INFO - 2023-06-06 10:33:35 --> Database Driver Class Initialized
INFO - 2023-06-06 10:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:33:35 --> Form Validation Class Initialized
INFO - 2023-06-06 10:33:35 --> Controller Class Initialized
INFO - 2023-06-06 10:33:35 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:33:35 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 10:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:33:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:33:35 --> Final output sent to browser
INFO - 2023-06-06 10:33:38 --> Config Class Initialized
INFO - 2023-06-06 10:33:38 --> Hooks Class Initialized
INFO - 2023-06-06 10:33:38 --> Utf8 Class Initialized
INFO - 2023-06-06 10:33:38 --> URI Class Initialized
INFO - 2023-06-06 10:33:38 --> Router Class Initialized
INFO - 2023-06-06 10:33:38 --> Output Class Initialized
INFO - 2023-06-06 10:33:38 --> Security Class Initialized
INFO - 2023-06-06 10:33:38 --> Input Class Initialized
INFO - 2023-06-06 10:33:38 --> Language Class Initialized
INFO - 2023-06-06 10:33:38 --> Loader Class Initialized
INFO - 2023-06-06 10:33:38 --> Helper loaded: url_helper
INFO - 2023-06-06 10:33:38 --> Helper loaded: form_helper
INFO - 2023-06-06 10:33:38 --> Database Driver Class Initialized
INFO - 2023-06-06 10:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:33:38 --> Form Validation Class Initialized
INFO - 2023-06-06 10:33:38 --> Controller Class Initialized
INFO - 2023-06-06 10:33:38 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:33:38 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:33:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:33:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:33:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:33:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:33:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:33:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:33:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:33:38 --> Final output sent to browser
INFO - 2023-06-06 10:39:01 --> Config Class Initialized
INFO - 2023-06-06 10:39:01 --> Hooks Class Initialized
INFO - 2023-06-06 10:39:01 --> Utf8 Class Initialized
INFO - 2023-06-06 10:39:01 --> URI Class Initialized
INFO - 2023-06-06 10:39:01 --> Router Class Initialized
INFO - 2023-06-06 10:39:01 --> Output Class Initialized
INFO - 2023-06-06 10:39:01 --> Security Class Initialized
INFO - 2023-06-06 10:39:01 --> Input Class Initialized
INFO - 2023-06-06 10:39:01 --> Language Class Initialized
INFO - 2023-06-06 10:39:01 --> Loader Class Initialized
INFO - 2023-06-06 10:39:01 --> Helper loaded: url_helper
INFO - 2023-06-06 10:39:01 --> Helper loaded: form_helper
INFO - 2023-06-06 10:39:01 --> Database Driver Class Initialized
INFO - 2023-06-06 10:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:39:01 --> Form Validation Class Initialized
INFO - 2023-06-06 10:39:01 --> Controller Class Initialized
INFO - 2023-06-06 10:39:01 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:39:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:39:01 --> Final output sent to browser
INFO - 2023-06-06 10:55:57 --> Config Class Initialized
INFO - 2023-06-06 10:55:57 --> Hooks Class Initialized
INFO - 2023-06-06 10:55:57 --> Utf8 Class Initialized
INFO - 2023-06-06 10:55:57 --> URI Class Initialized
INFO - 2023-06-06 10:55:57 --> Router Class Initialized
INFO - 2023-06-06 10:55:57 --> Output Class Initialized
INFO - 2023-06-06 10:55:57 --> Security Class Initialized
INFO - 2023-06-06 10:55:57 --> Input Class Initialized
INFO - 2023-06-06 10:55:57 --> Language Class Initialized
INFO - 2023-06-06 10:55:57 --> Loader Class Initialized
INFO - 2023-06-06 10:55:57 --> Helper loaded: url_helper
INFO - 2023-06-06 10:55:57 --> Helper loaded: form_helper
INFO - 2023-06-06 10:55:57 --> Database Driver Class Initialized
INFO - 2023-06-06 10:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:55:57 --> Form Validation Class Initialized
INFO - 2023-06-06 10:55:57 --> Controller Class Initialized
INFO - 2023-06-06 10:55:57 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:55:57 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:55:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:55:57 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-06 10:55:57 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 61
INFO - 2023-06-06 10:56:36 --> Config Class Initialized
INFO - 2023-06-06 10:56:36 --> Hooks Class Initialized
INFO - 2023-06-06 10:56:36 --> Utf8 Class Initialized
INFO - 2023-06-06 10:56:36 --> URI Class Initialized
INFO - 2023-06-06 10:56:36 --> Router Class Initialized
INFO - 2023-06-06 10:56:36 --> Output Class Initialized
INFO - 2023-06-06 10:56:36 --> Security Class Initialized
INFO - 2023-06-06 10:56:36 --> Input Class Initialized
INFO - 2023-06-06 10:56:36 --> Language Class Initialized
INFO - 2023-06-06 10:56:36 --> Loader Class Initialized
INFO - 2023-06-06 10:56:36 --> Helper loaded: url_helper
INFO - 2023-06-06 10:56:36 --> Helper loaded: form_helper
INFO - 2023-06-06 10:56:36 --> Database Driver Class Initialized
INFO - 2023-06-06 10:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:56:36 --> Form Validation Class Initialized
INFO - 2023-06-06 10:56:36 --> Controller Class Initialized
INFO - 2023-06-06 10:56:36 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:56:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:56:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:56:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-06 10:56:37 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 61
INFO - 2023-06-06 10:57:02 --> Config Class Initialized
INFO - 2023-06-06 10:57:02 --> Hooks Class Initialized
INFO - 2023-06-06 10:57:02 --> Utf8 Class Initialized
INFO - 2023-06-06 10:57:02 --> URI Class Initialized
INFO - 2023-06-06 10:57:02 --> Router Class Initialized
INFO - 2023-06-06 10:57:02 --> Output Class Initialized
INFO - 2023-06-06 10:57:02 --> Security Class Initialized
INFO - 2023-06-06 10:57:02 --> Input Class Initialized
INFO - 2023-06-06 10:57:02 --> Language Class Initialized
INFO - 2023-06-06 10:57:02 --> Loader Class Initialized
INFO - 2023-06-06 10:57:02 --> Helper loaded: url_helper
INFO - 2023-06-06 10:57:02 --> Helper loaded: form_helper
INFO - 2023-06-06 10:57:02 --> Database Driver Class Initialized
INFO - 2023-06-06 10:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:57:02 --> Form Validation Class Initialized
INFO - 2023-06-06 10:57:02 --> Controller Class Initialized
INFO - 2023-06-06 10:57:02 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:57:02 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:57:03 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:57:03 --> Final output sent to browser
INFO - 2023-06-06 10:57:13 --> Config Class Initialized
INFO - 2023-06-06 10:57:13 --> Hooks Class Initialized
INFO - 2023-06-06 10:57:13 --> Utf8 Class Initialized
INFO - 2023-06-06 10:57:13 --> URI Class Initialized
INFO - 2023-06-06 10:57:13 --> Router Class Initialized
INFO - 2023-06-06 10:57:13 --> Output Class Initialized
INFO - 2023-06-06 10:57:13 --> Security Class Initialized
INFO - 2023-06-06 10:57:13 --> Input Class Initialized
INFO - 2023-06-06 10:57:13 --> Language Class Initialized
INFO - 2023-06-06 10:57:13 --> Loader Class Initialized
INFO - 2023-06-06 10:57:13 --> Helper loaded: url_helper
INFO - 2023-06-06 10:57:13 --> Helper loaded: form_helper
INFO - 2023-06-06 10:57:13 --> Database Driver Class Initialized
INFO - 2023-06-06 10:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:57:13 --> Form Validation Class Initialized
INFO - 2023-06-06 10:57:13 --> Controller Class Initialized
INFO - 2023-06-06 10:57:13 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:57:13 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:57:14 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:57:14 --> Final output sent to browser
INFO - 2023-06-06 10:58:19 --> Config Class Initialized
INFO - 2023-06-06 10:58:19 --> Hooks Class Initialized
INFO - 2023-06-06 10:58:19 --> Utf8 Class Initialized
INFO - 2023-06-06 10:58:19 --> URI Class Initialized
INFO - 2023-06-06 10:58:19 --> Router Class Initialized
INFO - 2023-06-06 10:58:19 --> Output Class Initialized
INFO - 2023-06-06 10:58:19 --> Security Class Initialized
INFO - 2023-06-06 10:58:19 --> Input Class Initialized
INFO - 2023-06-06 10:58:19 --> Language Class Initialized
INFO - 2023-06-06 10:58:19 --> Loader Class Initialized
INFO - 2023-06-06 10:58:19 --> Helper loaded: url_helper
INFO - 2023-06-06 10:58:19 --> Helper loaded: form_helper
INFO - 2023-06-06 10:58:19 --> Database Driver Class Initialized
INFO - 2023-06-06 10:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:58:19 --> Form Validation Class Initialized
INFO - 2023-06-06 10:58:19 --> Controller Class Initialized
INFO - 2023-06-06 10:58:19 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:58:19 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:58:19 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:58:19 --> Final output sent to browser
INFO - 2023-06-06 10:58:21 --> Config Class Initialized
INFO - 2023-06-06 10:58:21 --> Hooks Class Initialized
INFO - 2023-06-06 10:58:21 --> Utf8 Class Initialized
INFO - 2023-06-06 10:58:21 --> URI Class Initialized
INFO - 2023-06-06 10:58:21 --> Router Class Initialized
INFO - 2023-06-06 10:58:21 --> Output Class Initialized
INFO - 2023-06-06 10:58:21 --> Security Class Initialized
INFO - 2023-06-06 10:58:21 --> Input Class Initialized
INFO - 2023-06-06 10:58:21 --> Language Class Initialized
INFO - 2023-06-06 10:58:21 --> Loader Class Initialized
INFO - 2023-06-06 10:58:21 --> Helper loaded: url_helper
INFO - 2023-06-06 10:58:21 --> Helper loaded: form_helper
INFO - 2023-06-06 10:58:22 --> Database Driver Class Initialized
INFO - 2023-06-06 10:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:58:22 --> Form Validation Class Initialized
INFO - 2023-06-06 10:58:22 --> Controller Class Initialized
INFO - 2023-06-06 10:58:22 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:58:22 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:58:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:58:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:58:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 10:58:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:58:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:58:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:58:22 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:58:22 --> Final output sent to browser
INFO - 2023-06-06 10:58:30 --> Config Class Initialized
INFO - 2023-06-06 10:58:30 --> Hooks Class Initialized
INFO - 2023-06-06 10:58:30 --> Utf8 Class Initialized
INFO - 2023-06-06 10:58:30 --> URI Class Initialized
INFO - 2023-06-06 10:58:30 --> Router Class Initialized
INFO - 2023-06-06 10:58:30 --> Output Class Initialized
INFO - 2023-06-06 10:58:30 --> Security Class Initialized
INFO - 2023-06-06 10:58:30 --> Input Class Initialized
INFO - 2023-06-06 10:58:30 --> Language Class Initialized
INFO - 2023-06-06 10:58:30 --> Loader Class Initialized
INFO - 2023-06-06 10:58:30 --> Helper loaded: url_helper
INFO - 2023-06-06 10:58:30 --> Helper loaded: form_helper
INFO - 2023-06-06 10:58:30 --> Database Driver Class Initialized
INFO - 2023-06-06 10:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:58:30 --> Form Validation Class Initialized
INFO - 2023-06-06 10:58:30 --> Controller Class Initialized
INFO - 2023-06-06 10:58:30 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:58:30 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:58:30 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:58:30 --> Final output sent to browser
INFO - 2023-06-06 10:58:33 --> Config Class Initialized
INFO - 2023-06-06 10:58:33 --> Hooks Class Initialized
INFO - 2023-06-06 10:58:33 --> Utf8 Class Initialized
INFO - 2023-06-06 10:58:33 --> URI Class Initialized
INFO - 2023-06-06 10:58:33 --> Router Class Initialized
INFO - 2023-06-06 10:58:33 --> Output Class Initialized
INFO - 2023-06-06 10:58:33 --> Security Class Initialized
INFO - 2023-06-06 10:58:33 --> Input Class Initialized
INFO - 2023-06-06 10:58:33 --> Language Class Initialized
INFO - 2023-06-06 10:58:33 --> Loader Class Initialized
INFO - 2023-06-06 10:58:33 --> Helper loaded: url_helper
INFO - 2023-06-06 10:58:33 --> Helper loaded: form_helper
INFO - 2023-06-06 10:58:33 --> Database Driver Class Initialized
INFO - 2023-06-06 10:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:58:33 --> Form Validation Class Initialized
INFO - 2023-06-06 10:58:33 --> Controller Class Initialized
INFO - 2023-06-06 10:58:33 --> Model "m_datatrain" initialized
INFO - 2023-06-06 10:58:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:58:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:58:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-06 10:58:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:58:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:58:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:58:33 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:58:33 --> Final output sent to browser
INFO - 2023-06-06 10:58:37 --> Config Class Initialized
INFO - 2023-06-06 10:58:37 --> Hooks Class Initialized
INFO - 2023-06-06 10:58:37 --> Utf8 Class Initialized
INFO - 2023-06-06 10:58:37 --> URI Class Initialized
INFO - 2023-06-06 10:58:37 --> Router Class Initialized
INFO - 2023-06-06 10:58:37 --> Output Class Initialized
INFO - 2023-06-06 10:58:37 --> Security Class Initialized
INFO - 2023-06-06 10:58:37 --> Input Class Initialized
INFO - 2023-06-06 10:58:37 --> Language Class Initialized
INFO - 2023-06-06 10:58:37 --> Loader Class Initialized
INFO - 2023-06-06 10:58:37 --> Helper loaded: url_helper
INFO - 2023-06-06 10:58:37 --> Helper loaded: form_helper
INFO - 2023-06-06 10:58:37 --> Database Driver Class Initialized
INFO - 2023-06-06 10:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:58:37 --> Form Validation Class Initialized
INFO - 2023-06-06 10:58:37 --> Controller Class Initialized
INFO - 2023-06-06 10:58:37 --> Model "m_datatrain" initialized
INFO - 2023-06-06 10:58:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:58:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:58:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_tambah.php
INFO - 2023-06-06 10:58:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:58:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:58:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:58:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:58:37 --> Final output sent to browser
INFO - 2023-06-06 10:58:39 --> Config Class Initialized
INFO - 2023-06-06 10:58:39 --> Hooks Class Initialized
INFO - 2023-06-06 10:58:39 --> Utf8 Class Initialized
INFO - 2023-06-06 10:58:39 --> URI Class Initialized
INFO - 2023-06-06 10:58:39 --> Router Class Initialized
INFO - 2023-06-06 10:58:39 --> Output Class Initialized
INFO - 2023-06-06 10:58:39 --> Security Class Initialized
INFO - 2023-06-06 10:58:39 --> Input Class Initialized
INFO - 2023-06-06 10:58:39 --> Language Class Initialized
INFO - 2023-06-06 10:58:39 --> Loader Class Initialized
INFO - 2023-06-06 10:58:39 --> Helper loaded: url_helper
INFO - 2023-06-06 10:58:39 --> Helper loaded: form_helper
INFO - 2023-06-06 10:58:39 --> Database Driver Class Initialized
INFO - 2023-06-06 10:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:58:39 --> Form Validation Class Initialized
INFO - 2023-06-06 10:58:39 --> Controller Class Initialized
INFO - 2023-06-06 10:58:39 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:58:39 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:58:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:58:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:58:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 10:58:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:58:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:58:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:58:39 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:58:39 --> Final output sent to browser
INFO - 2023-06-06 10:58:42 --> Config Class Initialized
INFO - 2023-06-06 10:58:42 --> Hooks Class Initialized
INFO - 2023-06-06 10:58:42 --> Utf8 Class Initialized
INFO - 2023-06-06 10:58:42 --> URI Class Initialized
INFO - 2023-06-06 10:58:42 --> Router Class Initialized
INFO - 2023-06-06 10:58:42 --> Output Class Initialized
INFO - 2023-06-06 10:58:42 --> Security Class Initialized
INFO - 2023-06-06 10:58:42 --> Input Class Initialized
INFO - 2023-06-06 10:58:42 --> Language Class Initialized
INFO - 2023-06-06 10:58:42 --> Loader Class Initialized
INFO - 2023-06-06 10:58:42 --> Helper loaded: url_helper
INFO - 2023-06-06 10:58:42 --> Helper loaded: form_helper
INFO - 2023-06-06 10:58:42 --> Database Driver Class Initialized
INFO - 2023-06-06 10:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:58:42 --> Form Validation Class Initialized
INFO - 2023-06-06 10:58:42 --> Controller Class Initialized
INFO - 2023-06-06 10:58:42 --> Model "m_datatrain" initialized
INFO - 2023-06-06 10:58:42 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:58:42 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:58:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:58:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:58:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-06-06 10:58:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:58:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:58:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:58:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:58:42 --> Final output sent to browser
INFO - 2023-06-06 10:58:52 --> Config Class Initialized
INFO - 2023-06-06 10:58:52 --> Hooks Class Initialized
INFO - 2023-06-06 10:58:52 --> Utf8 Class Initialized
INFO - 2023-06-06 10:58:52 --> URI Class Initialized
INFO - 2023-06-06 10:58:52 --> Router Class Initialized
INFO - 2023-06-06 10:58:52 --> Output Class Initialized
INFO - 2023-06-06 10:58:52 --> Security Class Initialized
INFO - 2023-06-06 10:58:52 --> Input Class Initialized
INFO - 2023-06-06 10:58:52 --> Language Class Initialized
INFO - 2023-06-06 10:58:52 --> Loader Class Initialized
INFO - 2023-06-06 10:58:52 --> Helper loaded: url_helper
INFO - 2023-06-06 10:58:52 --> Helper loaded: form_helper
INFO - 2023-06-06 10:58:52 --> Database Driver Class Initialized
INFO - 2023-06-06 10:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:58:52 --> Form Validation Class Initialized
INFO - 2023-06-06 10:58:52 --> Controller Class Initialized
INFO - 2023-06-06 10:58:52 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:58:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 10:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:58:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:58:52 --> Final output sent to browser
INFO - 2023-06-06 10:58:54 --> Config Class Initialized
INFO - 2023-06-06 10:58:54 --> Hooks Class Initialized
INFO - 2023-06-06 10:58:54 --> Utf8 Class Initialized
INFO - 2023-06-06 10:58:54 --> URI Class Initialized
INFO - 2023-06-06 10:58:54 --> Router Class Initialized
INFO - 2023-06-06 10:58:54 --> Output Class Initialized
INFO - 2023-06-06 10:58:54 --> Security Class Initialized
INFO - 2023-06-06 10:58:54 --> Input Class Initialized
INFO - 2023-06-06 10:58:54 --> Language Class Initialized
INFO - 2023-06-06 10:58:54 --> Loader Class Initialized
INFO - 2023-06-06 10:58:54 --> Helper loaded: url_helper
INFO - 2023-06-06 10:58:54 --> Helper loaded: form_helper
INFO - 2023-06-06 10:58:54 --> Database Driver Class Initialized
INFO - 2023-06-06 10:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:58:54 --> Form Validation Class Initialized
INFO - 2023-06-06 10:58:54 --> Controller Class Initialized
INFO - 2023-06-06 10:58:54 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:58:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:58:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:58:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:58:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 10:58:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:58:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:58:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:58:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:58:54 --> Final output sent to browser
INFO - 2023-06-06 10:58:56 --> Config Class Initialized
INFO - 2023-06-06 10:58:56 --> Hooks Class Initialized
INFO - 2023-06-06 10:58:56 --> Utf8 Class Initialized
INFO - 2023-06-06 10:58:56 --> URI Class Initialized
INFO - 2023-06-06 10:58:56 --> Router Class Initialized
INFO - 2023-06-06 10:58:56 --> Output Class Initialized
INFO - 2023-06-06 10:58:56 --> Security Class Initialized
INFO - 2023-06-06 10:58:56 --> Input Class Initialized
INFO - 2023-06-06 10:58:56 --> Language Class Initialized
INFO - 2023-06-06 10:58:56 --> Loader Class Initialized
INFO - 2023-06-06 10:58:56 --> Helper loaded: url_helper
INFO - 2023-06-06 10:58:56 --> Helper loaded: form_helper
INFO - 2023-06-06 10:58:56 --> Database Driver Class Initialized
INFO - 2023-06-06 10:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 10:58:56 --> Form Validation Class Initialized
INFO - 2023-06-06 10:58:56 --> Controller Class Initialized
INFO - 2023-06-06 10:58:56 --> Model "m_datatrain" initialized
INFO - 2023-06-06 10:58:56 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 10:58:56 --> Model "m_datatest" initialized
INFO - 2023-06-06 10:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 10:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 10:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_penghitungan.php
INFO - 2023-06-06 10:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 10:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 10:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 10:58:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 10:58:56 --> Final output sent to browser
INFO - 2023-06-06 11:00:56 --> Config Class Initialized
INFO - 2023-06-06 11:00:56 --> Hooks Class Initialized
INFO - 2023-06-06 11:00:56 --> Utf8 Class Initialized
INFO - 2023-06-06 11:00:56 --> URI Class Initialized
INFO - 2023-06-06 11:00:56 --> Router Class Initialized
INFO - 2023-06-06 11:00:56 --> Output Class Initialized
INFO - 2023-06-06 11:00:56 --> Security Class Initialized
INFO - 2023-06-06 11:00:56 --> Input Class Initialized
INFO - 2023-06-06 11:00:56 --> Language Class Initialized
INFO - 2023-06-06 11:00:56 --> Loader Class Initialized
INFO - 2023-06-06 11:00:56 --> Helper loaded: url_helper
INFO - 2023-06-06 11:00:56 --> Helper loaded: form_helper
INFO - 2023-06-06 11:00:56 --> Database Driver Class Initialized
INFO - 2023-06-06 11:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 11:00:56 --> Form Validation Class Initialized
INFO - 2023-06-06 11:00:56 --> Controller Class Initialized
INFO - 2023-06-06 11:00:56 --> Model "m_datatest" initialized
INFO - 2023-06-06 11:00:56 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 11:00:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 11:00:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 11:00:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 11:00:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 11:00:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 11:00:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 11:00:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 11:00:56 --> Final output sent to browser
INFO - 2023-06-06 11:00:59 --> Config Class Initialized
INFO - 2023-06-06 11:00:59 --> Hooks Class Initialized
INFO - 2023-06-06 11:00:59 --> Utf8 Class Initialized
INFO - 2023-06-06 11:00:59 --> URI Class Initialized
INFO - 2023-06-06 11:00:59 --> Router Class Initialized
INFO - 2023-06-06 11:00:59 --> Output Class Initialized
INFO - 2023-06-06 11:00:59 --> Security Class Initialized
INFO - 2023-06-06 11:00:59 --> Input Class Initialized
INFO - 2023-06-06 11:00:59 --> Language Class Initialized
INFO - 2023-06-06 11:00:59 --> Loader Class Initialized
INFO - 2023-06-06 11:00:59 --> Helper loaded: url_helper
INFO - 2023-06-06 11:00:59 --> Helper loaded: form_helper
INFO - 2023-06-06 11:00:59 --> Database Driver Class Initialized
INFO - 2023-06-06 11:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 11:00:59 --> Form Validation Class Initialized
INFO - 2023-06-06 11:00:59 --> Controller Class Initialized
INFO - 2023-06-06 11:00:59 --> Model "m_datatest" initialized
INFO - 2023-06-06 11:00:59 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 11:00:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 11:00:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 11:00:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 11:00:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 11:00:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 11:00:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 11:00:59 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 11:00:59 --> Final output sent to browser
INFO - 2023-06-06 11:01:02 --> Config Class Initialized
INFO - 2023-06-06 11:01:02 --> Hooks Class Initialized
INFO - 2023-06-06 11:01:02 --> Utf8 Class Initialized
INFO - 2023-06-06 11:01:02 --> URI Class Initialized
INFO - 2023-06-06 11:01:02 --> Router Class Initialized
INFO - 2023-06-06 11:01:02 --> Output Class Initialized
INFO - 2023-06-06 11:01:02 --> Security Class Initialized
INFO - 2023-06-06 11:01:02 --> Input Class Initialized
INFO - 2023-06-06 11:01:02 --> Language Class Initialized
INFO - 2023-06-06 11:01:02 --> Loader Class Initialized
INFO - 2023-06-06 11:01:02 --> Helper loaded: url_helper
INFO - 2023-06-06 11:01:02 --> Helper loaded: form_helper
INFO - 2023-06-06 11:01:02 --> Database Driver Class Initialized
INFO - 2023-06-06 11:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 11:01:02 --> Form Validation Class Initialized
INFO - 2023-06-06 11:01:02 --> Controller Class Initialized
INFO - 2023-06-06 11:01:02 --> Model "m_datatest" initialized
INFO - 2023-06-06 11:01:02 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 11:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 11:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 11:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 11:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 11:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 11:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 11:01:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 11:01:02 --> Final output sent to browser
INFO - 2023-06-06 11:03:40 --> Config Class Initialized
INFO - 2023-06-06 11:03:40 --> Hooks Class Initialized
INFO - 2023-06-06 11:03:40 --> Utf8 Class Initialized
INFO - 2023-06-06 11:03:40 --> URI Class Initialized
INFO - 2023-06-06 11:03:40 --> Router Class Initialized
INFO - 2023-06-06 11:03:40 --> Output Class Initialized
INFO - 2023-06-06 11:03:40 --> Security Class Initialized
INFO - 2023-06-06 11:03:40 --> Input Class Initialized
INFO - 2023-06-06 11:03:40 --> Language Class Initialized
INFO - 2023-06-06 11:03:40 --> Loader Class Initialized
INFO - 2023-06-06 11:03:40 --> Helper loaded: url_helper
INFO - 2023-06-06 11:03:40 --> Helper loaded: form_helper
INFO - 2023-06-06 11:03:40 --> Database Driver Class Initialized
INFO - 2023-06-06 11:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 11:03:40 --> Form Validation Class Initialized
INFO - 2023-06-06 11:03:40 --> Controller Class Initialized
INFO - 2023-06-06 11:03:40 --> Model "m_datatest" initialized
INFO - 2023-06-06 11:03:40 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 11:03:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 11:03:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-06 11:03:41 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 67
INFO - 2023-06-06 11:04:06 --> Config Class Initialized
INFO - 2023-06-06 11:04:06 --> Hooks Class Initialized
INFO - 2023-06-06 11:04:06 --> Utf8 Class Initialized
INFO - 2023-06-06 11:04:06 --> URI Class Initialized
INFO - 2023-06-06 11:04:06 --> Router Class Initialized
INFO - 2023-06-06 11:04:06 --> Output Class Initialized
INFO - 2023-06-06 11:04:06 --> Security Class Initialized
INFO - 2023-06-06 11:04:06 --> Input Class Initialized
INFO - 2023-06-06 11:04:06 --> Language Class Initialized
INFO - 2023-06-06 11:04:06 --> Loader Class Initialized
INFO - 2023-06-06 11:04:06 --> Helper loaded: url_helper
INFO - 2023-06-06 11:04:06 --> Helper loaded: form_helper
INFO - 2023-06-06 11:04:06 --> Database Driver Class Initialized
INFO - 2023-06-06 11:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 11:04:06 --> Form Validation Class Initialized
INFO - 2023-06-06 11:04:06 --> Controller Class Initialized
INFO - 2023-06-06 11:04:06 --> Model "m_datatest" initialized
INFO - 2023-06-06 11:04:06 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 11:04:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 11:04:06 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-06 11:04:06 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 67
INFO - 2023-06-06 11:04:54 --> Config Class Initialized
INFO - 2023-06-06 11:04:54 --> Hooks Class Initialized
INFO - 2023-06-06 11:04:54 --> Utf8 Class Initialized
INFO - 2023-06-06 11:04:54 --> URI Class Initialized
INFO - 2023-06-06 11:04:54 --> Router Class Initialized
INFO - 2023-06-06 11:04:54 --> Output Class Initialized
INFO - 2023-06-06 11:04:54 --> Security Class Initialized
INFO - 2023-06-06 11:04:54 --> Input Class Initialized
INFO - 2023-06-06 11:04:54 --> Language Class Initialized
INFO - 2023-06-06 11:04:54 --> Loader Class Initialized
INFO - 2023-06-06 11:04:54 --> Helper loaded: url_helper
INFO - 2023-06-06 11:04:54 --> Helper loaded: form_helper
INFO - 2023-06-06 11:04:54 --> Database Driver Class Initialized
INFO - 2023-06-06 11:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 11:04:54 --> Form Validation Class Initialized
INFO - 2023-06-06 11:04:54 --> Controller Class Initialized
INFO - 2023-06-06 11:04:54 --> Model "m_datatest" initialized
INFO - 2023-06-06 11:04:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 11:04:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 11:04:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-06 11:04:54 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 35
INFO - 2023-06-06 11:05:26 --> Config Class Initialized
INFO - 2023-06-06 11:05:26 --> Hooks Class Initialized
INFO - 2023-06-06 11:05:26 --> Utf8 Class Initialized
INFO - 2023-06-06 11:05:26 --> URI Class Initialized
INFO - 2023-06-06 11:05:26 --> Router Class Initialized
INFO - 2023-06-06 11:05:26 --> Output Class Initialized
INFO - 2023-06-06 11:05:26 --> Security Class Initialized
INFO - 2023-06-06 11:05:26 --> Input Class Initialized
INFO - 2023-06-06 11:05:26 --> Language Class Initialized
INFO - 2023-06-06 11:05:26 --> Loader Class Initialized
INFO - 2023-06-06 11:05:26 --> Helper loaded: url_helper
INFO - 2023-06-06 11:05:26 --> Helper loaded: form_helper
INFO - 2023-06-06 11:05:26 --> Database Driver Class Initialized
INFO - 2023-06-06 11:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 11:05:26 --> Form Validation Class Initialized
INFO - 2023-06-06 11:05:26 --> Controller Class Initialized
INFO - 2023-06-06 11:05:26 --> Model "m_datatest" initialized
INFO - 2023-06-06 11:05:26 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 11:05:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 11:05:26 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-06 11:05:26 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 67
INFO - 2023-06-06 17:01:35 --> Config Class Initialized
INFO - 2023-06-06 17:01:35 --> Hooks Class Initialized
INFO - 2023-06-06 17:01:35 --> Utf8 Class Initialized
INFO - 2023-06-06 17:01:35 --> URI Class Initialized
INFO - 2023-06-06 17:01:35 --> Router Class Initialized
INFO - 2023-06-06 17:01:35 --> Output Class Initialized
INFO - 2023-06-06 17:01:35 --> Security Class Initialized
INFO - 2023-06-06 17:01:35 --> Input Class Initialized
INFO - 2023-06-06 17:01:35 --> Language Class Initialized
INFO - 2023-06-06 17:01:35 --> Loader Class Initialized
INFO - 2023-06-06 17:01:35 --> Helper loaded: url_helper
INFO - 2023-06-06 17:01:35 --> Helper loaded: form_helper
INFO - 2023-06-06 17:01:35 --> Database Driver Class Initialized
INFO - 2023-06-06 17:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:01:35 --> Form Validation Class Initialized
INFO - 2023-06-06 17:01:35 --> Controller Class Initialized
INFO - 2023-06-06 17:01:35 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-06 17:01:35 --> Final output sent to browser
INFO - 2023-06-06 17:01:38 --> Config Class Initialized
INFO - 2023-06-06 17:01:38 --> Hooks Class Initialized
INFO - 2023-06-06 17:01:38 --> Utf8 Class Initialized
INFO - 2023-06-06 17:01:38 --> URI Class Initialized
INFO - 2023-06-06 17:01:38 --> Router Class Initialized
INFO - 2023-06-06 17:01:38 --> Output Class Initialized
INFO - 2023-06-06 17:01:38 --> Security Class Initialized
INFO - 2023-06-06 17:01:38 --> Input Class Initialized
INFO - 2023-06-06 17:01:38 --> Language Class Initialized
INFO - 2023-06-06 17:01:38 --> Loader Class Initialized
INFO - 2023-06-06 17:01:38 --> Helper loaded: url_helper
INFO - 2023-06-06 17:01:38 --> Helper loaded: form_helper
INFO - 2023-06-06 17:01:38 --> Database Driver Class Initialized
INFO - 2023-06-06 17:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:01:38 --> Form Validation Class Initialized
INFO - 2023-06-06 17:01:38 --> Controller Class Initialized
INFO - 2023-06-06 17:01:38 --> Model "m_user" initialized
INFO - 2023-06-06 17:01:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-06 17:01:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-06 17:01:38 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-06 17:01:38 --> Final output sent to browser
INFO - 2023-06-06 17:01:42 --> Config Class Initialized
INFO - 2023-06-06 17:01:42 --> Hooks Class Initialized
INFO - 2023-06-06 17:01:42 --> Utf8 Class Initialized
INFO - 2023-06-06 17:01:42 --> URI Class Initialized
INFO - 2023-06-06 17:01:42 --> Router Class Initialized
INFO - 2023-06-06 17:01:42 --> Output Class Initialized
INFO - 2023-06-06 17:01:42 --> Security Class Initialized
INFO - 2023-06-06 17:01:42 --> Input Class Initialized
INFO - 2023-06-06 17:01:42 --> Language Class Initialized
INFO - 2023-06-06 17:01:42 --> Loader Class Initialized
INFO - 2023-06-06 17:01:42 --> Helper loaded: url_helper
INFO - 2023-06-06 17:01:42 --> Helper loaded: form_helper
INFO - 2023-06-06 17:01:42 --> Database Driver Class Initialized
INFO - 2023-06-06 17:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:01:42 --> Form Validation Class Initialized
INFO - 2023-06-06 17:01:42 --> Controller Class Initialized
INFO - 2023-06-06 17:01:42 --> Model "m_user" initialized
INFO - 2023-06-06 17:01:42 --> Config Class Initialized
INFO - 2023-06-06 17:01:42 --> Hooks Class Initialized
INFO - 2023-06-06 17:01:42 --> Utf8 Class Initialized
INFO - 2023-06-06 17:01:42 --> URI Class Initialized
INFO - 2023-06-06 17:01:42 --> Router Class Initialized
INFO - 2023-06-06 17:01:42 --> Output Class Initialized
INFO - 2023-06-06 17:01:42 --> Security Class Initialized
INFO - 2023-06-06 17:01:42 --> Input Class Initialized
INFO - 2023-06-06 17:01:42 --> Language Class Initialized
INFO - 2023-06-06 17:01:42 --> Loader Class Initialized
INFO - 2023-06-06 17:01:42 --> Helper loaded: url_helper
INFO - 2023-06-06 17:01:42 --> Helper loaded: form_helper
INFO - 2023-06-06 17:01:42 --> Database Driver Class Initialized
INFO - 2023-06-06 17:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:01:42 --> Form Validation Class Initialized
INFO - 2023-06-06 17:01:42 --> Controller Class Initialized
INFO - 2023-06-06 17:01:42 --> Model "m_user" initialized
INFO - 2023-06-06 17:01:42 --> Model "m_datatrain" initialized
INFO - 2023-06-06 17:01:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:01:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:01:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:01:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:01:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:01:42 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-06 17:01:42 --> Final output sent to browser
INFO - 2023-06-06 17:01:44 --> Config Class Initialized
INFO - 2023-06-06 17:01:44 --> Hooks Class Initialized
INFO - 2023-06-06 17:01:44 --> Utf8 Class Initialized
INFO - 2023-06-06 17:01:44 --> URI Class Initialized
INFO - 2023-06-06 17:01:44 --> Router Class Initialized
INFO - 2023-06-06 17:01:44 --> Output Class Initialized
INFO - 2023-06-06 17:01:44 --> Security Class Initialized
INFO - 2023-06-06 17:01:44 --> Input Class Initialized
INFO - 2023-06-06 17:01:44 --> Language Class Initialized
INFO - 2023-06-06 17:01:44 --> Loader Class Initialized
INFO - 2023-06-06 17:01:44 --> Helper loaded: url_helper
INFO - 2023-06-06 17:01:45 --> Helper loaded: form_helper
INFO - 2023-06-06 17:01:45 --> Database Driver Class Initialized
INFO - 2023-06-06 17:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:01:45 --> Form Validation Class Initialized
INFO - 2023-06-06 17:01:45 --> Controller Class Initialized
INFO - 2023-06-06 17:01:45 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:01:45 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:01:45 --> Final output sent to browser
INFO - 2023-06-06 17:01:47 --> Config Class Initialized
INFO - 2023-06-06 17:01:47 --> Hooks Class Initialized
INFO - 2023-06-06 17:01:47 --> Utf8 Class Initialized
INFO - 2023-06-06 17:01:47 --> URI Class Initialized
INFO - 2023-06-06 17:01:47 --> Router Class Initialized
INFO - 2023-06-06 17:01:47 --> Output Class Initialized
INFO - 2023-06-06 17:01:47 --> Security Class Initialized
INFO - 2023-06-06 17:01:47 --> Input Class Initialized
INFO - 2023-06-06 17:01:47 --> Language Class Initialized
INFO - 2023-06-06 17:01:47 --> Loader Class Initialized
INFO - 2023-06-06 17:01:47 --> Helper loaded: url_helper
INFO - 2023-06-06 17:01:47 --> Helper loaded: form_helper
INFO - 2023-06-06 17:01:47 --> Database Driver Class Initialized
INFO - 2023-06-06 17:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:01:47 --> Form Validation Class Initialized
INFO - 2023-06-06 17:01:47 --> Controller Class Initialized
INFO - 2023-06-06 17:01:47 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:01:47 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:01:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:01:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:01:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:01:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:01:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:01:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:01:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:01:47 --> Final output sent to browser
INFO - 2023-06-06 17:03:13 --> Config Class Initialized
INFO - 2023-06-06 17:03:13 --> Hooks Class Initialized
INFO - 2023-06-06 17:03:13 --> Utf8 Class Initialized
INFO - 2023-06-06 17:03:13 --> URI Class Initialized
INFO - 2023-06-06 17:03:13 --> Router Class Initialized
INFO - 2023-06-06 17:03:13 --> Output Class Initialized
INFO - 2023-06-06 17:03:13 --> Security Class Initialized
INFO - 2023-06-06 17:03:13 --> Input Class Initialized
INFO - 2023-06-06 17:03:13 --> Language Class Initialized
INFO - 2023-06-06 17:03:13 --> Loader Class Initialized
INFO - 2023-06-06 17:03:13 --> Helper loaded: url_helper
INFO - 2023-06-06 17:03:13 --> Helper loaded: form_helper
INFO - 2023-06-06 17:03:13 --> Database Driver Class Initialized
INFO - 2023-06-06 17:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:03:13 --> Form Validation Class Initialized
INFO - 2023-06-06 17:03:13 --> Controller Class Initialized
INFO - 2023-06-06 17:03:13 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:03:13 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:03:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:03:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:03:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:03:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:03:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:03:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:03:13 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:03:13 --> Final output sent to browser
INFO - 2023-06-06 17:12:41 --> Config Class Initialized
INFO - 2023-06-06 17:12:41 --> Hooks Class Initialized
INFO - 2023-06-06 17:12:41 --> Utf8 Class Initialized
INFO - 2023-06-06 17:12:41 --> URI Class Initialized
INFO - 2023-06-06 17:12:41 --> Router Class Initialized
INFO - 2023-06-06 17:12:41 --> Output Class Initialized
INFO - 2023-06-06 17:12:41 --> Security Class Initialized
INFO - 2023-06-06 17:12:41 --> Input Class Initialized
INFO - 2023-06-06 17:12:41 --> Language Class Initialized
INFO - 2023-06-06 17:12:41 --> Loader Class Initialized
INFO - 2023-06-06 17:12:41 --> Helper loaded: url_helper
INFO - 2023-06-06 17:12:41 --> Helper loaded: form_helper
INFO - 2023-06-06 17:12:41 --> Database Driver Class Initialized
INFO - 2023-06-06 17:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:12:41 --> Form Validation Class Initialized
INFO - 2023-06-06 17:12:41 --> Controller Class Initialized
INFO - 2023-06-06 17:12:41 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:12:41 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:12:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:12:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:12:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 17:12:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:12:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:12:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:12:41 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:12:41 --> Final output sent to browser
INFO - 2023-06-06 17:12:44 --> Config Class Initialized
INFO - 2023-06-06 17:12:44 --> Hooks Class Initialized
INFO - 2023-06-06 17:12:44 --> Utf8 Class Initialized
INFO - 2023-06-06 17:12:44 --> URI Class Initialized
INFO - 2023-06-06 17:12:44 --> Router Class Initialized
INFO - 2023-06-06 17:12:44 --> Output Class Initialized
INFO - 2023-06-06 17:12:44 --> Security Class Initialized
INFO - 2023-06-06 17:12:44 --> Input Class Initialized
INFO - 2023-06-06 17:12:44 --> Language Class Initialized
INFO - 2023-06-06 17:12:44 --> Loader Class Initialized
INFO - 2023-06-06 17:12:44 --> Helper loaded: url_helper
INFO - 2023-06-06 17:12:44 --> Helper loaded: form_helper
INFO - 2023-06-06 17:12:44 --> Database Driver Class Initialized
INFO - 2023-06-06 17:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:12:44 --> Form Validation Class Initialized
INFO - 2023-06-06 17:12:44 --> Controller Class Initialized
INFO - 2023-06-06 17:12:44 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:12:44 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:12:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:12:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:12:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:12:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:12:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:12:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:12:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:12:44 --> Final output sent to browser
INFO - 2023-06-06 17:12:47 --> Config Class Initialized
INFO - 2023-06-06 17:12:47 --> Hooks Class Initialized
INFO - 2023-06-06 17:12:47 --> Utf8 Class Initialized
INFO - 2023-06-06 17:12:47 --> URI Class Initialized
INFO - 2023-06-06 17:12:47 --> Router Class Initialized
INFO - 2023-06-06 17:12:47 --> Output Class Initialized
INFO - 2023-06-06 17:12:47 --> Security Class Initialized
INFO - 2023-06-06 17:12:47 --> Input Class Initialized
INFO - 2023-06-06 17:12:47 --> Language Class Initialized
INFO - 2023-06-06 17:12:47 --> Loader Class Initialized
INFO - 2023-06-06 17:12:47 --> Helper loaded: url_helper
INFO - 2023-06-06 17:12:47 --> Helper loaded: form_helper
INFO - 2023-06-06 17:12:47 --> Database Driver Class Initialized
INFO - 2023-06-06 17:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:12:47 --> Form Validation Class Initialized
INFO - 2023-06-06 17:12:47 --> Controller Class Initialized
INFO - 2023-06-06 17:12:47 --> Model "m_datatrain" initialized
INFO - 2023-06-06 17:12:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:12:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:12:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatrain/v_datatrain.php
INFO - 2023-06-06 17:12:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:12:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:12:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:12:47 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:12:47 --> Final output sent to browser
INFO - 2023-06-06 17:12:50 --> Config Class Initialized
INFO - 2023-06-06 17:12:50 --> Hooks Class Initialized
INFO - 2023-06-06 17:12:50 --> Utf8 Class Initialized
INFO - 2023-06-06 17:12:50 --> URI Class Initialized
INFO - 2023-06-06 17:12:50 --> Router Class Initialized
INFO - 2023-06-06 17:12:50 --> Output Class Initialized
INFO - 2023-06-06 17:12:50 --> Security Class Initialized
INFO - 2023-06-06 17:12:50 --> Input Class Initialized
INFO - 2023-06-06 17:12:50 --> Language Class Initialized
INFO - 2023-06-06 17:12:50 --> Loader Class Initialized
INFO - 2023-06-06 17:12:50 --> Helper loaded: url_helper
INFO - 2023-06-06 17:12:50 --> Helper loaded: form_helper
INFO - 2023-06-06 17:12:50 --> Database Driver Class Initialized
INFO - 2023-06-06 17:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:12:50 --> Form Validation Class Initialized
INFO - 2023-06-06 17:12:50 --> Controller Class Initialized
INFO - 2023-06-06 17:12:50 --> Model "m_user" initialized
INFO - 2023-06-06 17:12:50 --> Config Class Initialized
INFO - 2023-06-06 17:12:50 --> Hooks Class Initialized
INFO - 2023-06-06 17:12:50 --> Utf8 Class Initialized
INFO - 2023-06-06 17:12:50 --> URI Class Initialized
INFO - 2023-06-06 17:12:50 --> Router Class Initialized
INFO - 2023-06-06 17:12:50 --> Output Class Initialized
INFO - 2023-06-06 17:12:50 --> Security Class Initialized
INFO - 2023-06-06 17:12:50 --> Input Class Initialized
INFO - 2023-06-06 17:12:50 --> Language Class Initialized
INFO - 2023-06-06 17:12:50 --> Loader Class Initialized
INFO - 2023-06-06 17:12:50 --> Helper loaded: url_helper
INFO - 2023-06-06 17:12:50 --> Helper loaded: form_helper
INFO - 2023-06-06 17:12:50 --> Database Driver Class Initialized
INFO - 2023-06-06 17:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:12:50 --> Form Validation Class Initialized
INFO - 2023-06-06 17:12:50 --> Controller Class Initialized
INFO - 2023-06-06 17:12:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-06 17:12:50 --> Final output sent to browser
INFO - 2023-06-06 17:12:52 --> Config Class Initialized
INFO - 2023-06-06 17:12:52 --> Hooks Class Initialized
INFO - 2023-06-06 17:12:52 --> Utf8 Class Initialized
INFO - 2023-06-06 17:12:52 --> URI Class Initialized
INFO - 2023-06-06 17:12:52 --> Router Class Initialized
INFO - 2023-06-06 17:12:52 --> Output Class Initialized
INFO - 2023-06-06 17:12:52 --> Security Class Initialized
INFO - 2023-06-06 17:12:52 --> Input Class Initialized
INFO - 2023-06-06 17:12:52 --> Language Class Initialized
INFO - 2023-06-06 17:12:52 --> Loader Class Initialized
INFO - 2023-06-06 17:12:52 --> Helper loaded: url_helper
INFO - 2023-06-06 17:12:52 --> Helper loaded: form_helper
INFO - 2023-06-06 17:12:52 --> Database Driver Class Initialized
INFO - 2023-06-06 17:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:12:52 --> Form Validation Class Initialized
INFO - 2023-06-06 17:12:52 --> Controller Class Initialized
INFO - 2023-06-06 17:12:52 --> Model "m_user" initialized
INFO - 2023-06-06 17:12:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:12:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:12:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-06 17:12:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:12:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:12:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-06 17:12:52 --> Final output sent to browser
INFO - 2023-06-06 17:12:54 --> Config Class Initialized
INFO - 2023-06-06 17:12:54 --> Hooks Class Initialized
INFO - 2023-06-06 17:12:54 --> Utf8 Class Initialized
INFO - 2023-06-06 17:12:54 --> URI Class Initialized
INFO - 2023-06-06 17:12:54 --> Router Class Initialized
INFO - 2023-06-06 17:12:54 --> Output Class Initialized
INFO - 2023-06-06 17:12:54 --> Security Class Initialized
INFO - 2023-06-06 17:12:54 --> Input Class Initialized
INFO - 2023-06-06 17:12:54 --> Language Class Initialized
INFO - 2023-06-06 17:12:54 --> Loader Class Initialized
INFO - 2023-06-06 17:12:54 --> Helper loaded: url_helper
INFO - 2023-06-06 17:12:54 --> Helper loaded: form_helper
INFO - 2023-06-06 17:12:54 --> Database Driver Class Initialized
INFO - 2023-06-06 17:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:12:54 --> Form Validation Class Initialized
INFO - 2023-06-06 17:12:54 --> Controller Class Initialized
INFO - 2023-06-06 17:12:54 --> Model "m_datatrain" initialized
INFO - 2023-06-06 17:12:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:12:54 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:12:54 --> Model "M_solusi" initialized
INFO - 2023-06-06 17:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\diagnosa/v_diagnosa.php
INFO - 2023-06-06 17:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-06 17:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:12:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template_user.php
INFO - 2023-06-06 17:12:54 --> Final output sent to browser
INFO - 2023-06-06 17:12:56 --> Config Class Initialized
INFO - 2023-06-06 17:12:56 --> Hooks Class Initialized
INFO - 2023-06-06 17:12:56 --> Utf8 Class Initialized
INFO - 2023-06-06 17:12:56 --> URI Class Initialized
INFO - 2023-06-06 17:12:56 --> Router Class Initialized
INFO - 2023-06-06 17:12:56 --> Output Class Initialized
INFO - 2023-06-06 17:12:56 --> Security Class Initialized
INFO - 2023-06-06 17:12:56 --> Input Class Initialized
INFO - 2023-06-06 17:12:56 --> Language Class Initialized
INFO - 2023-06-06 17:12:56 --> Loader Class Initialized
INFO - 2023-06-06 17:12:56 --> Helper loaded: url_helper
INFO - 2023-06-06 17:12:56 --> Helper loaded: form_helper
INFO - 2023-06-06 17:12:56 --> Database Driver Class Initialized
INFO - 2023-06-06 17:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:12:56 --> Form Validation Class Initialized
INFO - 2023-06-06 17:12:56 --> Controller Class Initialized
INFO - 2023-06-06 17:12:56 --> Model "m_user" initialized
INFO - 2023-06-06 17:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-06 17:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:12:56 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-06 17:12:56 --> Final output sent to browser
INFO - 2023-06-06 17:12:58 --> Config Class Initialized
INFO - 2023-06-06 17:12:58 --> Hooks Class Initialized
INFO - 2023-06-06 17:12:58 --> Utf8 Class Initialized
INFO - 2023-06-06 17:12:58 --> URI Class Initialized
INFO - 2023-06-06 17:12:58 --> Router Class Initialized
INFO - 2023-06-06 17:12:58 --> Output Class Initialized
INFO - 2023-06-06 17:12:58 --> Security Class Initialized
INFO - 2023-06-06 17:12:58 --> Input Class Initialized
INFO - 2023-06-06 17:12:58 --> Language Class Initialized
INFO - 2023-06-06 17:12:58 --> Loader Class Initialized
INFO - 2023-06-06 17:12:58 --> Helper loaded: url_helper
INFO - 2023-06-06 17:12:58 --> Helper loaded: form_helper
INFO - 2023-06-06 17:12:58 --> Database Driver Class Initialized
INFO - 2023-06-06 17:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:12:58 --> Form Validation Class Initialized
INFO - 2023-06-06 17:12:58 --> Controller Class Initialized
INFO - 2023-06-06 17:12:58 --> Model "m_user" initialized
INFO - 2023-06-06 17:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar_user.php
INFO - 2023-06-06 17:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:12:58 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home_user.php
INFO - 2023-06-06 17:12:58 --> Final output sent to browser
INFO - 2023-06-06 17:13:01 --> Config Class Initialized
INFO - 2023-06-06 17:13:01 --> Hooks Class Initialized
INFO - 2023-06-06 17:13:01 --> Utf8 Class Initialized
INFO - 2023-06-06 17:13:01 --> URI Class Initialized
INFO - 2023-06-06 17:13:01 --> Router Class Initialized
INFO - 2023-06-06 17:13:01 --> Output Class Initialized
INFO - 2023-06-06 17:13:01 --> Security Class Initialized
INFO - 2023-06-06 17:13:01 --> Input Class Initialized
INFO - 2023-06-06 17:13:01 --> Language Class Initialized
INFO - 2023-06-06 17:13:01 --> Loader Class Initialized
INFO - 2023-06-06 17:13:01 --> Helper loaded: url_helper
INFO - 2023-06-06 17:13:01 --> Helper loaded: form_helper
INFO - 2023-06-06 17:13:01 --> Database Driver Class Initialized
INFO - 2023-06-06 17:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:13:01 --> Form Validation Class Initialized
INFO - 2023-06-06 17:13:01 --> Controller Class Initialized
INFO - 2023-06-06 17:13:01 --> Model "m_user" initialized
INFO - 2023-06-06 17:13:01 --> Config Class Initialized
INFO - 2023-06-06 17:13:01 --> Hooks Class Initialized
INFO - 2023-06-06 17:13:01 --> Utf8 Class Initialized
INFO - 2023-06-06 17:13:01 --> URI Class Initialized
INFO - 2023-06-06 17:13:01 --> Router Class Initialized
INFO - 2023-06-06 17:13:01 --> Output Class Initialized
INFO - 2023-06-06 17:13:01 --> Security Class Initialized
INFO - 2023-06-06 17:13:01 --> Input Class Initialized
INFO - 2023-06-06 17:13:01 --> Language Class Initialized
INFO - 2023-06-06 17:13:01 --> Loader Class Initialized
INFO - 2023-06-06 17:13:01 --> Helper loaded: url_helper
INFO - 2023-06-06 17:13:01 --> Helper loaded: form_helper
INFO - 2023-06-06 17:13:01 --> Database Driver Class Initialized
INFO - 2023-06-06 17:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:13:01 --> Form Validation Class Initialized
INFO - 2023-06-06 17:13:01 --> Controller Class Initialized
INFO - 2023-06-06 17:13:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\welcome_message.php
INFO - 2023-06-06 17:13:01 --> Final output sent to browser
INFO - 2023-06-06 17:13:43 --> Config Class Initialized
INFO - 2023-06-06 17:13:43 --> Hooks Class Initialized
INFO - 2023-06-06 17:13:43 --> Utf8 Class Initialized
INFO - 2023-06-06 17:13:43 --> URI Class Initialized
INFO - 2023-06-06 17:13:43 --> Router Class Initialized
INFO - 2023-06-06 17:13:43 --> Output Class Initialized
INFO - 2023-06-06 17:13:43 --> Security Class Initialized
INFO - 2023-06-06 17:13:43 --> Input Class Initialized
INFO - 2023-06-06 17:13:43 --> Language Class Initialized
INFO - 2023-06-06 17:13:43 --> Loader Class Initialized
INFO - 2023-06-06 17:13:43 --> Helper loaded: url_helper
INFO - 2023-06-06 17:13:43 --> Helper loaded: form_helper
INFO - 2023-06-06 17:13:43 --> Database Driver Class Initialized
INFO - 2023-06-06 17:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:13:43 --> Form Validation Class Initialized
INFO - 2023-06-06 17:13:43 --> Controller Class Initialized
INFO - 2023-06-06 17:13:43 --> Model "m_user" initialized
INFO - 2023-06-06 17:13:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_header.php
INFO - 2023-06-06 17:13:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\auth/login.php
INFO - 2023-06-06 17:13:43 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\templates/auth_footer.php
INFO - 2023-06-06 17:13:43 --> Final output sent to browser
INFO - 2023-06-06 17:13:50 --> Config Class Initialized
INFO - 2023-06-06 17:13:50 --> Hooks Class Initialized
INFO - 2023-06-06 17:13:50 --> Utf8 Class Initialized
INFO - 2023-06-06 17:13:50 --> URI Class Initialized
INFO - 2023-06-06 17:13:50 --> Router Class Initialized
INFO - 2023-06-06 17:13:50 --> Output Class Initialized
INFO - 2023-06-06 17:13:50 --> Security Class Initialized
INFO - 2023-06-06 17:13:50 --> Input Class Initialized
INFO - 2023-06-06 17:13:50 --> Language Class Initialized
INFO - 2023-06-06 17:13:50 --> Loader Class Initialized
INFO - 2023-06-06 17:13:50 --> Helper loaded: url_helper
INFO - 2023-06-06 17:13:50 --> Helper loaded: form_helper
INFO - 2023-06-06 17:13:50 --> Database Driver Class Initialized
INFO - 2023-06-06 17:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:13:50 --> Form Validation Class Initialized
INFO - 2023-06-06 17:13:50 --> Controller Class Initialized
INFO - 2023-06-06 17:13:50 --> Model "m_user" initialized
INFO - 2023-06-06 17:13:50 --> Config Class Initialized
INFO - 2023-06-06 17:13:50 --> Hooks Class Initialized
INFO - 2023-06-06 17:13:50 --> Utf8 Class Initialized
INFO - 2023-06-06 17:13:50 --> URI Class Initialized
INFO - 2023-06-06 17:13:50 --> Router Class Initialized
INFO - 2023-06-06 17:13:50 --> Output Class Initialized
INFO - 2023-06-06 17:13:50 --> Security Class Initialized
INFO - 2023-06-06 17:13:50 --> Input Class Initialized
INFO - 2023-06-06 17:13:50 --> Language Class Initialized
INFO - 2023-06-06 17:13:50 --> Loader Class Initialized
INFO - 2023-06-06 17:13:50 --> Helper loaded: url_helper
INFO - 2023-06-06 17:13:50 --> Helper loaded: form_helper
INFO - 2023-06-06 17:13:50 --> Database Driver Class Initialized
INFO - 2023-06-06 17:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:13:50 --> Form Validation Class Initialized
INFO - 2023-06-06 17:13:50 --> Controller Class Initialized
INFO - 2023-06-06 17:13:50 --> Model "m_user" initialized
INFO - 2023-06-06 17:13:50 --> Model "m_datatrain" initialized
INFO - 2023-06-06 17:13:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:13:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:13:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:13:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:13:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:13:50 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\home/v_home.php
INFO - 2023-06-06 17:13:50 --> Final output sent to browser
INFO - 2023-06-06 17:13:52 --> Config Class Initialized
INFO - 2023-06-06 17:13:52 --> Hooks Class Initialized
INFO - 2023-06-06 17:13:52 --> Utf8 Class Initialized
INFO - 2023-06-06 17:13:52 --> URI Class Initialized
INFO - 2023-06-06 17:13:52 --> Router Class Initialized
INFO - 2023-06-06 17:13:52 --> Output Class Initialized
INFO - 2023-06-06 17:13:52 --> Security Class Initialized
INFO - 2023-06-06 17:13:52 --> Input Class Initialized
INFO - 2023-06-06 17:13:52 --> Language Class Initialized
INFO - 2023-06-06 17:13:52 --> Loader Class Initialized
INFO - 2023-06-06 17:13:52 --> Helper loaded: url_helper
INFO - 2023-06-06 17:13:52 --> Helper loaded: form_helper
INFO - 2023-06-06 17:13:52 --> Database Driver Class Initialized
INFO - 2023-06-06 17:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:13:52 --> Form Validation Class Initialized
INFO - 2023-06-06 17:13:52 --> Controller Class Initialized
INFO - 2023-06-06 17:13:52 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:13:52 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:13:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:13:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:13:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_datatest.php
INFO - 2023-06-06 17:13:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:13:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:13:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:13:52 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:13:52 --> Final output sent to browser
INFO - 2023-06-06 17:13:53 --> Config Class Initialized
INFO - 2023-06-06 17:13:53 --> Hooks Class Initialized
INFO - 2023-06-06 17:13:53 --> Utf8 Class Initialized
INFO - 2023-06-06 17:13:53 --> URI Class Initialized
INFO - 2023-06-06 17:13:53 --> Router Class Initialized
INFO - 2023-06-06 17:13:53 --> Output Class Initialized
INFO - 2023-06-06 17:13:53 --> Security Class Initialized
INFO - 2023-06-06 17:13:53 --> Input Class Initialized
INFO - 2023-06-06 17:13:53 --> Language Class Initialized
INFO - 2023-06-06 17:13:53 --> Loader Class Initialized
INFO - 2023-06-06 17:13:53 --> Helper loaded: url_helper
INFO - 2023-06-06 17:13:53 --> Helper loaded: form_helper
INFO - 2023-06-06 17:13:54 --> Database Driver Class Initialized
INFO - 2023-06-06 17:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:13:54 --> Form Validation Class Initialized
INFO - 2023-06-06 17:13:54 --> Controller Class Initialized
INFO - 2023-06-06 17:13:54 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:13:54 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:13:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:13:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-06 17:13:54 --> Severity: Notice --> Undefined variable: a1 C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 36
ERROR - 2023-06-06 17:13:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 36
INFO - 2023-06-06 17:13:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:13:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:13:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:13:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:13:54 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:13:54 --> Final output sent to browser
INFO - 2023-06-06 17:14:29 --> Config Class Initialized
INFO - 2023-06-06 17:14:29 --> Hooks Class Initialized
INFO - 2023-06-06 17:14:29 --> Utf8 Class Initialized
INFO - 2023-06-06 17:14:29 --> URI Class Initialized
INFO - 2023-06-06 17:14:29 --> Router Class Initialized
INFO - 2023-06-06 17:14:29 --> Output Class Initialized
INFO - 2023-06-06 17:14:29 --> Security Class Initialized
INFO - 2023-06-06 17:14:29 --> Input Class Initialized
INFO - 2023-06-06 17:14:29 --> Language Class Initialized
INFO - 2023-06-06 17:14:29 --> Loader Class Initialized
INFO - 2023-06-06 17:14:29 --> Helper loaded: url_helper
INFO - 2023-06-06 17:14:29 --> Helper loaded: form_helper
INFO - 2023-06-06 17:14:29 --> Database Driver Class Initialized
INFO - 2023-06-06 17:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:14:29 --> Form Validation Class Initialized
INFO - 2023-06-06 17:14:29 --> Controller Class Initialized
INFO - 2023-06-06 17:14:29 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:14:29 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:14:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:14:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-06 17:14:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 36
INFO - 2023-06-06 17:14:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:14:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:14:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:14:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:14:29 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:14:29 --> Final output sent to browser
INFO - 2023-06-06 17:16:44 --> Config Class Initialized
INFO - 2023-06-06 17:16:44 --> Hooks Class Initialized
INFO - 2023-06-06 17:16:44 --> Utf8 Class Initialized
INFO - 2023-06-06 17:16:44 --> URI Class Initialized
INFO - 2023-06-06 17:16:44 --> Router Class Initialized
INFO - 2023-06-06 17:16:44 --> Output Class Initialized
INFO - 2023-06-06 17:16:44 --> Security Class Initialized
INFO - 2023-06-06 17:16:44 --> Input Class Initialized
INFO - 2023-06-06 17:16:44 --> Language Class Initialized
INFO - 2023-06-06 17:16:44 --> Loader Class Initialized
INFO - 2023-06-06 17:16:44 --> Helper loaded: url_helper
INFO - 2023-06-06 17:16:44 --> Helper loaded: form_helper
INFO - 2023-06-06 17:16:44 --> Database Driver Class Initialized
INFO - 2023-06-06 17:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:16:44 --> Form Validation Class Initialized
INFO - 2023-06-06 17:16:44 --> Controller Class Initialized
INFO - 2023-06-06 17:16:44 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:16:44 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:16:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:16:44 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:16:45 --> Severity: Warning --> Illegal string offset 'a2' C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 44
ERROR - 2023-06-06 17:16:45 --> Severity: Warning --> Illegal string offset 'a3' C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 50
ERROR - 2023-06-06 17:16:45 --> Severity: Warning --> Illegal string offset 'a4' C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 55
ERROR - 2023-06-06 17:16:45 --> Severity: Warning --> Illegal string offset 'a5' C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 60
ERROR - 2023-06-06 17:16:45 --> Severity: Warning --> Illegal string offset 'a6' C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 65
INFO - 2023-06-06 17:16:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:16:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:16:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:16:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:16:45 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:16:45 --> Final output sent to browser
INFO - 2023-06-06 17:18:01 --> Config Class Initialized
INFO - 2023-06-06 17:18:01 --> Hooks Class Initialized
INFO - 2023-06-06 17:18:01 --> Utf8 Class Initialized
INFO - 2023-06-06 17:18:01 --> URI Class Initialized
INFO - 2023-06-06 17:18:01 --> Router Class Initialized
INFO - 2023-06-06 17:18:01 --> Output Class Initialized
INFO - 2023-06-06 17:18:01 --> Security Class Initialized
INFO - 2023-06-06 17:18:01 --> Input Class Initialized
INFO - 2023-06-06 17:18:01 --> Language Class Initialized
INFO - 2023-06-06 17:18:01 --> Loader Class Initialized
INFO - 2023-06-06 17:18:01 --> Helper loaded: url_helper
INFO - 2023-06-06 17:18:01 --> Helper loaded: form_helper
INFO - 2023-06-06 17:18:01 --> Database Driver Class Initialized
INFO - 2023-06-06 17:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:18:01 --> Form Validation Class Initialized
INFO - 2023-06-06 17:18:01 --> Controller Class Initialized
INFO - 2023-06-06 17:18:01 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:18:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 37
ERROR - 2023-06-06 17:18:01 --> Severity: Warning --> Illegal string offset 'a2' C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 44
ERROR - 2023-06-06 17:18:01 --> Severity: Warning --> Illegal string offset 'a3' C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 50
ERROR - 2023-06-06 17:18:01 --> Severity: Warning --> Illegal string offset 'a4' C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 55
ERROR - 2023-06-06 17:18:01 --> Severity: Warning --> Illegal string offset 'a5' C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 60
ERROR - 2023-06-06 17:18:01 --> Severity: Warning --> Illegal string offset 'a6' C:\xampp\htdocs\sistemdiagnosa\application\views\datatest\v_penghitungan.php 65
INFO - 2023-06-06 17:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:18:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:18:01 --> Final output sent to browser
INFO - 2023-06-06 17:20:02 --> Config Class Initialized
INFO - 2023-06-06 17:20:02 --> Hooks Class Initialized
INFO - 2023-06-06 17:20:02 --> Utf8 Class Initialized
INFO - 2023-06-06 17:20:02 --> URI Class Initialized
INFO - 2023-06-06 17:20:02 --> Router Class Initialized
INFO - 2023-06-06 17:20:02 --> Output Class Initialized
INFO - 2023-06-06 17:20:02 --> Security Class Initialized
INFO - 2023-06-06 17:20:02 --> Input Class Initialized
INFO - 2023-06-06 17:20:02 --> Language Class Initialized
INFO - 2023-06-06 17:20:02 --> Loader Class Initialized
INFO - 2023-06-06 17:20:02 --> Helper loaded: url_helper
INFO - 2023-06-06 17:20:02 --> Helper loaded: form_helper
INFO - 2023-06-06 17:20:02 --> Database Driver Class Initialized
INFO - 2023-06-06 17:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:20:02 --> Form Validation Class Initialized
INFO - 2023-06-06 17:20:02 --> Controller Class Initialized
INFO - 2023-06-06 17:20:02 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:20:02 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:20:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:20:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:20:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:20:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:20:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:20:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:20:02 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:20:02 --> Final output sent to browser
INFO - 2023-06-06 17:22:53 --> Config Class Initialized
INFO - 2023-06-06 17:22:53 --> Hooks Class Initialized
INFO - 2023-06-06 17:22:53 --> Utf8 Class Initialized
INFO - 2023-06-06 17:22:53 --> URI Class Initialized
INFO - 2023-06-06 17:22:53 --> Router Class Initialized
INFO - 2023-06-06 17:22:53 --> Output Class Initialized
INFO - 2023-06-06 17:22:53 --> Security Class Initialized
INFO - 2023-06-06 17:22:53 --> Input Class Initialized
INFO - 2023-06-06 17:22:53 --> Language Class Initialized
INFO - 2023-06-06 17:22:53 --> Loader Class Initialized
INFO - 2023-06-06 17:22:53 --> Helper loaded: url_helper
INFO - 2023-06-06 17:22:53 --> Helper loaded: form_helper
INFO - 2023-06-06 17:22:53 --> Database Driver Class Initialized
INFO - 2023-06-06 17:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:22:53 --> Form Validation Class Initialized
INFO - 2023-06-06 17:22:53 --> Controller Class Initialized
INFO - 2023-06-06 17:22:53 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:22:53 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:22:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:22:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:22:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:22:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:22:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:22:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:22:53 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:22:53 --> Final output sent to browser
INFO - 2023-06-06 17:28:55 --> Config Class Initialized
INFO - 2023-06-06 17:28:55 --> Hooks Class Initialized
INFO - 2023-06-06 17:28:55 --> Utf8 Class Initialized
INFO - 2023-06-06 17:28:55 --> URI Class Initialized
INFO - 2023-06-06 17:28:55 --> Router Class Initialized
INFO - 2023-06-06 17:28:55 --> Output Class Initialized
INFO - 2023-06-06 17:28:55 --> Security Class Initialized
INFO - 2023-06-06 17:28:55 --> Input Class Initialized
INFO - 2023-06-06 17:28:55 --> Language Class Initialized
INFO - 2023-06-06 17:28:55 --> Loader Class Initialized
INFO - 2023-06-06 17:28:55 --> Helper loaded: url_helper
INFO - 2023-06-06 17:28:55 --> Helper loaded: form_helper
INFO - 2023-06-06 17:28:55 --> Database Driver Class Initialized
INFO - 2023-06-06 17:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:28:55 --> Form Validation Class Initialized
INFO - 2023-06-06 17:28:55 --> Controller Class Initialized
INFO - 2023-06-06 17:28:55 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:28:55 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:28:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:28:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:28:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:28:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:28:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:28:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:28:55 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:28:55 --> Final output sent to browser
INFO - 2023-06-06 17:29:17 --> Config Class Initialized
INFO - 2023-06-06 17:29:17 --> Hooks Class Initialized
INFO - 2023-06-06 17:29:17 --> Utf8 Class Initialized
INFO - 2023-06-06 17:29:17 --> URI Class Initialized
INFO - 2023-06-06 17:29:17 --> Router Class Initialized
INFO - 2023-06-06 17:29:17 --> Output Class Initialized
INFO - 2023-06-06 17:29:17 --> Security Class Initialized
INFO - 2023-06-06 17:29:17 --> Input Class Initialized
INFO - 2023-06-06 17:29:17 --> Language Class Initialized
INFO - 2023-06-06 17:29:17 --> Loader Class Initialized
INFO - 2023-06-06 17:29:17 --> Helper loaded: url_helper
INFO - 2023-06-06 17:29:17 --> Helper loaded: form_helper
INFO - 2023-06-06 17:29:17 --> Database Driver Class Initialized
INFO - 2023-06-06 17:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:29:17 --> Form Validation Class Initialized
INFO - 2023-06-06 17:29:17 --> Controller Class Initialized
INFO - 2023-06-06 17:29:17 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:29:17 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:29:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:29:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:29:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:29:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:29:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:29:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:29:18 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:29:18 --> Final output sent to browser
INFO - 2023-06-06 17:39:01 --> Config Class Initialized
INFO - 2023-06-06 17:39:01 --> Hooks Class Initialized
INFO - 2023-06-06 17:39:01 --> Utf8 Class Initialized
INFO - 2023-06-06 17:39:01 --> URI Class Initialized
INFO - 2023-06-06 17:39:01 --> Router Class Initialized
INFO - 2023-06-06 17:39:01 --> Output Class Initialized
INFO - 2023-06-06 17:39:01 --> Security Class Initialized
INFO - 2023-06-06 17:39:01 --> Input Class Initialized
INFO - 2023-06-06 17:39:01 --> Language Class Initialized
INFO - 2023-06-06 17:39:01 --> Loader Class Initialized
INFO - 2023-06-06 17:39:01 --> Helper loaded: url_helper
INFO - 2023-06-06 17:39:01 --> Helper loaded: form_helper
INFO - 2023-06-06 17:39:01 --> Database Driver Class Initialized
INFO - 2023-06-06 17:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:39:01 --> Form Validation Class Initialized
INFO - 2023-06-06 17:39:01 --> Controller Class Initialized
INFO - 2023-06-06 17:39:01 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:39:01 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:39:01 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:39:01 --> Final output sent to browser
INFO - 2023-06-06 17:55:15 --> Config Class Initialized
INFO - 2023-06-06 17:55:15 --> Hooks Class Initialized
INFO - 2023-06-06 17:55:15 --> Utf8 Class Initialized
INFO - 2023-06-06 17:55:15 --> URI Class Initialized
INFO - 2023-06-06 17:55:15 --> Router Class Initialized
INFO - 2023-06-06 17:55:15 --> Output Class Initialized
INFO - 2023-06-06 17:55:15 --> Security Class Initialized
INFO - 2023-06-06 17:55:15 --> Input Class Initialized
INFO - 2023-06-06 17:55:15 --> Language Class Initialized
INFO - 2023-06-06 17:55:15 --> Loader Class Initialized
INFO - 2023-06-06 17:55:15 --> Helper loaded: url_helper
INFO - 2023-06-06 17:55:15 --> Helper loaded: form_helper
INFO - 2023-06-06 17:55:15 --> Database Driver Class Initialized
INFO - 2023-06-06 17:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 17:55:15 --> Form Validation Class Initialized
INFO - 2023-06-06 17:55:15 --> Controller Class Initialized
INFO - 2023-06-06 17:55:15 --> Model "m_datatest" initialized
INFO - 2023-06-06 17:55:15 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 17:55:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 17:55:15 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 17:55:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 17:55:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 17:55:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 17:55:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 17:55:16 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 17:55:16 --> Final output sent to browser
INFO - 2023-06-06 18:02:36 --> Config Class Initialized
INFO - 2023-06-06 18:02:36 --> Hooks Class Initialized
INFO - 2023-06-06 18:02:36 --> Utf8 Class Initialized
INFO - 2023-06-06 18:02:36 --> URI Class Initialized
INFO - 2023-06-06 18:02:36 --> Router Class Initialized
INFO - 2023-06-06 18:02:36 --> Output Class Initialized
INFO - 2023-06-06 18:02:36 --> Security Class Initialized
INFO - 2023-06-06 18:02:36 --> Input Class Initialized
INFO - 2023-06-06 18:02:36 --> Language Class Initialized
INFO - 2023-06-06 18:02:36 --> Loader Class Initialized
INFO - 2023-06-06 18:02:36 --> Helper loaded: url_helper
INFO - 2023-06-06 18:02:36 --> Helper loaded: form_helper
INFO - 2023-06-06 18:02:36 --> Database Driver Class Initialized
INFO - 2023-06-06 18:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 18:02:36 --> Form Validation Class Initialized
INFO - 2023-06-06 18:02:36 --> Controller Class Initialized
INFO - 2023-06-06 18:02:36 --> Model "m_datatest" initialized
INFO - 2023-06-06 18:02:36 --> Model "m_penghitungan" initialized
INFO - 2023-06-06 18:02:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/head.php
INFO - 2023-06-06 18:02:36 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/navbar.php
INFO - 2023-06-06 18:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\datatest/v_penghitungan.php
INFO - 2023-06-06 18:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/sidebar.php
INFO - 2023-06-06 18:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/footer.php
INFO - 2023-06-06 18:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\_partials/script.php
INFO - 2023-06-06 18:02:37 --> File loaded: C:\xampp\htdocs\sistemdiagnosa\application\views\template.php
INFO - 2023-06-06 18:02:37 --> Final output sent to browser
