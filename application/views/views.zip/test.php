<div class="pageheader ">
	<h3> <a href="home " style="color:#fff;"><i class="fa fa-home "></i> </a>Test Page</h3>
	<div class="breadcrumb-wrapper">
		<span class="label">You are here:</span>
		<ol class="breadcrumb">
			<li> <a href="c_home"> Home </a> </li>
			<li class="active"> Test Page </li>
		</ol>
	</div>
</div>
<!-- Basic Data Tables -->
<!--===================================================-->
<!--Page content-->
<!--===================================================-->
<div id="page-content">
	<div class="row">
		<div class="col-md-12">

			<div class="panel">
				
				<div class="panel-body" style="padding: 5px;">
				<?php echo $testing;
				?>
				
				</div>
			</div>
		</div>
	</div>
</div>




