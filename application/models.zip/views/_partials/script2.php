
<!--Switchery [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/switchery/switchery.min.js')?>"></script>
<!--Jquery Steps [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/parsley/parsley.min.js')?>"></script>
<!--Jquery Steps [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/jquery-steps/jquery-steps.min.js')?>"></script>
<!--Bootstrap Select [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/bootstrap-select/bootstrap-select.min.js')?>"></script>
<!--Bootstrap Wizard [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/bootstrap-wizard/jquery.bootstrap.wizard.min.js')?>"></script>
<!--Masked Input [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/masked-input/bootstrap-inputmask.min.js')?>"></script>
<!--Bootstrap Validator [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/bootstrap-validator/bootstrapValidator.min.js')?>"></script>
<!--Flot Chart [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/flot-charts/jquery.flot.min.js')?>"></script>
<script src="<?php echo base_url('assets/admin/plugins/flot-charts/jquery.flot.resize.min.js')?>"></script>
<script src="<?php echo base_url('assets/admin/plugins/flot-charts/jquery.flot.spline.js')?>"></script>
<script src="<?php echo base_url('assets/admin/plugins/flot-charts/jquery.flot.pie.min.js')?>"></script>
<script src="<?php echo base_url('assets/admin/plugins/moment/moment.min.js')?>"></script>
<script src="<?php echo base_url('assets/admin/plugins/moment-range/moment-range.js')?>"></script>
<script src="<?php echo base_url('assets/admin/plugins/flot-charts/jquery.flot.tooltip.min.js')?>"></script>
<!--Flot Order Bars Chart [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/flot-charts/jquery.flot.categories.js')?>"></script>
<!--ricksaw.js'?> [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/jquery-ricksaw-chart/js/raphael-min.js')?>"></script>
<script src="<?php echo base_url('assets/admin/plugins/jquery-ricksaw-chart/js/d3.v2.js')?>"></script>
<script src="<?php echo base_url('assets/admin/plugins/jquery-ricksaw-chart/js/rickshaw.min.js')?>"></script>
<script src="<?php echo base_url('assets/admin/plugins/jquery-ricksaw-chart/ricksaw.js')?>"></script>
<!--Summernote [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/summernote/summernote.min.js')?>"></script>
<!--Fullscreen jQuery [ OPTIONAL ]-->
<script src="<?php echo base_url('assets/admin/plugins/screenfull/screenfull.js')?>"></script>
<!--Form Wizard [ SAMPLE ]-->
<script src="<?php echo base_url('assets/admin/js/demo/wizard.js')?>"></script>
<!--Form Wizard [ SAMPLE ]-->
<script src="<?php echo base_url('assets/admin/js/demo/form-wizard.js')?>"></script>
<script src="<?php echo base_url('assets/admin/js/demo/dashboard-v2.js')?>"></script>


