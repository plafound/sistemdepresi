<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> <?php echo SITE_NAME ." : ". ucfirst($this->uri->segment(1)) ." - ". ucfirst($this->uri->segment(2)) ?></title>
<link rel="icon" href="<?= base_url('assets/assetslogin/img');?>/logounp.png" type="image/png">
<!--STYLESHEET-->
<!--=================================================-->
<!--Roboto Slab Font [ OPTIONAL ] -->
<link href="http://fonts.googleapis.com/css?family=Roboto+Slab:400,300,100,700" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Roboto:500,400italic,100,700italic,300,700,500italic,400"
	rel="stylesheet">
<!--Bootstrap Stylesheet [ REQUIRED ]-->
<link href="<?php echo base_url('assets/admin/css/bootstrap.min.css')?>" rel="stylesheet">
<!--Jasmine Stylesheet [ REQUIRED ]-->
<link href="<?php echo base_url('assets/admin/css/style.css')?>" rel="stylesheet">
<!--Font Awesome [ OPTIONAL ]-->
<link href="<?php echo base_url('assets/admin/plugins/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet">
<!--Switchery [ OPTIONAL ]-->
<link href="<?php echo base_url('assets/admin/plugins/switchery/switchery.min.css')?>" rel="stylesheet">
<!--Bootstrap Select [ OPTIONAL ]-->
<link href="<?php echo base_url('assets/admin/plugins/bootstrap-select/bootstrap-select.min.css')?>" rel="stylesheet">
<!--ricksaw.js [ OPTIONAL ]-->
<link href="<?php echo base_url('assets/admin/plugins/jquery-ricksaw-chart/css/rickshaw.css')?>" rel="stylesheet">
<!--Bootstrap Validator [ OPTIONAL ]-->
<link href="<?php echo base_url('assets/admin/plugins/bootstrap-validator/bootstrapValidator.min.css')?>"
	rel="stylesheet">
<!--Demo [ DEMONSTRATION ]-->
<link href="<?php echo base_url('assets/admin/css/demo/jquery-steps.min.css')?>" rel="stylesheet">
<!--Summernote [ OPTIONAL ]-->
<link href="<?php echo base_url('assets/admin/plugins/summernote/summernote.min.css')?>" rel="stylesheet">

<!--Bootstrap Table [ OPTIONAL ]-->
<link href="<?php echo base_url('assets/admin/plugins/datatables/media/css/dataTables.bootstrap.css')?>" rel="stylesheet">
<link href="<?php echo base_url('assets/admin/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css')?>" rel="stylesheet">
		<!--Demo [ DEMONSTRATION ]-->
<link href="<?php echo base_url('assets/admin/css/demo/jasmine.css')?>" rel="stylesheet">
<!--SCRIPT-->
<!--=================================================-->
<!--Page Load Progress Bar [ OPTIONAL ]-->
<link href="<?php echo base_url('assets/admin/plugins/pace/pace.min.css')?>" rel="stylesheet">
<script src="<?php echo base_url('assets/admin/plugins/pace/pace.min.js')?>"></script>


